# China_s virtual water trade through the metacoupling framework_ å…¨ç¨‹è€¦åˆæ¡†æž¶ä¸‹ä¸­å›½è™šæ‹Ÿæ°´

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:07:48.918798+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Sun et al. - 2025 - China_s virtual water trade through the metacoupling framework_ å…¨ç¨‹è€¦åˆæ¡†æž¶ä¸‹ä¸­å›½è™šæ‹Ÿæ°´.pdf
- Year: unknown
- DOI: 10.11821/dlxb202501006
- OA status: unknown
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: no license info, oa_status=unknown

## Copyright-Safe Summary
This paper analyzes Chinas interprovincial virtual water trade using the metacoupling framework, which distinguishes intra-provincial interactions, adjacent (neighboring) linkages, long-distance linkages, and spillover systems. The study covers 30 provincial-level regions of China in 2012 and 2017, focusing on domestic trade only.

Methodologically, the authors build a multi-regional input-output model extended with water-use coefficients to quantify virtual water flows between provinces and sectors. They then adapt the WWZ value-added decomposition approach to trace how third-party provinces contribute virtual water embodied in traded intermediate and final goods, thereby identifying upstream and downstream spillover virtual water. Finally, they evaluate how different trade configurations affect progress toward SDG 6.4 (sustainable water withdrawal and supply) by comparing trade and no-trade scenarios.

Results show that most virtual water is consumed within provinces (about 78 percent), while cross-provincial trade accounts for roughly one-fifth, dominated by long-distance rather than neighboring exchanges. Manufacturing and agriculture together use around two-thirds of total virtual water. Spillover systems are substantial and growing: upstream and downstream spillover virtual water combined reach nearly half of all traded virtual water by 2017, with Jiangsu and Jilin standing out for upstream spillovers and Xinjiang and Heilongjiang for downstream spillovers, largely due to water-intensive grain production.

Sectorally, manufacturing, construction, and agriculture are the main drivers of upstream spillovers, while manufacturing and agriculture dominate downstream spillovers. Long-distance trade generates more spillover virtual water than trade with neighbors. Virtual water trade improves Chinas average SDG 6.4 performance by about 5-6 percent, especially benefiting economically developed but water-scarce coastal provinces, while some less developed or agricultural regions experience increased water pressure.

The paper explicitly applies and extends the metacoupling framework (sending, receiving, and spillover systems; near vs distant coupling) to virtual water, demonstrating how internal, adjacent, distant, and spillover linkages jointly reshape regional water sustainability outcomes.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong intracoupling of provincial water use, plus peri- and telecoupled virtual water trade
- Telecoupling dominates over pericoupling in interprovincial virtual water flows

### Intracoupling
#### Systems
- Chinese provinces as water use and production systems
- Human-nature coupled water systems within each province
#### Flows
- Local blue water consumption in agriculture and industry
- Internal virtual water embodied in provincially consumed products
#### Agents
- Provincial production sectors, especially agriculture and manufacturing
- Provincial governments managing water and development
#### Causes
- Local economic growth and industrial structure
- Population and food demand within provinces
- Provincial water resource endowment and stress
#### Effects
- High share of water use met by internal resources
- Changes in provincial SDG 6.4 scores without trade

### Pericoupling
#### Systems
- Neighboring Chinese provinces linked by short-distance trade
- Quadrant groups of provinces by GDP and water stress
#### Flows
- Peripheral virtual water trade between adjacent provinces
- Upstream and downstream spillover water tied to nearby value chains
#### Agents
- Interprovincial supply chains among neighboring provinces
- Regional planners and basin-level water managers
#### Causes
- Geographic proximity and similar economic structures
- Regional integration and nearby market access
#### Effects
- Pericoupling weaker than telecoupling but increasing over time
- Limited or negative SDG 6.4 gains for some poorer neighbors

### Telecoupling
#### Systems
- Distant Chinese provinces as sending and receiving systems
- Spillover provinces as third-party systems in national value chains
#### Flows
- Long-distance virtual water trade in goods and services
- Upstream and downstream virtual water spillovers via third parties
- Associated value added, finance, and technology flows
#### Agents
- Manufacturing, construction, and agricultural sectors driving trade
- National government shaping trade and water policies
- Domestic consumers and firms demanding traded products
#### Causes
- Regional differences in water endowment and economic level
- Comparative advantage and national food security policies
- Deepening domestic value chain specialization
#### Effects
- Major contribution to improving national SDG 6.4 performance
- Relief of water stress in rich but water-poor provinces
- Heightened water pressure or losses in some poor exporting provinces

### Cross-Coupling Interactions
- Intracoupling dominates total water use, while telecoupling dominates traded water and spillovers
- Spillover systems mediate between peri- and telecoupled trade links

### Research Gaps or Limitations
- International virtual water trade not integrated with the domestic metacoupling analysis
- Impact assessment focused mainly on SDG 6.4, omitting broader socio-environmental tradeoffs
- Green water dynamics and transfers excluded from calculations

### Search Keywords
- China virtual water trade metacoupling
- upstream downstream spillover systems
- SDG 6.4 interprovincial water

### Extraction Confidence
high
