RESEARCH ARTICLE

# Linking food systems and landscape sustainability in the Mediterranean region

Marı´a Garcı´a-Martı´n $\textcircled{1}$ . Mario Torralba $\textcircled{1}$ . Cristina Quintas-Soriano $\textcircled{1}$ Johannes Kahl $\textcircled { 1 0 }$ . Tobias Plieninger $\textcircled{1}$

Received: 29 January 2020 / Accepted: 19 November 2020 / Published online: 8 December 2020 $©$ The Author(s) 2020

# Abstract

Context Global dynamics affect the sustainability of agricultural landscapes, but these cross-scale connections are understudied. Therefore, we combine food systems and landscape ecology, focusing on food products that provide a linkage between global consumers and landscapes of production (e.g., Douro Valley wine) which we call landscape products. Objective The aim of this study is to characterise Mediterranean landscape products based on experts’ perceptions by analysing their qualities, farming practices, and value chains, and to identify their ecological, cultural, and socio-economic outcomes in the landscapes of production.

Supplementary Information The online version contains supplementary material available at https://doi.org/10.1007/ s10980-020-01168-5.

M. Garcı´a-Martı´n $( \boxtimes )$ - T. Plieninger Department of Agricultural Economics and Rural Development, University of Go¨ttingen, Platz der Go¨ttinger Sieben 5, 37073 Go¨ttingen, Germany e-mail: maria.garcia-martin@uni-goettingen.de

M. Torralba $\cdot$ C. Quintas-Soriano - T. Plieninger Faculty of Organic Agricultural Sciences, University of Kassel, Steinstraße 19, 37213 Witzenhausen, Germany

J. Kahl Faculty of Organic Agricultural Sciences, University of Kassel, Nordbahnhofstr. 1a, 37213 Witzenhausen, Germany

Methods Experts with specific knowledge on a landscape product were surveyed by email and their answers analysed using descriptive and ordination statistics. Fifty-four landscape products were characterised.

Results Based on the experts’ perceptions, landscape products are high quality products, mainly using traditional knowledge and low intensity farming. They support biocultural diversity in the landscapes of production, but their positive socio-economic outcomes remain limited, with problems of inequity and lack of empowerment among producers and a tendency towards intensification or abandonment of the farming practices. We distinguished three types of products based on their localness and how their qualities were shared with consumers. Local products performed better in the ecological and cultural outcomes and products under certification in the economic. Labelling mechanisms and better organisation of producers could enhance these products and their positive outcomes.

Conclusions Combining landscape ecology and food systems research allowed us better understand the outcomes of landscape products in the landscapes of production and suggest pathways for fostering landscape sustainability.

Keywords Landscape products $\cdot$ Social-ecological systems - Telecouplings - Food systems $\cdot$ Landscape ecology $\cdot$ Landscape sustainability

# Introduction

Global change in agricultural landscapes is a major sustainability concern. Agricultural landscape change is driven by a multitude of (typically closely interlinked) processes. First, agricultural land is expanding globally, converting natural and semi-natural ecosystems and thus compromising biosphere integrity and ecological processes in land systems (Steffen et al. 2015). Second, rising societal needs for food, feed, fibres, and fuels also lead to an intensification of agriculture (Erb et al. 2013). Third, an increasing amount of (often fertile) agricultural land is sealed and converted to cities, with substantial impacts on agricultural production, biodiversity, and ecosystem services (Seto et al. 2012). At the same time, largescale processes of de-intensification, forest expansion, and designation of protected areas are taking place, often leading to a polarisation of intensification and abandonment of agriculture (Plieninger et al. 2016). Consequently, competition for land, land-use conflicts, and trade-offs between human needs and agricultural landscape functions have become critical topics for landscape ecology.

Agricultural landscape changes—though manifested at local levels—are increasingly driven by globally interconnected economies and markets for food products and other agricultural commodities which act across large distances and create interactions between regions (Meyfroidt et al. 2013). The complexity of these connections between distant places (so-called telecouplings Liu et al. 2013) pose not only threats but also opportunities for landscape sustainability (e.g., regarding biodiversity, land use, poverty reduction, and water scarcity). For instance, increased world trade in biofuels triggers agricultural expansion across large distances, often resulting in losses of ecosystems and biodiversity. On the other hand, the growing demand from urban consumers for high-quality and sustainable food products can drive land-use decisions in remote places, improving rural livelihoods and promoting multifunctional landscapes (Rueda and Lambin 2013). Thus, the characteristics of food systems, and in particular the trade-offs around them, show complex linkages to landscape sustainability.

Food products that originate from specific distinct landscapes (termed ‘landscape products’ herein) represent a particular case (Ilbery and Kneafsey 1999).

These products are deeply linked to the local identity and landscape character of the places of production and are part of a ‘quality turn’ in food consumption by parts of society in Europe and beyond (Goodman 2002). Examples of these landscape products from the Mediterranean region are olive oil produced in the Greek island of Lesvos; ham from acorn-fed pigs raised in wooded pastures in Extremadura, Spain; and wine produced in the Portuguese Alto Douro region. Although landscape products are usually traded on niche markets, they can offer leverage points for promoting sustainable management of producer landscapes when they have high market values and cultivation is tied to specific regions (le Polain de Waroux and Lambin 2013). However, while the role of mass-market food products has been widely studied (e.g., for palm oil or soybeans; Boerema et al. 2016; Furumo and Aide 2017), little is known about how these landscape products may contribute to landscape sustainability in the places of production.

Landscape ecology and food systems are two research areas in which an interdisciplinary, systems-oriented research approach is taken, with the former centred on configuration and functioning of landscapes (Christensen et al. 2017) and the latter focussed on the production, processing, retailing, and consumption of food (Ingram 2011). Food system studies evidence an interest in studying the places from which foods originate (Barham and Sylvander 2011; Bowen and Mutersbaugh 2014; Berriss 2019), and some landscape ecological studies have in turn investigated the landscape ecological dynamics around food and agricultural production at large (Benoıˆt et al. 2012; Smith et al. 2013). However, landscape ecology and food systems studies have not thus far been linked through a comprehensive and systematic framework.

The aim of this study is to bring together landscape ecology and food systems approaches to explore the connections between different properties of food systems and multiple landscape sustainability outcomes in the Mediterranean region, using landscape products as a critical link between distant places and processes. To do so, we define the following research questions:

1. How are Mediterranean landscape products characterised based on the shared attributes of their food systems?

2. What are the ecological, cultural, social, and economic landscape sustainability outcomes of these landscape products, and what synergies and trade-offs arise among them?   
3. What different types of food systems can be identified and how do they relate to the landscape sustainability outcomes?

The assumption underlying this research is that food systems and landscapes are a crucial but underutilized nexus for evaluating the connections between people and the environment. We consider that an indepth understanding of these couplings will benefit both landscape ecology and food system research to foster landscape sustainability.

# Methods

Study area: the Mediterranean region

We focus on the Mediterranean region to study the linkages between food systems and landscape sustainability. Mediterranean landscapes are very diverse in food systems (the Mediterranean diet has been declared an intangible cultural heritage of humanity; UNESCO 2013) and are a global hotspot of biological diversity (Myers et al. 2000). At the same time, the Mediterranean region is most critically affected by global environmental changes, in particular by soil degradation and water shortages (Underwood et al. 2009). Mediterranean farming landscapes have resulted from a very long human history that interacts with highly varied physiography, soil, and climate, thus becoming archetypes of closely coupled social– ecological systems. Mediterranean traditional agriculture is dominated by agro-silvo-pastoral mosaic systems that cover approximately $23 \%$ of the land (Malek and Verburg 2017). Spatial–temporal interactions between agricultural, pastoral, and forestry components typically result in a high resource use efficiency, high biodiversity values, a large assortment of commodities, and other ecosystem services. Many Mediterranean farming systems are thus considered to be multifunctional and of high nature value (Pinto-Correia and Vos 2004). It is also a region characterised by contrasts: While landscapes at the southern fringe of the Mediterranean (especially in the productive plains) are predominantly exposed to increasing land-

use pressures and competition for land, many farmlands in the northern Mediterranean countries (especially in the less productive mountain areas) have been affected by land abandonment (Debolini et al. 2018). Furthermore, many of the major ongoing socioeconomic challenges are taking place in this region regarding demographic trends, political stability, and socio-economic realities (King et al. 2014). Given these social–ecological contrasts, the Mediterranean region provides a useful microcosm for the study of different food systems and agricultural landscapes.

# Concepts

According to the Landscape Ecology journal, landscape ecology is an interdisciplinary research field that integrates the biophysical and socioeconomic sciences, conceptualises landscapes as coupled human–environment systems, and applies such a lens in answering research questions around the ecology, conservation, management, design/planning, and sustainability of landscapes. While investigating the relationship between spatial pattern and ecological processes is at the heart of landscape ecology, sustainability has become a key concept and research priority in this field (Musacchio 2013; Wu 2019). Landscape ecology informs sustainability through spatially explicit approaches; consideration of multiple scales; integration of stakeholders’ knowledge, values, and concerns; and social–ecological systems thinking (Opdam et al. 2018). The term ‘landscape sustainability science’ emphasises the linkages between landscape ecology and sustainability science, and there is a discussion as to whether landscape sustainability science should be understood as part of landscape ecology or as a distinct field (Wu 2013).

Food systems comprise sets of activities that include production and consumption of food (Ericksen 2008; Ingram 2011). According to UNEP (2016) a food system approach allows the food chain activities to be linked to their social and environmental contexts, including institutional dimensions (rules and regulations), jurisdictional dimensions, and administrative dimensions (provincial, national, intergovernmental). Therefore, food systems are recognised as coupled human–environment systems (Liu et al. 2007) and especially as complex social–ecological systems (Ostrom 2009; Foran et al. 2014; Tendall et al. 2015; Allen and Prosperi 2016). For Ostrom (2009), the

challenge of taking a systems approach to food is to identify and analyse the relationships among multiple levels of these complex systems at different spatial and temporal scales. Food systems as complex adaptive systems are ‘composed of many heterogeneous pieces, whose interactions drive system behaviour in ways that cannot easily be understood from considering the components separately’ (Nesheim et al. 2015, p. 287). In this view, landscapes may also be taken as an inherent part of food systems, whether as a prerequisite, a driver, or an outcome. Therefore, we go beyond a food chain approach and study food chain and landscape sustainability components in combination.

Figure 1 presents the framework used in this study, which comprises food systems and landscape sustainability as central pillars that are connected through landscape products. We define landscape products as products that originate in a distinct landscape and typically are sold at prices higher than those of usual agricultural commodities (le Polain de Waroux and Lambin 2013). In our analysis of food systems and their linkages to landscape sustainability through landscape products, the following are of particular interest‘‘

• the product qualities, such as the geographic origin of the product, the traits associated with it (e.g., healthy, organic, gourmet, or traditional; le Polain

# FOOD SYSTEM OF LANDSCAPE PRODUCTS

Product qualities

traits

Geographicorigin

Certification mechanisms

Farming practices

Intensity

Land cover type

Producers'size

Farmers cooperatives

Value chain characteristics

Communication channels

distribution channels

Processingand packaging

Geographic distance to consumers

Landscape sustainability outcomes

Ecological

Biodiversity

Waterresources preservation

Soilmaintenance

Cultural

Local culture

Identity

localrecipes

Social

Genderand age balance

Collaboration among farmers (collective action)

Empowerment offarmers (particip.inoperationalrules)

Equity

(fair profit distribution)

Economic

Localemployment

farmers'income

Higher prices

tourism

Fig. 1 Elements considered to connect food with landscape sustainability through landscape products

de Waroux and Lambin 2013; Renting et al. 2003), the product identity in reference to the territory of production, and the existence of any certification;

• the farming practices that are underpinning the landscape product, as related to the intensity of production systems and associated land covers, the size of the producers, and the presence of farmers’ cooperatives (Ostrom 2007);   
• the value chain characteristics, including producing, processing, distributing, and retailing goods to consumers (Gereffi et al. 2005). These include the way in which the qualities of the product are communicated to the consumer (e.g., personal interaction, regional identity, certifications; Renting et al. 2003), and aspects related to the length of the value chain such as the distribution channels (e.g., farmers sell directly to consumers or farmers sell to retailers or distributors), where the packaging and processing takes place (i.e., within or outside the landscape of production), and the geographic distance to the market (e.g., regional and local markets or national and international markets; Schmitt et al. 2016).

As we take a special focus on sustainability, we refer to sustainable food systems using the consensus definition of the High Panel of Experts on Food Security and Nutrition (HLPE 2014, p. 31): ‘Sustainable food system (SFS) is a food system that ensures food security and nutrition for all in such a way that the economic, social, and environmental bases to generate food security and nutrition of future generations are not compromised’. In this study, our focus is on the sustainability of the food system at a landscape of production level. We thus divide the landscape sustainability outcomes of food systems into:

ecological outcomes which consider how farming practices contribute to aspects related to biodiversity, water, and soil preservation in the landscapes of production;   
cultural outcomes which include the role of the landscape products in the local culture (e.g., by maintaining traditional ways of farming, the local ecological knowledge, and links to traditional festivals and community events), the local identity associated with landscape products, and local recipes;   
• social outcomes which take into account the age and gender balance among producers and aspects

connected to the organisation and relationships along the value chain: farmer empowerment (whether farmers are involved in the determination of the operational rules), equity in the distribution of the profits obtained from the landscape product, and farmers’ collective action; and

economic outcomes which look at the importance of landscape products and associated activities (cultivation, processing, and retailing/distribution) for local employment and farmers’ incomes, at landscape product prices with respect to mass market equivalents, and at the role of landscape products for the tourist sector.

# Survey design

To study these linkages between food and landscapes, we performed an online survey that targeted food and landscape experts from different disciplines and multiple Mediterranean countries. Experts were asked to select a landscape product they know well and its landscape of production and provide information on all the components presented in Fig. 1. We left it to the understanding of the respondents as to how they delimited a production landscape. However, in order to ensure that all respondents had a similar understanding of the objects of the survey, we provided an extended introduction at the beginning of the survey that included examples of products and landscapes from different areas in the Mediterranean. The survey was created using the online platform ‘Limesurvey’ (https://www.limesurvey.org/) and was structured into the following main sections: i) identification of the product and the landscape of production; ii) characterisation of the food system; and iii) sustainability outcomes in the landscapes of production divided into ecological, cultural, social, and economic outcomes (see Supplementary Materials 1 for the full survey). We also asked respondents about their visions and the conflicts they identify around their chosen landscape product.

To select the respondents, we compiled a list of researchers through internet keyword searches (a combination of sustainability and food systems concepts) looking at existing literature and the agriculture- and landscape-related departments of universities across the Mediterranean region. We targeted the largest research institutes and departments

in every Mediterranean country and selected the profiles of the most relevant respondents based on their lines of work and publication records. In addition, we followed a snowball sampling approach in which respondents were asked to suggest other contacts. Experts were defined as those survey recipients who had developed a role as a scientist or practitioner in the topics of food systems or landscape sustainability for a specific product or landscape in the Mediterranean.

We sent an email to all of the experts with a nonpersonalised link to the survey, which was also distributed by social media. The survey could only be started after the participant had read and accepted a note of consent which explained how their answers were going to be used and stored. The responses to the survey were anonymous. The survey campaign took place from May to July 2019, and two reminders were sent out during that time. Completion of the survey by the respondents took between $3 0 ~ \mathrm { { m i n } }$ and one hour. A total of 286 experts were invited to take the survey, 73 provided answers and after deleting incomplete responses, 54 cases (representing each a landscape product and a landscape of production) were kept for the analysis (response rate of $1 9 \%$ ). Most of the respondents $( 8 0 \% )$ reported high or medium expertise on the topic. Eighty percent of the respondents were scientists and the rest producers and workers in a nongovernmental organizations or local government.

# Data analysis

We used frequency analyses to describe the landscapes of production and the characteristics shared by the landscape products as related to their food systems and the landscape sustainability outcomes in the landscapes of origin. We performed Multiple Correspondence Analysis (MCA), followed by a cluster analysis, to identify patterns in the data set related to the connections between food system characteristics and landscape sustainability outcomes. The MCA was carried out with the food system variables in order to assess associations and patterns across food system characteristics. Using those factors explaining $65 \%$ o f the inertia a cluster analysis was then conducted to identify consistent groups of landscape products based on shared food system characteristics (Table A1 and Fig. A1 in Supplementary Materials 2). Lastly, we explored the different landscape sustainability

outcomes connected to each cluster using the mean value of each outcome on a Likert scale ranging from 1 (strongly disagree) to 5 (strongly agree).

# Results

Characterisation of the landscape products and food system types

The spatial distribution of the landscape products collected across the Mediterranean showed a high number of cases in the western countries $5 9 \%$ of the total—Spain, Portugal, Morocco, France), followed by the central Mediterranean countries $30 \%$ —Italy, Slovenia, Croatia, Albania, Greece, Tunisia) and eastern Mediterranean countries $1 1 \%$ —Egypt, Turkey, Lebanon, Jordan; Fig. 2). The most common type of landscape products selected by the experts were tree crops $52 \%$ of the total sample—wine, olive oil, almonds, cherries, apples, chestnuts, carob fruit, cork). Animal products were also highly represented $( 2 4 \%$ , with all but one of the meat products coming from Spain). Cereals made up $13 \%$ of the total sample, including wheat and rice. There were also some vegetables $( 7 \% )$ , comprising, for example, green beans, asparagus, and tomatoes, all of them coming from Spain.

The landscapes of production identified by the experts were very heterogeneous in terms of size and socio-demographic and biophysical characteristics (from mountain areas to hilly landscapes, steep valleys, or coastal plains; from arid steps to lush valleys; and from sparsely populated and remote areas to intensively used coastal areas). Within this diversity, common landscape development trends mentioned were: expansion of tourism, increased preservation of the cultural and natural heritage, and agricultural abandonment or intensification (additional information about the characteristics of the landscapes of production is given in the Supplementary Materials 2, Table A2).

# Landscape product qualities

Most of the landscape products identified were defined by the experts as gourmet products $( 7 0 \% )$ associated with a distinct landscape and to tradition narratives $( 6 2 \%$ ; Fig. 3a). In half of the cases $(46 \% )$ , the products were exclusively grown in the area of the

![](images/4413c2474cebca8239deafe213e2e67c14ce04917112a092050ff331723c90dc.jpg)  
Fig. 2 Map with the geographical distribution of the landscape products by type. The graph at the bottom shows the percentage of each product type

landscape of production mentioned in the survey (Fig. 3b). Half of the products $( 5 0 \% )$ were under labelling or certification mechanisms; of these products (Fig. 3b), $70 \%$ of the cases had Geographical Indication labels, while only a few $( 2 6 \% )$ had organic agriculture labels. The products that were most often under certification mechanisms were wine $7 5 \%$ of wine products were under certification), vegetables $( 7 5 \% )$ , olive oil $( 7 1 \% )$ , and cheese $(67 \% )$ , while cereals and fruit trees were not often certified (only $2 9 \%$ and $33 \%$ of these products, respectively).

# Farming practices in the landscapes of production

Most of the products identified by the experts were grown using low intensity practices $78 \%$ ; based on manual labour, low input of agrochemicals and machinery, etc.) with very few using high intensity practices $1 3 \%$ ; high input of agrochemicals and machinery, etc.; Fig. 3c). The most common land cover associated with the products was mosaic lands $( 5 9 \%$ ; small cultivated land parcels with different cultivation types; Fig. 3d. Lands were mostly owned by multiple smallholders $60 \%$ ; Fig. 3e). Only in $30 \%$ of the cases were farmers organised into cooperatives.

# Value chain characteristics

The value chains of the products were very heterogeneous. In how the authenticity of the product was communicated to the consumer (Fig. 3f), experts most often mentioned reputation effects (about $60 \%$ of the products). Remarkably, in only $16 \%$ of the cases did the experts respond that there was no communication of the authenticity of the product to the consumer. Responses on the distribution channels in which the product reached the consumer were varied (Fig. 3g). The most frequent channel was that farmers or farmers’ cooperatives sell the product to retailers and distributors $80 \%$ of the cases), but it was also very often the case that farmers and cooperatives sold directly to consumers $6 9 \%$ of the cases). The processing and packaging of the product was also carried out in different ways (Fig. 3h). In most of the cases $( 6 8 \% )$ , processing and packaging happened within the landscape of production (the farmers in $46 \%$ of the cases and farmers’ cooperatives in $33 \%$ of the cases). As for the geographic distance to the market (Fig. 3i), in $50 \%$ of the cases they were sold in the local/regional market and in $39 \%$ at the national/ international market.

![](images/e3af934021c14bf6f7a30dcbce670396479f4d3d2c7a1224b855f6a01de88070.jpg)  
(a) Narratives associated to the landscape product   
(c) Farming practices

![](images/16a7e51578e775ed7d160f271319e2f2c6c5214c2ec2bc6df57c0226ef74aaca.jpg)

![](images/e5d2fe5d7d05887ae2f4936e74abada1134e07568df02843774113cbcec40f8d.jpg)  
(e) Land ownership and producers size   
(f) Communication channels of the product's authenticity

![](images/67a700df5840a57c4befe8fd04ed3435bef66b604aac1ce22722fe830df0b308.jpg)

![](images/40e369f54fc00a282a3c5cc4903e64e0f5186cc6955ee42223b574cbcf36df18.jpg)  
(h) Processing and packaging   
Fig. 3 Main food system characteristics of the landscape products: The horizontal axis represents the percentage of landscape products $( { \mathfrak { n } } = 5 4 )$ ). Graphs a and b in blue relate to

Landscape sustainability outcomes in the landscapes of production

The farming practices associated to the landscape products were generally regarded by the experts to lead to positive ecological outcomes in the preservation of biodiversity $(82 \% )$ and water resources, not causing water overuse ( $65 \%$ ; Fig. 4). There was also general agreement on the positive contributions of landscape products to the preservation of local culture $( 9 1 \% )$ , local recipes $( 9 0 \% )$ , and identity $(89 \% )$ .

![](images/e974fed604eed5ea45c99085d99303f2047369426da70568c6dcdef0348625cc.jpg)  
(b) Products' origin and certification qualities   
(d) Land cover types

![](images/20035e5f7c9c09dfb380f312dcf37ae1f59c8055f2e8064ecc11abff67c4eb97.jpg)

![](images/d9ee74d3e4cfbf6a3789bb3243789edac3aa61efb9b528a1ff54b199bb5e0c31.jpg)  
(g) Distribution channels   
(i) Geographic distance to consumers

![](images/f6a96581c2d0eb6ebe26cdd0f75512078114074b6e3a7d4e5ce42e3eecb87cc0.jpg)  
product qualities; graphs c to e in green to the farming practices; and f to i in orange to value chain characteristics

The social outcomes were more heterogeneous. The percentage of experts who considered that there is gender or age balance among the food product farmers was low $23 \%$ and $34 \%$ of the respondents, respectively), as was the percentage of the experts who considered that there is a fair profit distribution along the value chain $( 2 7 \% )$ . Outcomes connected to collective action and participation of the farmers in the operational rules were considered positive by about half of the experts $46 \%$ and $53 \%$ , respectively). We also found a variety of responses regarding the

economic outcomes. The highest percentages of agreement were connected to the landscape product being sold at higher prices than generic/mass market equivalents $( 7 1 \% )$ and being the main source of income for most farmers that cultivate it $( 7 0 \% )$ ; and the lowest with the producers being better off than other farmers $( 3 6 \% )$ .

Connections between food system types and landscape sustainability outcomes

Types of landscape products based on the food system characteristics

The results of the MCA and the cluster analysis revealed three clusters of products based on the food system characteristics defined by the experts (see Supplementary Matterials 2: Table A3 for the cluster characterisations; Table A1 and Fig. A1 for the results of the MCA and the dendrogram of the cluster

analysis). The first cluster, named local type with personal interaction (19 products, $3 5 \%$ of the total sample), included products that were sold both directly to consumers $( 7 4 \% )$ and to local shops and restaurants $( 7 4 \% )$ , predominately in the local and regional market $(7 9 \% )$ , and whose authenticity was communicated to the consumers through personal interaction and networks of trust $( 8 4 \% )$ and reputation effects $( 8 4 \% )$ . The packaging and processing of the product was done in the landscape of production by farmers and farmers’ cooperatives $( 6 3 \% )$ . Characteristics of this cluster were also low intensity farming practices $( 9 5 \% )$ and multiple small producers $(7 9 \% )$ . Products often included in this cluster were olive oil, nuts, and cheese.

Cluster 2, named mixed type without communication (15 products, $28 \%$ of the total sample), covered those products whose authenticity was frequently not communicated to the consumer $( 6 0 \% )$ . Landscape products within this cluster reached the consumers predominately through distributors and retailers $(73 \% )$

![](images/2257006124d0710afb8b0e74107933ca31205b71126fc07baa6f9c83ab70f9f4.jpg)  
Fig. 4 Percentage of respondents that considers that the landscape product contributes to the different landscape sustainability outcomes in the landscapes of production

but also directly from the farmers $( 6 7 \% )$ . The packaging and processing was done by both farmers and farmers’ cooperatives $(67 \% )$ and by external companies outside of the landscape of production $(40 \% )$ .

Cluster 3, named international type with certification mechanisms (20 products, $37 \%$ of the total sample), represented those products that farmers and farmers’ cooperatives sold to retailers and distributors $9 5 \%$ of the products in this cluster), and most of the produce was sold in national and international markets $(8 5 \% )$ . Products were under certification mechanisms $( 7 5 \% )$ and the percentage of products that were exclusively grown in the area was the highest $( 6 5 \% )$ . Processing and packaging was mainly done by farmers or farmers’ cooperatives $( 7 5 \% )$ . As for the farming practices, there was a mix of small and big producers $( 6 5 \% )$ , and farmers were organised in cooperatives $( 7 5 \% )$ . The percentage of products that were grown using low intensity practices was the lowest in this cluster $( 6 5 \% )$ . A typical product in this cluster was wine.

We did not observe a clear differentiation between the sustainability outcomes linked to the different food system clusters (Table 1). However, products from the local type performed better in terms of ecological and cultural outcomes, with mean values of 4.7 for preservation of the local culture and 4.4 for preservation of biodiversity, with 5 as the highest value. Products from the international type performed better in regard to the economic outcomes, with mean values of 4.3 for higher prices than mass market equivalents and 4.1 for being the main source of income for producers. The lowest levels of performance were found for the social outcomes in the mixed cluster type, with mean values of 2.4 for farmers’ participation in the operational rules of the value chain and 2.4 for a fair profit distribution among the actors of the value chain.

# Discussion

This study represents a first approximation to combine food systems and landscape ecology approaches to understand how the qualities, farming practices, and value chains of Mediterranean landscape products allow or hinder sustainability in the landscapes of production. Based on expert perceptions, our analysis allowed us to identify the main characteristics shared

by particular landscape products, the differences to be found in their food systems, and the landscape sustainability outcomes they provide. This methodology has previously been shown to be robust and has been used in sustainability science (Hanspach et al. 2017), but we acknowledge that the different levels of expertise among the respondents and their different relations to the products may limit the validity of the survey. This issue was addressed by including an ‘I do not know’ option among the answers and excluding partial surveys from the analysis. Additionally, there was an overrepresentation of respondents from the west Mediterranean, so that results may not be fully representative of the whole Mediterranean.

Characteristics of the landscape products

Landscape products share many characteristics with gourmet products (e.g., products sold at prices higher than their mass-market equivalents), and they are also associated with healthy, organic production, and sustainable development narratives. Although these qualities are important, their main trait is the connection to a distinct landscape. The farming practices associated to the landscape products (i.e. low production intensity, involvement of traditional knowledge and techniques, cultivation by multiple small producers, and creation of mosaic landscapes) contribute to maintain the distinctive character of the landscapes of origin—that is, ‘what makes one area ‘‘different’’ or ‘‘distinct’’ from another’ (Swanwick 2002). In this sense, our landscape products framework aligns with the different initiatives and concepts that have emerged globally around characteristic agricultural landscapes, such as the Globally Important Agricultural Heritage Systems (GIAHS) supported by the Food and Agriculture Organization of the United Nations (FAO), the Socio-Ecological Production Landscapes and Seascapes (SEPLS) promoted under the Satoyama Initiative, or the High Nature Value farmlands (HNV) in Europe.

The communication of landscape product qualities to consumers seems to be of great relevance. Marsden et al. (2000) brought up the concept of ‘re-spatializing food’ by embedding the product with information about the landscape of production as it reaches the consumer as opposed to ‘placeless food’ (Schmitt et al. 2017). This re-spatialization of food through information connects consumers with the place of production

Table 1 Mean of the values of how the landscape product contributes to the different landscape sustainability outcomes in each of the three clusters   

<table><tr><td>Outcome categories</td><td>Variables</td><td colspan="2">Cluster 1
Local with personal 
interaction 
(n=19)</td><td colspan="2">Cluster 2
Mixed, no 
communication 
(n=15)</td><td colspan="2">Cluster 3
International with 
certification 
(n=20)</td></tr><tr><td></td><td></td><td>Mean</td><td>SD</td><td>Mean</td><td>SD</td><td>Mean</td><td>SD</td></tr><tr><td rowspan="3">Ecological outcomes</td><td>Preserves biodiversity</td><td>4.368</td><td>0.597</td><td>4.267</td><td>0.961</td><td>3.941</td><td>1.298</td></tr><tr><td>Preserves water resources</td><td>4.176</td><td>0.943</td><td>3.929</td><td>1.406</td><td>2.824</td><td>1.372</td></tr><tr><td>Maintains soils</td><td>3.529</td><td>0.728</td><td>3.143</td><td>1.072</td><td>3.000</td><td>1.286</td></tr><tr><td rowspan="3">Cultural outcomes</td><td>Preserves the local culture</td><td>4.789</td><td>0.419</td><td>4.533</td><td>0.640</td><td>4.250</td><td>1.070</td></tr><tr><td>Is a key ingredient in local recipes</td><td>4.667</td><td>0.686</td><td>4.467</td><td>0.640</td><td>4.350</td><td>0.988</td></tr><tr><td>People in the area identify themselves with it</td><td>4.579</td><td>0.607</td><td>4.400</td><td>0.737</td><td>4.450</td><td>0.759</td></tr><tr><td rowspan="5">Social outcomes</td><td>There is gender balance among producers</td><td>2.947</td><td>0.705</td><td>2.800</td><td>1.014</td><td>2.579</td><td>1.017</td></tr><tr><td>There is age balance among producers</td><td>2.947</td><td>1.079</td><td>2.867</td><td>0.915</td><td>3.412</td><td>1.004</td></tr><tr><td>Value chain organisation contributes to collective action</td><td>3.263</td><td>0.872</td><td>2.786</td><td>1.188</td><td>3.588</td><td>0.795</td></tr><tr><td>Farmers participate in operational rules</td><td>3.353</td><td>0.996</td><td>2.429</td><td>1.089</td><td>3.778</td><td>1.003</td></tr><tr><td>There is a fair profit distribution along the value chain</td><td>3.059</td><td>1.029</td><td>2.429</td><td>1.284</td><td>2.938</td><td>1.063</td></tr><tr><td rowspan="5">Economic outcomes</td><td>Producers are better off than other farmers</td><td>3.118</td><td>1.054</td><td>2.933</td><td>0.704</td><td>3.722</td><td>0.895</td></tr><tr><td>Attracts tourists</td><td>3.611</td><td>1.037</td><td>3.467</td><td>1.060</td><td>3.850</td><td>1.226</td></tr><tr><td>Employs an important proportion of local population</td><td>3.167</td><td>1.098</td><td>3.600</td><td>0.986</td><td>3.842</td><td>0.958</td></tr><tr><td>Is the main source of income of the farmers</td><td>3.278</td><td>1.074</td><td>3.667</td><td>0.724</td><td>4.150</td><td>0.745</td></tr><tr><td>Is sold at higher prices than mass market equivalents</td><td>3.833</td><td>0.924</td><td>3.600</td><td>0.986</td><td>4.316</td><td>0.885</td></tr></table>

Mean values (as translated from the answers to the survey in a Likert scale format from strongly disagree to strongly agree) range from 1 (strongly disagree, dark red) to 5 (strongly agree, dark green), where 5 means strong contribution and 1 means no contribution

and allows them to make conscious and informed decisions about purchasing a product (Renting et al. 2003). The regional identity of a product was frequently emphasised in our survey, either through formal Geographic Indications (GI) or informal communication between producers and consumers. Strategies to re-spatialize products seem crucial in times of globalisation and increasing distance between consumers and landscapes of production. Thus, reconnecting people with landscapes is a critical leverage point for a transition towards sustainability as such reconnection can foster a feeling of stewardship towards landscapes (Abson et al. 2016; Garcı´a-Martı´n et al. 2018).

Our survey identified heterogeneous value chains as another important characteristic of landscape

products. This heterogeneity seems to be inherent in alternative food systems due to the increasing complexity and diversity in commercialisation options, organisation of the value chains, and relationships between producers and consumers (Marsden et al. 2000; Schmitt et al. 2016). The geographic distance to the consumers of the products in terms of local/ regional or national/international outreach is also varied. We identified three types of food systems based on their more local or international reach, the length of their value chain, and the way the authenticity of the product is communicated to the consumers: local landscape products with short value chains and authenticity communicated through personal interaction; international landscape products with long value chains and authenticity communicated

through certification mechanisms; and mixed products for which there is no communication of their qualities to consumers. This ‘local–global hybridity’ (cases in which the local attributes and values of the product are promoted but the product is sold in international markets Schmitt et al. 2017) contests binary assumptions about conventional and global versus alternative and local food systems (Watt et al. 2005; Beriss 2019). Accordingly, some argue for supply chains’ in which producers and their supply chain partners ally to ‘distribute significant volumes of high-quality, differentiated food products while maintaining transparent relationships and fair distribution of revenues’ (Ostrom et al. 2017, p. 7). This raises questions of embeddedness, i.e. about how the different actors are connected among each other and with the landscapes of production (Hinrichs 2003; Renting et al. 2003). In the case of landscape products, embeddedness goes beyond the social dimension of producer–consumer relations and also incorporates notions of territoriality (sensu Sonnino 2007, p. 63: ‘the ecological and cultural relationships that a food system has with its territorial context’). Our findings might call for an expansion of the concept toward telecoupled landscape embeddedness that connects the different actors along and beyond the value chain through the shared valorisation of a distinct landscape embodied in the landscape product.

The local–global hybridity also concerns the scale of production (Kizos 2013; Chilla et al. 2020). Landscape products are typically small-scale products for which entry into international niche markets might require ‘scaling up’ of production, which may lead to unintended ecological, socio-economic, and cultural landscape sustainability outcomes. This also raises the question of ‘what constitutes local’ (Beriss 2019, p. 67) and how the locality of the product is conveyed at different scales. In line with our results, some authors have distinguished between local products and localised products. Local products are commercialised through short value chains and convey locality values (e.g., care, community, and stewardship between producers and local consumers; cluster 1 in our sample); while localised products are anchored within particular territories through ‘socially constructed, culturally marketed, and institutionally regulated’ structures that convey values of locality to distant consumers (e.g., GIs and Slow Food; cluster 3) (Bowen and Mutersbaugh 2014, p. 204).

We conclude that the local–global hybridity, with an emphasis on landscape embeddedness, is one important characteristic of landscape products. Acknowledging the distinction between more local and more international landscape products is important as different products and landscapes require different strategies.

Links between landscape sustainability outcomes and food system characteristics

Landscape products frequently promote ecological and cultural outcomes, which tend to happen in parallel. This is mainly the case when low intensity farming practices are used (common among the products in the local cluster). In this sense, landscape products foster biocultural diversity, ‘sustaining the biophysical and socio-cultural components of dynamic, interacting, and interdependent social–ecological systems’’ (Gavin et al. 2015, p. 140). The realisation of this interdependence of cultural and biological diversity is especially relevant in the current context of biodiversity loss and landscapes homogenisation (Hanspach et al. 2020). Therefore, the concept of landscape products appears useful to explore linkages between the cultural practices of food production and the ecological characteristics in the landscapes of production (Hedberg 2015; Plieninger et al. 2017).

Landscape products seem to be well integrated in the socio-economic context of the landscapes of production, employing an important proportion of the local population and acting as the main source of income of the local producers. However, our survey indicated that there is rarely a fair profit distribution and farmers often do not participate in the operational rules. Even when there was general agreement among respondents that higher prices are paid for landscape products than for mass market equivalents, the perception was still that this did not necessarily reflect in farmers- incomes. This might be explained by aspects such as the lack of empowerment of small producers and the fact that prices still are too low to cover the producers’ costs (Polain de Waroux and Lambin 2013).

Our survey demonstrated that products sold under certification mechanisms to national and international markets perform better in terms of economic outcomes, with prices that probably better reflect their

costs of production (Schmitt et al. 2016). However, labelling was only in place for half of the landscape products assessed and even then, experts did not expect that the higher prices paid by consumers would have a strong positive impact in contributing to a fair price paid to primary producers. As claimed by some authors, speciality or niche market products do not necessarily stimulate endogenous economic development (Watts et al. 2005; Kizos 2013). By relying on international value chains for economic viability, local producers are subordinated to the interests of the most powerful actors along the chain that profit from the added value that, for instance, a certification confers.

In our sample, this lack of empowerment is especially negative when external companies take over the processing, packaging, and distribution of the final product and when the qualities of the product are not communicated to the consumers, thereby making the primary producers invisible. Some scientists and practitioners are calling for the participation of farmers in partnerships—collaborative arrangements between various actors—as a way to improve their economic situation by allowing smallholders to participate in more remunerative value chains (Helmsing and Vellema 2011; Schmitt et al. 2016; Kizos et al. 2017). In fact, collective action among landscape product farmers seems to have a positive effect in the fair profit distribution along the value chain. However, this requires certain levels of trust and social capital that are often lacking (Kizos et al. 2014), and in our survey, cooperatives and collective action were not very common among landscape product actors. Ros-Tonen et al. (2015, p. 531) stated that farmers’ agency resides in their capacity to ‘negotiate, interact, position themselves and make claims vis- $\cdot \mathbf { \hat { a } }$ -vis companies, investors, NGOs and donors’. Therefore, there is a need to understand and improve the socio-economic situation of the producers by paying attention not only to their vertical integration in the value chain but also to their horizontal collaboration with non-chain actors at a landscape level (Ros-Tonen et al. 2015).

Finally, we found that the typical social problems of the agricultural sector in the rural Mediterranean prevail in our sample of landscape products among the producers, such as a lack of gender and age balance. The masculinisation of rural areas caused by the differences in migration behaviour between men and women is a widespread phenomenon (Camarero and Sampedro 2016). Gender equality is an essential

component of sustainable economic growth and poverty reduction (FAO et al. 2010) and thereby is a keystone in order to promote the sustainable management of traditional agricultural landscapes.

Towards the future: How to enhance landscape products and their sustainability outcomes?

Experts were asked to share their visions about the future of landscape products. In most of the cases, they mentioned serious threats to the persistence of the products and the associated landscapes due to, on the one hand, the dynamics of abandonment and lack of age balance and, on the other hand, the expansion of intensive monoculture lands and the pressures of urbanisation and tourism; common trends in the Mediterranean agricultural world (Agnoletti 2014; Wolpert et al. 2020). Under these circumstances, food systems that are well embedded in a distinct landscape of origin can contribute to landscape preservation and rural development (Schmitt et al. 2016). According to Sims (2009, p. 322), local products foster sustainable agricultural practices, local businesses, and ‘build a ‘‘brand’’ that can benefit the region by attracting more visitors and investment’ and distinguish it from other destinations. In the case of our landscapes, two aspects need to be considered to support that claim.

One aspect is that this particularly happens in association with the development of tourism (Nemes et al. 2019). Our results showed that tourism is attracted by those landscapes whose products help preserve the biocultural diversity and that in those cases, landscape product farmers are better off than the other local farmers, revealing interesting synergies between the benefits of the landscape product and the tourism sector. However, among our landscapes, we also observed how the expansion of tourism predominately happens in areas where land abandonment is a dominant trend. Therefore, the question remains of whether these benefits can compare to those in rural nonfarm activities and in cities (le Polain de Waroux and Lambin 2013). This also poses threats to landscape sustainability, such as an uneven distribution of tourism-generated wealth within the local community, the appropriation of distinctive traditions by some actor groups (Bowen and De Master 2011), an overdependence on tourism (Nemes et al. 2019), and a ‘Disneyfication’ of landscapes (Bowen and De Master 2011). To navigate these challenges, the

social–organisational context needs to be taken into account, ‘ensuring the representation of all actors, privileging local actors in the construction and governance of protective arrangements, considering local needs and priorities’ (Bowen and De Master 2011, p. 81).

A second aspect to be considered is the importance of the benefits and recognition that producers obtain as guarantors of the distinct landscape character. ‘Valuebased food chains’ that build on shared social, cultural, economic, environmental, or quality related product values among the actors along the supply chain and the fair distribution of the benefits are gaining attention (Ostrom et al. 2017). The shared appreciation of landscape products and distinct landscapes could act as a boundary object that carries the values of community and stewardship for their preservation and builds ties between the different actors: among the producers, between the producers and the rest of the local actors, and between the landscapes and the consumers (distant or not). In that regard, labelling mechanisms that allow consumers to be aware of the qualities of the products, even when they are far away from the production landscapes, are of great value. Our respondents reported how labelling contributed to better prices and market access. An open question is however, whether there are existing mechanisms that could capture the qualities of landscape products and the value of the landscape of origin as a whole to emphasise the landscape embeddedness of the product (Mann and Plieninger 2017; Flinzberger et al. 2020) and include products that are not often under certification such as cereals and fruit trees (as opposed to cheese, olive oil, and wine). GI labelling schemes often focus on processed (high value-added) foods and neglect low value-added food products (Watts et al. 2005). Therefore, what we propose here is to revisit the idea of landscape labelling proposed by Mann and Plieninger (2017), which considers the differentiation of the entire landscape rather than of the particular product, allowing other local products to be considered under the label. On the one hand, this idea captures the essence and benefits of the GI—that is, embedding the products in their socio-cultural and ecological local contexts, highlighting their added value to consumers and differentiating them from the competition, and promoting the collaboration among producers to define quality standards (Quin˜ones-Ruiz et al. 2015; Kizos et al. 2017). On the other hand, it has

at its core the integrated management of the landscape in which multiple actors and sectors (beyond the value chain) collaborate in a transparent and proactive way to preserve the landscape character and multiple landscape functions and services. Landscape products can offer ‘all-round social, economic and environmental benefits for hosts and guests’ (Sims 2009, p. 333) and they might be supported by initiatives such as GIAHS, SEPLS and HNV farming.

# Linking food systems and landscape ecology

The need to combine different approaches to address food sustainability issues is more and more acknowledged (Hinrichs 2010; Ros-Tonen et al. 2015; Schmitt et al. 2016). Both food systems and landscape ecology research provide an integrative and systemic approach to address complex sustainability challenges that result from the interaction between ecology and society across scales. But there are fundamental differences in their focus and approaches, with potential for complementarity. Food systems research typically looks at the interactions along the value chain and less at the interactions with non-chain actors or the social–ecological conditions in the areas of production (Helmsing and Vellema 2011). On the contrary, landscape ecology originally was dedicated to the relationships between spatial pattern and ecological processes at multiple nested scales within a landscape. While food systems research is usually focused on specific food products, landscape ecology rarely pays attention to the resulting products from the agricultural landscapes it studies. Both fields acknowledge the importance of considering institutional and governance issues as well as socio-cultural aspects in the study of sustainability challenges around food and agricultural production (including knowledge systems, heritage, perceptions and values, and management practices). Landscape ecology does so with a strong emphasis on the inclusion of all the different actor groups in the places of production, while food system research puts the actors directly connected with the food product at center.

In the framework presented here, we take the food system as the encompassing structure that articulates the connections between all of the elements and processes across the telecoupled systems, linking production landscapes with distant consumers. The landscape ecology lens expands the analysis beyond

the specific product to capture how it is embedded in the landscape of production from an ecological, economic, social, and cultural perspective. Although not captured in this paper, the study of the ecological outcomes of production practices is a crucial contribution of landscape ecology to food systems research, providing the tools for analysing the patterns and processes manifested at multiple scales. At the same time, food system approaches can contribute to the upscaling of local landscape initiatives by reaching out to global actors, for instance through labelling mechanisms and alternative distribution channels.

We conclude that the combination of landscape ecology and food system research opens new ways to address the challenges that the integrative analysis of food systems poses for sustainability science. Both fields share an interdisciplinary and system-oriented view that acknowledges the complexity of coupled human–environment systems but have a different focus. Food systems provide a well-defined framework to study the interactions along the value chain of landscape products, connecting places of production with places of consumption. Landscape ecology allows for understanding the embeddedness of the product and its sustainability outcomes in the landscapes of production from a holistic perspective by looking beyond the product, as well as to analyse the associated ecological processes and structures across nested scales.

Acknowledgements The authors acknowledge the financial support provided by the German Research Foundation, DFG, through grant number 426675955. We thank Christian Bunn, Lukas Flinzberger, and Franziska Wolpert for their contribution to the survey design. We especially thank all respondents to the survey. We are also very grateful to the editor and the two anonymous reviewers for their constructive feedback that considerably improved the relevance of this manuscript. Prof. Dr. Johannes Kahl passed away on 12 November 2020. He contributed a thorough food systems perspective to this study. We remember him as an outstanding colleague and scholar in the field of organic food quality and food culture.

Funding Open Access funding enabled and organized by Projekt DEAL. German Research Foundation, DFG, through grant number 426675955.

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if changes were made.

The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http://creativecommons.org/licenses/by/4.0/.

