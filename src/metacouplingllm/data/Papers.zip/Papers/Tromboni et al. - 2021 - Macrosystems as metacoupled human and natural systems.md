# Macrosystems as metacoupled human and natural systems

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:09:05.034372+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Tromboni et al. - 2021 - Macrosystems as metacoupled human and natural systems.pdf
- Year: unknown
- DOI: 10.1002/fee.2289
- OA status: hybrid
- License: other-oa
- Category: Journal Articles\Conceptual\Metacoupling
- Closed-access reason: non-permissive license (other-oa)

## Copyright-Safe Summary
This conceptual paper positions macrosystems as inherently integrated human-natural systems and argues that nearly all ecological processes at broad scales are now shaped by people, often over long distances. It focuses on global to continental scales rather than a specific geographic case, drawing examples from diverse regions (eg Amazon deforestation, US river networks, global trade, polar pollution, international species introductions).

The authors propose the metacoupling framework as a unifying system context for macrosystems biology. Metacoupling distinguishes interactions within a system (intracoupling), between neighboring systems (pericoupling), and between far-separated systems (telecoupling). It integrates ecological and socioeconomic processes, emphasizing flows of organisms, materials, energy, and information, along with cross-scale feedbacks.

Using literature-based examples and modeling results, the paper shows that human actions expand and intensify linkages across scales. Land-use change such as deforestation alters land-atmosphere exchanges and can reshape precipitation and productivity in distant regions. Transport of pollutants, nutrients, and wildfire aerosols similarly connects remote terrestrial, aquatic, and marine systems. River networks illustrate directional telecoupling, where headwater conditions have stronger influence on downstream water quality than adjacent midstream conditions. Global trade, travel, and species introductions demonstrate that distant social-ecological connections can be stronger than local ones, challenging assumptions that spatial proximity predicts interaction strength.

The paper further highlights ecological-socioeconomic feedbacks in metacoupled systems. Examples include how ecoclimatic teleconnections affect agriculture and forest management, how migratory species link distant habitats, and how international trade, tourism, and conservation financing (eg charismatic species loans) create feedbacks between distant economies and ecosystems.

This work is explicitly about metacoupling and telecoupling. It extends earlier teleconnection and macrosystems concepts by providing a systematic, interdisciplinary scheme for analyzing agents, flows, causes, effects, and feedbacks across local-adjacent-distant interactions. The authors outline research needs for quantifying metacouplings and feedbacks, combining models with observations, and using this framework to support cross-scale environmental governance and sustainability.

## Structured Metacoupling Extraction

### Coupling Classification
- Conceptual paper on metacoupling; elaborates intra, peri, and telecoupling in macrosystems biology.

### Intracoupling
#### Systems
- Focal human natural macrosystem managed within one country or region
- Local watersheds and headwater streams within a river network
- Forested landscapes undergoing deforestation or land cover change
#### Flows
- Local harvesting, farming, hunting, and resource extraction activities
- Carbon, water, and energy exchanges between vegetation and atmosphere
- Nutrient cycling and processing within individual stream reaches
#### Agents
- Local land managers, farmers, loggers, and communities
- National agencies regulating land use and water quality
- Plants, animals, and microorganisms mediating local ecosystem processes
#### Causes
- Local land use change, urbanization, and resource demand
- Fire use for clearing forests and agricultural expansion
- Headwater riparian management and in stream nutrient loading
#### Effects
- Altered local climate, biodiversity, and ecosystem services
- Changes in local water quality and stream nutrient saturation
- Shifts in forest structure, resilience, and tipping point proximity

### Pericoupling
#### Systems
- Adjacent terrestrial and marine ecosystems linked by wildfire plumes
- Upstream and downstream river segments within the same watershed
- Neighboring countries trading natural resources or agricultural products
#### Flows
- Sediment and nutrient delivery from rivers to coastal seas
- Wildfire derived aerosols and iron fertilizing nearby oceans
- Cross border trade, tourism, and short distance migration
#### Agents
- Regional governments coordinating watershed and coastal policies
- Fishers, farmers, and industries along shared river basins
- Travelers, tourists, and regional traders moving goods and people
#### Causes
- Floods, land clearing, and intensive agriculture in upstream areas
- Wildfires driven by climate variability and land management
- Regional economic integration and shared infrastructure
#### Effects
- Coastal eutrophication, red tides, and coral mortality
- Downstream water quality changes far from discharge sources
- Regional biodiversity shifts and resource exploitation patterns

### Telecoupling
#### Systems
- Distant countries connected by soybean, timber, or resource trade
- Remote regions linked by ecoclimatic teleconnections from deforestation
- Source and destination countries for invasive species or pandemics
#### Flows
- Global commodity trade, foreign investment, and payments for services
- Atmospheric transport of pollutants, aerosols, and mercury
- Long distance organism dispersal, invasions, and disease spread
#### Agents
- Multinational corporations, international traders, and investors
- International organizations and cross national policymakers
- Migrants, tourists, cargo shippers, and wildlife traders
#### Causes
- Globalization, market demand, and trade liberalization
- High emission climate scenarios amplifying land atmosphere coupling
- Human mobility transporting species and pathogens worldwide
#### Effects
- Land conversion in exporting regions driven by distant consumers
- Remote rainfall and productivity changes from regional deforestation
- Biotic homogenization, invasive spread, and rapid pandemic emergence

### Cross-Coupling Interactions
- Deforestation alters local climate, drives regional pericoupling, and triggers distant ecoclimatic telecouplings
- Headwater management produces directional telecoupling influencing far downstream waters despite weak local adjacency
- Telecoupled trade and tourism create feedbacks that reshape intracoupling governance and local livelihoods

### Research Gaps or Limitations
- Limited empirical studies jointly quantifying intra, peri, and telecouplings in macrosystems
- Feedbacks across distant telecouplings remain poorly detected, modeled, and compared
- Need integrative, quantitative analyses of agents, flows, causes, effects across metacoupled systems

### Search Keywords
- metacoupling macrosystems biology telecoupling pericoupling intracoupling
- ecoclimatic teleconnections deforestation land atmosphere coupling pollutants
- global trade invasive species directional telecoupling feedbacks

### Extraction Confidence
high
