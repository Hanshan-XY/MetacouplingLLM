# Synergies and tradeoffs among Sustainable Development Goals across boundaries in a metacoupled world

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:20:22.767067+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Zhao et al. - 2021 - Synergies and tradeoffs among Sustainable Development Goals across boundaries in a metacoupled world.pdf
- Year: unknown
- DOI: 10.1016/j.scitotenv.2020.141749
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This article develops and applies a metacoupling-based framework to analyze how interactions among Sustainable Development Goals (SDGs) operate both within a place and across geographic or administrative boundaries. The study is explicitly situated in the metacoupling/telecoupling literature and uses China’s network of 67 giant panda reserves as a demonstration case, with Wolong Nature Reserve as the focal system.

The framework extends existing SDG interaction work by embedding synergies and tradeoffs in a metacoupled system composed of sending, receiving, and spillover systems linked by flows of people, money, organisms, information, and infrastructure. It considers intracoupling (within one system), pericoupling (between adjacent systems), and telecoupling (between distant systems), and distinguishes direct and indirect SDG interactions.

Empirically, the authors examine two cross-boundary processes: nature-based tourism to Wolong (people flowing in) and international panda loans from Wolong to zoos abroad (animals, finance, and knowledge flowing out). Using household and tourist surveys, interviews with reserve staff, secondary statistics, and literature review, they link observed effects to official SDG indicators for six goals: no poverty (SDG 1), zero hunger (SDG 2), decent work and economic growth (SDG 8), industry-innovation-infrastructure (SDG 9), life on land (SDG 15), and partnerships for the goals (SDG 17).

They identify 19 distinct SDG interactions: 17 synergies and 2 tradeoffs. Within Wolong, tourism and panda loans are associated with poverty reduction, higher household incomes, more tourism employment, improved infrastructure, expanded scientific research, and stronger international and domestic partnerships. At the same time, tourism both supports forest recovery by reducing fuelwood use and harms panda habitat through disturbance, illustrating a simultaneous synergy and tradeoff between SDG 8 and SDG 15.

Across boundaries, tourism in Wolong stimulates tourism and income gains in other panda reserves and deepens institutional cooperation, but also spreads ecological pressures through resource extraction and habitat disturbance elsewhere. Panda-loan revenues support research capacity, conservation stations, and panda reintroductions in other reserves, creating positive links between SDG 17, SDG 9, and SDG 15.

The paper shows that SDG interactions are strongly shaped by cross-boundary flows and spillover effects, reinforcing that metacoupling/telecoupling perspectives are essential for designing policies that enhance SDG synergies and limit tradeoffs across places.

## Structured Metacoupling Extraction

### Coupling Classification
- Explicit metacoupling focus; analyzes intracoupling, pericoupling, and especially telecoupling of SDG interactions

### Intracoupling
#### Systems
- Wolong Nature Reserve as coupled human and natural system
- Individual panda reserves as local coupled systems
#### Flows
- Tourism within Wolong affecting livelihoods and habitats
- Internal financial and information flows supporting research and management
#### Agents
- Reserve administration and local government
- Local households and tourism businesses
- Researchers and conservation staff
#### Causes
- Pursuit of SDGs on poverty, growth, infrastructure, partnerships
- Development of nature-based tourism and panda programs
#### Effects
- Local poverty reduction and income growth
- Improved infrastructure and research capacity
- Mixed impacts on panda habitat from tourism

### Pericoupling
#### Systems
- Wolong and nearby panda reserves in Sichuan
- Neighboring reserves connected by regional tourism circuits
#### Flows
- Tourist trips extending from Wolong to adjacent reserves
- Labor migration between nearby reserves for tourism work
#### Agents
- Regional tour operators and drivers
- Households from adjacent reserves
- Regional conservation and tourism agencies
#### Causes
- Joint tourism development in regional scenic loop
- Search for employment and business opportunities
#### Effects
- Spillover tourism revenue in neighboring reserves
- Increased human disturbance in adjacent panda habitats
- Strengthened regional tourism partnerships

### Telecoupling
#### Systems
- Wolong and overseas zoos in multiple countries
- Wolong and international tourist source countries
- Other panda reserves as spillover systems globally
#### Flows
- Inbound international tourists to Wolong
- Outbound panda loans to foreign zoos
- Financial transfers via international collaboration fund
#### Agents
- Chinese and foreign zoo institutions
- International tourists and donors
- National forestry and conservation agencies
#### Causes
- Global panda loan agreements and conservation diplomacy
- International demand for panda viewing and nature tourism
- Implementation of global SDG agenda and partnerships
#### Effects
- Funding for conservation stations and research in many reserves
- Enhanced global scientific collaboration on pandas
- Potential global environmental impacts from travel emissions

### Cross-Coupling Interactions
- Tourism and panda loans jointly alter SDG synergies within Wolong and across other reserves
- Same SDG pair can show synergy and tradeoff simultaneously within and across systems
- Indirect SDG links emerge as initial flows trigger secondary financial and information flows

### Research Gaps or Limitations
- Limited data for SDG effects in tourist and panda recipient countries
- Conservative estimates of spillover impacts and indirect tradeoffs
- Climate and pollution consequences of flows only qualitatively discussed

### Search Keywords
- metacoupling SDG synergies tradeoffs Wolong panda loans tourism
- telecoupling pericoupling spillover systems conservation China
- Giant Panda International Collaboration Fund cross-boundary sustainability

### Extraction Confidence
high
