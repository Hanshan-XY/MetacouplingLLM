# From Kenya with loveâ€¦ agents shaping the backbone of a telecoupled rose system, 1920â€“2020

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:06:19.417449+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Strecker and Veraart - 2023 - From Kenya with loveâ€¦ agents shaping the backbone of a telecoupled rose system, 1920â€“2020.pdf
- Year: unknown
- DOI: unknown
- OA status: unknown
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: No DOI

## Copyright-Safe Summary
This article traces a century-long, transnational history of the rose trade linking Kenya and the Netherlands from the 1920s to 2020. It explicitly applies and extends the telecoupling and metacoupling lens by treating the Dutch-Kenyan flower sector as a dynamic socio-ecological system where production and consumption are separated in space and time but tightly connected through flows, feedbacks, and shared infrastructures.

Geographically, the study focuses on Kenya (especially the Lake Naivasha region and Nairobi’s Jomo Kenyatta International Airport) and the Netherlands (notably the auction hub around Aalsmeer and Royal FloraHolland), while also situating the system within broader European and East African trade networks. The system context is a globalised floriculture industry in which Kenyan roses supply European demand via Dutch auctions and logistics platforms.

Using historical methods, the authors synthesize secondary literature, trade statistics, and Dutch archival sources to reconstruct four major periods: early Dutch horticultural innovations and air freight (1920-1960), internationalisation and aid-supported outsourcing to Kenya (1960-1990), rapid Kenyan expansion and digital auctions (1990-2000), and post-2000 consolidation, regulation, and regional shifts. The analysis centres on human and non-human agents, including growers, auctions, airlines, governments, certification bodies, supermarkets, logistics firms, and the roses themselves, whose biological requirements drive technological and spatial change.

Key findings show how a Dutch-based production system gradually relocated to Kenya while the Netherlands retained its role as logistical and pricing hub. Colonial legacies, preferential trade agreements, and liberal Kenyan policies initially enabled strong Dutch corporate influence, while later Kenyan tax and land reforms partially redirected investment toward other East African countries. Conflicts between Dutch growers, auctions, and policymakers, as well as sustainability debates and certification regimes, continually reshaped the system.

The paper is clearly about telecoupling: it demonstrates how distant production and consumption regions become co-dependent, how domestic and supranational policies act as entangling or disentangling forces, and how feedbacks and power struggles drive ongoing reconfiguration of a transnational rose system.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling between Kenyan rose production and Dutch-European consumption and redistribution
- Some intracoupling within Kenyan and Dutch horticultural sectors shaped by colonial and policy legacies

### Intracoupling
#### Systems
- Kenyan floriculture cluster around Lake Naivasha
- Dutch greenhouse floriculture and auction system
- Kenyan national trade and transport infrastructure
#### Flows
- Domestic labour and land into Kenyan flower farms
- Capital and technology within Dutch horticulture
- Roses moving from Kenyan farms to Kenyan airports
#### Agents
- Kenyan government and agencies such as HCDA and airport authority
- Dutch growers associations and auctions
- Kenyan Flower Council and local logistics firms
#### Causes
- Search for profitable export crops and employment
- Cheap natural gas enabling Dutch greenhouse expansion
- Colonial land allocation and postcolonial Kenyanisation policies
#### Effects
- Large Kenyan employment and foreign exchange earnings from flowers
- Decline of Dutch rose cultivation area since 2000
- Local environmental stress around Lake Naivasha water and pollution

### Pericoupling
#### Systems
- Kenya and neighbouring East African producers like Ethiopia
- Regional logistics network linking Naivasha, Nairobi, Eldoret, Mombasa
- East African Community trade region linked to EU
#### Flows
- Investment and expertise shifting from Kenya to Ethiopia
- Regional cargo flows through Kenyan airports and harbour
- Knowledge transfer by Kenyan expatriates to Ethiopian floriculture
#### Agents
- Ethiopian government promoting floriculture
- Regional logistics companies such as Siginon Group
- East African Community negotiators on EU trade agreements
#### Causes
- Kenyan tax tightening and land laws pushing investors abroad
- Preferential EU access for East African exports
- Search for lower production costs and liberal regulations
#### Effects
- Rapid Ethiopian floriculture growth rivaling Kenyan production
- Spatial redistribution of employment and environmental burdens in East Africa
- Increased vulnerability of Kenyan farms to regional competition

### Telecoupling
#### Systems
- Kenyan rose export system oriented to European markets
- Dutch auction and re-export hub centred on FloraHolland
- Global consumer markets, especially European supermarkets and households
#### Flows
- Roses airfreighted from Kenya to the Netherlands and beyond
- Foreign investment, technology, and expertise into Kenyan floriculture
- Information, prices, and standards via auctions, digital platforms, certifications
#### Agents
- Royal FloraHolland and predecessor Dutch auctions
- Foreign and Kenyan flower firms like Oserian, Sulmac, Karuturi
- EU, Dutch and Kenyan governments, Fairtrade, supermarkets, consumers, airlines like KLM
#### Causes
- Year round European demand for roses and seasonal peaks
- Rising Dutch energy costs and search for cheaper warm locations
- Preferential trade agreements, development aid, and liberal import policies
#### Effects
- Economic dependence of Kenyan communities on volatile export markets
- Environmental impacts from irrigation, pesticides, and airfreight emissions
- Labour rights controversies and emergence of ethical certification schemes

### Cross-Coupling Interactions
- Dutch import restrictions triggered creation of online Tele Flower Auction reconnecting Kenyan growers to European buyers
- Kenyan regulatory tightening reduced local investment but spread rose production to other African countries
- Media and NGO campaigns shifted European demand toward certified roses reshaping Kenyan farm practices

### Research Gaps or Limitations
- Limited quantitative assessment of long term telecoupled environmental and social impacts
- Dutch side previously underresearched compared to Kenyan production focus
- Power and justice dimensions mentioned but not deeply theorised or measured

### Search Keywords
- Kenya Netherlands rose telecoupling
- Lake Naivasha floriculture history
- Royal FloraHolland Tele Flower Auction

### Extraction Confidence
high
