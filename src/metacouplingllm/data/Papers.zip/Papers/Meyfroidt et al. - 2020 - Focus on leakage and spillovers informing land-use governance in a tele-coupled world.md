EDITORIAL • OPEN ACCESS

# Focus on leakage and spillovers: informing landuse governance in a tele-coupled world

To cite this article: P Meyfroidt et al 2020 Environ. Res. Lett. 15 090202

View the article online for updates and enhancements.

# You may also like

The public use of early-stage scientificadvances in carbon dioxide removal: a science-technology-policy-media perspective

Giorgio Tripodi, Fabrizio Lillo, Roberto Mavilia et al.

Potential contributions of digital finance toalleviating the ‘low-end lock-in’ dilemma for green innovation in enterprises

Xinxin Yu

Deforestation spillovers from oil palmsustainability certification

Robert Heilmayr, Kimberly M Carlson and Jason Jon Benedict

![](images/65c457c4890a145abc2e430d7941f068373aee00cb9cadfc5ab26a5c4d948c47.jpg)

![](images/0a0baa4db07288e597833f6d2621332a4137219cb29b2cf40caf594aed0a07d2.jpg)

# Environmental Research Letters

![](images/5cf7ce39c4c45408baea450c9223c850bf6c5e3c67d71366a8ed1423062f7f8b.jpg)

CrossMark

# OPEN ACCESS

PUBLISHED

4 September 2020

Original content from this work may be used under the terms of the Creative Commons Attribution 4.0 licence.

Any further distribution of this work must maintain attribution to the author(s) and the title of the work, journal citation and DOI.

![](images/015cd66ce9cb4bce73799c8423c27563436c122294ba089fc50140637646310d.jpg)

# EDITORIAL

# Focus on leakage and spillovers: informing land-use governance in a tele-coupled world

P Meyfroidt $^ { 1 , 2 , 1 0 } \oplus$ , J Börner ${ } ^ { 3 } \oplus$ , R Garrett4 , T Gardner ${ } ^ { 5 } \oplus$ , J Godar5 , K Kis-Katos6 , B S Soares-Filho7 and S Wunder8,9

1 Université catholique de Louvain, Louvain-la-Neuve, Belgium   
2 Fonds de la Recherche Scientifique F.R.S.-FNRS, Brussels, Belgium   
3 Institute for Food and Resource Economics & Center for Development Research, Rheinische Friedrich-Wilhelms-Universität Bonn, Germany   
4 Environmental Policy Group, Departments of Environmental System Science and Humanities, Political and Social Science, ETH Zurich, Switzerland   
5 Stockholm Environment Institute, Sweden   
6 University of Göttingen, Platz der Göttinger Sieben 3, D-37073 Göttingen, Germany   
7 Federal University of Minas Gerais, Brazil   
8 European Forest Institute, Barcelona, Spain   
9 Center for International Forestry Research, Indonesia   
10 Author to whom any correspondence should be addressed.

E-mail: patrick.meyfroidt@uclouvain.be

# Abstract

Governing land use to achieve sustainable outcomes is challenging, because land systems manifest complex land use spillovers—i.e. processes by which land use changes or direct interventions in land use (e.g. policy, program, new technologies) in one place have impacts on land use in another place. The ERL issue ‘Focus on Leakage: informing Land-Use Governance in a Tele-coupled World’ builds on discussions in an international expert workshop conducted in Berlin in November 2017 to explore innovative ways to improve our understanding of how governance interventions, new technologies and other factors can affect land-use change both directly and indirectly through spillovers. This editorial starts by clarifying the definitions and relationships between land-use spillover, indirect land use change—a form of spillover where land use change in one place is caused by land use change in another place—leakage—a form of land use spillover, which is caused by an environmental policy (e.g. a conservation or restoration intervention), and the spillover reduces the overall benefits and effectiveness of this intervention—, and land use displacement processes. We then use this terminology to summarize the individual contributions of this special issue and conclude with lessons learned as well as directions for future research.

# 1. Introduction

Amid growing global demand for food and non-food biomass, new and innovative commodity supply chain interventions and hybrid governance arrangements are being devised by private, public, and civil society actors to minimize sustainability trade-offs among the goals of the Agenda 2030 (Timko et al 2018). Governing land-use is challenging, because land-use systems are complex with drivers operating directly and indirectly through dynamic interactions and feedbacks (Meyfroidt et al 2018). One type of indirect effect is the displacement of land-uses to near or remote sites, often described as either a spillover effect or leakage. Spillover effects are inherently more

difficult to detect and quantify than direct cause-effect relationships in telecoupled land-use systems, and can lead to both positive (reinforcing) and negative (counteracting) social and environmental impacts (Atmadja and Verchot 2012, le Polain de Waroux et al 2017). A systemic perspective that accounts for such indirect effects is needed for diversified governance schemes to tackle the increasing complexity of global value chains and achieve sustainable outcomes. A combination of quantitative and qualitative research approaches is required to provide such a systemic perspective (Magliocca et al 2019). Qualitative approaches are crucial to understanding the knowledge, motivations, decision-making, and coalitions of the multiple actors that operate these spillovers

(le Polain de Waroux 2019). Here we focus mostly on new tools and data sources to monitor land use change, trace commodity trade flows, and model dynamic spillovers in land systems, such as Global Forest Watch (https://globalforestwatch.org/), Trase (https://trase. earth), Exiobase (https://exiobase.eu/), and others.

The ERL issue ‘Focus on Leakage: informing Land-Use Governance in a Tele-coupled World’ explores innovative ways to put such tools and data to work towards improving our understanding of how governance interventions, new technologies and other factors can affect land-use change both directly and indirectly. Building on discussions in an international expert workshop11 conducted in Berlin in November 2017, it integrates three related streams of scholarly work on direct and indirect land use change:

1. Conceptual and theoretical research on the causal mechanisms, contextual determinants, and governance frameworks of land-use leakage and spillover effects.   
2. Empirical research that quantifies land-use spillover dynamics and impacts embodied in supply chains, often using data aggregated at relatively coarse scales.   
3. Use of trade and land-use models and other causal inference approaches to quantify the causal effects of specific factors such as policy interventions on land use leakage and spillovers.

Acknowledging that there is still a significant level of confusion around terminology and uncertainty in the causal mechanisms of indirect effects of land-use change drivers, this editorial starts by clarifying the definitions and relationships between land-use spillover, leakage, and displacement processes. We then build on this terminology to summarize the individual contributions of this special issue and conclude with lessons learned and directions for future research.

# 2. Spillovers in land system science: definition and categories

Building on economics, policy analysis and land system science, we refer to land-use spillovers as the process by which land-use changes or direct interventions in land use (e.g. policy, program, new technologies) in one place have impacts on land use in another place (Meyfroidt et al 2018). The notion of spillovers thus often relates to ‘indirect impacts’. Land-use spillovers manifest themselves through changes in land cover, use, or management practices. This definition leads to four key insights:

11 ‘Land use spillover and leakage effects: towards integrating concepts, empirical methods, and models’, 9–10 November 2017, Berlin, Germany. See: https://zef.de/index.php?id=2879

1. Spillovers take various forms: they can occur across and within places, agents, or land use and commodities not targeted by the intervention or not affected directly by the initial land-use change (Garrett et al 2019), or through indirect effects outside the time window of an intervention (e.g. Jacobson 2014).   
2. Spillovers can be positive or negative, i.e. reinforcing or counteracting the impacts of the intervention or the initial land-use change.   
3. Spillovers primarily refer to effects on the land-use change or outcome targeted by the intervention or initially affected (e.g. deforestation spillover from an anti-deforestation intervention), but the notion can also cover impacts on non-targeted or indirectly affected variables. For practical reasons, indirect effects are generally considered as spillovers when they affect variables in the same domain as the variables directly affected, but see below the discussion on leakage.   
4. An often-discussed criterion for spillovers is that they are unintended or unexpected by an intervention’s design (Lim et al 2017). This often proves to be a poor criterion, as the intentions and knowledge of a program’s designers may be ambiguous, exploratory, or simply unknown12. We therefore argue that spillovers can be intended and expected, or not.

An underlying definitional criterion of spillover (figure 1(a)) remains that an intervention or another cause (X), by affecting land use (Y), has an indirect causal impact on a non-targeted outcome (Z) in a different domain—i.e. a combination of (i) a geographic space, (ii) a set of actors, and (iii) a set of land uses, commodities or land use impacts) (see figure 1 and details below).

Indirect land use change (iLUC) (figure 1(b)) is a form of spillover, where land use change in one place is caused by land use change in another place (Meyfroidt et al 2018). iLUC is the most general form of land use spillover (whereas all other types of indirect outcomes from the intervention X on land use Y fall in the category of ‘other type of spillover’ (figure 1(c)). ILUC can be created when the increasing demand for one crop induces displacement of another crop, through rebound-effects, or land sparing from intensification (Meyfroidt et al 2018).

We define land use leakage (figure 1(d)) in a strict sense as a form of land use spillover, which is caused by

12 Researchers may use the notion of spillovers even for interventions where policy-makers decided to protect a highly valued area, while being aware of potential side effects elsewhere (to less valuable areas or outside their jurisdiction or mandate) (Bastos Lima et al 2019). The degree of control by program designers on spillovers may also be very variable, and some authors do not mention this criterion at all (Pfaff and Robalino 2017).

Cause X affects outcome Y in domain I

and not only outcome Yin Ichanges,but also outcome Zin domain Il is affected:

![](images/d15ef722904bcc74ba4c1730d66a58d650275cff79135f30b66305c8fa12e503.jpg)  
Figure 1. Forms of spillover phenomena in the context of land system change. Notes: A ‘domain’ is defined as a combination of (i) a geographic space, (ii) a set of actors, and (iii) a set of land uses, commodities or land use impacts. A land use spillover can thus arise if an initial land use change or intervention to affect land use results in another land use impact (denoted here by Z) in another geographic space, through other actors, or through another type of land use or commodity (e.g. an intervention that targets a specific crop and aims to reduce deforestation, which then leads to increased deforestation through another crop). When the causal attribution to a given policy or intervention is not sufficiently strongly established, the category of spillover, and possibly land use displacement, can be used. When sufficient evidence accumulates on the causal attribution to an intervention, the spillover can be labeled as leakage.

an environmental policy (e.g. a conservation or restoration intervention), and where the spillover reduces the overall effectiveness of this intervention (Meyfroidt et al 2018, Garrett et al 2019). We focus here on environmental interventions, but the same reasoning can be applied to policies that pursue other objectives such as social or economic goals. Following this definition, all land use leakage occurs through iLUC.

We highlight three key elements to define the concept of leakage in a strict sense:

1. A causal linkage from an environmentally-related intervention.   
2. The leakage-affected outcome variable is the same as the targeted outcome of the intervention, although in a different domain—i.e. in another place, through other actors, or through other land uses or commodities.   
3. Leakage (sensu stricto) has a negative (counteracting) effect on this variable.

Some broader definitions of leakage relax one or several of these criteria, or introduce complementary terms. Complete relaxation of these criteria would make leakage synonymous with spillovers and thus render the term useless. Yet, in practice, it can be tricky to fully apply the criteria above.

First, demonstrating the causal attribution of leakage can prove extremely difficult, due to methodological

limitations but also to the complex nature of land system changes, which often result from combinations of causes including policy mixes (Lambin et al 2014, Meyfroidt 2016, Meyfroidt et al 2018). Some authors have thus distinguished between ‘weak leakage’, as a displacement of environmental impact that is not clearly causally attributed to an environmental intervention, and ‘strong leakage’ that corresponds to the above, strict definition of leakage (Peters and Hertwich 2008, Peters 2010). Instead of ‘weak leakage’, other studies used the vocabulary of land use displacement (figure 1(f)) to refer to ‘a temporal, spatial, social or sectoral separation between consumption and production of a material good’ (Meyfroidt and Lambin 2009, p 16139), or a ‘geographic shift of land use from one place to another’ (Meyfroidt et al 2013, p 440). This term thus allows characterizing forms of distant impacts when the evidence for a causal link with a given intervention or initial land-use change, and thus the characterization as ‘spillover’, cannot be made firmly or may not exist (see figure 2).

Second, environmental policies typically have multiple targets that can be defined more or less precisely (e.g. by a clear indicator such as carbon emissions, or a broad objective such as ‘sustainability’), and the fundamental goals of agents (policy-makers, households, enterprises, etc) are often broader than what is covered by a single intervention. Evaluating trade-offs between multiple impacts thus often requires assessing spillovers on dimensions that were not initially considered in the intervention. As knowledge and awareness of new issues increases, and

![](images/15483a016a0f46ec0fcbc5c21a3913c9ed8669d36da4a82e0a01386c32a60f39.jpg)  
Figure 2. Venn diagrams of spillovers, leakage, iLUC and land use displacement, and the situation of the papers in this Special Issue.

intervention goals evolve, certain spillovers can come to be framed as leakage (Bastos Lima et al 2019). Although leakage is thus indeed referring to the target variables of the intervention, what constitutes these target variables can be the subject of political debates.

At times, the negative effect criterion may prove complicated operationally. Interventions can have multiple positive and negative spillovers. Some authors have thus used ‘inverted leakage’ or ‘positive leakage’ to refer to spillovers that have positive impacts on the targeted variable. However, we believe that because of its negative connotation, the word ‘leakage’ is best reserved for impacts that are indeed negative, and suggest referring to positive land use spillover (figure 1(e)) in other cases (Pfaff and Robalino 2017). The specific set of positive spillovers that fulfill the first two conditions of leakage (causal link with an environmental intervention and effect on the targeted variable) have also been called boosting effects (Bastos Lima et al 2019). In practice, the identification of a negative effect is linked to the scale of the analysis. In an analysis at country level, a negative effect in other countries represents leakage, even though this net effect may mask gross positive effects on some places or companies within this observed country. In contrast, in a spatially disaggregated analysis at grid cell level, all negatively affected pixels would constitute leakage.

Some widely studied examples of the above phenomena include iLUC as a result of biofuel policies in the EU and the US or from soybean expansion into pasture in Brazil (Tokgoz and Laborde 2014) (1b), inside-to-outside leakage of deforestation or illegal hunting from protected areas (Fuller et al 2019) (1d),

and affluence-induced displacement of agricultural production from high-income to low-income countries (Pendrill et al 2019, Schierhorn et al 2019) (1f).

# 3. What have we learned from this special issue’s papers?

We grouped the papers published in this special issue based on the above terminology, to synthesize their key contributions (figure 2). Here we discuss what we have learned about these phenomena, the next challenges in terms of knowledge and data gaps, and methodological frontiers, and the implications for policy-makers. We then distill broader insights that emerge from this set of studies.

# 3.1. Theoretical, methodological and conceptual insights

In his economic perspective on land use change and leakage, Hertel (2018) synthesizes implications from a series of successively more complex models to analyze core economic mechanisms behind land use leakage and spillovers. This work shows that economic responses to scarcity (i.e. biomass supply and demand responses), including through land use spillovers, dampen the extent of cropland expansion in the face of growing demand and technology change. It then highlights three key factors that moderate land use spillovers, namely (1) market segmentation and product differentiation, (2) the bilateral ‘geography’ of international trade, and (3) changes in comparative advantage.

Hertel et al (2019) review the bidirectional linkages between global and local processes in land use and land-cover change models, noting that research has so far mainly focused on impacts of global drivers on local outcomes. They propose a framework of globalto-local-to-global (GLG) linkages of land-use and land-cover change that emphasizes the role of (1) policies as filters and (2) local contextual factors as moderators of global drivers on local stressors, whereas the resulting (3) impacts induce behavioral and production changes that (4) have feedback effects on global drivers. They call for more interdisciplinary and transparent collaboration among modeling groups, including through open-source applications.

Bastos Lima et al (2019) highlight that leakage is a complex governance issue involving questions of institutional fit, landowners’ responses, and political agenda, and which operates not only through markets or activity displacement but also through information, motivation, and institutional channels. Analyzing leakage from an environmental governance perspective requires understanding that (1) as policy-makers may act strategically, the unintentionality of leakage should not be assumed, but rather be an object of research, (2) a phenomenon can come to be framed as leakage through the action of ‘problem brokers’ and changes in policy fields, and (3) the focus should be broadened from only avoiding leakage to seeking positive spillovers and institutional synergies.

# 3.2. Land use displacement

The papers summarized in this section do generally not seek to identify causes of land use change. They document patterns of land use change that have multiple causes, possibly including but not limited to land-targeting environmental policies. The methodological approaches used here thus serve to illustrate broad categories of ‘other land use spillovers’ and ‘land use displacement’ (see figures 1, 2).

Pendrill et al (2019) quantify deforestation embodied in production of internationally-traded agricultural and forestry commodities from the tropics and subtropics using a land-balance model based on global data. For the period 2005–2013, they attribute $6 2 \%$ (5.5 Mha $\mathrm { y r } ^ { - 1 } .$ ) of forest loss to expanding commercial cropland, pastures, and tree plantations. Over a quarter of the deforestation was associated to international demand, mostly by countries that have decreasing deforestation rates or increasing forest cover. About a third of the achievements in forest protection in these countries is thus offset by environmental externalities in the form of displacement toward commodity exporting, often tropical, regions.

Bruckner et al (2019) use a novel hybrid land flow accounting model with exceptional detail at country and product level to quantify the global cropland footprint of the European Union’s (EU) non-food bioeconomy. Their analysis shows that the EU, despite

small rates of domestic land-cover change, has increased its global cropland footprint between 1995 and 2010 mainly by displacing or expanding land uses that supply biomass for non-food uses, such as biofuels and biomaterials. The corresponding land use impacts accrue mainly in world regions with limited land-use governance capacity, such as Southeast Asia, Africa, and Latin America.

Többen et al (2018) develop a hybrid monetaryphysical supply-chain modeling approach by integrating physical accounts into the environmentally extended multiregional input–output model EXIOBASE. The EXIOBASE upgrade is linked with the life-cycle impact assessment model LC-Impact to assess land use effects on biodiversity. For the period 2000–2010, the analysis shows that oil seed consuming countries substituted significant amounts of domestically produced oil seeds with relatively low biodiversity impacts by Indonesian palm and Brazilian soybean oil, leading to land-use displacement towards these countries. The authors warn against devising unilateral demand-side policies focused on specific oils, such as palm oil, which could lead to substitution effects (between oils) and unintended shifts of environmental impacts.

Schierhorn et al (2019) take a consumption-based perspective pointing to large GHG emissions savings from food system changes associated with the collapse of the Soviet Union and subsequent economic recovery. Their analysis shows how emission changes were mainly driven by decreasing beef consumption in the 1990s and increasing beef imports after 2000. Despite the associated land use displacement, changes in consumption behavior, combined with carbon sequestration in soils on abandoned agricultural land, led to net GHG emission savings. This highlights the importance of jointly considering production and consumption changes to understand the systemic transformations that mediate land-use displacement and its outcomes.

# 3.3. iLUC, land use leakage, and other spillovers

This section synthesizes special issue contributions that employ causal inference methods and modeling to identify and measure land use spillovers, including leakage effects.

Escobar et al (2018) use an extended version of the computable general equilibrium model GTAP to study the effect of demand-side policies that encourage the consumption of bioplastics as opposed to conventional fossil fuel based plastic products. Their simulations suggest that complex interactions in the global trade system can produce leakage that offset the GHG savings from such a bio-based climate change mitigation strategy. On average, bioplastic-based fossil fuel substitution using conventional technologies would have carbon payback times of 22 years and result in annual abatement costs of over USD 2000 per ton of $\mathrm { C O } _ { 2 }$ -equivalents. More favorable outcomes are

potentially possible if second or third generation technologies allow producing bioplastics with enhanced properties.

Miranda et al (2019) explore how the Brazilian agricultural land market mediates leakage from conservation policies. Their innovative empirical approach suggests that land prices respond to the availability of knowledge on future infrastructure improvements, leading to speculation. The study also suggests, less robustly, that changes in conservation policy implementation in the Brazilian Amazon affected land prices in the neighboring Cerrado region. Further research is needed to explore whether (1) these price changes translate into cross-regional leakage of deforestation from one into another biome and (2) net outcomes in terms of sustainability indicators, such as biodiversity and carbon sequestration, are positive.

Giudice et al (2019) study the impact of the Peruvian National Forest Conservation Program on forest cover change in the indigenous communities targeted by the intervention using a quasi-experimental evaluation design. They find that the program has so far produced only small conservation gains, which accrued outside the enrolled forest areas, possibly induced by an unintended local positive spillover. The authors attribute these limited impacts to program design, which targeted communities with low deforestation pressure and allowed adverse selection of low-pressure forest areas into the program by communities. The observed dip in deforestation in the non-enrolled zones of participating communities could result from absorption of labor by the program’s initial activities, or a behavioral phenomenon called the ‘Hawthorne’ effect—i.e. the fact that as people know that they are enrolled into an experiment, this modifies their behavior. These findings suggest that econometric studies identifying micro-leakage processes may require complementary case-studies to characterize the underlying mechanisms.

Batista et al (2019) analyze the implications of national pasture restoration programs, including land-use and non land-use spillovers using a life-cycle analysis (LCA)-extended multi-sectoral simulation model of the ranching system in Mato Grosso state in Brazil. Their findings suggest that a GHG mitigation strategy focused more heavily on pasture restoration produces the least favorable economic and GHG emissions outcomes when compared to alternatives that additionally rely on supplementary feeding. Their results do not indicate strong direct or indirect effects on land cover change in any of the pasture restoration scenarios. However, they suggest that Brazil seek a more diversified strategy for cattle intensification in its climate change mitigation policy.

Villoria (2019) uses an econometric approach to explore whether technology improvements in agriculture contributed to reducing greenhouse gas emissions from land conversion, including in biodiversity rich biomes at global scale in the period from 2000 to

2010. Villoria finds that iLUC effects explain why agricultural productivity growth saves land and still contributes to degrading natural ecosystems. The study shows that agricultural land expanded in many countries that experienced strong productivity increases, confirming the so called ‘Jevon’s Paradox’, whereas agriculturally used land contracted in other parts of the world—an environmentally often costly process of iLUC. Villoria also predicts that current rates of agricultural productivity growth are insufficient to avoid future net expansion of agricultural land uses at global scale.

Richards and Arima (2018) investigate how capital surpluses during periods of high profitability are driving the expansion of soy production at Brazil’s agricultural frontiers. Temporary surpluses, rather than continuously growing international demand and corresponding producer expectations, allow farmers to reinvest profits for additional land acquisition and clearing. In the absence of alternative investment options, relaxation of capital constraints on expansion in the farm sector then appears to become a key mechanism driving iLUC.

zu Ermgassen et al (2019) use supply chain transparency data from Trase to monitor zero deforestation commitments (ZDCs) in the Brazilian soy sector. A jurisdictional approach allows to account for local spillovers within municipalities of production. They observe no change in the exposure of companies or countries adopting ZDCs to soy-associated deforestation in the Cerrado. They conclude that the formulation and implementation of these ZDCs present several systematic weaknesses that can induce leakage, related to definition of deforestation, the responsibility of subsidiary companies and joint ventures, vagueness in the stringency of the commitments, regions covered, cut-off points and others.

Heilmayr et al (2020) quantify deforestation spillovers from the Roundtable on Sustainable Palm Oil (RSPO) certification system in Indonesian Borneo (Kalimantan), both leakage and positive spillovers, using an econometric model. They develop a detailed framework to articulate the plausible causal mechanisms of spillovers transmitted within corporate groups and through local agricultural markets, including economic processes but also learning, nonpecuniary motivations and ecological-physical links. They show that these mechanisms can be partly disentangled by analyzing the spatial patterns in spillovers. Certification reduced the likelihood of forest clearing within the certified supply bases. Spillovers were spatially heterogenous, with counteracting positive and negative spillovers resulting in, overall, an insignificant net total direct and indirect impact of RSPO certification on deforestation in comparison to overall deforestation from oil palm expansion in Kalimantan.

Rodríguez García et al (2020) analyze the long and short-run spillovers between changes in cropland area and intensity, using a global cross-country panel

dataset over 1961–2016 and a cointegration approach. They disentangle the effects of intensification through yields versus total factor productivity changes. They show that in the short run, intensification resulted in a rebound effect in key agricultural producers of commodities with high price-elasticity of demand, including rubber, flex crops (sugarcane, palm oil and soybean), and tropical fruits. Over the long run, rebound effects remained for key commodities such as flex crops and rubber, but staple cereals such as wheat and rice manifested land sparing, and low income countries showed induced intensification.

# 4. Discussion: ways forward for understanding and governing land use spillovers

The papers in this Special Issue identify or hypothesize on several interacting mechanisms of leakage described in the literature, and which are triggered by different drivers under different sets of conditions (Meyfroidt et al 2018): (1) activity leakage—reallocation of production factors or inputs including labor and capital (Richards and Arima 2018, Giudice et al 2019), (2) land market leakage—the spread of land rent increases in affected places through land markets, driving land investments (Miranda et al 2019), and (3) commodity market leakage—land use expansion in response to changes in product prices (Escobar et al 2018, Hertel 2018). Several studies in this Special Issue also highlight that a proper accounting of spillovers and leakage effects requires accounting for effects across sectors and activities, e.g., across supply chains (zu Ermgassen et al 2019, Heilmayr et al 2020), the whole agricultural or food system (Rodríguez García et al 2020, Schierhorn et al 2019, Villoria 2019), across food and non-food sectors (Bruckner et al 2019), or across land and non-land related sources of GHG emissions (Escobar et al 2018).

The papers in the Special Issue also provide key insights regarding the governance of leakage and other spillovers. They illustrate that causal attribution of the observed spillover to a given intervention remains difficult, because the signal of the intervention mixes with the multiple drivers of land use change, including changes in local and global markets, technologies, and other policies (Többen et al 2018, Bruckner et al 2019, Pendrill et al 2019, Schierhorn et al 2019), and because multiple mechanisms overlap on the same land (Heilmayr et al 2020).

While land use impacts can be difficult to attribute to a specific policy post-hoc, identifying the conditions that make places and actors a priori more susceptible to leakage and other forms of iLUC (e.g. Meyfroidt et al 2018) can help improve the design of policies (Garrett et al 2019). Hertel (2018), Villoria (2019), and Hertel et al (2019) generate important insights in this regard. Conditions that make places more likely to

generate land use leakage include high labor and capital mobility, lack of knowledge or technology for agricultural intensification combined with elastic domestic or international demand (Hertel 2018, Rodríguez García et al 2020). Supply-chain leakage is hypothesized to be more likely in a diffuse purchasing market that exhibits heterogeneous preferences for sustainably-sourced products. It is also more likely when commodities are fungible and have complex production life-cycles, which complicates traceability (Garrett et al 2019). Conditions that make places more susceptible to absorb leakage could be framed in terms of vulnerability and exposure. Vulnerability includes being susceptible to respond to market signals because of available, suitable and accessible land and other resources, and being prone to respond by land use expansion on environmentally-valuable land, in particular because of inadequate environmental governance, including less stringent land use restrictions (le Polain de Waroux et al 2016, 2017, Hertel et al 2019).

Exposure to both land use displacement and land use leakage increases when places are well-connected to the place where an intervention or other cause of land use change (e.g. consumption) occurs (Villoria 2019). This integration can favor efficiency in the reallocation of inputs via global trade, but may also lead to greater overall land use demands, depending on the underlying technology levels in the susceptible regions (Villoria 2019). Connectedness is influenced not only by how linked two regions are at a current point in time, but also how rigid these connections are. Larger spillovers can be expected when two places are fully integrated, and trade relations are flexible, compared to a situation in which trade relationships are ‘sticky’, thereby muting reactions to changing contexts such as policy changes (Villoria and Hertel 2011, Godar et al 2015, Hertel 2018, Reis et al 2019). These rigidities between trade partners may also contribute to explain improvements in environmental and land use governance, which are in themselves a form of spillover and may contribute to offset leakage (Garrett et al 2013, 2019). Understanding how these existing patterns of rigidity along supply chains may favor or offset leakage can also inform the design of policy. Beyond the magnitude of leakage, the location where leakage may occur may also depend on the patterns of stickiness in trade: interventions in supply chains are more likely to result in leakage to some specific places or through some specific actors that are more rigidly linked to the places where interventions originate from. Multiple studies have quantified stickiness in country-to-country trade patterns for different agricultural products (Agcaoili-Sombilla and Rosegrant 1994, McDaniel and Balistreri 2003, Donnelly et al 2004), but they typically say little on why these rigidities happen, and even less is known about the persistence of trading relations between local places of production and producers, local buyers, and trading and retailing companies that operate international

supply chains. Further investigating and understanding this ‘stickiness’ and its role in spillovers and leakage constitute a key research area (Reis et al 2019).

# 5. Conclusions and ways forward

Research on land-use related leakage and spillovers has made valuable progress recently by improving the identification and characterization of the various mechanisms through which such indirect effects occur, as well as the quantification of the complex environmental impacts that such spillovers create across places and indicators. Here we aimed to bring more conceptual clarity in the different types of land use spillovers and summarize recent research on spillovers as part of a special issue. This synthesis elucidated some of the drivers of different types of spillovers and their implications for governance. Below we summarize remaining knowledge gaps.

First, despite advances in quantifying single environmental indicators across supply chains, we need further progress in estimating the net global scale impacts when land-use spillover and leakage occurs through GLG linkages (Hertel et al 2019, Schierhorn et al 2019, Smith et al 2019). We currently lack a proper suite of tools that can inform the design of land-based governance schemes about immanent tradeoffs among sustainability dimensions, when these are likely to be mediated through spillover and leakage mechanisms (Escobar et al 2018, Többen et al 2018, Bruckner et al 2019).

Second, future work should combine multiple methodological approaches to strengthen causal analyses of particular spillovers and quantify the importance of distinct causal mechanisms. Model-based and empirical research on spillover and leakage effects evolve simultaneously, but seldom in collaboration. Opportunities regarding the interconnection between modeling and empirical approaches lie in (1) the exchange of data and joint generation of hypotheses, (2) empirical parameterization of critical model mechanisms, such as land-supply elasticities, (3) the use of modeling to inter- and extrapolate available spatial data to be used for empirical evaluation of spillover effects, and (4) the measurement of stickiness of commodity flow dynamics at various scales. Similarly, causal attribution of leakage requires complementary methodological frameworks, for instance by linking empirical research using big data to investigate largescale patterns with complementary case studies to verify hypothesized spillover and leakage phenomena at micro-scale, and better characterize the role of specific agents (e.g. producers, traders, investors) in these phenomena (Giudice et al 2019, Hertel et al 2019, zu Ermgassen et al 2019, Heilmayr et al 2020). Qualitative research focusing on the actors or agents of spillovers are key to understand the informational, motivational or institutional channels of leakage and how certain phenomenon come to be framed as

leakage (Bastos Lima et al 2019). Combining modeling approaches also opens promising avenues. Economically motivated global trade models and land use simulation modeling informed by environmental science can be combined by generating summary functions or coupled meta-models. Such models may be, in turn, linked with MRIO and LCA methods using new data types (e.g. Trase).

Finally, research is needed to support the development of ‘adaptive management’ approaches for the governance of land use systems. To the extent that spillovers will never become entirely predictable, interventions must be designed to allow for adjustments when evidence for undesirable spillovers becomes available.

# ORCIDiDs

P Meyfroidt $\textcircled{1}$ https://orcid.org/0000-0002- 1047-9794 J Börner $\textcircled{1}$ https://orcid.org/0000-0003-3034-5360 R Garrett $\textcircled{1}$ https://orcid.org/0000-0002-6171-263X T Gardner $\textcircled{1}$ https://orcid.org/0000-0002- 4007-2936 K Kis-Katos $\textcircled{1}$ https://orcid.org/0000-0003- 2459-1274 B S Soares-Filho $\textcircled{1}$ https://orcid.org/0000-0002- 7703-946X S Wunder $\textcircled{1}$ https://orcid.org/0000-0002-9422-0260

