# The employment impacts of fossil fuel trade across cities in China A telecoupling perspective

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:48:38.893966+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Jin et al. - 2024 - The employment impacts of fossil fuel trade across cities in China A telecoupling perspective.pdf
- Year: unknown
- DOI: 10.1016/j.energy.2024.132751
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This article examines how intercity trade in fossil fuels shapes employment patterns across China, using a telecoupling perspective that focuses on socioeconomic linkages over distance. The geographic scope is national, with city-level detail across 313 regions. The study is clearly framed as a metacoupling/telecoupling analysis, connecting sending (resource-producing) and receiving (energy-consuming) cities through fossil fuel flows and employment dependencies.

The authors compile a spatially explicit inventory of 989 coal mines, 642 oil fields, and 461 gas fields, covering the large majority of China’s coal, oil, and gas extraction in 2017 (coal) and 2021 (oil and gas). They map each facility to its host city and estimate workers involved in extraction. For oil and gas, city statistical yearbooks provide employment intensities, which are multiplied by field output. This bottom-up employment dataset is integrated with a City-level Multi-Regional Input-Output (CMRIO) table for 313 regions and 42 sectors to track fossil fuel trade and the associated employment embodied in those flows. The authors compute telecoupled employment by combining trade flows with employment intensities and then decompose driving forces using final demand categories (households, government, investment, inventories, exports).

The study finds that fossil fuel extraction directly employs about 2.2 million workers, dominated by coal. Roughly 70 percent of these jobs serve energy demand outside the producing city, meaning they are telecoupled to distant consumers. Coal trade accounts for a bit more than half of telecoupled employment, oil and gas for the remainder. About three quarters of telecoupled employment moves across provincial borders, highlighting strong interprovincial dependence. Most cities are net importers of telecoupled employment, while a smaller group of resource rich cities are net exporters. Domestic final demand, particularly capital formation and construction, is the primary driver; international exports play a smaller role.

The authors show that consumption based and production based employment perspectives yield different spatial patterns, with many affluent, energy importing cities driving more fossil fuel jobs elsewhere than they host locally. They argue that city employment and energy transition policies should explicitly incorporate telecoupled employment risks, particularly for fossil fuel exporting cities exposed to demand shifts in distant consuming regions.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling among Chinese cities via fossil fuel trade and related employment
- Limited explicit intracoupling; pericoupling mainly intra provincial employment flows

### Intracoupling
#### Systems
- Individual Chinese cities fossil fuel extraction sectors
- City level energy and labor systems
#### Flows
- Local fossil fuel extraction and on site employment
- Intra city employment linked to city energy demand
#### Agents
- City governments and planners
- Local fossil fuel companies
- City level workers and households
#### Causes
- City energy demand and industrial structure
- Local resource endowment and mine characteristics
- National decarbonization and energy transition goals
#### Effects
- Uneven city fossil fuel employment intensity
- Local vulnerability to fossil fuel phase down
- Intra city labor shifts across energy types

### Pericoupling
#### Systems
- Neighboring cities within same province
- Provincial fossil fuel production and consumption systems
#### Flows
- Intra provincial coal trade and employment transfer
- Oil and gas trade within provinces
#### Agents
- Provincial governments
- State owned and regional energy enterprises
- Interlinked urban labor markets
#### Causes
- Spatial clustering of mines and consumers within provinces
- Provincial development and industrial policies
- Transport cost advantages over short distances
#### Effects
- Major intra provincial employment corridors like Dazhou Chengdu
- Employment dependence among nearby cities
- Shared provincial risks from demand declines

### Telecoupling
#### Systems
- Resource rich Chinese cities exporting fossil fuels
- Energy intensive consuming cities across China
- National and international demand drivers
#### Flows
- Intercity fossil fuel trade embodied in monetary flows
- Telecoupled employment embedded in traded fuels
- Employment driven by domestic and export final demand
#### Agents
- Fossil fuel extraction firms and workers
- Urban consumers, construction sector, exporters
- National planners and statistical agencies
#### Causes
- Uneven coal oil gas resource distribution
- City level multi regional production networks
- Domestic investment and consumption patterns
#### Effects
- Seventy percent of extraction jobs depend on other cities demand
- Net exporter and net importer employment cities emerge
- Interprovincial corridors dominate employment telecoupling

### Cross-Coupling Interactions
- Cities can simultaneously export coal employment and import oil and gas employment
- Production based and consumption based employment views give contrasting city roles
- Future energy transition scenarios will reshape intra peri and telecoupled employment

### Research Gaps or Limitations
- Incomplete coverage of small fossil fuel plants and some city energy outputs
- Only extraction stage employment analyzed; processing and transport excluded
- Monetary trade data used; physical fuel flow quantities still missing

### Search Keywords
- telecoupled employment fossil fuel trade China cities
- city level multi regional input output energy jobs
- coal oil gas extraction employment intensity spatial heterogeneity

### Extraction Confidence
high
