# Staying with the system theoretical consistency and change in Danish geographical work on the Sahel

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:03:06.901251+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Rasmussen and Nielsen - 2014 - Staying with the system theoretical consistency and change in Danish geographical work on the Sahel.pdf
- Year: unknown
- DOI: 10.1080/00167223.2013.878227
- OA status: closed
- License: none recorded
- Category: Journal Articles\Review\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This article is a scholarly review of how Danish geographic research on the Sahel has evolved, using the work of Anette Reenberg as a central reference point. The geographic focus is the Sudano-Sahelian region of West Africa (notably Burkina Faso, Niger, and Senegal), but the system context is broader debates on land systems, global change, and coupled human-environmental systems.

Methodologically, the authors conduct three linked literature reviews. First, they analyze 33 peer-reviewed Sahel studies authored or co-authored by Reenberg since 1980. Second, they review 38 research articles on the Sahel published in the Danish Journal of Geography over 1980-2012. Third, they examine five influential international papers on human-environmental systems co-authored by Reenberg. They classify articles by themes (e.g. land use, remote sensing, climate adaptation, socioeconomic geography), and by whether they follow a traditional natural-vs-social science divide or an integrated systems approach, and they trace changes over time.

The main finding is that Reenberg has maintained a consistent systems-oriented view of the Sahel as a coupled human-environmental system, while progressively opening the analysis to multiple scales, feedbacks, and drivers (biophysical, economic, political, cultural, and historical). Her empirical land-use work demonstrates that simple narratives of degradation driven by population growth and drought do not match locally complex trajectories of fields, livelihoods, and adaptation.

Within Danish geography, especially in the Danish Journal of Geography, this agenda coincides with and likely accelerates a shift: pre-2000 Sahel papers are largely disciplinary (either natural or social science), whereas post-1999 contributions almost all adopt integrated human-environment system perspectives, particularly around land use.

Internationally, Reenberg’s Sahel-based insights feed directly into conceptual developments in land change science, long-term socioecological research, and frameworks for coupled human and natural systems. These strands underpin the more recent telecoupling and metacoupling paradigms, which extend coupled-system thinking across distant places and scales. The paper is explicitly about coupled systems and telecoupling, positioning Sahel research as both a testing ground and a source of concepts for understanding globally connected land and climate change.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong focus on intracoupling within Sahel land systems, plus emerging telecoupling framing for global change.

### Intracoupling
#### Systems
- Sahelian coupled human-environmental land systems at field, village, landscape and national scales
- Agropastoral and agricultural production systems in Burkina Faso, Niger, Senegal, West Africa
- Socioecological land systems analyzed through long term socioecological research frameworks
#### Flows
- Local land use and land cover changes including field expansion and intensification
- Household livelihood adjustments, labor allocation, migration and resource access shifts
- Knowledge, perceptions, narratives and policies about degradation and climate adaptation
#### Agents
- Smallholder farmers, herders, women producers and village communities in Sudano Sahel
- National and local state institutions, extension services and development projects
- Researchers in geography, land change science, and long term socioecological research
#### Causes
- Interactions among climate variability, demographic pressure and market conditions
- State policies, tenure arrangements, social institutions, gender and ethnic relations
- Dominant environmental narratives and scientific paradigms guiding research and policy
#### Effects
- Complex, non linear land use trajectories challenging simple degradation narratives
- Differentiated vulnerability, adaptation pathways and livelihood outcomes across scales
- Shifts in Danish and international research toward integrated system based approaches

### Pericoupling
#### Systems
- Neighboring Sahel and Sudano Sahel regions linked by migration and grazing movements
- Transboundary river basin land and water management systems in West Africa
- Urban rural interfaces within West African countries influencing land and labor use
#### Flows
- Pastoral mobility, seasonal migration and cross border herd movements
- Regional trade of crops, shea products and cooking oil across Sahelian towns
- Diffusion of regional policies, development initiatives and environmental discourses
#### Agents
- Pastoral groups, traders and market intermediaries operating regionally
- River basin authorities and regional planning institutions
- NGOs and donor funded projects active across neighboring countries
#### Causes
- Climate variability and drought prompting mobility and regional adaptation
- Regional market integration and infrastructure development
- Shared colonial legacies and policy frameworks across Sahelian states
#### Effects
- Reallocation of fields, changing settlement patterns and regional land mosaics
- Cross border environmental impacts from local resource management
- Emergence of regional perspectives in Sahel land and livelihood research

### Telecoupling
#### Systems
- Sahelian land systems connected with distant urban consumption regions
- Global coupled human natural systems considered in land change science
- Telecoupled human natural systems emphasized in urban land teleconnections work
#### Flows
- International commodity and price signals affecting Sahel crops and livestock
- Development aid, projects and scientific agendas linking Sahel to global institutions
- Information, concepts and narratives on climate change, degradation and sustainability
#### Agents
- International research networks like Global Land Project and LTSER community
- Global donors, development agencies and climate adaptation programs
- Urban consumers and distant policymakers influencing land demand
#### Causes
- Globalization of markets, governance and environmental concerns
- Recognition of cross scale feedbacks in coupled human environment systems
- Emergence of telecoupling as extension of coupled systems theory
#### Effects
- Need for process based, non place bound analysis of land system change
- Sahel empirical cases informing global telecoupling and sustainability debates
- Greater attention to distant drivers in local livelihood and land use studies

### Cross-Coupling Interactions
- Local Sahel land decisions influenced by regional mobility and global market signals simultaneously
- Telecoupled research agendas reshape intracoupled Sahel studies toward multi scale system views
- Regional river basin management mediates between local practices and global environmental concerns

### Research Gaps or Limitations
- Persistent difficulty capturing cross scalar spatial and temporal linkages in Sahel systems
- Limited empirical documentation of crop land changes to robustly support policymaking
- Telecoupling concept not yet fully operationalized in Sahel empirical case analyses

### Search Keywords
- Sahel coupled human environmental systems land use adaptation
- Sudano Sahel land change socioecological and telecoupled systems
- Danish geography Reenberg long term socioecological research

### Extraction Confidence
high
