# The Coupled Human and Natural Cube A conceptual framework for analyzing urbanization and eco-enviro

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:55:03.721764+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Liu et al. - 2019 - The Coupled Human and Natural Cube A conceptual framework for analyzing urbanization and eco-enviro.pdf
- Year: unknown
- DOI: 10.11821/dlxb201908001
- OA status: unknown
- License: none recorded
- Category: Journal Articles\Conceptual\Metacoupling
- Closed-access reason: no license info, oa_status=unknown

## Copyright-Safe Summary
This conceptual paper develops a new framework, the Coupled Human and Natural Cube (CHNC), to analyze how urbanization and the eco-environment interact as a complex human-nature system. The work is grounded mainly in Chinese experience of rapid urbanization but is framed for global application. It explicitly builds on human-earth areal system theory, telecoupling and metacoupling, and planetary urbanization, interpreted through complexity science.

The authors argue that traditional urban-environment studies focus on local, synchronous, direct, and often linear relationships inside a single region, and thus poorly capture long-distance connections, time lags, hidden pathways, and multi-actor conflicts that have intensified under globalization, fast transport, and information networks. They conceptualize any regional urbanization-eco-environment system as a small cube embedded in a larger Rubik-like cube of many regions, all linked by material, energy, people, information, and capital flows (coupling lines). System evolution is described as self-organization with continual fluctuation, path dependence, thresholds, and possible phase shifts, usually staying between full order and full disorder.

CHNC decomposes couplings into four analytical dimensions, each with two types: spatial (pericoupling within a region vs telecoupling across regions and scales), temporal (syncoupling with near-simultaneous effects vs lagcoupling with delayed or path-dependent effects), appearance (apparent direct links vs hidden links mediated by other variables, flows, or virtual resources), and organization (intra-organization dynamics within one actor group vs inter-organization couplings among governments, firms, citizens, NGOs, media, etc.). Telecoupling and hidden coupling are directly aligned with metacoupling concepts; the cube explicitly integrates intra-, peri-, and tele-couplings within one scheme.

The paper outlines typical methods for each dimension (e.g., spatial econometrics, multi-region input-output, lag models, mediation analysis, multi-agent modeling) and then generalizes CHNC into a broader human-nature coupling matrix combining multiple dimensions. It is a framework paper, not an empirical study, and its main contribution to telecoupling/metacoupling is to provide a multi-dimensional, actor-aware, and time-explicit structure for diagnosing complex, multi-scale couplings and for informing more systemic sustainability and regional policy design.

## Structured Metacoupling Extraction

### Coupling Classification
- Conceptual multi-dimensional framework for intra-, peri-, and telecoupling in urbanization–environment systems

### Intracoupling
#### Systems
- Single regional urbanization–eco-environment system as one cube element
- Local subsystems like population, economy, water, land, air within a region
- Human–nature areal system inside one territorial unit
#### Flows
- Internal material recycling within a city region
- Local energy use and transformation
- Information exchange among internal subsystems
#### Agents
- Local governments and planning agencies
- Residents and local enterprises
- Sectoral departments within one administration
#### Causes
- Urban land expansion and population agglomeration
- Local industrial restructuring and consumption shifts
- Internal policy choices on growth versus protection
#### Effects
- Internal pollution and ecosystem degradation or recovery
- Changes in local resource carrying capacity
- Nonlinear internal fluctuations between order and disorder

### Pericoupling
#### Systems
- Adjacent cities within an urban agglomeration
- Neighboring upstream and downstream areas in one basin
- Regional clusters of cities sharing ecological corridors
#### Flows
- Short-distance commuting and migration between nearby cities
- Regional transport of pollutants and haze
- Inter-city exchange of goods, services, and infrastructure use
#### Agents
- Regional coordinating governments and alliances
- Firms operating across neighboring cities
- Regional environmental management bodies
#### Causes
- Functional division within city clusters
- Shared infrastructure and environmental governance
- Spillover from one localitys development strategies
#### Effects
- Spatial spillover of environmental pressures among neighbors
- Regional joint air and water quality outcomes
- Path dependence in surrounding urbanization patterns

### Telecoupling
#### Systems
- Distant sending, receiving, and spillover regions linked by urbanization
- Global urban network under planetary urbanization
- Cross-scale systems from local city to national and global levels
#### Flows
- Trade of food, energy, minerals, and virtual water
- Tourism, migration, investment, and technology transfer
- Long-range transport of pollutants like PM2.5
#### Agents
- National governments and international organizations
- Multinational corporations and global supply chains
- NGOs and transboundary advocacy networks
#### Causes
- Economic globalization and time–space compression
- Large infrastructure like interbasin water transfer projects
- International climate agreements and resource demand
#### Effects
- Remote land use change and ecosystem impacts in exporting areas
- Cross-border air pollution affecting downwind countries
- Delayed and hidden global environmental burdens via trade

### Cross-Coupling Interactions
- Combined near-far, short-long term, explicit-implicit, and intra-inter organizational couplings in one issue
- Coupling matrix integrating spatial, temporal, appearance, and organizational dimensions
- Examples like soybean trade or ecological restoration mixing tele-, lag-, hidden, and inter-organizational links

### Research Gaps or Limitations
- Traditional frameworks underrepresent long-distance, delayed, hidden, and inter-organizational couplings
- Quantitative integration of all four CHNC dimensions remains preliminary
- Need case-based modeling to operationalize the cube in policy analysis

### Search Keywords
- Coupled Human and Natural Cube urbanization eco-environment telecoupling lagcoupling
- urbanization environmental coupling hidden coupling inter-organization China
- human-nature coupling matrix planetary urbanisation complexity science

### Extraction Confidence
high
