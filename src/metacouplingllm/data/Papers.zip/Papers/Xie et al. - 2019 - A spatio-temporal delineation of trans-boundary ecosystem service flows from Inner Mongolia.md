LETTER • OPEN ACCESS

# A spatio-temporal delineation of trans-boundary ecosystem service flows from Inner Mongolia

To cite this article: Gaodi Xie et al 2019 Environ. Res. Lett. 14 065002

View the article online for updates and enhancements.

# You may also like

Effect of grain boundary on martensite transformation behaviour in Fe–32 at.%Ni bicrystals

Masato Ueda, Hiroyuki Yasuda and Yukichi Umakoshi

Grain boundary migration in Fe-3mass%Sialloy bicrystals with twist boundary

T Shibayanagi, K Ichimiya and Y Umakoshi

Ion Transport and Surface Kinetics in-Oxygen Ion Conducting Nanocrystalline Oxide Thin Films

Jiwoong Bae, Jihwan An, Young Beom Kim et al.

![](images/8685752721fd75ddefed472c07d305e0381fe0e17e43f0bc72b26ab20e460ad7.jpg)

![](images/fe102d5e77c5a9de407480c75acee67bc90dafd26b12f77416e102911aa1aca5.jpg)

# Environmental Research Letters

![](images/26ce1908daa8dfbcfce2165420cbcf4576bcb9882b4d3de660c638f5c32ce63e.jpg)

CrossMark

# OPEN ACCESS

# LETTER

# A spatio-temporal delineation of trans-boundary ecosystem service flows from Inner Mongolia

RECEIVED

25 December 2018

REVISED

1 April 2019

ACCEPTED FOR PUBLICATION

4 April 2019

PUBLISHED

24 May 2019

Original content from this work may be used under the terms of the Creative Commons Attribution 3.0 licence.

Any further distribution of this work must maintain attribution to the author(s) and the title of the work, journal citation and DOI.

![](images/c04ded5de583f2913708d6ab3f7b4c9feab0bd19f2c3a7c49c2489806997ac9e.jpg)

Gaodi Xie1,2,5 , Jingya Liu1,2,5 , Jie $\mathbf { X } \mathbf { u } ^ { 1 , 2 } \mathbb { \oplus }$ , Yu Xiao1,2 , Lin Zhen $^ { 1 , 2 } \oplus$ , Changshun Zhang1,2 , Yangyang Wang1,2 , Keyu $\mathbf { Q i n } ^ { 2 , 3 }$ , Shuang Gan1,2 and Yuan Jiang4

1 Institute of Geographic Sciences and Natural Resources Research, Chinese Academy of Sciences, A11 Datun Road, 100101 Beijing, People’s Republic of China   
2 University of Chinese Academy of Sciences, 19A Yuquan Road , Shijingshan District, Beijing 100049, People’s Republic of China   
3 Institute of Oceanology, Chinese Academy of Sciences, 7 Nanhai Road, Qingdao, Shandong 266071, People’s Republic of China   
4 Faculty of Geographical Science, Beijing Normal University, No.19, XinJieKouWai St., HaiDian District, Beijing 100875, People’s Republic of China   
5 These authors contributed equally to this work and are co-first authors.

E-mail: xuj.16b@igsnrr.ac.cn and xiaoy@igsnrr.ac.cn

Keywords: supply-demand balance, value flow, Inner Mongolia, ecosystem service flows, trans-boundary

Supplementary material for this article is available online

# Abstract

Ecosystem service (ES) flows across geophysical and administrative boundaries are ubiquitous and are receiving more attention in an increasingly metacoupled world. Omitting trans-boundary ES flows from ES assessments will lead to unilateral conclusions and underestimation of ES contributions over distances. Inner Mongolia is an important ecological security barrier of China and Eurasia, but the trans-boundary effect of this barrier is difficult to be quantitatively evaluated and is rarely assessed. This study assessed the ecological security barrier function of Inner Mongolia from the perspective of trans-boundary ES flows, including wind prevention and sand fixation (WPSF), water provision (WP), carbon sequestration (CS) and livestock product provision (LPP) service flows. The transboundary value flows for the WPSF, WP, CS and LPP services in 2010 were $6 . 2 0 \times 1 0 ^ { 1 0 }$ CNY (Chinese currency, yuan), $0 . 2 1 \times 1 0 ^ { 1 0 } \mathrm { C N Y } , 1 . 2 9 \times 1 0 ^ { 1 0 } \mathrm { C N Y }$ $1 . 2 9 \times 1 0 ^ { 1 0 } \mathrm { C N }$ and $1 . 2 7 \times 1 0 ^ { 1 0 } \mathrm { C N Y }$ , respectively, and $5 . 8 9 \times 1 0 ^ { 1 0 } \mathrm { C N Y } , 0 . 1 6 \times 1 0 ^ { 1 0 } \mathrm { C N Y } , 0 . 3 7 \times 1 0 ^ { 1 0 } \mathrm { C N Y }$ $0 . 3 7 \times 1 0 ^ { 1 0 } \mathrm { C }$ and $1 . 3 3 \times 1 0 ^ { 1 0 } \mathrm { C N Y } ,$ , respectively, in 2015; correspondingly, the percentages of these trans-boundary value flows in terms of the total value flow were $6 9 . 1 2 \%$ , $2 . 3 4 \%$ , $1 4 . 3 8 \%$ and $1 4 . 1 6 \%$ , respectively, in 2010 and $7 6 . 0 0 \%$ , $2 . 0 6 \%$ , $4 . 7 7 \%$ and $1 7 . 1 6 \%$ , respectively, in 2015. Therefore, WPSF service plays a more important role in the transboundary ecological security barrier function of Inner Mongolia. This study can enhance the understanding of trans-boundary telecoupling in an integral socio-ecological system and identify the critical ESs to form a foundation for ecological conservation measures considering sustainable development.

# 1. Introduction

Ecosystem services (ESs) are the benefits that humans derive from natural ecosystems (MA (Millennium Ecosystem Assessment) 2005). The acquisition of these benefits is not limited to local areas but often exists as a transregional phenomenon, that is, the dislocation of service providing areas (SPAs) and service benefiting areas (SBAs) in time and space. This spatio-temporal mismatch leads to the spatial flow of ESs, but this spatial flow is often ignored or underestimated in

existing ES evaluations (Pascual et al 2017). With rapid social and economic development, there is an increasing demand for ESs; the effect of ES flow is becoming increasingly obvious, and the scope of ES flow is increasing. ES flow, as an intermediate link between SPAs and SBAs, has an important impact on whether the demand for ESs can be satisfied (Burkhard et al 2012, Syrbe and Walz 2012) and is presently the focus of ESs research. Spatial mapping of ES supply and its characteristics represent incipient ES flow research, and mapping of ES supply and demand is the basis of

ES flow research (Xiao et al 2016). Considering ES flow enriches research regarding the correlation between ES supply and demand (Bagstad et al 2013, Villamagna et al 2013, Serna-Chavez et al 2014) and emphasizes the diffusion path simulation of the ES effects. Clarification of the transregional effects of ESs on human welfare can provide a direct and scientific basis for ecological environmental protection measures, interregional ecological cooperation and horizontal ecological compensation policy.

The ES flow mechanism varies among ES types (Schröter et al 2018), leading to various spatio-temporal relationships between SPAs and SBAs, such as (1) global service flow does not rely on proximity to the service, e.g. climate regulation and carbon sequestration (CS); (2) adjacent services on a local scale include all-around services (e.g. pollination) and directional services (e.g. water provision (WP) and wind prevention and sand fixation (WPSF)); and (3) services related to a user’s movement, e.g. scenery appreciation (Costanza 2008, Fisher et al 2009). Currently, there are two main understandings of ES flow (Yao et al 2018). One emphasizes the spatio-temporal connection process between the SPAs and SBAs and mainly reveals the dynamic mechanism of ES flows based on a distributed ecosystem model, such as the Artificial Intelligence for Ecosystem Services (ARIES) system constructed by the University of Vermont (Bagstad et al 2014, Bagstad et al 2016, Zank et al 2016) or the distributed hydrological model (Francesconi et al 2016, Schmalz et al 2016). The other understanding is based on the gray/black box theory, which does not consider the status and structure of the ecosystem and emphasizes only the ultimate utility and the balance between ES supply and demand (Baró et al 2016, Goldenberg et al 2017). However, regardless of the method adopted when simulating ES flows, the transregional effect should be quantitatively reflected to establish the spatio-temporal relationship between supply and demand.

Inner Mongolia is an important ecological security barrier in northern China and plays an important role in ensuring the quality of life and physical and mental health of Chinese and Northern Eurasian people (Chen et al 2018). The WPSF, WP, CS and livestock product provision (LPP) services are the main ESs of Inner Mongolia. These ESs benefit local areas and contribute to regional and global human welfare. In this research, the ecological security barrier function of Inner Mongolia was quantified by analyzing the ES flow effects of WPSF, WP, CS and LPP services based on differences in the corresponding ES flow mechanisms. This study can clarify the trans-boundary effects of ESs in Inner Mongolia and provide a scientific basis for the ES payments and ecological environmental protection measures to ensure that the ecological security barrier function of Inner Mongolia is fully utilized.

# 2. Methodology

# 2.1. Study area

Inner Mongolia is in northern China $( 3 7 ^ { \circ } 2 4 ^ { \prime } - 5 3 ^ { \circ } 2 3 ^ { \prime }$ E, $9 7 ^ { \circ } 1 2 ^ { \prime } { - } 1 2 6 ^ { \circ } 0 4 ^ { \prime } \mathrm { ~ N } )$ (figure 1(a)), with an average elevation of $1 0 0 0 \mathrm { m }$ (figure 1(c)). The total area of Inner Mongolia is $1 . 1 8 \times 1 0 ^ { 6 } \mathrm { k m } ^ { 2 }$ . The climate is dominated by a temperate continental monsoon. The river distribution in Inner Mongolia is uneven, and flows are low. From east to west, there are 12 major river basins and seven river systems (figure 1(b)), including the Erguna River, Nenjiang River, Xiliao River, Yongding River, Luanhe River, Yellow River and Inland River, in Inner Mongolia. The basic ecosystem pattern is ‘forest in the east, grass in the middle, sand in the west with grazing in the north and agriculture in the south’. Grassland is the main ecosystem type in Inner Mongolia.

# 2.2. Methods and analytical framework

From the perspective of ES flow, ESs flow from SPAs to SBAs. Therefore, the spatial scope of SPAs and SBAs should first be identified. Among the four ESs involved in this study, WP, CS and LPP services have obvious supply-demand balances, which correspond to water yield and water consumption, CS and carbon emission amount, livestock product production and consumption, respectively. For such ESs, SPAs are the regions where the supply-demand balance is positive in Inner Mongolia, and the regions where the supply-demand balance is negative both in and out of Inner Mongolia are the potential SBAs (figure 2). WPSF is a protective service and it is difficult to quantify its service demand characteristics. In addition, the flow process of WPSF service is mainly controlled by natural conditions and is basically free from human interference. Therefore, the diffusion paths and SBAs of WPSF service can be simulated only without vegetation. According to the differences in ES flow characteristics, the spatial scales of SBAs extend from the local to regional and global scale, which reflects the transregional flow of ESs. The effects of ES flows are reflected in the diffusion of physical flow and the transfer of value flow. Physical flow is the carrier of value flow. Based on the ESs valuation and physical flow of ESs, the ES value flow can provide a more direct reference for the formulation of horizontal ecological compensation policies.

As one of the most important ecological functions of natural ecosystems in arid and semiarid areas, WPSF service is conducive to the sustainable development of the regional economy and human welfare. WPSF service flow is associated with dust migration from the source region to the potential subsidence area. The physical WPSF service can be evaluated by the Revised Wind Erosion equation model from the perspective of wind erosion considering the model’s applicability (Fryrear et al 1998, Du et al 2015, Du et al 2016, Jiang et al 2016a) (table 1). The value of WPSF service was estimated by the

![](images/1d1b5b0973c2cfe1f8b5bdda3b99c192e7a5891b3689f2d696e42daea8331a8d.jpg)

![](images/607a322b1714fab8e281a00b6785ee5be561745d9b3d0b18cd5b85de5aab24c2.jpg)

![](images/a8405b12e6fde622cdcc7cb5dbe1662de7054806edfbcf75300797d80117152b.jpg)  
Figure 1. Location of the study area. (a) Map of the location of Inner Mongolia. (b) The basins and river systems of Inner Mongolia. (c) The elevation and regions adjacent to Inner Mongolia.

![](images/4907575568c85e8ccc80336485780974905c52ce886ff90fdb81d85b78abcb48.jpg)  
Figure 2. The analytical framework of the ecosystem service flow effect in Inner Mongolia.

substitute cost method (supplementary A1 is available online at stacks.iop.org/ERL/14/065002/mmedia.). The WPSF service flow is a passive process involving air flow, and the demand for this service is nonquantifiable. We evaluated the flow effect by identifying the SBAs of

the WPSF service and tracing the sand and dust transmission in the downwind direction based on the hybrid single-particle Lagrangian integrated trajectory model, which has high operability and computational efficiency (Draxler et al 2001, Escudero et al 2006).

Table 1 . Evaluation methods of related ecosystem service flow effect (supplementary A) .   

<table><tr><td>Ecosystem service type</td><td>Physical amount calculation</td><td>Value amount evaluation</td><td>Demand calculation</td><td>Ecosystem service flow</td></tr><tr><td>Wind prevention and sand fixation service</td><td>RWEQ</td><td>Substitute cost method</td><td>Passive and nonquantifiable demand</td><td>HYSPLIT</td></tr><tr><td>Water provision service</td><td>Water balance method</td><td>Market-price method</td><td>Spatialization of water consumption data based on land cover, population density and GDP density</td><td>Water flow model based on DEM</td></tr><tr><td>Carbon sequestration service</td><td>Carbon sequestration of vegetation: conversion from NPP based on Carnegie-Ames-Stanford Approach (CASA) models carbon sequestration of soil: soil organic carbon pool</td><td>Reforestation cost method</td><td>Emission coefficient method of IPCC</td><td>Supply-demand balance</td></tr><tr><td>Livestock product provision service</td><td>Conversion from NPP based on CASA models</td><td>Market-price method</td><td>Spatialization of livestock product consumption data based on population density</td><td>Supply-demand balance</td></tr></table>

WP is a typical ES with spatial mismatch between supply and demand. The water balance method is widely used in the physical calculation of WP. We estimated the water demand based on agricultural, domestic and industrial consumptive use by spatial visualization combined with population, gross domestic product and land use type distribution (Li et al 2017). The value of WP service was estimated by the market price method (supplementary A2). The WP service flow was simulated by simplifying the surface water supply of the Service Path Attribution Networks (SPANs) model (Johnson et al 2012) based on a digital elevation model and stream network data; WP service flowed from upstream to downstream after satisfying the local water consumption.

The flow mechanism of CS service is complex, and the effect is global. Few studies to date have quantified and visualized the CS service flow process. We attempted to evaluate the flow from the perspective of supplydemand balance (Li et al 2019). On the supply side, the physical CS service included the CS of vegetation and soil, which could be evaluated based on the net primary productivity (NPP) and soil organic carbon pool, respectively. The CS service was estimated by the reforestation cost method (supplementary A3). The demand of CS service could be calculated based on the emission coefficient method of the Intergovernmental Panel on Climate Change (IPCC).

LPP service is more influenced by human intervention than other services are. With the development of the economy and the diverse dietary needs of the people, the flow extent of LPP service is not restricted to the local scale but is transregional and even global due to trade (Kastner et al 2011, Xie et al 2014). The physical LPP service can be converted from NPP, and the demand calculation was based on the spatialization of livestock product consumption data. The value of LPP service was estimated by the market-price method (supplementary A4). Considering the data restriction, we estimated the LPP service flow from the perspective of supply-demand balance, which can sufficiently quantify the flow effects.

# 3. Results

# 3.1. WPSF service flow of Inner Mongolia

In 2010 and 2015, the total physical amount of WPSF service in Inner Mongolia was $7 . 8 3 \times 1 0 ^ { 1 2 } \mathrm { k g }$ and $7 . 3 7 \times 1 0 ^ { 1 2 } \mathrm { k g } ,$ respectively. The average physical amount of WPSF service per unit area was $6 . 9 0 \times 1 0 ^ { 6 } \mathrm { k g } \mathrm { k m } ^ { - 2 } \mathrm { a } ^ { - 1 }$ and $6 . { \overset { \circ } { 4 } } 0 \ \times \ 1 0 ^ { 6 } \mathrm { k g } \mathrm { k m } ^ { - 2 } { \mathrm { a } } ^ { - 1 }$ in 2010 and 2015, respectively. Correspondingly, the total value of WPSF service in Inner Mongolia was $7 . 8 3 \times 1 0 ^ { 1 0 }$ CNY in 2010 and $7 . 3 7 \times 1 0 ^ { 1 0 }$ CNY in 2015. The average value amount of WPSF service per unit area was $6 . 9 0 \times 1 0 ^ { 4 }$ $\mathrm { C N Y } \mathrm { k m } ^ { - 2 } \mathrm { a } ^ { - 1 }$ and $6 . 4 0 \times 1 0 ^ { 4 } \mathrm { C N Y } \mathrm { k m } ^ { - 2 } \mathrm { a } ^ { - 1 }$ in 2010 and 2015, respectively. In terms of spatial distribution (figure C1), the

quantity of windbreak and sand fixation per unit area in central area was high, while that in the west and northeast was low.

The spatial distribution patterns of the flow paths of WPSF service in Inner Mongolia were similar in 2010 and 2015 (figure C2), mainly passing through northeastern and northern China and extending to North Korea, South Korea, Japan, Mongolia, southeastern Russia, Alaska of the United States and a small part of the northwest Philippines. The SBAs encompassed an area of $2 8 3 2 . 7 5 \times 1 0 ^ { 4 } ~ \mathrm { k m } ^ { 2 }$ in 2010 and $3 3 4 8 . 7 2 \times 1 0 ^ { 4 } \mathrm { k m } ^ { 2 }$ in 2015, of which $2 2 . 8 7 \%$ and $1 8 . 8 3 \%$ were within China. In 2010 and 2015, the average trajectory frequency of SBAs was $1 . 1 1 \%$ and $0 . 9 1 \%$ , respectively, and the average of SBAs while that in China was $2 . 9 7 \%$ and $2 . 5 8 \%$ , respectively. The paths of the WPSF service passed through the following regions at a high frequency $( \geqslant 1 0 \%$ ): Hexi Corridor in Gansu Province, Hulunbuir in Inner Mongolia, Hunshandak Sandland and the wind erosion and desertification areas at the northern foot of Yinshan Mountain. The WPSF service of Inner Mongolia is not only conducive to alleviating the transmission of sand and dust in local wind-erosion-prone areas but also plays an important role in the prevention of sand and dust in China and neighboring countries.

The physical flow rate of WPSF service obtained locally in Inner Mongolia was $1 . 6 3 \times 1 0 ^ { 1 2 } \mathrm { k g ~ i n ~ } !$ 2010 and $\mathrm { 1 . 4 8 \times 1 0 ^ { 1 2 } k g }$ in 2015, and the value flow rate was $1 . 6 3 \times { 1 0 } ^ { 1 0 }$ CNY and $1 . 4 8 \times 1 0 ^ { 1 0 } \mathrm { C N Y }$ in 2010 and 2015, respectively. The physical flow rate of WPSF service obtained within China across the Inner Mongolia border was $4 . 3 9 \times 1 0 ^ { 1 2 } \mathrm { k g }$ in 2010 and $3 . 7 4 \times 1 0 ^ { 1 2 } \mathrm { k g }$ in 2015, corresponding to a value flow rate of $4 . 3 9 \times 1 0 ^ { 1 0 }$ CNY and $3 . 7 4 \times 1 0 ^ { 1 0 }$ CNY, respectively. The distribution of physical and value flows decreased concentrically from the central concentration (figure 3), consistent with the service transmission paths passing through the region (figure C2).

# 3.2. WP service flow of Inner Mongolia

The total physical amount of WP service in Inner Mongolia decreased from $5 . 7 0 \times 1 0 ^ { 1 0 } \mathrm { m } ^ { 3 }$ in 2010 to $3 . 7 3 \times 1 0 ^ { 1 0 } \ \mathrm { m } ^ { 3 }$ in 2015, and the total value was $0 . 5 1 \times 1 0 ^ { 1 0 }$ CNY and $0 . 3 4 \times 1 0 ^ { 1 0 } \mathrm { C N Y }$ , respectively. The spatial distribution pattern was higher in the northeast and lower in the southwest (figure C3, table D). In 2010 and 2015, the dynamic water surplus in Inner Mongolia was $1 3 . 6 0 \times 1 0 ^ { 1 2 } \mathrm { m } ^ { 3 }$ and $7 . 2 6 \times 1 0 ^ { 1 2 }$ $\mathrm { m } ^ { 3 }$ , respectively. The spatial heterogeneity of the dynamic water surplus in Inner Mongolia was significant: high in the east and low in the west (figure 4).

In 2010, the physical inflow of WP service in Inner Mongolia was $0 . 4 7 \times 1 0 ^ { 1 0 } \mathrm { m } ^ { 3 }$ , and the physical outflow was $2 . 8 2 \times 1 0 ^ { 1 0 } ~ \mathrm { m } ^ { 3 }$ , corresponding to a value inflow of $0 . 4 2 \times 1 0 ^ { 9 }$ CNY and a value outflow of $2 . 5 3 \times 1 0 ^ { 9 } \mathrm { C N Y }$ , respectively. In 2015, Inner Mongolia had a physical inflow of $0 . 2 0 \times 1 0 ^ { 1 0 } \mathrm { m } ^ { 3 }$ and a physical

![](images/1ee0ef6a2943316b5264e438a00db8fcb6c696481651a6d70b2a1d5d01b8e4e1.jpg)

![](images/789d1f0f78cd764caed7cff86fbda73513b577374ea7d1350b876c27ae36ac4d.jpg)

![](images/1173ea93aa7956bce9c17ebb30b1ea7a936306a09d703e7e3f1d1cac3b3dbe44.jpg)

![](images/ab177f963c03d0150f44e28f0efe05bec8dc461226c7402df76f4f312a3a7646.jpg)  
Figure 3. Flow effect of wind prevention and sand fixation service in Inner Mongolia’s SBAs in 2010 and 2015. The figures labeled with a suffix a and b represent physical flow and value flow of wind prevention and sand fixation service in Inner Mongolia in 2010 and 2015, respectively.

![](images/ba5355b2587047b13dd58913b48207c19df40bdc620241b2a89965b087febaf2.jpg)

![](images/3a288f8754507841017b220bd9779bdbb3942c05aef6000b0fb47862bc8eeb26.jpg)  
Figure 4. Dynamic surplus and potential flow paths of water provision service in 2010 and 2015.

outflow of $1 . 7 8 \times 1 0 ^ { 1 0 } ~ \mathrm { m } ^ { 3 }$ , corresponding to a value inflow of $0 . 1 8 \times 1 0 ^ { 9 }$ CNY and a value outflow of $1 . 6 0 \times 1 0 ^ { 9 } \mathrm { C N Y }$ , respectively. Overall, Inner Mongolia was a supply area of WP service. In 2010, except for the Inland River Basin west of the Yellow River,

Lanzhou to Hekou and the Interior Basin, the amount of water transferred from Inner Mongolia was much greater than that from each river basin (figure C4, supplementary D). In 2015, the transregional effect of WP service in Inner Mongolia was similar to that in 2010,

![](images/77d8ed3e0249c9e24c8a9e97d2fe3cd24cd585496b8c02a3d3f0b4e738c165b6.jpg)

![](images/d411deb330c87d677ac7f0996ae42afcb32b602cb10aad072f1ff98279d858d9.jpg)  
Figure 5. The supply-demand balance and potential flow paths of carbon sequestration service in Inner Mongolia’s adjacent province/city in 2010 and 2015.

but the WP service from Lanzhou to Hekou was greatly reduced, which led to the physical flow from Lanzhou to Hekou being smaller than that from Inner Mongolia in 2015.

# 3.3. CS service flow of Inner Mongolia

In 2010 and 2015, the total carbon sequestered in Inner Mongolia was $1 8 . 0 5 \times 1 0 ^ { 1 0 } \mathrm { k g }$ and $1 8 . 8 4 \times$ $1 0 ^ { 1 0 } \mathrm { k g } ,$ , respectively, of which, the $\mathrm { C S 1 3 . 7 2 \times 1 0 ^ { 1 0 } k g }$ and $1 4 . 5 1 \times 1 0 ^ { 1 0 } \mathrm { k g }$ was sequestered in vegetation, respectively, $4 . 3 3 \times 1 0 ^ { 1 1 } \mathrm { k g }$ was sequestered in soil (in both years). The total value of CS service was $4 . 7 1 \times 1 0 ^ { 1 0 }$ CNY in 2010 and $4 . 9 2 \times 1 0 ^ { 1 0 }$ CNY in 2015. The spatial distribution of the total CS service was similar to that of vegetation CS service, decreasing from northeast to southwest (figure C5). In 2010 and 2015, the total demand for CS service in Inner Mongolia was $1 2 . 8 8 \times 1 0 ^ { 1 0 } \mathrm { k g }$ and $1 7 . 4 3 \times 1 0 ^ { 1 0 } \mathrm { k g } ,$ respectively, which was mainly concentrated in densely populated urban areas. The supply-demand balance of CS service in Inner Mongolia was $4 . 9 5 \times 1 0 ^ { 1 0 } \mathrm { k g }$ in 2010 and $1 . 1 8 \times 1 0 ^ { 1 0 } \mathrm { k g }$ in 2015, reflecting a the supply area of CS service overall.

The demand for CS service in surrounding urban areas of Inner Mongolia was in short supply (figure 5), including the potential SBAs of CS service, especially the demand gap in the Beijing-Tianjin-Hebei urban agglomeration. At the provincial and municipal scales, the supply-demand balance of CS service in Hebei, Shanxi, Liaoning, Tianjin, Ningxia and Beijing were all negative in 2010 and 2015; in 2010, the demand gaps in each province/city were $^ { 1 4 . 9 6 \times 1 0 ^ { 1 0 } \mathrm { k g } , }$ $7 . 5 2 \times 1 0 ^ { 1 0 } \mathrm { k g } ,$ $^ { 7 . 0 8 } \times 1 0 ^ { 1 0 } \mathrm { k g } ,$ $4 . 1 0 \times 1 0 ^ { 1 0 } \mathrm { k g } ,$ $2 . 6 7 \times 1 0 ^ { 1 0 } \mathrm { k g }$ and $1 . 4 7 \times 1 0 ^ { 1 0 } \mathrm { k g } ,$ respectively; in 2015, the demand gaps increased to $1 6 . 0 0 \times 1 0 ^ { 1 0 } \mathrm { k g } ,$ $1 2 . 3 2 \times 1 0 ^ { 1 0 } \mathrm { k g } ,$ $9 . 4 2 \times 1 0 ^ { 1 0 } \mathrm { k g } ,$ $7 . 2 2 \times 1 0 ^ { 1 0 } \mathrm { k g } ,$ $2 . 9 0 \times 1 0 ^ { 1 0 } \mathrm { k g }$ and $2 . 8 5 \times 1 0 ^ { 1 0 } \mathrm { k g } ,$ , respectively.

# 3.4. LPP service flow of Inner Mongolia

The provision of livestock products in Inner Mongolia increased from $8 . 9 2 \times 1 0 ^ { 8 } \mathrm { k g } \mathrm { i n } 2 0 1 0$ to $9 . 2 6 \times 1 0 ^ { 8 } \mathrm { k g }$ in 2015, and the demand for livestock products increased from $6 . 7 4 \times 1 0 ^ { 6 } \mathrm { k g } \mathrm { i n } 2 0 1 0$ to $1 . 1 8 \times 1 0 ^ { 7 } \mathrm { k g }$ in 2015, leading to a $3 . 1 1 \%$ increase in the balance of livestock products from $8 . 8 5 \times 1 0 ^ { 8 } \mathrm { k g }$ to $9 . 1 2 \times 1 0 ^ { 8 } \mathrm { k g }$ . In 2010 and 2015, the values of LPP service were $1 . 2 8 \times 1 0 ^ { 1 0 }$ CNY and $1 . 3 5 \times 1 0 ^ { 1 0 } \mathrm { C N Y } ,$ respectively. The supply-demand balance of LPP service in 2010 and 2015 was lower in the east and higher in the west (figure C6). The supply-demand balance of LPP service in Inner Mongolia resulted in a deficit in only a few regions, and most other areas had a surplus of livestock products. Therefore, Inner Mongolia as a whole was a supply area of LPP service.

In 2010 and 2015, the local physical flow of LPP service was $0 . 6 7 \times 1 0 ^ { 7 } \mathrm { k g }$ and $1 . 1 8 \times 1 0 ^ { 7 } \mathrm { k g } ,$ respectively, and the corresponding local value flow in Inner Mongolia was $0 . 0 1 \times 1 0 ^ { 1 0 }$ CNY and $0 . 0 2 \times 1 0 ^ { 1 0 }$ CNY, respectively. The transregional physical flow of LPP service was $8 . 8 5 \times 1 0 ^ { 8 } \mathrm { k g }$ and $9 . 1 4 \times 1 0 ^ { 8 } \mathrm { k g }$ with a transregional value flow of $1 . 2 7 \times 1 0 ^ { 1 0 }$ CNY and $1 . 3 3 \times 1 0 ^ { 1 0 } \mathrm { C N Y }$ in 2010 and 2015, respectively. The SBAs were concentrated in central Northeast China, North China and the Guanzhong regions (figure 6). The LPP service mainly flowed from the sparse shrubs and grasslands in the east and the forests and grasslands in the central areas of Inner Mongolia to the SBAs.

# 3.5. Combined effects of ES flow of Inner Mongolia

Based on the regional effects of WPSF, WP, CS and LPP service in Inner Mongolia (table 2), the total ES local value flow within Inner Mongolia was $5 . 3 6 \times 1 0 ^ { 1 0 }$ CNY in 2010 and $6 . 2 1 \times 1 0 ^ { \mathrm { i 0 } }$ CNY in 2015, which accounted for $3 7 . 4 0 \%$ and $4 5 . 5 6 \%$ of the total ES value, respectively (figure 7). In terms of the individual ES type, the local effect of CS service was the

![](images/bacfb1877b4d0a8ff6e106ed46c3d82dcecd7b16770654ea206b1624e7cd9533.jpg)

![](images/53641296355abc00e5ebbccba12d0afb35a70a369abae15e563e484dc2f4434e.jpg)  
Figure 6. The supply-demand balance and potential flow paths of livestock product provision service in Inner Mongolia in 2010 and 2015.

most significant, accounting for $7 1 . 3 4 \%$ and $9 2 . 4 8 \%$ of the total CS service values in 2010 and 2015, respectively. In 2010 and 2015, the total transregional ES value flow in Inner Mongolia was $8 . 9 7 \times 1 0 ^ { 1 0 } \mathrm { C N Y }$ and $7 . 7 5 \times 1 0 ^ { 1 0 }$ CNY, respectively, accounting for $6 2 . 6 0 \%$ and $5 5 . 4 4 \%$ of the total value flow in that year. The transregional effects of LPP service were the most significant, accounting for $9 9 . 2 2 \%$ and $9 8 . 5 2 \%$ of the total LPP service flow in 2010 and 2015, respectively. Overall, among the total local value flows, the percentage of the local value flow of CS service was $6 3 . 8 1 \%$ in 2010 and $7 3 . 0 3 \%$ in 2015. In terms of all four ESs, the transregional flow effects of the WPSF service cover the largest percentage of all transregional value flows, accounting for $6 9 . 1 2 \%$ in 2010 and $7 6 . 0 0 \%$ i n 2015. Therefore, the ecological security barrier function of Inner Mongolia is mainly attributed to CS service at the local scale and WPSF service at the transregional scale. The improvement of ESs in Inner Mongolia can strengthen the local ecological environment and play an important role as a barrier to the ecological environment outside the region, especially the ecological security of surrounding large urban agglomerations.

# 4. Discussion and conclusions

This study reflects the various mechanisms of ES flows. For Inner Mongolia, the ES flows of WPSF, WP, CS and LPP extend from local to trans-boundary scales, while the degree of trans-boundary flows varies. ES flows are driven by both natural and human factors, such as natural ecology and social economy, leading to the spatiotemporal changes in ES supply and demand. The relationship between these factors are complex and

interactive (Schröter et al 2018). WPSF is a typical example of passive ES flow, which is more influenced by natural conditions (e.g. wind speed and precipitation) and clearly changes with the season (Xu et al 2018). The provision of WP, CS and LPP service are more affected by the climate and vegetation, while their demand is basically driven by human needs and preferences.

The initial research on ES flows mainly focused on the identification of beneficiaries and quantified the supply and demand of ESs individually (Burkhard et al 2012). To forbid the segmentation of the supply and demand of ES, recent studies have attempted to reveal multi-dimensional supply-demand mismatches (Wei et al 2017). In increasingly metacoupled social-ecological systems, trans-boundary ES flows over distances are becoming more common and aim to link humannature interactions in a more comprehensive way (Liu et al 2017). Liu et al (2016) established an integrated telecoupling framework to analyze the causes, effects, agents, and dynamics of ES flows and applied the framework to China’s South–North Water Transfer Project. This framework proved the transregional effect of ES flows and the necessity of a more holistic assessment of socio-economic and environmental interactions over distances. Many studies evaluated the spatial pattern and impacts of distant virtual material flows embodied in the products and services (e.g. water, energy, land, $\mathrm { C O } _ { 2 } ;$ , and nitrogen) (Feng et al 2013, Duan et al 2018, Xu et al 2019b) but did not emphasize the contribution of ES flow. Xu et al (2019a) assessed the temporal evolution and interactions of virtual material and financial capital flows by comparing the trade between adjacent and distant countries, consistent with the cross-border physical and value flow perspective in this research. Schröter et al (2018) also stressed interregional ES flows by

Table 2. The effect of ecosystem service flow in Inner Mongolia.   

<table><tr><td>Ecosystem service type</td><td>Year</td><td>Total physical amount</td><td>Total value amount/1010 CNY</td><td>Local physical flow</td><td>Local value flow/1010 CNY</td><td>Transregional physical flow</td><td>Transregional value flow/1010 CNY</td></tr><tr><td rowspan="2">Wind Prevention and Sand Fixation Service</td><td>2010</td><td>7.83 × 1012 kg</td><td>7.83</td><td>1.63 × 1012 kg</td><td>1.63</td><td>6.20 × 1012 kg</td><td>6.2</td></tr><tr><td>2015</td><td>7.37 × 1012 kg</td><td>7.37</td><td>1.48 × 1012 kg</td><td>1.48</td><td>5.89 × 1012 kg</td><td>5.89</td></tr><tr><td rowspan="2">Water Provision Service</td><td>2010</td><td>5.70 × 1010 m3</td><td>0.51</td><td>3.35 × 1010 m3</td><td>0.30</td><td>2.35 × 1010 m3</td><td>0.21</td></tr><tr><td>2015</td><td>3.73 × 1010 m3</td><td>0.34</td><td>1.98 × 1010 m3</td><td>0.18</td><td>1.75 × 1010 m3</td><td>0.16</td></tr><tr><td rowspan="2">Carbon Sequestration Service</td><td>2010</td><td>1.81 × 1011 kg</td><td>4.71</td><td>12.88 × 1010 kg</td><td>3.42</td><td>4.95 × 1010 kg</td><td>1.29</td></tr><tr><td>2015</td><td>1.88 × 1011 kg</td><td>4.92</td><td>17.43 × 1010 kg</td><td>4.55</td><td>1.18 × 1010 kg</td><td>0.37</td></tr><tr><td rowspan="2">Livestock Product Provision Service</td><td>2010</td><td>8.92 × × 108 kg</td><td>1.28</td><td>0.67 × 107 kg</td><td>0.01</td><td>8.85 × 108 kg</td><td>1.27</td></tr><tr><td>2015</td><td>9.26 × 108 kg</td><td>1.35</td><td>1.18 × 107 kg</td><td>0.02</td><td>9.14 × 108 kg</td><td>1.33</td></tr></table>

![](images/af8199d3ac6b3b23206a581b182b3a4ddcf62e56c086b20b7940a386a9c60bf1.jpg)  
Figure 7. The local and transregional effect of ecosystem service flow in Inner Mongolia.

constructing a conceptual framework between the sending and receiving system of an ES. However, there is a lack of a spatio-temporal delineation of transboundary ES flows in a certain study area.

This study addresses the research gap in the mapping of various ES flows in a certain region. The analysis framework can be applied directly to the corresponding ES flow simulation in other areas. The supply-demand balance approach is more suitable for ESs that have obvious supply-demand relationships and for which the flow mechanism remains uncertain. This method is based on the gray/black box theory. ES flows with specific movement mechanisms, such as water and sand transport, should be better evaluated by the corresponding distributed ecosystem model. This research did not consider the stakeholders’ intervention to the ES flow process or the seasonal variation in the supply, demand and flow paths. It is still challenging to quantify the complex interactions over space and time and among various stakeholders.

The trans-boundary ES flows have broad implications in the decision-making process, including ES management, sustainable development, land use policy, and payments for ESs (PES) not only for Inner Mongolia and China but also for any other regions worldwide. Due to population growth and economic development, demands for ESs are rapidly increasing, often beyond the supply capacity of the ecosystem; additionally, a gradual decline in certain ESs is occurring. In this case, the ES flow process is conducive to coordinating the relationship between supply and demand for a specific spatiotemporal location. ESs are the foundation of sustainable development. With globalization acceleration, transregional trading of goods, information interchange and population mobility are becoming increasingly common. Simultaneously, ESs are incorporated into the flow process by connecting SPAs and SBAs. Therefore, the sustainability of one region is not restricted to the local

scale but is also closely related to the region’s SPAs and ES flow process. Evaluating the regional sustainable development level by incorporating the ES flows can avoid unilateralism (Schröter et al 2018) and is conducive to balancing the ecological deficit, especially in an urban agglomeration. Simultaneously, ES flows and land use changes are highly interlinked. There exists competition and tradeoff between different ES in terms of land use patterns. In addition, interregional dependencies reflect the ES flow and make transregional ecological cooperation necessary. In this study, we analyzed the ES effect from the physical and value perspectives. The value flow is both the development opportunity cost of the SPAs and the receiving benefit of the SBAs. ES valuation provides an indispensable reference for stakeholder decision-making. To maintain the interregional development balance and guarantee the sustainable supply of ES, financial flows across regions occur and should be equal to the ES value flow (Boerema et al 2016), including PES and ecological engineering construction. Therefore, the ES flow can enhance understanding and promote the policy-making process in a more telecoupled world (Liu et al 2016).

# ORCIDiDs

Jie Xu $\textcircled{1}$ https://orcid.org/0000-0001-9725-1444 Lin Zhen $\textcircled{1}$ https://orcid.org/0000-0001-6227-4697

