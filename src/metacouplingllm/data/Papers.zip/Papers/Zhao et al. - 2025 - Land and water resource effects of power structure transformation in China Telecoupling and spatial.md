# Land and water resource effects of power structure transformation in China Telecoupling and spatial

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:20:47.567900+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Zhao et al. - 2025 - Land and water resource effects of power structure transformation in China Telecoupling and spatial.pdf
- Year: unknown
- DOI: 10.1016/j.jenvman.2025.127347
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This article examines how transforming Chinas power generation mix affects land and water use, and how these effects are redistributed across provinces through telecoupled electricity trade. The study focuses on domestic linkages within China, treating electricity flows as a key channel of spatial interaction.

The authors build an environmentally extended multiregional input-output (EE-MRIO) model for 31 provinces and 49 sectors, explicitly splitting electricity production into six technologies (coal, hydro, nuclear, wind, solar, biomass). They couple the 2017 MRIO table to satellite accounts for land and water footprints per unit of electricity, then simulate future conditions under two policy pathways aligned with national carbon peaking (CAP, 2030) and carbon neutrality (CAN, 2060) targets.

For 2017, electricity demand is estimated to require about 138,000 km2 of land and 64 billion m3 of water. Land footprints concentrate in coastal industrial and central agricultural provinces, while water footprints peak in coal-based power hubs, particularly in water-stressed basins and northwestern dry regions. Interprovincial electricity trade yields strong telecoupling: provinces such as Guangdong and Beijing outsource more than 60 percent of their electricity-related land and water demand to inland, resource-rich regions, creating a pattern of coastal consumption and inland ecological burden. Power generation and supply dominate national footprints, whereas service-oriented economies shift a larger share of land and water use into tertiary sectors.

Scenario analysis reveals a key trade-off. The CAP pathway, focused on more efficient coal, slightly lowers land footprints but raises water demand. The CAN pathway, driven by large-scale renewables, cuts water use markedly yet causes a very large rise in land occupation, concentrated in high-resource western provinces such as Tibet and Qinghai. The paper is explicitly framed within the telecoupling/metacoupling perspective by tracing virtual flows of land and water embodied in electricity and highlighting cross-regional responsibility, ecological zoning needs, and compensation mechanisms to align decarbonization with land and water conservation.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong domestic telecoupling via interprovincial electricity trade and virtual land water footprints
- Intracoupling within China between power mix, land, water, and regional economies
- Pericoupling among neighboring provinces sharing power grids and resource footprints

### Intracoupling
#### Systems
- Chinese provincial power system structure and operation
- Provincial land and water resource bases
- Regional industrial and service sector economies
#### Flows
- Local electricity production and consumption within provinces
- Embedded land footprint in provincial electricity demand
- Embedded water footprint in provincial electricity demand
#### Agents
- Provincial governments and regulators
- Power generation and grid enterprises
- Industrial and service sector electricity users
#### Causes
- National dual carbon targets reshaping power structure
- Shift from coal power to renewable technologies
- Provincial differences in economic structure and resource endowment
#### Effects
- Spatially uneven land and water pressures within China
- High footprints in industrial coastal and agricultural heartland provinces
- Sectoral differences in resource footprints across provinces

### Pericoupling
#### Systems
- Neighboring coastal and inland provincial power grids
- Adjacent provinces sharing river basins and arid regions
- Regional clusters of coal bases and renewable energy bases
#### Flows
- Interprovincial electricity trade among neighboring provinces
- Virtual land and water transfer along short grid connections
- Cross-border movement of energy intensive industries
#### Agents
- Regional grid operators and dispatch centers
- Neighboring provincial planning and resource agencies
- Industrial firms relocating across nearby provinces
#### Causes
- Regional comparative advantages in coal, water, wind, and solar
- Infrastructure driven power exchanges between contiguous provinces
- Policies promoting regional industrial upgrading and relocation
#### Effects
- Coastal consumption inland burden intensified near borders
- Localized water stress in arid neighboring regions
- Land use conflicts from clustered renewable projects

### Telecoupling
#### Systems
- Electricity importing coastal megacity provinces
- Electricity exporting inland coal and renewable bases
- Nationally integrated multi regional power and resource system
#### Flows
- Long distance power transfers from inland to coastal provinces
- Virtual land and water exports embedded in traded electricity
- Ecological responsibility shifted from consumers to producers
#### Agents
- State grid and large power companies
- Central and provincial energy and resource planners
- National level policymakers designing dual carbon pathways
#### Causes
- Spatial mismatch of energy resources, land, water, and demand centers
- Decarbonization scenarios altering technology mix and locations
- Economic growth and service sector expansion in coastal regions
#### Effects
- Over 60 percent footprints outsourced by some coastal provinces
- Resource rich western and northern regions bear ecological burdens
- Trade offs between water saving and land expansion under scenarios

### Cross-Coupling Interactions
- Scenario shifts change telecoupled footprints while reshaping intracoupled sectoral impacts
- Coastal demand drives inland land and water use despite local service oriented economies
- Renewable expansion relocates land pressure from coal regions to high resource western areas

### Research Gaps or Limitations
- Single year IO table limits temporal dynamics of transitions
- International electricity and technology trade not modeled in resource flows
- Land use policy constraints like farmland protection not embedded in simulations

### Search Keywords
- China telecoupling electricity land footprint water footprint EE MRIO
- power structure transition dual carbon interprovincial virtual resource trade
- renewable energy expansion coastal consumption inland burden spatial redistribution

### Extraction Confidence
high
