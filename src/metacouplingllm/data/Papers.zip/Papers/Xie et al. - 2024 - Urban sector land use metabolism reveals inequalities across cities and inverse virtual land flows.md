# Urban sector land use metabolism reveals inequalities across cities and inverse virtual land flows

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:12:11.976116+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Xie et al. - 2024 - Urban sector land use metabolism reveals inequalities across cities and inverse virtual land flows.pdf
- Year: unknown
- DOI: 10.1016/j.resconrec.2023.107394
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines how urban land tied to economic sectors is used and traded within and beyond the Jing-Jin-Ji (Beijing-Tianjin-Hebei) urban agglomeration in northern China, and how these flows reflect telecoupled and metacoupled relationships.

The authors build a spatially explicit inventory of urban, non-agricultural land for 42 sectors (later grouped into 30) across 13 cities for 2013. They use a Land Use Estimation Model combining crowdsourced point-of-interest data, remote sensing land cover, and other geospatial datasets to map sectoral land occupation. This inventory is linked to a city-level multi-regional input-output table through an environmentally extended input-output analysis, converting monetary flows into virtual land flows and consumption-based land footprints. Ecological network analysis is then applied to the intercity virtual land network to identify control, exploitation, and benefit-cost relationships.

The study finds highly uneven and clustered urban land use, dominated by Beijing and Tianjin, with strong differences among sectors. Roughly 40 percent of economic urban land is driven by non-local demand, indicating substantial telecoupling through supply chains. Cities with higher income levels have lower land-use intensity and gain more economic value per unit of land, while many Hebei cities supply land-intensive activities with weaker returns. Urban residents have much larger land footprints per capita than rural residents, reinforcing urban-rural inequality.

At the regional scale, Jing-Jin-Ji is a net exporter of embodied urban land to other Chinese regions and to foreign markets, mainly via services and manufacturing. These flows run opposite to virtual agricultural land flows, which move into the region to satisfy food demand. Within the agglomeration, Beijing and Tianjin sit at the core of the virtual land network, acting as main beneficiaries and control centers, while several surrounding cities supply land-intensive functions. The paper explicitly addresses telecoupling and metacoupling by tracing distant, intercity, and intra-city linkages and highlighting how urban land metabolism embeds asymmetric benefits and responsibilities in regional development.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong intracoupling of sectoral urban land metabolism within Jing Jin Ji cities
- Pericoupling among neighboring Chinese provinces via interprovincial virtual land trade
- Telecoupling through exports of embodied urban land from Jing Jin Ji to foreign regions

### Intracoupling
#### Systems
- Urban economic sectors within individual Jing Jin Ji cities
- City level land use, consumption, and industrial structure
- Intra city networks of services, manufacturing, utilities, and construction
#### Flows
- Direct urban land occupation by 30 economic sectors
- Embodied land use driven by local final demand categories
- Virtual land reallocation among industries within each city
#### Agents
- Municipal governments planning land and industry layout
- Urban households and rural residents consuming goods and services
- Firms in manufacturing, services, mining, transport and utilities
#### Causes
- Urbanization and industrialization concentrating activities on limited urban land
- Differences in sectoral land productivity and value added
- Local demand for infrastructure, housing, and services
#### Effects
- Spatial clustering of industrial and service land hotspots
- Large inequalities in land use intensity and per capita footprints
- Lock in of high impact urban land patterns via path dependence

### Pericoupling
#### Systems
- Jing Jin Ji urban agglomeration as a regional system
- Neighboring provinces such as Hebei, Shandong, Henan, Inner Mongolia
- Suburban versus central urban zones surrounding core cities
#### Flows
- Intercity virtual land flows along regional supply chains
- Embodied land trade between Jing Jin Ji and nearby provinces
- Inverse flows between urban industrial land and imported agricultural land
#### Agents
- Regional planners coordinating Jing Jin Ji integration
- Provincial governments managing cross border trade and industry
- Regional industrial and logistics enterprises
#### Causes
- Regional division of labor between high tech cores and industrial periphery
- Comparative land scarcity and differential land values across provinces
- Infrastructure and transport corridors enabling regional trade
#### Effects
- Beijing and Tianjin emerge as regional land benefit hubs
- Hebei cities bear higher land burdens with lower economic returns
- Spatial autocorrelation of virtual land flows around the agglomeration

### Telecoupling
#### Systems
- Jing Jin Ji region as sending and receiving system
- Other Chinese provinces as interconnected distant systems
- Foreign trading partners importing embodied urban land
#### Flows
- Exports of virtual urban land in manufactured and service products
- Imports of virtual agricultural land from distant regions
- Two way embodied land exchange forming inverse land flow patterns
#### Agents
- National government shaping trade and regional development policies
- Export oriented firms in services and heavy manufacturing
- Domestic and foreign consumers driving remote land demand
#### Causes
- Globalization of supply chains for urban centered production
- Final demand outside Jing Jin Ji for industrial and service outputs
- Economic specialization of cities versus agricultural hinterlands
#### Effects
- Jing Jin Ji becomes net exporter of embodied urban land nationally
- Highly urbanized cities capture excess economic gains from remote land
- Unequal distribution of land related environmental pressures across China

### Cross-Coupling Interactions
- Regional virtual land network links intracity metabolism with interregional and international trade
- Beijing and Tianjin simultaneously net importers regionally and net exporters nationally
- Mining and manufacturing land externally driven while services mainly support local demand

### Research Gaps or Limitations
- Agriculture and forestry land excluded, limiting full land system representation
- Analysis restricted to single year snapshot without temporal trends
- Foreign virtual land imports not quantified due to data gaps

### Search Keywords
- urban land metabolism Jing Jin Ji telecoupling
- virtual land flows ecological network analysis China
- land use inequality regional supply chains

### Extraction Confidence
high
