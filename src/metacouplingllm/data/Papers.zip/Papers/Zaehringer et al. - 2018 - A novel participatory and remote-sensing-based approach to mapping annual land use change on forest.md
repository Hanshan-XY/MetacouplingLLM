# A novel participatory and remote-sensing-based approach to mapping annual land use change on forest

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:17:38.738992+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Zaehringer et al. - 2018 - A novel participatory and remote-sensing-based approach to mapping annual land use change on forest.pdf
- Year: unknown
- DOI: 10.1080/1747423X.2018.1447033
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Methodological\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This methodological paper presents a new way to reconstruct annual land use change at forest frontiers, where land systems are rapidly transforming under global and regional pressures. The study focuses on smallholder-dominated landscapes in humid tropical forest frontiers of Laos, Myanmar, and Madagascar, all of which are strongly affected by distant demand for commodities (rubber, oil palm, banana, sugarcane, cloves, vanilla, coffee) and by conservation initiatives.

The authors work at village-to-landscape scale (roughly 1,400 to 7,200 ha per case), within eight case study landscapes bordering or near protected areas and commercial agriculture. They combine very-high-resolution satellite imagery (mainly Pléiades) with local knowledge collected through village workshops and extensive field walks. First, they segment recent imagery into homogeneous polygons and visually assign current land use. Then, through participatory mapping, villagers correct boundaries and categories, identify past land uses for different landscape sections, and date transitions using local reference events and, where available, global forest loss data. Field walks with GPS and photos refine plot-level histories. All information is transferred to a GIS, producing an annual land use map for each year from 2000 onward (1990 in Myanmar) and time series of land use shares.

The resulting datasets provide spatially explicit, annually resolved land use trajectories and reveal both gradual and abrupt land system regime shifts, such as the replacement of shifting cultivation by mixed and monoculture plantations in Myanmar, or rapid cycles of rice-to-banana-to-sugarcane in Laos driven by Chinese investment and national policy changes. The approach explicitly addresses telecoupling and metacoupling by linking local land system changes to distant commodity markets, investment flows, national laws, and conservation policies. It is not a general telecoupling framework paper, but a method tailored to support empirical analysis of telecoupled land-use decisions and their impacts on social-ecological systems, and to inform future participatory land-use planning.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong focus on local land use change within globally telecoupled forest frontiers.

### Intracoupling
#### Systems
- Village level social ecological systems in Laos, Myanmar, Madagascar forest frontiers.
- Local land systems such as shifting cultivation, paddy rice, mixed plantations.
- Protected areas and adjacent smallholder agricultural landscapes.
#### Flows
- Local flows of land, labor, food, forest products within villages.
- Local ecosystem services such as biodiversity, carbon storage, water regulation.
- Village level information sharing and social learning on land use history.
#### Agents
- Smallholder farmers and village authorities.
- Local conservation managers and protected area staff.
- Village level workshop and field walk participants.
#### Causes
- Population pressure and subsistence rice demand.
- Local land allocation, zoning, and resettlement policies.
- Village responses to perceived land scarcity and soil degradation.
#### Effects
- Regime shifts between shifting cultivation, permanent agriculture, plantations.
- Loss or maintenance of local forest cover and ecosystem services.
- Changes in local livelihoods and land tenure security.

### Pericoupling
#### Systems
- Neighboring villages sharing or contesting land parcels.
- Village landscapes bordering national parks and reserves.
- District or provincial scale agricultural frontiers.
#### Flows
- Expansion of agriculture into nearby forest and protected zones.
- Short distance trade of cash crops and timber to regional towns.
- Spread of land use practices across adjacent communities.
#### Agents
- District officials and land use planners.
- Protected area authorities interacting with surrounding villages.
- Regional traders and intermediaries.
#### Causes
- Regional infrastructure such as roads, gas pipelines, market access.
- Establishment or expansion of nearby protected areas.
- Regional development and conservation discourses.
#### Effects
- Agricultural encroachment on adjacent forests and reserves.
- Spatial clustering of plantations and paddy fields across landscapes.
- Rising land conflicts and boundary uncertainties between villages.

### Telecoupling
#### Systems
- Forest frontier landscapes in Laos, Myanmar, Madagascar as sending and receiving systems.
- Distant consumer markets in China, Europe, global North.
- International conservation networks and donors.
#### Flows
- Global demand driven trade in rubber, oil palm, banana, sugarcane, cloves, vanilla, coffee.
- Foreign direct investment from China, Thailand, international companies.
- Telecoupled policy ideas, conservation agendas, and land governance models.
#### Agents
- Chinese, Thai, Burmese, and other external agribusiness investors.
- International conservation NGOs and global environmental programs.
- National governments shaping land, forest, and farmland laws.
#### Causes
- Rising global commodity prices and changing consumer preferences.
- Foreign investment policies and regional trade agreements.
- Global climate, biodiversity, and carbon conservation initiatives.
#### Effects
- Conversion of shifting cultivation to rubber, oil palm, mixed cash crops.
- Telecoupled land system regime shifts and irreversible landscape transformations.
- Intensified trade offs between agricultural production and biodiversity conservation.

### Cross-Coupling Interactions
- Telecoupled commodity demand reshapes regional investments and local land use decisions.
- Protected areas funded internationally alter village scale land options and frontier dynamics.
- National policy reforms mediate external investments, triggering local regime shifts.

### Research Gaps or Limitations
- Approach limited to relatively small, accessible landscapes due to time intensive fieldwork.
- No full accuracy assessment for past land use due to missing historical high resolution imagery.
- Participatory data biased by power relations, gender exclusion, and research fatigue.

### Search Keywords
- participatory mapping telecoupling forest frontiers Laos Myanmar Madagascar
- annual land use trajectories regime shifts remote sensing Pléiades
- global commodity crops rubber oil palm banana cloves vanilla

### Extraction Confidence
high
