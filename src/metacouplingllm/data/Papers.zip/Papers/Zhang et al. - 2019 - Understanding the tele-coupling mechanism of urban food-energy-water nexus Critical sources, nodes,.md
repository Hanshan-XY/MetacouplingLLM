# Understanding the tele-coupling mechanism of urban food-energy-water nexus Critical sources, nodes,

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:18:20.273054+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Zhang et al. - 2019 - Understanding the tele-coupling mechanism of urban food-energy-water nexus Critical sources, nodes,.pdf
- Year: unknown
- DOI: 10.1016/j.jclepro.2019.06.232
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines how a major citys demand for food, energy, and water (FEW) is supplied through distant economic linkages, providing a clear telecoupling perspective. The case is Beijing, China, in 2010, situated within the national economic and resource system.

The authors couple a China-wide multi-regional input-output (MRIO) model with structural path analysis (SPA). The MRIO table covers 30 provinces and 30 economic sectors; FEW satellite accounts are compiled from national and provincial statistics on agricultural production, energy use, and water withdrawals. The model traces embodied FEW use along supply chains driven by Beijings final demand, identifying (1) total FEW footprints, (2) main supplying regions, (3) critical supply-chain paths, and (4) key sectors (nodes) that strongly shape urban FEW impacts.

Results show that Beijing depends heavily on other provinces for embodied resources: about two-thirds of its food footprint, over half of its energy footprint, and more than four-fifths of its water footprint arise outside the municipal boundary. Direct imports of grain, energy, and transferred water further reinforce this dependence. The principal supplying regions are nearby provinces Hebei, Inner Mongolia, Jiangsu, Anhui, and Shandong, which together provide a large share of Beijings FEW needs but themselves face severe water scarcity and environmental stress.

Critical supply chains differ by resource. Food and water flows are dominated by agriculture and food-processing sectors in multiple provinces, while energy flows are largely tied to construction and services in Beijing that indirectly pull in coal, petrochemical, metal, and non-metal products from surrounding regions. SPA reveals a small set of key nodes, such as non-metal manufacturing in Hebei, coal mining in Inner Mongolia, and petroleum-related sectors in Heilongjiang, through which many FEW flows pass.

The paper explicitly addresses telecoupling and metacoupling: it characterizes flows between an urban core and its hinterlands, highlights asymmetric benefits and burdens, and argues for coordinated cross-regional governance and supply-chain interventions to secure urban FEW provision while reducing pressures on source regions.

## Structured Metacoupling Extraction

### Coupling Classification
- Explicit telecoupling of Beijing with domestic hinterland FEW suppliers via trade and supply chains

### Intracoupling
#### Systems
- Urban Beijing FEW subsystems and economic sectors
- Internal city FEW interactions across services, construction, industry
#### Flows
- Direct and embodied FEW use within Beijing sectors
- Internal FEW linkages among services, food industry, construction
#### Agents
- Beijing municipal government and planners
- Urban producers and service providers
- Urban households and final consumers
#### Causes
- Urbanization and rising Beijing FEW demand
- Sector based governance ignoring nexus linkages
- Economic growth of services, construction, transport
#### Effects
- High urban FEW footprints concentrated in a few sectors
- Strong internal dependence on service driven demand
- Potential unintended cross sector FEW trade offs

### Pericoupling
#### Systems
- Beijing and neighboring provinces like Hebei, Inner Mongolia
- Regional FEW production bases near Beijing
#### Flows
- Embodied food from nearby agricultural provinces
- Construction related energy and materials from surrounding regions
#### Agents
- Provincial governments around Beijing
- Regional agricultural and industrial producers
- Interprovincial traders and logistics firms
#### Causes
- Proximity driven sourcing of FEW resources
- Beijing land and water scarcity pushing regional imports
- Regional specialization in agriculture and heavy industry
#### Effects
- Concentrated FEW burden on neighboring provinces
- Local water stress and land degradation near Beijing
- Need for coordinated regional FEW governance

### Telecoupling
#### Systems
- Beijing as consuming hub within national FEW network
- Distant supplying provinces such as Xinjiang, Heilongjiang, Guangdong
#### Flows
- Virtual water in crops and food from arid distant regions
- Embodied energy in heavy industrial products and fuels
- Multi layer FEW flows traced along national supply chains
#### Agents
- National government coordinating cross regional policies
- MRIO and SPA modelers revealing distant linkages
- Enterprises participating in long supply chains
#### Causes
- Nationwide trade connecting city demand to distant FEW sources
- Economic integration and specialization across provinces
- Urban outsourcing of resource intensive production
#### Effects
- Shifted environmental pressures to distant water scarce regions
- Vulnerability of Beijing to disruptions in key supplying nodes
- Need for telecoupled FEW governance and shared responsibilities

### Cross-Coupling Interactions
- Urban demand simultaneously drives coupled food, energy, water flows along shared supply chains
- Key industrial nodes control multiple FEW types and influence many regions
- Policy in one sector or region can reallocate FEW burdens across the network

### Research Gaps or Limitations
- Relies on 2010 MRIO; temporal dynamics and newer data not captured
- Limited resolution for intra urban processes and distributional aspects
- Focus on domestic teleconnections; international FEW linkages not modeled

### Search Keywords
- urban food energy water nexus telecoupling Beijing MRIO SPA
- embodied resources supply chains key FEW nodes China
- virtual water energy flows regional FEW governance

### Extraction Confidence
high
