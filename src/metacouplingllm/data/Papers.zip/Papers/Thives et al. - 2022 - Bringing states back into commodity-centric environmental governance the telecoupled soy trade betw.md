# Bringing states back into commodity-centric environmental governance the telecoupled soy trade betw

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:08:41.093363+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Thives et al. - 2022 - Bringing states back into commodity-centric environmental governance the telecoupled soy trade betw.pdf
- Year: unknown
- DOI: 10.1080/01436597.2022.2081144
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This article examines how the international soy trade between Brazil and China is governed, emphasizing the often-overlooked role of states in a field dominated in research by private, voluntary initiatives. The geographic focus is the Brazil-China corridor, with Brazil as the main sending system of soy and China as the principal receiving system. The authors explicitly frame this as a telecoupled relationship: distant but tightly linked socio-environmental systems connected through commodity, financial, and information flows.

Methodologically, the study combines analysis of official diplomatic documents and minutes (especially within the China-Brazil High-Level Coordination and Cooperation Committee, COSBAN), joint action plans and a ten-year plan, multilateral statements under BASIC, BRICS, and G-77 + China, archival research in Brazil’s foreign ministry, interviews, and environmental/deforestation data from the Trase database, complemented by secondary literature.

Empirically, the paper shows that Chinese demand has become the dominant driver of Brazilian soy expansion, with major land-use impacts in the Amazon, Cerrado, and frontier regions like MATOPIBA. Although deforestation per ton of soy fell during the late 2000s, weakening of Brazilian environmental regulation and amnesties for illegal land grabbing have renewed deforestation risks, especially from 2014 onward. Socio-environmental impacts include biodiversity loss, land conflicts, inequitable local development, water cycle disruption, and agrochemical exposure.

The authors contrast robust multilateral environmental rhetoric by Brazil and China (on climate, biodiversity, forests, and sustainable development) with a bilateral agenda that largely sidelines environmental issues. Environmental ministries are absent from COSBAN and key bilateral mechanisms, and environmental cooperation is limited mainly to a climate and energy technology center and scattered references to renewables. This creates a governance gap in managing the telecoupled soy system.

The article is directly about telecoupling/metacoupling. It argues that overemphasis on private governance obscures the central regulatory role of states and warns that China’s growing share of Brazilian soy imports, without strong public sustainability requirements, risks regulatory leakage that undermines emerging deforestation controls elsewhere.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via Brazil China soy trade with weak associated bilateral environmental governance

### Intracoupling
#### Systems
- Brazilian soy frontier regions such as Amazon and Cerrado
- Domestic Brazilian governance and agribusiness policy arena
#### Flows
- Soy expansion into frontier lands for national and export markets
- Domestic political support and subsidies for agribusiness
#### Agents
- Brazilian federal and state governments and agencies
- Brazilian agribusiness firms and producer lobbies
- Brazilian civil society and local communities
#### Causes
- Commodity boom and agribusiness political influence
- Relaxation and weakening of Brazilian environmental regulations
#### Effects
- Deforestation dynamics and regulatory rollbacks
- Local inequality, land conflicts, and agrochemical exposure
- Shifts in land use and water cycle impacts

### Pericoupling
#### Systems
- Brazil soy regions trading with European Union
- Brazil soy regions trading with domestic Brazilian market
#### Flows
- Soy exports from Brazil to European Union
- Brazilian domestic soy supply chains
#### Agents
- Multinational grain traders operating in Brazil
- European buyers imposing zero deforestation requirements
#### Causes
- European due diligence and sustainability campaigns
- Trader commitments covering all sourcing regions
#### Effects
- Lower deforestation risk in soy for European Union
- Spillover of private zero deforestation rules into other markets

### Telecoupling
#### Systems
- Brazil as soy sending system and deforestation hotspot
- China as soy receiving system concerned with food security
- Global environmental governance arena influencing both countries
#### Flows
- Massive soy shipments Brazil to China plus capital and machinery flows
- Embodied deforestation, GHG emissions, biodiversity and water impacts
- Information flows through agreements, market signals, and NGO campaigns
#### Agents
- Chinese and Brazilian national governments and diplomatic bodies
- Chinese state owned and private grain traders such as COFCO
- Multilateral coalitions like BRICS, BASIC, G77 plus NGOs and researchers
#### Causes
- Rapid growth in Chinese demand for soy feed and oil
- Brazilian comparative advantages and agricultural technology improvements
- Trade oriented foreign policy prioritizing commodity exports
#### Effects
- Telecoupled deforestation and socio environmental risks concentrated in Brazil
- Contribution to global GHG emissions and biodiversity loss
- Economic gains with uneven local development and social displacement

### Cross-Coupling Interactions
- European private standards indirectly shape Brazilian soy supplied to China via company wide sourcing
- Multilateral climate commitments contrast with weak bilateral environmental provisions
- Chinese demand amplifies impacts of Brazilian domestic deregulation

### Research Gaps or Limitations
- Limited analysis of concrete outcomes from China Brazil Climate Center projects
- Sparse attention to bilateral environmental cooperation in telecoupling literature
- Few civil society linkages constraining bottom up oversight across the dyad

### Search Keywords
- Brazil China soy telecoupling governance
- commodity centric environmental governance states role
- soy trade deforestation regulatory leakage

### Extraction Confidence
high
