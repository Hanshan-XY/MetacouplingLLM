# Distant regions underpin interregional flows of cultural ecosystem services provided by birds and ma

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:04:50.008154+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Schroeter et al. - 2020 - Distant regions underpin interregional flows of cultural ecosystem services provided by birds and ma.pdf
- Year: unknown
- DOI: 10.1007/s13280-019-01261-3
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This paper examines how distant ecosystems support cultural ecosystem services enjoyed in Europe, focusing on two services: existence and bequest values of wild species, and birdwatching. The geographic focus is on Germany and the Netherlands as receiving regions, while sending regions are identified globally.

The authors first identify service-providing species for each cultural service. For existence and bequest, they extract bird and mammal species highlighted in annual reports of major conservation NGOs in each country. For birdwatching, they select the most frequently recorded bird species from large online observation databases (eBird for Germany, waarneming.nl for the Netherlands). Species distribution ranges from BirdLife International and the IUCN Red List are then used to map where these species occur worldwide.

Interregional flows are inferred where species ranges lie entirely or seasonally outside the receiving countries (with a buffer for birdwatching). Overlapping ranges are aggregated on a 100 x 100 km grid to delineate global hotspots of sending regions. The authors characterize these hotspots by biome, level of human pressure (human footprint), protection status, and national income (GDP per capita), and compare them to global averages.

More than half of the species that matter for birdwatching, and about half for existence and bequest, depend on habitats located far from Germany and the Netherlands. Key sending hotspots are concentrated in tropical and subtropical grasslands, savannas, and shrublands, with additional contributions from boreal and temperate systems, especially for the Dutch case. These hotspots are generally poorer and more heavily impacted by humans than the global mean, and their formal protection coverage is mixed, with German-linked hotspots slightly better protected than those linked to the Netherlands.

The study is explicitly framed in a telecoupling/metacoupling perspective: it quantifies non-material flows from distant ecosystems to European beneficiaries, shows that these flows rest on threatened and low-income regions, and highlights resulting equity and conservation implications for sustaining cultural ecosystem services through international cooperation.

## Structured Metacoupling Extraction

### Coupling Classification
- Study focuses on interregional and distant links, mainly telecoupling of cultural ecosystem services.

### Intracoupling
#### Systems
- Not identified.
#### Flows
- Not identified.
#### Agents
- Not identified.
#### Causes
- Not identified.
#### Effects
- Not identified.

### Pericoupling
#### Systems
- Neighboring European regions linked to Germany via migratory flyways
- Neighboring European regions linked to Netherlands via migratory flyways
#### Flows
- Seasonal bird movements within broader European flyways
- Information and values shared via European conservation policies
#### Agents
- European Union environmental institutions
- Regional conservation NGOs in Europe
#### Causes
- Shared migratory routes across nearby European countries
- EU habitat and bird protection directives
#### Effects
- Regional coordination of bird conservation along flyways
- Shared responsibility for nearby migratory bird habitats

### Telecoupling
#### Systems
- Receiving regions: Germany and Netherlands as service beneficiaries
- Sending regions: African, Asian, boreal and marine habitats of birds and mammals
- Global tropical and subtropical grasslands, savannas, shrublands as cultural ES providers
#### Flows
- Cultural ecosystem services: existence and bequest values of distant species
- Cultural ecosystem services: birdwatching supported by migratory birds
- Information flows through conservation reports and online bird observation platforms
#### Agents
- National and international conservation NGOs in Germany and Netherlands
- Citizen scientists contributing bird observations online
- International conservation bodies managing protected areas and datasets
#### Causes
- Public appreciation of charismatic and migratory species in wealthy countries
- Global migratory bird flyways connecting Europe with Africa and Eurasia
- Limited local biodiversity and strong interest in wildlife in receiving countries
#### Effects
- Dependence of European cultural benefits on distant, often poorer ecosystems
- Conservation burdens and land use pressures concentrated in remote sending regions
- Equity concerns due to poorer, high-impact hotspots supporting rich-country cultural services

### Cross-Coupling Interactions
- Human footprint and land use change in sending regions threaten telecoupled cultural services in Europe
- Protected areas and NGO projects in distant regions help sustain European cultural ecosystem flows
- Climate and environmental changes in distant hotspots may alter bird migration and observation opportunities

### Research Gaps or Limitations
- Does not quantify actual bird abundance or individual movement between regions
- Relies on coarse species range maps likely overestimating true occupied area
- Excludes intensity of information flows and many cultural practices beyond birds and mammals

### Search Keywords
- telecoupling cultural ecosystem services birds mammals Germany Netherlands
- interregional ecosystem service flows migratory birds existence bequest birdwatching
- sending regions hotspots human footprint GDP conservation equity

### Extraction Confidence
high
