# Climate change, tropical fisheries and prospects for sustainable development

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:50:53.123548+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Lam et al. - 2020 - Climate change, tropical fisheries and prospects for sustainable development.pdf
- Year: unknown
- DOI: 10.1038/s43017-020-0071-9
- OA status: green
- License: other-oa
- Category: Journal Articles\Review\Telecoupling
- Closed-access reason: green OA without permissive license (other-oa)

## Copyright-Safe Summary
This review examines how climate change is reshaping tropical marine fisheries and the implications for sustainable development and distant regions linked through telecoupling. The focus is global but centers on tropical exclusive economic zones between the Tropics of Cancer and Capricorn, and on their economic and nutritional connections to extratropical countries via trade, distant-water fleets, and fishmeal-based aquaculture.

The authors synthesize evidence from oceanography, ecology, fishery models, socioeconomics, and case studies (Pacific Island countries and territories, Brazil, and African coastal states). They draw heavily on IPCC scenarios (RCP2.6 and RCP8.5), ensemble ecosystem and fisheries models, reconstructed catch data, and trade statistics.

Projected physical and biogeochemical changes in tropical oceans include strong surface warming, more frequent marine heatwaves, increasing stratification, deoxygenation, acidification, and sea-level rise. These changes reduce primary productivity, damage key habitats such as coral reefs, mangroves, and seagrasses, and alter fish physiology, size, and distributions. Ensemble models suggest substantial declines in tropical marine animal biomass and maximum catch potential, with losses up to about 40 percent in some tropical EEZs by mid-century under high emissions, and pronounced species turnover.

Socioeconomic analyses indicate that revenues and employment from fisheries will decline most in low-income tropical countries that depend heavily on fish for nutrition and livelihoods and have limited adaptive capacity, including many small island developing states and parts of Africa and Asia. Climate impacts also threaten tropical mariculture potential.

Telecoupling is a core theme: climate-driven reductions in tropical fisheries will reverberate through global seafood supply chains, affecting high-value tuna exports, fishmeal supplies for extratropical aquaculture (for example, Peruvian anchoveta and farmed salmon), distant-water fishing arrangements, and processing industries in temperate countries. The paper explicitly applies telecoupling concepts to these distant but linked human-natural systems.

The authors highlight adaptation options (ecosystem-based, infrastructure, and governance reforms; community-based management; flexible regional tuna governance) and emphasize that stringent emission mitigation consistent with limiting warming to 1.5 C would avoid many of the most severe biological and socioeconomic impacts.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling between tropical fisheries and extratropical economies via trade and distant-water fleets

### Intracoupling
#### Systems
- Tropical coastal socioecological systems reliant on wild marine fisheries
- National EEZ fisheries in small island developing states
- Tropical marine ecosystems including coral reefs, mangroves, seagrasses
#### Flows
- Fish biomass and catch within national EEZs
- Nutritional benefits and micronutrients to local populations
- Domestic fisheries revenue, employment and cultural services
#### Agents
- Small-scale fishers and coastal communities
- Domestic industrial fishing fleets and processors
- National fisheries agencies and community institutions
#### Causes
- Ocean warming, acidification, deoxygenation and sea-level rise
- Overfishing, habitat degradation, pollution and invasive species
- Limited fisheries governance capacity and rapid population growth
#### Effects
- Reduced biomass, body size and catch potential of tropical stocks
- Loss and degradation of coral reefs, mangroves and seagrasses
- Increased vulnerability to food insecurity, poverty and job losses

### Pericoupling
#### Systems
- Neighboring tropical countries sharing regional marine ecosystems
- Transboundary tuna stocks across Pacific Island EEZs
- Regional fish trade hubs in West Africa, Southeast Asia, Caribbean
#### Flows
- Migrating fish populations across adjacent EEZ boundaries
- Regional seafood trade and license fee revenues
- Knowledge, technology and management practices among neighbors
#### Agents
- Regional fisheries management organizations and commissions
- Artisanal and industrial fleets operating in nearby EEZs
- Regional economic communities and policy bodies
#### Causes
- Climate-driven species redistribution and local extinctions
- Variable governance and enforcement across neighboring states
- Fuel subsidies and regional access agreements shaping effort
#### Effects
- Shifts in national revenue shares from shared tuna resources
- Potential conflicts over transboundary stocks and access rights
- Uneven progress toward food security and development goals

### Telecoupling
#### Systems
- Tropical fisheries economies in SIDS, Africa, Asia, Latin America
- Extratropical seafood markets in Europe, North America, East Asia
- Global aquaculture systems dependent on fishmeal and fish oil
#### Flows
- Exports of high-value tropical tuna and other seafood
- Exports of small pelagics for reduction to fishmeal and oil
- Distant-water fishing effort and associated license payments
#### Agents
- Distant-water fleets from developed nations, including Asia and Europe
- International seafood trading companies and processors
- Extratropical consumers and aquaculture feed manufacturers
#### Causes
- Global demand and willingness to pay for seafood products
- Climate-induced declines in tropical catch and species shifts
- Subsidy policies and international trade regulations
#### Effects
- Reduced seafood supply and higher risk for importing countries
- Exposure of extratropical jobs and industries to tropical climate impacts
- Feedbacks on tropical governance through external policy changes

### Cross-Coupling Interactions
- Climate-driven stock shifts alter intracoupled livelihoods and telecoupled trade simultaneously
- Distant-water fleet policies impact both local tropical ecosystems and foreign processing jobs
- Fishmeal supply variability telecouples tropical small pelagics with extratropical aquaculture growth

### Research Gaps or Limitations
- Uncertain projections for deoxygenation, productivity and regional catch responses
- Limited understanding of social adaptation, conflict and equity in telecoupled systems
- Need for integrated models spanning biophysical change, governance and global supply chains

### Search Keywords
- tropical fisheries climate change telecoupling
- tuna trade distant-water fishing SDGs
- fishmeal Peruvian anchoveta aquaculture

### Extraction Confidence
high
