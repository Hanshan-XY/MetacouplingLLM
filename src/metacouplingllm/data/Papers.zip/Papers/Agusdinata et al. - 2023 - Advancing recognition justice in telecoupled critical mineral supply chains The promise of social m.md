# Advancing recognition justice in telecoupled critical mineral supply chains The promise of social m

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:27:01.151600+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Agusdinata et al. - 2023 - Advancing recognition justice in telecoupled critical mineral supply chains The promise of social m.pdf
- Year: unknown
- DOI: 10.1016/j.erss.2023.103264
- OA status: green
- License: cc-by-nc-nd
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This paper examines how social media can help address recognition justice issues in telecoupled critical mineral supply chains, focusing on lithium extraction in Chile’s Salar de Atacama. The study is explicitly framed within the telecoupling literature and contributes to metacoupling debates by analyzing immaterial information flows that connect distant mining regions (receiving systems) with consumers and institutions that drive demand for low-carbon technologies (sending systems).

Geographically, the work centers on northern Chile but tracks Twitter communication globally from 2015 to mid-2020. The system context is lithium mining for electric vehicles and other low-carbon technologies, with particular attention to water scarcity, ecosystem impacts, and indigenous livelihoods in one of the driest places on earth.

The authors compile tweets using a bilingual (Spanish-English) query targeting Atacama- and mining-related environmental and social concerns, excluding specific corporate names. They collect about 1,700 georeferenced “local” tweets within 600 km of Atacama and over 71,000 “global” tweets. Using NLP tools, they preprocess text, conduct sentiment analysis with a multilingual transformer model, run n-gram frequency analysis, and perform network analysis (Gephi) on user interactions. They also classify users into actor types (individuals, NGOs, media, government, companies, IGOs).

Results show that water and mining dominate discussions, with frequent associations to scarcity, contamination, and service cuts. Negative sentiment is especially strong where “mining” and “water” co-occur. Networks are sparse overall but contain dense clusters in which a few highly connected users (notably news outlets, NGOs, and some individual and indigenous-representative accounts) act as communicative hubs and bridges. Most geographically tagged activity is within Chile, especially near mining areas and major cities, with limited but visible international participation.

The paper concludes that social media, while uneven and potentially biased, can function as a “return flow” in telecoupled systems, making local harms more visible to distant publics and influential organizations. This enhances opportunities for recognition justice, though evidence of direct effects on distributive or procedural justice remains limited and is identified as a key area for future research.

## Structured Metacoupling Extraction

### Coupling Classification
- Primarily telecoupling in global lithium supply chains, with some intracoupling and limited pericoupling aspects.

### Intracoupling
#### Systems
- Salar de Atacama socioecological system in northern Chile
- Chilean national governance and protest landscape
#### Flows
- Groundwater extraction and competition within Atacama basin
- Local Twitter communication about mining and water
#### Agents
- Indigenous Atacamenos communities and local residents
- Mining companies operating lithium brine fields
- Chilean government agencies and local NGOs
#### Causes
- National water and mining laws granting extraction rights
- Expansion of lithium operations in hyperarid ecosystem
- Domestic conflicts over water rights and environmental protection
#### Effects
- Water scarcity and ecosystem degradation near salt flats and wetlands
- Local protests, social mobilization and constitutional reform debates
- Growing online discourse on mining, water cuts and contamination

### Pericoupling
#### Systems
- Atacama mining region and nearby Chilean cities like Antofagasta
- Chilean administrative capital and regional media networks
#### Flows
- Domestic news coverage on lithium and water conflicts
- Policy debates on water rights and mining regulation
#### Agents
- Chilean news outlets and journalists
- National NGOs and social movements
- Regional and central government bodies
#### Causes
- Visibility of mining impacts on tourism and rural livelihoods
- Nationwide protests over inequality and resource governance
#### Effects
- Amendments to water legislation and debates on lithium nationalization
- Increased domestic information flows linking mining regions and cities

### Telecoupling
#### Systems
- Lithium extraction landscapes in Chile as receiving systems
- EV and battery-consuming countries in Global North as sending systems
- Global social media and news ecosystem as spillover system
#### Flows
- Material flows of lithium and other critical minerals to technology manufacturers
- Immaterial flows of tweets, sentiments, narratives on mining impacts
- Financial investments and corporate supply-chain relations across continents
#### Agents
- Automotive and renewable energy firms demanding lithium
- International NGOs, IGOs and foreign individuals engaging on Twitter
- News media amplifying Atacama mining and water stories
#### Causes
- Rising global demand for EVs and low-carbon technologies
- Information asymmetries between distant consumers and mining communities
- Power imbalances embedded in global supply-chain governance
#### Effects
- Redistribution of environmental burdens to indigenous and rural communities
- Partial recognition of water and environmental harms in global discourse
- Potential pressure for more just mineral governance and responsible sourcing

### Cross-Coupling Interactions
- Local Twitter messages form return information flows from receiving to sending systems.
- Domestic media and NGOs bridge local grievances into global online networks.
- Telecoupled recognition dynamics influence national debates on mining and water policy.

### Research Gaps or Limitations
- Limited georeferenced tweets restrict robust mapping of local-to-global information pathways.
- Twitter users are a narrow, potentially unrepresentative subset of affected populations.
- Study tracks recognition signals but not concrete changes in distributive or procedural justice.

### Search Keywords
- telecoupling lithium Atacama social media recognition justice
- critical minerals EV supply chains water conflict Chile
- Twitter mining impacts information flows environmental justice

### Extraction Confidence
high
