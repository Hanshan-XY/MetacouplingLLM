Synthesis

# Telecoupling visualizations through a network lens: a systematic review

Gabi Sonderegger 1,2, Christoph Oberlack 1,2, Jorge C. Llopis 1,2, Peter H. Verburg 3,4 and Andreas Heinimann 1,2

ABSTRACT. Telecoupling is an integrative social-ecological framework that has made important contributions to understanding land change processes in a hyperconnected world. Visualizations are a powerful tool to communicate knowledge about telecoupling phenomena. However, little is known about current practices of telecoupling visualization and the challenges involved in visually displaying connections between multiple social-ecological systems. Our research takes stock of existing telecoupling visualizations and provides recommendations for improving current practices. We systematically review 118 visualizations presented in the scientific literature on telecoupling, and assess them in terms of their content and the adopted visualization approaches. To this end, we conceptualize telecoupling visualizations through a network lens. We find that they typically present networks of social-ecological systems, which are linked through flows. Displays of telecoupling connections through actor networks or action situation networks are less frequent. We categorize the existing visualizations into seven main types, which differ in terms of the visual encoding strategies used to represent telecoupling components. We then draw on insights from data visualization literature to reflect critically upon these current practices and provide practical recommendations. Finally, we show that network perspectives are inherent in telecoupling research and visualizations, and may deserve further attention in this field.

Key Words: connectivity; data visualization; human-environment interactions; social-ecological systems; telecoupling; visual communication

# INTRODUCTION

Causes and consequences of land use changes are closely tied to distant places (Lambin and Meyfroidt 2011). The telecoupling framework aims to provide a holistic understanding of land use changes that captures distant linkages between social-ecological systems (Liu et al. 2013, Eakin et al. 2014). In recent years, there has been a boom in research on telecoupling phenomena, covering a wide range of subjects and bridging scientific efforts from various disciplines (Kapsar et al. 2019). Visualizations are a common means to depict, analyze, and communicate knowledge about telecoupled land systems (see, e.g., the telecoupling toolbox, Tonini and Liu 2017, McCord et al. 2018). They are particularly valuable and powerful in the context of intangible research subjects, e.g., those dealing with cross-scale issues or abstract concepts (McInerny et al. 2014). Visuals can support researchers in the process of exploring their data (Fox and Hendler 2011), helping them to unravel the human-environmental dynamics within and across systems. Furthermore, visual communication allows the sharing of knowledge in a more accessible, tangible, and memorable way than text sources (Rodriguez and Dimitrova 2011). It can thus facilitate cross-disciplinary exchange and coproduction of scientific knowledge, as well as communication with a nonscientific audience (Grainger et al. 2016). Despite their many advantages, visualizations also bear risks and limitations. All visual communications are selective in terms of the data they present or leave out (Tversky 2011). They can introduce biases through decontextualization or oversimplification of the subject, or through low quality data inputs (Dörk et al. 2013, Boehnert 2015). The production of informative and unbiased visualizations can thus be challenging, but also bring about fundamental gains for the generation and communication of scientific knowledge.

A telecoupling understanding of land use change implies the study of multiple social-ecological systems, and essentially the

connections between them. Applying this more holistic lens to land use phenomena brings about particular visualization needs, which go beyond those commonly addressed in land system-based research, e.g., through land use maps. Despite these potential challenges and the important role of visualizations in telecoupling research, little systematic knowledge and guidance is available on existing visualization practices in this field. Addressing this knowledge gap is key to making full use of the potentials that visualizations can offer. Telecoupling research can thus benefit from a critical reflection of existing visualizations, including the contents they represent (or leave out) and the visualization approaches used to portray telecoupling dynamics. Therefore, the objective of this study is to provide insights into a better understanding of the current practices of telecoupling visualization. We further aim to identify key visualization challenges in this field and provide recommendations for improving current practice. We will do so by systematically reviewing visualizations presented in telecoupling publications and thereby drawing on insights from data visualization and network analysis literature.

# MATERIALS AND METHODS

# Key concepts and analytical framework

Data visualization, data representation, and visual encoding Kirk (2016:19) defines data visualization as the “representation and presentation of data to facilitate understanding.” This definition refers to two consecutive steps in the visualization process. Data representation is the process of converting data to graphical form. It defines the basic structure of the visualization and is shaped by the content that is to be visually displayed. Data presentation concerns more detailed design choices, e.g., on the use of color schemes or annotations (Kirk 2016). In this study,

![](images/4a564c68dc2443f969df3807134652159a3abd8ead0e21eeb470aa3fdefb99c0.jpg)  
Fig. 1. A selection of visual mark and attribute encodings. Source: Authors, adapted from Iliinsky and Steele (2011) and Kirk (2016).

![](images/192f1ceb443ec48f94e0ef720032e25cecfe563a26ad90b085815890bc572c3a.jpg)

we focus on data representation, as we aim to gain insights into the way specific content, i.e., telecoupling information, is visualized.

A common approach to data representation is to select predefined visualization techniques such as bar charts or sankey diagrams to visualize the available data. A more elaborate approach is visual encoding (Kirk 2016, Healy 2018). It involves the translation of data into a combination of marks and attributes (see Fig. 1 for examples thereof). Marks include basic graphical elements such as points, lines, areas, or forms (Munzner 2014). Attributes (also called channels) define the appearance of marks, e.g., through color or size variations and respective labeling. For example, in a bar chart, the bars constitute the marks and the length of the bars the attributes. A large spectrum of attributes exist, as first outlined by Bertin (1983). Figure 1 presents a nonexhaustive list of visual attributes, with an indication of the related suitable data types (see Iliinsky and Steele 2011, Munzner 2014, Kirk 2016 for more options). Spatial data is an additional data type to consider, which is usually represented through spatially explicit marks, e.g., on maps.

# Telecoupling: a network perspective

Several approaches to telecoupling analysis have been suggested (Friis et al. 2016). Liu et al. (2013) define telecoupling in terms of sending, receiving, and spillover systems that are connected through flows of material, information, and energy. Furthermore, they identify different system components, namely agents, causes, and effects. Other authors have further elaborated on this systemflow-based understanding of globalized land use phenomena by explicitly drawing attention to the role of governance structures and the underlying actor networks in a telecoupling context (Eakin et al. 2014, 2017, Lenschow et al. 2016, Oberlack et al. 2018, Munroe et al. 2019).

A network approach has been gaining prominence in telecoupling research (Seaquist et al. 2014, Prell et al. 2017, Schaffer-Smith et al. 2018, Andriamihaja et al. 2019), and areas of synergy have been proposed for network-related concepts and tools (Seaquist and Johansson 2019, Sayles et al. 2019). The basic components of networks are nodes and links. They can differ largely in terms

of the content and the level of aggregation they represent (Bodin et al. 2019). Nodes can, for example, represent people in a social network or countries in a trade network. Similarly, links can indicate friendships between people or commodity flows between countries. In this sense, telecoupled phenomena can also be viewed as networks, for example, with social-ecological systems as nodes and flows as links (see Fig. 2). Nodes and links can thus

![](images/75399acfc52c88a4c4bc9d1f16a073a37edb24f786580bb708593caf82ac7d3b.jpg)  
Fig. 2. (a) Node-link structure of networks. (b) Network examples: actor networks and networks of social-ecological systems. Source: Authors, inspired by Barabási (2016).

![](images/f1c067a73391e12805c437712d2f1b9c71ef3ca44b55aec6829ad9ec410087e2.jpg)

![](images/5066aba5a942428af9f7d4c44c38e3032530db59f7e4b40b2817d3b31ca7c73d.jpg)

Fig. 3. Publication and case selection process.

<table><tr><td colspan="3">Publication selection phase</td></tr><tr><td>Publication identification process
• Web search in Scopus &amp; Web of Science
  ○ Keyword search (in title, abstract, keywords): telecoupl* OR &quot;tele-coupl&quot;
○ Date of search: April 8th 2019
• Manual search for additional publications:
○ Book chapters of telecoupling books
○ Source cross-check with other telecoupling literature reviews</td><td>Publication search criteria
• Publication date: January 2009 - present
• Thematic focus: Telecoupling
• Language: English</td><td>Results
Web of Science: 104 publications
Scopus: 111 publications
Manual search: 22 publications</td></tr><tr><td>Publication selection process
• Screening of potential publications and publication exclusion according to criteria.</td><td>Publication selection criteria
Exclusion criteria:
• No visualizations present (13 excluded)
• Main text body not in English (2 excluded)
• Different use of telecoupling term (2 excluded)</td><td>137 potential publications, after duplicate check.</td></tr></table>

<table><tr><td colspan="3">Case (i.e. visualization) selection phase</td></tr><tr><td>Case identification process
·Identification of all potential cases within the selected publications.</td><td>Case identification criteria
General rule:
·Each figure presented in the selected publications (and labelled accordingly) classifies as one potential case.
Exception:
·If a figure contains multiple graphs that have different visual designs and fulfil the inclusion criteria below, they can be classified as separate cases (applied once)</td><td>Results
495 potential cases, present in the 120 selected publications.</td></tr><tr><td>Case selection process
·Content-scanning of all potential cases (incl. data collection on information presented in all potential cases)
·Selection of cases based according to criteria.</td><td>Case selection criteria
Inclusion criteria:
·Visualization content: telecoupling connections
·Type of information visualized: empirical, case-specific information
Exclusion criteria:
·Duplication within source (9 excluded)
·Duplication across sources (3 excluded)</td><td>Results
118 selected cases, presented in 62 publications.</td></tr></table>

represent an array of phenomena. Borgatti et al. (2009, 2018) identify four basic types of links in social networks: flows (e.g., information flows); interactions (e.g., collaborative activities), relations (e.g., power relations); and similarities (e.g., same gender).

# Visualizing telecoupling networks

Visualizations are fundamental in network-based research, allowing viewers to detect patterns (Golbeck 2013) and “translate structural complexity into perceptible visual insights” (Lima 2011:79). Network visualizations differ in terms of how nodes and links are visually encoded, i.e., whether they are explicitly visualized through marks, or implicitly through attributes (Munzner 2014).

In this study, we adopt a network-based approach to analyzing visual representations of telecoupling dynamics. Hence, we

interpret existing visualizations in terms of their node-link structure. We then identify the content that these nodes and links represent and assess how they are visually encoded through marks and attributes. This network-based approach presents a means to analyze telecoupling visualizations in a unified manner, independent of the definition of the system in use, displayed analytical units of the telecoupling framework, or scale of the study region.

# Methods: systematic review of telecoupling visualizations

# Publication and case selection

In this study, we systematically reviewed visualizations presented in telecoupling literature in order to investigate current practices of telecoupling visualization. We conducted the review in line with the guidelines of the Preferred Reporting Items for Systematic

Reviews and Meta-Analyses (PRISMA) statement (Moher et al. 2010). Figure 3 presents the publication and case selection process. In the first stage, we conducted a keyword search in bibliographic databases to identify scientific journal articles and book chapters on the topic of “telecoupling.” We cross-checked these results with other systematic reviews of telecoupling literature (Carlson et al. 2018, Corbera et al. 2019, Kapsar et al. 2019). Taking specific exclusion criteria into account (see Fig. 3), we then selected 120 publications. They served as sources to identify potential cases for our study.

The second stage involved the selection of cases, i.e., visualizations. The selected articles and book chapters contained 495 visualizations, to which we applied the case identification, inclusion, and exclusion criteria shown in Figure 3. We found that 381 visualizations $( 7 7 . 0 \% )$ present empirical, case-specific information on real world phenomena. Moreover, 85 $( 1 7 . 2 \% )$ displayed purely conceptual information, typically portraying telecoupling frameworks. The remaining 29 visualizations presented other types of information, e.g., on methodological approaches. Of the 381 visualizations, 130 presented explicit information on telecoupling connections. These cases were considered for our review, making up $2 6 . 3 \%$ of the initially identified potential cases. We then excluded visualizations that represent similar content through an identical visual design. This resulted in the selection of 118 visualizations, i.e., cases, displayed in 62 publications (see Table A1.1 in Appendix 1 for a complete overview).

# Coding process and data analysis

We employed an iterative process to develop the codebook. We first derived a preliminary version based on insights from telecoupling, network, and visualization literature. We then adjusted it throughout several rounds of coding, and recoded all cases using the final version of the codebook. It consisted of the following sections: general information; nodes; links; systems; flows; and data visualization (see Table A2.1 in Appendix 2 for the full codebook). In order to ensure the quality of the data, we applied sample-double coding. Of the cases, $3 3 . 1 \%$ were coded by at least two of the authors, which resulted in a percentage agreement intercoder reliability of 0.92.

We employed descriptive statistics to analyze the resulting data set. Furthermore, we developed a typology of telecoupling visualizations based on the characterization of single cases (Oberlack et al. 2019). The following visualization characteristics were thereby considered: visual encodings; and spatial explicitness of nodes and links. We used a truth table approach to identify the visualization types. A truth table presents the prevailing combinations of different case characteristics (Rihoux and Ragin 2009). Each unique combination of visualization characteristics corresponds to one visualization type.

# Limitations

Our case selection was limited to those that explicitly refer to “telecoupling.” This precludes consideration of the numerous other visualizations presenting information about telecoupling phenomena without mentioning the term. In addition, there appears to be a thematic bias in telecoupling visualizations, as the majority present information on commodity trade (see Fig. 4). It is clear that much can be learned from other thematic fields in terms of (alternative) visualization approaches used for

displaying connections. However, by confining the scope of this study to telecoupling, we were able to systematically review all existing visualizations in this field and draw more reliable and concrete conclusions about its practice. Nonetheless, this specific focus also ruled out the inclusion of visualizations presented in grey literature and online visualizations. To our knowledge, no such sources exist that explicitly mention telecoupling and present visualizations that meet the case selection criteria of this study. However, because interactive visualizations offer important features for visualizing complex data sets, we further elaborate on them in the discussion section, based on illustrative examples. Finally, our approach of considering each visualization as a separate case poses two risks. First, this implies that multiple cases from the same article/book chapter can be included in the analysis. This may introduce a certain bias, if authors tend to use similar visualization approaches for multiple graphs in their articles. We introduced duplication exclusion criteria to limit this potential bias (see Fig. 3). Second, our approach bears the risk of neglecting the complementary function that multiple visualizations can have within one source. This aspect is also taken up in the discussion section.

# RESULTS

# Visualization content

The 118 reviewed visualizations covered a range of topics, most frequently commodity trade, species migration, and nature conservation (Fig. 4). They mainly display secondary data $\mathbf { \bar { n } = }$ 89), but also primary data $( \mathtt { n } = 5 )$ ) or a mix of both $( \mathtt { n } = 8 )$ ). For some cases $( \mathtt { n } = 1 6$ ), no data sources were exposed.

![](images/9444caa1aa24f093616cb07b62934f76d35b54379a0c6233ad6909089760abc3.jpg)  
Fig. 4. Telecoupling topics addressed in the selected 118 cases (by number of cases).

# Nodes and links

We adopted a network lens to analyze telecoupling visualizations, identifying their node and link components and the content they represent. We found that they typically presented networks of social-ecological systems, which were linked through flows (Fig. 5). This is in line with the original framework of Liu et al. (2013), which proposes social-ecological systems and flows as main analytical units of telecouplings. Because of their predominance, a more detailed account of the use of systems and flows in telecoupling visualizations is given below.

Our analysis also revealed the presence of alternative node and link contents (Fig. 5). Besides systems, nodes also represent

individual or collective actors, or action situations. Nine out of the 118 cases presented actors as nodes in a telecoupling network, without an explicit display of the systems in which the actors were embedded (see, for example, Gasparri et al. 2016, Tapia-Lewin et al. 2017). A small proportion of the reviewed cases $( \mathtt { n } = 2 )$ displayed connections between action situations (Boillat et al. 2018, Oberlack et al. 2018). Action situations are decision arenas in which actors interact and take interdependent and joint decisions that lead to specific outcomes (Ostrom 2010).

![](images/077df689e52af8c9900bda8142b215265643d772a57eb3c4658a4360111b4e3c.jpg)  
Fig. 5. Node and link types represented in telecoupling visualizations and the combination thereof. Link types are based on Borgatti et al. (2009).

In some cases, telecoupling links represented interactions, relations, or similarities, rather than flows. Interactions refer to events that are facilitated through flows (Borgatti et al. 2018). Examples are market demand and supply interactions (e.g., Liu et al. 2015, Eakin et al. 2017) as well as collaboration and negotiation (Gasparri et al. 2016). Two cases also displayed relations, for instance referring to power or legitimacy (Chignell and Laituri 2016, Oberlack et al. 2018). One study (Andriamihaja et al. 2019) identified the presence of shared institutions as links between actors, thus indicating similarity between them. For some cases, the nature of the link was not specified.

# Systems and flows

System nodes mainly differed in terms of three aspects: (1) whether a distinction was made between sending, receiving, and spillover systems; (2) whether they presented information about internal system dynamics; and (3) the way their boundaries were defined. We found that among all cases that presented system nodes, $3 1 . 3 \%$ made explicit reference to sending, receiving, and/or spillover systems. Furthermore, less than a third $( 2 8 \% )$ presented information about dynamics that took place within the respective systems. Some included specific information about the system components proposed by Liu et al (2013): actors $( 1 2 . 5 \% )$ ; causes $( 2 3 . 2 \% )$ ; and effects $( 1 7 . 9 \% )$ . A range of system boundaries were used to delineate system nodes (Fig. 6). They were most commonly based on existing governance units, accounting for $6 4 . 6 \%$ of all

identified system boundary types. Many thereby referred to administrative units at different levels $( 5 5 . 7 \% )$ . Others pointed to spatial zonings $( 8 . 9 \% )$ such as protected areas or land concessions. System boundaries were further based on broader geobased characteristics (e.g., world regions, $1 2 . 5 \%$ , diverse social-economic features (e.g., economic sectors or infrastructure facilities, $1 0 . 4 \% )$ ), ecosystems (e.g., biomes or breeding sites of migrating species, $9 . 4 \%$ ), or areas defined through their topographic-hydrological traits (e.g., watersheds or valleys, $3 . 1 \%$ ).

![](images/461ce8440794d70ef34b9f40a462c04e0f4ab65ee03603f3f8470d3612c8220d.jpg)  
Fig. 6. System boundaries used in telecoupling visualizations. System categories are partly based on Brondizio et al. (2016).

There was a tendency to define systems at a high level of aggregation. More than half of the identified boundary types $( 5 3 . 6 \% )$ represent telecoupled systems at the national level or above, i.e., systems defined through supra-national governance units, world regions, the rest of the world (in relation to a focal system), or the world itself. This often applied to spillover systems (see, for example, Liu et al. 2015, Parish et al. 2018). Furthermore, most boundary types $( 9 6 . 4 \% )$ provided an indication of the system’s geographical location. Systems without a geographic reference were observed merely with regard to socioeconomically defined boundaries.

Flows in telecoupling visualizations mainly differed in terms of content. Material flows were most commonly depicted, accounting for $3 4 . 5 \%$ of all flow types identified. They generally referred to the export and import of goods, in particular agricultural commodities such as soybeans or beef. Some links also represented elements implicitly embedded within commodity flows. These can be virtual resources $( 5 . 1 \% )$ such as water or land, or virtual risks/ benefits $( 7 . 3 \% )$ such as deforestation risks or biodiversity loss. The movement of capital $( 1 6 . 9 \% )$ , humans (e.g., tourists, $1 2 . 4 \%$ ), nonhuman beings (e.g., migrating birds, $1 0 . 2 \% )$ ), or information $( 9 \% )$ is also commonly visualized. Flows of ecosystem services are explicitly mentioned in a number of graphs $( 2 . 3 \% )$ . Few cases displayed flows, but did not present any detailed information about their content $( 2 . 3 \% )$ .

Fig. 7. Overview of visualization types used to display telecoupling dynamics, approaches used to represent node and link data, and their association with different visualization techniques (the order of the naming of the techniques corresponds to the order of the listed icons).   

<table><tr><td rowspan="3">Visualization types</td><td colspan="4">Data representation approaches</td><td rowspan="3">Visualization techniques</td><td rowspan="3">Visualization technique symbols</td></tr><tr><td colspan="2">Nodes</td><td colspan="2">Links</td></tr><tr><td>How are nodes visually encoded?</td><td>Are nodes spatially explicit?</td><td>How are links visually encoded?</td><td>Are links spatially explicit?</td></tr><tr><td>Relational graphs</td><td>Mark</td><td>X</td><td>Mark</td><td>X</td><td>Schematic diagrams, Network diagrams, Chord diagrams</td><td></td></tr><tr><td>Quantity graphs</td><td>Link attribute</td><td>X</td><td>Mark</td><td>X</td><td>Bar charts, Line graphs, Area graphs, Box plots</td><td></td></tr><tr><td>Route maps</td><td>Mark</td><td>✓</td><td>Mark</td><td>✓</td><td>Route maps</td><td></td></tr><tr><td>Link maps</td><td>Mark</td><td>✓</td><td>Mark</td><td>X</td><td>Flow maps, Connection maps</td><td></td></tr><tr><td>Quantity maps</td><td>Mark</td><td>✓</td><td>Node attribute</td><td>X</td><td>Choropleth maps, Proportional symbol maps</td><td></td></tr><tr><td>Quantity maps with link marks (hybrid)</td><td>Mark</td><td>✓</td><td>Node attribute &amp; Mark</td><td>X</td><td>Combination of Quantity maps and Link maps</td><td></td></tr><tr><td>Partially spatial relational graphs (hybrid)</td><td>Mark</td><td>✓&amp;X</td><td>Mark</td><td>X</td><td>Combination of Schematic diagrams and various map types</td><td></td></tr></table>

# Visualization approaches

# Visualization types

Our analysis identified seven distinctly different telecoupling visualization types used in current practice, which correspond to 15 visualization techniques (see Fig. 7). They reflect unique combinations of data representation strategies used to depict node and link information visually.

Relational graphs and quantity graphs are the two most frequently used telecoupling visualization types (Fig. 8). Of all cases, $5 5 . 9 \%$ made use of one of these two types. Neither are spatially explicit. For relational graphs $\mathrm { ~ n ~ } = 3 6$ out of 118 cases), the predominant visualization technique used was schematic diagrams. In many instances, these were box and arrow diagrams that reproduced the telecoupling framework structure proposed by Liu et al. (2013) and applied it to an empirical context. Chord and network diagrams are alternative but much less frequently used forms of relational graphs. Quantity graphs $( \mathrm { n } = 3 0 )$ ) include a number of different visualization techniques used to display quantitative, comparative data. Examples are different types of bar charts and area graphs. In these visualizations, nodes are not explicitly depicted through a mark, but rather implicitly through a link attribute.

In $4 4 . 1 \%$ of all cases, nodes were depicted with a spatial reference. However, only $3 . 4 \%$ also presented links in a spatially explicit way. This is the case for route maps $( \mathtt { n } = 4 )$ ), which present links as a

series of geographical data, thus depicting a path from one location to another. Link maps $( \mathtt { n } = 2 1$ ) depict links as geodesic lines instead, either as connection maps or flow maps. The former present nodes through points on a map, and the latter through areas. Quantity maps $( \mathrm { n } ~ = ~ 7 )$ ) do not explicitly present link connections. They indicate the presence of links by presenting quantitative link information as attributes of geospatially explicit nodes. For instance, the proportional symbol map presented by Parish et al. (2018) displays information about the magnitude of wood pellet exports (links) through the varying size of the bubbles representing the ports (nodes) from which these goods are shipped. Furthermore, we have identified hybrid types that combine multiple visualization approaches, for instance by overlapping choropleth maps and flow maps (see, for example, Kastner et al. 2015).

The identified visualization types can be used to depict node and link information, irrespective of their thematic content. Each of them can thus be applied to a variety of telecoupling phenomena. This is underlined by our results, which show a high diversity in visualization types used for different telecoupling topics (see Fig. 9). Exceptions are visualizations of land acquisition telecouplings (though this is possibly linked to the small n for this category) and those of species migration (showing a relatively large share of link maps). Each of the visualization types has its own set of data requirements. Depending on the topic, such data might be more or less accessible. For example, a route map can in principle

![](images/89e7e472c11f365097089b397a0da4006d47cff5bc0e06c758f0269828835b0e.jpg)  
Fig. 8. Frequency of visualization types by occurrence in cases $( \mathtt { n } = 1 1 8 )$ ), with an indication of their composition of visualization techniques (see Fig. 7 for the meaning of the icons).

be used to present any type of flows between two places, e.g., flows of water, migrating species, or conservation funds. However, it requires spatially explicit information about the flow route. Accessing such information might be particularly challenging for some types of flows, e.g., species migration routes, but relatively more straight forward for others, e.g., water transfer channel infrastructure (see, for example, Quan et al. 2016).

# Visual attributes

The identified visualization types indicate different approaches for visually representing the two key components of telecoupling visualizations, i.e., nodes and links. Moreover, visual attributes can be applied to node and link marks, in order to present additional or more detailed information about the telecoupling phenomena (cf. Fig. 1).

In Appendix 3, we provide an overview of the main visual attributes used in existing telecoupling visualizations, based on illustrative case examples (see Figure A3.1). A large range of attributes was used, providing different types of information. For instance, authors use visual attributes to characterize nodes, e.g., distinguishing between export and import countries, and to delineate them, e.g., indicating closed or porous system boundaries. Visual attributes are also used to indicate the direction, magnitude, or other characteristics of the displayed links. For instance, when portraying the flows linked to the expansion of banana plantations in Laos, Friis and Nielsen (2017a) apply color attributes to the link marks (i.e., the arrows representing flows) to add information about flow content (e.g.,

discursive flows or political flows). They also use solid and dashed arrows to indicate whether or not these arrows represent spillover flows.

Visual attributes were also used to display temporal information, in particular to present comparative data over time. This applied to $2 4 . 6 \%$ of all cases $\left( \mathrm { n } = 3 0 \right)$ ). The majority thereby presented temporal variations in quantitative data $( \mathrm { n } = 2 6 )$ ), such as the changing magnitude of commodity exports (see, e.g., Reenberg and Fenger 2011). Quantity graphs are the predominant visualization type used to present such information, using positioning attributes in reference to a time scale (see, e.g., Yang et al. 2016). Quantity maps allow to present quantitative information that is both temporally and spatially explicit. In a choropleth map, for instance, color attributes can be used to show net changes of flow magnitude across a certain time period (see Marston and Konar 2017). Four cases further present qualitative data in a temporally explicit framing, e.g., through labelling (Eakin et al. 2017) or positioning on a time line (Raya Rey et al. 2017).

# DISCUSSION AND CONCLUSIONS

# Data representation in telecoupling visualizations: current practices, challenges, and recommendations

Our study shows that visualizations are widely used in communicating knowledge about telecoupled connections, and that this practice is rich in content and visual diversity. In particular, we draw attention to the node-link structure of

![](images/f3ec9a32c9fa0b62db360d097b9993d3a2d85af61b41f0abd2803b4b07ac3b2a.jpg)  
Fig. 9. Relative frequency of use of visualization types for each telecoupling topic.

telecoupling visualizations and unravel the visual encoding strategies applied to them. We find that the visual representation of telecoupling phenomena is particularly challenging, given the multidisciplinary conceptual foundations, diversity of analytical approaches, and richness of the data used in this field. In this section, we reflect upon selected practices of data representation in telecoupling visualizations, providing specific recommendations for enhancement. We thereby refer to the two concurrent data representation processes: visual encoding; and the selection of visualization techniques.

Our research identified seven telecoupling visualization types. These differ in terms of the way node and link information is visually encoded, i.e., explicitly through visual marks or implicitly through visual attributes. In relational graphs, route maps, and link maps, nodes and links are shown explicitly and can thus be quickly captured by the target audience. In quantity maps and quantity graphs, either node or link information is implicitly encoded. This facilitates the visually display of quantitative data, but also makes the implicitly presented information less accessible to the viewer. Quantity maps with link marks (hybrid type) attempt to address this issue, for example by displaying selected links in the form of arrows, in addition to the presentation of link information through visual attributes (e.g., color coding in a choropleth map). However, this approach implies that links are encoded in multiple ways, which may lead to visual clutter and encoding inconsistencies. These examples illustrate that several potentially competing factors (number of data points, combination of data types, coding consistency, etc.) affect visual encoding decisions. Careful reflection and design is thus needed at this stage of the data visualization process, ensuring that the selected visual encodings facilitate a rapid and intuitive decoding process (Iliinsky and Steele 2011) and support the main purpose of the visualization (Kirk 2016).

The same applies to the selection of visual attributes. Our research revealed that telecoupling visualizations commonly make use of

(combinations of) visual attributes to represent different telecoupling contents. The field could learn from data visualization literature, which discusses a broad range of different attributes and presents guidance on their selection and implementation. Iliinsky and Steele (2011), for instance, present an overview of attributes and indicate their suitability for different data types and the number of distinct values they can represent. Munzner (2014) provides an effectiveness ranking for different visual attributes. Once attributes are selected, their implementation also requires careful consideration, e.g., appropriate color scheme (see, for example, Brewer 1994, Borland and Taylor 2007) or axis ranges (Tufte 2006). A range of literature presents and critically discusses recommendations in this respect (see, for example, Kelleher and Wagener 2011, Kosara 2016, Healy 2018).

Regarding the selection of visualization techniques, our research revealed some diversity in existing telecoupling visualizations, with 15 different techniques being used. The field of data visualization, however, offers a wider range of visualization techniques. Multiple online catalogues exist that group them by function (see, e.g., the Data Visualization Catalogue (https:// datavizcatalogue.com/search.html) and the R Graph Gallery (https://www.r-graph-gallery.com/), data input (From Data to Viz web site (https://www.data-to-viz.com/), or both (Data Viz Project, https://datavizproject.com/). Figure 10 presents a selection of techniques that were not identified in the cases but could provide interesting opportunities to display telecoupling phenomena. Some form the basis of well-known interactive visualizations on land-related themes, such as the sankey diagram used in the Trase platform (SEI and Global Canopy 2020) and the nonribbon chord diagram presented on the Land matrix platform (ILC et al. 2019). Matrix-based charts (Ghoniem et al. 2005), hive diagrams (Krzywinski et al. 2012), and biofabrics (Longabaugh 2012) are alternatives to node-link diagrams, which aim to address the challenge of visual clutter in large and dense

networks[1]. The edge bundling technique, involving the visual bundling of adjacent links, can also be helpful in this respect. It is commonly applied to chord diagrams (Holten 2006) or link maps (Holten and Van Wijk 2009, Lambert et al. 2010). Finally, brick maps present an alternative technique for quantity maps (Few, 2013). They portray spatially explicit, quantitative values through an accumulation of squares representing a specific value range. Few (2013) suggests that this approach could be more effective in terms of visual perception than the use of varying colors (as in choropleth maps) or bubble sizes (as in proportional symbol maps).

Fig. 10. Selection of additional visualization techniques suitable for the visualization of telecoupling connections, grouped by the visualization types.

<table><tr><td colspan="3">Relational graphs</td></tr><tr><td>Sankey Diagram/ 
Parallel Sets</td><td>Nonribbon 
chord diagram</td><td>Arc Diagram</td></tr><tr><td>Biofabrics</td><td>Hive plot</td><td></td></tr><tr><td>Quantity graphs</td><td colspan="2">Quantity maps</td></tr><tr><td>Matrix chart</td><td colspan="2">Brick map</td></tr></table>

# Integrating multiple perspectives: a telecoupling visualization challenge

A combination of different views is essential for achieving a sound understanding of social-ecological phenomena (Berkes et al. 2003), particularly in a hyperconnected world. Nonetheless, in order to produce purposeful results, researchers may need to choose between different entry points and analytical foci on the subject matter. A similar challenge exists in presenting research visually. Visualizations can display single or multiple perspectives of the portrayed subject, accounting for different levels of complexity (Kirk 2016). Lima (2011) identifies three main perspectives in network visualizations: (1) a micro perspective providing detailed information on specific network entities; (2) a relationship perspective focusing more on dismantling network links and presenting analytics thereof; and (3) a macro perspective

presenting a bird’s eye view of the network and offering insights on its topology. Many of the reviewed cases seem to emphasize one of these perspectives, respectively: (1) providing a detailed characterization of social-ecological systems and their internal dynamics but presenting limited information on the flows connecting them (e.g., Chignell and Laituri 2016, Hulina et al. 2017); (2) identifying and characterizing the links in telecoupled connections (e.g., Reenberg and Fenger 2011, Schierhorn et al. 2016); (3) displaying large telecoupled networks while presenting less detail about individual nodes and links (e.g., Prell et al. 2017, Andriamihaja et al. 2019).

The data visualization process thus requires and is guided by choices on the perspectives and levels of details that are to be visually presented. The following case examples illustrate how the identified visualization types (cf. Fig. 7) allow for different presentations of commodity trade phenomena, the most frequently visualized telecoupling topic (cf. Fig. 4). Quantity graphs are commonly used to display highly aggregated trade data, thus presenting a relationship view between trade partners (e.g., Schierhorn et al. 2016). Quantity maps and link maps add a spatial component to this, potentially revealing spatial trade patterns (e.g., Liu 2014). Route maps present more detailed spatial information by displaying the precise transport routes and mapping the multiple sites, e.g., cities or ports, that the commodities pass through (e.g., Godar and Gardner 2019). This allows a better understanding of such telecoupling phenomena, for example by indicating potential spillover sites or the different actors involved along the route. Relational graphs can have multiple uses. For example, schematic diagrams are commonly used to map existing trade phenomena in terms of the telecoupling schema and present micro views on internal system dynamics (e. g., Garrett and Rueda 2019). Network and chord diagrams depict trade networks from a more macro perspective (e.g., Xiong et al. 2018). They can provide insights on the structure of a trade network, for example by highlighting predominant trade relationships or showing clusters among trade partners.

The more perspectives combined, the more challenging it is to accommodate them in a single visualization (Munzner 2014). Visually portraying telecoupling phenomena while avoiding both an oversimplification of the complex subject matter and an overloading of the visualization is thus a key challenge in this field. It is essential for researchers first to reflect on all potential perspectives that could be combined, and then to select with care just enough perspectives to represent the telecoupling phenomenon adequately and purposefully. Once a selection is made, different approaches can be used to simultaneously portray multiple perspectives in a visual form. Hybrid visualization techniques, for instance, can be used for joint display of multiple types of information (see hybrid types, Fig. 7). However, they may be challenging and time-consuming to decode if not carefully designed. Text boxes and labels within visualizations can also be a helpful means to provide contextual information (see, e.g., Godar and Gardner 2019). Furthermore, data can be juxtaposed and presented across separate visual objects (Gleicher et al. 2011). Thereby, data comparison can be facilitated through side-by-side presentation of the same chart types presenting different subsamples of a dataset (see the small multiples technique, Tufte 2001). An alternative is using multiple graphs of different design to present complementary data (Munzner 2014). For example,

Liu et al. (2018) complement a flow map on soybean trade with more specific information through additional bar charts. Data can further be visualized through multiple, superimposed layers (Gleicher et al. 2011). López-Hoffman et al. (2017), for instance, present a schematic representation of bird migration with a background map that provides additional geographic context about these systems. Finally, comparative data can be combined in a visualization through explicit encodings that compute the relationship between objects (Gleicher et al. 2011). Sun et al. (2018), for instance, indicate net imports of soy using a color scale.

# Interactive visualizations

Interactive visualizations offer far greater possibilities to represent multiple aspects of telecouplings than static ones. Interactive features can enable users to navigate between different scales and perspectives, tailoring the visual display to their needs and interest (Bostrom et al. 2008, Janvrin et al. 2014). They allow them to engage actively with the data, and possibly analyze and download it. The following examples of interactive visualizations on commodity trade illustrate a few of the many potential benefits of using interactivity in this field. The interactive flow map Resourcetrade.earth (Chatham House 2018) presents elaborate possibilities for users to define the level of analysis shown in the visualization. Through data filtering processes, they can choose among different types of flows at varying levels of aggregation (commodity [sub]types). On the trase platform (SEI and Global Canopy 2020), commodity production data is presented in a spatially explicit way and also interactively linked to other supply chain stages. Users have various options to customize the data display, e.g., by applying different scales to the commodity production data (municipality, biome, country, logistic hubs). On the Economic Complexity Observatory web site (Simoes and Hidalgo 2011, CID 2020a), users can also choose different visualization techniques to display the same trade data. This feature helps to address the needs of different users (Spiegelhalter et al. 2011). Furthermore, interactive features can allow users to explore data in a three-dimensional space (see, for example, the Globe of Economic Complexity, Cornec and Vuillemot 2015, CID 2020b). They also offer interesting opportunities to present longitudinal data, for instance through time sliders or movies (Moody et al. 2005). This is particularly relevant to this field, given its spatio-temporal dynamics. As we have shown, a temporal angle is often missing in telecoupling visualizations.

However, interactive graphs also bring about challenges. Their development and maintenance can be demanding in terms of resources. Furthermore, their use requires computer literacy and potentially more refined user skills, preventing some potential users from accessing the displayed information (Spiegelhalter et al. 2011). Visualization developers have a high responsibility to ensure the legitimacy and validity of the data that is visualized and can potentially be downloaded by users. In terms of design, the web interface needs to allow users to navigate intuitively between different levels of analysis. Shneiderman’s renowned mantra “overview first, zoom and filter, details on demand” (1996:337) can be helpful in this respect, along with other techniques proposed to reduce intricacy in multiperspective visualizations (Lima 2011).

Hence, although static visualizations are and will remain important tools for scientific communication, interactive graphs

and dashboards present novel opportunities to accommodate the multiplicity of perspectives often present in telecoupling research. Because visual encodings, i.e., marks and attributes, also form the basis of interactive graphs, the insights and recommendations proposed in this study are equally relevant to this form of visualization. Though falling outside of the scope of this analysis, alternative mediums for cocreating and communicating scientific knowledge, e.g., videos, participatory mapping and art, and augmented and virtual reality, may further be explored, as they offer other stimulating ways to engage with the target audience and knowledge holders.

# Reflecting the content of telecoupling visualizations: system boundaries and actor dynamics

Visualizations are simplifications of a complex reality, and thus naturally emphasize certain elements and perspectives while leaving others out. They are a representation of researchers’ mental models of the phenomena they are investigating. In this study, we have analyzed the content of telecoupling visualizations, offering a glimpse into current telecoupling research practice and the underlying choices that go with it. Here, we discuss and reflect on selected findings that reveal how certain perspectives and telecoupling components receive dissimilar attention in telecoupling visualizations. We thereby focus on the results regarding the presence of system boundaries and actor dynamics.

The definition of system boundaries has been put forward as a critical issue in telecoupling research (Friis et al. 2016, Friis and Nielsen 2017b). In visualizations, where systems are often clearly delineated, researchers’ boundary choices are highly visible. Our study reveals that in telecoupling visualizations, systems are often defined at a high level of aggregation (country level and above) and commonly based on territorial governance structures. These results are in line with previous claims suggesting that system boundaries in telecoupling research are predominantly territorybased (Friis and Nielsen 2017b) and frequently delineated at country level (Seaquist and Johansson 2019). Although data availability issues may also play a role in this, e.g., trade data often being recorded at national level, these results may indicate that certain systemic perspectives and scales of analysis are predominant in telecoupling research. By all accounts, they call for a careful selection and (visual) communication of system boundaries, which includes a critical reflection on the potential gains and limitations that different perspectives may bring.

Furthermore, we have shown that system boundaries are usually drawn based on one or more specific characteristics of real world phenomena, e.g., hydrological-topographic. A social-ecological system approach, however, postulates the consideration and integration of multiple dimensions or subsystems within one geographic area (Ostrom 2009). In empirically-based visualizations, it can be challenging to present this multidimensionality and multiplicity of (sub)systems visually because of their limited capacity to portray manifold perspectives (as outlined in the previous section). Brondizio et al. (2016) address this challenge by visually displaying multiple layers of one geographic area, each showing different subsystems of the social-ecological system. Others make use of nested views to present multiple systems of varied scales conjointly (Drakou et al. 2017).

Our analysis further reveals that actors and the interactions between them are given relatively little emphasis in the reviewed cases. Though present in visualizations of actor networks and action situation networks, we have found that actor-specific information is less frequently represented in visualizations showing connections between systems, i.e., as elements within the systems. A recent systematic review of telecoupling literature presents similar observations, suggesting that actors and their interactions deserve further attention in telecoupling research (Kapsar et al. 2019). In terms of explaining their visual absence from telecoupling visualizations, additional factors may play a role. For example, actor-related information may be particularly challenging to capture visually and accommodate within telecoupling visualizations. Similarly, disciplines that place more emphasis on actor perspectives may make less use of visualizations. However, considering the importance of actor dynamics for understanding and governing telecoupling processes (Liu et al. 2013, Eakin et al. 2014, Munroe et al. 2019), it is important to develop effective visualizations that capture these components.

These reflections show that, on the one hand, the decisions that researchers make during the visualization design process are shaped by their ability to visualize certain research contents. On the other hand, they are also intrinsically guided by their view of the telecoupling phenomenon and the selected approach to investigating it. Do we present a micro, macro, or link perspective of the telecoupling phenomenon, or a combination thereof ? How do we define our system boundaries? Do we consider spillover dynamics? And do we take temporal dimensions into account? These and many more choices define research directions and the way we communicate about them, leading to different, complementary understandings and visual presentations of telecoupling connections. In this regard, the visualization process offers researchers an opportunity to reflect upon the underlying assumptions and perspectives that define their research, and to communicate them in a transparent way.

# The potential of network perspectives

This study demonstrates the ubiquity of network perspectives in telecoupling visualizations, even if networks are often not explicitly discussed. Such a networked view of telecoupling is inherent in its definition, as the framework is built on the idea of connectivity. Nonetheless, visual depictions of telecoupling dynamics often do not appear to go beyond the display of broader large-scale flows between systems whose boundaries are typically defined based on administrative units at high levels of aggregation. The contexts, drivers, and actors operating across these systems are thus often not visually captured at the levels at which decisions are made. However, our research also underpins alternative avenues for portraying telecoupling phenomena, namely through actor networks and action situation networks. These approaches allow for the depiction of telecoupling connections that span geographical locations and scales and emphasize the actors driving these dynamics and their interrelations. Furthermore, by introducing insights from the field of social network analysis, we have pointed to additional ways of conceptualizing links in telecoupling, i.e., as interactions, relations, or similarities. These can complement the predominant flow-based perspective and may be useful for exploring more intangible linkages, e.g., values, power relations, or political

dynamics, that are increasingly considered as crucial for governing telecoupled processes (Eakin et al. 2017). These insights support previous calls for the further integration of network-based views, concepts, and methods in telecoupling research (Sayles et al. 2019, Seaquist and Johansson 2019). This may provide for more indepth understandings of the relations that drive and shape telecoupling connections, as well as the broader network structure of telecoupled social-ecological systems. Particularly if paired with effective visuals, network-based understandings of telecoupling phenomena may thus offer promising new directions for identifying and communicating the main leverage points for addressing global sustainability challenges within local realities.

[1]See also R. Kosara, blog, https://eagereyes.org/techniques/ graphs-hairball#more-1685

Responses to this article can be read online at: https://www.ecologyandsociety.org/issues/responses. php/11830

# Appendix 1.

Table A1.1. List of selected cases.   

<table><tr><td>Publications (Reference)</td><td>Cases
(Fig. no.)</td></tr><tr><td>Andriamihaja, O. R., F. Metz, J. G. Zaehringer, M. Fischer, and P. Messerli. 2019. Land Competition under Telecoupling: Distant Actors&#x27; Environmental versus Economic Claims on Land in North-Eastern Madagascar. Sustainability 11(3).</td><td>2, 4</td></tr><tr><td>Bagstad, K. J., D. J. Semmens, J. E. Diffendorfer, B. J. Mattsson, J. Dubovsky, W. E. Thogmartin, R. Wiederholt, J. Loomis, J. A. Bieri, C. Sample, J. Goldstein, and L. Lopez-Hoffman. 2019. Ecosystem service flows from a migratory species: Spatial subsidies of the northern pintail. Ambio 48(1):61–73.</td><td>1, 2</td></tr><tr><td>Boillat, S., J.-D. Gerber, C. Oberlack, J. G. Zaehringer, C. I. Speranza, S. Rist, and C. Ifejika Speranza. 2018. Distant Interactions, Power, and Environmental Justice in Protected Area Governance: A Telecoupling Perspective. Sustainability 10(11):3954.</td><td>2, 3</td></tr><tr><td>Brondizio, E. S., N. D. Vogt, A. V Mansur, E. J. Anthony, S. Costa, and S. Hetrick. 2016. A conceptual framework for analyzing deltas as coupled social-ecological systems: an example from the Amazon River Delta. Sustainability Science 11:591–609.</td><td>5</td></tr><tr><td>Carlson, A. K., W. W. Taylor, J. Liu, and I. Orlic. 2017. The Telecoupling Framework: An Integrative Tool for Enhancing Fisheries Management. Fisheries 42(8):395–397.</td><td>2</td></tr><tr><td>Carlson, A. K., W. W. Taylor, J. Liu, and I. Orlic. 2018. Peruvian anchoveta as a telecoupled fisheries system. Ecology and Society 23(1).</td><td>1, 2</td></tr><tr><td>Carter, N. H., A. Viña, V. Hull, W. J. McConnell, W. Axinn, D. Ghimire, and J. Liu. 2014. Coupled human and natural systems approach to wildlife research and conservation. Ecology and Society 19(3):43.</td><td>4, 5</td></tr><tr><td>Castilla, J. C., J. Espinosa, C. Yamashiro, O. Melo, and S. Gelcich. 2016. Telecoupling Between Catch, Farming, and International Trade for the Gastropods Concholepas concholepas (Loco) and Haliotis spp. (Abalone). Journal of Shellfish Research 35(2):499–506.</td><td>1, 2</td></tr><tr><td>Chen, W., X. Ye, J. Li, X. Fan, Q. Liu, and W. Dong. 2019. Analyzing requisition-compensation balance of farmland policy in China through telecoupling: A case study in the middle reaches of Yangtze River Urban Agglomerations. Land Use Policy 83:134–146.</td><td>8</td></tr><tr><td>Chignell, S. M., and M. J. Laituri. 2016. Telecoupling, urbanization, and the unintended consequences of water development aid in Ethiopia.</td><td>4</td></tr></table>

In G. R. Wessel and J. K. Greenberg, editors, Geoscience for the Public Good and Global Development: Toward a Sustainable Future: 125 135. Geological Society of America Special Papers Volume 520, Geological Society of America, Boulder, Colorado, USA.   
Chung, M. G., T. Dietz, and J. Liu. 2018. Global relationships between 3 biodiversity and nature-based tourism in protected areas. Ecosystem Services 34:11 23.   
Deines, J. M., X. Liu, and J. Liu. 2016. Telecoupling in urban water 4 systems: an examination of Beijing's imported water supply. Water International 41(2):251 270.   
Dou, Y., R. F. B. da Silva, H. Yang, and J. Liu. 2018. Spillover effect 1, 10 offsets the conservation effort in the Amazon. Journal of Geographical Sciences 28(11):1715 1732.   
Drakou, E. G., L. Pendleton, M. Effron, J. C. Ingram, and L. Teneva. 2, 3 2017. When ecosystems and their services are not co-located: oceans and coasts. ICES Journal of Marine Science 74(6):1531 1539.   
Drakou, E. G., J. Virdin, and L. Pendleton. 2018. Mapping the global 3, 7 distribution of locally-generated marine ecosystem services: The case of the West and Central Pacific Ocean tuna fisheries. Ecosystem Services 31(B, SI):278 288.   
Eakin, H., X. Rueda, and A. Mahanti. 2017. Transforming governance 3, 4 in telecoupled food systems. Ecology and Society 22(4):32.   
Easter, T. S., A. K. Killion, and N. H. Carter. 2018. Climate change, 2 cattle, and the challenge of sustainability in a telecoupled system in Africa. Ecology and Society 23(1).   
Friis, C., and J. O. Ø. Nielsen. 2017. Land-use change in a telecoupled 3 world: the relevance and applicability of the telecoupling framework in the case of banana plantation expansion in Laos. Ecology and Society 22(4):30.   
Garrett, R. D., X. Rueda, and E. F. Lambin. 2013. Globalization's 4 unexpected impact on soybean production in South America: linkages between preferences for non-genetically modified crops, eco-certifications, and land use. Environmental Research Letters 8(4).   
Garrett, R., and X. Rueda. 2019. Telecoupling and Consumption in 6.2, 6.3 Agri-Food Systems. In C. Friis and J. Ø. Nielsen, editors, Telecoupling: Exploring Land-Use Change in a Globalised World: 115 137. Springer Nature Switzerland AG, Cham, Switzerland.   
Gasparri, N. I., T. Kuemmerle, P. Meyfroidt, Y. le Polain de Waroux, 4

and H. Kreft. 2016. The Emerging Soybean Production Frontier in Southern Africa: Conservation Challenges and the Role of South-South Telecouplings. Conservation Letters 9(1):21 31.   
Godar, J., and T. Gardner. 2019. Trade and Land-Use Telecouplings. In 8.1, 8.2, 8.3, 8.4 C. Friis and J. Ø. Nielsen, editors, Telecoupling: Exploring Land-Use Change in a Globalised World: 149 175. Springer Nature Switzerland AG, Cham, Switzerland.   
Hulina, J., C. Bocetti, H. Campa III, V. Hull, W. Yang, and J. Liu. 2017. 4, 5, 6, 7 Telecoupling framework for research on migratory species in the Anthropocene. Elementa Science of the Anthropocene 5(5):5.   
Kastner, T., K. H. Erb, and H. Haberl. 2015. Global Human 1, 2 Appropriation of Net Primary Production for Biomass Consumption in the European Union, 1986-2007. Journal of Industrial Ecology 19(5):825 836.   
Kuemmerle, T., T. Kastner, P. Meyfroidt, and S. Qin. 2019. 15.4 Conservation Telecouplings. In C. Friis and J. Ø. Nielsen, editors, Telecoupling: Exploring Land-Use Change in a Globalised World: 281 302. Springer Nature Switzerland AG, Cham, Switzerland.   
Leisz, S. J., E. Rounds, N. T. An, N. T. B. Yen, T. N. Bang, S. 8 Douangphachanh, and B. Ninchaleune. 2016. Telecouplings in the East-West Economic Corridor within Borders and Across. Remote Sensing 8(12).   
Liu, J. 2014. Forest Sustainability in China and Implications for a 4, 6, 8 Telecoupled World. Asia & the Pacific Policy Studies 1(1):230 250.   
Liu, J. 2017. Integration across a metacoupled world. Ecology and 4 Society 22(4):29.   
Liu, J., Y. Dou, M. Batistella, E. Challies, T. Connor, C. Friis, J. D. A. Millington, E. Parish, C. L. Romulo, R. F. B. Silva, H. Triezenberg, H. Yang, Z. Zhao, K. S. Zimmerer, F. Huettmann, M. L. Treglia, Z. Basher, M. G. Chung, A. Herzberger, A. Lenschow, A. Mechiche-Alami, J. Newig, J. Roche, and J. Sun. 2018. Spillover systems in a telecoupled Anthropocene: typology, methods, and governance for global sustainability. Current Opinion in Environmental Sustainability 33:58 69.   
Liu, J., V. Hull, J. Luo, W. Yang, W. Liu, A. Viña, C. Vogt, Z. Xu, H. 1, 2, 3, 5, 8 Yang, J. Zhang, L. An, X. Chen, S. Li, Z. Ouyang, W. Xu, and H. Zhang. 2015a. Multiple telecouplings and their complex interrelationships. Ecology and Society 20(3):44.   
Liu, J., H. Mooney, V. Hull, S. J. Davis, J. Gaskell, T. Hertel, J. 0, 2, 3, 4 Lubchenco, K. C. Seto, P. Gleick, and C. Kremen. 2015. Systems

integration for global sustainability. Science 347(6225):1258832.   
Liu, J., W. Yang, and S. Li. 2016. Framing ecosystem services in the 2, 4 telecoupled Anthropocene. Frontiers in Ecology and the Environment 14(1):27 36.   
López-Hoffman, L., C. C. Chester, D. J. Semmens, W. E. Thogmartin, 2, 6 M. S. Rodriguez-McGoffin, R. Merideth, and J. E. Diffendorfer. 2017. Ecosystem Services from Transborder Migratory Species: Implications for Conservation Governance. Annual Review of Environment and Resources 42:509 539.   
López-Hoffman, L., J. Diffendorfer, R. Wiederholt, K. J. Bagstad, W. E. 1 Thogmartin, G. McCracken, R. L. Medellin, A. Russell, D. J. Semmens, L. Lopez-Hoffman, J. Diffendorfer, R. Wiederholt, K. J. Bagstad, W. E. Thogmartin, G. McCracken, R. L. Medellin, A. Russell, and D. J. Semmens. 2017. Operationalizing the telecoupling framework for migratory species using the spatial subsidies approach to examine ecosystem services provided by Mexican free-tailed bats. Ecology and Society 22(4):23.   
Marston, L., and M. Konar. 2017. Drought impacts to water footprints 9, 10 and virtual water transfers of the Central Valley of California. Water Resources Research 53(7):5756 5773.   
McCord, P., F. Tonini, and J. Liu. 2018. The Telecoupling GeoApp: A 3, 4 Web-GIS application to systematically analyze telecouplings and sustainable development. Applied Geography 96:16 28.   
Oberlack, C., S. Boillat, S. Brönnimann, J. D. Gerber, A. Heinimann, C. 4, 5 I. Speranza, P. Messerli, S. Rist, and U. Wiesmann. 2018. Polycentric governance in telecoupled resource systems. Ecology and Society 23(1):16.   
Pace, M. L., and J. A. Gephart. 2017. Trade: A Driver of Present and 2, 3 Future Ecosystems. Ecosystems 20(1):44 53.   
Parish, E. S., A. J. Herzberger, C. C. Phifer, and V. H. Dale. 2018. 1, 2, 3, 4 Transatlantic wood pellet trade demonstrates telecoupled benefits. Ecology and Society 23(1):28.   
Prell, C., L. Sun, K. Feng, J. He, and K. Hubacek. 2017. Uncovering the spatially distant feedback loops of global trade: A network and input-output approach. Science of the Total Environment 586:401 408.   
Quan, Y., C. Wang, Y. Yan, G. Wu, and H. Zhang. 2016. Impact of 2, 3 Inter-Basin Water Transfer Projects on Regional Ecological Security from a Telecoupling Perspective. Sustainability 8(2).   
Raya Rey, A. N., J. C. Pizarro, C. B. Anderson, F. Huettmann, J. 2, 3, 4 Cristobal Pizarro, C. B. Anderson, and F. Huettmann. 2017. Even

at the uttermost ends of the Earth: how seabirds telecouple the Beagle Channel with regional and global processes that affect environmental conservation and social-ecological sustainability. Ecology and Society 22(4):31.   
Reenberg, A., and N. A. Fenger. 2011. Globalizing land use transitions: 5, 6, 7 the soybean acceleration. Geografisk Tidsskrift-Danish Journal of Geography 111(1):85 92.   
Rulli, M. C., S. Casirati, J. Dell'Angelo, K. F. Davis, C. Passera, and P. 4, 5 2019. Interdependencies and telecoupling of oil palm expansion at the expense of Indonesian rainforest. Renewable and Sustainable Energy Reviews 105:499 512.   
Schaffartzik, A., H. Haberl, T. Kastner, D. Wiedenhofer, N. 3 Eisenmenger, and K.-H. Erb. 2015. Trading Land: A Review of Approaches to Accounting for Upstream Land Requirements of Traded Products. Journal of Industrial Ecology 19(5):703 714.   
Schaffer-Smith, D., S. A. Tomscha, K. J. Jarvis, D. Y. Maguire, M. L. 2, 3 Treglia, and J. Liu. 2018. Network analysis as a tool for quantifying the dynamics of metacoupled systems: an example using global soybean trade. Ecology and Society 23(4):3.   
Schierhorn, F., P. Meyfroidt, T. Kastner, T. Kuemmerle, A. V. 1, 2, 3 Prishchepov, and D. Müller. 2016. The dynamics of beef trade between Brazil and Russia and their environmental implications. Global Food Security 11:84 92.   
Seaquist, J. W., E. L. Johansson, and K. A. Nicholas. 2014. Architecture 2 of the global land acquisition system: applying the tools of network science to identify key vulnerabilities. Environmental Research Letters 9(11).   
Semmens, D. J., J. E. Diffendorfer, K. J. Bagstad, R. Wiederholt, K. 1, 3 Oberhauser, L. Ries, B. X. Semmens, J. Goldstein, J. Loomis, W. E. Thogmartin, B. J. Mattsson, and L. López-Hoffman. 2018. Quantifying ecosystem service flows at multiple scales across the range of a long-distance migratory species. Ecosystem Services 31:255 264.   
Silva, R. F. B., M. Batistella, Y. Dou, E. Moran, S. M. Torres, and J. 3 Liu. 2017. The Sino-Brazilian Telecoupled Soybean System and Cascading Effects for the Exporting Country. Land 6(3).   
Sun, J., H. Mooney, W. Wu, H. Tang, Y. Tong, Z. Xu, B. Huang, Y. 1 Cheng, X. Yang, D. Wei, F. Zhang, and J. Liu. 2018. Importing food damages domestic environment: Evidence from global soybean trade. Proceedings of the National Academy of Sciences of the United States of America 115(21):5415 5419.

<table><tr><td>Sun, J., Y. Tong, and J. Liu. 2017. Telecoupled land-use changes in distant countries. Journal of Integrative Agriculture 16(2):368-376.</td><td>1</td></tr><tr><td>Tapia-Lewin, S., K. Vergara, C. De La Barra, N. Godoy, J. Carlos Castilla, and S. Gelfich. 2017. Distal impacts of aquarium trade: Exploring the emerging sandhopper (Orchestoidea tuberculata) artisanal shore gathering fishery in Chile. Ambio 46(6):706-716.</td><td>4</td></tr><tr><td>Tonini, F., and J. Liu. 2017. Telecoupling Toolbox: spatially explicit tools for studying telecoupled human and natural systems. Ecology and Society 22(4):11.</td><td>6, 8, 10</td></tr><tr><td>Wyckhuys, K. A. G., W. Zhang, S. D. Prager, D. B. Kramer, E. Delaquis, C. E. Gonzalez, and W. van der Werf. 2018. Biological control of an invasive pest eases pressures on global commodity markets. Environmental Research Letters 13(9).</td><td>3 (upper and lower panel are separate cases)</td></tr><tr><td>Xiong, H., J. D. A. Millington, and W. Xu. 2018. Trade in the telecoupling framework: evidence from the metals industry. Ecology and Society 23(1):11.</td><td>2, 3, 4, 5, 6</td></tr><tr><td>Yang, D., J. Cai, V. Hull, K. Wang, Y. Tsang, and J. Liu. 2016. New road for telecoupling global prosperity and ecological sustainability. Ecosystem Health and Sustainability 2(10).</td><td>1</td></tr><tr><td>Yang, W., D. W. Hyndman, J. A. Winkler, A. Vina, J. M. Deines, F. Lupi, L. Luo, Y. Li, B. Basso, C. Zheng, D. Ma, S. Li, X. Liu, H. Zheng, G. Cao, Q. Meng, Z. Ouyang, and J. Liu. 2016. Urban water sustainability: framework and application. Ecology and Society 21(4):4.</td><td>3, 4</td></tr><tr><td>Yang, H., F. Lupi, J. Zhang, X. Chen, and J. Liu. 2018. Feedback of telecoupling: the case of a payments for ecosystem services program. Ecology and Society 23(2):45.</td><td>1</td></tr><tr><td>Yang, D., H. Y. Wan, T. K. Huang, and J. Liu. 2019. The role of citizen science in conservation under the telecoupling framework. Sustainability 11(4):1108.</td><td>1, 3</td></tr><tr><td>Yao, G., T. W. Hertel, and F. Taheripour. 2018. Economic drivers of telecoupling and terrestrial carbon fluxes in the global soybean complex. Global Environmental Change 50:190-200.</td><td>1</td></tr><tr><td>Zhang, J., T. Connor, H. Yang, Z. Ouyang, S. Li, and J. Liu. 2018. Complex effects of natural disasters on protected areas through altering telecouplings. Ecology and Society 23(3):17.</td><td>3, 5</td></tr></table>

# Appendix 2.

Table A2.1. Codebook.   

<table><tr><td>Code categories</td><td>Coding information</td></tr><tr><td colspan="2">General information</td></tr><tr><td>Telecoupling topic</td><td>Description: the main telecoupling topic of the visualization, based on its content and the figure caption.
Options: ‘commodity trade’, ‘land acquisition’, ‘conservation’, ‘water transfer’, ‘tourism’, ‘species migration’, ‘other’, or ‘combined topics’. 
Instructions: one option is to be selected</td></tr><tr><td>Data source type</td><td>Description: the type of data that served as input to the visualization.
Options: ‘primary’, ‘secondary’, ‘both’, or ‘data source not clear’. 
Instructions: one option is to be selected, and the methods section is to be consulted in addition to the visualization.</td></tr><tr><td colspan="2">Nodes</td></tr><tr><td>Node type</td><td>Description: the type of content that the visualized nodes represent.
Options: ‘systems’, ‘actors’, ‘action situation’, or ‘other’. 
Instructions: multiple options can be selected, e.g. if different options apply for different nodes.</td></tr><tr><td>Node representation</td><td>Description: Visual encoding strategy used for the visualized nodes
Options: ‘mark’ or ‘link attribute’. 
Instructions: multiple options can be selected, e.g. if different options apply for different nodes.</td></tr><tr><td>Spatial explicitness of nodes</td><td>Description: Spatially explicit representation of visualized node information.
Options: ‘yes’ or ‘no’. 
Instructions: multiple options can be selected, e.g. if different options apply for different nodes.</td></tr><tr><td colspan="2">Links</td></tr><tr><td>Link type</td><td>Description: The type of content that the visualized links represent.
Options: ‘flows’, ‘interactions’, ‘relations’, ‘similarity’, or ‘not defined’. 
Instructions: multiple options can be selected, e.g. if different options apply to different links. Flow mediums (e.g. roads or canal infrastructure) are coded under ‘flows’.</td></tr><tr><td>Link representation</td><td>Description: Visual encoding strategy used for the visualized links.
Options: ‘mark’ or ‘node attribute’. 
Instructions: multiple options can be selected, e.g. if different options apply to different links.</td></tr><tr><td>Spatial explicitness of links</td><td>Description: Spatially explicit representation of visualized link information.
Options: ‘yes’ or ‘no’. 
Instructions: multiple options can be selected, e.g. if different options apply to different links.</td></tr><tr><td>Systems</td><td></td></tr><tr><td>System boundary type</td><td>Description: types of system boundaries are used to delineate the visualized systems and indication of whether or not there is a reference to a geographical location.
Options: ‘world/rest of the world’, ‘world regions’, ‘supra-national governance unit’, ‘national governance unit’, ‘sub-national governance unit’, ‘spatial zoning’, ‘local governance unit’, ‘ecosystem-based’, ‘economic sectors/supply chains’, ‘other social-economic’, topographic-hydrological’, or ‘other’. 
Coding instructions: multiple options can be selected, e.g. if different options apply to different systems. This code category only applies to those cases where systems have been identified.</td></tr><tr><td>Geographic location of system</td><td>Description: Indication of whether the systems are presented in a location-specific way or not.
Options: ‘location-specific’ or ‘non-location-specific’. 
Coding instructions: multiple options can be selected, e.g. if different options apply to different systems. This code category only applies to those cases where systems have been identified.</td></tr><tr><td>System boundary detailed</td><td>Description: Specific information about the nature of the system boundaries of the visualized systems.
Coding instructions: Indicate how the visualized systems are delineated, e.g. ‘breeding sites in Mexico’. This code category only applies to those cases where systems have been identified.</td></tr><tr><td>Internal system elements and dynamics</td><td>Description: Presence of information about any elements and/or dynamics within any of the visualized systems.
Options: ‘yes’ or ‘no’. 
Coding instructions: one option is to be selected. This code category only applies to those cases where systems have been identified.</td></tr><tr><td>Internal system elements: actors</td><td>Description: Presence of information about actors within any of the visualized systems.
Options: ‘yes’ or ‘no’. 
Coding instructions: one option is to be selected. This code category only applies to those cases where systems have been identified.</td></tr><tr><td>Internal system elements: causes</td><td>Description: Presence of information about causes within any of the visualized systems.
Options: ‘yes’ or ‘no’. 
Coding instructions: one option is to be selected. This code category only applies to those cases where systems have been identified.</td></tr><tr><td>Internal system elements: effects</td><td>Description: Presence of information about effects within any of the visualized systems.
Options: ‘yes’ or ‘no’. 
Coding instructions: one option is to be selected. This code category only applies to those cases where systems have been identified.</td></tr><tr><td>System types: sending and receiving systems</td><td>Description: Explicit reference to sending and receiving system types in visualization or visualization caption.
Options: ‘yes’ or ‘no’. 
Coding instructions: one option is to be selected. This code category only applies to those cases where systems have been identified.</td></tr><tr><td>System types: spillover systems</td><td>Description: Explicit reference to spillover system types in visualization or visualization caption.
Options: ‘yes’ or ‘no’. 
Coding instructions: one option is to be selected. This code category only applies to those cases where systems have been identified.</td></tr><tr><td>Flows</td><td></td></tr><tr><td>Flow content type</td><td>Description: The type of content that the visualized flows represent.
Options: ‘material’, ‘capital’, ‘energy’, ‘humans’, ‘non-human living beings’, ‘information’, ‘virtual resources’, ‘virtual risks and benefits’, ‘ecosystem services’, ‘not specified’. 
Coding instructions: multiple options can be selected. This code category only applies to those cases where flows have been identified.</td></tr><tr><td>Flow content detailed</td><td>Description: Specific information about the content of the flows that are visualized.
Coding instructions: Indicate which contents the visualized flows represent, e.g. ‘remittances’. This code category only applies to those cases where flows have been identified.</td></tr><tr><td colspan="2">Other visualization characteristics</td></tr><tr><td>Visualization techniques</td><td>Description: Predominant chart type used for the visualization.
Coding instructions: Indicate the visualization techniques used.
Multiples can be listed, e.g. in case of a hybrid.</td></tr><tr><td>Visual attributes</td><td>Description: Visual attributes (cf. Figure 1) used in the visualization. Coding instructions: Take note of specific uses of visual attributes and which information the represent.</td></tr><tr><td>Temporal explicitness of visualization</td><td>Description: any temporal reference given for the information presented in the visualization, either in the visualization or its caption.
Options: ‘yes’ or ‘no’. 
Coding instructions: one option is to be selected.</td></tr><tr><td>Comparison across time</td><td>Description: Presentation of data across different moments in time.
Options: ‘yes’ or ‘no’. 
Coding instructions: one option is to be selected.</td></tr></table>

# Appendix 3.

Figure A3.1. Visual attributes in telecoupling visualizations.

An overview of visual attributes used to display node, link and temporal information in telecoupling visualizations, with illustrative case examples:

<table><tr><td>Telecoupling information</td><td>Visual attributes</td><td>Illustrative examples from cases</td></tr><tr><td colspan="3">Nodes</td></tr><tr><td>Node delineation
Examples:
- Indication of ‘hard’ system boundaries (vs. soft ones)
- Indication of porous system boundaries (vs. non-porous ones)</td><td>Categorical data:
- Color
- Pattern</td><td>• Bagstad et al. (2019), Fig. 2: fading colors used to indicate system boundaries
• Eakin et al. (2017), Fig. 3: dotted lines used to indicate system boundaries</td></tr><tr><td>Node type, characteristics, or context
Examples:
- Type of actor, or scale at which he/she operates
- Distinguishing receiving, sending and spillover systems through colors
- Degree centrality in networks (total number of links entering or leaving the node)</td><td>Categorical data:
- Color
Quantitative data:
- Node size
Relational data:
- Position
- Containment
All data types:
-Text labels
A, B, C, 1, 2, 3</td><td>• Chung et al. (2018), Fig. 3: Colors indicate types of systems
• Prell et al. (2017), Fig. 1: Node size indicates the countries’ export centrality
• Andriamihaja et al. (2019), Fig 2: actor node positions indicate actor levels and domains
• Carter et al. (2014), Fig. 4: containment attributes indicate the sub-systems
• Godar et al. (2019), Fig. 8.3: text labels provide detailed information on the presented systems, incl. potential impacts</td></tr><tr><td colspan="3">Links</td></tr><tr><td>Link direction:Examples:- Direction of species migration- Import &amp; export of commodity flows</td><td>Categorical data:- Line endings- Color- Text label, or indicated in figure caption or titleA, B, C, 1, 2, 3</td><td>· Boillat et al. (2018), Fig. 2: line endings indicate directions· López-Hoffman et al. (2017), Fig. 6: combination of line endings and line color to indicate direction· Garrett et al. (2013), Fig. 4: figure title indicates direction of flows</td></tr><tr><td rowspan="2">Link strength/magnitudeExamples:- Amount of soy being traded between different countries- Amount of land acquired for large-scale land acquisitions- Flow-linked impacts, such as deforestation risk embedded in soy flows</td><td>Quantitative data - through link attribute:- Line strength- Length of link marks- Text labelsA, B, C, 1, 2, 3</td><td>· Liu et al. (2015b), Fig. 2: line strength indicates the magnitude of the flows· Schierhorn et al. (2016), Fig. 3: length of bar indicates magnitude of trade flows· Semmens et al. (2018), Fig. 3: text labels indicate the specific link magnitude</td></tr><tr><td>Quantitative data - through node attribute:- Color saturation of nodes proportional to link strength- Size of nodes proportional to link strength</td><td>· Sun et al. (2018), Fig. 1: color of countries representing the systems indicate net imports of soy· Liu et al. (2015a), Fig. 2a: Size of bubbles representing the systems indicates the magnitude of the link</td></tr><tr><td>Link type, characteristics, or context:
Examples:
- Flow content (material, capital or information flows; or soybean or beef commodities)
- Differentiation of spring and fall migration of migrating species
- Impacts of trade flow (e.g. in CO2 emissions)</td><td>Categorical data:
- Color
- Pattern
- Symbols, photos
All data types:
- Text labels
A, B, C, 1, 2, 3</td><td>·Liu et al. (2016), Fig 2: line color indicates different line types
·Gasparri et al. (2016), Fig 4: line pattern indicates different types of actor relations
·Zhang et al. (2018), Fig. 5: photos and text labels to indicate link types
·Liu et al. (2017), Fig. 4: symbols indicate link type
·Godar et al. (2019), Fig. 8.3: text labels provide detailed information on trade flow and their impacts</td></tr><tr><td>Link connections
Examples:
- Linking countries on a map through arrows that represent commodity flows</td><td>Relational data:
- Connection</td><td>·Tonini et al. (2017), Fig. 6: connection attributes indicate links between telecoupled systems</td></tr><tr><td colspan="3">Other</td></tr><tr><td>Temporal data
Examples:
- Showing the change of the magnitude of commodity exports over time
- Illustrating how institutional setups change in telecoupled systems over time</td><td>Quantitative data:
- Position
- Color saturation
Categorical data:
- Position
- Textual labels
A, B, C, 1, 2, 3</td><td>·Reenberg &amp; Fenger (2011), Fig. 6: position of bar provides temporal reference
·Marston &amp; Konar (2017), Fig. 9: color attributes show net changes of flows across a certain time period
·Raya Rey et al. (2017), Fig. 2: position of information on timeline gives time indication
·Eakin et al. (2017), Fig. 3: text labels indicate differing temporal stages (t0, t1, ...)</td></tr></table>

Literature cited in Appendix 3:

Andriamihaja, O. R., F. Metz, J. G. Zaehringer, M. Fischer, and P. Messerli. 2019. Land Competition under Telecoupling: Distant Actors' Environmental versus Economic Claims on Land in North-Eastern Madagascar. Sustainability 11(3):851.   
Bagstad, K. J., D. J. Semmens, J. E. Diffendorfer, B. J. Mattsson, J. Dubovsky, W. E. Thogmartin, R. Wiederholt, J. Loomis, J. A. Bieri, C. Sample, J. Goldstein, and L. Lopez-Hoffman. 2019. Ecosystem service flows from a migratory species: Spatial subsidies of the northern pintail. Ambio 48(1):61 73.   
Boillat, S., J.-D. Gerber, C. Oberlack, J. G. Zaehringer, C. I. Speranza, S. Rist, and C. Ifejika Speranza. 2018. Distant Interactions, Power, and Environmental Justice in Protected Area Governance: A Telecoupling Perspective. Sustainability 10(11):3954.   
Carter, N. H., A. Viña, V. Hull, W. J. McConnell, W. Axinn, D. Ghimire, and J. Liu. 2014. Coupled human and natural systems approach to wildlife research and conservation. Ecology and Society 19(3):43.   
Chung, M. G., T. Dietz, and J. Liu. 2018. Global relationships between biodiversity and nature-based tourism in protected areas. Ecosystem Services 34:11 23.   
Eakin, H., X. Rueda, and A. Mahanti. 2017. Transforming governance in telecoupled food systems. Ecology and Society 22(4):32.   
Garrett, R. D., X. Rueda, and E. F. Lambin. 2013. Globalization's unexpected impact on soybean production in South America: linkages between preferences for non-genetically modified crops, eco-certifications, and land use. Environmental Research Letters 8(4).   
Gasparri, N. I., T. Kuemmerle, P. Meyfroidt, Y. le Polain de Waroux, and H. Kreft. 2016. The Emerging Soybean Production Frontier in Southern Africa: Conservation Challenges and the Role of South-South Telecouplings. Conservation Letters 9(1):21 31.   
Godar, J., and T. Gardner. 2019. Trade and Land-Use Telecouplings. In C. Friis and J. Ø. Nielsen, editors, Telecoupling: Exploring Land-Use Change in a Globalised World: 149 175. Springer Nature Switzerland AG, Cham, Switzerland.   
Liu, J. 2017. Integration across a metacoupled world. Ecology and Society 22(4):29.   
Liu, J., V. Hull, J. Luo, W. Yang, W. Liu, A. Viña, C. Vogt, Z. Xu, H. Yang, J. Zhang, L. An, X. Chen, S. Li, Z. Ouyang, W. Xu, and H. Zhang. 2015a. Multiple telecouplings and their complex interrelationships. Ecology and Society 20(3):44.   
Liu, J., H. Mooney, V. Hull, S. J. Davis, J. Gaskell, T. Hertel, J. Lubchenco, K. C. Seto, P. Gleick, and C. Kremen. 2015b. Systems integration for global sustainability. Science 347(6225):1258832.   
Liu, J., W. Yang, and S. Li. 2016. Framing ecosystem services in the telecoupled Anthropocene. Frontiers in Ecology and the Environment 14(1):27 36.   
López-Hoffman, L., C. C. Chester, D. J. Semmens, W. E. Thogmartin, M. S. Rodriguez-McGoffin, R. Merideth, and J. E. Diffendorfer. 2017. Ecosystem Services from

Transborder Migratory Species: Implications for Conservation Governance. Annual Review of Environment and Resources 42:509 539.   
Marston, L., and M. Konar. 2017. Drought impacts to water footprints and virtual water transfers of the Central Valley of California. Water Resources Research 53(7):5756 5773.   
Prell, C., L. Sun, K. Feng, J. He, and K. Hubacek. 2017. Uncovering the spatially distant feedback loops of global trade: A network and input-output approach. Science of the Total Environment 586:401 408.   
Raya Rey, A. N., J. C. Pizarro, C. B. Anderson, F. Huettmann, J. Cristobal Pizarro, C. B. Anderson, and F. Huettmann. 2017. Even at the uttermost ends of the Earth: how seabirds telecouple the Beagle Channel with regional and global processes that affect environmental conservation and social-ecological sustainability. Ecology and Society 22(4):31.   
Reenberg, A., and N. A. Fenger. 2011. Globalizing land use transitions: the soybean acceleration. Geografisk Tidsskrift-Danish Journal of Geography 111(1):85 92.   
Schierhorn, F., P. Meyfroidt, T. Kastner, T. Kuemmerle, A. V. Prishchepov, and D. Müller. 2016. The dynamics of beef trade between Brazil and Russia and their environmental implications. Global Food Security 11:84 92.   
Semmens, D. J., J. E. Diffendorfer, K. J. Bagstad, R. Wiederholt, K. Oberhauser, L. Ries, B. X. Semmens, J. Goldstein, J. Loomis, W. E. Thogmartin, B. J. Mattsson, and L. López-Hoffman. 2018. Quantifying ecosystem service flows at multiple scales across the range of a long-distance migratory species. Ecosystem Services 31:255 264.   
Sun, J., H. Mooney, W. Wu, H. Tang, Y. Tong, Z. Xu, B. Huang, Y. Cheng, X. Yang, D. Wei, F. Zhang, and J. Liu. 2018. Importing food damages domestic environment: Evidence from global soybean trade. Proceedings of the National Academy of Sciences of the United States of America 115(21):5415 5419.   
Tonini, F., and J. Liu. 2017. Telecoupling Toolbox: spatially explicit tools for studying telecoupled human and natural systems. Ecology and Society 22(4):11.   
Zhang, J., T. Connor, H. Yang, Z. Ouyang, S. Li, and J. Liu. 2018. Complex effects of natural disasters on protected areas through altering telecouplings. Ecology and Society 23(3):17.
