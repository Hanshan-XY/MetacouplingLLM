Letter

# Exploring the Spatio-Temporal Dynamics of Winter Rape on the Middle Reaches of Yangtze River Valley Using Time-Series MODIS Data

Jianbin Tao 1 , Wenbin $\mathbf { W _ { u } } ^ { 2 , * }$ , Wenbin Liu 3 and Meng Xu 1

1 Key Laboratory for Geographical Process Analysis & Simulation of Hubei province, School of Urban and Environmental Sciences, Central China Normal University, Wuhan 430079, China; taojb@mail.ccnu.edu.cn (J.T.); xumeng1216@mails.ccnu.edu.cn (M.X.)   
2 Key Laboratory of Agricultural Remote Sensing, Institute of Agricultural Resources and Regional Planning, Ministry of Agriculture, Chinese Academy of Agricultural Sciences, Beijing 100081, China   
3 State Key Laboratory of Information Engineering in Surveying, Mapping and Remote Sensing, Wuhan University, Wuhan 430070, China; liuwenbin@whu.edu.cn   
￥ Correspondence: wuwenbin@caas.cn; Tel.: +86-10-82105070

Received: 10 November 2019; Accepted: 1 January 2020; Published: 8 January 2020

![](images/2e4a2bbb178815f8059397eeeabb6dc2c2a50395494189b5dcfaabbed64f6f61.jpg)

- -

Abstract: Rapeseed is an important oil product in China. China’s current soybean trade issues with major soybean producing countries have caused a large decline in soybean import since 2017. This may bring the increasing needs of rapeseed import, which would have an impact on domestic production. However, our knowledge on the effects of international rapeseed trade on domestic production remains unknown. It is thus important to understand the pattern of rapeseed in China under this scenario, as it may provide necessary information for all relevant stakeholders. With this goal, this study aims to investigate the spatial and temporal patterns of winter rape in China’s major winter rape production region, the Middle Reaches of the Yangtze River Valley (MYR), during 2003–2015 using time-series Moderate Resolution Imaging Spectroradiometer (MODIS) data. A decision tree according to the difference in enhanced vegetation index (EVI) profiles of land-cover types was built to extract winter rape. The results show that there is an essential decrease in both the number and density of winter rape patches under the opening global rapeseed market. There are significant hotspots of winter rape gain and loss, within which the loss dominated the trend. The significant cost advantage of rapeseed in the international market may largely reduce the domestic cultivation in China through telecoupling effects. Understanding the spatio-temporal dynamics of winter rape on the MYR has significant economic and policy implications and can provide great supports for the agricultural production, policy-making, and oil products trade in the international market.

Keywords: international rapeseed trade; winter rape; spatio-temporal patterns; MYR; time-series MODIS data

# 1. Introduction

Rapeseed is a major source of vegetable oil all over the world [1], as well as an important oil crop in China. Winter rape is mainly concentrated in the Yangtze River Valley [2], taking up over $9 0 \%$ of the rapeseed share in China. Rapeseed and soybean are substitutes for each other when being used as vegetable oil. Rapeseed oil used to rank first in China’s cooking oil market, however, it has been replaced by soybean oil since 2003 [2]. After joining the World Trade Organization (WTO), China’s soybean market has been deeply integrated into the global market. Soybean import has a serious impact on domestic soybean production in China owing to low tariffs on import and decreasing comparative benefit of soybean planting [3–5]. China’s soybean imports accounted for $4 1 \%$ of the world

total in 2005 and topped the world in 2017 [6,7]. Currently, over $8 0 \%$ of China’s soybean consumption is imported [8,9]. This large import of soybean from the international market has put great pressure on China’s domestic soybean cultivation, resulting in a substantial shrinkage in soybean planting areas [10,11].

Similarly, the latest statistics show that rapeseed imports have also largely increased and replaced most of the market share in China owing to its advantages of low price and high oil output. Chinese rapeseed imports approached $4 2 8 \mathrm { k }$ tons in 2007 and have soared since then. The imports reached 1.56 million tons in 2013 and then dropped in 2014, but still ran high at about $8 0 0 \mathrm { k }$ tons until 2017 (Figure 1). The exports, however, are far less than the imports during the observed years, except in 2006. As a member of the World Trade Organization, international trade has impacts on domestic prices in agricultural sector. When increased imports affect China’s domestic price, producers will feel the price shifts and adjust the cropping pattern [12].

![](images/c55fa5050543fa2bd208ee5c8329e20f8eff1b73cd478f49462f0a20fb5912c5.jpg)  
Figure 1. Rapeseed import/export quantity in China from 2000 to 2017. Data source: the Statistics Figure 1. Rapeseed import/export quantity in China from 2000 to 2017. Data source: the StatistDivision of the Food and Agriculture Organization of the United Nations at http://faostat.fao.org/.

These statistics raise an important question: whether the story of soybean happens to winter These statistics raise an important question: whether the story of soybean happens to winter rape? Does the free international rapeseed trade stress China’s domestic rapeseed production? Where rape? Does the free international rapeseed trade stress China's domestic rapeseed production? Where winter rape is still grown, increasing or decreasing? Agricultural production is dependent on economic winter rape is still grown, increasing or decreasing? Agricultural production is dependent on drivers together with the challenges of urbanization and climate change, which is increasing the economic drivers together with the challenges of urbanization and climate change, which is need for timely agricultural monitoring. Timely and accurate monitoring of the spatial and temporal increasing the need for timely agricultural monitoring. Timely and accurate monitoring of the spatial dynamics of winter rape is of great importance not only for the rapeseed sector and national food and temporal dynamics of winter rape is of great imposecurity, but also for all other relevant stakeholders [13].

onal food security, but also for all other relevant stakeholders [13]. Remote sensing has been proven to be a valuable technique to provide large-scale multi-temporal Remote sensing has been proven to be a valuable technique to provide large-scale multi-data, and has been widely used to map individual crops or cropping structure owing to its low cost and temporal data, and has been widely used to map individual crops or cropping structure owing to its high efficiency. Remote sensing can also significantly contribute to agricultural systems monitoring low cost and high efficiency. Remote sensing can also significantly contribute to agricultural systems such as anomaly hot spots of agricultural production over large areas [14]. The literature shows monitoring such as anomaly hot spots of agricultural production over large areas [14]. The literature that there are many studies to map grain crops in China such as rice, wheat, and soybean [15–19]. shows that there are many studies to map grain crops in China such as rice, wheat, and soybean [15–Yet, these studies are mainly conducted in Northeast or North China, and fewer in Central and South 19]. Yet, these studies are mainly conducted in Northeast or North China, and fewer in Central and China. Moreover, there have been fewer mapping activities on winter rape using remote sensing South China. Moreover, there have been fewer mapping activities on winter rape using remote data. The existing winter rape mapping literatures are limited in local regions, which makes it difficult sensing data. The existing winter rape mapping literatures are limited in local regions, which makes to understand the dynamic changes in winter rape cultivation [20,21]. It is necessary to develop a it difficult to understand the dynamic changes in winter rape cultivation [20,21]. It is necessary to method for large-scale winter rape mapping, so as to understand its spatio-temporal changes over develop a methtime and space.

ges over time and space. The objective of this study is thus to investigate and understand the spatial and temporal dynamics The objective of this study is thus to investigate and understand the spatial and temporal of winter rape in China in the context of international rapeseed trade. To be specific, time-series

Moderate Resolution Imaging Spectroradiometer (MODIS) data were used to explore the spatial and temporal patterns of winter rape production in China’s major winter rape production region,Sustainability 2020, 12, x FOR PEER REVIEW 3 of 13 the Middle Reaches of the Yangtze River Valley (MYR). A decision tree was built to extract winter rape from time-series MODIS data. Two MODIS products, Terra and Aqua, were combined to minimize the impact of the cloud interference. We further extracted the hot spots of winter rape gain and loss, and measured the changes of spatial fragmentation using some landscape indices. Information on the spatial and temporal patterns of winter rape can help estimate total winter rape production on theInformation on the spatial and temporal patterns of winter rape can help estimate total winter rape MYR and predict the rapeseed demand from oil-exporting countries.production on the MYR and predict the rapeseed demand from oil-ex

# 2. Materials and Methods

# 2.1. Study Area

The study area is in the Middle Reaches of the Yangtze River Valley, including Hubei Province,The study area is in the Middle Reaches of the Yangtze River Valley, including Hubei Province, parts of Henan province, Hunan Province, Anhui Province, and Jiangxi Province (Figure 2). It containsparts of Henan province, Hunan Province, Anhui Province, and Jiangxi Province (Figure 2). It several plains and the croplands account forcontains several plains and the cropland $4 3 . 1 5 \%$ of the total. Only parts of those provinces (exceptnt for 43.15% of the total. Only parts of those Hubei Province) were included because winter rape is concentrated on these areas within MYR. Withprovinces (except Hubei Province) were included because winter rape is concentrated on these areas the rise of Central China and the promotion of national strategies such as the Yangtze River Economicwithin MYR. With the rise of Central China and the promotion of national strategies such as the Belt, the MYR has become an important economic growth pole of China. As the largest and mostYangtze River Economic Belt, the MYR has become an important economic growth pole of China. As concentrated winter-rape-growing region, the MYR takes the lion’s share. Approximatelythe largest and most concentrated winter-rape-growing region, the MYR takes the lion $5 5 \%$ of theare. total annual winter rape production in the Yangtze River Valley was sourced from the MYR over theApproximately 55% of the total annual winter rape production in the Yangtze River Valley was past decade [2]. The MYR has also been one of the major areas with a rapid decrease of croplands insourced from the MYR over the past decade [2]. The MYR has also been one of the major areas with the last 20 years [22].a rapid decrease of

![](images/e7a9253ca6bd9516ebda86c69811230a0ea6f4f01ea0bf3461fc7d02ac531354.jpg)  
Figure 2. The study area and the main land-cover types in 2010 from MCD12Q1 UMD datasets, which were from the standard MODIS land cover type data product in the IGBP Land Cover Type Classification. UMD, University of Maryland. MODIS, Moderate Resolution Imaging Spectroradiometer. Spectroradiometer. IGBP, International GeospherIGBP, International Geosphere-Biosphere Program.

# 2.2. Data

The MODIS MOD13Q1 and MYD13Q1 v006 data were used in this study, which were recorded by the EOS (Earth Observing System) /Terra and EOS/Aqua Satellite, respectively. We selected 2003 and 2015 as observation years, because we can get high-quality sampling data in these years, and they span more than one decade so as to observe the trend of winter rape distribution. The MOD13Q1 and

MYD13Q1 products include $2 5 0 ~ \mathrm { m }$ resolution normalized difference vegetation index (NDVI) and enhanced vegetation index (EVI) data. Vegetation index measures the density of live green vegetations, and time-series vegetation index captures the phenological differences of varied land-cover types. The MODIS image sequence numbers of the tile covering the research area are h27v05, h27v06, h28v05, and h28v06 (h: horizontal, v: vertical). EVI layer was used in our study because it handles the saturation problems better compared with NDVI [23]. Landsat 8 OLI (Operational Land Imager) and GF-1 (GaoFen-1) remote sensing images were analyzed together to prepare winter rape samples.

All the data preprocessing (including geographical geometric correction, re-sampling, and filtering) was the same as in the work of [24]. TimeSat software was used to resconstruct the MODIS time-series [25]. The Savitzky–Golay (S–G) algorithm was used to smooth the time-series EVI to derive optimized time-series datasets.

# 2.3. Extraction of Rapeseed Distribution

The appropriate period to extract winter wheat areas using satellite images is the date between middle March and early April. However, this period is so short that it may be inundated by the low time resolution of the 16-day composites. Another problem is the EVI disorder caused by time disorder if MOD13Q1-EVI and MYD13Q1-EVI were simply merged [26]. Following the method of [26], we developed an eight-day time-series EVI data by merging the 16-day Terra and Aqua MODIS EVI time-series. Firstly, a threshold (blue band reflectivity $\geq 0 . 2 1$ ) was set to eliminate the pixels with heavy clouds. Then, an EVI time-series with less cloud interference and time disorder was obtained by combining the composite day of year and pixel reliability data.

Our previous research revealed that winter crops have unique phenological characteristics differing from the background [27]. Therefore, principle components analysis (PCA) was performed on the EVI profile, covering the winter crops’ growing season. the Iterative Self-Organizing Data Analysis Techniques Algorithm was conducted to identify winter crops planting areas using the first three PCA components.

Winter rape and winter wheat are two major winter crops on the MYR and they have similar phenophases; the key issue of extracting winter rape is thus how to distinguish winter rape from winter wheat. In the window period from middle March to early April, winter rape and winter wheat are in different stages and show different colors on true-color satellite images [27]. By observing this difference in GF-1 images, we can collect winter rape samples on MODIS data. The EVI curves of these two winter crops have an opposite change trend after DOY (day of a year; day indicates Julian day, the number of days since the beginning of the year) 065 (Figure 3), which clearly shows the ability of EVI profiles in discriminating the winter crops. Finally, a decision tree rule $\mathrm { ( E V I D O Y 0 6 5 + E V I D O Y 0 8 9 ) } > \mathrm { ( E V I D O Y 0 7 3 + E V I D O Y }$ $>$ 081) was established to extract winter rape from winter crops. If the rule is satisfied, the pixel is considered as winter rape. The main steps of extracting winter rape are summarized in Figure 4.

![](images/a8973c8063f235d7f4edba0ba8489901b75b184e652d6c4aa82ef18ec74b4c44.jpg)  
Figure 3. Enhanced vegetation index (EVI) curves for dominant winter crops within their lifecycle. Figure 3. Enhanced vegetation index (EVI) curves for dominant winter crops within their lifecycle. DOY, Julian day of DOY, Julian day of a year.

![](images/1420d00e0eefbe92189bee79ee4d690f0bf75447f6806c9017bedcc4be2cb5d9.jpg)  
Figure 4. Flowchart of extracting winter rape. PCA, principle components analysis. ISODATA, Figure 4. Flowchart of extracting winter rape. PCA, principle components analysis. ISODATA, Iterative Self-Organizing Data Analysis Techniques Algorithm.

In this way, phenological information contained in time-series remote sensing data was fully utilized to accurately map winter rape at a large-scale.

# 2.4. Spatio-Temporal Patterns of Winter Rape Cultivation

The spatial and temporal patterns of winter rape were investigated in terms of changes in planting area and spatial aggregation. To map the changes in winter rape planting area on the MYR, firstly, a change detection was used to map the hotspots of the changes at pixel level between 2003 and 2015. Then, the winter rape area in 2003 versus the winter rape area in 2015, as well as winter rape gain and and 2015. Then, the winter rape area in 2003 versus the winter rape area in 2015, as well as winter loss, were analyzed by plotting their accumulated pixels versus abundance level using a frequency histogram. The abundance here is a normalized metric of pattern measurement, which can be used to assess the trend of winter rape planting area. The original $2 5 0 \mathrm { m }$ winter rape maps were aggregated to 2000 m image blocks to get a fractional map.

Spatial aggregation measures if the spatial pattern of winter rape is more dispersed or clustered. Global spatial autocorrelation was used to explore the spatial pattern of winter rape distribution. Global spatial autocorrelation was used to explore the spatial pattern of winter rape distribution. Moran’s Index indicates the spatial pattern of the data (clustering or dispersing) and the Z score and $p$ -value can evaluate the significance of Moran’s index. We also measured the landscape pattern using landscape indicator. Several widely used indicators, NP (number of patches), PD (patch density), MPA (mean patch area), LPI (largest patch index), SI (splitting index), and AI (aggregation index) were selected as the indicators for reflecting landscape fragmentation. The calculations of these indicators are based on FRAGSTATS [28].

# 3. Results and Analysis

# 3.1. Validation of Classification Accuracy

The true color composites from GF-1/Landsat 8 images and the modeled results are shown in Figure 5 (two sample areas in Hubei Province and Anhui Province were selected, respectively, taking the year 2015 as an example). From a visual interpretation, the winter rape pixels in these two sources have good spatial agreement.

The modeled results were validated by referencing the samples from high resolution images for the year 2015 using correlation analysis. Both the modeled result and the sample data from GF-1/Landsat 8 images were aggregated to $2 0 0 0 \mathrm { m }$ fractural images by averaging the binary values within each block to facilitate analysis. The validation demonstrated that there is strong correlation, with correlation coefficients of 0.77 and 0.80, respectively (Figure 6). The deviation was acceptable, evidencing the feasibility of the model in winter rape mapping.

Fragmented fields in the study area that are typically smaller than the size of one MODIS pixel and highly heterogeneous cropping practices may result in sub-pixel heterogeneity and uncertainty of the winter rape maps. The cloud cover, noises, and biases in MODIS time-series and the quality of winter rape samples may also result in uncertainty of the result. However, the accuracy is sufficient when it is used to observe the overall trend at regional scale.

![](images/2915ec6c2688ed9619cda5e0a4915ca5beb5eb8ecbefa990aff8e35462ed4e5c.jpg)

![](images/9669a087cb03ea49bcdb9dce9603a2faa394fe1f8a213c2479412441a5fda532.jpg)  
(a)   
(b)

![](images/dca44edaade4d0343bf9d1d9a64f3004aa3c84db9b5634a733676d80f54e30ae.jpg)  
Figure 5. Comparison of the winter rape distributions from different sources (true-color composites Figure 5. Comparison of the winter rape distributions from different sources (true-color composites vs. vs. the decision tree modeled results), (a) sample area in Hubei Province, (b) sample area in Anhui the decision tree modeled results), (a) sample area in Hubei Province, (b) sample area in Anhui Province.Sustainability 2020, 12, x FOR PEER REVIEW 7 of 13   
(a)

![](images/f1332b8b1e3e1dd8dde1e0717e85e987ac59ebf2a0a71a3de34d9ed62c7ea0c3.jpg)  
(b)   
Figure 6. Validation of modeled results, (a) sample area in Hubei Province, (b) sample area in Anhui Figure 6. Validation of modeled results, (a) sample area in Hubei Province, (b) sample area in Anhui Province.

# 3.2. Temporal Changes in Rapeseed Cultivation

and highly heterogeneous cropping practices may result in sub-pixel heterogeneity and uncertainty The total plating area on the MYR dropped significantly, from 3,486,405 k ha in 2003 to 1,862,287 of the winter rape k ha in 2015, at a rate of $- 4 6 . 6 \%$ cloud cover, noises, and biases in MODIS time-series and the quality of  (Table 1). Except for a slight increase in Jiangxi Province, there are winter rape samdrastic declines (about $- 5 0 \%$ ay also result in uncertainty of the result. However, the accuracy is sufficient ) in all the provinces. This slight increase in Jiangxi Province can be partly explained as the boom of rapeseed-flower-tourism in recent years.

3.2. Temporal Changes in Rapeseed Cultivation The changes of winter rape cultivation are intensive (Figure 7a). Although the total area has The total plating area on the MYR dropped significantly, from 3,486,405 k ha in 2003 to 1,862,287 decreased (Table 1), there was also significant winter rape gain, which mainly located in the areas

along the Yangtze River in Anhui Province (Figure 7b). Winter rape loss was more widely distributed, and there were widespread hotspots of winter rape loss in the research area (Figure 7c).

The profiles in Figure 8 showed the number of winter rape pixels in 2003 versus winter rape pixels in 2015, and winter rape gain versus winter rape loss in relation to their abundance. The abundance is the percentage of winter rape areas in a given grid $( 2 \mathrm { k m } )$ , and the pixel number is the sum of winter rape pixels at the same abundance level.

Table 1. The summarized winter rape areas in the study area (k ha).   

<table><tr><td>Provinces</td><td>2003</td><td>2015</td><td>Changing Amount</td><td>Changing Rate (%)</td></tr><tr><td>Henan</td><td>354,864.40</td><td>181,419.30</td><td>-173,445.10</td><td>-48.9</td></tr><tr><td>Hubei</td><td>1,615,787.00</td><td>839,704.60</td><td>-776,082.40</td><td>-48.0</td></tr><tr><td>Hunan</td><td>299,374.20</td><td>141,926.40</td><td>-157,447.80</td><td>-52.6</td></tr><tr><td>Anhui</td><td>1,064,767.00</td><td>526,301.20</td><td>-538,465.80</td><td>-50.6</td></tr><tr><td>Jiangxi</td><td>151,612.50</td><td>172,936.00</td><td>21,323.50</td><td>14.1</td></tr><tr><td>Total</td><td>3,486,405.10</td><td>1,862,287.50</td><td>-1,624,117.60</td><td>-46.6</td></tr></table>

![](images/d19920babdec09282141d57c6a8bd8a4398b9fda033d45dff19a90e945d7ea84.jpg)

![](images/aee8ca30a52339d6064265ecc6271e5ea43a56d039b9400c4af6168f39446ff3.jpg)  
(a)   
(b)   
Figure 7. Cont.

![](images/cf443eeae0c511a7551c443c8b7487c38b2add4efbd9d7fa2f56ae807c7e1d36.jpg)  
(c) ber of

![](images/1b5346ef849b7f9238a40f59c3bc7a4caf06a829127f152e98f72be3fa4ed729.jpg)  
Figure 7. Hotspots of winter rape dynamics from 2003 to 2015 on the Middle Reaches of the Yangtze Figure 7. Hotspots of winter rape dynamics from 2003 to 2015 on the Middle Reaches of the Yangtzeabundance is the percentage of winter rape areas in a given grid (2 km), and the pixel number is the River Valley (MYR), China. (a) Changes of winter rape, (b) hotspots of winter rape gain, (c) hotspots River Valley (MYR), China. (a) Changes of winter rape, (b) hotspots of winter rape gain, (c) hotspots ofThe profiles for winter rape area in 2003 and 2015 were skewed to the left, which indicated the winter rape loss. Names of provincial-level regions are also shown. Color bars in (b) and (c) indicatefragmented winter rape patches on the MYR. The bars in 2003 were higher than those of 2015 (Figure the change rate of winter rape frombars for winter gain and loss $0 \%$ (light color) toa similar pattern to t $1 0 0 \%$ (dark color). The originalFigure 8a. The profile of winter rape $2 5 0 \mathrm { m }$ change maps were aggregated toloss was higher $2 0 0 0 \mathrm { m }$ image blocks.f winter rape gain,

![](images/e58559882c5bde846ce583a4c06091564690ebe0f9fad5a5282bae019aac2c52.jpg)  
(a)   
(b)   
Figure 8. Winter rape dynamics in relation to their abundance on the MYR, China. (a), Winter rape area 2003 (cyan bars) vs winter rape area 2015 (dark green bars). (b), winter rape gain (green bars) vs winter rape loss (red bars).

The profiles for winter rape area in 2003 and 2015 were skewed to the left, which indicated the fragmented winter rape patches on the MYR. The bars in 2003 were higher than those of 2015 (Figure 8a), which indicated a net loss of winter rape planting area at all abundance levels. In Figure 8b, the bars for winter gain and loss have a similar pattern to those in Figure 8a. The profile of winter rape loss was higher than that of winter rape gain, which also indicated a net loss of winter rape.

# 3.3. Spatial Fragmentation of Rapeseed Cultivation

Global autocorrelation analysis indicated that the winter rape distribution exhibits a clustered pattern at a 0.01 significance level. Moran’s I indicated (Table 2) that winter rape in 2015 had a little bit more dispersed pattern than that of 2003.

Table 2. Global autocorrelation analysis of winter rape distribution.   

<table><tr><td>Indicators</td><td>Moran&#x27;s I</td><td>Z-score</td><td>p-value</td></tr><tr><td>2003</td><td>0.53</td><td>10.0</td><td>0</td></tr><tr><td>2015</td><td>0.41</td><td>7.8</td><td>0</td></tr></table>

All the selected landscape indicators showed a clear trend that the winter rape landscape of 2015 was more fragmented than that of 2003. To be specific, the PD, MPA, SI, and AI changed significantly, and LPI had a dramatic decrease from 0.80 to 0.15 (Table 3).

Table 3. Landscape indexes of winter rape distribution. NP, number of patches; PD, patch density; MPA, mean patch area; SI, splitting index; AI, aggregation index; LPI, largest patch index.   

<table><tr><td>Indicators</td><td>NP</td><td>PD</td><td>MPA</td><td>LPI</td><td>SI</td><td>AI</td></tr><tr><td>2003</td><td>64,097</td><td>0.16</td><td>54</td><td>0.80</td><td>5697</td><td>64</td></tr><tr><td>2015</td><td>43,728</td><td>0.11</td><td>43</td><td>0.15</td><td>104,558</td><td>52</td></tr></table>

Overall, the spatial aggregation of winter rape decreased, but the pattern of concentration in the main producing areas did not change greatly.

# 4. Discussion

This study showed that there was an obvious shrinkage of winter rape planting areas on the MYR, although some regions also gained area. There are many reasons that may drive these changes. Firstly, the rapeseed industry may suffer from international rapeseed trade. As shown in Figure 1, China is now the largest rapeseed importer in the world and there is a large increase in rapeseed import in recent years. A total of $9 5 \%$ of the imported rapeseeds were from Canada. It can be seen from Table 4 that the labor cost of winter rape is about 560 CNY/Mu and accounts for $6 2 \%$ of the total input and is the largest input in China [29]. However, materials input is the largest input for Canada’s rapeseed production and the labor cost is only about 33 CNY/Mu and account for $8 \%$ of the total input. The trade competitiveness (TC) index was used to evaluate the competitiveness of China’s rapeseed in the international market [3] by selecting five top rapeseed producing countries (Canada, China, India, France, and Australia) in the world for comparison. The TC index has a data range of 0~1. China’s TC index is close to $^ { - 1 }$ , indicating a very uncompetitive level in the international rapeseed market (Figure 9). The imported rapeseed with a lower cost and higher oil output could bring great pressure on China domestic rapeseed production. The historical story of soybean in China happened to some extent to the rapeseed sector, too. Secondly, domestically, labor force shortage has pushed up agricultural labor input. The rapid urbanization and fast development of the market economy have caused intensive migration of laborers from rural areas to urban areas, which has resulted in serious shortages in the agricultural labor force. It is very common for farmers to enter cities and find new work to obtain a higher income. With the shortage of the labor force, labor cost is increasing and the

comparative benefit of winter rape planting is low or even loses money [30]. Therefore, a large amount of croplands remained fallow during the first growing season, leading to a significant decline in winter rape cultivation.

Table 4. Comparison of the winter rape input between Canada and China (CNY/Mu).   

<table><tr><td rowspan="2">Input</td><td rowspan="2">Land</td><td colspan="4">Materials</td><td rowspan="2">Labor</td><td rowspan="2">Total</td></tr><tr><td>Subtotal</td><td>Seed</td><td>Pesticide</td><td>Mechanism</td></tr><tr><td>China</td><td>120.8</td><td>223.7</td><td>19.1</td><td>15.2</td><td>59.5</td><td>559.3</td><td>903.7</td></tr><tr><td>Canada</td><td>58.8</td><td>349.7</td><td>57.2</td><td>59.2</td><td>23.8</td><td>32.8</td><td>441.4</td></tr></table>

![](images/d4a9c236655b0a4ee4db98de397b229792b1ab897021594d04480f4afa64e4a6.jpg)  
Figure 9. Trade competitiveness (TC) index of rapeseed for five top rapeseed producing countries (Canada, China, India, France, and Australia) in 2017. The data used to calculate TC index were sourced (Canada, China, India, Frafrom http://faostat.fao.org/.

The MYR has great potential for winter rape producing as the natural environment in this area is Table 4. Comparison of the winter rape input between Canada and China (CNY/Mu). more suitable for winter rape. However, the external and internal factors have recently driven the Materials decline in winter rape cultivation. The depression of rapeseed production in China creates a striking Input Land Labor Total Subtotal Seed Pesticide Mechanism contrast with the thriving of rapeseed production in the world [30]. This has raised worries about the China 120.8 223.7 19.1 15.2 59.5 559.3 903.7 potential collapse of this cropping system and the concerns on how to maintain the advantages of this area for winter rape production in China. To ensure oil production, the government may need to encourage farmers’ willingness to plant winter rape by increasing their income. Some policies need to The MYR has great potential for winter rape producing as the natural environment in this area be enacted to promote scale management of agriculture, raise the level of mechanization, and reduce is more suitable for winter rape. However, the external and internal factors have recently driven the labor cost. Only by doing so, can the competitiveness of domestic rapeseed be improved, and the decline in winter rape cultivation. The depression of rapeseed productiofarmers are willing to maximize the potential of winter rape production.

# contrast with th5. Conclusions

area for winter rape production in China. To ensure oil production, the government may need to The spatial and temporal patterns of winter rape on the MYR can provide valuable information encourage farmers’ willingness to plant winter rape by increasing their income. Some policies need for rapeseed production and sustainable development of the oil market. This study explored the to be enacted to promote scale management of agriculture, raise the level of mechanization, and spatial and temporal patterns of winter rape on the MYR of mainland China. It is found that there is a reduce labor cost. Only by doing so, can the competitiveness of domestic rapeseed be improved, and substantial shrinkage and a net loss of winter rape planting. The results also show decreased spatial the farmers are willing to maximize the potential of winter rape production. aggregation of winter rape extent. The international rapeseed trade and domestic labor cost have pressed rapeseed cultivation in China.

As China’s demand for cooking oil will continue to rise, self-sufficiency in oil product and a steady supply of rapeseed oil is strongly needed. Without effective intervention, the winter rape production on the MYR may continue to decline. Because the Yangtze River Valley is the largest rapeseed production belt in the world, among which the MYR is the largest producer in China [31], this decline may serve as a caution to the Chinese rapeseed industry. Promoting growth in the planting area and the yield of winter rape in this region is an important way of ensuring China’s oil supply capacity and the sustainable development of rapeseed industry.

Author Contributions: Conceptualization, J.T. and W.W.; methodology, J.T.; validation, J.T. and W.L.; formal analysis, J.T.; investigation, W.L.; resources, J.T.; data curation, M.X.; writing—original draft preparation, J.T.; writing—review and editing, J.T. and W.W.; supervision, J.T.; project administration, J.T.; funding acquisition, W.W. All authors have read and agreed to the published version of the manuscript.

Funding: This work was founded by the National Natural Science Foundation of China (41971371), National Natural Science Foundation of China (41871356), and Fundamental Research Funds for the Central Universities (CCNU19TS004 and CCNU19TD002).

Acknowledgments: The authors would like to thank the anonymous reviewers for their comments and suggestions on this paper.

Conflicts of Interest: The authors declare no conflict of interest.

