Article

# Smallholder Telecoupling and Climate Governance in Jambi Province, Indonesia

Yvonne Kunz 1,*, Fenna Otten $^ { 1 , * \oplus }$ , Rina Mardiana 2, Katrin Martens 3, Imke Roedel 1 and Heiko Faust 1

Department of Human Geography, Georg-August-University of Goettingen, 37073 Göttingen, Germany; imke.roe@gmail.com (I.R.); hfaust@gwdg.de (H.F.)   
2 Department of Human Ecology, Institut Pertaninan Bogor, Bogor 16680, Indonesia; rina_nrf@yahoo.com   
3 Department of Agricultural Economics, Humboldt University Berlin, 10099 Berlin, Germany; katrin.martens@hu-berlin.de   
* Correspondence: Yvonne.Kunz@geo.uni-goettingen.de (Y.K.); fenna.otten@geo.uni-goettingen.de (F.O.)

Received: 26 February 2019; Accepted: 3 April 2019; Published: 10 April 2019

![](images/80fe3016497ddb67363fbc92b24710e23e5dcd7f58cfea44e406492d60bfc072.jpg)

- -

Abstract: Current debates on climate change have led to an increased demand for sustainable commodities. Serving this demand, sustainability certification schemes and eco-friendly labels have become prominent mechanisms of climate governance. Smallholder farmers in Jambi province, Indonesia, producing palm oil and rubber as the two dominant smallholder crops, are impacted by this distal demand. Zimmerer et al. (2018) suggest analyzing the potential sustainability in such a context with the multilevel smallholder telecoupling framework. Applying this framework to case studies from Jambi province, our first case reveals that smallholder certification for so-called sustainable palm oil does not necessarily influence smallholder towards more sustainable management practices. One explanation might be a discrepancy in sustainability perception between sender and receiver systems. The second case is the setup of an allegedly eco-friendly rubber plantation. The establishment of this model plantation is implemented by a transnational corporation in collaboration with a nature conservation organization, impacting the access to land for adjacent smallholders. The struggle over access to land is not only negotiated between smallholders and the corporation producing “eco-friendly” rubber but also between smallholders and big land mammals lacking access to land since the rubber plantation began to be established. We argue that the concept of sustainability as demanded by the receiving system does not mirror management practices in the sending system, even though the products reach the Global North as supposedly socially and climate-friendly. The smallholder telecoupling framework is helpful for assessing potential sustainability but can be expanded towards conflictive spillovers, second order effects, and a mismatch in sustainability perceptions in order to draw a more comprehensive picture.

Keywords: telecoupling; sustainability; multi-stakeholder initiatives; roundtable for sustainable palm oil; sustainable natural rubber initiative

# 1. Introduction

Climate change and its current consequences, as well as damages yet to happen, are prominent in public debate. Land-use and land-use change are regarded as one of the main contributors to climate change (IPCC 2014). Especially in the so-called Global North, this debate leads to an increased awareness towards considerations of the origin of commodities purchased. These considerations apply to the ecological, as well as socio-economic, impacts of the desired goods. Not only goods produced in the vicinity to the consumer are here taken into account but also the distant places of production. Gradually more information, hence more awareness, trickles through on management

practices and their impacts, especially on monoculture plantations of boom crops, such as oil palm and rubber (Hall 2011), produced in the so-called Global South. In the context of globalization, a rise in information dissemination has led to new moralities and hence a demand for sustainable commodities (Johnson et al. 2014; Eakin et al. 2014). In response to this consumer demand, schemes of sustainability certification for palm oil and rubber were established. These led to initiatives, which “signal to consumers that their products and/or production processes used, hold certain standards regarding environmental, health or social aspects” (Vatn 2015). Private actors are increasingly engaging in climate governance through private rule-making mechanisms like certification or other, often voluntary, multi-stakeholder ‘cooperative initiatives’ (Chan et al. 2016). Non-state actors, often referred to as Non-Party actors, to distinguish them from the United Nations Framework on Climate Change Convention (UNFCCC), “can help national governments to reach existing climate policy goals and set higher targets” (Hsu et al. 2019). Recognizing this development, Jagers and Stripple (2003) argue that climate governance should not be ascribed to only international climate actors, such as the UNFCCC. They add the notion that climate governance should further be used towards any “purposeful mechanisms and measures aimed at steering social systems towards preventing, mitigating, or adapting to the risks posed by climate change” (ibid., p. 60). From this perspective, the term ‘climate governance’ also fits to describe the private multi-stakeholder initiatives context as the starting point for this paper. The standards developed by these multi-stakeholder initiatives, initiated in the Global North, were in its infancy set up to steer the management practices of large-scale companies (Hidayat et al. 2018; Brandi et al. 2015). However, not only companies are affected but also the smallholder production of oil palm and rubber at distal places is increasingly targeted by schemes intending to increase sustainability along the value chain. The impacts on smallholders as intended by the initiatives are not always congruent with how local land users perceive the effects. At times, the impacts felt by smallholder are, from the perspective of the initiative, rather unintended and hence are considered as the second order effects. The impacts of climate governance instruments alter land control at these places at a distance.

Current studies on oil palm certification are prevalent. Some focus on biodiversity conservation potential (Azhar et al. 2015) or on deforestation elimination potential (Van der Ven et al. 2018; Carlson et al. 2018) while some on the effectiveness regarding social and environmental performance (Morgans et al. 2018). The analysis of eco-friendly rubber is less frequent. Early studies primarily focused on environmental consequences of rapid monoculture expansions in the tropics (Ahrends et al. 2015), investigated options to halt ecosystems and biodiversity loss, and strongly recommended the adoption of sound certification schemes for sustainable rubber (Warren-Thomas et al. 2015a) and the financial adjustment of payments for ecosystem services if binding regulations are absent (Ekandinata and Vincent 2011; Warren-Thomas et al. 2018). Kennedy et al. (2016) consider the comparably slow uptake of rubber certification as opposed to crops like palm oil, cocoa, or coffee and illustrate shortcomings of those being present. However, Kenney-Lazar et al. (2018) question the potential of ‘green’ rubber cultivation, especially in resource frontiers. The current literature available hardly looks at second order effects or conflictive spillovers. We would like to contribute to closing this gap by asking the question what sustainability potential the Roundtable for Sustainable Palm Oil (RSPO) and the Sustainable Natural Rubber initiative (SNR-i), as two examples for multi-stakeholder initiatives, have in distal smallholder social-ecological systems, especially when considering conflictive spillovers or second order effects.

One such distal smallholder setting is Jambi province on the island of Sumatra in Indonesia. Indonesia and Malaysia together produce approximately $8 5 \%$ of palm oil and approximately $3 0 \%$ of rubber traded worldwide (FAOSTAT 2019). Even though an estimated $6 0 \%$ of oil palm (Beckert 2016; Indonesia Investments 2017) is produced by companies, smallholder production plays an increasingly crucial role to resource management and sustainability, worldwide as well as in Jambi (Zimmerer et al. 2018; Cohn et al. 2017). For rubber, the figures are even more striking. In Indonesia, “smallholder account for over $7 8 \%$ of the total volume produced and occupy over $8 5 \%$ of the total

area under rubber cultivation” (Kennedy et al. 2016, p. 106), punctuating the relevance of smallholder production in this field.

To assess the potential sustainability for smallholder production, (Zimmerer et al. 2018) propose to utilize the analytical framework of smallholder telecoupling. Applying this framework to two case studies from Jambi province is the paramount intention of this paper. Our first case reveals that smallholder certification for so-called sustainable palm oil under the Roundtable for Sustainable Palm Oil (RSPO) does not necessarily influence the production process towards more sustainable practices. The second case is the establishment of an allegedly eco-friendly rubber plantation by a transnational corporation with the involvement of a nature conservation organization, impacting the access to land for adjacent smallholders. As the second intention of this paper, we argue that within this smallholder telecoupling framework, the sustainability paradigm creates new arenas of conflictive spillovers. The spillovers or second order effects transform perceptions of resource use and control, hence reshape the frontier.

# 2. Conceptual Framework

The frontier in its classic understanding was described as the line pushing back wilderness, to create a space for development at the expense of natural resources (Fold and Hirsch 2009). This idea of a clear-cut line between agricultural land and settlements opposed to the forest as wilderness is (if it has ever been adequate) outdated and does not keep up with current dynamics in land use patterns. Post-frontiers or new frontiers have replaced the old notion, filling it with new understandings of transformation and concepts of land control. According to Peluso and Lund (2011, p. 668), new frontiers are “sites where authorities, sovereignties, rights, and hegemonies of the recent past have been or are currently challenged by new enclosures, territorializations, or property regimes. What is new is not only land grabbing or ownership but also new crops with new labor processes and objectives for growers, new actors and subjects, and new legal and practical instruments for possessing, expropriating, or challenging previous land controls.” Rasmussen and Lund (2017, p. 392) add that “frontiers are novel configurations of the relationship between natural resources and institutional orders that happen at particular moments in particular places. [ . . . ] Frontiers emerge when a new resource is identified [ . . . ]. The ‘discovery’ of new resources [ . . . ] opens frontiers and challenges established right.” As we will see in the following, concepts of sustainable crop production can be regarded as the discovery of a new crop as they alter land control and hence the access to land. Following the definition of Ribot and Peluso (2003, p. 154), we understand “access to land as the ability to benefit”. The new frontiers, with their new objectives for growers, new actors and subjects, and ‘new resources’ are stuffed with complex, beyond place-based observable aspects. We hence argue that the innovative telecoupling framework is particularly suitable to analyze new frontier settings.

Telecoupling is an emerging analytical concept in land system science reacting to an increasingly complex and distal cause and impact context, as well as a reaction to an increasingly process-oriented system (Kapsar et al. 2019). It aims to support research striving to unravel drivers of intended as well as unintended changes in social-ecological systems (Friis and Nielsen 2017). Understanding and explaining contemporary land-use changes “requires a conceptual framework geared toward capturing not only the place-based and site-specific factors of change but also the multidirectional flows of capital, produce, and information linking it to processes in distal places” (ibid.: w.p.).

The role of the 2 to 2.5 billion smallholders worldwide in socio-ecological systems in these gradually more telecoupled systems are of crucial importance in land use science. According to the Food and Agricultural Organization of the United Nations (FAO), farmers are considered as smallholder who grows agricultural products for the market and family consumption on less than 10 hectares of land (FAO 2012). We extend this definition to a maximum of 20 ha as some respondents of our sample hold more than 10 ha but still meet the remaining indicators of the smallholder definition. We follow the invitation of Zimmerer et al. (2018) to analyze potential sustainability as demanded by the Global North by applying the smallholder telecoupling framework. Telecoupling

occurs when a change in one social-ecological system impacts one or more social-ecological systems at a geographical distance while this change would not necessarily have been expected or assumed (Eakin et al. 2014). Land system science has been very place-based in the past; the telecoupling concept, in contrast, emphasizes networks and interactions amongst systems (ibid.). These interactions do not only encompass material flows but also socioeconomic as well as environmental interactions (Liu 2014). The telecoupling framework furthermore explicitly considers feedbacks in the analysis of land use change and sustainability research. Feedbacks can, for example, be “reciprocal interactions among different coupled systems” (ibid., p. 3). The basic telecoupling framework analyzes the systems, the agents acting in them, flows of material, ideas, technologies, and people, as well as causes and effects. The systems are subdivided into sending, receiving, and spillover systems. The definition of the systems is context dependent (ibid.). In our case, the sending systems are the systems providing material, hence rubber and palm oil. The receiving system, in turn, receives materials; in our case, allegedly sustainable or eco-friendly palm oil and rubber.

The smallholder telecoupling framework as proposed by Zimmerer et al. (2018) follows this basic telecoupling framework just introduced. It is then argued, that in dependence to the basic framework, telecoupled smallholder social-ecological systems can be analyzed along four factors. The first factor consists of the (1) telecoupled global systems affecting smallholders or the linkages of smallholders; in our case, the demand of sustainably produced commodities, a demand which also reaches out to smallholder systems. Closely linked to this first factor are the (2) the resource use of the smallholder and land access in the sending system, forming a second analysis factor. (3) The governance, including public and private institutions, markets, and national-level governance are described as the third factor. In our case, this third factor consists mainly of multi-stakeholder initiatives. The fourth analysis component is the (4) local interactions among smallholders in their communities and landscapes (ibid.). To our knowledge, neither oil palm nor rubber smallholders have been analyzed by applying the concept of telecoupling1. We would like to contribute to the telecoupling framework by analyzing oil palm and rubber smallholders and thereby expanding the framework if necessary. Analyzing interactions triggered at a distance to the systems where changes occur, supports a better understanding of local social-ecological system alterations. Further research could apply the telecoupling framework in a more exhaustive manner by analyzing changes in the social-ecological system in the receiving system as well (e.g., the impacts of sustainable palm oil production in Indonesia on rapeseed farmers in the European Union). In this article, the focus remains on altered land control in the sending system though.

Taking account of these four analysis components for smallholder telecouplings and their sustainability potentials demanded by consumers mainly in the Global North, to us also means to take on a perspective across scales with a focus on power asymmetries. In other words, this research endeavors to narrate from the lens of political ecology (Zulu 2009).

# 3. Methodology

The sustainability potential of smallholder production is analyzed along two initiatives: the Roundtable for Sustainable Palm Oil (RSPO) and the Sustainable Natural Rubber initiative (SNR-i). We knew of cases of RSPO certification in our research area which we visited on purpose. In the case of the SNR-i, we followed an inductive approach and learned about this case while on the field.

# 3.1. Study Sites

Jambi province is located on the island of Sumatra, the third largest island in Indonesia and the fifth largest island in the world (Barber 2005). Jambi province borders the provinces of Riau

in the north, the South China Sea in the east, the province of South Sumatra in the south, and the provinces of West Sumatra and Bengkulu in the west. There are four national parks in Jambi province, which comprise an area of 693,354 hectares: Kerinci Sebelat National Park in the west, Bukit Tigapuluh in the north, Bukit Duabelas National Park in the center, and Berbak National Park in the eastern part of the province (Beckert 2016). These national parks seem to be important last resorts as the development from the forested area towards monoculture plantation is rampant. According to Laumonier et al. (2010), between 1985 and 2007, 1.7 million hectares of forest had been cleared,Soc. Sci. 2019, 8, x FOR PEER REVIEW 5 of 26 which is an estimated $7 1 \%$ of the forest in 1985. In 2013, only $3 0 \%$ of the land in Jambi province was covered with rainforest, predominantly in the highlands, anddevelopment from the forested area towards monoculture p $5 5 \%$ of the land mass was agriculturalion is rampant. According to land (Drescher et al. 2016). Parts of the land are obviously also taken up by settlements to hostLaumonier et al. (2010), between 1985 and 2007, 1.7 million hectares of forest had been cleared, which approximately 3.5 million inhabitants of the province (in 2017) (Badan Pusat Statistik Jambi 2019),is an estimated 71% of the forest in 1985. In 2013, only 30% of the land in Jambi province was covered of whichw $4 9 \%$ were working in the agricultural sector in 2014 (Badan Pusat Statistik Jambi 2015).inforest, predominantly in the highlands, and 55% of the land mass was agricultural land

Data used in this paper were collected in four villages spread across Jambi province. The research(Drescher et al. 2016). Parts of the land are obviously also taken up by settlements to host regarding the implementation, impacts, and sustainability potential for certified palm oil waswhich 49% were working in the agricultural sector in 2014 (Badan Pusat Statistik Jambi 2015). conducted in three villages: Mekar Jaya (with one RSPO certified farmer group since 2014), Merlung,Data used in this paper were collected in four villages spread across Jambi province. The and Sungai Rotan (at the time of research, both still in the RSPO certification process). The villageresearch regarding the implementation, impacts, and sustainability potential for certified palm oil Muara Sekalo was the study site for the impacts and potentials of the so-called eco-friendly rubberwas conducted in three villages: Mekar Jaya (with one RSPO certified farmer group since 2014), under the Sustainable Natural Rubber initiative (SRN-i) (see Figure 1). The project is situated on theMerlung, and Sungai Rotan (at the time of research, both still in the RSPO certification process). The border of the National Park Bukit Tigapuluh (‘Thirty Hills’) and enclaves the village Muara Sekalo,village Muara Sekalo was the study site for the impacts and potentials of the so-called eco-friendly with its 1200 inhabitants (village survey 2012). Villagers have, since long, predominantly cultivatedon the border of the National Park Bukit Tigapuluh (‘Thirty Hills’) and enclaves the village Muara rubber besides paddy and vegetables for subsistence, though today, generally both rubber and oilSekalo, with its 1200 inhabitants (village survey 2012). Villagers have, since long, predominantly palms are grown. Paddy farming is almost completely abandoned. While the village Sungai Rotancultivated rubber besides paddy and vegetables for subsistence, though today, generally both rubber also borders the Bukit Tigapuluh National Park in the northern part of the province, Mekar Jaya is inand oil palms are grown. Paddy farming is almost completely abandoned. While the village Sungai the vicinity to the Bukit Duabelas National Park.

![](images/915a495eeaecb8e21e99396133b73f05e7cc9ff6ae8145f3d9599f7f1e194fa9.jpg)  
Figure 1. Study Sites.Figure 1. Study Sites.

# 3.2. Multi-Stakeholder Initiatives at the Study Sites: RSPO and SNR-i3.2. Multi-Stakeholder Initiatives at the Study Sites: RSPO and SNR-i

As already mentioned, the villages Mekar Jaya, Merlung, and Sungai Rotan were selected as As already mentioned, the villages Mekar Jaya, Merlung, and Sungai Rotan were selected as research sites as all three villages have farmer groups who are either already certified by the RSPO research village illuminating the impacts of the Sustainable Natural Rubber initiative (SNR-i). or are in the process of receiving recognition as RSPO certified farmer groups. Muaro Sekalo is the research village illuminating the impacts of the Sustainable Natural Rubber initiative (SNR-i).

# 3.2.1. The Roundtable on Sustainable Palm Oil (RSPO)

Launched in 2004, the RSPO is a multi-stakeholder initiative supported by the Worldwide Fund for Nature (WWF) and private industry actors in Europe. It is listed by the United Nations Environment Program as one of over 250 climate initiatives (Climate Initiative Platform 2019) and states to support the Sustainable Development Goal 13 on Climate Action (RSPO 2018). For the first time, plantations were certified in 2008; in the same year, the first certified sustainable palm oil was sold (Rival et al. 2016). In 2018, around $1 9 \%$ of the worldwide traded palm oil was certified by the RSPO. With almost 4000 members, the RSPO aims at reaching full traceability of the palm oil supply chain (RSPO 2018). Compliance to RSPO standards is audited by a third-party audit company.

In order to reach this traceability and to work towards the self-proclaimed climate goals in the name of sustainability, eight principles that are subdivided into 39 criteria were formulated2. These principles and criteria (P&C) are frequently reviewed to improve their relevance, especially for different grower groups3 (RSPO 2010). The overarching themes of the P&C are transparency, laws and regulations, economic and financial viability, environmental responsibility, conservation, biodiversity, as well as workers’ and communities’ rights. In November 2018, the RSPO launched official cooperation with the High Carbon Stock Approach (HCSA) “to establish a No Deforestation Joint Steering Group (NDJSG) focused on providing guidance on the implementation of no deforestation requirements in High Forest Cover Landscapes” (RSPO, and HCSA 2018). Growers, processors and traders, manufacturers, banks and investors, retailers, and NGOs are among the members of the RSPO (Rival et al. 2016). Independent smallholders, as the relevant group for this research, need to be organized in a farmer group in order to apply for RSPO certification.

The literature lists several potential benefits the RSPO certification can provide to a smallholder. These are improved market access, higher incomes through higher productivity, and better quality of harvests (Brandi et al. 2015). Improved management practices, as a principle of the RSPO, are expected to produce higher yields. As smallholders are paid according to the weight of their harvest, higher productivity would result in higher yields, which would then translate into higher market prices. It is worth mentioning here that there are no price premiums for certified sustainable palm oil on international markets (Brandi 2017).

Challenges for smallholders to join the certification process is the capital- and time-consuming processes, which consist of trainings, as well as the fees for administration, monitoring, and auditing (Cheyns 2011). Smallholder hardly considers this effort as a long-term investment, which could later pay off through higher yields (Nagiah and Azmi 2012). Compliance with RSPO P&C is limited through a lack of agricultural skills, as well as through a lack of incentives, for example, price premiums (Jelsma and Schoneveld 2016).

# 3.2.2. The Sustainable Natural Rubber Initiative (SNR-i)

The Sustainable Natural Rubber initiative (SNR-i) has been developed under the framework of the International Rubber Study Group (IRSG) as a voluntary and collaborative industry project in 2014.

The objective of the initiative is to ensure that the rubber industry can build on its best practices plus demonstrate and communicate throughout the natural rubber value chain. In this context, a Sustainable Natural Rubber Working Group (SNRWG) was established in 2012 with a view to defining voluntary sustainability standards regarding the broader natural rubber sector. The working group members representing the complete natural rubber (NR) value chain (including representatives from international organizations) developed an Action Plan to explain the factors driving this

initiative and brought forward proposals for its design and implementation. The Action Plan defined a set of five criteria for a voluntary verification system targeted on wide stakeholder participation. From these criteria, indicators have been developed for the implementation of SNR-i that may allow organizations to participate in this voluntary initiative on a self-certification basis. Self-certification means that there is no external auditing. The main themes to be improved under the initiative are the improvement of natural rubber plantations, to enhance the quality of natural rubber, to support forest sustainability through the protection/conservation of protected areas, to demonstrate appropriate water management, and to demonstrate the highest respect for human and labor rights. As is the case for the RSPO, the SNR-i also has a set of criteria, even if far less detailed4. By October 2017, 43 companies/organizations had completed the self-declaration on the SNR-i. The majority of these 43 self-declared registrants are processors. The smallest part of the members falls under the plantation category $( 9 \% )$ (SNR-i 2017).

# 3.3. Data Collection

The research villages were visited during several fields stays in 2016 (Merlung) and 2017 (Muara Sekalo, Sungai Rotan, and Mekar Jaya). To gain a deeper understanding of the effects of multi-stakeholder initiatives in the palm oil and rubber sector, a range of qualitative as well as quantitative methods were applied. Using a case study approach, main methods applied were participant observation and semi-structured problem-centered guideline interviews $( n = 6 4 )$ ); as well as focus group discussions (6) with women and farmer groups were conducted during the time spent in the villages (on average one week per village) (see Supplementary Materials). In Sungai Rotan and Mekar Jaya, the Sustainability Assessment of Food and Agricultural Systems (SAFA) framework was additionally applied, even with a small number, of only 10 respondents (for further information see Appendix A). This framework was developed by the FAO, and it targets several dimensions of sustainability. The questionnaire comprises of 100 multiple and single choice questions, focusing on good governance, environmental integrity, economic resilience, and social well-being. In Merlung, the social power network mapping method was implemented to gather in-depth information about multi-stakeholder governance. It helps to identify networks that “tend to be located outside existing hierarchies” (Schiffer and Waale 2008). It hence helps to understand how smallholders are impacted in their decision-making processes and what their intentions are. In addition to the interviews in the villages, expert interviews with non-governmental organizations and government officials (e.g., with RSPO representatives in Jakarta), mostly on the provincial and district level, were conducted.

# 4. Results

The results for the two cases, namely the certification for so-called sustainable palm oil under the Roundtable for Sustainable Palm Oil (RSPO) and the allegedly ‘eco-friendly’ natural rubber cultivation following Sustainable Natural Rubber initiative (SNR-i), are discussed separately and along the four central criteria identified by the smallholder telecoupling framework. The data on the RSPO concerns the impacts of a climate governance instrument on smallholders directly, as the program also targets the production of a smallholder. The SNR-i case is less straightforward. Here, the initiative targets large-scale production and thereby ‘only’ affecting smallholders’ access to land as a second order effect.

# 4.1. Smallholder Telecouplings under the Roundtable on Sustainable Palm Oil

Oil palm smallholders in Jambi province are impacted by a growing consumer awareness towards social and ecological sustainability impacts of commodity production. This growing awareness has led

to the establishment of certified palm oil schemes. An increasing number of certificates for sustainable palm oil is available on the market (Rival et al. 2016; Pacheco et al. 2017).

It is worth mentioning that the RSPO, as other certification schemes as well, equips itself with the interpretation of sovereignty on what sustainability actually is. The RSPO itself states in this context that it “has developed a set of environmental and social criteria which companies must comply with in order to produce Certified Sustainable Palm Oil” (RSPO 2019). Looking at the stakeholders deciding on these criteria shows that the vast majority of board members belong to investor groups. Governmental actors, as well as grower groups of smallholders, are not represented. It can hence be argued that sustainability, as defined by the representative of investors and few non-governmental organizations engaged in nature protection, is rather a compromise, subjective, and certainly not a very inclusive understanding of the term (Ruysschaert and Salles 2014). Against this background, it might be argued here that the RSPO is rather geared towards business development than towards genuine sustainability.

# 4.1.1. Telecoupled Systems—Demand for Sustainable Palm Oil

To date, the Roundtable for Sustainable Palm Oil (RSPO) remains the most popular scheme, in terms of quantity certified. An increase in the demand for sustainable palm oil in the receiving system resulted in $7 4 \%$ of all palm oil imported to the European Union being RSPO certified palm oil (European Sustainable Plam Oil 2019). From the initial setup to certify palm oil produced by large-scale companies, there has been a shift towards the recognition of the importance of smallholder production (RSPO 2018). Today, 55,000 certified schemes and independent smallholders produce certified palm oil, translating to $9 \%$ of the total area for RSPO certified palm oil, being under smallholder’s production (RSPO 2018). In order to sell certified sustainable palm oil, farmers need to be organized in a farmers group. In other words, individuals cannot apply for certification and only groups of individuals can. According to interview partners who are members of such a farming group, a certain minimum collective plantation size needs to be reached to apply for the certification process. Smallholders who were interviewed further state that by getting organized in a farmers group, there is an improvement in bargaining positions, savings in management costs, and it can be helpful when striving for loans or subsidized inputs. By talking to smallholders, it becomes obvious that most RSPO P&C, as they have been set up mostly by the receiving system, are quite complex to understand, difficult to obey to or simply not applicable to small-scale farming realities. For example, the reduction of greenhouse gas (GHG) emissions is an intention behind sustainable agricultural practices under the RSPO. Smallholders obviously lack the necessary technological equipment, skills, and incentive to track GHG emissions from the application of fertilizer. The mere recording of emissions does not necessarily lead to a change in agricultural practices. The limited economic capacity of farmers to adhere to these principles, and their motivation being to achieve wellbeing, reflects an imbalance of indicators. They are legitimized by discourses among experts, consumers, and politicians from the receiving system. This is not to say indicators should only reflect small-scale producers’ perceptions, but the information on trade-offs and feedbacks between sustainability dimensions and target-oriented support (such as the provision of machinery for replanting oil palm trees), or extension services, is still lacking.

# 4.1.2. Smallholders’ Resource Use and Access to Land

One RSPO criterion is the legal land ownership or, in other words, a clear tenure status is crucial in the RSPO certification scheme. One goal of the RSPO on their way to a sustainable value chain is to reduce or avoid deforestation. In this context, another criterion is that RSPO only accepts palm oil from plots which were not deforested after 2005. To reduce soil degradation and to improve the responsible use of agrochemicals (criteria under principle 4), a fertilizer schedule has to be maintained by the smallholders. Commitment to long-term economic and financial viability, as again another criterion,

calls for the maintenance of a schedule for fertilizer and harvest. A commitment to transparency is listed as the very first principle of the RSPO.

According to statements from interviews, however, many farmers do not hold a land title recognized by the national organization in charge of issuing land titles. According to an expert, working for an Indonesian NGO focusing on palm oil, many independent smallholders migrated to Sumatra. They bought land from local people and do not know when their land had been reclassified to agricultural land. He further explained that this criterion is more feasible for companies as it is possible to compensate for non-compliance by protecting another forest or by planting a new forest. The fertilizer schedule is regarded as one of the major challenges among smallholder interviewed. The application of fertilizer is weather-dependent. In dry times, the soil does not take up the fertilizer which is regarded as wasteful if applied anyway. In the rainy season, the excretion is washed away and equally regarded as wasteful. In case of heavy rains, the plantations can at times not be accessed which hinders the fertilizer’s application. Often, the fertilizer needed is not available in accessible stores.

Smallholder, however, also reports on positive impacts through certification: they have a better understanding on fertilizer use (due to training received), use fewer pesticides, have better access to organic fertilizer, and also better access to high-quality seeds. At the same time, results show that many farmers have never heard about certification for sustainable palm oil, even if they belong to a certified group. Our findings support the findings of Brandi (2017) that even among certified smallholders, some do not know about the RSPO or the principles and criteria. Some of those who are certified and are also aware of the certification claim that they have not changed their management practices from the time prior to certification as the audit would not reach their plot anyway. “I am not going to change anything unless there is an audit on my plantation” was the statement of one smallholder interviewed.

# 4.1.3. National Institutions

Adhering to the national laws and land tenure regulation, mentioned in the context of legal land ownership above, is also amongst the criteria listed by the RSPO. This national-level governance frame was named as the biggest hurdle in focus group discussions on challenging RSPO criteria. Farmers need to verify legal ownership through a national level land certificate, which the majority of the farmers in Jambi do not have (Kunz et al. 2016). The farmer groups in Mekar Jaya and Sungai Rotan alike were supported though, in receiving certification or being in the certification process by one Indonesian non-governmental organization (NGO). This NGO helps rural villages that lack market access and governmental support in forming farmer groups and guides them through the RSPO certification process. They also support farmer groups in receiving the Indonesian Roundtable for Sustainable Palm Oil (ISPO) certificate. The principles and criteria for the Indonesian certificate are granted when obeying to national laws. Principles and criteria here are thus congruent with the national law. According to interviewees, the NGO also takes care of the costs for sustainability certification, which includes the acquisition of a formal land title. The same NGO also carries out training with the farmers.

# 4.1.4. Local Interactions

Throughout the interviews and focus group discussions, the involvement in farmer groups has been mentioned as having a positive impact on a smallholder. The membership in farmer groups can in many cases be traced back to the initiation of the certification process under the RSPO. While an increase in palm oil production is mentioned as having led to a decline in a bond among villagers, the farmer group compensates for this decline. “Before [oil palm expansion]5, there were lots of emotional bonds, a sense of togetherness and everyone was family” was a statement in one focus group discussion. What is described in this statement was something we found in all villages,

a concept summarized under the term ‘gotong-royong’. Literally, this term translates to ‘mutual cooperation’. To community members in all the places we visited in Indonesia, it is a matter, of course, to participate in ‘gotong-royong’ activities. This can be cleaning up the village, renovating the kindergarten, improving basic infrastructure, and alike. Usually, community members actively participate in these activities. If participation is not possible, financial compensation can be accepted as a supplement. According to interview partners, with an increase in palm oil adoptions, an increase in supplementing payments has been observed. In turn, this means, that the value of the mutual cooperation is in decline, while competition between farmers is increasing.

Furthermore, many smallholders state that they obtain information on oil palm management through friends, neighbors, etc., working for a company on an oil palm plantation. In this context, the word also spreads on certification-related issues. In Merlung, a smallholder stated to have been advised by a palm oil company to initiate the certification process as otherwise, they will not be able anymore to sell their fresh fruit bunches.

# 4.2. Smallholder Telecouplings under the Sustainable Natural Rubber Initiative (SNR-i)

Jambi province has for long been a smallholder-dominated landscape; rubber cultivation in agroforestry systems was widespread. Increasingly, these systems are substituted by monoculture cultivation systems (Feintrenie and Levang 2009). Opposing to developments in the palm oil industries, rubber cultivation in Jambi was for a very long time not at all affected by demands for more sustainable management practices, but, this has changed with the recent establishment of a large-scale ‘model’ plantation for sustainable rubber cultivation.

# 4.2.1. Telecoupled Systems—Demand for Eco-Friendly Rubber

While negative social-ecological consequences and land dispossession “have attracted considerable attention from scientific and academic communities, public awareness—particularly in terms of consumer demand for standards and certification—has been slow to develop in comparison to other agro-commodity crops” (Kennedy et al. 2016).

By now, however, producers of natural rubber (NR) are increasingly under pressure to cap negative environmental impacts. Especially agro-industrial rubber cultivation has expanded rapidly, and the area under cultivation has doubled within the last decade and is projected to swallow up to another 8.5 million hectares to meet demands (Warren-Thomas et al. 2015a). New frontiers of rubber expansion include biodiversity hotspots in Southeast Asia and many protected areas (Ahrends et al. 2015; Warren-Thomas et al. 2015a). In response to this massive expansion in biodiversity hotspots, initiatives for sustainability standards arose, mostly industry-led, resulting in voluntary guidelines like the SNRi (Kennedy et al. 2016). These rather weak guidelines do not target smallholders per se but still indirectly exert influence on them.

Lately, tire producers increasingly claim to take sustainability issues into account. The tire industry is the main purchaser of natural rubber; it consumes about $7 0 \%$ of the global trade volume (Clay 2010). Michelin was the first tire producing company to announce a ‘zero deforestation’ policy (WWF 2016), which is embedded in their sustainable natural rubber policy. The policy’s guiding principles are based on the SNR-i criteria aiming to establish sustainability of the natural rubber value chain. The French company is a core member of the Sustainable Natural Rubber Working Group (SNRWG) that developed the SNR-i criteria.

Michelin (2017) states that they established model plantations in Sumatra to produce ‘eco-friendly’ rubber “in both social and environmental terms”. On those plantations, the company indicates to cooperate with local communities, applies best management practices, and spares half of the concession for conservation.

Two years ago, the Indonesian rubber company PT LAJ started its business and initiated the establishment of this model plantation in cooperation with Michelin. The whole concession amounts to more than 60,000 ha. According to inhabitants of Muara Sekalo, roughly half of the concession will

be a rubber plantation, while the other half is designated for conservation issues, including a buffer zone to the ‘Thirty Hills’ national park and an elephants reserve. According to the local customary law, the parts of this concession are claimed by villagers.

# 4.2.2. Smallholders’ Resource Use and Access to Land

These overlapping land tenure regulations between de-jure and de-facto tenure cause contradictions (cf. Kunz et al. 2017). On-site, people cultivate land, which the Ministry of Environment and Forestry has allocated to the company to produce eco-friendly natural rubber to be processed by Michelin. PT LAJ compensates villagers in case they claim the land within the concession, but not everyone recognizes the payments straightforward. In case of non-compliance, as the last consequence, the company takes legal action, the Corporate Social Responsibility assistant of the company reports. In many cases, locals accept the offered compensation payments, yet the process was decelerated.

Furthermore, members of a women’s group vividly demonstrated that they and many others did not want to abandon their rubber and oil palm plots that now lay within the concession, as they prefer to stay independent farmers. As a response to their resistance, they were intimidated for giving their land to the company. They had no choice; in the end, the company would have won. Effectively, there is a single villager, who confronted the company and could keep his plot. If needed, he would even have defended himself before the court. Other villagers did not follow his example, because they do not know their rights, he said, and it was not in the interest of the previous village government to inform inhabitants about their rights. The village government, he continues, who negotiated the deal, had their own particular interests.

The limited agency of smallholders concerning their land claims was compounded by the difficulties they faced regarding independent farming. Since the establishment of the plantation by PT LAJ in 2016, more and more elephants encroached the villagers’ plots within and outside the concession area and even the village settlement. Although such incidents were common before, elephants cannot be driven back as easily anymore; they became more aggressive and destroyed especially young rubber and oil palm plantations in search of a feed.

Those young plantations inside the concession were finally given to the company since farmers could not afford to replant their plots more than once. They accepted the compensation payment and started working on their remaining plots outside the concession and eventually for the company.

Villagers hold the company responsible for this because parts of the elephants’ habitat are destroyed by the establishment of the plantation. According to interview partners working for PT LAJ, the activities on the plantation currently consist of forest clearing.

# 4.2.3. National Institutions

In Jambi province, there is potential for sustainable rubber production by smallholders because $9 4 \%$ of the land is managed by independent smallholders ( $8 7 \%$ in Sumatra, respectively) (Directorate General of State Crops 2015). Nonetheless, there has not yet evolved a broad-scale initiative for sustainable rubber production; neither the local farmers aligned their cultivation practices to sustainability standards independently nor did governmental institutions or market mechanisms support this step. Significant regional or national level policies do not exist, though Kenney-Lazar et al. (2018, p. 112) found that “an active engagement on the part of the state in terms of planning and targeting commodity programs to improve sustainable intensification, supporting social capital for strong collective actions and grassroots institutions at the local level and providing incentives for environmentally friendly agricultural practices, is crucial to the successful development and adoption of certification”.

On the contrary, in Jambi, the institutional environment deters the engagement of smallholders since market-induced price incentives like premiums are ruled out through oligopolistic value chains (Kennedy et al. 2016). Only nine processing factories purchase the produce of approximately 250,000 smallholder farmers (Kopp et al. 2014a, 2014b). Grassroots initiatives like farmer groups did

form to counter these disadvantageous market conditions or to demand governmental support for environmentally friendly management.

# 4.2.4. Interactions between PT LAJ and the Local Community

PT LAJ initiated training for village farmers on best management practices in rubber monocultures. According to one participant, the main objective was to improve smallholder’s productivity, proving good on farmers’ plots as well as on the company’s plantation. However, the training did not focus on ecological aspects but plantation establishment and harvesting techniques improving yields. Such training will not be repeated on a regular basis. The company counts on knowledge sharing between the participants and other village farmers. A rubber farmer who participated in the training said that he learned a lot and applies his new tapping skills now on his own plots. He wished he would have gained this knowledge long before. However, this farmer stated that other participants do not apply their new skills or even share their knowledge with others.

Further, there are plans for a partnership scheme between PT LAJ and local farmers, but information remains vague. It is uncertain when the plans of such collaboration will be addressed, but data strongly suggests that they will be realized only once the company’s core plantation will be fully established. So far, PT LAJ has acquired approximately two-thirds of the concession designated for the rubber monoculture; they are in the process of planting trees there, and it might take another two to three years until the first rubber trees will produce sap. Therefore, positive feedbacks cannot be assessed, but knowledge transfer might increase farmers’ productivity and thus their economic situation.

None of the villagers is aware of the fact that the company’s rubber plantation will produce ‘eco-friendly’ rubber. Only a few interviewees knew that PT LAJ is somehow cooperating with the French tire producer Michelin and the World Wide Fund for Nature (WWF).

# 5. Discussion and Conclusions

Multi-stakeholder sustainability initiatives, here regarded as climate government instruments, impact smallholders’ land use practices. They introduce new actors and new sets of regulations to social-ecological smallholder landscapes. The intention of the multi-stakeholder initiatives addressed in this article, namely RSPO for oil palm and the SNR-i for rubber, is a socially and ecologically more sustainable way of production. We have claimed and proven that we can assess the sustainability potential of these two initiatives by applying the smallholder telecoupling framework. This approach seems particularly suitable as it helps to reveal unintended or second-order effects at a distance to the places where the triggers were kicked off.

Both cases disclose that the multi-stakeholder initiatives have brought new actors to the scene. In the case of rubber certification, Michelin and the WWF have entered the smallholder ecological-system. In the RSPO case, it was the Indonesian NGO to deliver the new legal and practical instrument to the smallholders. In both sites, previous land controls are challenged whereby so far it was enough to go with a local level recognized title deed. With the emergence of the new actors and the regulations, the control of the land was altered. At least in the SNR-i case, according to Peluso and Lund (2011), this leads to new dependencies, hence new hegemonies and indicators for arising new frontiers. They further argue that agrarian landscapes have been transformed by various processes, including protected area expansion amongst others. Our cases show that a sustainablization of these landscapes also alter forms of land control. These alterations, especially in the rubber case, are accompanied by a decline in the agency and an increased vulnerability. The worsening livelihood situation of the smallholder is an unintended spillover effect of sustainability certification.

Regarding environmental benefits, our RSPO data is not exhaustive enough to draw a comprehensive picture. In combination with existing studies, we can, however, underline that RSPO certification does not seem to achieve large-scale conservation effects because of implementation and control challenges, as well as due to weak standards, in general. In some cases, it can contribute to reducing impacts on a small scale: for example, reduced usage of agrochemicals

(Brandi 2017). The SNR-i case in comparison shows that there are, until now, no environmental benefits. On the contrary, deforesting an area, even if this area might ‘only’ be a secondary forest, cannot contribute to a sustainable production process. The RSPO, with its policy prohibiting deforestation after 2005, has acknowledged this aspect, but the SNR-i apparently not yet. Although Michelin gave a ‘zero-deforestation’ pledge in addition to the SNR-i guidelines (Michelin 2016), the pledge is weak, since it only considers primary forest for unrestricted protection. Further areas are only protected if identified as high-carbon stock (HCS) or with high conservation value (HCV) (ibid.). Therefore, the forested area within the concession will not be preserved. If this deforestation then negatively affects the Sumatran elephant as our case reveals, the term sustainability would not seem appropriate anymore. The decrease in habitat for the Sumatran elephant is again a second order effect of sustainability certification. According to the WWF, the Sumatran elephant is a critically endangered species. “The leading threat to Sumatran elephants is the loss of their habitat to an unending parade of chainsaws and bulldozers” (WWF 2019). If then the same WWF contributes to the destruction of this habitat under the umbrella of an eco-friendly model plantation for rubber monocultures, a perfidious peak has been reached. At the same time, the training provided to smallholders to not take environmental aspects into account. They are, according to what interview partners reported, a classic production intensification training.

The social benefits of the RSPO, according to Li (2015), have neither been sufficiently studied nor are they included in socio-economic analyses considering contributions to wealth and jobs. According to our data, the smallholder socially benefits from being organized in farmer groups in the context of RSPO certification. However, farmers could also be supported in setting up farmer groups without being certified. The benefits of increased knowledge exchange and increased bargaining powers would remain even without the RSPO. If farmers benefit economically cannot be answered with our data set, a tendency can be given though. Farmers name the input costs for certification as a challenge but not as the biggest hurdle. This can be traced back to the support they receive from the Indonesian NGO. If farmers had to cover the costs for certification themselves, this would exclude them from the system. At the same time, they do not gain price premiums through RSPO certification because it is expected that farmers are able to generate better yields due to improved management practices. This part has not been covered by our research though. It is quite obvious, at the same time, that the RSPO certification adds stress to the smallholders interviewed. They claim that they need to be certified as they can otherwise no longer access the market. This does not mirror the market reality, as China and India are large importers of palm oil and do not emphasize on certified palm oil (Hein and Kunz 2018). Again, the SNR-i polls off worse. Many farmers are in a replanting process. The decreasing habitat for elephants due to the so-called ‘eco-friendly’ plantation leads to an increase in human-elephant conflicts. Farmers reported that they had to replant several times after their young plants were destroyed by elephants. As the second order effects of the model plantation, the expenditures of smallholder increase. As savings are limited, they lose their independence and start working at the plantation of PT LAJ.

In the case of the Roundtable for Sustainable Palm Oil, it can be argued that the challenges lie in the implementation and control of the rather weak principles and criteria, two aspects reinforcing each other. Further, a discrepancy in the sustainability perception between consumer and producer can explain the limited success of the instrument. Farmers are striving for an increased income and hence an improved livelihood. This might work out on a long-term perspective. Smallholder often follows a shorter-term vision, though. In the case of the Sustainable Natural Rubber Initiative, it can be argued that contrary to the self-description of the Michelin Group, smallholders and their livelihoods are neglected. The creation of new jobs for the local communities in the course of the plantation establishment gives the impression they were unemployed beforehand. Furthermore, some farmers became landless through the large-scale enclosure and ended up as workers on the plantations of PT LAJ or other landowners, a case of primitive accumulation. Referring to an interviewee, the land

compensations paid by PT LAJ are below district compensation standards; they are necessary but not a sufficient condition to build a new livelihood.

This analysis using the smallholder telecoupling framework has revealed second order spillover effects which would have remained hidden otherwise. We strongly urge the concept to take on a more critical perspective. Zimmerer et al. (2018) rather reveal positive spillover effects, such as “the interaction among smallholder producers can lead to the clustering of sustainability-enhancing land use” (ibid.: w.p.). By consciously adding the term conflictive spillovers to the analytical framework, a more comprehensive sustainability potential picture can be drawn.

Supplementary Materials: The supplementary material are available online at http://www.mdpi.com/2076- 0760/8/4/115/s1, the supplementary material consist of the quantitative as well as qualitative questionnaires which were applied in different villages.

Author Contributions: Conceptualization, Y.K.; methodology, I.R.; K.M., F.O.; writing—original draft preparation, Y.K.; F.O. writing—review and editing, Y.K.; I.R.; K.M., F.O.; R.M.; H.F.; supervision, H.F.; funding acquisition, H.F.

Funding: This publication was funded by the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation)—project number 192626868—in the framework of the collaborative German-Indonesian research project CRC 990 (SFB): “EFForTS, Ecological and Socioeconomic Functions of Tropical Lowland Rainforest Transformation Systems (Sumatra, Indonesia).

Acknowledgments: Cartography by Chunyan Xu, Department of Human Geography, Georg-August-University of Goettingen, 37073 Göttingen, Germany, chunyan.xu@stud.uni-goettingen.de.

Conflicts of Interest: The authors declare no conflict of interest.

# Appendix A. SAFA Smallholders Survey

# Basic Information

1. Name of assessor:   
2. Assessing organization:   
3. Date of assessment:   
4. Name of person being interviewed:   
5. Gender of the person being interviewed:

Female   
Male

6. Is this person the farm owner?

Yes   
O No

7. Name of the farm:   
8. The village of the farm:   
9. Country of the farm:   
10. Does the interview take place on or close to the farm?

Yes   
No

11. If you do know the GPS coordinates of your farm, please type them here:   
12. OR Collect the GPS coordinates of the interview (function in the app)   
13. Phone number of interviewee:   
14. E-Mail of interviewee (if any):   
15. What are the main crops and products that you produce?

Main product 1: Main product 6: Main product 2: Main product 7: Main product 3: Main product 8: Main product 4: Main product 9: Main product 5: Main product 10:

16. Which best describes your level of commercialization? (check all that apply)

$\bigcirc$ I am a subsistence farmer $\bigcirc$ I sell mostly to local markets/customers $\bigcirc$ I am a fully commercialized farmer (sell goods mostly for export) $\bigcirc$ I am a contract farmer (with a company or a public-private partnership)

17. Do you produce any livestock on your farm?

Yes No

18. What is the size of the farm (local units and preferably, in hectares)?

# Mission Explicitness

1. Do you have a statement about the farm’s goals and values that you follow and that everyone on your farm understands? [weight: 1]

Yes (green) Partially (yellow) No (red)

# Accountability

2. Do you keep accurate records of your production processes (e.g., planting and harvesting information, input use) so they can be made available to producer organizations, customers or suppliers when required? [weight: 1]

C Always or often (green) $\bigcirc$ Sometimes (yellow) $\bigcirc$ Never or rarely (red)

# Participation

3. Do you belong to a producer organization (or another agriculturally focused organization)? [weight: 1]

a. Yes (green) b. No (red)

4. How much value do you feel the farm receives from being a part of the organization? [weight: 1]

a. Significant value (green) b. Some value (yellow) c. Little or no value (red)

# Conflict Resolution

5. How often have you been able to peacefully and successfully resolve any problems or conflicts that you have experienced with your suppliers, workers, producer organization or buyers? [weight: 1]

$\bigcirc$ Always or often (green)   
$\bigcirc$ Sometimes (yellow)   
$\bigcirc$ Never or rarely (red)   
$\bigcirc$ There have not been any problems or conflicts with other stakeholders (neutral)

# Sustainability Management Plan

6. Do you have a farm management plan that provides for the success of your production in the long run? [weight: 1]

Yes (green)   
No (red)

7. How successful has this plan been? [weight: 1]

Very successful (green)   
$\bigcirc$ Somewhat successful (yellow)   
$\bigcirc$ Not at all or limited success (red)

8. Which elements are part of your plan? [weight: 1] (green for 3 choices or more, yellow for 2 choices, red for 1 choice or less)

 Finances

 Expansion/Staff

 Quality

 Soil fertility management

Health and Safety

 Processing or adding value

 Environmental management

Marketing

 Other

# Profitability

9. Do you produce crops, animals, or agricultural products for sale or trade? [weight: 2]

Yes (green)   
No (red)—no go

10. Do you know your farm revenue for the last production year? [weight: 2]

Yes (green)   
No (red)

11. Do you know your paid labor costs for the last production year? [weight: 1]

Yes (green)   
$\bigcirc$ No (red)   
$\bigcirc$ Not applicable (neutral)

12. Do you know your fertilizer, pesticide, and seeds/plant material costs for the last production year? [weight: 1]

Yes (green)   
No (red)

Not applicable (neutral)

13. Do you know your animal feed, veterinary care, and juvenile stock costs for the last production year? [weight: 1]

Yes (green)   
No (red)   
$\bigcirc$ Not applicable (neutral)

14. During the last five years, how often were farm revenues greater than costs? [weight: 1]

$\bigcirc$ All or most of the time (green)   
$\bigcirc$ Some of the time (yellow)   
$\bigcirc$ Rarely/Never (red)—no go   
$\bigcirc$ I don’t know (yellow)

# Product Diversification

15. How many significant crops, products, or services are offered for sale? [weight: 1]

$\bigcirc$ Three or more significant crops, products, or services (green)   
$\bigcirc$ Two significant crops, products, or services (yellow)   
$\bigcirc$ One significant crop or product (red)

16. Do you do any processing or value adding in order to increase revenue from services or the sale price of your crops or agricultural products (e.g., tourism, butchered meat, drying coffee or fruit, processing jam)? [weight: 1]

Yes (green)   
No (yellow)

# Stability of Market

17. How many buyers do you have for your significant crops or products? [weight: 1]

$\bigcirc$ I usually have multiple people or places to sell my product(s) to (green)   
$\bigcirc$ I usually have one or two people or places to sell my product(s) to (yellow)   
$\bigcirc$ I do not have a regular person or place to sell to (red)

18. How is your relationship with your most important buyer? [weight: 1]

Very reliable and consistent (green)   
$\bigcirc$ Somewhat reliable and consistent (yellow)   
$\bigcirc$ Unreliable (red)—no go

19. Do you feel that you have a choice in where to sell your products? [weight: 1]

Yes (green)   
No (red)

Fair pricing and transparent contracts

20. Do you understand how buyer(s) calculate or establish prices paid? [weight: 1]

○ Always or often (green)

Sometimes (yellow)   
Never or rarely (red)

21. What type of market information did you know during the last production year? [weight: 1] Check all that apply (any of the first three answers gets a green score for the question):

 Prices paid by different buyers throughout the region for the same product   
 Price my buyer received for the product   
 Retail price of the product   
 None (red)

# Liquidity

22. Check the sources from which you could realistically get a loan if you needed one: [weight: 1] (two or more of the first four answers is green, one is red)

 Informal sources, such as friends, relatives, or religious groups   
 Banks, government lending institutions   
 Directly from buyers (exporter, importer, roaster, trader)   
 NGOs, cooperatives, farmer associations, or microfinance group   
 My only option would be to ask a loan shark (red)—no go

23. If you requested a loan during the last year, how much did you receive compared to the amount that you requested? [weight: 1]

All or most (green)   
$\bigcirc$ Some (yellow)   
$\bigcirc$ None (red)—no go   
$\bigcirc$ I did not request a loan during the last year (neutral)

24. Have you set aside savings? [weight: 1]

Yes (green)   
No (red)

# Safety Nets

25. Do you have crop-related insurance? [weight: 1]

$\bigcirc$ Yes (green)   
$\bigcirc$ No (red)   
$\bigcirc$ It is not available (yellow)

26. Do you have a risk management plan that accounts for minimum costs or support in case of harvest loss (e.g., community supported schemes, agreements with cooperatives)? [weight: 1]

Yes (green)   
No (red)

27. Have you implemented on-farm measures to reduce risk from variability in natural conditions and inputs (e.g., building a water tank)? [weight: 1]

Yes (green)   
Some (yellow)   
No (red)

# Food Quality

28. Do you take actions to maintain high-quality in your crops and products (e.g., hygienic processing, proper storing and packaging, grading)? [weight: 1]

Yes (green)   
No (red)

29. During the last two years, have you had a technical quality assessment of any of your main crops or products? [weight: 1]

Yes (green)   
No (red)

# Certified Products

30. Do you produce any crops, animals, or products that meet, or are certified, to a standard? [weight: 1]

Yes (green)   
$\bigcirc$ No (yellow)   
$\bigcirc$ I had a certification, but it was rescinded/taken away (red)—no go

31. How much of your main products or crops are sold as certified? [weight: 1]

$\bigcirc$ All or most (more than $8 0 \%$ ) (green)   
$\bigcirc$ Some $( 4 0 – 8 0 \%$ ) (yellow)   
$\bigcirc$ Not much or none (less than $4 0 \%$ ) (red)

# Legitimacy

32. How do you ensure legal and regulatory compliance in general, including any standard, voluntarily entered into? [weight: 1]

 (green for 2 choices, yellow for 1 choice, red no choice)   
 I use board agendas, other official records or notes of rights and compliances   
 I keep licenses and permits, if required by law   
 I regularly report on compliance to auditors

# GHG Mitigation Practices

33. Which statement best describes the current area covered by trees on your farm? [weight: 1]

$\bigcirc$ About half or more of my farm is covered by trees (green)   
$\bigcirc$ Less than half of my farm is covered by trees (yellow)   
$\bigcirc$ I do not have any trees on my farm (red)

34./35. During the last production year, was there any change to the number of trees on your farm? [weight: 1]

Increase (include planting new trees from cuttings or from seed) (green)   
） Decrease (removing focus crop trees, shade trees, natural forest trees, or other crop trees) (yellow)   
No change (green)

36. What is your main tillage method? [weight: 1 for both GHG and Land]

$\bigcirc$ Conventional (red)   
$\bigcirc$ Reduced (yellow)   
$\bigcirc$ No-till (green)

37. Does your farm consist mostly of ruminant production (e.g., cattle, goats, sheep)? [weight: 1]

Yes (red)   
No (green)

38. What is the main type of manure management system used on the farm? [weight: 1]

$\bigcirc$ Open-air lagoon or discharged into water bodies (red)   
$\bigcirc$ Compost or biodigestion (green)   
$\bigcirc$ Direct use (collected and spread on cropping area, left on pasture) (yellow)

Air Pollution Prevention Practices

39. Do you use a smokeless fuel or chimney to vent smoke when cooking? [weight: 1]

Yes (green)   
No (red)

40. Do you ever burn your fields? [weight: 1 for both Air pollution and Species conservation]

Yes (red)   
No (green)

Soil Improvement Practices

41. What is the main type of fertilizer used on the farm? [weight: 1 for GHG and Soil]

Natural fertilizers applied according to crop and soil needs (green for GHG and Soil)   
Natural fertilizers applied without knowledge of crop or soil needs (yellow for GHG and green for Soil)   
$\bigcirc$ A combination of natural and synthetic fertilizers (yellow for GHG and Soil)   
$\bigcirc$ Synthetic fertilizers applied according to crop and soil needs (yellow for GHG and Soil)   
$\bigcirc$ Synthetic fertilizers applied without knowledge of crop or soil needs (red for GHG and yellow for Soil)   
$\bigcirc$ None (green for GHG and red for Soil)

42. Which of the following are used to improve soil fertility on the farm? [weight: 1] two or more of the first four answers is green, one is yellow

 Cover crops   
 Nitrogen fixing annual or perennial plants   
 Intercropping   
 Crop rotation for maintaining soil health   
 None (red)

# Nutrient Balance

43. How do you determine how much fertilizer (synthetic or natural) to apply to your crop(s)? [weight: 1]

O We apply fertilizer based on a careful assessment of our soil and crops (including farmer observation, professional tests, or analyses) (green)   
$\bigcirc$ We apply fertilizer based on general advice for the region or for our crop(s) (yellow)   
$\bigcirc$ We are not able to fertilize (red)   
$\bigcirc$ We do not use enough fertilizer, but we apply as much as we can afford (yellow)

# Land Conservation and Rehabilitation Practices

44. Which of the following are ways that you manage your soil? [weight: 1] (two or more of the first three answers are green, one is yellow)

 Maintain a permanent soil cover through the mulch, planted soil cover, etc.   
 Terracing or contour planting on areas of significant slope   
 Hedgerows (e.g., trees and shrubs)   
 Soils are often bare between cropping cycles (red)

# Hazardous Pesticides

45. Do you use any synthetic (chemical) pesticides on your farm? [weight: 1 for Pesticides and Water pollution]

Yes (red)   
$\bigcirc$ Only occasionally (yellow)   
No (green)

46. Do any of the synthetic pesticides used on your farm have a red band around the container or on the label? [weight: 1]

Yes (red)—no go   
No (neutral)

47. Do the pesticides used on your farm have labels that you understand? [weight: 1]

Yes, they all have labels with instructions on dosage, safety, etc., that I understand (green)   
Some do not have readable labels (or are unlabeled) (red)—no go

48. Do you ever mix pesticides? [weight: 1]

Yes (red)—no go   
No (green)

# Ecosystem Diversity

49. Did you convert any natural land (prairie, forest, or savannah) to production land during the last five years? [weight: 2 for Ecosystem diversity and weight: 1 for Land]

$\bigcirc$ Yes (red)   
$\bigcirc$ No, there is no natural land on the farm (neutral)   
$\bigcirc$ No, natural land on the farm was left as it is (green)

# Species Conservation Practices

50. Do you have any of the following on your farm to preserve or restore natural species? [weight: 1] (two or more of the first three answers are green, one is yellow)

 Permanent set-aside (land taken out of production to create a habitat for biodiversity)   
 Rehabilitated or restored natural areas   
 Hedgerows or buffer zones   
 None (red)

51. Check all of the pest and disease management practices used for the main crop(s) during the last production year: [weight: 1 for both Species conservation and Hazardous pesticides] (All four first choices should be marked for green, yellow if only some are marked)

 Conduct regular visual examinations of plants to detect pests or disease   
 Use traps, repellents (including repellent species), and natural pesticides   
 Create or preserve places (including plant species) for beneficial predators of pests to live   
 Maintain written record of pest infestation, treatments, and results   
 I use synthetic pesticides specific to the crop and/or pest at the proper dosage and timing (yellow)   
 I apply synthetic pesticides preventatively (e.g., on a regular schedule regardless of whether a pest or disease threat currently exists) (red)

52. Which statement best describes the diversity of your farming system? [weight: 1]

$\bigcirc$ I produce multiple $^ { ( 4 + ) }$ types of crops and/or livestock in the same area (green)   
$\bigcirc$ I produce 2–3 types of crops and/or livestock in the same area (yellow)   
$\bigcirc$ The majority of my farm is used to produce a single crop or one type of livestock (red)

# Saving Seeds and Breeds

53. For the main crops and livestock produced on the farm, do you use any locally adapted varieties of seeds or breeds? [weight: 2]

Yes (green)   
No (red)

54. What is the main source of your seeds or breeds? [weight: 1]

Saved by the farmer, obtained from neighbors, or from a local seed bank (or breeding program for livestock) (green)   
$\bigcirc$ A combination of local and non-local sources (yellow)   
$\bigcirc$ Completely reliant on external non-local sources (red)

# Water Conservation Practices

55. Do you use water conservation practices on the farm? [weight: 1]

Yes (green)   
$\bigcirc$ No (red)   
$\bigcirc$ Sometimes (yellow)

56. Do you irrigate your crops? [weight: 1]

Yes (neutral)

No (green)

57. What form of irrigation do you use? [weight: 1]

$\bigcirc$ Manual irrigation (hand watering) (yellow)   
$\bigcirc$ Surface irrigation (red)   
$\bigcirc$ Drip irrigation (green)

Water Pollution Prevention Practices

58. Which of the following statements apply to your farm? [weight: 1]

The land I use for cultivating crops and/or for pasturing animals is directly next to natural waterways (red)   
$\bigcirc$ Pesticide application equipment is cleaned in natural water bodies (red)   
Untreated domestic or processing water is discharged into natural water bodies (red)   
$\bigcirc$ None (green)

Renewable and Recycled Materials

59. How do you manage crop residues, processing residues, and organic matter? [weight: 2]

$\bigcirc$ Reused (e.g., through compost, as a soil cover, animal feed, biofuel, or other uses) (green)   
$\bigcirc$ Burned or discharged into waterways (red)   
$\bigcirc$ Left in piles or taken off farm (yellow)

60. Do you recycle or reuse metal, plastic containers or bags (with the exception of agrochemical containers), paper or cardboard? [weight: 1]

Yes (green)   
$\bigcirc$ No (red)   
$\bigcirc$ Not applicable (neutral)

Energy Use/Energy consumption/Renewable energy

61. If you use electricity, charcoal, wood, or fuel sources of energy, are you improving your efficiency? [weight: 1]

O I can demonstrate that I reduce energy use (e.g., through fuel-efficient stoves, solar drying, well-maintained machinery, switching from wood to gas) (green)   
I have made some efforts to reduce energy, but I have not applied them to most of my farm (yellow)   
） I do not make any attempts to reduce energy (red)

62. If you used wood or charcoal for energy during the last production year, what was the main source? [weight: 1]

$\bigcirc$ Purchased, I don’t know (yellow)   
$\bigcirc$ Managed natural forest with limited extraction (green)   
$\bigcirc$ Unlimited forest use (red)   
$\bigcirc$ Managed plantations or planted woodlots (green)   
$\bigcirc$ Tree pruning (green)   
$\bigcirc$ Not applicable, I do not use wood or charcoal energy (neutral)

63. Do you use any of the following renewable energy sources for a significant portion of your energy needs? [weight: 1] (any green answer gets green for the indicator)

 Solar (green)   
 Hydropower or geothermal (green)   
 Wind (green)   
 Biofuel from the farm or household waste (green)   
 None of the above (yellow)

Food Loss and Waste Reduction

64. Which of the following best describes your pre- and post-harvest losses (i.e., the amount of crop lost during production, storage, and transport) during the last production year? [weight: 1]

Minimal (less than $1 0 \%$ ) (green)   
$\bigcirc$ Some $( 1 0 - 3 0 \% )$ ) (yellow)   
$\bigcirc$ Substantial (more than $3 0 \%$ ) (red)

65. Do you take active steps to reduce pre- and post-harvest losses on your farm (through improving storage and transport methods, pest/disease management, harvesting at the appropriate time, etc.) [weight: 1]

Yes (green)   
No (red)

Animal Health and Welfare

66. Do you have access to veterinary care for the livestock on your farm? [weight: 1]

I do not have access (red)   
$\bigcirc$ I have access, but it is problematic (unqualified personnel, too costly, too distant, or it is inhumane) (yellow)   
$\bigcirc$ I have access to veterinary services that are of good quality, affordable, and nearby (green)

67. Which statement best describes the way livestock diseases are managed on the farm? [weight: 1]

I give animals medication routinely to prevent them from becoming sick (red)   
$\bigcirc$ I follow my veterinarian or a local expert’s recommendation for the treatment of diagnosed diseases (green)   
I do not consult professionals or experts about animal diseases (yellow)   
O I do not provide my livestock with any veterinary care (red)

Legend

Single choice

 Multiple choice

