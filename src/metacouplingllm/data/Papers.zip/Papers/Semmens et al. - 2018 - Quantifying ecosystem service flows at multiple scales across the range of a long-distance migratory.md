# Quantifying ecosystem service flows at multiple scales across the range of a long-distance migratory

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:05:19.853899+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Semmens et al. - 2018 - Quantifying ecosystem service flows at multiple scales across the range of a long-distance migratory.pdf
- Year: unknown
- DOI: 10.1016/j.ecoser.2017.12.002
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper develops and applies a quantitative framework to measure how ecosystem service benefits from a migratory species flow across regions and social groups, using the eastern North American monarch butterfly as a case. The work is explicitly grounded in the telecoupling concept, treating monarchs as mobile carriers that connect spatially separated ecological source areas and human beneficiaries.

Geographically, the study spans the monarchs full annual range: wintering forests and migration corridors in Mexico, breeding and migration habitats in the southern United States, and breeding regions in the north-central and northeastern U.S. and southern Canada. The system context is a multinational, multi-jurisdictional conservation problem in which monarch populations are declining while people in all three countries value them highly for cultural reasons.

Methodologically, the authors build a spatial subsidies model. They first use a spatially explicit demographic matrix model with five life-cycle regions and a perturbation analysis to derive each region’s proportional contribution to monarch population viability. They then estimate non-market cultural ecosystem service values by combining three data sources: willingness-to-pay survey results for monarch conservation, the imputed value of volunteer time in monarch-focused citizen science, and tourism revenue from monarch overwintering sites in Mexico. These values are allocated to the five regions and, in a refinement, partitioned between rural and urban areas using milkweed distribution (as a habitat proxy) and human population data.

Results show that, when regions are defined by life-cycle stages, benefits received and ecological importance overlap substantially, and net inter-regional subsidies are modest (about 10 percent of annual monarch-related value). Nonetheless, habitats in Mexico provide net support for cultural benefits largely realized in the U.S. and Canada. When the analysis distinguishes rural habitat providers from mainly urban beneficiaries, subsidies become much larger: rural landscapes supply most monarch habitat while urban populations receive most cultural benefits.

The paper is firmly about telecoupling/metacoupling: it quantifies distant ecological-socioeconomic linkages and illustrates how recognizing these flows can inform cross-border and rural-urban conservation incentives, including potential payment-for-ecosystem-services schemes.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via monarch migration linking Mexico, US, and Canada cultural ecosystem services

### Intracoupling
#### Systems
- Monarch habitats within each region such as South, North Central, Northeast
- Rural grasslands and urban areas inside national boundaries
#### Flows
- Local cultural benefits from observing monarchs and citizen science participation
- Intraregional ecosystem service flows supported by nearby monarch habitat
#### Agents
- Residents and households within each migration region
- Local volunteers in monarch monitoring programs
#### Causes
- Regional monarch reproduction and survival conditions
- Availability of milkweed and nectar plants locally
#### Effects
- Regional welfare from willingness to pay for monarch conservation
- Local tourism income at overwintering communities

### Pericoupling
#### Systems
- Adjacent monarch regions such as South and North Central breeding zones
- Neighboring rural and urban landscapes within countries
#### Flows
- Short-distance migration segments between contiguous regions
- Ecosystem service flows between nearby rural providers and city beneficiaries
#### Agents
- Subnational governments coordinating regional monarch conservation
- Agricultural landowners near metropolitan areas
#### Causes
- Seasonal monarch movement across neighboring regions
- Scale mismatches between regional management and ecological processes
#### Effects
- Redistribution of conservation costs between nearby jurisdictions
- Rural areas subsidizing adjacent urban cultural benefits

### Telecoupling
#### Systems
- Mexican overwintering forests and migration corridor
- US and Canadian breeding regions including South, North Central, Northeast
- Urban population centers across North America
#### Flows
- Monarch migration acting as carrier of cultural ecosystem services across countries
- Spatial subsidies where Mexican habitats support benefits enjoyed in US and Canada
- Rural monarch habitats subsidizing cultural benefits for distant urban residents
#### Agents
- National governments of Mexico, United States, and Canada
- Local communities and ejidos managing overwintering forests
- International tourists, donors, and citizen scientists
#### Causes
- Long-distance migratory life cycle requiring multiple habitat regions
- Habitat loss from agriculture intensification and logging in overwintering sites
- Policy interest in payments for ecosystem services across borders
#### Effects
- Net monetary subsidies from Mexican habitats toward US and Canadian beneficiaries
- Conservation burden concentrated on rural and Mexican communities
- Need for international cost sharing and cross-border conservation planning

### Cross-Coupling Interactions
- Telecoupled subsidies overlay intracoupled local benefits within each monarch region
- Rural to urban subsidies intersect with international subsidies from Mexico to northern countries
- Changing agricultural practices simultaneously alter local dynamics and distant benefit flows

### Research Gaps or Limitations
- Nonmarket cultural benefits only partially captured by willingness to pay, tourism, volunteering
- Limited socioeconomic data for Mexico and lack of citizen science there
- Urban rural partition extrapolated from one region to entire range with uncertainty

### Search Keywords
- monarch butterfly telecoupling spatial subsidies ecosystem services
- migratory species cultural ecosystem services Mexico US Canada
- rural urban subsidies payments for ecosystem services monarchs

### Extraction Confidence
high
