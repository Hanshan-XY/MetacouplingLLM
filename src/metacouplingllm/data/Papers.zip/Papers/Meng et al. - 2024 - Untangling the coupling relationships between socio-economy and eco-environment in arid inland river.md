# Untangling the coupling relationships between socio-economy and eco-environment in arid inland river

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:59:09.669845+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Meng et al. - 2024 - Untangling the coupling relationships between socio-economy and eco-environment in arid inland river.pdf
- Year: unknown
- DOI: 10.1007/s10668-023-03439-y
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study analyzes how social-economic development and eco-environmental conditions interact in the Heihe River Basin, the second-largest inland river basin in arid northwest China. The basin is divided into upstream, midstream, and downstream reaches, all tightly constrained by scarce water. A major ecological water allocation policy, the Ecological Water Dividing Plan (EWDP), was launched around 2000 to limit midstream water use and restore degraded downstream ecosystems.

The authors construct a socio-economic index (SEI) from gridded GDP and nighttime light data and an eco-environment index (RSEI) from MODIS-based greenness, wetness, heat, and dryness. Using data mainly from 2000 to 2018, they map spatial patterns and trends, then apply a coupling coordination model to assess how well socio-economy and eco-environment develop together, a scissors difference model to compare their relative growth rates, and environmental Kuznets curves to capture telecoupled relationships between different reaches.

Eco-environmental quality improves overall, especially in midstream oases and the downstream Ejina Oasis, while socio-economic development accelerates most strongly in the midstream. Coupling and coordination between socio-economy and eco-environment rise across the basin, with substantial gains upstream and downstream. Development speed relationships follow N- or W-shaped trajectories, indicating shifting phases of conflict and harmony between economic growth and environmental improvement.

A key telecoupling finding is that downstream ecological recovery is strongly linked to midstream socio-economic dynamics through water flows. Before EWDP, higher midstream crop yields were associated with reduced downstream runoff and environmental degradation. After EWDP and improvements in water-use efficiency, this relationship reverses: midstream production continues growing while downstream ecosystems recover. Environmental Kuznets curves show an N-shaped relationship, with downstream conditions more sensitive to midstream than upstream economies.

The paper explicitly addresses telecoupling within a single basin: water reallocations create long-distance cause-effect links between midstream economic activity and downstream ecological outcomes. It offers a transferable framework for evaluating how water policy reshapes local coupling and cross-reach telecoupling in arid inland river systems.

## Structured Metacoupling Extraction

### Coupling Classification
- Analyzes local coupling within river reaches and telecoupling among reaches via shared water resources

### Intracoupling
#### Systems
- Socioeconomic system of each reach using GDP, lights, population, crop yield
- Ecoenvironmental system of each reach using remote sensing ecological index
#### Flows
- Local water use for irrigation, industry, households within each reach
- Land use and oasis expansion affecting local water and ecology
#### Agents
- Local governments managing land and water in each reach
- Farmers and urban residents driving water demand
- Tourism operators in downstream oases
#### Causes
- Rapid urbanization and oasis agriculture increasing water withdrawals
- Implementation of ecological protection and water saving policies
- Climate driven changes in runoff from upstream mountains
#### Effects
- Changing coordination between economic growth and ecological quality
- Oasis restoration or degradation depending on local water allocation
- Stage specific antagonism or synergy in development speeds

### Pericoupling
#### Systems
- Not identified.
#### Flows
- Not identified.
#### Agents
- Not identified.
#### Causes
- Not identified.
#### Effects
- Not identified.

### Telecoupling
#### Systems
- Midstream socioeconomic system linked with downstream oasis ecosystem
- Upstream socioeconomic system linked with downstream ecoenvironment
- Subcatchments of Heihe River Basin connected by controlled river flows
#### Flows
- Managed river discharge from midstream to downstream under water division plan
- Environmental flow releases to restore downstream lakes and vegetation
- Telecoupled runoff changes from mountain headwaters to terminal desert oases
#### Agents
- River basin authority implementing ecological water division project
- Provincial and county governments negotiating cross reach water quotas
- Agricultural sector adapting irrigation and improving water productivity
#### Causes
- Ecological water division policy reallocating water from midstream to downstream
- Historical overuse of water in middle reaches degrading lower oasis ecosystems
- Need to balance basinwide sustainability and COP style climate water goals
#### Effects
- Downstream ecological recovery tightly linked to midstream economic behavior
- Shift from negative to positive correlation between midstream farming and downstream runoff
- Reduced tradeoffs and emerging synergy between midstream economy and downstream ecology

### Cross-Coupling Interactions
- Telecoupling modifies local coupling indicators in all reaches over time
- Improved midstream water efficiency enables downstream restoration without long term midstream economic loss
- N shaped Kuznets telecurves show stage dependent tradeoff and synergy across reaches

### Research Gaps or Limitations
- Telecoupling modeled with one chosen cubic EKC form; results may depend on functional choice
- Telecoupling only analyzed among reaches; lacks finer grid scale interaction assessment
- Suggests future multiscale, frequency based methods to better capture distant interactions

### Search Keywords
- Heihe River Basin telecoupling water reallocation
- ecological water diversion socio economy eco environment coupling
- environmental Kuznets curve arid inland river

### Extraction Confidence
high
