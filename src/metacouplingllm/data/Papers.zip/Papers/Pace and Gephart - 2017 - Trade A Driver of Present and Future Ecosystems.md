# Trade A Driver of Present and Future Ecosystems

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:01:42.509980+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Pace and Gephart - 2017 - Trade A Driver of Present and Future Ecosystems.pdf
- Year: unknown
- DOI: 10.1007/s10021-016-0021-z
- OA status: closed
- License: none recorded
- Category: Journal Articles\Review\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This review paper examines how international trade acts as a major but under-recognized driver of ecosystem change. It is global in scope, with examples from North and South America, Europe, Asia, and marine systems worldwide. The authors work within ecosystem science but explicitly connect to telecoupling and social-ecological systems research.

They first show, via a Web of Science survey of leading ecology journals (2006-2015), that trade rarely appears as a topic in mainstream ecological research, aside from work on invasive species and some sustainability studies. Yet, trade strongly shapes ecosystem mass balances. Using examples for nitrogen and phosphorus, the paper explains how traded fertilizers, animal feeds, food, and agricultural products reallocate nutrients among regions, disturbing biogeochemical cycles and creating geographically uneven pollution and soil depletion.

The authors then review evidence that trade accelerates depletion of biological resources and land conversion. Cases include serial and parallel overfishing (for example, sea cucumbers), deforestation and logging for export crops and timber, and the resulting impacts on biogeochemistry, hydrology, biodiversity, and carbon storage. They also highlight how trade transports alien species and pathogens, both intentionally and unintentionally, reshaping communities and ecosystem processes over long time scales.

A major contribution is the explicit framing of trade as a generator of telecouplings: distant cause-effect linkages between sending, receiving, and spillover systems. Examples include European demand driving Brazilian deforestation while allowing European reforestation and carbon sequestration, as well as market-driven overgrazing in China increasing locust outbreaks that affect distant food systems. The paper emphasizes that feedbacks, financial instruments, and multicausal interactions make these telecouplings complex and potentially surprising.

The authors argue that trade is central to metacoupling research but still under-integrated into ecosystem science. They call for better trade data, finer taxonomic and spatial resolution, and new modeling approaches that link trade flows to ecosystem processes, services, and resilience at multiple scales.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong focus on telecoupling created by international trade in ecosystem goods and services.

### Intracoupling
#### Systems
- River watersheds receiving traded fertilizer and feed inputs.
- Agricultural landscapes accumulating or losing soil phosphorus.
- Local ecosystems altered by invasive species establishment.
#### Flows
- Nutrient inputs from imported fertilizers and animal feed.
- Phosphorus recycling via manure within farming systems.
- Biotic interactions among native and alien species.
#### Agents
- Farmers managing fertilizer, feed, and manure.
- Local fishers, loggers, and resource users.
- Invasive species such as zebra mussels.
#### Causes
- Local management responding to market signals and trade opportunities.
- Internal nutrient budgeting and mass balance dynamics.
- Species introductions followed by local population expansion.
#### Effects
- Changed nitrogen and phosphorus budgets in watersheds and farms.
- Soil fertility shifts and eutrophication in nearby waters.
- Reorganized food webs and productivity within invaded systems.

### Pericoupling
#### Systems
- Neighboring river basins linked by regional commodity flows.
- Adjacent coastal fisheries and nearshore ecosystems.
- Bordering countries connected by regional agricultural trade.
#### Flows
- Regional trade in crops, livestock, and fertilizers.
- Fishery products moving through nearby ports and markets.
- Spread of invasive species along regional transport routes.
#### Agents
- Regional traders and commodity brokers.
- Fishery companies and processing plants.
- Regional plant and animal health authorities.
#### Causes
- Shifts in regional demand for food, timber, and seafood.
- Policy changes restricting harvest in one region, displacing effort.
- Infrastructure linking nearby production and consumption areas.
#### Effects
- Leakage of resource extraction to neighboring regions.
- Parallel depletion of similar resources across nearby ecosystems.
- Regional spread of invasive species and pathogens.

### Telecoupling
#### Systems
- Latin American exporting regions and European importing regions.
- Tropical shorelines supplying sea cucumbers to East Asian markets.
- Producing countries and distant consumers of virtual water and nutrients.
#### Flows
- Global trade in cereals, seafood, timber, and livestock feed.
- Embodied nitrogen, phosphorus, and carbon in traded commodities.
- International movement of alien species and disease vectors.
#### Agents
- Multinational corporations, traders, and certification bodies.
- National governments, customs agencies, and trade organizations.
- Ecological agents like locust swarms and invasive mussels.
#### Causes
- Rising global demand and price incentives for food, timber, and bioresources.
- Land acquisitions, fishing access deals, and export-oriented agriculture.
- Improved shipping, communication, and financial markets expanding trade networks.
#### Effects
- Deforestation in exporters and forest regrowth in importers altering carbon sinks.
- Serial or parallel resource depletion across distant ecosystems.
- Global redistribution of nutrients, water use, and invasive species risks.

### Cross-Coupling Interactions
- Trade-driven telecouplings reshape local mass balances and resource depletion patterns.
- Alien species introduced via trade alter ecosystem function and feed back on services.
- Commodity markets, finance, and ecological responses interact to create complex feedbacks.

### Research Gaps or Limitations
- Limited integration of trade as an ecosystem driver in ecological journals and studies.
- Coarse, incomplete trade data, especially species-level wildlife and fisheries tracking.
- Scale mismatch between national trade statistics and local ecosystem processes and impacts.

### Search Keywords
- telecoupling trade ecosystems nutrients invasions
- global commodity flows deforestation fisheries virtual water
- mass balance phosphorus nitrogen alien species land-use change

### Extraction Confidence
high
