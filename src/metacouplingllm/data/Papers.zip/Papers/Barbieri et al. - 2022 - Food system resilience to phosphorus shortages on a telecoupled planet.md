# Food system resilience to phosphorus shortages on a telecoupled planet

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:28:07.921076+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Barbieri et al. - 2022 - Food system resilience to phosphorus shortages on a telecoupled planet.pdf
- Year: unknown
- DOI: 10.1038/s41893-021-00816-1
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study analyzes how global food systems depend on non-renewable phosphorus (P) fertilizers under conditions of strong telecoupling through international trade. The authors focus on national vulnerabilities to future disruptions in phosphate rock and P fertilizer supply.

The work is global in scope, covering 163 countries and about 95 percent of world agricultural trade (by mass) between 2013 and 2016. The system context is the intertwined network of phosphate rock mining, fertilizer production, soil P stocks, and trade in crops and livestock products. Using FAOSTAT bilateral trade data and crop-specific P fertilization rates, the authors calculate virtual P use for exports, meaning the mineral P applied in producing traded commodities. They combine this with country data on plant-available soil P and on phosphate rock extraction/reserves, primarily from USGS and global soil datasets.

They find that roughly one quarter of total P fertilizer applied globally is associated with exported crops and livestock products, with Latin America a major virtual P exporter and East Asia a major importer. Export-oriented crops tend to receive more P per hectare than crops for domestic use, especially oilseeds like soybean and rapeseed. Comparing virtual P use with domestic soil P and rock reserves, the study classifies exporting countries into four groups: (A) low resilience, with little rock and low soil P; (B) short-term buffering via high legacy soil P; (C) relatively high resilience, with both soil P and rock reserves; and (D) low virtual P use or marginal exporters. Many key exporters fall into vulnerable categories despite their importance for global markets.

The paper is explicitly about telecoupling of P: it applies and extends the telecoupling framework to mineral nutrients, highlighting distant dependencies between fertilizer-supplying countries, export-oriented producers, and import-dependent consumers. It shows how trade decouples different P stocks, complicates recycling, and can propagate shocks and price spikes across borders. The authors argue that enhancing P recycling, managing legacy soil P, and coordinating among trade partners are necessary to improve resilience of telecoupled food systems to P shortages and market volatility.

## Structured Metacoupling Extraction

### Coupling Classification
- Primarily telecoupling of phosphorus in globalized food and fertilizer trade networks

### Intracoupling
#### Systems
- National agricultural production systems dependent on mineral and soil phosphorus
- Domestic phosphate rock mining and fertilizer manufacturing sectors
#### Flows
- Mineral phosphorus fertilizer applied to crops and pastures
- Legacy phosphorus accumulation and depletion in national agricultural soils
- Phosphorus recycling from manure and wastewater to domestic cropland
#### Agents
- Domestic farmers and livestock producers
- National fertilizer producers and mining companies
- National governments and resource regulators
#### Causes
- Intensification of agriculture and high fertilizer input strategies
- National policies on phosphorus use and environmental protection
- Historical over fertilization creating soil phosphorus legacies
#### Effects
- Changes in national food production and export capacity
- Soil fertility buffers against short term fertilizer shortages
- Water quality and environmental impacts from phosphorus mismanagement

### Pericoupling
#### Systems
- Neighboring or regional trade partners exchanging agricultural commodities
- Regional food and fertilizer markets within continents
#### Flows
- Cross border trade of crops, livestock products, and processed foods
- Regional displacement of embedded and virtual phosphorus in commodities
#### Agents
- Regional trade blocs and economic unions
- Export oriented agribusinesses operating across nearby countries
#### Causes
- Regional specialization in fertilizer production or crop exports
- Proximity driven trade agreements and logistics advantages
#### Effects
- Shared exposure to fertilizer price shocks within regions
- Cascading export restrictions affecting neighboring importers

### Telecoupling
#### Systems
- Phosphate rock reserve countries supplying global fertilizers
- Export oriented agricultural countries with limited domestic phosphorus
- Food importing countries relying on overseas phosphorus intensive production
#### Flows
- Virtual phosphorus use embedded in internationally traded crops and livestock products
- Trade of phosphate rock and processed phosphorus fertilizers
- Displacement of phosphorus recycling opportunities from exporters to importers
#### Agents
- Global fertilizer and mining corporations controlling phosphorus supply
- National governments setting export tariffs and trade restrictions
- International traders and supply chain actors in food and feed markets
#### Causes
- Geopolitically concentrated phosphate rock reserves in few countries
- Rising global demand for meat, feed, and processed foods
- Trade liberalization and globalization of food supply chains
#### Effects
- Interdependent vulnerabilities to phosphorus shortages and price spikes
- Risk of cascading food supply disruptions across trading networks
- Unequal environmental burdens from phosphorus use in exporting regions

### Cross-Coupling Interactions
- Domestic soil phosphorus legacies mediate national exposure to international fertilizer disruptions
- Exporters with low resilience transmit phosphorus shocks to distant food importers
- Telecoupled trade hampers returning recyclable phosphorus from importing to exporting countries

### Research Gaps or Limitations
- National average data mask strong subnational variation in fertilizer use and soil phosphorus
- Uncertain fertilizer application rates for many low income or minor producer countries
- Environmental risks of virtual phosphorus trade along full supply chain remain poorly quantified

### Search Keywords
- telecoupling phosphorus virtual P trade food system resilience
- phosphate rock reserves fertilizer trade vulnerability
- soil legacy phosphorus global agricultural exports

### Extraction Confidence
high
