# A novel telecoupling framework to assess social relations across spatial scales for ecosystem servic

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:58:10.962632+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Martin-Lopez et al. - 2019 - A novel telecoupling framework to assess social relations across spatial scales for ecosystem servic.pdf
- Year: unknown
- DOI: 10.1016/j.jenvman.2019.04.029
- OA status: closed
- License: none recorded
- Category: Journal Articles\Methodological\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This methodological paper develops a new way to analyze how social relations across spatial scales shape access to and control over ecosystem services. It is explicitly grounded in telecoupling thinking, extending it beyond material and ecological flows to include power-laden social interactions.

The authors propose the cross-scale influence-dependence framework. The focal system is any landscape providing a set of ecosystem services, with actors considered at local, regional, and global levels. The framework unfolds in four steps: identifying relevant actor groups at each scale; assessing how strongly each group depends on the services for its wellbeing; assessing how much each group can influence decisions on service management; and mapping social relations and power dynamics within and across scales. They adapt tools from stakeholder analysis, political ecology, and social network research, and list qualitative and quantitative methods that can be combined (interviews, surveys, interest-influence matrices, participatory mapping, actor-linkage matrices, social network analysis, institutional ethnography).

The framework is tested retrospectively in four contrasting case studies: small-scale coral reef fisheries in southern Kenya; traditional irrigated farming in the Nacimiento watershed (Spain); nature-based tourism in the Piedra River valley (Spain); and a grass-based dairy landscape in Voeren (Belgium). These cases span Africa and Europe and cover fisheries, agriculture, and tourism systems.

Across cases, local resource users (farmers, fishers, residents) are highly dependent on ecosystem services but have limited influence in decision-making, especially beyond the local scale. In contrast, decision-makers, tourism operators, agribusiness, and other remote actors gain influence with scale, often shaping management through laws, policies, investment, and knowledge networks. This generates scale mismatches, distributional inequities in who gains or loses from ecosystem service trade-offs, and procedural inequities in whose voices count.

The paper clearly engages with telecoupling and metacoupling debates: it treats cross-scale social and institutional relations as inter-regional flows that drive ecosystem service provision and distribution, and it identifies how distant, powerful actors can reconfigure local landscapes and vulnerabilities.

## Structured Metacoupling Extraction

### Coupling Classification
- Explicit telecoupling focus using cross scale social relations for ecosystem services
- Covers intra system social ecological dynamics at local landscapes
- Analyzes peri and distant multi level governance links affecting local services

### Intracoupling
#### Systems
- Local coral reef social ecological systems along southern Kenya coast
- Traditional farming landscape in Nacimiento watershed Spain
- Local grass based dairy and tourism landscapes in Europe
#### Flows
- Local use of food, fodder, fish, cultural and regulating services
- Information and influence flows within villages and farmer communities
- Benefits and costs of local conservation and modernization projects
#### Agents
- Fish workers, local residents, traditional farmers, dairy farmers
- Local NGOs, irrigation communities, village councils
- Local tourism workers and small tourism businesses
#### Causes
- Local livelihood dependence on ecosystem services for wellbeing
- Historical farming and irrigation practices shaping landscapes
- Local governance arrangements and informal institutions
#### Effects
- Vulnerability of local users with high dependence and low influence
- Changes in landscape aesthetics, erosion and hydrological regulation
- Local conflicts over access to fishery, water and land

### Pericoupling
#### Systems
- Rural landscapes and nearby urban or regional centers
- Protected areas and surrounding agricultural communities
- Regional tourism destinations and adjacent source communities
#### Flows
- Regional tourists visiting rural and coastal sites
- Regional policies and funding for irrigation and conservation
- Knowledge exchange between regional scientists and local managers
#### Agents
- Regional decision makers and environmental agencies
- Regional tourism industry and agro business actors
- Regional NGOs and research institutions
#### Causes
- Scale mismatches between ecosystem service benefits and governance
- Regional aims for water efficiency and agricultural intensification
- Promotion of nature based tourism in rural areas
#### Effects
- Unequal distribution of tourism and agricultural benefits
- Modernization of irrigation reducing regulating services
- Shifts in local identity and traditional practices

### Telecoupling
#### Systems
- Global tourism markets linked to Kenyan coral reefs and European rural areas
- International science and conservation networks connected to local sites
- European Union and national policy arenas shaping local irrigation systems
#### Flows
- International tourists and capital into coastal and rural tourism sectors
- Global conservation and fisheries guidelines influencing national policies
- Multi level information, research and governance networks across countries
#### Agents
- International tourism companies and elite nonlocal investors
- International scientists and conservation organizations
- Supranational and national policy makers on water and agriculture
#### Causes
- Global demand for tourism, fish and agricultural products
- Telecoupled governance through international guidelines and legislation
- External interest in ecosystem services and biodiversity conservation
#### Effects
- Concentration of decision power at regional and global levels
- Local losers such as fishers and traditional farmers despite global benefits
- Intensified trade offs between provisioning and regulating services

### Cross-Coupling Interactions
- Cross scale influence dependence framework traces how distant actors shape local service access
- Regional and global decision makers reconfigure local landscapes through top down water and fishery rules
- Scientists, managers, and tourism industry act as brokers linking local and distant governance levels

### Research Gaps or Limitations
- Primarily retrospective case study applications rather than prospective testing
- Limited treatment of biophysical teleconnections compared to social relations
- Need quantitative hypotheses testing on equity, trade offs and telecoupled power

### Search Keywords
- telecoupling cross scale influence dependence framework ecosystem services
- power relations distributional procedural equity fisheries irrigation tourism
- social network analysis multilevel governance scale mismatch vulnerable actors

### Extraction Confidence
high
