# The influence of urbanization on vegetation carbon pools under a tele-coupling framework in China

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:16:08.149755+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Yin - 2022 - The influence of urbanization on vegetation carbon pools under a tele-coupling framework in China.pdf
- Year: unknown
- DOI: 10.1007/s10668-021-01603-w
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper analyzes how rapid urbanization in China affects vegetation carbon pools, explicitly using a tele-coupling framework to capture cross-provincial economic linkages. The study covers all 31 provincial-level regions in mainland China from 2010 to 2015 and focuses on vegetation carbon storage and net primary productivity (NPP) as key components of terrestrial carbon pools.

The author combines 30 m land-use maps, a national vegetation carbon density map based on detailed vegetation types, MODIS NPP data, and a 2012 multiregional input-output (MRIO) table for China. Urban expansion is mapped by detecting conversions of cropland, woodland, and grassland to urban land, treating vegetation carbon density and NPP in urban cells as zero. The MRIO model then allocates portions of this urban expansion and associated carbon loss to interprovincial trade, representing tele-coupled effects.

Between 2010 and 2015, about 31,800 km2 of other land types were converted to urban areas. More than half of this came from cropland, with smaller but significant shares from woodland and grassland. Urban growth was concentrated in the North China Plain and the Yangtze River Basin. The resulting vegetation-related carbon loss totaled roughly 6.8×108 t, with about 39 percent from reduced vegetation carbon storage and 61 percent from reduced NPP. Losses generally declined from southeast to northwest, reflecting underlying biomass gradients.

The tele-coupling analysis shows that some provinces, notably Hebei and Inner Mongolia, experienced large urban land expansion and carbon loss driven by demand from other provinces. In contrast, coastal and more developed provinces such as Jiangsu, Zhejiang, Shandong, Guangdong, Shanghai, Beijing, and others were major drivers of urban expansion and carbon loss outside their own borders. Provinces with high biomass, especially in southern China, tend to bear disproportionate tele-coupled carbon losses when their vegetated land is converted.

This work is explicitly about telecoupling/metacoupling: it links economic interactions to spatially explicit land conversion and carbon impacts, reveals regional inequities, and suggests that low-carbon land-use strategies and compensation mechanisms should consider these interregional tele-coupled effects.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling among Chinese provinces via trade driven urban expansion and vegetation carbon loss

### Intracoupling
#### Systems
- Provincial terrestrial ecosystems within China
- Urban and vegetated land within each province
#### Flows
- Conversion of cropland woodland grassland to urban land
- Within province vegetation carbon and NPP changes
#### Agents
- Provincial governments and planners
- Local industries and households
#### Causes
- Economic and social development within provinces
- Population growth and internal urbanization demand
#### Effects
- Provincial vegetation carbon storage reduction
- Provincial NPP decline and carbon sink weakening
- Loss of local woodland grassland ecological services

### Pericoupling
#### Systems
- Neighboring or economically linked Chinese provinces
- Coastal versus inland provincial clusters
#### Flows
- Near regional trade in industrial and consumer goods
- Regionally clustered urban land expansion fronts
#### Agents
- Interprovincial trading firms and supply chains
- Regional planning and economic coordination bodies
#### Causes
- Spatially uneven economic development along coast and basins
- Regional trade integration and industrial specialization
#### Effects
- Urban expansion belts in North China Plain and Yangtze Basin
- Shared regional hotspots of vegetation carbon loss

### Telecoupling
#### Systems
- Economically advanced coastal provinces as receiving systems
- Less developed interior provinces as sending systems
- National interprovincial trade network as coupling medium
#### Flows
- Embodied urban land expansion driven by domestic trade
- Embodied vegetation carbon storage loss and NPP loss
- Interregional export and import of carbon loss responsibility
#### Agents
- Provincial economies represented in MRIO sectors
- National government designing land and trade policies
- Energy and resource intensive industries
#### Causes
- Trade driven demand for goods produced in other provinces
- Assumption that economic growth solely drives urban expansion
- Spatial mismatch between production locations and consumption
#### Effects
- Hebei and Inner Mongolia urban growth heavily pulled by external demand
- High trade embodied carbon loss in Hunan Guizhou Hainan Guangxi Jiangxi Hubei
- Importing provinces like Shanghai Shandong Guangdong Zhejiang externalize carbon loss

### Cross-Coupling Interactions
- Telecoupled trade flows reshape intracoupling of land use and carbon within sending provinces
- Pericoupled economic clusters amplify telecoupled urban expansion and carbon loss
- Spatial heterogeneity in biomass decouples land loss patterns from carbon loss patterns

### Research Gaps or Limitations
- Vegetation carbon densities assumed constant ignoring ongoing carbon accumulation
- Soil organic carbon dynamics excluded for 2010 2015 period
- MRIO trade structure fixed at 2012 for whole study interval

### Search Keywords
- telecoupling urbanization China vegetation carbon NPP MRIO
- embodied land use trade driven carbon loss provinces
- urban expansion cropland woodland grassland carbon pools

### Extraction Confidence
high
