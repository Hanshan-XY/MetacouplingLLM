# Intelligence Briefing

Cite this article: Ortiz, A. M. D., Baeza-González, S., Jensen, M., Huaico Malhue, A., Lavín-Oviedo, U., Celis-Diez, J. L. (2025). Telecoupled social–ecological systems: the case of avocado in Chile. Global Sustainability, 8, e23, 1–10. https://doi.org/ 10.1017/sus.2025.10011

Received: 26 June 2024 Revised: 31 January 2025 Accepted: 3 June 2025

Keywords: avocado; consumption; Chile; international trade; social–ecological system; telecoupling; water crisis; water conflict; water footprint; pollinators

Corresponding author: Andrea Monica D. Ortiz; Email: monicaortiz@udec.cl

# Telecoupled social–ecological systems: the case of avocado in Chile

Andrea Monica D. Ortiz1,2 , Sebastián Baeza-González1 , Magdalena Jensen3 , Ana Huaico Malhue4 , Uranía Lavín-Oviedo5 and Juan L. Celis-Diez2,6,7

1Departamento de Geografía, Facultad de Arquitectura, Urbanismo, y Geografía, Universidad de Concepción, Concepción, Victoria 486-490, Chile; 2Instituto de Ecología y Biodiversidad, Barrio Universitario, Concepción, Victoria 631, Chile; 3Departamento de Ingeniería Industrial, Facultad de Ingeniería, Universidad de Concepción, Concepción, Edmundo Larenas 219, Chile; 4Departamento de Prevención de Riesgos y Medio Ambiente, Facultad de Ciencias de la Construcción y Ordenamiento Territorial, Universidad Tecnológica Metropolitana, Santiago, Dieciocho 390, Chile; 5Centro de Investigación e Innovación para el Cambio Climático, Universidad Santo Tomás, Santiago, Chile; 6Escuela de Agronomía, Pontificia Universidad Católica de Valparaíso, Calle San Francisco, Quillota, La Palma 2260000, Chile and 7Centro Regional de Investigación e Innovación para la Sostenibilidad de la Agricultura y los Territorios Rurales (CERES), Quillota, Chile

# Abstract

Non-Technical Summary. Avocados are a widely consumed fruit and are part of many Latin American cuisines and plant-based diets globally. However, producing avocados is waterintensive, and plantations can cause soil erosion and water stress. In Chile, avocados are produced in semiarid zones and require irrigation. They are widely consumed locally but are increasingly exported to meet growing global demand. This causes significant local conflicts over water, especially because of the system of private water rights in Chile. There are many gaps in understanding the complex and interconnected system of avocado production and international markets, especially its impacts on local communities and biodiversity.

Technical Summary. The popularity of avocados has increased globally in alternative diets, alongside its integral role in Latin American cuisine. In Chile, avocados are grown extensively and intensively in orchards in the dry and Mediterranean climate of Central Chile. Avocado is a water-demanding crop and the severe water crisis in Chile has called attention to the conflicts caused by its water use. As most of the pressure to produce avocado comes from international demand but results in impacts on native ecosystems and local communities, avocado production in Chile is an example of a telecoupled system. Here, we characterize avocado production as a telecoupled social–ecological system in order to identify gaps in knowledge, based on a review of key studies. Research priorities include how to improve water-use efficiency, especially in the context of climate change; the impacts on biodiversity; and the socioeconomic dynamics between local communities, trade, and governance. The analysis is constrained by limited access to data and few interdisciplinary studies on the matter. To reduce the impacts of avocado production and increase its sustainability, there is an urgent need to amplify the interdisciplinary research that emphasizes the interconnections between the social and ecological components in avocado production in Chile.

Social Media Summary. Global avocado demand fuels local conflicts in Chile due to water stress and social–ecological pressures on communities.

$\circledcirc$ The Author(s), 2025. Published by Cambridge University Press. This is an Open Access article, distributed under the terms of the Creative Commons Attribution-NonCommercial licence (http:// creativecommons.org/licenses/by-nc/4.0), which permits non-commercial re-use, distribution, and reproduction in any medium, provided the original article is properly cited. The written permission of Cambridge University Press must be obtained prior to any commercial use.

![](images/12f169fb59809fc784922bb162ba510832917d8f9bed5a498e7a901f35a72387.jpg)

CAMBRIDGE UNIVERSITYPRESS

# 1. Introduction

Avocado is a tropical fruit that has become one of the most traded agricultural commodities worldwide (Caro et al., 2021). It is an important source of fats and vitamins, and is popular in alternative Western diets as a ‘superfood’ (e.g. Laroche et al., 2020; Ohlau et al., 2023). Over the past 20 years, the global demand for avocado (Persea americana) has increased significantly (Magrach & Sanz, 2020). This has led to both expansion and intensification of avocado production in Mexico, Chile, and Peru, the world’s biggest producers and exporters of avocados (Armesto et al., 2010; Denvir et al., 2022; Magrach & Sanz, 2020). Economic globalization and free trade agreements promoted the expansion of avocado production, moving from domestic consumption to international markets (Armesto et al., 2010).

The high water demand of avocado has fueled the debate concerning its sustainability. A significant water crisis in 2018 called public attention to the responsibility of international demand for avocado amidst a mega-drought in Chile, with Petorca in Central Chile emerging as a key symbol of this crisis (Facchini & Laville, 2018). The avocado boom has led to severe

water scarcity, reversing the region’s focus from subsistence crops to export-oriented avocados (Duran-Llacer et al., 2020; Madariaga et al., 2021; Sommaruga & Eldridge, 2021). This shift has threatened local communities’ rights to water, forcing them to rely on cistern trucks for their water supply (Madariaga et al., 2021). Local authorities have taken minimal action, resulting in socioecological conflict driven by the water crisis (Berasaluce et al., 2021).

An analysis of avocados’ virtual water (see Dalin et al., 2017, 2019) showed that Mexico exported 1369 mega cubic meters of water $( \mathrm { M m } ^ { 3 } )$ , while Peru and Chile exported 198 and $1 4 4 \mathrm { M m } ^ { 3 }$ of virtual water, respectively, in 2016 (Caro et al., 2021). This quantity is significant, considering the water crisis in Chile and exacerbated by the mega-drought that reduced water reservoirs by up to $4 0 \%$ (Garreaud et al., 2017, 2020). However, conflicting evidence exists regarding the environmental impacts of the crop, arguably because of the fruit’s high value in the agroindustry.

For example, a recent report by a UNESCO body based in Chile asserts that the sector uses water responsibly (Centro del Agua para Zonas Áridas y Semiáridas de América Latina y el Caribe (CAZALAC), 2020). Based mainly on grey literature, the report claims that avocado orchards which replace native ecosystems become new habitats for diverse species. The agroindustry also promotes that avocados consume less water than meat production, are not harmful to the hilly terrain nor water resources, and that they capture carbon, therefore being a boon to the environment (Comité de Paltas, 2023). These reports contrast with scientific studies on the matter: while it is true that the water footprint of avocado is a fraction of what is required to produce beef, pork or poultry (Mekonnen & Hoekstra, 2011), a life-cycle analysis that compared avocado to other fruits and vegetables – rather than meat production – showed that avocado is linked to significant water stress, based on the water scarcity of the growing region and the ratio of irrigated water consumed to the yield (Stoessel et al., 2012). In addition, the concentration of avocado production in countries of extreme water stress such as Mexico, Peru, and Chile (World Resources Institute, 2023) means that these climatevulnerable zones bear the brunt of the environmental impacts (Caro et al., 2021).

Avocado orchards significantly affect the ecosystems that they form part of. Cultivated areas along steep hillslopes increase erosion and runoff, reducing infiltration and groundwater recharge, thus aggravating water shortages during periods of drought (Youlton et al., 2010). Regional climate change projections show increases in temperature, and changes in precipitation that may increase the risk of droughts (Salazar et al., 2024), an undesirable outcome in a region threatened by water scarcity. This is exacerbated by Chile’s unique model for private water rights, rooted in neoliberal principles, that often leads to overexploitation and unequal access (Box 1).

# Box 1. Water rights in Chile.

Chile’s water resources are primarily governed by the Water Code, which was enacted in 1981 and has undergone several modifications over the years. The Water Code established a system of private water rights, allowing individuals and companies to obtain permanent and tradable rights to use water from natural sources. This market-based approach aimed to promote efficient water allocation and encourage private investment in water infrastructure. However, critics have argued that this system has led to the overexploitation of water resources, particularly in water-scarce regions, and has prioritized economic activities over environmental and social considerations (Bauer, 2015; Larrain, 2012).

In recent years, there have been efforts to reform Chile’s water legislation to address these concerns. The government has proposed modifications to the Water Code (Law 21435, Water Reform Code) to strengthen environmental regulations, establish water reserves for ecosystem conservation, and improve public participation in water management decisions. However, these reform efforts have faced opposition from various stakeholders. Chile faces the complex challenge of balancing economic interests, environmental sustainability, and social equity in water governance.

The system of private water rights has led to inequitable water distribution, with large agribusinesses often having more access to water than small-scale farmers (Budds, 2004, 2008). Furthermore, the issue of water governance in Chile is complicated by the effects of climate change. Decreased rainfall and increased evaporation due to rising temperatures are exacerbating water scarcity in many parts of the country (Garreaud et al., 2017). This underscores the urgency of reforming Chile’s water legislation to ensure sustainable and equitable water management in the face of these challenges.

Studies show that the area in Chile most planted with avocado is located within a global biodiversity hotspot, hosting $7 0 \%$ of endemic bees in sclerophyllous forests (Gould, 2015; Lavín et al., 2024). Avocados are pollinated by wild bees and other flying insects, and depend on suitable natural habitats for these pollinators (Dymond et al., 2021; Lavín et al., 2024). Indeed, wild floral visitors are more important than honeybees in avocado pollination (Lavín et al., 2024). The replacement of native vegetation for intensively managed orchards via agricultural expansion threatens avocado’s native pollinators, and as a result, agricultural production itself.

These impacts demonstrate that beyond land and resources, actors, trade policies, and water governance form part of this complex social–ecological system (e.g. Ostrom, 2009). Here, we argue that avocado production in Chile is an exemplary case of telecoupling. Telecoupled systems are distant regions interconnected through socio-economic and environmental processes such as agricultural production and its trade (Liu et al., 2013; Sun et al., 2017). The environmental impacts of water stress and biodiversity loss, driven by international trade, highlight the need to consider how global demand affects local biodiversity (Kastner et al., 2014; Lenzen et al., 2012; Ortiz et al., 2021), and how local governance and environmental management affect this system (Barbieri et al., 2022; Liu et al., 2013). Coupled social–ecological systems also indirectly influence other spillover social–ecological systems (Carrasco et al., 2017), causing a cascade of impacts from the spatial decoupling of production and consumption.

There has been research on avocado production in Chile, especially in the context of its water use (Anticoli, 2022; Madariaga et al., 2021; Sommaruga & Eldridge, 2021); however, there are few approaches with the telecoupling framework. There is a need to emphasize the connection between social and ecological drivers and impacts in order to design interventions to reduce local impacts and increase its sustainability. Here, to understand the telecoupled system, we characterize its different components based on our expertise and a review of key studies, then highlight research needs for this important commodity in Chile.

# 2. Methods

Data on avocado production and export were analyzed to explore trends and identify critical research needs. The telecoupling framework allowed for an understanding of how global demand and social and ecological factors interact.

![](images/17b99568c7046a7e3f92f927fd91378160a2abf7fc835a0b14fb21673304949f.jpg)  
Figure 1. Map of regions in Central Chile with high-volume avocado production and the spatial distribution of orchards (2021). Production and cropland data from ODEPA (2024).

# 2.1. Avocado production in Chile

Cultivated areas for avocado were analyzed between 1997 and 2023 using official statistics from the Chilean Office of Agricultural Studies and Policies (ODEPA). Spatial data from ODEPA (2024) was also used to identify the most important growing regions to spatially refine the analysis (Figure 1), using QGIS 3.34.3.

Focusing only on avocado producing regions, the Valparaiso region accounts for $6 0 { - } 7 0 \%$ of the total avocado cultivation area in the country. Within Valparaiso, districts (comuna) were filtered based on size, selecting those with more than 500 hectares and then greater than 1,000 hectares to identify the top-producing districts. Fourteen of the 32 districts in the Valparaiso region had cultivated areas of more than 500 hectares, and 10 had an area of at least 1,000 hectares. These top producing districts – Cabildo, Hijuelas, La Cruz, La Ligua, Llaillay, Nogales, Panquehue, Petorca, Quillota, and Santo Domingo – were selected for further analysis.

The study also utilized data from the Food and Agriculture Organization Statistical Database to analyze changes in production and consumption between 2010 and 2021 (FAO, 2024). Avocado production quantity (tons), import quantity (tons), export quantity (tons), and food supply quantity (kilograms/capita/year) were analyzed.

# 2.2. Chile avocado export

Export data from the Chilean Customs Services (Aduanas, 2024) from 2009 to 2024 were filtered using the tariff code 080440, which relates to “Fresh and Dried Avocados.” Although this category includes several varieties, most exports are of the Hass variety $( 9 9 . 8 \% )$ . Data were organized by region of export and destination, then by region and year. The registered total item weight was used to estimate export volume. This differs from the total

![](images/4cbe6f3fbf515941316902ae5cecf32b60a6061313d77f763345c30d4b86343c.jpg)  
Figure 2. Avocado production, in tons: raw product, quantity for export, quantity imported, and food supply quantity (g/capita/day).

package weight, which may include packaging. Several data inconsistencies including undefined destinations were removed from the dataset.

Linear regression models were constructed to determine if there were any significant trends for production across the time period. Statistical significance was observed with a $\boldsymbol { p }$ -value $< 0 . 0 5$ . Statistical software R v4.4.2 was used for the analysis and visualization.

# 3. Results

# 3.1. Production, consumption, and land use

Avocado production data showed significant upward trends in both domestic production and import volumes in recent years. While production quantities exhibited a significant positive trend based on a linear regression model $( p < 0 . 0 5 )$ , export quantities did not show significant trends over the same period. Notably, import volumes displayed a strong positive trend $\left( { p < 0 . 0 0 0 1 } \right) .$ ), suggesting a growing domestic demand for avocados. In 2021, Chile produced over 169,000 tons of avocados, with approximately 98,000 tons exported to international markets. The country’s import volume also reached nearly 72,000 tons in the same year, indicating a substantial portion of domestic consumption being met through imports.

The results also showed the per capita consumption of avocado in Chile averaged to about 16 g/day (Figure 2). Avocado is one of the most commonly consumed fats in Chile (Díaz-Torrente & Quintiliano-Scarpelli, 2020), reflecting local food culture that consumes avocado as a spread on sandwiches and hotdogs (the ‘completo’). In 1992, the average avocado consumption was about $3 \mathrm { k g }$ per person in Chile (Barros & Sanchez, 1992). In 2024, it was about 8 kg per person annually (24horas.cl, 2020).

Most of imported avocados in Chile came from Peru; in 2019, this totaled 17,300 tons or $9 0 . 5 \%$ of imported avocados (Comisión de La Promoción del Peru para la Exportación y el Turismo [PROMPERU], 2020). The Chilean Avocado Committee reports that Chilean Hass avocados are valued higher by consumers than Peruvian varieties for their creaminess. However, their relative affordability compared to Chilean produce may explain this increase in imports and per capita/day consumption (Portal Fruticola, 2023).

Regional production data from 2009 to 2023 showed that Valparaiso, Metropolitana, O’Higgins, and Coquimbo are the top avocado producing regions. While production in Valparaiso remained stable between 2009 and 2023 (15 years), the O’Higgins region increased its production $( p \ < 0 . 0 5 )$ , while production in the Metropolitan region declined $( p < 0 . 0 5 )$ (Figures 3 and S2). Chilean avocado exports have sustained volumes exceeding 200,000 tons over the past decade, with notable peaks between 2016 and 2020.

In the Valparaiso region, more land is increasingly converted to avocado orchards in its top-producing districts $( p < 0 . 0 1 )$ (Figure 4). Most of these new cultivated areas replaced native ecosystems. However, following a complaint from environmental NGOs and the scientific community, the Comptroller General of Chile and Supreme Court declared the replacement of native vegetation by crops illegal in 2018, arguing that it goes against the Forestry Law, which mandates the protection of native forests (Canal Cero, 2020).

# 3.2. International trade flows: Chilean avocado trading partners

Analysis of trade flows between 2016 and 2024 showed that Chile traded primarily with the USA and Europe, and the production

![](images/1f58a75bce7e76f8dfbb1762096b8c9d71837e3f9201f4fc19d19728541db5fb.jpg)  
Figure 3. Regional export of avocado per region in Chile, 2009-2023. Valparaiso is the largest producer and exporter of avocado.

![](images/40db0277254be7f00cd8b7ad15d934f5e40c52abf23bb938e9f024d3fc955c6d.jpg)  
Figure 4. Cropland cultivated with avocado in the Valparaiso region is increasing annually across its districts (1997-2023).

volume also increased over this period. Chile also exports avocados to the Middle East, Asia, and Australia (Figure 5). The regional export distribution mirrors the spatial distribution of areas dedicated to avocado production (Figure S1). The USA is the largest

single importer of Chilean avocados, underscoring its role in the global avocado market. The Netherlands also plays a role as an importer and a hub for redistributing avocados across Europe. It is a major trader in the European market for the avocado trade

![](images/041eea1fc922fe28e354744b6ed5c6b2ddca38479e1ee4c2f9c5b1eb02d6b1d4.jpg)  
Figure 5. Avocado export flows from Chile. Chile exports avocados primarily to the USA and Europe, with the Netherlands being a primary port.

between European producers and consumers (Aguirre-López et al., 2024). These different global and regional interactions are part of the receiving, sending, and spillover systems (Figure 6).

# 4. Discussion

# 4.1. Impacts of changes in the production and export of avocados in Chile

The results of the analysis showed the increases in avocado production and the expansion of trade in the last decade. Second, cropland for avocado production has increased. Lastly, regions south of Valparaiso have increased avocado production. While the production of avocado for export has affected this increase, increased consumption and reduction can also be attributed to Chilean avocado producers’ advertising campaigns to increase domestic consumption at the beginning of the 21st century (Wallace, 2021). In Figure 2, a dip between 2015 and 2019 in per capita consumption can be observed, but the reasons are difficult to discern; a longer-term dataset would be helpful to better understand fluctuations across long-term trends and relationship with factors such as prices.

Climate change will have varying effects on avocado production. On one hand, climate change is anticipated to increase temperatures and water scarcity in the already water-stressed Central Chile (Salazar et al., 2024). But climate change may also contribute to increasing production as the suitability for growing avocados south of Valparaiso increases (Ramírez-Gil et al., 2019). Indeed, avocado cultivation in Chile is projected to increase because of increased yield and also farmers’ decisions related to crop profitability (Melo & Foster, 2021). At present, the Valparaiso and the Metropolitana regions in Central Chile are the principal exporting regions, and have also experienced the most significant water scarcity and socio-territorial conflicts in recent decades (Delamaza et al., 2017).

In the future, how will shifting climate patterns affect social– ecological dynamics and production? We argue that critical research is needed in Chile to examine these interactions, especially because of the significance of their outcomes for local communities. For example, in Mexico, avocado expansion has been shown to contribute to land dispossession, poverty, food insecurity, violence, and health challenges in Indigenous and local communities (Khan et al., 2021; De la Vega-rivera & Merino-Pérez, 2021).

![](images/5ff664345e0fdded19f0668fe908e6cdbc202867ccc66cde674c66c95fa36f2f.jpg)  
Figure 6. The telecoupled avocado production of Chile. Blue arrows indicate positive feedback: increased international demand has resulted in more trade agreements that cause greater domestic production of avocado for export. Red arrows indicate negative impacts: increases in the demand for irritation negatively affect water supply. The US and Europe are the primary importing countries of Hass avocados (receiving systems), while Peruvian production helps to cover domestic demand (spillover system).

# 4.2. Avocado production in Chile as a telecoupled system

Chile’s avocado industry is a prime example of a telecoupled system. At present, Chile’s high-volume and high-quality production of Hass avocados primarily for the USA and Europe means that it competes with Mexico as a producer. However, this also indicates that the social and environmental impacts in the country have also increased: the demand for avocados has led to significant changes in Chile, affecting land use, water resources, and local communities (Duran-Llacer et al., 2020; Madariaga et al., 2021).

The growing global demand for avocados has also driven expansion in the region. In the last 10 years, Peru has increased planting areas and export volume of Hass avocado, and thus competes with Chile in the international market (Schwartz et al., 2018). Under the telecoupling framework, Peru acts as a spillover system for the Chilean trade of avocados, ‘catching’ the domestic market of Chile with cheaper avocados while also participating in trade with developed countries. This is a dynamic system affected by factors such as the dollar exchange rate, which, along with increased export-oriented production, have caused the prices of avocado in the Chilean domestic market to steadily increase in recent years (Guevara et al., 2021). Future changes are also anticipated: more countries around the world are beginning to produce avocado for trade, e.g. in smallholder farms in Tanzania, where it is viewed as having positive impacts on livelihoods and biodiversity (Boniphace et al., 2023).

However, the reality is that the avocado boom is not profitable for all. In Mexico, 300,000 jobs have been created by the avocado industry, albeit mostly as seasonal work. The sector’s economic profits are concentrated with agribusinesses rather than its workers, and the impacts of the avocado boom in Michoacán, Mexico’s center of avocado production, have made the region’s Indigenous and rural communities precarious agricultural workers in their

own lands (De la Vega-rivera & Merino-Pérez, 2021). In Colombia, the avocado boom meant that farmers who could not produce export-quality avocados were squeezed out from the domestic market due to increased competition and little government support (Serrano & Brooks, 2019). As Mexico, Chile and now Peru are the most experienced Latin American producers in the market, the trade dynamics between these countries should be investigated further to contribute to developing safeguards for local producers.

# 4.3. What has propelled these changes in consumer demand and international trade?

There has been a notable increase in avocado production on a global scale, driven by the demand for ’superfoods’ (Magrach & Sanz, 2020). In Mexico, the Free Trade Agreement with the USA, established in 1994, has further amplified this demand, transforming what was predominantly local production in the 1960s into a globalized complex production chain (Denvir et al., 2022; Ramírez-Mejía et al., 2022). The economic liberalization policies implemented since the 1980s have similarly reoriented local food production toward globalization (Gwynne, 1999) creating a complex network of supermarkets, landowner elites, and local farmers. Despite limited research on the global avocado trade’s impacts in Chile, substantial evidence points to the significant influence of global companies on local production, bolstered by exportoriented agribusiness policies (Bengoa, 2013; Madariaga et al., 2021).

# 4.4. Identifying research priorities

In order to address these interlinked challenges, we view the following three research priorities as essential for charting the sustainability of the sector.

# 4.4.1. Sustainable water management and climate change adaptation

It is essential to investigate methods for optimizing water use in avocado orchards, to minimize acute water stress in productive regions, as the crop requires irrigation (Opazo et al., 2024). In the central zones of Chile, problems of water scarcity are already acute due to poor water management for agricultural use and overexploitation (Beyá-Marshall et al., 2022).

Because of Chile’s unique water privatization laws (see Box 1), there are significant hurdles to water security. Evidence shows that the La Ligua and Petorca basins cannot support the high demand of agriculture in semiarid conditions, the impacts of drought, and overextraction of groundwater (Duran-Llacer et al., 2020). There is also evidence that all the aquifers in central Chile were overexploited before the mega-drought (Jódar et al., 2024). With avocado production poised to increase, understanding the impacts of avocado crops on the water cycle from a local watershed approach is recommended.

# 4.4.2. Understanding the long-term biodiversity impacts of avocado production and its trade

In arid and semiarid ecosystems in Chile, there are significant gaps in information for several key environmental indicators. For example, carbon emissions are imprecise since there is no exact estimate of intact forests, even though they are relevant for the conservation of biodiversity (Marquet et al., 2019). It is thus a challenge to quantify the environmental benefits and losses of transitions in changes in land use and land cover.

This research priority also involves addressing conflicting ecological evidence of the impacts of avocados on biodiversity. Evidence for the need to protect native ecosystems can be bolstered by long-term initiatives to monitor native species populations, especially for pollinators. Monitoring efforts should incorporate technologies like remote sensing and participatory strategies and include the mapping and assessment of key ecosystem services, such as pollination and water regulation.

Here, effective territorial planning is needed to tackle the challenges posed by the increasing global demand for avocados, the rapid expansion of this crop and climate change. This may help reduce negative impacts on biodiversity and ecosystem services, enhance the long-term sustainability of avocado cultivation, and support the well-being of local communities (Lavín et al., 2024).

# 4.4.3. Social dynamics, profits, and policies

Research is needed to analyze the effects of avocado production on social dynamics in avocado-growing regions, with a lens on water injustice and the rights of local communities and Indigenous Peoples. Access to drinking water for communities (Fragkou et al., 2022), farmers’ irrigation security (Budds, 2008), and local poverty are issues that are connected to the agroindustry, and need to be explored further. Lesser-documented impacts, such as the role of seasonal migrant workers in Chile, need more attention to understand the significant, yet largely underexplored, effects of increased local populations and their social dynamics and their interactions with rurality, gender, and identity (Valdés et al., 2017). For instance, in La Ligua, the main reason for young people’s migration out of the district was their perception of land degradation (Rodríguez-Díaz et al., 2022).

# 4.8. Limitations of the study

The analysis relied on secondary data and existing studies, which restricted the scope to publicly available information. Much of the production data of industrial agricultural producers have limited public access. We hope that by highlighting key areas for future research, comprehensive assessments can be performed to understand the past, current and future impacts of avocados within social–ecological systems.

# 5. Conclusions

Avocados are an important commodity whose popularity has increased in recent decades. Avocado production in Chile, in combination with neoliberal water policies and climate-induced water stress, has resulted in significant pressures on water resources, biodiversity, and local communities. Our analysis showed that there are strong links between the increasing international demand and trade of avocado and negative impacts in Chile. As a telecoupled system, avocado production in Chile is linked to global markets and other competitors like Mexico and Peru, with significant impacts for local people and ecosystems. There are still several gaps in knowledge and moving research into practice to address unsustainable practices and better prepare for climate change. This also involves addressing inequities and injustices toward local social– ecological communities that bear the brunt of the expansion and intensification of avocado production in Chile.

Supplementary material. The supplementary material for this article can be found at https://doi.org/10.1017/sus.2025.10011.

Acknowledgements. The background image in Figure 6 is a royalty-free image on a CC0 license from Pixabay. The authors thank the editor, editorial team and anonymous reviewers for their feedback and support.

Author contributions. AMDO, SBG and MJ jointly conceived the work, supported by AHM, JLCD and ULO’s contributions. AMDO led the writing, SBG and MJ worked on the export and production data, AHM and ULO worked on the spatial data.

Funding statement. Several authors have support from the Chilean Agencia Nacional de Investigación y Desarrollo (ANID). ANID/PIA/BASAL/FB210006 (AMDO; JLCD); ANID/REGIONAL/R23F0003 (JLCD); ANID PROYECTO ANILLOS Pluriversos Climáticos ATE230072 (AMDO); ANID PROYECTO ANILLOS TECNOLÓGICOS SHELL-NBS ACT240004 (ULO).

Competing interests. The authors report no conflict of interest.

