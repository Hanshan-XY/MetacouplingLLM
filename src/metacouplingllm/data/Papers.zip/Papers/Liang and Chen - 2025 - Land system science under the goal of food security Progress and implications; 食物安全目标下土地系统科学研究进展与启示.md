# Land system science under the goal of food security Progress and implications; 食物安全目标下土地系统科学研究进展与启示

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:53:32.821419+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Liang and Chen - 2025 - Land system science under the goal of food security Progress and implications; 食物安全目标下土地系统科学研究进展与启示.pdf
- Year: unknown
- DOI: 10.31497/zrzyxb.20250702
- OA status: gold
- License: cc-by-nc-nd
- Category: Journal Articles\Review\Telecoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This review examines how land system science contributes to achieving food security, with a primary focus on China but drawing on global literature. The paper treats land as a coupled human-environment system whose use is shaped by non-linear changes, feedbacks, and multiple, often competing, societal demands. Food is framed as a key medium linking social and ecological processes, and food security is decomposed into four dimensions: availability, access, utilization, and stability.

Within this structure, the authors synthesize five major research lines. First, work on land use strategies and land use transitions explores how to balance agricultural production and biodiversity through concepts such as land sharing and land sparing, and how cropland transitions involve both visible shifts in area and configuration and less visible changes in quality, efficiency, and management. Second, studies on long-distance land-use linkages analyze how global food trade and urbanization create telecoupled impacts, including land use displacement, uneven development, and debates around land grabbing and local food systems.

Third, research on land demand modeling links biophysical and socioeconomic drivers to project land needs for food under different climate, demographic, economic, dietary, and food loss scenarios. Modeling is used both to understand complex system behavior (including water-energy-food linkages and planetary boundaries) and to inform policy. Fourth, analyses of land management systems focus on property rights reforms, land use regulations, and governance changes that condition stable food supplies, with attention to Chinese instruments such as cultivated land protection and the evolving roles of central and local governments.

The review explicitly engages with telecoupling and broader metacoupling thinking by emphasizing flows of food, virtual resources, capital, and information across regions and scales, and by calling for flow-based, value-chain-oriented perspectives. It concludes that future land system science for food security must deepen systems integration, improve theory, and better connect natural and social sciences to address complex, multiscale couplings.

## Structured Metacoupling Extraction

### Coupling Classification
- Covers intra systems, regional pericoupling, and strong telecoupling via food trade and flows.

### Intracoupling
#### Systems
- Domestic land system and national food system within China
- Human environment land system integrating social economic ecological components
#### Flows
- Food production within regions and cities
- Nutrients, energy, and information inside national food chains
#### Agents
- Farm households and agricultural producers
- National and local governments managing land and food policies
#### Causes
- Rising domestic food demand and dietary transition
- Urbanization reshaping rural urban land relations
#### Effects
- Cropland use transformation and intensification
- Changes in biodiversity, ecosystem services, and land system resilience

### Pericoupling
#### Systems
- Urban food consumption areas and surrounding rural production areas
- Adjacent regions connected by food logistics and foodshed relations
#### Flows
- Short distance food transport between neighboring regions
- Regional trade of agricultural products and inputs
#### Agents
- Regional governments coordinating land and food policies
- Food processors, distributors, and local retailers
#### Causes
- Spatial mismatch between regional food supply and demand
- Infrastructure expansion enabling inter regional food flows
#### Effects
- Land use displacement between cropland and construction land
- Coupled rural transformation and urban development

### Telecoupling
#### Systems
- Global food exporting regions such as Brazil and Costa Rica
- Food importing countries including the United States and China
- Remote ecosystems affected by global land grabbing
#### Flows
- International trade in soybeans, livestock products, and other food
- Virtual land, virtual water, and ecosystem services embedded in food
- Capital flows and remittances linked to land acquisitions
#### Agents
- Multinational agribusiness and foreign investors
- National governments negotiating land and trade agreements
- International organizations developing scenarios and pathways
#### Causes
- Globalization of food systems and comparative advantage
- High profitability of export crops driving agricultural expansion
- Climate change and global dietary shifts influencing demand
#### Effects
- Deforestation and biodiversity loss in distant producer regions
- Nutritional inequities and food insecurity in exporting countries
- Political social conflicts over land rights and dispossession

### Cross-Coupling Interactions
- Global food trade displaces land use abroad while reshaping domestic cropland protection.
- Urban dietary changes create telecoupled demand that feeds back on local land transitions.
- Policy on national food security interacts with international land grabbing outcomes.

### Research Gaps or Limitations
- Need finer integration of social institutions culture into land sharing sparing frameworks.
- Foodshed and local food models lack agreement on boundaries, distance goals, and cultural factors.
- Telecoupling models limited by coarse economic data and simplified trade representations.

### Search Keywords
- land system science food security telecoupling
- land use transition land sharing sparing
- foodshed WEF nexus land demand modelling

### Extraction Confidence
high
