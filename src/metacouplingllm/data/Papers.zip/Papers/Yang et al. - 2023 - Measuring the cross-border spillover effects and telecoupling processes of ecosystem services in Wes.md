# Measuring the cross-border spillover effects and telecoupling processes of ecosystem services in Wes

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:14:18.226190+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Yang et al. - 2023 - Measuring the cross-border spillover effects and telecoupling processes of ecosystem services in Wes.pdf
- Year: unknown
- DOI: 10.1016/j.envres.2023.117291
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This article examines how ecosystem services in western China generate cross-border spillovers and long-distance linkages, using a telecoupling framework. The geographic focus is the ecologically fragile belts and barriers in western China, including the Qinghai-Tibet Plateau, Tianshan and Qilian Mountains, and the Yunnan-Guangxi region, and their connections to eastern China and neighboring Asian countries.

The authors quantify nine ecosystem services, such as water conservation, soil retention, carbon sequestration, flood mitigation, food production, and pollination. They combine land use and biophysical data, InVEST ecosystem service models (including scenario simulations), monetary valuation following national methods, and a gravity- and field-strength-based spillover model. The Telecoupling Toolbox is used conceptually to organize systems, flows, agents, causes, and effects.

Results show strong service provision from mountain and plateau areas, with large increases in overall ecosystem service capacity and value between 1980 and 2020, alongside regional land cover change. Around two-thirds of service value from western China spills over to eastern provinces, especially as water regulation and disaster mitigation for major river basins, air quality improvement, sandstorm prevention, and food supply, benefiting hundreds of millions of people. Roughly 40 percent of services spill to Southeast, South, and Central Asia through shared rivers and trade in agricultural products, supporting water security, reduced sedimentation and flood risk, and regional food security.

Scenario analysis for water and food services illustrates contrasting futures under ecological restoration versus continued degradation, with large differences in beneficiary populations and risk profiles. The paper also documents positive feedbacks, such as national ecological compensation and resettlement programs that enhance both ecosystem functions and rural livelihoods in source regions.

This work is explicitly about telecoupling and metacoupling. It operationalizes telecoupling concepts to measure distant ecosystem service flows and feedbacks, and argues for strengthened interprovincial and international ecological compensation mechanisms, particularly in the context of Chinas Belt and Road initiative and broader sustainability goals.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling among western China, eastern China, and Asian countries via ecosystem service spillovers

### Intracoupling
#### Systems
- Ecologically fragile regions within western China
- Provincial social economic systems in western China
- Local ecosystems such as forests grasslands wetlands farmlands
#### Flows
- Local ecosystem services among western provinces
- Information on ecological policies and restoration projects
- Internal ecological compensation and subsidies
#### Agents
- Local governments and nature reserve administrations
- Western China farmers herders and rural households
- Chinese central government environmental agencies
#### Causes
- National ecological civilization and western development strategies
- Land use change including restoration and degradation
- Population growth climate change and resource pressure
#### Effects
- Improved regional ecosystem service capacity and values
- Local livelihood changes through compensation and new industries
- Persistent ecological vulnerability and grassland degradation

### Pericoupling
#### Systems
- Western China ecological barriers and neighboring eastern provinces
- Upstream plateau catchments and downstream Chinese river basins
- Sending mountain regions and adjacent downwind basins
#### Flows
- River water regulating services to Yellow Yangtze Pearl basins
- Soil retention and reduced sediment to downstream areas
- Sandstorm prevention and air purification to nearby provinces
#### Agents
- Upstream watershed managers and reserve authorities
- Downstream provincial governments and urban residents
- Agricultural producers and water users in China
#### Causes
- Hydrological and atmospheric connectivity across provincial borders
- Implementation of reforestation and grassland restoration programs
- Economic growth and water food demand in eastern provinces
#### Effects
- Hundreds of millions benefiting from reduced floods and disasters
- Enhanced downstream industrial and agricultural production
- Need for upstream downstream ecological compensation mechanisms

### Telecoupling
#### Systems
- Western China as ecosystem service sending system
- Southeast South Central Asian countries as receiving systems
- Global food trade partners including Asia Europe North America
#### Flows
- Cross border river water and water quality services
- Exported agricultural products and virtual water
- Policy finance and ecological compensation feedbacks
#### Agents
- Chinese central and provincial governments
- Foreign governments and regional initiatives like Belt and Road
- Farmers traders and telecoupling researchers
#### Causes
- Globalization and transboundary river basins
- International trade integration and food security needs
- Climate change affecting glaciers and runoff regimes
#### Effects
- Dozens of millions abroad gaining water food and risk reduction
- Potential crises from upstream ecological degradation scenarios
- Opportunities for international ecological compensation cooperation

### Cross-Coupling Interactions
- Upstream ecological restoration alters domestic spillovers and international water supplies simultaneously
- Food trade expansion links local land use with distant consumer security
- Positive feedback via compensation improves ecosystems and livelihoods reinforcing future flows

### Research Gaps or Limitations
- Limited field monitoring data in key ecological function areas
- Ecosystem service assessment sensitive to classification and parameter choices
- Need higher resolution global data and multi scale observation networks

### Search Keywords
- telecoupling ecosystem services western China spillover
- cross border water and food flows Asia
- ecological compensation upstream downstream Belt and Road

### Extraction Confidence
high
