LETTER • OPEN ACCESS

Globalization’s unexpected impact on soybean production in South America: linkages between preferences for non-genetically modified crops, eco-certifications, and land use

To cite this article: Rachael D Garrett et al 2013 Environ. Res. Lett. 8 044055

View the article online for updates and enhancements.

# You may also like

Study on comparison of the advantages ofdifferent soybean producing areas in China from a temporal and spatial perspective

Yu Wang, Shiwei Xu, Ganqiong Li et al.

Strategies to increase soybean productionby increasing the distribution of new superior varieties

R D Yofa, R P Perdana, R Aldillah et al.

Adoption Determinants of Biofertilizer Technology for Soybean in Rainfed Area

Dian Adi Anggraeni Elisabeth, Siti

Mutmaidah and Arief Harsono

![](images/9d0808dc4b70cf15e63d60641054679d9960f072d3a0008d8a412b4b5b5cada9.jpg)

250th ECS Meeting

Otober 25-29, 2026

Calgary, Canada

BMO Center

![](images/b4ccdd004ec0106d9243ce9bc2aaad240bce513ad5a3d4de7251e34a475670ba.jpg)

The Electrochemical Society

Advancing solid state&electrochemical science & technology

Stepintothe

Spotlight

SUBMIT YOUR

ABSTRACT

Submission deadline:

March 27,2026

# Globalization’s unexpected impact on soybean production in South America: linkages between preferences for non-genetically modified crops, eco-certifications, and land use

Rachael D Garrett1,2, Ximena Rueda3 and Eric F Lambin4

1 Sustainability Science Program, Harvard University, 79 JFK Street, Box 81, Cambridge, MA 02138, USA   
2 Center on Food Security and Environment, Stanford University, 616 Serra St Encina Hall East, 4th Floor, Stanford, CA 94305, USA   
3 School of Management, Universidad de los Andes, Calle 21 # 1-20 Edificio, Bogota, Colombia ´   
4 Woods Institute for the Environment and Environmental Earth System Science, Stanford University, 473 Via Ortega, Stanford, CA 94305, USA

E-mail: rachael garrett@hks.harvard.edu

Received 13 September 2013, revised 11 November 2013

Accepted for publication 29 November 2013

Published 20 December 2013

Online at stacks.iop.org/ERL/8/044055

# Abstract

The land use impacts of globalization and of increasing global food and fuel demand depend on the trade relationships that emerge between consuming and producing countries. In the case of soybean production, increasing trade between South American farmers and consumers in Asia and Europe has facilitated soybean expansion in the Amazon, Chaco, and Cerrado biomes. While these telecouplings have been well documented, there is little understanding of how quality preferences influence trade patterns and supply chains, incentivizing or discouraging particular land use practices. In this study we provide empirical evidence that Brazil’s continued production of non-genetically modified (GM) soybeans has increased its competitive advantage in European countries with preferences against GM foods. Brazil’s strong trade relationship with European consumers has facilitated an upgrading of the soybean supply chain. Upgraded soybean supply chains create new conservation opportunities by allowing farmers to differentiate their products based on environmental quality in order to access premiums in niche markets in Europe. These interactions between GM preferences, trade flows, and supply chain structure help to explain why Brazilian soybean farmers have adopted environmental certification programs on a larger scale than Argentinian, Bolivian, Paraguayan, and Uruguayan soybean producers.

Keywords: telecoupling, trade, multi-stakeholder initiatives, supply chains

S Online supplementary data available from stacks.iop.org/ERL/8/044055/mmedia

![](images/48031ec1053b195ef1bf146011dc21f97be1441dfa7f48f931574d66ef6d4b84.jpg)

Content from this work may be used under the terms of the Creative Commons Attribution 3.0 licence. Any further

distribution of this work must maintain attribution to the author(s) and the title of the work, journal citation and DOI.

# 1. Introduction

Population growth, expanding affluence, and changing dietary preferences are increasing global demand for food and fuel

![](images/e5d8dff4dc3068547fc58b740fe626e0f3b6dda8d69f6ec046a0195a562f6822.jpg)  
Figure 1. Soybean area and yields in 1986 and 2010 by country. The size of the pie reflects the size of the total soybean area in North and South America. Each slice reflects a countries percentage of the total soybean area in North and South America. Yields are country averages. Data source: FAO Production Statistics (faostat.org).

products [1, 2]. Concurrently, globalization is changing the environmental impact of these products by shifting production away from temperate countries towards tropical ones [3, 4]. The redistribution of production from temperate to tropical areas may increase the global land use efficiency of agricultural production by transferring some production to countries with higher than average yields [5, 6]. However, this is not always the case. The comparative advantage of tropical regions may stem from the availability of cheap land and labour, rather than high yields, resulting in the use of more cropland to produce the same amount of food, often in regions of high biodiversity and carbon value [7, 8]. On the other hand, increased global trade linkages create new opportunities for international consumers to influence environmental governance in agricultural export countries through market mechanisms [9, 10]. The concept of telecoupling [11] captures these duelling outcomes of globalization on land use and the environment, which are well illustrated by the case of soybean production in South America.

Global consumption of soybean products has increased by 200 million tons (MT) since 1970 [12]. When crushed, soybeans produce both oil and meal, ingredients that are then incorporated into cooking oils, biofuels, livestock feeds, and numerous processed foods. Soybean consumption has grown particularly quickly in China, where soybean meal fuels the burgeoning swine industry. To meet the growing global demand for soybean by-products, farmers in North and South America have greatly increased yields and planted area

(figure 1). The environmental impact of increased soybean area has been particularly high in South America, where croplands planted with soybeans expanded by more than 30 million hectares (Mha) between 1986 and 2010. This process resulted directly and indirectly in the conversion of native vegetation to agriculture in the Brazilian tropical savannah (Cerrado), Brazilian and Bolivian moist tropical forest (Amazon), and seasonally dry forests of Argentina, Paraguay, and Bolivia (Chaco and Chiquitano) [13–17].

Economic globalization, via reduced trade barriers and improved transportation and logistics, has undoubtedly accelerated this increase in soybean production and deforestation in South America by linking producers in remote agricultural regions to distant urban consumers [5, 18]. However, globalization also has the potential to help kerb future deforestation for soybean production in some countries by allowing international consumers to incentivize sustainable production practices through eco-certification programs. The broad purpose of this study is to understand linkages between consumer preferences for non-genetically modified crops and the adoption of eco-certification programs in producing countries. In particular we ask: (1) how do preferences for non-genetically modified (GM) soybeans affect global trade flows; and (2) how do trade relationships emerging from GM preferences influence the structure of regional soybean supply chains, and consequently, the extent to which producers can participate in eco-certification programs.

We focus on trade between the world’s 7 largest exporters and 11 largest importers of soybeans, accounting for $9 5 \%$

![](images/40e8e8c4977d445988fc7a2fc33f743c6ace127b4a6ba0d271a9b2ed6d4830ef.jpg)  
Figure 2. Total non-genetically modified soybean area by country in 1996 and 2010. Excludes Bolivia and Paraguay who produced negligible volumes in both years. The graph shows an $80 \%$ decrease in non-genetically modified soybean area in North and South America between 1996 and 2010. Data source: yearly reports published by the International Service for the Acquisition of Agri-biotech Applications (isaaa.org).

of world production and $80 \%$ of world consumption [19]. We begin the letter by reviewing recent trends in consumer preferences for non-GM foods and global production of non-GM soybeans. We then describe our framework for understanding interactions between consumer preferences, trade flows, and eco-certifications and methods for analysing and accounting for these interactions. Next we present and discuss our results, concluding that Brazil’s continued production of non-GM soybeans has led to strong trade linkages with European consumers. These trade linkages have facilitated the creation of upgraded supply chains that enhance Brazilian producers’ opportunities to be rewarded for more environmentally sustainable production through eco-certification programs.

# 2. Background and theory

# 2.1. Global availability of non-GM soybeans and consumer preferences for non-GM foods

Since RoundupReadyTM (glyphosate-resistant) soybeans were first introduced in 1996, global non-GM soybean area has declined dramatically (figure 2). RoundUp resistance is appealing to producers because it allows them to apply herbicides less frequently during the growing season and reduce their soil tillage [20]. The use of GM seeds has been legal since 1997 in the United States, Canada, and Argentina, but it remained illegal in Uruguay until 2000, in Paraguay until 2004, and in Bolivia and Brazil until 2005. As a result, GM seed varieties suitable for the climates and soils of Bolivia, Brazil, Paraguay, and Uruguay were not developed until the 2000s. Despite a prohibition against their use, GM soybeans were planted illegally in the southern states of Brazil as early as 1997, using varieties developed for Argentina [21, 22]. However, as GM varieties were generally not adopted in northern Brazil until 2005, GM seed usage was far less

Table 1. Per cent of total soybean production deriving from transgenic seeds in each Brazilian state as of 2006. Source: IBGE 2006 agricultural census, table 824. (Note: ‘—‘signifies missing data.)   

<table><tr><td>Region</td><td>State</td><td>% of total production</td></tr><tr><td rowspan="7">North</td><td>Rondônia</td><td>—</td></tr><tr><td>Acre</td><td>&lt;1</td></tr><tr><td>Amazonas</td><td>&lt;1</td></tr><tr><td>Roraima</td><td>—</td></tr><tr><td>Pará</td><td>&lt;1</td></tr><tr><td>Amapá</td><td>&lt;1</td></tr><tr><td>Tocantins</td><td>2</td></tr><tr><td rowspan="9">Northeast</td><td>Maranhão</td><td>1</td></tr><tr><td>Piauí</td><td>1</td></tr><tr><td>Ceará</td><td>&lt;1</td></tr><tr><td>Rio Grande do Norte</td><td>&lt;1</td></tr><tr><td>Paraíba</td><td>&lt;1</td></tr><tr><td>Pernambuco</td><td>—</td></tr><tr><td>Alagoas</td><td>&lt;1</td></tr><tr><td>Sergipe</td><td>&lt;1</td></tr><tr><td>Bahia</td><td>1</td></tr><tr><td rowspan="3">Centerwest</td><td>MatoGrosso</td><td>3</td></tr><tr><td>Goiás</td><td>8</td></tr><tr><td>MatoGrosso do Sul</td><td>9</td></tr><tr><td rowspan="4">Southeast</td><td>Minas Gerais</td><td>2</td></tr><tr><td>Espírito Santo</td><td>&lt;1</td></tr><tr><td>Rio de Janeiro</td><td>&lt;1</td></tr><tr><td>São Paulo</td><td>&lt;1</td></tr><tr><td rowspan="3">South</td><td>Paraná</td><td>6</td></tr><tr><td>Santa Catarina</td><td>6</td></tr><tr><td>Rio Grande do Sul</td><td>39</td></tr><tr><td>Brazil</td><td></td><td>9</td></tr></table>

common in these states as of the last agricultural census (table 1) [23]. Brazil is now the largest remaining producer of non-GM soybeans in the world, producing approximately 15 million tons each year. The next largest producers of non-GM soybeans were China (14 million tons), India (12 million tons), the United States (6 million tons), and Canada (1 million tons). India and China, in particular, produce a large volume of non-GM soybeans, but unlike Brazil, they do not export much of their production due to high domestic consumption [24, 25].

While the production of GM soybeans has increased substantially in the last decade, public opinion polls have consistently shown that more than $70 \%$ of Japanese and European consumers prefer to consume foods that do not contain genetically modified materials [26, 27]. As a result, foods derived directly from GM crops must be labelled in the EU and Japan (but meat and dairy products originating from animals fed GM corn and soybeans do not need to be labelled) [28, 29]. GM imports are not banned in the EU or Japan, but are subject to a strict approval process [30]. The total demand for certified non-GM soybeans in Europe and Japan is roughly 7.5–9 million tons, which accounts for close to $10 \%$ of all the soybeans purchased in world markets [31].

Although the demand for differentiated (non-GM) soybeans is relatively small, it can play a substantial role in global land use outcomes through two mechanisms. First, preferences for non-GM soybeans can influence trade patterns, as countries with larger supplies of non-GM

soybeans can deepen their specialization in serving this market segment. Secondly, to provide certified non-GM soybeans, exporters must use segregated supply chains to maintain the purity of the shipment, which influences the structure of the supply chain.

# 2.2. Effects of quality preferences on trade patterns

To understand how preferences for non-GM soybeans influence trade patterns we begin with a standard economic trade model that assumes that there is an integrated world market for each agricultural commodity [32]. The model assumes that each importer purchases soybean products from the lowest cost exporter, adjusting bi-lateral trade levels whenever the relative prices of different exporters change. This model also assumes that soybean imports from all current trade partners will increase as an importer’s domestic soybean consumption increases, so long as new consumption cannot be met (in a cost-effective way) by domestic production. Similarly, soybean exports to all current trade partners will decrease as an exporter’s domestic soybean consumption increases, so long as domestic soybean production does not increase to meet this new demand. The relative prices of soybeans originating in different countries are determined by production costs, domestic and international transportation costs, exchange rates, import tariffs and other trade barriers, and export taxes. For example, an exporter whose currency is decreasing in value relative to other exporters will have decreasing production and transportation costs in the importer’s currency, relative to those other exporters, even if input and transportation costs stay the same in the domestic currency. Some of these price factors may fluctuate greatly on a year-to-year basis (exchange rates, export taxes, and production costs), while others factors tend to change over longer time periods (import tariffs and transportation costs).

Importers also substitute between potential trade partners based on relative quality [32, 33]. Since the presence of GM material influences the perceived quality of soybeans in countries with consumer preferences against GM crops, soybeans from different exporters can be differentiated based on whether or not they were produced with GM seeds [34]. Importers then balance price with quality when making sourcing decisions. If the preference against GM foods is more important than price in a particular country, then buyers in that country will shift their demand away from exporters that produce only GM soybeans, even if the GM beans produced by those exporters are less expensive than the non-GM beans of other exporters. Conversely, a country whose citizens do not reject GM foods would be expected to increase its soybean imports from an exporter whose soybean prices decreased because they adopted GM production practices.

# 2.3. Effects of quality preferences on supply chains and land use

In addition to adjusting trade relationships based on product quality, importers can motivate trade partners to improve

product quality by offering price premiums for certain attributes. To tap into these niche markets, traders and producers need a mechanism for verifying that their product meets the desired attributes. Certification programs are an attractive mechanism from the consumer perspective because they theoretically provide uniform standards that can be applied to any producer and can be independently verified by third-party organizations. The use of certification mechanisms that span the entire supply chain is particularly attractive in food sectors where individual producers have low brand identity and the crop is heavily transformed before it reaches end consumers. Certification programs have been created for non-GM soybeans and for environmentally responsible production practices, which partially overlap.

The largest certifying program for non-GM soybeans is CERT-ID, which has been certifying non-GM production in Brazil since 1999 [35]. To comply with the criteria of CERT-ID and obtain a premium for non-GM soybeans, soybean traders must segregate non-GM from GM soybeans throughout the supply chain to prevent contamination. The average premium for non-GM soybeans has fluctuated between $\$ 16$ and 54 per ton over the past three years, depending on the country and world soybean price at the time [36, 37]. Given a world soybean price of $\$ 350 – 5600$ per ton during the same period, the premium for non-GM soybeans adds between 5 and $10 \%$ to the price paid to producers.

There are two major certification standards for environmentally responsible production: ProTerra and Roundtable on Responsible Soybeans (RTRS). The ProTerra certification was created through a multi-stakeholder process in 2006 within the CERT-ID system and is modelled on the Basel Criteria for social and environmental responsibility [24]. ProTerra certification requires soybeans to be non-GM and ensures that farms practice sustainable use of soil, pesticides, and water and do not convert native forests or other high conservation value areas $( H C V A s ) ^ { 5 }$ to cropland. More specifically, soybeans may not be grown on HCVA land that was cleared after 2004. This standard requires certified products to be segregated and traceable from farm to fork [38]. Compliance with the ProTerra standard is evaluated according to a uniform certification protocol, by a third-party (independent) certification body that is accredited according to ISO/IEC standards. The premium for ProTerra certified soybeans is roughly $\$ 4$ per ton, which is added to the standard premium for non-GM soybeans [35].

The RTRS standard was also created in 2006 through a multi-stakeholder process, but was modelled after the Roundtable on Responsible Palm Oil [39]. Like ProTerra, RTRS certification must be performed by an accredited third-party auditor and requires companies demonstrate

that soybeans are produced in compliance with existing environmental laws, do not convert HCVAs, and meet additional environmental management criteria regarding restoration, inputs, and pollution. However, the timeline for using previously cleared land is different; soybeans may not be grown on HCVA land that was cleared after 2009. Furthermore, in contrast to ProTerra, producers can grow GM, non-GM, or organic soybeans. Consumers can source these beans through a segregated supply chain, mass balance accounting, or a certificate-trading platform. The mass balance accounting system allows a company to produce (or trade) both non-responsible and responsible soybeans, so long as they keep track of how much of their total supply is certified and do not sell more RTRS soybeans than what they produced (or bought) [40]. The certificate-trading platform enables soybean buyers to purchase ‘responsible soy production credits’ directly from soybean growers, with one credit equalling one metric ton of responsibly produced soybeans [40]. The last two mechanisms do not require segregated supply chains and thus do not ensure that consumers actually receive responsibly produced soybeans. The average premium for RTRS certified soybeans is $\$ 1.5$ per ton [41].

# 3. Methods

# 3.1. Effects of quality preferences on trade patterns

To examine how quality preferences for non-GM soybeans influence bi-lateral soybean trade we specify a multivariate logistic model that utilizes panel data from 1986 to 2010 for the 7 largest soybean exporters in the world during this period—Argentina, Bolivia, Brazil, Paraguay, Uruguay, USA, and Canada—and the 11 largest importers—China, Japan, Thailand, Indonesia, Mexico, Egypt, Germany, Italy, Netherlands, Spain, and Belgium. The model is a standard partial equilibrium integrated world market model, with an Armington assumption, which states that seemingly identical exports from different countries are not perfectly substitutable. Instead, an importer’s rate of substitution between different exporters in response to price changes depends on the perceived quality of different exporters [32]. In previous studies the Armington assumption has been used mainly to capture the home bias of consumers. In this study we use the assumption to allow for preferences based on the presence of genetically modified materials.

We estimate annual imports as a function of quality $( Q )$ , prices $( P )$ , and consumption $( C )$ , with country and time fixed effects $( F )$ :

$$
\operatorname {I m p o r t s} _ {i, e, t} = Q _ {i, e, t} + P _ {i, e, t - 1} + C _ {i, e, t} + F \tag {1}
$$

Where the dependent variable $( \mathrm { I m p o r t s } _ { i , e , t } )$ is the proportion of country i’s unprocessed6 soybean imports from country $e$

6 In the SI we also examine a model that includes soybean meal in the dependent variable Import $_ { i , e , t }$ . The results of this model are listed in table S2 (available at stacks.iop.org/ERL/8/044055/mmedia). Soybean oil is not included in either model because there are too many missing years in the FAO data.

in time t. The dependent variable is the proportion of imports from each exporter, rather than total import volume, to eliminate the effect of market expansion on annual trade levels and focus instead on substitution between export partners.

$Q$ is the proportion of the soybean area in the exporting country that is planted with GM seeds in year $t \ - \ 1$ $\left( \mathrm { G M } _ { e , t - 1 } \right)$ . We include an interaction term with $\mathrm { G M } _ { e , t - 1 }$ for each importer to account for a structural difference in the way different importers respond to GM usage in the exporter. For example, we expect to find a negative and significant coefficient on the GM variable for countries that have a strong non-GM preference and a coefficient that is not statistically different from zero for importers who have no preference for non-GM. The vector $P$ includes the exchange rate between the exporting country’s currency and the importing country’s currency in time t − 1 (ExRate,i,t−1), i.e. the value of the exporter’s currency per unit of the importer’s currency, and export taxes in each exporting country in time $t - 1$ $( \mathrm { E x p o r t T a x } _ { e , t - 1 } )$ . The vector $C$ includes the volume of soybean consumption in the importing country (Consumptioni,t) and the exporting country (Consumptione,t) in time t. We include country and year fixed effects to account for any other price or quality variable that is place dependent or time dependent but which we are not able to include due to data limitations. In particular, country level differences in total production capacity, transportation costs, and soybean purity, protein content, or oil content should be captured by country and year fixed effects. We also include country by year trends in bi-lateral trade to account for path dependency in trade relationships. The final econometric model is as follows:

$$
\begin{array}{l} \operatorname {I m p o r t s} _ {i, e, t} = \alpha + \beta_ {1} \operatorname {E x R a t e} _ {i, e, t - 1} + \beta_ {2} \operatorname {E x p o r t T a x} _ {e, t - 1} \\ + \beta_ {3} \text {C o n s u m p t i o n} _ {i, t} + \beta_ {4} \text {C o n s u m p t i o n} _ {e, t} \\ + \beta_ {5} \left(\mathrm {G M} _ {e, t - 1} \times \text {I m p o r t e r}\right) + \beta_ {6} \text {E x p o r t e r} \times \text {Y e a r} \\ + \varepsilon_ {i, e, t}. \tag {2} \\ \end{array}
$$

Data sources are explained in table S1 (available at stacks.iop. org/ERL/8/044055/mmedia). One limitation of the trade data is that imports and exports are self-reported and countries may purposefully or mistakenly misrepresent trade levels in official data. Furthermore, import data may not account for re-exports.

# 3.2. Effects of quality preferences on supply chains and land use

To analyse how preferences for non-GM soybeans are influencing supply chains and land use in South America we first identify how much land area is currently affected by each certification program, by producer, state, and country. We then interpret these data based on existing literature about the soybean supply chain structure in each region. Certification area data are collected through public reports available on the ProTerra Foundation and RTRS websites (proterrafoundation.org, responsiblesoy.org) for each certified farm and through direct communication with representatives of CERT-ID, ProTerra, and RTRS.

Table 2. Logistic regression results for model analysing soybean import behaviour between 1986 and 2010. The dependent variable is the per cent of unprocessed soybeans an importer receives from each of the 7 major exporters included in this study each year. Model 1 includes country year trends, while Model 2 does not. (Note: Standard errors are listed in parenthesis.)   

<table><tr><td>Variable</td><td>Model 1 Estimate (SE)</td><td>Model 2 Estimate (SE)</td></tr><tr><td>log(EXCHANGE_RATE)</td><td>0.18 (0.02)a</td><td>0.22 (0.02)a</td></tr><tr><td>EXPORT_TAX</td><td>-0.01 (0.01)b</td><td>-0.02 (0.01)a</td></tr><tr><td>log(CONSUMPTION.ImportER)</td><td>-0.14 (0.19)</td><td>-0.15 (0.19)</td></tr><tr><td>log(CONSUMPTION-exportER)</td><td>-0.01 (0.03)</td><td>-0.01 (0.03)</td></tr><tr><td>GM_PER CENT</td><td>0.75 (0.38)b</td><td>0.50 (0.39)</td></tr><tr><td>GM_PER CENT:INDONESIA</td><td>1.51 (0.43)a</td><td>1.53 (0.45)a</td></tr><tr><td>GM_PER CENT:THAILAND</td><td>1.00 (0.40)c</td><td>0.98 (0.42)c</td></tr><tr><td>GM_PER CENT:EGYPT</td><td>0.88 (0.48)b</td><td>0.86 (0.49)b</td></tr><tr><td>GM_PER CENT:MEXICO</td><td>0.71 (0.42)b</td><td>0.74 (0.43)b</td></tr><tr><td>GM_PER CENT:JAPAN</td><td>-0.29 (0.47)</td><td>-0.29 (0.48)</td></tr><tr><td>GM_PER CENT:NETHERLANDS</td><td>-2.20 (0.45)a</td><td>-2.20 (0.47)a</td></tr><tr><td>GM_PER CENT:GERMANY</td><td>-0.50 (0.46)</td><td>-0.57 (0.48)</td></tr><tr><td>GM_PER CENT:SPAIN</td><td>-2.27 (0.47)a</td><td>-2.44 (0.48)a</td></tr><tr><td>GM_PER CENT:ITALY</td><td>-3.20 (0.51)a</td><td>-3.44 (0.52)a</td></tr><tr><td>GM_PER CENT:BELGIUM</td><td>-2.81 (0.52)a</td><td>-2.98 (0.54)a</td></tr><tr><td>Country fixed effect</td><td>Yes</td><td>Yes</td></tr><tr><td>Year fixed effect</td><td>Yes</td><td>Yes</td></tr><tr><td>Country year trend</td><td>Yes</td><td>No</td></tr><tr><td>Psuedo R2</td><td>0.70</td><td>0.69</td></tr><tr><td>No. of observations</td><td>1848</td><td>1848</td></tr></table>

a Significant at $1 \%$ level. b Significant at $10 \%$ level. c Significant at $5 \%$ level.

# 4. Results

# 4.1. Effects of quality preferences on trade patterns

Our statistical model confirms the influence of preferences for non-GM soybeans on bi-lateral soybean trade patterns. We found a significant negative relationship $( p < 0 . 0 5 )$ ) between GM soybean area in each exporting country and import behaviour by four of the countries with strong non-GM preferences7 (Netherlands $- 2 . 2 [ - 3 . 1 , - 1 . 3 ] , ^ { 8 }$ Spain $- 2 . 3 \ [ - 3 . 2 , - 1 . 4 ]$ , Italy $- 3 . 2 \ [ - 4 . 2 , - 2 . 2 ]$ , Belgium $- 2 . 8 \ [ - 3 . 8 , - 1 . 8 ] )$ , after controlling for changes in the exchange rates, export taxes, and unobserved variables in each of these countries (table 2). We also found a positive relationship $( p < 0 . 1 0 )$ between GM soybean area in the exporting countries and import behaviour by countries that have not expressed a non-GM preference (China 0.75 [0.0, 1.5], Indonesia 1.5 [0.7, 2.3], Thailand 1.0 [0.2, 1.8], Egypt 0.9 [−0.1, 1.8], Mexico 0.7 [−0.1, 1.5]). GM soybean area in the exporting countries had no statistically significant relationship with import behaviour by Japan or Germany. Exchange rates (i.e. the rate of exchange between the exporter’s and importer’s currencies) had a significant positive relationship $( p < 0 . 0 1 )$ with imports to all countries (0.18 [0.13, 0.23]), while export taxes had a significant negative relationship $( p < 0 . 1 0 )$ with imports to all countries $( - 0 . 0 1$ $[ - 0 . 0 3 , 0 . 0 0 ]$ ).

Table 3. Certified soybean area by program and country. Data for ProTerra and RTRS compiled from proterrafoundation.org and responsiblesoy.org. Data for non-GM obtained through personal communication with CERT-ID.   

<table><tr><td>Country</td><td>Cert-ID non-GM (HA)</td><td>ProTerra (HA)</td><td>RTRS (HA)</td></tr><tr><td>Argentina</td><td>—</td><td>—</td><td>123 687</td></tr><tr><td>Bolivia</td><td>—</td><td>—</td><td>—</td></tr><tr><td>Brazil</td><td>4295 000</td><td>1100 000</td><td>230 768</td></tr><tr><td>Paraguay</td><td>—</td><td>—</td><td>2765</td></tr><tr><td>Uruguay</td><td>—</td><td>—</td><td>372</td></tr><tr><td>Canada</td><td>20 000</td><td>—</td><td>—</td></tr><tr><td>China</td><td>8000</td><td>—</td><td>—</td></tr><tr><td>India</td><td>1000 000</td><td>—</td><td>29 801</td></tr><tr><td>United States</td><td>54 000</td><td>—</td><td>—</td></tr></table>

# 4.2. Effects of quality preferences on supply chains and land use

Brazil produced the majority of the globally certified non-GM, ProTerra and RTRS soybeans in 2012: 4.3 million tons of certified non-GM soybeans, while India, China, the US, and Canada together provided less than 2 million tons (table 3). Approximately $79 \%$ of Brazil’s certified non-GM soybeans were also certified under ProTerra standards for environmental and social responsibility. We found that $59 \%$ of the 1 million tons of RTRS certified soybeans were produced in Brazil, $32 \%$ in Argentina, and $1 \%$ in Paraguay and Uruguay, taken together. The remaining $8 \%$ of RTRS certified production came from India. None of the farms certified under the RTRS standard were certified as non-GM.

All of the ProTerra certified farms are located in Mato Grosso, Brazil, except for two sourcing regions in Goias who

![](images/9f89b535e3d13364f5f5e4d8943eb543eeeef430521426a776dc7f216f900167.jpg)  
Figure 3. Total certified area of RTRS soy by state and country in 2012. BR = Brazil, AR = Argentina, PR = Paraguay. Uruguay, which has less than 400 ha of certified area is not included. Data source: reports published by RTRS (responsiblesoy.org).

supply to the processor and trader Caramuru. A majority of the RTRS certified farms are also located in Mato Grosso, but there are certified farms scattered throughout Argentina and the Centerwest and Northeast regions of Brazil (figure 3). Grupo Maggi owns and sources the largest area of RTRS soy, followed by Vanguarda (table S3 available at stacks. iop.org/ERL/8/044055/mmedia). Paraguay and Uruguay each have one RTRS certified farm. The ports certified under the ProTerra standard are located in Santos (Sao Paulo) and˜ Paranagua (Paran´ a), in the South of Brazil, and Itacoatiara´ (Amazonas) and Porto Velho (Rondonia), both in the Northˆ of Brazil in the Amazon. Both of the Amazonian ports are controlled by Grupo Maggi under the company Hermasa Navegac¸ao da Amaz˜ onia SA.ˆ

# 5. Discussion

# 5.1. Effects of quality preferences on trade patterns

The statistically significant negative relationship between an exporter’s production of GM soybeans and imports by the Netherlands, Italy, Spain, and Belgium provides empirical evidence that quality differentiation based on the presence of GM materials plays an important role in trade between South America and Europe; especially since these four countries serve as a major gateway for imports into the rest of Europe, providing soybeans to numerous other countries with non-GM preferences. This result differs substantially from previous trade models that assume that market expansion and relative prices are the main determinants of import behaviour [32, 42]. While it is possible that the negative relationship between GM usage and imports in the Netherlands, Italy, Spain, and Belgium reflects some underlying factor that we did not measure, we have minimized this possibility by incorporating country year trends. For example, Brazil’s steady increase in

import share in many countries over the last two decades is captured by a country year trend, but the degree to which Brazil has increased its import share faster in countries with a strong non-GM preference versus other countries is explained statistically by Brazil’s level of non-GM soybean production rather than by changes in prices. More specifically, we find that the Netherlands, Italy, Spain, and Belgium increased imports from Brazil and simultaneously decreased imports from the United States, even as Brazil’s currency increased in value in the late 2000s, which should have made Brazilian soybean producers less competitive than their North American counterparts on a pure cost basis (figure 4). In particular, note that the increase of the value of the Brazilian currency relative to the US Dollar and Argentine Peso should have made Brazil less competitive in European markets, if not for their advantage in non-GM production (figure 5).

In contrast, China and other non-European importers increased their import share from the United States as the Brazilian Real appreciated against the US Dollar. The lack of a significant negative relationship between Japan’s import behaviour and GM usage in North and South America is potentially explained by the fact that Japan also imports non-GM soybeans from China. The non-significant finding for Germany is likely related to the large amount of soybeans that Germany imports from the Netherlands ${ \bf > } 1$ million tons). Thus, Germany’s import response to changing non-GM availability may be partially captured in the coefficient for the Netherlands.

This redistribution of soybean trade partners by the Netherlands, Italy, Spain, and Belgium amounts to a substantial volume of trade, even if these importers are small compared to China. These four EU countries increased their imports of Brazilian soybeans by 3 million tons and decreased their imports of United States soybeans by nearly 5 million tons between 1986 and 2010. Total exports to the Netherlands, Italy, Spain, and Belgium now account for $12 \%$ of raw soybean exports from Brazil, contributing to the need for Brazil to expand soybean area to supply to both European and Chinese markets. Thus, even though preferences for non-GM soybeans only affect a small proportion of the global market, they do have substantial land use consequences in terms of total area devoted to soybean production in Brazil.

# 5.2. Effects of quality preferences on supply chains and land use

Our study finds that farmers’ ability to adopt eco-certifications is related to the local supply chain structure. First, Brazil is the world’s largest producer of both non-GM and ‘environmentally responsible’ soybeans; furthermore, ProTerra and RTRS certified farms are clustered in Mato Grosso (Brazil). Finally, Brazilian producers have adopted ProTerra certification, the stricter of the two standards (ProTerra prohibits GM seeds and requires traceability from farm to fork), over a larger area than RTRS certification, while Argentinian (and to a lesser extent Paraguay and Uruguayan) producers have only adopted the less demanding RTRS certification.

![](images/cb517193001b53fe7dbf722096bb80a38cf4b261cab1c534cede1e3b303b0ab1.jpg)

![](images/c0185f30ed2a756e2cb8894aa19d584c2ced9c7914ea47be7ed7a2b0cec7ed86.jpg)

![](images/dab26d70f281c05e46474992ad5443da0841166dc33403b26fd13b14737ec477.jpg)

![](images/4daae7f0575fd6d888a47b27a6b84e6786b4a5501fcefca668e8f69862a2d9c0.jpg)

![](images/0acaf288dc4a2788175156660ecdb9beb71e588987352efd5eac7d2af905ec39.jpg)

![](images/88b36a7aa595f068aeedca22eb1d001f7c8e057b0b14be3aa5fe13173a4db2d8.jpg)

![](images/b0e6b6daf7083f8e3838dd21d6995e103744177823b0b113d44cf33297148bb0.jpg)

![](images/393f7a30c96e21d7c76f991e6b6747686b200800cacc246df7a22bab7a1da41d.jpg)

![](images/76ed95e1befbcd53ed331cf8b9110f9006819d84fd60399f6073744c25dea70c.jpg)

![](images/98e0f6f0f819b49a4b5429a44b7aefe4821824ec2822b0ca5939401a3f67c099.jpg)  
Figure 4. Annual soybean trade by each major importer included in study from 1990 to 2010 (excluding Egypt for space). Data sources listed in table S1 (available at stacks.iop.org/ERL/8/044055/mmedia).

![](images/49313e5a2a8082266caa6da62eab53a6433d4d92382cdc98578c3928fc61fa32.jpg)

![](images/3d7cbcb7fd18393dfc9cc03b58264918fa4a4ecc1b62831f4efbc1938693a568.jpg)  
Figure 5. Non-GM soy area (as a proportion of total soy planted area) and exchange rates (measured as the value of the domestic currency per US dollar) in each exporter included in study from 1990 to 2010. Data sources listed in table S1 (available at stacks.iop.org/ERL/8/ 044055/mmedia).

Mato Grosso is the largest and earliest producing region of certified non-GM soybeans in South America; traders in this region have long possessed the infrastructure needed to segregate, trace, and test the physical quality of local soybeans. In contrast, Argentina, Paraguay, and Uruguay no longer produce non-GM soybeans and lack segregation infrastructure. Since the ProTerra certification provides a higher premium than the RTRS certification, we would expect most farmers to opt for this certification, provided that they meet the criteria. However, ProTerra’s prohibition of GM seeds and requirement of traceability is infeasible for producers who lack access to segregated supply chains and where contamination is a common risk. The RTRS standard allows both GM and non-GM production systems and soybeans can be sourced through mass balance accounting or certificate trading in the supply chain, so this certification is more feasible for producers outside of Brazil.

The advanced soybean supply chains of central Brazil are well illustrated by the case of the Brazilian soybean agribusiness giant Grupo Andre Maggi, which produces non-GM soybeans certified by the ProTerra Foundation and was the first company to have farms certified by the RTRS in Mato Grosso, Brazil [43]. Over the last decade Grupo Maggi, which controls $18 \%$ of the market in Mato Grosso [44], has continued to produce non-GM soybeans on its farms, has certified multiple nodes in its supply chain with the CERT-ID certification, and has maintained private ports specialized in non-GM soybeans. These ports, located in Itacoatiara, Amazonas and Porto Velho, Rondonia, allow for a directˆ shipping route to Europe through the Amazon river [45, 46]. This vertically integrated export pathway not only prevents GM contamination, but also reduces the costs of segregation and aids traceability.

# 6. Conclusion

While most studies focus on the negative environmental impacts of globalization, this study provides empirical evidence that the impacts of globalization depend on the trade relationships that emerge from increased integration. On the one hand, globalization has contributed to an overall expansion of soybean production in sensitive biomes by

linking producers in those regions to distant consumers. On the other hand, globalization has led to the development of a bifurcated soybean market, reflecting different quality preferences. In the differentiated market, consumers demand products with lower perceived risks (non-GM) and improved environmental sustainability (‘forest friendly’). In the mass market consumers have no preference about how soybeans are produced. Producers who have access to supply chains that can verify and segregate ‘high quality’ soybeans through the supply chain can take advantage of the differentiated market, while producers who do not have access to these supply chains must sell into the mass market.

Brazil’s historical provision of non-GM soybeans to Europe has promoted the development of segregated supply chains in that country, which has in turn facilitated access to the differentiated market for more environmentally sustainable soybeans. Access to the differentiated market has increased opportunities for European consumers to influence Brazilian land use through premiums for specific management practices. This has introduced new incentives to reduce deforestation associated with soybean production and new opportunities to increase transparency about production practices and compliance with existing laws on Brazilian soybean properties. In contrast, other South American countries that did not develop segregated supply chains for non-GM soybeans now face smaller opportunities to access niche markets in Europe. This supply chain limitation is only now being remedied through the development of unique marketing mechanisms that do not rely on segregation (mass balance and credit trading). However, these mechanisms will not be suitable solutions for consumers who want both environmentally responsible and non-GM soybeans.

Thus, without denying the perverse environmental impacts of soybean expansion in fragile ecosystems, the Brazilian case illustrates how a country can take advantage of international differences in consumer preferences to build a competitive advantage around ‘sustainable’ production. The ability of Brazilian soybean producers to develop this green image was particularly important for protecting trade relationships with Europe, given previous campaigns by Greenpeace in 2006 to promote the image of Brazilian soybeans as ‘eating up the Amazon’. Ironically, other South

American soybean producers who are not located in the Amazon biome have been less able to tap into niche markets for responsible soybeans.

It remains unclear whether the demand for (and production of) environmentally responsible and non-GM soybeans will remain coupled in the future and whether or not either of these preferences will become mainstream. In the Spring of 2013, an exceptionally high soybean harvest in Brazil overwhelmed the storage and segregation capacity of supply chains, which led to a decision by some soybean traders to stop separating GM and non-GM beans. As a result, the European poultry feed industry had to accept GM soybeans on short notice and the non-GM stock was redirected towards foods that are consumed directly by consumers. The feed industry aimed to alleviate retailers’ concerns about consumers’ reaction to GM feeds by replacing non-GM soybeans with soybeans that meet broader environmental sustainability criteria. This ‘sustainable soy for non-GM swap’ in the feed sector has increased Europe’s demand for soybeans associated with zero net deforestation and produced on legally occupied land, among other criteria. It is not clear whether consumers of poultry products will continue to accept this substitution in the future, but this development does align with recent commitments by a number of large soybean importers in Europe, including the Dutch Sustainable Soy Initiative, the Belgian Platform on Responsible Feed, Waitrose, and Nutreco to purchase $100 \%$ of their soybean imports from RTRS certified farms by 2015, accounting for a total demand for responsible soy of 5 million tons (about half of the size of the current non-GM soybean market) [47]. This demand increase could stimulate a broader adoption of RTRS certification criteria in South America beyond currently low levels, but its impact will be limited given the small size of the European market relative to China. However, in the last year Chinese consumers also expressed interest in importing certified non-GM soybeans, mainly to address domestic concerns about food safety and traceability (49). If these concerns become a reality, then the production of traceable, non-GM soybeans in South America could increase exponentially given China’s huge market share.

While we have discussed participation in certification programs and theoretical opportunities for improved sustainability, the question remains as to what effect these emerging eco-certification programs are actually having on the environment and sustainable development. On the one hand, the availability of financial incentives (premiums) for protecting remaining forests, restoring riparian areas, reducing on-farm greenhouse gas emissions, and controlling erosion should stimulate adoption of these practices. RTRS and ProTerra’s requirements for compliance with existing environmental regulations and independent verification of production practices through third-party auditors should improve local environmental governance of the Brazilian soybean sector. Furthermore, ProTerra’s requirement of traceability from farm–fork can promote transparency about the location and impacts of soybean production. On the other hand, it is possible that eco-certifications are rewarding producers who historically deforested land (thus had few

incentives for new deforestation) and comparatively disadvantaging smallholders who do not have the knowledge or capital to become certified. Exclusion from certification mechanisms may also create incentives for non-certified producers to reduce their conservation initiatives if they are not being rewarded for their efforts. Additional research is needed to better understand these processes, since participation in eco-certification programs is poised to increase in the future with growing commitments from major European consumers.

