# Local and non-local drivers of consumption-based water use in China during 2007-2015 Perspective of

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:42:25.363929+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Du et al. - 2022 - Local and non-local drivers of consumption-based water use in China during 2007-2015 Perspective of.pdf
- Year: unknown
- DOI: 10.1016/j.jenvman.2022.114940
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines how both local and non-local socioeconomic processes have shaped Chinas consumption-based water use between 2007 and 2015, explicitly framed within the metacoupling concept. The analysis covers 30-31 provinces grouped into eight hydro-economic regions, focusing on interactions within provinces (intracoupling) and between provinces via trade and migration (peri- and telecoupling).

The authors use environmentally extended multiregional input-output (MRIO) tables for 2007, 2010, 2012, and 2015 to calculate consumption-based water use (including consumption- and capital-investment-driven components). They then apply Logarithmic Mean Divisia Index (LMDI) decomposition to attribute changes in national and provincial water use to five drivers: water use intensity, economic structure, per capita GDP (affluence), total population, and population share (a proxy for internal migration as a non-local factor).

Total national consumption-based water use rose from about 387 to 431 billion m3 by 2012 and then fell to about 413 billion m3 in 2015, implying a possible peak around 2012. Over the same period, GDP grew much faster than water use, indicating decoupling. Water use intensity decreased almost everywhere and was the dominant force reducing water use, especially in agriculture and thermoelectric power. Shifts in economic structure toward less water-intensive tertiary activities further lowered water demand. In contrast, rising affluence and, to a lesser degree, population growth increased water use.

The metacoupling perspective highlights that migration and interprovincial virtual water flows reallocate water burdens. Coastal and more developed provinces, which attract migrants and import large volumes of virtual water, experienced rising consumption-based water use while outsourcing much of the resource pressure to inland and northwestern regions. The paper is clearly about metacoupling/telecoupling: it explicitly separates local and non-local drivers and traces how human and economic linkages across space redistribute water use and associated environmental risks, providing guidance for regionally differentiated and flow-aware water governance in China.

## Structured Metacoupling Extraction

### Coupling Classification
- Analyzes intracoupling of provincial water use and metacoupled peri and tele linkages within China

### Intracoupling
#### Systems
- Provincial human water demand systems across 30 31 Chinese provinces
- Sectoral systems including agriculture thermoelectric power industry services
- National Chinese water economy as integrated intracoupled system
#### Flows
- Blue water withdrawn and consumed for local production activities
- Consumption based water use driven by local households government
- Capital investment driven water use for infrastructure and industry
#### Agents
- Provincial governments and water resource managers
- Households firms and industrial sectors using water
- National policymakers implementing water conservation policies
#### Causes
- Economic growth and rising provincial affluence PVA
- Changes in sectoral economic structure ES among primary secondary tertiary
- Local efficiency improvements reducing water use intensity IWU
#### Effects
- Peak and subsequent decline of national water use around 2012
- Decoupling of economic growth from water use intensity
- Spatial inequality in water use per GDP and per capita

### Pericoupling
#### Systems
- Adjacent Chinese provinces linked via interprovincial trade
- Hydro economic regions such as Northwest North Coast East Coast
- Neighboring sending and receiving provinces for virtual water
#### Flows
- Interprovincial virtual water transfers embodied in traded goods
- Regional trade of agricultural products and industrial commodities
- Spillover of water use pressures via nearby supply chains
#### Agents
- Regional planners coordinating cross provincial water policies
- Firms sourcing inputs from neighboring provinces
- Migrants moving between adjacent inland and coastal provinces
#### Causes
- Regional production specialization especially agricultural Northwest
- Urbanization and industrial relocation among nearby provinces
- Differences in water scarcity and economic opportunities across neighbors
#### Effects
- Coastal provinces dependence on water imports from nearby inland regions
- Water stress export from water scarce senders to better endowed neighbors
- Regional disparities in water intensity and virtual water balances

### Telecoupling
#### Systems
- Distant inland agricultural provinces as virtual water senders
- Coastal megacity provinces as virtual water receivers
- Spillover provinces indirectly affected by upstream trade and migration
#### Flows
- Long distance virtual water exports from Northwest to eastern coasts
- Capital and goods flows driving remote water consumption
- Population migration redistributing water demand across distant regions
#### Agents
- National economic policies reshaping inland coastal linkages
- Migrants concentrating in coastal urban centers
- Enterprises organizing long distance supply chains
#### Causes
- Migration driven change in provincial population shares SPOP
- Economic transition from investment led to consumption led growth
- National programs promoting western development and trade integration
#### Effects
- Increasing coastal water use while many inland provinces decline
- Outsourcing of water intensive production to remote water scarce regions
- Strong decoupling in some western senders despite heavy export duties

### Cross-Coupling Interactions
- Local efficiency gains counterbalance non local affluence and migration driven water increases
- Virtual water trade links intracoupled provincial use with peri and tele sending receiving systems
- Migration effects interact with outsourcing patterns to shift environmental burdens spatially

### Research Gaps or Limitations
- Migration factor captures net population share change but not origin destination pairs
- Only blue water considered excluding green and grey components
- Climate variability and precipitation impacts on water use not explicitly modeled

### Search Keywords
- China metacoupling virtual water MRIO migration water use drivers
- consumption based water use intra provincial interprovincial trade
- water intensity decoupling agriculture thermoelectric power Northwest coastal

### Extraction Confidence
high
