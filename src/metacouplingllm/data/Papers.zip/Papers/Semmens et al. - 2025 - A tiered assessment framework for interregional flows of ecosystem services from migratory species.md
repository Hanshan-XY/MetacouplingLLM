# A tiered assessment framework for interregional flows of ecosystem services from migratory species

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:05:34.485142+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Semmens et al. - 2025 - A tiered assessment framework for interregional flows of ecosystem services from migratory species.pdf
- Year: unknown
- DOI: 10.1111/cobi.70008
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Conceptual\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This conceptual paper proposes a structured way to assess how migratory species generate ecosystem services that move across regions, and how those benefits depend on habitat networks spanning large distances. The study is global in scope and focuses on migratory animals as carriers of ecosystem service flows linking multiple jurisdictions, making it directly relevant to telecoupling and metacoupling.

The authors synthesize ecological and socioeconomic literature on ecosystem services from migratory species and on interregional flows. They highlight that robust, range-wide data are rare, and that existing case studies have used diverse, often incompatible methods. To organize this emerging field, they develop a four-tier framework that classifies assessments by the quality and completeness of ecological and socioeconomic information, and by what kinds of conclusions each tier can support.

Tier 1 (telecoupled ES assessment) includes descriptive or partial studies that identify services and geographic linkages but cannot quantify net flows. Tier 2 (qualitative flows) would infer the likely direction and relative strength of flows using coarse information on habitat importance and range-wide service benefits, although the authors find no published examples yet. Tier 3 (quantitative static flows) uses medium or better ecological models of migratory networks combined with consistent, range-wide service metrics (monetary or biophysical) to calculate net flows between regions at a point in time; existing spatial subsidy analyses for a few North American migrants fall here. Tier 4 (quantitative dynamic flows) is an aspirational level that would link detailed, dynamic ecological models with economic models to forecast how flows and values change under different environmental or policy scenarios.

The paper also reviews candidate ecological models (from simple distance-based networks to individual-based models) and valuation approaches (from biophysical indicators to nonmarket valuation and macroeconomic models), emphasizing data demands and equity concerns. Overall, this is a framework and agenda-setting contribution rather than an empirical telecoupling case; it aims to guide future, more consistent assessments of interregional ecosystem service flows from migratory species.

## Structured Metacoupling Extraction

### Coupling Classification
- Conceptual framework for interregional ecosystem service flows from migratory species, focused on telecoupling.
- Emphasizes cross-border social-ecological linkages created by animal migration and associated services.
- Distinguishes qualitative versus quantitative, static versus dynamic telecoupled ES flow assessments.

### Intracoupling
#### Systems
- Within-region social-ecological systems supporting migratory species habitats and local beneficiaries
- Breeding, wintering, and stopover habitats managed inside single jurisdictions
#### Flows
- Local ecosystem services from migratory species to residents within same region
- Intra-regional cultural, recreational, and subsistence uses of migratory species
#### Agents
- Local communities and indigenous groups using migratory species
- Regional wildlife managers and conservation agencies
#### Causes
- Habitat condition and management decisions within a region
- Local conservation investments and harvest regulations
#### Effects
- Changes in local provisioning, cultural, and regulating services from migratory species
- Distribution of conservation costs and benefits within a jurisdiction

### Pericoupling
#### Systems
- Neighboring countries sharing migratory flyways or marine corridors
- Adjacent administrative regions linked by seasonal animal movements
#### Flows
- Cross-border movement of migratory individuals between contiguous habitats
- Regional trade and tourism based on shared migratory populations
#### Agents
- Subnational and national governments in bordering regions
- Cross-jurisdictional conservation initiatives and NGOs
#### Causes
- Spatial mismatch between key habitats and areas receiving benefits
- Differences in habitat protection and enforcement among neighbors
#### Effects
- Need for coordinated habitat management across borders
- Potential inequities in regional conservation burdens versus received services

### Telecoupling
#### Systems
- Distant breeding, wintering, and stopover regions for wide-ranging migrants
- Global seafood, tourism, and agriculture systems relying on migratory species
- Sending, receiving, and spillover systems in migratory ES telecoupling
#### Flows
- Interregional ES flows carried by migrating animals, such as pollination and pest control
- Economic benefits from wildlife viewing, hunting, fishing far from supporting habitats
- Spatial subsidies: net ES flows between regions based on habitat contributions and received benefits
#### Agents
- Migratory species as ES carriers between ecosystems and people
- International tourists, consumers, and supply chain actors
- Multinational conservation organizations and intergovernmental bodies
#### Causes
- Seasonal migration creating dependence on multiple habitats along routes
- Global demand for food, recreation, and cultural experiences tied to migrants
- Policy calls to account for nature-dependent flows between nations
#### Effects
- International dependencies and potential conflicts over conservation responsibilities
- Opportunities for cross-border cost sharing and payments for ecosystem services
- Implications for environmental justice and equitable benefit distribution

### Cross-Coupling Interactions
- Tiered framework links local, regional, and distant ES assessments across intra, peri, and telecoupled scales.
- Spatial subsidies reveal how one region subsidizes ES benefits enjoyed in other distant regions.
- Multi-species analyses aggregate telecoupled flows to guide cross-scale conservation prioritization.

### Research Gaps or Limitations
- Range-wide ecological and socioeconomic data for most migratory species are scarce and inconsistent.
- Few quantitative flow studies exist; no fully dynamic ecological-economic telecoupling models implemented.
- Socioeconomic valuation often monetary only, underrepresenting cultural and relational values across cultures.

### Search Keywords
- migratory species spatial subsidies telecoupling ecosystem service flows tiered framework
- quantitative static dynamic ES flows proportional dependence migratory network models
- telecoupled conservation finance cross-jurisdictional governance migratory ecosystem services

### Extraction Confidence
high
