# An integrated tele-coupling analysis for requisition-compensation balance and its influence on carbo

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:46:09.223986+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Gao et al. - 2022 - An integrated tele-coupling analysis for requisition-compensation balance and its influence on carbo.pdf
- Year: unknown
- DOI: 10.1016/j.landusepol.2022.106057
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper examines how Chinas requisition-compensation balance of farmland (RCBF) policy affects vegetation carbon storage, using a telecoupling and input-output approach. The study covers all 31 provincial units in mainland China and focuses on the 2010-2015 period, when rapid urban expansion converted large areas of farmland to construction land.

Within Chinas land management system, the RCBF policy requires that any farmland taken for construction be offset by creating new farmland elsewhere. The authors integrate high-resolution land-use maps (30 m), a multi-regional input-output (MRIO) table for 2012, and spatially explicit vegetation carbon density data. They calculate carbon storage changes from land conversions and use the MRIO framework to evaluate how economic trade links drive indirect, interprovincial flows of embodied requisitioned farmland.

Nationally, the total area of farmland increased, so the quantity target of RCBF was met. However, vegetation carbon storage decreased by about 3.7 Tg. Major carbon losses came not only from farmland being built over, but also from converting forest to farmland as a compensation measure, particularly in southwestern and central provinces with high-biomass forests such as Sichuan, Yunnan, and Henan. Grassland-to-farmland conversions in drier northwest regions tended to increase or maintain carbon stocks.

The telecoupling analysis reveals strong spatial inequities. Developed coastal and southeastern provinces (e.g., Jiangsu, Zhejiang, Guangdong, Shanghai) act as net importers of embodied requisitioned farmland, relying heavily on land resources in other regions to support their construction and consumption. Less-developed, land-rich provinces (e.g., Hebei, Henan, Inner Mongolia, Xinjiang) function primarily as net exporters, bearing disproportionate carbon and ecological costs while exporting land embodied in trade.

This work is explicitly about telecoupling/metacoupling: it treats provinces as sending, receiving, and spillover systems linked by economic flows, land conversions, and carbon outcomes. The authors argue that RCBF should move beyond simple area balance toward strategies that respect regional carbon capacities, avoid forest-to-farmland compensation, and include cross-regional financial and environmental compensation mechanisms.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling among Chinese provinces via farmland exchange and trade driven land use change

### Intracoupling
#### Systems
- Within province land system of farmland, forest, grassland, construction land
- Provincial carbon storage and terrestrial ecosystem dynamics
#### Flows
- Local land conversion between farmland, forest, grassland, construction land
- Within province carbon stock changes from construction land expansion
#### Agents
- Provincial governments managing land conversion and RCBF targets
- Local farmers and land users reacting to land requisition
#### Causes
- Urbanization and industrialization increasing provincial construction land demand
- Economic growth prioritizing construction over high quality farmland
#### Effects
- Provincial loss of vegetation carbon storage
- Local decline in farmland quality and productivity

### Pericoupling
#### Systems
- Neighboring provinces with adjacent land and trade linkages
- Regional clusters such as eastern coastal belt or northwest interior
#### Flows
- Near distance exchange of requisitioned farmland between adjacent provinces
- Short range trade in agricultural and industrial products
#### Agents
- Neighboring provincial governments negotiating land balance
- Regional planning authorities coordinating RCBF implementation
#### Causes
- Spatial heterogeneity in hydrothermal conditions and land productivity
- Regional disparities in urban growth and construction pressure
#### Effects
- Shift from paddy fields in southeast to dryland in northwest
- Regional imbalance in carbon storage gains and losses

### Telecoupling
#### Systems
- National China RCBF system as coupled human natural system
- Sending provinces exporting compensatory farmland and carbon loss
- Receiving provinces importing embodied requisitioned farmland
#### Flows
- Embodied requisitioned farmland traded via multiregional input output links
- Indirect flows of construction land demand through domestic supply chains
- Telecoupled carbon storage changes associated with interprovincial land transfers
#### Agents
- Central government designing and enforcing RCBF policy
- Provincial governments as dual sending and receiving agents
- Economic sectors aggregated into MRIO agriculture land sector
#### Causes
- National land policy requiring quantitative balance of farmland
- Economic development driving conversion of farmland to construction land
- Interprovincial trade and urban demand relocating land use impacts
#### Effects
- Net national vegetation carbon loss despite farmland area balance
- More developed coastal provinces as net importers of requisitioned farmland
- Less developed inland provinces bearing higher environmental and carbon costs

### Cross-Coupling Interactions
- National telecoupling overlays with provincial intracoupling carbon dynamics
- Interprovincial trade reallocates carbon losses from coastal receivers to inland senders
- Compensation methods link local land change to distant carbon and food security impacts

### Research Gaps or Limitations
- Soil organic carbon changes and dynamic vegetation growth not quantified
- Non CO2 agricultural and biomass burning emissions omitted from analysis
- Single year MRIO used to represent multi year economic interactions

### Search Keywords
- telecoupling RCBF China carbon storage MRIO
- requisition compensation farmland embodied land trade
- provincial inequality vegetation carbon construction land expansion

### Extraction Confidence
high
