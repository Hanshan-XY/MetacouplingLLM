# The short-range and remote analysis of virtual water trade in China

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:21:37.005002+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Zheng and Sun_The short-range and remote analysis of virtual water trade in China.pdf
- Year: 2023
- DOI: 10.1016/j.jclepro.2023.137831
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines how virtual water moves through Chinas economy over different distances, using the metacoupling / telecoupling lens of local versus distant linkages. The spatial scope is 30 Chinese provinces plus international trading partners, over the years 2002, 2007, 2012, and 2017. The authors combine three main tools: a multi-regional input-output model (separating local, interprovincial, and international trade), calculation of water footprints including green and blue water, and a geographical detector to identify socio-economic, natural, and technological drivers. Distances between regions are represented by centroid-to-centroid distances and used to distinguish short-range (within province and neighboring provinces) from remote (non-adjacent domestic and international) interactions.

They find that both water footprints and virtual water trade are strongly distance dependent and concentrated among nearby provinces, mostly within 500 km. Domestic remote exchanges typically occur over 1100-2000 km but represent a shrinking share of national water flows. Short-range (especially intra-provincial) inflow and outflow footprints increasingly dominate both consumption- and production-side water use, while domestic long-distance exchanges lose importance. In contrast, international imports of virtual water grow rapidly and partially substitute for domestic remote inflows, whereas export-related water footprints decline.

Spatially, eastern and central provinces with relatively better water endowments and stronger economies tend to be net recipients of virtual water at both short and long distances, while many western provinces remain net senders. This pattern reinforces rather than corrects Chinas internal water imbalance, creating a clustered, small-cycle regime of water circulation below roughly 800 km rather than a broad national redistribution.

Geographical detector results show that socio-economic factors (population, trade dependence, foreign direct investment, water use per GDP) and, to a lesser extent, technology, explain virtual water patterns more than natural endowment alone. Interactions among factors exhibit nonlinear enhancement, aligning well with the telecoupling/metacoupling framework, which emphasizes multiple interacting drivers and cross-scale flows. The paper is explicitly framed as a local-telecoupled analysis of water flows and thus clearly contributes to metacoupling and telecoupling research.

## Structured Metacoupling Extraction

### Coupling Classification
- Explicit analysis of local, peri-, and remote (tele) virtual water trade in China

### Intracoupling
#### Systems
- Provincial water resource and economic systems within single Chinese provinces
- Local industrial subsystems linked by intra-provincial input output relations
#### Flows
- Local virtual water trade among sectors inside each province
- Local inflow and outflow water footprint for production and consumption
#### Agents
- Provincial industries producing and consuming water intensive goods
- Provincial and municipal water resource managers
#### Causes
- Provincial economic growth and internal demand expansion
- Water scarcity combined with uneven local water endowments
#### Effects
- Rising dominance of local water footprint in total use and trade
- Formation of provincial level small water resource circulation

### Pericoupling
#### Systems
- Neighboring Chinese provinces sharing borders
- Regional clusters in eastern, central, and western China
#### Flows
- Peripheral virtual water trade between adjacent provinces under 800 km
- Short range inflow and outflow water footprints between neighbors
#### Agents
- Inter-provincial commodity traders and logistics firms
- Regional governments coordinating cross border water intensive trade
#### Causes
- Lower trade costs and distance frictions at short range
- Agglomerated economic activity in eastern and central corridors
#### Effects
- Small cycle water circulation between local and nearby regions
- Reinforcement of spatial imbalance between eastern and western provinces

### Telecoupling
#### Systems
- Water rich and water scarce Chinese provinces linked over long distance
- Chinese provinces and foreign countries in global trade network
- Sending western provinces, receiving eastern provinces, global spillover regions
#### Flows
- Domestic remote virtual water trade over 1100 2000 km
- International import and export of embodied water in goods
- Net inflow to eastern and central provinces, net outflow from western
#### Agents
- National trade and water policy makers
- Export oriented and import dependent industries
- Foreign investors and international trading partners
#### Causes
- Uneven spatial water endowments and economic development
- Global and national supply chains restructuring and deglobalization pressures
- Trade dependence, foreign direct investment, and transport infrastructure
#### Effects
- Persistent spatial imbalance and clustering of water inflows
- Increasing reliance on imported virtual water and related risks
- Reduced domestic large cycle potential to relieve water scarcity

### Cross-Coupling Interactions
- Short range prominence displaces domestic remote flows while imports expand
- Local and remote trade flows interact so some links intensify, others weaken
- Socio economic and technological drivers jointly reshape near and distant water trade

### Research Gaps or Limitations
- Multi regional input output data only available to 2017, excludes post pandemic changes
- Driving factor analysis uses limited indicator set, omits many possible determinants
- Agent roles and spillover system dynamics in virtual water network not explicitly modeled

### Search Keywords
- China virtual water trade local telecoupling
- short range remote water footprint provinces
- multi regional input output geographical detector

### Extraction Confidence
high
