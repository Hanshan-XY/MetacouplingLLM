# Mapping fine-resolution nested social-ecological system archetypes to reveal archetypical human-envi

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:14:03.653679+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Yang et al. - 2023 - Mapping fine-resolution nested social-ecological system archetypes to reveal archetypical human-envi.pdf
- Year: unknown
- DOI: 10.1016/j.landurbplan.2023.104863
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study develops a fine-scale method to classify and map social-ecological system (SES) archetypes in an urbanizing region and use them to interpret dominant human-environment relations.

The geographic focus is the Beijing-Tianjin-Hebei (BTH) urban agglomeration in northern China, a diverse landscape including major cities, plains, and mountain-plateau areas. The authors adapt an SES framework with three components: socioeconomic conditions, ecological conditions, and human-environment interactions. They operationalize 18 indicators using open-access geospatial data at 1 km resolution, including population, lights at night, infrastructure point-of-interest data, climate, terrain, vegetation productivity, land cover, air pollution, cropland and built-up extent, and selected ecosystem service proxies (grain production, carbon storage, habitat quality, cultural sites).

Methodologically, they combine a top-down, rule-based classification with a bottom-up hierarchical clustering. First, they use composite indices of human activity intensity and natural coverage to define five broad SES archetypes: urban, urban-rural transition, agricultural, ecological transition, and natural systems. Second, within each, they apply clustering to derive 11 finer sub-archetypes that distinguish, for example, high- vs low-density cities, different agricultural regimes, and distinct mountain and ecotone systems. Validation against high-resolution imagery shows high mapping accuracy and robustness across resolutions (1, 5, 10 km).

The archetypes reveal clear social-ecological gradients from largely natural, high-carbon, high-habitat mountain systems, through agro-pastoral and agricultural zones, to highly modified, service-rich but ecologically dependent urban cores. Analyzing indicator patterns, the authors infer four recurring types of human-environment interaction: cross-regional telecouplings between food-producing and consuming areas; strong dependence of human activities on environmental suitability; adaptive efforts to reconnect with nature (e.g., urban green and cultural landscapes); and the co-occurrence of intensive modification and conservation across the region.

The paper explicitly uses and advances metacoupling/telecoupling ideas, especially in interpreting spatial decoupling between where human activities concentrate and where environmental impacts occur. It offers a transferable, data-driven SES archetype mapping approach to support context-specific sustainability and landscape governance in BTH and comparable urbanizing regions.

## Structured Metacoupling Extraction

### Coupling Classification
- Primarily intracoupling within BTH SESs, with explicit intra-regional telecoupling via pollution and resource flows.

### Intracoupling
#### Systems
- Urban, urban-rural transition, agricultural, ecological transition, and natural systems inside Beijing-Tianjin-Hebei.
- Nested regional sub-archetypes like high-density urban, plateau agro-pastoral, mountain forest systems.
#### Flows
- Local flows of food, labor, and ecosystem services between neighboring archetypes.
- Localized PM2.5, land-use change, and infrastructure expansion across adjacent grids.
#### Agents
- Urban residents, farmers, herders, local governments, regional planners.
- Industrial enterprises, infrastructure developers, conservation agencies.
#### Causes
- Urbanization, agricultural intensification, poverty, and ecological restoration policies.
- Terrain, climate gradients and land suitability guiding settlement and land use.
#### Effects
- Spatial gradients in habitat quality, carbon storage, and ecosystem service supply.
- Local pollution hotspots, land conversion, and social inequalities across archetypes.

### Pericoupling
#### Systems
- BTH agricultural and ecological transition zones with surrounding provinces and river basins.
- BTH urban fringe interacting with nearby rural counties.
#### Flows
- Short-distance commuting, peri-urban land and housing markets.
- Cross-boundary PM2.5 and water runoff between plains and mountains.
#### Agents
- Commuters, peri-urban developers, county-level administrations.
#### Causes
- In-situ urbanization and rural industrialization around major cities.
- Differences in infrastructure and public service provision near administrative borders.
#### Effects
- Urban-rural land conflicts, village loss, and cropland reduction near city edges.
- Ecological degradation in poverty belts around metropolitan cores.

### Telecoupling
#### Systems
- Urban systems as receiving systems; agricultural and urban-rural systems as sending systems.
- Ecological transition and natural systems as spillover systems affected by distant demand.
- BTH linked to distant regions through trade, investment, and pollution transport.
#### Flows
- Telecoupled food, water, energy, and other ecosystem service flows to cities.
- Atmospheric transport of PM2.5 and other pollutants across long distances.
- Trade-mediated resource extraction and carbon-emission footprints beyond local boundaries.
#### Agents
- National and regional governments shaping trade and environmental policy.
- Urban consumers, agribusiness, supply-chain corporations.
- Environmental NGOs and international initiatives influencing restoration projects.
#### Causes
- Globalization, industrialization, and concentration of consumption in metropolitan areas.
- Decoupling of resource consumption locations from production landscapes.
- Large-scale ecological restoration and afforestation responding to regional dust and climate concerns.
#### Effects
- Human impacts shifted from cities to rural production and transition zones.
- Spillover degradation or improvement in mountain and plateau ecosystems.
- Vulnerability of cities to disruptions in distant provisioning systems.

### Cross-Coupling Interactions
- Four archetypical interactions: telecoupling, dependence, adaptation, and modification-conservation of environment.
- Human-environment gradients from natural to urban systems reveal shifting coupling intensities.
- Urban cultural ecosystem services partly mitigate negative telecoupled impacts elsewhere.

### Research Gaps or Limitations
- Grid-level indicators omit key social factors like equity, migration, and trade structure.
- Clustering choices and rules depend on expert judgment and knowledge of BTH.
- Limited temporal analysis; archetypes mapped for a single year rather than dynamic evolution.

### Search Keywords
- social-ecological system archetypes Beijing Tianjin Hebei telecoupling
- fine resolution SES mapping human-environment interactions PM2.5
- urban rural transition agricultural systems ecological and natural systems China

### Extraction Confidence
high
