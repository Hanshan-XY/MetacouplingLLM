# Unraveling the Dual Impacts of Urbanization on Agricultural Habitats A Telecoupling Perspective Fro

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:56:16.308692+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Liu et al. - 2025 - Unraveling the Dual Impacts of Urbanization on Agricultural Habitats A Telecoupling Perspective Fro.pdf
- Year: unknown
- DOI: 10.1002/ldr.70075
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This study examines how rapid urbanization affects agricultural habitats in Zhejiang Province, China, using a telecoupling perspective that links urban land demand with land-use changes in distant rural areas. Zhejiang is both highly urbanized and biodiversity rich, with cropland and forests providing key habitats.

The authors combine land use/land cover maps for 2000 and 2020, road data, MODIS net primary productivity (NPP), and a habitat quality model. They distinguish three pathways: (1) direct conversion of cropland to built-up land, (2) indirect degradation of remaining cropland near new urban areas, and (3) indirect gains from cropland displacement, where new cropland is created elsewhere to maintain food production.

From 2000 to 2020, built-up land grew dramatically, while cropland shrank. Urban expansion directly removed a large share of agricultural habitat and further reduced habitat quality on surrounding cropland through edge effects and human pressures. The indirect degradation affected a broader area but caused less loss per unit area than direct conversion.

Cropland displacement, estimated via NPP-based food production demand, increased agricultural habitat in other locations, often in more remote, biodiversity-richer settings. On average, these new croplands had higher modeled habitat quality than cropland near cities. As a result, telecoupled gains partly offset the local losses, and the net provincial decline in agricultural habitat was smaller than the direct losses alone would suggest. However, most displaced cropland replaced forests and other natural ecosystems, generating significant ecological trade-offs and a spatial mismatch between where habitat is lost and gained.

The paper is explicitly about telecoupling/metacoupling: it uses the telecoupling framework to trace how urbanization in core cities such as Hangzhou drives cropland creation, deforestation, and habitat change in less urbanized areas like Lishui. The authors emphasize that cropland displacement is policy driven, not an inherent benefit of urbanization, and that planning must consider both local and distant ecological impacts of urban growth.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling focus; also addresses intracoupling and pericoupling in Zhejiang urban rural systems.

### Intracoupling
#### Systems
- Urbanizing cities within Zhejiang such as Hangzhou, Ningbo, Jiaxing
- Rural and mountainous counties within Zhejiang like Lishui, Quzhou
#### Flows
- Local cropland conversion to built up land within each city
- Local habitat quality changes on cropland near new construction
#### Agents
- Municipal governments implementing urban expansion and zoning
- Local farmers adjusting land use and cropping decisions
- Provincial agencies enforcing cropland protection regulations
#### Causes
- Economic growth and population concentration in Zhejiang cities
- Municipal preference for land based development revenues
- Implementation of permanent basic cropland and balance rules
#### Effects
- Direct local loss of cropland and agricultural habitat
- Indirect degradation of cropland biodiversity around cities
- Local trade offs between food production and urban land demand

### Pericoupling
#### Systems
- Urban fringes and adjacent rural belts around major Zhejiang cities
- Neighboring prefecture level cities within Zhejiang
#### Flows
- Peri urban expansion converting nearby cropland to built up land
- Short distance relocation of cropland from plains to nearby hills
#### Agents
- County governments at urban rural interfaces
- Developers acquiring cropland at city edges
#### Causes
- Urban sprawl and low density expansion patterns
- Policies encouraging compensation cropland within same province
#### Effects
- Habitat fragmentation in peri urban cropland mosaics
- Reduction of landscape connectivity for farmland species
- Increased pressure on nearby forests and wetlands

### Telecoupling
#### Systems
- Highly urbanized cities like Hangzhou as sending systems
- Less urbanized mountainous cities like Lishui as receiving systems
- Provincial policy and financial institutions as intermediary system
#### Flows
- Displaced cropland area from urban cores to distant rural areas
- Financial compensation and investment moving opposite to cropland
- Telecoupled ecological impacts including deforestation and habitat shifts
#### Agents
- Provincial government coordinating cropland balance across cities
- City governments negotiating cropland occupation and compensation
- Land bureaus and planning departments mediating land transfers
#### Causes
- Urban food demand and cropland protection targets
- Requisition compensation balance and permanent farmland policies
- Rural development needs and search for fiscal revenues
#### Effects
- Increased agricultural habitat in distant cropland displacement zones
- Loss and degradation of forest habitats in receiving regions
- Spatial mismatch between habitat losses near cities and gains elsewhere

### Cross-Coupling Interactions
- Urban expansion in sending cities triggers cropland displacement and deforestation in remote receiving cities.
- Policy driven cropland balance links local urban habitat losses with distant agricultural habitat gains.
- Indirect impacts extend farther than direct ones, redistributing biodiversity risks across the province.

### Research Gaps or Limitations
- Coarse land use and road data limit precision of habitat and urban impact estimates.
- Study considers in province displacement; cross provincial or international telecoupling remains unclear.
- Positive agricultural habitat gains may hide unquantified losses of forest services and long term productivity.

### Search Keywords
- telecoupling urbanization cropland displacement Zhejiang
- agricultural habitat quality urban rural teleconnections
- forest loss policy driven land compensation China

### Extraction Confidence
high
