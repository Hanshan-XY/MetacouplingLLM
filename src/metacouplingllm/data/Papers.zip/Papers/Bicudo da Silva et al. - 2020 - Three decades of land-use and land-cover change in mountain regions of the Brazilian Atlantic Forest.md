# Three decades of land-use and land-cover change in mountain regions of the Brazilian Atlantic Forest

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:29:01.046297+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Bicudo da Silva et al. - 2020 - Three decades of land-use and land-cover change in mountain regions of the Brazilian Atlantic Forest.pdf
- Year: unknown
- DOI: 10.1016/j.landurbplan.2020.103948
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines long-term land-use and land-cover change in mountain regions of the Brazilian Atlantic Forest biome and their implications for conservation and coupled human-nature systems. The focus is on the officially mapped mountain reliefs (serras) across eight Brazilian states, which together cover about 12 percent of the biome.

Using MapBiomas land-cover maps for 1985, 2001, and 2018 (30 m resolution), the authors reclassified 27 land-use classes into six broader types and applied change-detection, landscape metrics, and non-parametric statistical tests. They also combined these data with elevation and slope models, protected area boundaries, and municipal-level census data on rural and urban populations. Comparisons were made between mountain and non-mountain portions of the Atlantic Forest to assess relative pressures and fragmentation.

Overall land-cover composition in mountain regions remained statistically stable over 34 years, with natural vegetation staying near half of the area. Yet patch metrics reveal a meta-stable mosaic: strong two-way exchanges between agriculture and natural vegetation occur without large net change, and small patches (under 10 ha) experience the greatest turnover and fragmentation. Planted forests, mainly eucalyptus, expanded markedly and emerged as the main net driver of natural vegetation loss. Total deforestation in mountain areas was much lower than in non-mountain parts of the biome; natural vegetation loss in mountains was about thirteen times smaller in relative terms.

Most forest in mountain regions persists on steep, agriculturally unsuitable slopes and remains in large patches: around 90 percent of natural vegetation lies in fragments over 50 ha, and one very large patch constitutes a substantial share of the biome’s remaining continuous forest. Urban areas and populations have grown, but urban and rural populations are positively associated with forest cover, and built-up land remains under 1 percent of mountain area, though often on hazardous steep slopes. Only a small fraction of mountain forests lies in strictly protected areas.

The paper explicitly engages telecoupling by highlighting how distant demand and tourism, as well as forest-product supply chains and certification systems, shape land-use dynamics in these mountain landscapes.

## Structured Metacoupling Extraction

### Coupling Classification
- Mainly intracoupling of mountain landscapes, with some discussed telecoupling via tourism and forestry demand.

### Intracoupling
#### Systems
- Mountain regions within Brazilian Atlantic Forest biome.
- Non-mountain Atlantic Forest regions for comparison.
- Municipal socio-ecological systems with urban and rural populations.
#### Flows
- Land transitions among natural vegetation, agriculture, planted forest, built-up areas.
- Human migration and urban expansion within mountain municipalities.
- Tourism and second-home visitation inside mountain landscapes.
#### Agents
- Smallholder farmers and local agro-extractive producers.
- Urban residents, second-home owners, and tourists.
- Forestry companies establishing eucalyptus plantations.
#### Causes
- Topography limiting extensive agribusiness and concentrating uses on gentle slopes.
- Local demand for food, energy wood, housing, and tourism services.
- Lack of mountain-specific conservation and land-use policies.
#### Effects
- Meta-stable shifting mosaic of natural vegetation and agriculture patches.
- Low net deforestation in mountains but increased fragmentation of small patches.
- Urban growth on steep slopes raising landslide and erosion risks.

### Pericoupling
#### Systems
- Mountain municipalities and adjacent lowland municipalities.
- Urban cores and surrounding peri-urban mountain fringes.
- Protected areas and nearby unprotected private lands.
#### Flows
- Daily commuting, service access, and short supply chains for food products.
- Expansion of urban built-up areas into peri-urban steep terrains.
- Leakage of land-use change around protected areas.
#### Agents
- Municipal governments and local planners.
- Peri-urban residents including low-income hillside dwellers.
- Managers of conservation areas and local NGOs.
#### Causes
- Higher land prices in safer central urban zones.
- Insufficient regulation of hillside construction and landfills.
- Spatial mismatch between conservation priority and legal protection.
#### Effects
- Concentration of favelas and infrastructure on risky slopes.
- Localized environmental degradation in peri-urban steep areas.
- Partial buffering of biodiversity by protected but fragmented mosaics.

### Telecoupling
#### Systems
- Mountain regions of the Atlantic Forest as sending and receiving system.
- Distant national and international markets for eucalyptus pulp and wood.
- External urban populations engaging in ecotourism in mountain areas.
#### Flows
- Trade in pulp, timber, charcoal, and other forest-based commodities.
- Tourist visits and second-home investments from distant cities.
- Diffusion of international forest certification norms.
#### Agents
- Forestry corporations and certification bodies.
- Tour operators, hospitality businesses, and external tourists.
- National policymakers and global conservation organizations.
#### Causes
- Global demand for cellulose pulp and forest products.
- Growing ecotourism interest in scenic and biodiverse mountains.
- Telecoupled policy and certification incentives affecting plantation management.
#### Effects
- Expansion of planted forests replacing natural vegetation in mountains.
- Reinforcement of conservation where ecotourism values intact forests.
- Indirect, understudied land-change drivers via distant economic forces.

### Cross-Coupling Interactions
- Telecoupled pulp demand amplifies local plantation expansion, altering intracoupled land mosaics.
- Tourism from distant cities strengthens local conservation but stimulates risky urbanization on slopes.
- Low protection levels make mountain biodiversity vulnerable to combined local and distant pressures.

### Research Gaps or Limitations
- Telecoupling mechanisms linking mountains, agricultural frontiers, and markets remain largely unexplored.
- Limited understanding of non-certified local plantation chains and their land-use impacts.
- Need finer-scale socio-economic data to link household decisions with patch-level dynamics.

### Search Keywords
- Brazilian Atlantic Forest mountain land-use change
- meta-stable shifting mosaic natural vegetation agriculture
- telecoupling tourism eucalyptus plantations biodiversity

### Extraction Confidence
high
