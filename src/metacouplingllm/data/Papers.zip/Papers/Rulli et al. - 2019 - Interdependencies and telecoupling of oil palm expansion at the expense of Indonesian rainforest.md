# Interdependencies and telecoupling of oil palm expansion at the expense of Indonesian rainforest

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:03:57.596214+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Rulli et al. - 2019 - Interdependencies and telecoupling of oil palm expansion at the expense of Indonesian rainforest.pdf
- Year: unknown
- DOI: 10.1016/j.rser.2018.12.050
- OA status: green
- License: other-oa
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: green OA without permissive license (other-oa)

## Copyright-Safe Summary
This paper examines how global demand for palm oil drives environmental change in Indonesia, using a telecoupling perspective that links distant consumers, energy policies, and local ecosystems.

The study focuses on Indonesia, the world’s largest palm oil producer, where plantations expand mainly into rainforest and peatland. It situates oil palm within global food and biofuel systems, emphasizing European Union and United States bioenergy policies and rising demand in emerging economies as key external drivers.

Using national and spatially explicit datasets, the authors overlay forest cover maps (2000-2014), concession boundaries (oil palm, logging, fiber), and land cover to quantify deforestation and forest fragmentation. They estimate associated CO2 emissions from biomass and soil (with peat and non-peat scenarios), map seasonal blue water scarcity, and calculate nitrogen-related water pollution using a grey water footprint approach. Trade statistics then connect Indonesian production to importing countries, framing exported palm oil as embodying outsourced emissions and pollution.

Results show that Indonesia lost over 20 million hectares of forest since 2000, with concession areas experiencing about 20 percent forest loss and a 44 percent rise in fragmentation, higher than comparable non-concession lands. Oil palm concessions hold only a small share of initial forest but account for a disproportionate fraction of deforestation and fragmentation, especially in Kalimantan and Sumatra. Estimated carbon loss from palm-driven land conversion reaches roughly 2.4-4.4 gigatonnes of CO2-equivalent, with peatlands contributing heavily. Fertilizer use generates substantial grey water footprints in major producing provinces, and dry-season irrigation intensifies local water scarcity. Around four-fifths of Indonesian palm oil is exported, with most going to a few Asian and European countries, effectively shifting climate and water pollution burdens from importers to Indonesia.

The paper is explicitly about telecoupling: it links sending (consumer/policy) regions, receiving (Indonesian production) regions, and spillover effects, and shows how climate and biofuel policies can displace, rather than reduce, global environmental impacts.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling between Indonesian oil palm frontiers and distant consumer and biofuel markets.

### Intracoupling
#### Systems
- Indonesian rainforest landscapes and peatlands
- National oil palm plantation and concession system
- Indonesian river basins and groundwater resources
#### Flows
- Land conversion from forest to oil palm plantations
- Domestic CO2 emissions from deforestation and peat degradation
- Nutrient runoff and grey water pollution from fertilizer use
#### Agents
- Indonesian government allocating land concessions
- Domestic and transnational agribusiness plantation companies
- Local communities and smallholders near concessions
#### Causes
- National policies favoring plantation expansion and land concessions
- Profitability of oil palm relative to alternative land uses
- Weak enforcement of forest and peatland protection
#### Effects
- Accelerated forest loss and sharp rise in fragmentation within concessions
- Large national carbon stock reduction, especially on peatlands
- Seasonal water scarcity and widespread nitrate pollution in key provinces

### Pericoupling
#### Systems
- Indonesia and neighboring Southeast Asian producer countries
- Regional biodiesel production and trade in Asia
- Transboundary ecological systems across Borneo and Sumatra
#### Flows
- Regional palm oil and biodiesel trade among Asian countries
- Cross-border investment in oil palm concessions
- Spread of land grabbing practices across Southeast Asia
#### Agents
- Regional agribusiness and investment firms
- Neighboring governments promoting biofuel feedstocks
- Regional certification and governance initiatives
#### Causes
- Regional energy transition and biofuel mandates
- Competitive land and labor costs in producer countries
- Market deregulation to attract foreign land investments
#### Effects
- Shared regional deforestation and habitat fragmentation hotspots
- Expansion of oil palm frontiers into new Asian regions
- Emerging regional water and pollution stresses

### Telecoupling
#### Systems
- Indonesia as sending system exporting crude palm oil
- EU, USA, India, China, Pakistan as receiving systems
- Other palm oil importers and displaced buyers as spillover systems
#### Flows
- Exports of crude palm oil and biofuel feedstocks from Indonesia
- Embodied CO2 emissions and grey water in traded palm oil
- Information and policy signals from foreign renewable energy directives
#### Agents
- European and US policymakers designing renewable energy and biofuel mandates
- Food, cosmetic, and biofuel industries in importer countries
- International traders, financiers, and land investors
#### Causes
- Foreign renewable energy and climate mitigation policies increasing vegetable oil demand
- Rising dietary and industrial demand for palm oil in populous countries
- Globalization of agricultural commodity markets and land investments
#### Effects
- Indonesian deforestation and peatland conversion eroding intended foreign climate benefits
- Virtual export of pollution and emissions from importing to producing countries
- Leakage where restrictions in one market shift demand to other importers

### Cross-Coupling Interactions
- EU palm oil restrictions redirect demand toward Asian and Middle Eastern importers, keeping Indonesian exports high.
- Domestic Indonesian biodiesel blending increases local use while exports to new partners still grow.
- Forest protection or biofuel caps in one region trigger land use change and trade realignment elsewhere.

### Research Gaps or Limitations
- Quantitative attribution of deforestation specifically to foreign land acquisitions remains uncertain.
- Social impacts on local livelihoods and land rights are noted only indirectly.
- Future telecoupling under evolving policies and markets is not dynamically modeled.

### Search Keywords
- telecoupling oil palm Indonesia deforestation
- palm oil trade CO2 grey water exports
- biofuel policy leakage peatland conversion

### Extraction Confidence
high
