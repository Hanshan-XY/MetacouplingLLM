# Framing ecosystem services in the telecoupled Anthropocene

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:54:28.259119+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Liu et al. - 2016 - Framing ecosystem services in the telecoupled Anthropocene.pdf
- Year: unknown
- DOI: 10.1002/16-0188.1
- OA status: closed
- License: none recorded
- Category: Journal Articles\Conceptual\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This conceptual paper links ecosystem services research with the telecoupling framework to better understand how benefits from nature move across large distances in the Anthropocene. The authors argue that traditional ecosystem services studies often focus either on local supply areas or on distant trade and environmental impacts, but rarely integrate both in a single analytical structure. They propose using telecoupling, defined as socioeconomic and environmental interactions between geographically separated coupled human-natural systems, as a unifying lens.

Geographically, the paper is centered on China but draws on global examples of water and virtual water transfers. The core empirical illustration is China’s South-North Water Transfer Project (SNWTP), the world’s largest inter-basin water diversion, which moves water from the Yangtze basin in the south to water-scarce northern regions including Beijing and Tianjin.

Within the telecoupling framework, the authors classify sending, receiving, and spillover systems; identify flows of material, energy, money, technology, and information; and describe key agents such as central and local governments, companies, experts, and residents. They analyze multiple causes driving the SNWTP, including stark regional water imbalances, rapid economic and population growth in the north, political support for mega-projects, and technological capacity. The paper then examines environmental and social effects such as reduced groundwater extraction in the north, altered hydrology and ecosystems in source basins, large-scale resettlement, changes in navigation and hydropower, risks of invasive species, and downstream impacts like saltwater intrusion in the Yangtze Delta.

The study explicitly concerns telecoupling and contributes to the broader metacoupling perspective by stressing feedbacks among distant systems and the importance of spillover regions, which are often ignored in ecosystem services and payment for ecosystem services policies. The authors argue that using the telecoupling framework can help design more holistic governance of distant ecosystem service flows, highlight trade-offs between real and virtual water, and support more equitable compensation mechanisms in an increasingly interconnected world.

## Structured Metacoupling Extraction

### Coupling Classification
- Conceptual telecoupling study of distant ecosystem service flows using Chinas South North Water Transfer
- Also addresses intracoupling within sending and receiving regions and pericoupled spillover areas

### Intracoupling
#### Systems
- Yangtze basin sending areas including reservoirs and upstream catchments
- Northern China receiving provinces and mega cities
- Local spillover sites such as resettlement towns and delta regions
#### Flows
- Local ecosystem services like water regulation, food, recreation within each basin
- Internal water use changes including groundwater extraction reduction
- Local information flows on project impacts and compensation demands
#### Agents
- Local governments and basin management bureaus
- Households, farmers, fishers, resettled residents
- Local enterprises involved in construction, shipping, tourism
#### Causes
- Mismatch between local water availability and rising local demand
- Pollution and eutrophication degrading local water ecosystem services
- Local political incentives for regional economic expansion
#### Effects
- Vegetation loss and land cover change near dams and canals
- Altered lake and river hydrology, biodiversity decline, invasive species spread
- Job creation, displacement, changing livelihoods and land subsidence mitigation

### Pericoupling
#### Systems
- Regions along transfer routes acting as adjacent spillover systems
- Yangtze Delta and downstream coastal areas
- Domestic provinces providing materials, labor, finances
#### Flows
- Lateral leakage, evaporation, and tributary inflows along canals
- Movement of construction materials, machinery, and workers regionally
- Regional spread of pollutants, invasive species, and diseases
#### Agents
- Provincial construction committees and environmental agencies
- Regional logistics, shipping, and hydropower companies
- Resettlement authorities and social service providers
#### Causes
- Routing of canals through intermediate regions for engineering feasibility
- Need for regional infrastructure upgrades and navigation improvements
- Demand for labor markets and industrial opportunities near routes
#### Effects
- Regional flood and drought regulation changes along routes
- Saltwater intrusion threats in delta due to reduced river discharge
- Socioeconomic shifts in resettlement zones and port cities

### Telecoupling
#### Systems
- Southern China water sending systems in Yangtze basin
- Northern China receiving systems including Beijing, Tianjin, grain regions
- Domestic and international spillover systems supplying capital, technology, expertise
#### Flows
- Massive real water transfer from south to north via three routes
- Virtual water trade through grain shipments between north and south
- Information, technology, financial flows across distant institutions and countries
#### Agents
- Central government, State Council, national project office
- Banks, engineering firms, transregional companies, NGOs
- Distant consumers of water intensive goods and ecosystem services
#### Causes
- Strong spatial decoupling between ecosystem service supply and distant demand
- Rapid population, economic growth and water consumption in northern cities
- National political agenda favoring mega projects and enabled by technological advances
#### Effects
- Redistribution of water related services, shifting environmental burdens southward
- Net environmental and economic benefits projected for northern receivers
- Global scale implications through virtual water trade and potential policy diffusion

### Cross-Coupling Interactions
- Feedback as southern environmental impacts influence northern policies via media and scientific reports
- Telecoupled water transfers alter virtual water trade directions between northern and southern China
- Payments for ecosystem services link sending, receiving, and spillover systems through financial feedbacks

### Research Gaps or Limitations
- Spillover system environmental and social effects remain poorly quantified
- Limited integration of multiple ecosystem services and trade offs in assessments
- Few policy instruments fully incorporate distant feedbacks and true telecoupling costs

### Search Keywords
- telecoupling ecosystem services Anthropocene
- South North Water Transfer Project China
- real and virtual water flows coupled human natural systems

### Extraction Confidence
high
