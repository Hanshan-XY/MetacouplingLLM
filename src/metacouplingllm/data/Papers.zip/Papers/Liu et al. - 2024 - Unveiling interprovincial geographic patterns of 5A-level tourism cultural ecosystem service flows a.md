# Unveiling interprovincial geographic patterns of 5A-level tourism cultural ecosystem service flows a

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:55:52.142320+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Liu et al. - 2024 - Unveiling interprovincial geographic patterns of 5A-level tourism cultural ecosystem service flows a.pdf
- Year: unknown
- DOI: 10.1016/j.apgeog.2024.103432
- OA status: hybrid
- License: cc-by-nc-nd
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This study analyzes how cultural ecosystem services associated with nature-based tourism flow between Chinese provinces, focusing on top-tier (5A) scenic sites and applying the metacoupling framework. The geographic scope is all 31 provincial-level regions in mainland China, considering intracoupling (within-province travel), pericoupling (between neighboring provinces), and telecoupling (between non-neighboring provinces).

The authors construct an interprovincial flow network using 143,681 user comments on 217 nature-based 5A attractions from the Ctrip platform (2022-2023). Each comment is linked to the users IP-based home province and the destination province, generating a 31-by-31 directed flow matrix. Attractions are classified into 12 ecosystem types (e.g., forests, deserts, urban landscapes, cryosphere, oases). Metacoupling indicators are computed as the shares of flows that are intra-, peri-, or tele-coupled. The study also applies a Chinese NLP toolkit (SnowNLP) to 94,469 cleaned comments, training seven sentiment dimensions (climate, natural landscape, indigenous culture, tourist expenses, transport costs, facilities, tourism services). Multiple linear regression relates these sentiment scores to travel distance. Network modularity is used to identify regional flow bundles.

Nationally, within-province travel dominates cultural service flows, but telecoupling is stronger than pericoupling, indicating a substantial role for long-distance tourism. Northeastern provinces are more telecoupled, while southwestern and parts of western China are more inward-looking. Forest ecosystems account for about one-third of recorded visits and are mainly used locally or regionally, whereas rarer ecosystems (oases, cryosphere) show strong telecoupling and attract distant visitors.

Sentiment results show that nearby or neighboring trips generally yield higher satisfaction in geographic, economic, and social dimensions, while long-distance trips are particularly driven by interest in indigenous cultures. Economic factors (prices and transport costs) are the primary constraints on telecoupled travel in most provinces.

The paper explicitly adopts and operationalizes the metacoupling/telecoupling framework for tourism-related cultural ecosystem service flows, offering a scalable method to link big-data-based tourist movements, ecosystem types, and distance-dependent preferences.

## Structured Metacoupling Extraction

### Coupling Classification
- Explicit metacoupling study of tourism cultural ecosystem service flows among Chinese provinces

### Intracoupling
#### Systems
- Individual Chinese provinces as coupled human nature systems
- Forest dominated scenic areas within provinces
- Southwestern and northwestern provincial tourism systems
#### Flows
- Within province visits to 5A nature based scenic spots
- Local cultural ecosystem service experiences by nearby residents
- Short distance nature based recreation trips
#### Agents
- Domestic tourists residing in the same province
- Local tourism managers and park administrations
- Online travel platform Ctrip as data mediator
#### Causes
- Lower time and monetary costs of nearby trips
- Post pandemic preference for short haul and rural nature tourism
- High availability of forest and urban park ecosystems locally
#### Effects
- Intracoupling dominates national CESF share
- Concentration of visits in popular provincial hotspots
- Local economic benefits and pressure on nearby ecosystems

### Pericoupling
#### Systems
- Adjacent Chinese provinces with shared borders
- Regional clusters like Jiangsu Anhui Shanghai
- Neighboring provinces with similar forest and water ecosystems
#### Flows
- Cross border trips to nearby 5A scenic sites
- Moderate distance cultural ecosystem service flows
- Periprovincial tourism bundles in eastern China
#### Agents
- Tourists traveling to neighboring provinces
- Regional tourism authorities coordinating marketing
- Transportation providers enabling short interprovincial trips
#### Causes
- Comfortable travel distances and perceived safety
- Policy support for regional tourism cooperation
- Attractive nearby climates and landscapes
#### Effects
- Intermediate share of national CESF but lowest among three types
- Highest average sentiment in several preference pillars
- Strengthened regional tourism clusters and bundles

### Telecoupling
#### Systems
- Distant Chinese provinces such as northeast and southwest pairs
- Rare ecosystems like oases and cryosphere destinations
- Highly connected provinces including Beijing Hainan Jiangsu Sichuan
#### Flows
- Long distance interprovincial tourism flows to 5A sites
- Telecoupled cultural ecosystem service exchanges
- High weight network links among distant tourism bundles
#### Agents
- Long distance domestic tourists tracked via IP locations
- Destination managers in iconic remote landscapes
- Online reviewers shaping distant travelers perceptions
#### Causes
- Search for unique landscapes and indigenous cultures
- Economic capacity to afford travel and transport costs
- Government promotion of cross regional tourism recovery
#### Effects
- Telecoupling nationally exceeds pericoupling share
- Northeastern residents show strong telecoupling preference
- Economic impacts and cultural exchange in remote destinations

### Cross-Coupling Interactions
- Metacoupling analysis links intra peri and tele flows in one national network
- Ecosystem types show different dominance of intra peri tele patterns
- Tourist sentiments vary systematically with coupling distance category

### Research Gaps or Limitations
- Only 5A scenic spots from one platform with IP data were analyzed
- Non Chinese trips and other platforms without IP disclosure excluded
- Visitor demographics and detailed cultural service subtypes not captured

### Search Keywords
- metacoupling tourism China IP based flow network
- cultural ecosystem service flows intra peri telecoupling
- sentiment analysis long distance nature based tourism

### Extraction Confidence
high
