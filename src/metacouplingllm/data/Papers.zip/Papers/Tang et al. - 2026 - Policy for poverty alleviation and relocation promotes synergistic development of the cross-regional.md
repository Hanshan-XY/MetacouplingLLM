# Policy for poverty alleviation and relocation promotes synergistic development of the cross-regional

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-10-12T05:39:45.816590+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Tang et al. - 2026 - Policy for poverty alleviation and relocation promotes synergistic development of the cross-regional.pdf
- Year: unknown
- DOI: 10.1016/j.habitatint.2025.103666
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines how Chinas poverty alleviation and relocation (PAR) policy reshapes linked social-ecological systems across space, focusing on Guizhou Province, a mountainous, karst region in southwest China with extensive ecological fragility and large-scale relocation.

Within a telecoupling framework, migrant outflow sites (MOS) are treated as sending systems where ecosystem health (EH) responds to reduced human pressure, while migrant inflow sites (MIS) are receiving systems where social adaptability (SA) reflects how well relocated households integrate. The study explicitly applies telecoupling theory, so it is directly relevant to metacoupling/telecoupling research.

Data include: a four-wave panel survey of 708 relocated households in 23 resettlement communities (2019-2022); detailed questionnaire indicators on livelihoods, psychology, social relations, and development potential; and spatial data (land use, NDVI, DEM, relocation scale). SA is measured through a weighted index with four dimensions: economic adaptability, social life adaptability, psychological attribution, and development ability. EH in MOS is assessed from 2000-2022 using a Vigor-Organization-Resilience-Services (VORS) model on 1 km grids, incorporating vegetation productivity, landscape pattern, resilience of land-use types, and ecosystem service values with neighborhood effects.

Results show significant improvements in SA after relocation, with especially rapid gains after 2020 and marked spatial differences: central and some western resettlement areas improve fastest, and psychological identification adapts more strongly than economic and social-life dimensions. EH in MOS first declines slightly, then increases sharply, then stabilizes at higher levels, with EH gains strongly associated with the scale of out-migration and no counties showing continuous deterioration.

A refined coupling coordination model links SA (MIS) and EH (MOS) along actual migration pathways, revealing a strengthening, increasingly widespread synergy network over time. Surprisingly, some long-distance pairs show stronger coupling than nearby ones. Generalized additive models indicate that distance effects on coordination are often weak overall but nonlinear and site-specific, challenging simple distance-decay assumptions.

Overall, PAR in Guizhou functions as a telecoupled intervention that simultaneously enhances ecosystem conditions in sending regions and social adaptation in receiving communities, illustrating how relocation policy can be designed and evaluated as a cross-regional metacoupled system.

## Structured Metacoupling Extraction

### Coupling Classification
- Study explicitly analyzes telecoupling between migrant sending and receiving social ecological systems

### Intracoupling
#### Systems
- Migrant inflow urban communities in Guizhou
- Migrant outflow rural counties and townships
#### Flows
- Local land use change and vegetation recovery
- Community interactions and social capital formation
- Household livelihood diversification within sites
#### Agents
- Relocated households
- Local governments and neighborhood committees
- Local farmers remaining in origin areas
#### Causes
- Implementation of poverty alleviation relocation policy
- Follow up support measures and community governance
- Existing karst ecological fragility and land scarcity
#### Effects
- Rising social adaptability of migrants after relocation
- Improved ecosystem health in some origin counties
- Internal heterogeneity among communities adaptation levels

### Pericoupling
#### Systems
- Neighboring counties within Guizhou province
- Adjacent rural urban fringes near resettlement sites
#### Flows
- Spillover of ecosystem services across nearby grids
- Regional labor and commuting between towns and cities
#### Agents
- Prefecture level governments
- Regional enterprises investing in agriculture or tourism
#### Causes
- Spatial clustering of relocation projects and hotspots
- Shared climatic and geomorphological conditions
#### Effects
- Core periphery pattern in ecosystem health around Guiyang
- Positive spatial correlation of relocation scale and ecosystem recovery

### Telecoupling
#### Systems
- Migrant outflow sites as sending social ecological systems
- Migrant inflow sites as receiving social ecological systems
- Relocation policy apparatus as spillover system
#### Flows
- Population migration from karst rural areas to urban resettlement
- Cross regional flows of capital technology and information
- Cross regional ecosystem service and carbon sink changes
#### Agents
- Central and provincial governments designing PAR policy
- Ecological migration bureaus and local implementation agencies
- Relocated households making livelihood and return decisions
#### Causes
- National poverty eradication and rural revitalization strategies
- Goal to reduce human pressure on fragile karst ecosystems
- New type urbanization based on spatial population redistribution
#### Effects
- Synergistic improvement in social adaptability and ecosystem health over time
- Reduced dependence on natural resources in origin areas
- Potential for return migration to undermine ecological gains

### Cross-Coupling Interactions
- Higher migrant adaptability in cities stabilizes ecological restoration in origin areas
- Ecological improvements and land use changes in origin influence migrants land transfer decisions
- Long distance migration sometimes shows stronger SES coupling than nearby moves

### Research Gaps or Limitations
- Only spatial distance effects modeled while other drivers of telecoupling left for future work
- Telecoupling assessed for a short post relocation period limiting long term insights
- Emotional and social capital linkages between origin and destination not fully operationalized

### Search Keywords
- poverty alleviation relocation Guizhou telecoupling
- social adaptability ecosystem health coupling coordination
- karst rural migration cross regional social ecological system

### Extraction Confidence
high
