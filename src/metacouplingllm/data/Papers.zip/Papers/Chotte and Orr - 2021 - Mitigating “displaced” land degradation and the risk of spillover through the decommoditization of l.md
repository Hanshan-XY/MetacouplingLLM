# Mitigating “displaced” land degradation and the risk of spillover through the decommoditization of l

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:36:16.183320+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Chotte and Orr - 2021 - Mitigating “displaced” land degradation and the risk of spillover through the decommoditization of l.pdf
- Year: unknown
- DOI: 10.1016/j.landusepol.2021.105659
- OA status: closed
- License: none recorded
- Category: Journal Articles\Commentary\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This viewpoint paper examines how global consumption drives land degradation in distant production areas and explores options to reduce this telecoupled damage. It has a global focus, using examples and datasets that span multiple regions, with particular emphasis on wealthy importing countries such as those in Europe. The authors situate land degradation within a wider system context that includes biodiversity loss, ecosystem services decline, and heightened risk of zoonotic disease spillover, as highlighted by COVID-19.

Using existing global assessments and indicators rather than new empirical data, the paper synthesizes evidence on how international trade and consumption patterns displace environmental burdens. It discusses the concepts of Human Appropriation of Net Primary Production (HANPP) and especially embodied HANPP, which traces biomass and land-use impacts through trade to final consumption. These tools help reveal how consumption in one region is linked to land-use pressures and degradation elsewhere, illustrating telecoupling between production and consumption systems.

The authors argue that growth-oriented, affluent economies externalize a significant share of their agricultural and ecological footprints through imports, effectively exporting land degradation and biodiversity threats. They connect this to international goals on sustainable resource use and land degradation neutrality, emphasizing that no-net-loss land targets within countries must be reconciled with the external impacts of domestic consumption.

A central proposal is the decommoditization of land-based products: shifting from anonymous bulk commodities to products differentiated by transparent information on land-use practices and land health. Emerging digital tools such as blockchain-based traceability could enable farm-to-table visibility of environmental performance. Such systems would allow consumers and retailers to favor products that avoid land conversion and support restoration, thereby reducing displaced degradation and spillover risks.

The paper is explicitly about telecoupling and closely aligned metacoupling ideas, focusing on distant interactions and feedbacks between consumption centers and land systems worldwide.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling focus linking distant consumption, production, and land degradation spillovers
- Pericoupling implied via regional trade and cross-border agricultural supply chains
- Intracoupling appears in national land use planning and land degradation neutrality policies

### Intracoupling
#### Systems
- National agricultural landscapes under land degradation neutrality strategies
- Domestic food systems integrating sustainable land management
- Country level land use planning and restoration programs
#### Flows
- Domestic food and biomass supply to national consumers
- Information on land condition for internal decision making
- National material and land footprints for policy monitoring
#### Agents
- National governments and land use planners
- Domestic farmers and land managers
- National consumers and retailers
#### Causes
- Overexploitation of land within country borders
- Growth oriented domestic economic policies
- Insufficient integration of land health in planning
#### Effects
- Local land degradation and biodiversity loss
- Reduced ecosystem services and resilience
- Increased national vulnerability to zoonotic spillover

### Pericoupling
#### Systems
- Neighboring countries connected by regional agricultural trade
- Shared transboundary ecosystems affected by land conversion
- Regional food and fashion supply chains
#### Flows
- Cross border trade in food, timber, and biomass
- Regional spread of sustainable land management standards
- Spillover risks of pathogens across nearby regions
#### Agents
- Regional trade blocs and customs unions
- Transboundary agribusiness and textile companies
- Regional environmental and health agencies
#### Causes
- Regional demand for imported agricultural products
- Lack of coordinated regional land use policies
- Weak traceability across neighboring supply chains
#### Effects
- Shifted land degradation to nearby supplier countries
- Regional biodiversity decline and habitat fragmentation
- Heightened cross border disease emergence risk

### Telecoupling
#### Systems
- High income consumer countries importing land based products
- Distant producer countries supplying agricultural commodities
- Globalized food and fashion production networks
#### Flows
- International trade in food, timber, fiber, biofuel crops
- Embodied HANPP and ecological footprints in traded goods
- Blockchain based farm to table land health information
#### Agents
- Global consumers and retailers in wealthy regions
- Export oriented farmers and agribusiness in producer countries
- International organizations promoting land degradation neutrality
#### Causes
- Affluence driven consumption of imported commodities
- Disconnection between consumption and land impacts abroad
- Commodity treatment of land products without land health transparency
#### Effects
- Displaced land degradation in distant production areas
- Global biodiversity threats and species extinction risk
- Increased probability of distant zoonotic spillover events

### Cross-Coupling Interactions
- Telecoupled consumption undermines intracoupling land neutrality goals in producer countries
- Blockchain traceability reconnects distant consumers with local land management outcomes
- Changes in rich country diets reduce telecoupled pressure on vulnerable producer landscapes

### Research Gaps or Limitations
- Limited empirical evidence on how decommoditization changes land degradation patterns
- Need better integration of telecoupled land indicators into national SDG monitoring
- Scarce data linking specific supply chains to quantified pathogen spillover risks

### Search Keywords
- telecoupling displaced land degradation decommoditization
- embodied HANPP land degradation neutrality blockchain traceability
- international trade biodiversity zoonotic spillover

### Extraction Confidence
high
