# Dynamic simulation of urbanization and eco-environment coupling Current knowledge and future prospe

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:39:12.564322+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Cui et al. - 2020 - Dynamic simulation of urbanization and eco-environment coupling Current knowledge and future prospe.pdf
- Year: unknown
- DOI: 10.1007/s11442-020-1731-x
- OA status: closed
- License: none recorded
- Category: Journal Articles\Review\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This review paper examines how urbanization and eco-environment interactions are dynamically simulated, and how systems science can better capture their complex coupling. The focus is global in scope but emphasizes Chinese cases and urban agglomerations. The authors situate urbanization-environment linkages within several theoretical traditions: human-environment interaction, urban social-ecological systems, complex systems, coupled human and natural systems, and the telecoupling framework that connects distant regions through flows of resources, people, and information.

They conceptualize the urbanization-eco-environment nexus as an open, large-scale, feedback-rich system with non-linear dynamics, thresholds, and phase changes. Methodologically, the review covers system dynamics models, artificial intelligence tools (artificial neural networks and Bayesian networks), land use/land cover change models (CLUE-s, cellular automata, multi-agent systems), and their integrated uses (e.g., SD-GIS, SD-CA, SD-ABM, SD-CLUE-s, hybrid AI methods). These approaches are applied to simulate urban growth, resource use, pollution, ecological vulnerability, and future scenarios, and to support decision-making via emerging interactive decision support systems.

Applications span multiple spatial contexts: individual cities, urban agglomerations, river basins, arid oases, and mountainous regions. Studies typically explore how water, land, terrain, and ecological carrying capacity constrain or are reshaped by urbanization, often revealing S-shaped or inverted-U trajectories in coupling coordination. Multi-element analyses decompose urbanization and environmental subsystems into population, economic, spatial, and ecological components to identify key drivers and constraints.

Regarding telecoupling and metacoupling, the paper explicitly addresses how distant linkages (e.g., inter-basin water transfers, trade, migration) interact with local urban-environment dynamics. It uses the telecoupling framework conceptually and notes a growing but still fragmented literature on cross-regional energy, water, ecological risk, and coordinated regional development. However, the authors argue that most telecoupling work remains qualitative or case-specific, lacks unified quantitative metrics, and is poorly integrated into spatially explicit, multi-scale simulations and practical planning. They call for theoretical integration, better data sharing, model coupling, and intelligent decision support systems to advance sustainable and coordinated urbanization.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong focus on intra-urban, regional (peri), and distant (tele) couplings in urbanization-environment dynamics.

### Intracoupling
#### Systems
- Coupled urbanization-ecoenvironment system within a city or basin
- Urban social-ecological systems and human-environment systems
- Urbanization-resources-environment composite system
#### Flows
- Internal flows of water, land, energy, and pollution within cities
- Information and feedback among population, economy, resources, environment
- Material cycles like emissions, waste, and resource extraction
#### Agents
- Urban residents, firms, and local governments
- City planners and environmental management agencies
- Infrastructure managers and utility companies
#### Causes
- Urban expansion and industrial growth under weak resource constraints
- Policy choices and planning strategies within urban areas
- Population growth and lifestyle driven consumption
#### Effects
- Land conversion, habitat fragmentation, and biodiversity loss
- Air and water pollution, PM2.5, and ecological degradation
- Changes in urban resilience, risk, and carrying capacity

### Pericoupling
#### Systems
- Neighboring cities within urban agglomerations
- Upstream-downstream areas in shared river basins
- Rural-urban fringes and surrounding ecological zones
#### Flows
- Regional water transfers within basins and lakes
- Inter-city energy and resource exchanges in clusters
- Regional pollution dispersion and ecological spillovers
#### Agents
- Provincial and regional coordinating governments
- Intercity economic and planning alliances
- Basin management and environmental agencies
#### Causes
- Regional integration and coordinated development policies
- Shared river systems and ecological interdependence
- Industrial relocation and spatial economic restructuring
#### Effects
- Coordinated or imbalanced regional urbanization patterns
- Shifts in basin water stress and ecosystem health
- Regional synergy or conflict over resources and risks

### Telecoupling
#### Systems
- Distant coupled human-natural systems linked by trade or flows
- Sending and receiving regions in energy or technology trade
- Distant water source regions supplying large cities
#### Flows
- Trade of photovoltaics and other environmental goods
- Long-distance water diversion to megacities
- Cross-border migration, tourism, and information flows
#### Agents
- National governments and international organizations
- Exporters, importers, and multinational firms
- Telecoupling researchers and global governance bodies
#### Causes
- Globalization of markets, population, and information
- Cost advantages and differentiated environmental standards
- Externalizing local environmental pressures to distant systems
#### Effects
- Job and tax gains with displaced emissions in exporters
- Climate mitigation benefits in import regions
- Telecoupled ecological risks and biodiversity impacts

### Cross-Coupling Interactions
- Local urbanization changes propagate through regional and distant resource and pollution networks.
- Telecoupled trade and water transfers reshape local and regional carrying capacities.
- Multi-scale feedbacks link city-level decisions with basin and global environmental outcomes.

### Research Gaps or Limitations
- Foundational theories and cross-scale frameworks remain fragmented and weakly integrated.
- Telecoupling simulations are rarely quantified or systemically unified for spatial synergy.
- Limited cross-scale data sharing and dynamic models for multi-factor, multi-agent interactions.

### Search Keywords
- urbanization eco-environment coupling dynamic simulation telecoupling
- system dynamics LUCC artificial intelligence urban agglomeration
- telecoupling framework coupled human and natural systems

### Extraction Confidence
high
