# Water quality improvements and ecological inertia a basin-wide assessment of ecosystem recovery in

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:21:11.770009+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Zhao et al. - 2025 - Water quality improvements and ecological inertia a basin-wide assessment of ecosystem recovery in.pdf
- Year: unknown
- DOI: 10.1016/j.ecolind.2025.113700
- OA status: gold
- License: cc-by-nc-nd
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This study examines how water quality and aquatic ecosystems have changed across the Yangtze River Basin, China, from a basin-wide perspective, and what this implies for long-term ecological recovery. The geographic scope covers the mainstem, tributaries, and 99 large lakes along the middle and lower reaches of the Yangtze.

The authors work within a coupled human-natural system context, implicitly linked to metacoupling: intensive development, hydrological engineering, fisheries exploitation, and national restoration policies connect upstream-downstream reaches, rivers-lakes, and human activities-ecosystem responses. However, the paper does not explicitly frame its analyses using formal telecoupling/metacoupling terminology, though its conclusions clearly resonate with that perspective.

Using monthly monitoring data (2005-2022) from over 1,000 river sections and 17 lakes, they assess trends in nutrients, organic pollution, and chlorophyll-a. They also integrate satellite-based mapping of aquatic vegetation for 99 lakes (2005-2024), macroinvertebrate surveys for 27 lakes (two periods: 2007-2009 and 2018), long-term benthos records for Lake Taihu, and fish catch data from the upper Yangtze (1998-2022). Statistical methods include linear regressions and mixed-effects models to compare rivers, Yangtze-connected lakes, and hydrologically isolated lakes.

Rivers show strong, widespread improvement in key pollutants, with most sections reaching good national standards by 2022. Lakes respond more slowly and unevenly. Isolated lakes achieve the fastest declines in total nitrogen and organic load, but phosphorus shows little decrease and phytoplankton biomass (chlorophyll-a) rises, especially in closed systems. Trophic state indices for many lakes remain mesotrophic to eutrophic. Macrophyte coverage declines basin-wide, especially in isolated lakes, and macroinvertebrate abundance and richness fall over time. In contrast, the recent fishing ban coincides with partial fish stock recovery in the upper river.

The authors attribute this chemical-biology decoupling to internal nutrient legacies, long water residence times, fragmentation, and climate warming. They argue that effective restoration requires integrated, meta-coupled management that links watershed pollution control, in-lake remediation, and river-lake connectivity, and that uses biological as well as chemical indicators.

## Structured Metacoupling Extraction

### Coupling Classification
- Focuses mainly on intracoupling within Yangtze Basin; hints of peri-coupling via river-lake links.

### Intracoupling
#### Systems
- Yangtze River mainstem and tributaries within the basin
- Connected floodplain lakes like Dongting and Poyang
- Isolated lakes such as Taihu and Chaohu
#### Flows
- Nutrient and organic pollutant transport from human activities into rivers and lakes
- Internal nutrient recycling between lake sediments and overlying water
- Movement of aquatic organisms including fish, macrophytes, macroinvertebrates
#### Agents
- National and local environmental agencies implementing water policies
- Farmers, industries, and urban residents emitting pollutants
- Fisheries sector affected by and responding to fishing bans
#### Causes
- Rapid economic growth, dam building, land reclamation, urbanization since mid twentieth century
- Pollution-control laws, wastewater treatment expansion, fishing ban, river protection law
- Climate warming, extreme droughts, and hydrological alterations
#### Effects
- Improved river water quality but lagging lake ecological recovery
- Lake eutrophication, macrophyte loss, benthic and fish biodiversity decline
- Partial fish stock rebound following basin fishing moratorium

### Pericoupling
#### Systems
- Hydrologically connected Yangtze mainstem and floodplain lakes
- Upstream reservoir cascade and downstream river-lake reaches
- Urban-industrial areas and adjacent rural catchments within basin
#### Flows
- Pollutants and nutrients from inlet rivers into connected lakes
- Hydrological exchange mediating organic matter and sediment fluxes
- Fish and other aquatic species migrating between river and connected lakes
#### Agents
- Dam operators controlling reservoir and flow regimes
- Local governments coordinating cross-county pollution management
- Fishers relocating effort after fishing bans in core reaches
#### Causes
- Dams fragmenting river-lake connections and altering floodplain hydrology
- Administrative pollution targets defined by jurisdictional boundaries
- Land-use changes near lakes increasing nonpoint nutrient inputs
#### Effects
- Connected lakes experience buffered water-quality variability versus isolated lakes
- Disconnection reduces floodplain fish richness and macrophyte stability
- Localized eutrophication hotspots in hydrologically closed lakes

### Telecoupling
#### Systems
- Not identified.
#### Flows
- Not identified.
#### Agents
- Not identified.
#### Causes
- Not identified.
#### Effects
- Not identified.

### Cross-Coupling Interactions
- Same basin-wide policies yield rapid river improvements but slow lake biological recovery
- River-lake disconnection amplifies internal nutrient loading and biodiversity loss in isolated lakes
- Fishing bans interact with past dam impacts to shape fish population trajectories

### Research Gaps or Limitations
- Limited integration of full food-web and multi-taxa indicators into routine assessments
- Insufficient quantification of diffuse agricultural and rural pollution contributions
- Lack of ecosystem-based water-quality thresholds explicitly linking loads to biological states

### Search Keywords
- Yangtze River Basin ecological recovery eutrophication
- internal nutrient loading macrophyte and benthic decline
- dam-induced disconnection fishing ban fish restoration

### Extraction Confidence
high
