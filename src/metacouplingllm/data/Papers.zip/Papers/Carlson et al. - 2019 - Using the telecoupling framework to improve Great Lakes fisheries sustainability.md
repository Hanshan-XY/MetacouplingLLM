# Using the telecoupling framework to improve Great Lakes fisheries sustainability

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:30:52.468166+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Carlson et al. - 2019 - Using the telecoupling framework to improve Great Lakes fisheries sustainability.pdf
- Year: unknown
- DOI: 10.1080/14634988.2019.1668660
- OA status: closed
- License: none recorded
- Category: Journal Articles\Conceptual\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This conceptual paper applies the telecoupling framework to the Great Lakes salmonine fishery to better understand and manage its sustainability. The geographic focus is the Laurentian Great Lakes of North America, with connections to salmon source regions in the U.S. Pacific Northwest and to broader national and international networks of agencies, anglers, and markets. The system context is a coupled human-natural system in which introduced Coho and Chinook salmon support large recreational fisheries and associated lake ecosystems and coastal economies.

Rather than presenting new empirical data, the authors synthesize historical and contemporary literature, management documents, and economic assessments. They map the Great Lakes salmonine fishery onto core telecoupling components: systems (sending, receiving, spillover), flows (fish, money, information, people), agents (agencies, legislatures, anglers, businesses, NGOs, media), causes, and effects.

Key findings are that salmon introductions since the 1960s created extensive long-distance linkages. Biological flows include eggs and smolts shipped from western U.S. hatcheries and subsequent salmon movements among lakes. Financial flows run from legislatures, federal programs, and conservation organizations to hatcheries, management agencies, and tourism-related businesses, supporting multi-billion-dollar recreational and tourism economies. Information flows through professional networks, media, and public communication have amplified demand, guided policy, and attracted research and restoration funding. Telecoupled causes include degraded native fisheries, overabundant alewife, rising leisure time and recreational demand, technological advances in fishing, and shifting political support from commercial to recreational sectors. Effects span altered food webs, disease and genetic risks, enhanced recreational opportunities, regional development, and feedbacks that drive stocking and funding decisions.

The paper is explicitly about telecoupling/metacoupling. It argues that using the telecoupling framework can reveal hidden spillover systems, clarify complex causality, identify leverage points (such as invasive species, climate change, funding structures, and stakeholder behavior), and support more integrative, multiscale governance of Great Lakes fisheries and, by extension, other aquatic systems worldwide.

## Structured Metacoupling Extraction

### Coupling Classification
- Explicit telecoupling case; also covers intra-basin interactions and regional spillovers.

### Intracoupling
#### Systems
- Individual Great Lakes basins and adjacent coastal communities
- State or provincial fisheries sectors within single jurisdictions
#### Flows
- Local fish movements within one lake
- Money cycling among local anglers, businesses, agencies
#### Agents
- State fisheries departments and hatcheries
- Local anglers, charter captains, tourism operators
#### Causes
- Desire for local recreation and tourism income
- Need to control nuisance forage fish locally
#### Effects
- Changed local food webs and predator prey balance
- Growth of lake specific angling and tourism economies

### Pericoupling
#### Systems
- Neighboring Great Lakes and shared watersheds
- Adjacent US states and Canadian provinces around the basin
#### Flows
- Salmon migration between neighboring lakes
- Cross border angler travel and tourism spending
#### Agents
- Multi state and binational fisheries commissions
- Regional tourism businesses and charter fleets
#### Causes
- Physical connectivity among lakes and rivers
- Regional dissemination of stock assessment information
#### Effects
- Spillover catches where fish were not originally stocked
- Distributional conflicts in funding and stocking benefits

### Telecoupling
#### Systems
- Pacific Northwest hatchery regions sending salmon eggs
- Great Lakes states and provinces receiving fish, funds, information
- External funding bodies and global conservation organizations
#### Flows
- Long distance transfers of salmon eggs and smolts
- National program funds and legislative appropriations
- Scientific, management, and media information about the fishery
#### Agents
- Federal agencies and interstate commissions
- Universities, research institutes, extension services
- Nonprofit conservation and angling organizations
#### Causes
- Collapse of native commercial fisheries and lamprey impacts
- Public demand for recreation as incomes and leisure rose
- Availability of surplus salmon eggs in western hatcheries
#### Effects
- Creation of a major recreational salmon fishery and tourism hub
- Large economic benefits and new employment across the basin
- Ecological change, disease spread, genetic and community alterations

### Cross-Coupling Interactions
- Telecoupled funding and information reshape regional stocking and local ecosystem outcomes
- Fish dispersal creates feedback between local management and basin wide predator prey dynamics
- Climate and invasive species telecouplings drive multiscale management adjustments

### Research Gaps or Limitations
- Limited quantitative analysis of spillover systems and indirect beneficiaries
- Incomplete valuation of nonmonetary cultural, social, and psychological benefits
- Scarce modeling of complex feedbacks and surprise dynamics in coupled systems

### Search Keywords
- Great Lakes salmonine telecoupling fisheries governance
- Coho Chinook stocking cross scale social ecological systems
- fish money information flows recreational fishery globalization

### Extraction Confidence
high
