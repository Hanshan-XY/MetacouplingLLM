# Trading Land A Review of Approaches to Accounting for Upstream Land Requirements of Traded Products

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:04:25.086002+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Schaffartzik et al. - 2015 - Trading Land A Review of Approaches to Accounting for Upstream Land Requirements of Traded Products.pdf
- Year: unknown
- DOI: 10.1111/jiec.12258
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Review\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This review examines how to quantify the land used worldwide to produce traded biomass-based goods and services, often called land footprints or upstream land requirements. The focus is global, with particular attention to major producing and consuming countries such as China, the United States, Brazil, and Australia, and to cropland as the primary land-use type considered.

The paper situates the topic within international trade, land-use change, and leakage: policies that protect land or reduce emissions in one country can shift land demand and environmental burdens abroad. This cross-border displacement of land use is a core telecoupling phenomenon. The authors discuss how production-based metrics (used in most international agreements) differ from consumption-based metrics that trace land use along global supply chains to final demand.

Two main methodological families are reviewed. Biophysical factor approaches use physical trade data (tonnes) and country- or product-specific yield factors (tonnes per hectare) to infer the land embodied in traded products. They can be detailed in terms of products and land types, and can incorporate spatially explicit yields, but they suffer from truncation: long and complex supply chains are incompletely captured, and coproduct allocation is challenging.

Economic modeling approaches extend monetary input-output tables with land-use or biomass data (environmentally extended input-output analysis, often in multi-region form). These methods resolve truncation by covering complete economic networks and all intermediate inputs, but are constrained by coarse sector aggregation and the assumption that monetary flows are a good proxy for land use. Differences in prices within sectors or between domestic and export markets can distort land allocations.

The review compares numerical results from representative studies using both approaches. Overall patterns, such as net exports from land-abundant countries and net imports to densely populated countries, are often similar. However, for key economies (notably China and sometimes the United States) the sign and magnitude of net land trade can differ sharply between methods. The authors argue that these are not simply errors but reflect different allocation principles and conceptual meanings.

The paper is explicitly about telecoupling: it analyzes how distant consumption drives land use elsewhere and how different accounting frameworks represent this coupling. It emphasizes that choosing a method is simultaneously a scientific and political decision about how to assign responsibility for global land use.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong focus on telecoupling via global trade in biomass and embodied land use.

### Intracoupling
#### Systems
- National land systems managing cropland, grazing land, forestry, built-up areas.
- Domestic production sectors using land to supply internal final demand.
#### Flows
- Biomass flows from domestic land to national consumers.
- Domestic supply chains linking land use to upstream inputs like machinery lubricants.
#### Agents
- National governments designing land-use and conservation policies.
- Domestic farmers, foresters, and agribusiness companies.
#### Causes
- Domestic consumption patterns and dietary choices.
- National environmental regulations and forest protection laws.
#### Effects
- Local land-use change and forest transition dynamics.
- Domestic greenhouse gas emissions and biodiversity impacts from land use.

### Pericoupling
#### Systems
- Neighboring or regional trading partners sharing biomass markets.
- Transboundary forest and agricultural frontiers in regional blocs.
#### Flows
- Regional biomass and timber trade within continents.
- Cross-border leakage of deforestation and forest harvest.
#### Agents
- Regional trade blocs and policy initiatives like REDD+ implementers.
- Cross-border logging and agricultural enterprises.
#### Causes
- Regional conservation measures shifting production to nearby countries.
- Differences in environmental standards among neighboring states.
#### Effects
- Displacement of forest cover loss within regions like Southeast Asia.
- Regional land-use competition and social conflicts over land.

### Telecoupling
#### Systems
- Consumer countries importing biomass and embodied cropland.
- Producer countries exporting biomass, timber, and bioenergy feedstocks.
- Global trade network linking multiple land systems via supply chains.
#### Flows
- Trade in agricultural commodities, wood, and biomass-based products.
- Embodied or virtual land flows measured as upstream land requirements.
- Monetary trade flows represented in multiregion input-output tables.
#### Agents
- National governments setting trade, climate, and land-use policies.
- International corporations managing global supply chains and sourcing.
- Tourists and foreign consumers driving exported service and food demand.
#### Causes
- Foreign final demand inducing land-use change in distant countries.
- Climate, forest, and bioenergy policies causing land-use leakage abroad.
- Global market incentives favoring export-oriented agricultural expansion.
#### Effects
- Deforestation and agricultural expansion in tropical producer regions.
- Leakage of emissions and land-use pressures from strict to lax jurisdictions.
- Large net imports or exports of embodied cropland for major economies.

### Cross-Coupling Interactions
- Domestic conservation or forest transition often coincides with increased imported deforestation abroad.
- Policies reducing domestic emissions can raise land-use and emissions in distant producer countries.
- Bioenergy demand shifts land from food or forest to energy crops, affecting multiple regions.

### Research Gaps or Limitations
- High uncertainty from differing accounting methods, yields, prices, and trade data quality.
- Biophysical factor approaches face truncation and complex allocation among coproducts.
- Economic IO models suffer from sector aggregation, price heterogeneity, and misallocated land use.

### Search Keywords
- upstream land requirements and trade
- land footprint biophysical and input-output
- telecoupling embodied cropland leakage

### Extraction Confidence
high
