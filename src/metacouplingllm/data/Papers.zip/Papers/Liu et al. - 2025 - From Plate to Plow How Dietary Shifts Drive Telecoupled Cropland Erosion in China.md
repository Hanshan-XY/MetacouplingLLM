# From Plate to Plow: How Dietary Shifts Drive Telecoupled Cropland Erosion in China

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:56:04.898834+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Liu et al. - 2025 - From Plate to Plow How Dietary Shifts Drive Telecoupled Cropland Erosion in China.pdf
- Year: 2025
- DOI: 10.1002/ldr.70123
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This research analyzes how changing diets in China influence soil erosion on cropland through telecoupled production-consumption linkages. The study is explicitly framed within the telecoupling and metacoupling perspective, focusing on interprovincial flows of food and embodied soil loss within China.

Geographically, the work covers all mainland Chinese provinces, distinguishing erosion in ecologically fragile southwest regions from consumption centers in coastal and central provinces. The authors integrate a spatially explicit RUSLE erosivity model (1 km resolution) with a high-sector-resolution environmentally extended multi-regional input-output (EE-MRIO) model for 2017. Agriculture is split into 20 subsectors (detailed crop and livestock categories), enabling attribution of erosion to specific food types and supply chains. Scenario simulations couple population projections for 2030 and 2050 with dietary changes based on China’s 2022 dietary guidelines.

Production-based estimates indicate about 1.8 billion tons of soil loss on cropland in 2017, heavily concentrated in southwestern provinces that have relatively smaller cropland areas but steep terrain and intense rainfall. Cereals dominate national erosion totals, but vegetables, potatoes, and oil crops are major contributors in specific regions. From the consumption perspective, the national footprint is about 1.6 billion tons, with large differences among provinces: affluent, urbanized regions outsource most of their embodied erosion to inland and southwestern production areas. Nearly half of erosion is driven by indirect and induced demand along supply chains, not just direct household food purchases.

Scenario analysis shows that demographic change alone modestly alters erosion, whereas shifting diets toward more tubers, vegetables, fruits, animal products, and dairy substantially restructures erosion drivers and can significantly increase total soil loss. The paper concludes that telecoupled erosion risks require coordinated, cross-regional governance combining spatially differentiated dietary and trade policies with targeted conservation investments in erosion-prone source regions.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong intracoupling in Chinese cropland management and erosion processes
- Pronounced pericoupling via interprovincial agri-food trade and erosion transfers
- Clear telecoupling between distant consumer provinces and remote erosion hotspots

### Intracoupling
#### Systems
- Chinese cropland ecosystems and soil systems
- National food production and dietary demand system
- Provincial agricultural subsectors and land management
#### Flows
- Soil loss from water-driven erosion on cropland
- Embedded erosion in domestic food supply chains
- Shifts in crop composition driven by diet change
#### Agents
- Chinese farmers and agricultural producers
- Provincial and national policymakers
- Food processing and distribution enterprises
#### Causes
- Rainfall erosivity, slope and soil erodibility factors
- Dietary transition toward potatoes, vegetables, fruits, animal products
- Agricultural practices and limited conservation measures
#### Effects
- High national cropland erosion volumes and hotspots
- Reduced land productivity and food security risks
- Changing sectoral erosion responsibility across crops

### Pericoupling
#### Systems
- Neighboring Chinese provinces linked by food trade
- Southwestern erosion-prone regions and coastal demand centers
- Loess and karst farming areas and adjacent urban markets
#### Flows
- Interprovincial transfer of embodied soil erosion
- Virtual topsoil exports from fragile uplands to cities
- Food commodities moving along regional supply chains
#### Agents
- Provincial governments managing ecological compensation
- Interprovincial traders and logistics firms
- Regional planning and taxation authorities
#### Causes
- Regional dietary demand differences and income disparities
- Industrial structure and location of food processing hubs
- Ecological compensation and fiscal policy design
#### Effects
- Concentration of erosion in southwestern provinces
- Erosion outsourcing by developed provinces to poorer regions
- Mismatch between erosion intensity and transfer magnitude

### Telecoupling
#### Systems
- Ecologically fragile southwestern croplands supplying wider China
- Coastal megacities with highly externalized erosion footprints
- Pastoral regions producing livestock, dairy, eggs for distant consumers
#### Flows
- Telecoupled soil erosion embodied in long-distance food flows
- Net erosion imports into megacities like Beijing and Shanghai
- Export of erosion from karst and loess zones to affluent consumers
#### Agents
- Urban consumers shifting toward guideline-based diets
- National agencies designing dietary and agricultural policies
- Firms integrated in multi-regional food value chains
#### Causes
- Dietary guidelines promoting more horticulture and animal products
- Economic globalization and complex agri-food networks
- Population and income growth in distant urban regions
#### Effects
- Spatial decoupling between erosion sources and beneficiaries
- Telecoupled governance needs for virtual topsoil accounting
- Heightened erosion pressure on already vulnerable landscapes

### Cross-Coupling Interactions
- Dietary shifts simultaneously reshape local erosion and telecoupled erosion flows
- Population change modulates but does not dominate telecoupled erosion dynamics
- Agricultural modernization interacts with trade networks to redistribute erosion burdens

### Research Gaps or Limitations
- Static MRIO and land use representation omit future structural production changes
- RUSLE and EE-MRIO uncertainties under extreme rainfall and technological progress
- Limited treatment of policy, market, and technological interactions with dietary change

### Search Keywords
- telecoupled cropland soil erosion China
- dietary transition EE-MRIO RUSLE
- interprovincial virtual topsoil trade

### Extraction Confidence
high
