LETTER • OPEN ACCESS

Perspectives on tipping points in integrated models of the natural and human Earth system: cascading effects and telecoupling

To cite this article: Christian L E Franzke et al 2022 Environ. Res. Lett. 17 015004

View the article online for updates and enhancements.

# You may also like

Off-stage ecosystem service burdens: Ablind spot for global sustainability Unai Pascual, Ignacio Palomo, William M Adams et al.   
Critical minerals for electric vehicles: atelecoupling review Datu Buyung Agusdinata, Hallie Eakin and Wenjuan Liu   
Globalization’s unexpected impact onsoybean production in South America: linkages between preferences for nongenetically modified crops, ecocertifications, and land use Rachael D Garrett, Ximena Rueda and Eric F Lambin

![](images/1bafdd8852d18a1b9257e86c1c6fa81fd9ecdf5e7208dedbc9f908920de9151a.jpg)

![](images/cf0e136a9feb8a41ef7d1db34bfb6b82b483bd768bcfac8274859c362171f253.jpg)

# ENVIRONMENTAL RESEARCH

LETTERS

![](images/74b851f3e8903772cdfa575a71486903007740099fc0afdf5586d916604953d8.jpg)

CrossMark

# OPEN ACCESS

# LETTER

# Perspectives on tipping points in integrated models of the natural and human Earth system: cascading effects and telecoupling

RECEIVED

14 October 2021

REVISED

28 November 2021

ACCEPTED FOR PUBLICATION

14 December 2021

PUBLISHED

5 January 2022

Original content from this work may be used under the terms of the Creative Commons Attribution 4.0 licence.

Any further distribution of this work must maintain attribution to the author(s) and the title of the work, journal citation and DOI.

![](images/da41b4cf50aa0d2f854a1c5670023155ea24810c696cd39f0f8c96530f83a3a9.jpg)

Christian L E Franzke $^ { 1 , 2 , * } \oplus$ , Alessio Ciullo3, Elisabeth A Gilmore $^ 4 \oplus$ , Denise Margaret Matias5,6, Nidhi Nagabhatla7, Anton Orlov8, Shona K Paterson9, Jürgen Scheffran $^ { 1 0 } \oplus$ and Jana Sillmann8

1 Center for Climate Physics, Institute for Basic Science, Busan, Republic of Korea   
2 Pusan National University, Busan, Republic of Korea   
3 Institute for Environmental Decisions, ETH, Zurich, Switzerland   
4 Department of International Development, Community and Environment, Clark University, Worcester, United States of America   
5 Eberswalde University for Sustainable Development, Eberswalde, Germany   
6 Center for Development Research, University of Bonn, Bonn, Germany   
7 United Nations University, Institute on Comparative Regional Integration Studies (UNU CRIS), Brugge, Belgium   
8 CICERO Center for International Climate Research, Oslo, Norway   
9 College of Business, Arts and Social Sciences, Brunel University London, Uxbridge, United Kingdom   
10 Institute for Geography, University of Hamburg, Hamburg, Germany   
∗ Author to whom any correspondence should be addressed.

E-mail: christian.franzke@pusan.ac.kr

Keywords: tipping points, cascading effects, coupling of natural and human Earth systems, telecoupling, extreme events

# Abstract

The Earth system and the human system are intrinsically linked. Anthropogenic greenhouse gas emissions have led to the climate crisis, which is causing unprecedented extreme events and could trigger Earth system tipping elements. Physical and social forces can lead to tipping points and cascading effects via feedbacks and telecoupling, but the current generation of climate-economy models do not generally take account of these interactions and feedbacks. Here, we show the importance of the interplay between human societies and Earth systems in creating tipping points and cascading effects and the way they in turn affect sustainability and security. The lack of modeling of these links can lead to an underestimation of climate and societal risks as well as how societal tipping points can be harnessed to moderate physical impacts. This calls for the systematic development of models for a better integration and understanding of Earth and human systems at different spatial and temporal scales, specifically those that enable decision-making to reduce the likelihood of crossing local or global tipping points.

# 1. Introduction

Tipping points (Lenton et al 2008)—ecological, climatological and social—are fundamental concepts within the Intergovernmental Panel on Climate Change (IPCC) reports (Masson-Delmotte et al 2018, IPCC 2021) and the Planetary Boundaries framework (Rockström et al 2009, Steffen et al 2015). It is frequently highlighted that crossing identified tipping points presents severe risks and would result in widespread and irreversible impacts (Steffen et al 2018, Otto et al 2020).

The concept of tipping points, however, has a longer history. Tipping points were applied earlier in other sciences to describe processes of how communities become racially segregated (Grodzins 1957,

Schelling 1971). This conceptualization suggested that even a relatively small fraction of non-whites could ‘tip’ a neighborhood to a racially completely different setting (Schelling 1971), with the tipping point being the threshold at which this happens. Although the results of this model are not fully supported by empirical evidence (Easterly 2009), Schelling’s framing remains popular in both academic and public discourses. Gladwell (2000) elaborated the concept for a general audience to explain the concept of tipping points and how individual behavior may lead to a ‘critical mass, threshold or boiling point’ that results in large changes in society.

Natural and human systems, from large-scale climate systems to local ecosystems and communities, can behave in complex ways, including abrupt

changes and threshold behavior. This neutral and relatively value-free definition can be contrasted with the use of tipping point by the climate science community. Within the climate change discourse, James Hansen’s use of the phrase ‘climate tipping point’ in 1988 in a statement to the US Congress was understood as suggesting an imminent threat through which gradual changes in radiative forcing could trigger abrupt and large-scale changes in the climate system (Hansen 2008). Thus, a tipping point in the climate change discourse has been largely used to invoke changes that are ‘abrupt, non-linear, irreversible, and dangerous to humans and other species’ (Russill 2015) and has been used to focus attention and foster support for urgent action. In this sense, climate tipping points have become a metaphor (Van der Hel et al 2018) for translating climate science into policy discourse, especially to draw attention to large risks due to crossing thresholds leading to abrupt shifts that cannot be well bounded by the existing climatic record such that we may want to avoid them or dedicate resources and planning to manage those that cannot be mitigated (Russill 2015). This shift to a risk management, rather than a costbenefit approach that has dominated the policy discussion, has gained widespread support in recognition of the potential for large-scale disruptions that may be poorly captured in existing models (Stoerk et al 2018). Thus, to some extent, the ‘tipping point’ metaphor has been effective. However, using tipping points in a more actionable sense to support ‘never to exceed’ targets, however, shows less promise (Dudney and Suding 2020), suggesting that the link between tipping points and action will remain a more complex interplay between science and societal values of risk.

In Earth system science tipping points largely have a negative connotation, indicating a change which will negatively impact on society and ecosystems. In social science, they can also have a positive meaning, where societal tipping points can prompt transformations that can drive climate action (T`abara et al 2018). In the context of climate change policy, positive social tipping points leading to sustainable transformation have been referred to as beneficial and increase societal resilience by reducing climate change loss and damage through mitigation and adaptation (Kopp et al 2016). Positive social tipping points, therefore, stand to benefit from early intervention and spreading processes in complex social networks, such as arresting contagious dynamics observed in epidemiology that lead to irreversible and uncontainable positive behavior (Otto et al 2020).

This makes a transdisciplinary approach necessary to evaluate the interplay between human society and environmental systems that may lead to the crossing of tipping points, the types of outcomes that include cascading effects and compound extremes which in turn may affect sustainability and security

that are related to tipping points, and models and approaches to identify and moderate these outcomes. Here we critically discuss these issues by focusing on understanding interlinkages and interactions in tipping point settings. First, we review the use of tipping points across disciplines and elaborate on an example of these interlinkages of physical tipping points with cascading effects into socioeconomic systems in the Lake Chad region. We then discuss the current state of climate-economy models and their treatment of tipping points and the need for integrated models which can capture tipping points and cascading effects in the coupled natural and human Earth system. Finally, we consider how early warning systems and governance approaches can moderate the risks from tipping points. We conclude with an outlook for next steps for our understanding and modeling of tipping points.

# 2. Tipping points from a mathematical and social science perspective

From a mathematical perspective, tipping points are most easily understood as bifurcations. A bifurcation is a qualitative change for a smooth change in a control parameter in the structure of fixed points, periodic orbits or limit cycles of a dynamical system which can be either attracting or repelling; Dijkstra (2013) provides a basic introduction. If a system is stable, then despite a perturbation it would return or remain close to its original state. If it is unstable then even small perturbations can lead the system to move to another attracting state. Hence, a small change in the control parameter can lead to a major qualitative change (Scheffer et al 2009, Lenton 2011). Furthermore, in dynamical systems theory tipping points can be seen as ‘any situation where accelerating change caused by positive feedback drives the system to a new state’ (van Nes et al 2016). Various tipping indicators for early warning have been developed and validated mainly on paleoclimate data or for ecosystems (Scheffer et al 2009, 2012, Lenton 2011, 2013, Milkoreit et al 2018). In physics, this phenomenon is called a phase transition, or critical phenomenon, whereby crossing a threshold of a tipping point leads the state of the system to change its properties, e.g. going from a solid to a liquid state (e.g. Sornette 2006). This definition is neutral and valuefree and reflects the fact that the Earth system can behave in complex ways including abrupt changes and threshold behavior.

From a social science perspective, tipping points are defined as a form of ‘social change whereby a small change can shift a sensitive social system into a qualitatively different state due to strongly selfamplifying feedback mechanisms’ (Winkelmann et al 2022). These self-amplifying feedback mechanisms make the system unstable so that it can tip to a new stable state. This definition is on a conceptual

level similar to the mathematical one. However, social tipping point as a term is a boundary object that has taken on multiple meanings; it could have a negative connotation such as financial market crashes, economic crisis or anti-democratic political revolutions or it could also have a positive connotation such as contagious processes of rapidly spreading climatefriendly technologies and social norms (Milkoreit et al 2018, T`abara et al 2018, Fisher 2019, Otto et al 2020). Furthermore, it needs to be seen how useful the mathematical definition is for social systems.

Centola et al (2018) show evidence for tipping behavior in social systems to change a majority opinion in the presence of a determined minority. If the minority reaches about $2 5 \%$ , a tipping point can be crossed. On the other hand, O’Brien (2020) discusses the psychology of tipping. Humans behave asymmetrically; we tip easier into a negative than a positive direction (‘good luck runs out, while bad luck stays’). How this could be used in crisis situations and can be implemented in models needs to be better understood, especially how societal tipping points can be harnessed and induced to generate transformations for climate action.

# 3. Tipping points, cascading effects and telecoupling

While climate action may be supported by generating positive feedbacks in societal systems, the physical impacts of climate change may undermine socioeconomic conditions. Tipping points can emerge from ‘risk multiplier’ mechanisms, such as the one associated with climate change triggering economic and social losses which cascade across regions and amplify other societal problems. Indeed, climate-related hazards (such as storms, floods, and droughts) cause local disasters and endanger the health of affected people, both in developing countries and industrialized countries (Franzke and Torello I Sentelles 2020, Eckstein et al 2021, NOAA 2021). These local areas, however, often act as hot-spots, and local impacts propagate to other areas and societies causing among others supply-chain interruptions (e.g. Haraguchi and Lall 2015, Franzke 2017) and food insecurity (Gaupp et al 2019, Naqvi et al 2020). Furthermore, local impacts can act as a trigger and amplifier of other social problems via telecoupling (Liu et al 2013, 2019, Kapsar et al 2019). This latter effect includes poverty and political instability (Helbing 2013, Kelman 2020, World Economic Forum 2021), and likely occurs where economies are climatesensitive (e.g. agriculture) and where the infrastructure is exposed to climate change (e.g. coastal areas, river basins).

To make things concrete, we now discuss one hot-spot and how it is affected by tipping points and cascading effects, and which is representative of the complexity of the Earth system and human

system interactions and cascading effects we are concerned about here. The Sahel region and, in particular, the Lake Chad Basin has been a research and development puzzle (Nagabhatla et al 2021). The Lake Chad Basin constitutes not only a complex environmental system but also has challenging socio-economic and socio-cultural settings that have a significant impact on regional security and sustainability, as the Lake Chad Basin provides livelihood for more than 30 million people (Leblanc et al 2007). The Lake Chad Basin has undergone significant changes over the last few decades (Nagabhatla and Brahmbhatt 2020, Pham-Duc et al 2020) (figure 1). These changes have had an impact on water availability and quality due to increased salinity. Furthermore, the regional geopolitical dynamics, socio-economic structures and political stability is threatened by multiple crises and conflicts, which can be partly attributed to resource scarcity (Nagabhatla et al 2021). Overall, this hydrological disaster triggered a massive humanitarian response worldwide and provides a storyline on tipping points (Skah and Lyammouri 2020). In particular, the cross-border arrangement to water sharing is a mix of customary norms and statenegotiated policy mechanisms. In such complicated settings, a small trigger can lead to big consequences. For instance, the decrease in surface area of Lake Chad for nearly 50 years is a classic case of thresholdcrossing that has not only influenced the regional dynamics of water sharing, but also influenced the socio-economic and security situation. Many studies have linked the rise of Boko Haram, a terrorist group, to the Lake Chad crisis (e.g. Connor 2017, Piesse 2017, Nagarajan et al 2018). A recent synthesis by Magrin and De Montclos (2018) discusses the environmental, economic, and political interactions and their cascading effects. Building on the concept of tipping points, examination of Lake Chad reflects the difficulty to explain or forecast the multifaceted impacts of abrupt and sometimes irreversible change, and how they pose considerable challenges to policy makers, communities and institutions trying to balance the needs and priorities of human well-being and ecological sustainability. In the case of the Lake Chad region the tipping point narrative also opens the opportunity for the discussion of the regional integration of the sustainability agenda wherein interventions like inter-basin water transfer are placed as a solution to mitigate the water crisis (Sayan et al 2020).

As the example shows, climate change and unsustainable resource management can affect the sustainability of natural resources, which can increase vulnerability. If people cannot cope with the consequences and limit the risks, generally through robust institutions, instability and conflict is more likely (e.g. Buhaug and Uexkull 2021, IMCCS 2021). In these cases, there may be further adverse impacts, including additional overexploitation of resources, low agency migration (McLeman et al 2021) or the

![](images/c4a9fe9789fb80be52912a7a2ca0055e72bfdc51706f4c4958339b7a52e2c64e.jpg)

![](images/3ca059ac4c8f6325c5ee19f544e2a0724c2b11c5f4adcd563aa1348e8b368583.jpg)

![](images/5bdc853c00e03791714dfd9672eaa895fd03a0b6e62210465458131aca97bf8b.jpg)

![](images/8008936199b264d99801701e61ddf672ecf7c646df835e6c83c7628e469dde68.jpg)

![](images/4f69277224b92417dc22e88ca34123009ee7c99be1add280688cd3c77f283fe8.jpg)

![](images/c23fc18b16d89aa5b49cad8e08b70688eb0bb4a0c5ec0727a3d4c30c4253067d.jpg)

![](images/29a480bb8b941c3a13c5ef37d2149639a5ca537e2ee23023fd006c1cc0e917d8.jpg)  
Water Body

![](images/d91866edcd95eaa44702c20fa713406297dba109029edbeefb5016cb76c5d6ec.jpg)  
Vegetation

![](images/ecdae5e15bee88923c3ea5ea38b8bcd7dd37af96b4d6421d2dc790042aa03fe0.jpg)  
International Boundary   
Figure 1. Changes in vegetation cover spread $( \mathrm { k m } ^ { 2 } )$ ) at lake Chad. Reproduced from Nagabhatla and Brahmbhatt (2020). CC BY 4.0.

prolongation of violence or conflict in areas that are already experiencing conflict (Kamta et al 2021). Furthermore, land scarcity can affect the availability of water and lead to crop losses. An example of telecoupling is that major droughts in crop producing areas can lead to a rise in food prices elsewhere due to the global food marketplace. This shows that local disasters can have significant impacts elsewhere by cascading through globally linked networks. This needs to be considered, as expressed in the nexus of water, energy, and food, the complex relationship between climate and migration, the compounding effect of conflict in areas that are especially vulnerable to climate change, scale linkages and conflict-cooperation transitions, tipping points, compound effects and cascading events. A possible set of interactions, tipping points, cascading effects and telecoupling are schematically represented in figure 2 (Note that these interactions are indicative only). Examples of vulnerable regional crisis hot-spots are in the Mediterranean region, Sahel Zone, Middle East and South Asia (e.g. Brauch et al 2016, Fitton et al 2019, Rodriguez Lopez et al 2019).

# 4. Modeling the socio-economic impact of tipping points

Given the importance of these interactions for climate risk and climate action, it motivates the development of enhanced models to better quantify these effects. Modeling climate impacts and damages in largescale Integrated Assessment Models (IAM), that were

designed primarily to evaluate climate mitigation pathways and costs, is challenging. Currently, many (IAM), such as DICE (Nordhaus 2018), FUND (Waldhof et al 2014) and REMIND (Leimbach et al 2010), represent the impact of economic activities on climate in the form of greenhouse gas emissions and the impact of climate change on the economy in the form of economic damage functions. These functions do not generally incorporate these non-linearities or feedbacks which could result in substantial damages if properly accounted for (Dietz et al 2021).

Such damage functions broadly fall into two categories: economic and biophysical damage functions. The former ones are derived from econometric models, which empirically estimate the causal effects between changes in climate variables (e.g. temperature and precipitation) and economic outcomes, e.g. Gross Domestic Product (GDP) (Burke et al 2018, Pretis et al 2018). Econometric models are rooted in empirical evidence based on observations, but do not explicitly reveal the transmission channels of climate impacts. Biophysical damage functions (e.g. Piontek et al 2021) estimate the relationship between climate and biophysical variables (e.g. effects of temperature changes on crop yields, worker productivity, and health). This type of damage function is used in process-based IAMs, Input-Output (IO) and Computable General Equilibrium (CGE) models to provide an economic valuation of climate impacts. Compared to econometric models, multi-region multi-sector IAMs, IO, and CGE models can explicitly incorporate the transmission

![](images/a1e44eb341f2940708484b7156d5e1945a8b5f0e7665aad7f56287f1a6ae217d.jpg)  
Figure 2. Schematic of some possible interactions and cascading effects between the Earth system and the Human system. In the world map, major large scale tipping elements are indicated. More localized tipping points, once they tip, have biophysical impacts on ecosystems, water and food security. Via this pathway they can cascade further into the human system inducing economic and social responses and potentially tip some social subsystems into a different state; though not all social subsystems have tipping points and the interactions in the social system are more complex than shown here. The responses of the Human system then can increase or mitigate global warming and, thus, potentially affect further tipping elements via positive or negative feedbacks. Only some possible responses are displayed; however, many more responses and interactions are likely. The far-reaching implications of tipping points are further highlighted through the Sustainable Development Goals (SDGs).

channels of climate impacts and reveal cross-regional and cross-sectoral interactions. In large-scale IAMs, economic impact assessments are typically based on damage functions that are calibrated using global or regional mean temperatures and global mean sea level rise (Diaz and Moore 2017). There are economic impact studies, where biophysical impacts are derived from climate projections with a high spatiotemporal resolution, but the impacts are typically averaged and smoothed out to capture the longterm trends, thereby leaving out the impacts of variability (Orlov et al 2019). Thus, global economic models estimate primarily the economic responses to long-term effects of climate change, while the effects of climate extremes remain poorly represented. However, a growing body of research reveals that the frequency and intensity of climate extremes will likely increase with global warming (Brown 2020, Perkins-Kirkpatrick and Lewis 2020, IPCC 2021) with a related risk of potential compound events and multiple breadbasket failures (Zscheischler et al 2018, 2020, Gaupp et al 2019, Wang et al 2021a, 2021b). In this context, the risk of tipping points is of huge concern (Lenton et al 2019).

Although growing scientific evidence predicts more severe and frequent climate extremes, the estimates of the regional changes in their magnitude and frequency are highly uncertain (van der Wiel and Bintanja 2021). Economic and biophysical damage functions, which are derived using historical observations and extrapolated using future climate projections, might fall short in accurately estimating potential climate damages. An impact assessment of potential tipping points is even more challenging due to a lack of observations. Therefore, the estimates of economic damages from catastrophic events are typically based on expert judgement (Cai et al 2015). In that regard, a lack of data and uncertainties associated with climate extremes poses a big challenge to economic and societal impact assessments.

Furthermore, incorporating biophysical shocks into economic modelling is associated with several other challenges. The curse of dimensionality implies a trade-off between the spatio-temporal scale and coherence of economic models. The treatment of space and time are two challenging aspects for economic modelling of climate extremes and tipping

points (Okuyama 2007). Climate extremes could be very localized and occur in a short period of time. Even though socio-economic consequences of climate extremes might be moderate from a largescale perspective, they could impose an existential threat to the livelihood of local communities and individuals. For example, many smallholder farms in poor countries are subsistence-oriented, disconnected from food markets, and receive little or no financial support, and therefore, might be especially vulnerable to adverse changes in weather conditions. Impacts on such groups cannot be directly derived from large-scale economic models (Aaheim et al 2021). To provide more insights into climate-induced changes in behavior and interactions among individuals and institutions, Agent Based Models (ABMs) are used (Czupryna et al 2020, Naqvi et al 2020).

Moreover, political and social responses and interactions to climate and environmental changes are currently not fully represented in most economic models. The human sphere typically consists of the energy sector and land-use in order to compute optimal mitigation pathways. Promising approaches to model political and social responses, include social dynamics (Castellano et al 2009), Earth system economics (Galbraith 2021) and big data approaches applied to social data.

# 5. Early warning systems: vital for decision support and beyond

When developing plans and policies, it is crucial that negative tipping points are not crossed and that the implemented plan adapts to changes in a way that it continuous to perform satisfactorily under changing conditions. This is accomplished by implementing monitoring and early warning systems (EWS) which indicate and signal when tipping points are being reached (van Ginkel et al 2020). For example, adaptive planning approaches, such as the Dynamic Adaptation Policy Pathways (DAAP) (Haasnoot et al 2013), support the development of adaptive plans which allows taking actions and changing measures before crossing a tipping point. As such, DAAP is a proactive decision support method, where decisions are taken to prevent, and not to respond to, critical changes. DAAP accomplishes this by employing an EWS with the goal of detecting signals of future changes before these occur.

While EWS have been developed to predict tipping points of natural phenomena, it has so far been challenging to implement them in the context of social tipping points (Grimm and Schneider 2011). For example, it has been argued that EWS in time series provide testable predictions for natural or mechanistic systems but not for social systems (Bentley et al 2014). Instead, Bentley et al (2014) suggest focusing more attention on probabilistic insights from collective social dynamics such

as heterogeneity, connectivity, and individual-based thresholds.

The challenges of using EWS to prevent social tipping points can be elaborated through the conflict in Syria. Before the Syrian uprising, that began in 2011, the greater Fertile Crescent region (of which Syria is part of) experienced the most severe drought in the instrumental record (Kelley et al 2015). The role of this drought on the subsequent political unrest which precipitated the ongoing violent conflict in Syria, however, remains contested (Gleick 2014, Selby et al 2017, Ide 2018). In one interpretation, the drought is attributed to the political uprising by an influx of farmers into the capital who had lost their livelihoods which aggravated existing tensions related to economic conditions and services. Reviewing the evidence for each of these links, Ide (2018) concludes that that large economic losses to the agricultural sector and the resulting rural to urban migration are supported but still contested. Whether the economic losses or the migration played a role in the observed urban unrest, however, is poorly understood (Ide 2018). By contrast, political factors such as the ongoing repression and the severity of the response by the regime are more clearly associated with the protests and the escalation (Selby et al 2017). The competing claims are an indicator that compounding effects and tipping points in both natural and social processes preclude simple statements on the dominant or even single causal mechanisms in the Syrian case. In such cases, an EWS would need to recognize these multi-dimensional drivers that underpin the complex interaction of conflict risks and climate risks (Hegre et al 2019, Mach et al 2019). Creating an EWS that is equally sensitive to both social and natural tipping points is, therefore, necessary for decision support in complex situations.

Grimm and Schneider (2011) enumerate four conditions for successful EWS of social tipping points:

(a) the systematic collection of event data and expert assessments;   
(b) the analysis of data based on advanced social science techniques;   
(c) development of strategic response scenarios and consequence assessments;   
(d) unbiased, impartial, and independent presentation of policy and implementation options to policymakers.

Generally, EWS should be considered within the context of identifying and avoiding negative physical and social tipping points. However, there may also be benefits to identifying early warning signals along pathways that aim for positive change to avert inequitable outcomes or traps that may forestall future progress such as lock-in effects (e.g. Haasnoot et al 2019).

# 6. Governance in the presence of tipping points

While physical tipping points have become more widely used in the literature, there is a long-standing and growing critique of the concept especially when considering the Planetary Boundaries framework from a social construction perspective. Planetary Boundaries, when initially conceived, ignored global inequality and social justice (Biermann and Kim 2020), instead framed tipping points as the extent to which the global human society could impact natural processes (Rockström et al 2009). Society faces immediate, persistent and pervasive choices about how to reduce the risks and vulnerabilities associated not only with intractable challenges to our resilience, such as climate change, but also potential tipping’s in societal functioning that could lock-in inequalities and inequities (Adger et al 2018, Thomas et al 2019).

The usability of frameworks such as Planetary Boundaries therefore become implausible from a societal and policy perspective unless translated through a governance lens (van Ginkel et al 2020). This reality identifies a very real need for political processes and institutions that properly detect, analyze, and debate continual change to existing biophysical and social landscapes and then mitigate and adapt in the face of this change.

The implementation of policy action is driven by the values and priorities of society. Collective action, at all scales, in the face of change is strongly dependent on interactions and information flows between individuals and groups due to reciprocity and exchange. The mechanism and degree of knowledge transfer is equally, if not more, paramount for sustainability efforts since that engagement process will determine the degree of knowledge and information available for transfer. This centers the reality of social tipping points around both governance and social justice, a reality that acknowledges uncertainties associated with the response capabilities and adaptive capacities of both social and natural systems (Adger et al 2017, Patterson et al 2018, Thomas et al 2019).

Tipping points becoming synonymous with climate risks may also pose challenges for describing social systems and may promote misunderstanding about the impact of physical climatic changes on social systems. There is no reason to believe that an abrupt change in a physical or environmental condition would correspond to a similar abrupt change in a human system—or that a gradual environmental change may not lead to a more sudden change in a human system (Bentley et al 2014). For example, Kopp et al (2016) draw critical distinctions between shocks that are experienced in economic systems and threshold behavior that may be observed in climate or societal interactions, recognizing that economic shocks may arise due to tipping elements, gradual change as well as non-climatic

triggers. Human systems can also exhibit behaviors that are much more complex than suggested by the physical tipping point model. This type of more complex relationship was recently shown in Bell et al (2021), where contrary to expectations, individuals would continue to populate coastal areas due to their economic, social, and cultural capital even as the climate risks increase due to sea-level rise (Bell et al 2021).

To prevent destabilizing tipping points, adequate governance is needed which anticipates and avoids hazardous pathways so that we can stay within the planetary boundaries. To contain systemic risks, a challenge is to develop adaptive governance approaches at multiple institutional levels that assess the underlying complex mechanisms and induce positive social tipping points, facilitating a transformation to more resilience, sustainability and peacebuilding (Brauch et al 2016). The stability of cooperation or conflict is unclear when escalation occurs, especially in the presence of climate change. Whether climate stress facilitates a cycle of cooperation, or a cycle of conflict, or other shifts between cooperation and conflict, depends ultimately on the societal response.

# 7. Outlook

Our discussion reveals an urgent need for the development of integrated Human-Earth System models which contain or can reasonably well represent tipping points and cascading effects and for more interdisciplinary research in this area. The Lake Chad Basin situation demonstrates how hydro-meteorological variability and climate change dynamics play in tandem to generate manifold tipping points and potential cascading effect settings acting along with social, cultural, and political elements and, thus, creating cascading effects between the environment and society which cannot be separately dealt with. There is also paleodata evidence for cascading effects propagating from the climate system to ecosystems and societies leading to societal collapses or transformations (Brovkin et al 2021). This calls for more rigorous interdisciplinary and transdisciplinary research on integrated natural and human Earth System tipping points and cascading effects and more causal link studies. Integrated natural and human Earth system models will be better able to support decision making (Lempert et al 2009, Haasnoot et al 2013, Kasprzyk et al 2013). However, the complexity of Integrated natural and human Earth System modelling might come at a cost of their interpretability and practical usefulness. Therefore, a stronger stakeholder engagement might be needed when designing modelling interfaces and scenarios.

Such integrated models should also include social equity and social justice mechanisms. This seems to be a pressing issue since inequality is currently fixed in Integrated Assessment Models in the form of Negishi

welfare weights (Stanton 2011, Rao et al 2017). The emerging scholarship on policies addressing tipping point settings is promising. For instance, the work of Moser and Rodgers (2012) in urban landscapes and urban conflicts integrates the dimensions of political economy, power dynamics and distribution within a society as underlying factors of urban tipping points.

Tipping points in social systems also need to be better understood in order to detect their presence and allow early interventions. In physical climate science and ecology, tipping points are nowadays a rigorous mathematical concept with potentially predictive skills. In social climate science, tipping points may at times seem to be still more like a metaphor (Van der Hel et al 2018). For example, Lenton (2020) discusses cascading tipping points and how to use tipping points to start positive change. This requires process understanding, which might be difficult for social systems to achieve, but attitude change might be possible.

Sustainable and adaptive governance approaches include mitigation, adaptation, the building of social networks, disaster management, and conflict resolution. To meet the temperature limit of $1 . 5 ~ ^ { \circ } \mathrm { C }$ or $2 ^ { \circ } C$ according to the 2015 Paris agreement, an anticipative policy framework will be necessary to avoid perilous pathways, and which allows for a systemic transformation towards self-organized stabilization. Early warning systems can build on measuring sensitivity, including criteria for instability, thresholds for transitions, factors of criticality and control mechanisms to facilitate transformation across tipping points. These can be incorporated into integrated modeling of human-environment interaction and dynamic social tipping processes, using agent-based modeling (behavioral rules) and social network analysis (spread of cascading events). Improving the cross-scale modelling integration (i.e. global vs. local) is needed to better represent the impacts of cascading effects on most vulnerable groups. This might be achieved by coupled climate models, global large-scale economic models, which capture cross-sectoral and cross-regional dependencies and micro-economic ABM modelling, which better depict heterogeneity and interactions in the human system at a local scale.

Tipping points as an organizing concept, as a way of bringing the potential for large, potentially catastrophic risks from climate change to the attention of policymakers, have shown some success. Continuing improvements in the assessment and communication of these risks to both physical and human systems are very much needed (Simpson et al 2021) together with interdisciplinary research and knowledge exchange.

