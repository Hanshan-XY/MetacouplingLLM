# Efficiency analysis of metacoupling of water transfer based on the parallel data envelopment analysi

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:06:30.866258+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Su and Chen - 2021 - Efficiency analysis of metacoupling of water transfer based on the parallel data envelopment analysi.pdf
- Year: unknown
- DOI: 10.1016/j.jclepro.2021.127952
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper develops a quantitative framework to evaluate how a large inter-basin water transfer project performs as a metacoupled system, using the Middle Route of China’s South-North Water Transfer Project (SNWTP-MR) as a case. The project links water-rich central China with water-scarce northern cities including Beijing, Tianjin, Hebei, and Henan.

The authors explicitly apply Liu’s metacoupling concept. They divide the system into three interacting subsystems: intracoupling (water source region around Danjiangkou Reservoir), pericoupling (downstream areas of the source basin), and telecoupling (distant northern receiving regions). For each subsystem they design an indicator set capturing economic, social, and ecological outcomes, distinguishing desired (e.g., agricultural and industrial output, GDP per capita, sewage treatment, reclaimed water use) from undesired outputs (e.g., COD emissions, disaster losses, household water use, water-control expenditures).

Using statistical yearbooks and provincial water bulletins for 2015-2019, they build an input-output dataset that includes both local water use and transferred water volumes. They then apply a parallel, input-oriented data envelopment analysis (DEA) model with a super-efficiency extension. This allows separate efficiency scores for each subsystem and a weighted overall efficiency index, and it treats unwanted outputs via linear transformation. The parallel structure breaks open the typical DEA black box and links subsystem efficiencies to overall performance, while allowing simulated reallocations of transferred water among subsystems.

Results indicate that overall metacoupling efficiency of SNWTP-MR is high (multi-year average about 0.96, always above 0.7). Average subsystem scores follow intracoupling 0.605 < pericoupling 0.818 < telecoupling 1.088, meaning distant northern users generally convert water into economic and social benefits more efficiently than water-abundant source and downstream regions. Efficiency in the source and downstream areas improves notably after project operation, whereas some northern areas show slight efficiency declines as scarcity pressures ease and water use becomes more relaxed.

The study is directly about metacoupling and telecoupling: it operationalizes these concepts in a quantitative, multi-region efficiency model and offers a transferable approach for assessing and optimizing cross-regional water transfers and other telecoupled resource flows.

## Structured Metacoupling Extraction

### Coupling Classification
- Explicit metacoupling analysis of one large cross regional water transfer project with three subsystems

### Intracoupling
#### Systems
- Water source region around Danjiangkou Reservoir within sending basin
- Local socio economic and ecological conditions in source region
#### Flows
- Regulated water storage and release within source area
- Changes in local water supply for agriculture and households
#### Agents
- Reservoir managers and basin water authorities
- Local governments in upstream cities and counties
- Farmers and households using source area water
#### Causes
- National decision to divert water from water rich central China to arid north
- Need to protect source water quality and quantity
- Industrial restructuring toward eco agriculture in source area
#### Effects
- Improved but relatively low internal water use efficiency
- Changes in agricultural output and livelihoods in source area
- Altered pollution loads entering reservoir and rivers

### Pericoupling
#### Systems
- Downstream reaches below Danjiangkou within same basin
- Adjacent areas hydraulically connected to source reservoir
#### Flows
- Reduced downstream discharge due to diversion
- Seasonally regulated flows for flood control and supply
#### Agents
- Downstream provincial governments and water bureaus
- Reservoir operation agencies managing releases
- Downstream farmers and industries
#### Causes
- Diversion altering downstream water volume and seasonality
- Need to reduce flood risk and stabilize water supply
- Increasing downstream water demand under urbanization
#### Effects
- Moderate to high water use efficiency with passive improvements
- Lower flood damages and disaster losses in downstream areas
- Pressure to optimize agricultural and industrial water use

### Telecoupling
#### Systems
- Remote northern receiving cities and provinces
- National interbasin transfer infrastructure linking basins
#### Flows
- Large scale interbasin transfer of high quality surface water
- Virtual flows of economic benefits, pollution displacement and population
#### Agents
- Central government water planners and regulators
- Municipal water utilities in Beijing Tianjin Hebei Henan
- Urban industries and residents consuming transferred water
#### Causes
- Severe water scarcity in northern cities and rapid urbanization
- Goal to rebalance spatial water availability and support economic growth
- Policy adoption of South North Water Transfer Middle Route
#### Effects
- Very high water use efficiency in receiving areas on average
- Improved urban water security and environmental quality upstream of cities
- Some rebound water waste as scarcity pressure declines

### Cross-Coupling Interactions
- Competition between downstream and remote receiving areas for limited diverted water
- Changes in source and downstream efficiency jointly determine overall project efficiency
- Reallocation of transfer shares among subsystems can optimize system wide efficiency

### Research Gaps or Limitations
- Few DMUs and short time series constrain DEA discrimination power
- Indirect ecological impacts like groundwater recovery and biotic changes not modeled
- Parallel DEA yields efficiency sets requiring subjective resource allocation choices

### Search Keywords
- metacoupling water transfer parallel DEA efficiency
- South North Water Transfer Middle Route intracoupling pericoupling telecoupling
- interbasin water transfer cross regional sustainability evaluation

### Extraction Confidence
high
