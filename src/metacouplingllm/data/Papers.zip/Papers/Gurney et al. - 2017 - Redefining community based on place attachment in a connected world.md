# Redefining community based on place attachment in a connected world

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:46:56.657469+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Gurney et al. - 2017 - Redefining community based on place attachment in a connected world.pdf
- Year: unknown
- DOI: 10.1073/pnas.1712125114
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This paper examines how ideas of community in environmental policy need to change in an increasingly interconnected world. It focuses on the Great Barrier Reef (GBR) in Australia, a globally recognized and threatened World Heritage site whose key drivers of change, such as climate change, extend far beyond local scales.

The authors argue that defining community only by residence or resource use is inadequate for understanding who cares about the GBR and who should participate in its management. They instead use place attachment theory, which emphasizes emotional identification with a place and functional reliance on it, including both direct use and more indirect contributions to well-being.

Using survey data from 5,403 people linked to the GBR as residents, indigenous residents, tourists, tourism operators, or commercial fishers, and spanning local, national, and international locations, the authors measure three aspects of attachment to the reef. They apply hierarchical cluster analysis to these indicators to identify emergent stakeholder groupings. Four distinct attachment-based communities appear: highly attached and directly involved users, intense users with weak identity ties, people who strongly value and identify with the GBR from a distance, and a more disengaged group.

These attachment communities cut across conventional communities of place and use; every use group and every location group contains all four attachment types, though in different proportions. Notably, many national and international respondents show strong emotional and symbolic ties to the GBR despite limited direct use.

The study is explicitly relevant to telecoupling and metacoupling. It shows that strong social and psychological connections to a distant ecosystem can develop through mobility, media, and shared identities, not only through local residence or direct use. This supports reframing community in environmental governance to include transnational communities of attachment, which could be mobilized for stewardship actions that influence distant ecosystems, such as climate mitigation, political lobbying, and global campaigns. The paper thus links evolving people-place relations to managing telecoupled sustainability challenges.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling focus; also relevant to intracoupling and pericoupling via place-based communities.

### Intracoupling
#### Systems
- Great Barrier Reef social-ecological system within coastal Queensland
- Local coastal communities and marine resource users
#### Flows
- Local environmental impacts from fishing, tourism, and pollution
- Information and communication about reef conditions and management
#### Agents
- Coastal residents and Indigenous residents
- Tourism operators and commercial fishers
- Great Barrier Reef Marine Park Authority managers
#### Causes
- Conventional community engagement based on location or resource use
- Local resource dependence for livelihoods and recreation
- Need for stewardship in face of reef degradation
#### Effects
- Heterogeneous place attachment within local use communities
- Variable support for reef management and policies
- Opportunities to tailor communication by attachment types

### Pericoupling
#### Systems
- Great Barrier Reef region and broader Australian society
- GBR region and adjacent national governance institutions
#### Flows
- Domestic tourism and travel to the reef
- National media and symbolic representations of the reef
- Political lobbying and policy feedback within Australia
#### Agents
- Australian non-coastal residents
- National NGOs and advocacy campaigns
- Federal and state government agencies
#### Causes
- Reef framed as national icon and heritage site
- Climate and water quality policies decided at higher scales
- Growing mobility and mediated experiences of the reef
#### Effects
- National residents forming strong identity-based attachment without frequent visits
- Potential for nationwide stewardship and behavior change
- Tension over relative influence of local versus national stakeholders

### Telecoupling
#### Systems
- Great Barrier Reef World Heritage Area
- International publics and distant stakeholders
- Global governance arenas and markets affecting the reef
#### Flows
- Virtual experiences and information via global media and internet
- Global advocacy, donations, and NGO campaigns for reef protection
- Teleconnected drivers like greenhouse gas emissions and global seafood demand
#### Agents
- International tourists and distant admirers of the reef
- Transnational NGOs and online advocacy networks
- International organizations and foreign governments influencing policies
#### Causes
- Globalization of mobility, communication, and environmental concern
- Reef status as global icon and shared natural heritage
- Need to manage drivers operating far beyond local scale
#### Effects
- Emergence of transnational attachment communities and imagined cosmopolitan publics
- Nonlocal actors contributing to stewardship through consumption and lobbying
- Governance challenges around multilevel participation and power sharing

### Cross-Coupling Interactions
- Place-attachment communities span local, national, and international systems, linking intra-, peri-, and telecouplings.
- Telecoupled advocacy and national identity feed back into local management and stakeholder conflicts.
- Local reef degradation triggers global concern, which influences higher-scale policies affecting local drivers.

### Research Gaps or Limitations
- Limited to one iconic reef system; generalizability to less symbolic places uncertain.
- Survey focuses on attachment measures, not detailed mapping of concrete cross-scale behaviors.
- Normative questions about balancing local and nonlocal influence remain largely unexplored empirically.

### Search Keywords
- place attachment communities Great Barrier Reef telecoupling
- transnational environmental stewardship imagined communities reef
- public participation location use attachment framing

### Extraction Confidence
high
