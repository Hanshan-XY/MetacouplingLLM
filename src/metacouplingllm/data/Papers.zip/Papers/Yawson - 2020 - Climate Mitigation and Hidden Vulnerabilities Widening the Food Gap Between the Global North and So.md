# Climate Mitigation and Hidden Vulnerabilities Widening the Food Gap Between the Global North and So

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:15:21.991357+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Yawson - 2020 - Climate Mitigation and Hidden Vulnerabilities Widening the Food Gap Between the Global North and So.pdf
- Year: unknown
- DOI: 10.1089/env.2020.0029
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This article examines how land-based climate mitigation policies in the global North can unintentionally deepen food insecurity in the global South, using a UK-barley-North-Africa case. The geographic focus is the United Kingdom as a major barley producer and exporter, and Algeria and Tunisia as import-dependent countries in arid North Africa.

The study models future UK feed barley supply to the 2050s by combining: (1) simulated barley yields under three climate change emissions scenarios using the FAO AquaCrop model and UK climate projections; and (2) projected UK cropland areas under five land-use and mitigation policy scenarios for the land use, land use change, and forestry (LULUCF) sector, ranging from business-as-usual to highly ambitious afforestation. Future demand is estimated from projected population (three fertility scenarios) and per capita feed grain demand for OECD countries. A food-balance approach and FAO Food Balance Sheets are used to translate total production into feed availability and to compare supply and demand. Trade and utilization data from FAOSTAT illustrate Algeria and Tunisia’s dependence on imported barley.

Results show that although climate change alone is expected to raise UK barley yields, land-based mitigation policies that expand forests at the expense of cropland sharply reduce barley area. Under all mitigation and population scenarios, large UK feed barley deficits emerge by the 2050s, larger than under a constant-cropland baseline. Since the UK is currently a surplus producer and key exporter, these deficits would likely drive higher imports from Europe and global markets.

Algeria and Tunisia already rely heavily on imported barley, mainly for animal feed linked to food and religious needs, with imports constituting a substantial share of domestic supply. They have limited capacity to substitute meat imports. The study argues that, in a telecoupled or metacoupled system, UK mitigation choices transmit risks to these distant, more vulnerable economies, potentially widening the North-South food gap. It calls for climate and land-use policies that explicitly integrate such cross-border justice and food security impacts. The paper is explicitly about telecoupled climate-food interactions.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via barley trade; some intracoupling within UK land system; limited explicit pericoupling.

### Intracoupling
#### Systems
- United Kingdom land use and LULUCF sector
- UK barley production and feed supply system
- UK food security and livestock sector
#### Flows
- Land allocation among forest cropland grassland
- Barley flows from farms to domestic feed users
- Financial flows from mitigation subsidies to afforestation
#### Agents
- UK government climate and agriculture ministries
- UK farmers and forestry enterprises
- UK livestock producers and feed industries
#### Causes
- UK land based climate mitigation targets and policies
- Afforestation incentives reducing cropland
- Population growth increasing UK feed demand
#### Effects
- Reduced UK cropland and barley area
- Large UK feed barley deficits by 2050
- Pressure to increase imports or alter diets

### Pericoupling
#### Systems
- Not identified.
#### Flows
- Not identified.
#### Agents
- Not identified.
#### Causes
- Not identified.
#### Effects
- Not identified.

### Telecoupling
#### Systems
- United Kingdom as barley exporting climate mitigation actor
- Algeria and Tunisia as barley dependent importers
- Broader global north barley producers and global south importers
#### Flows
- International barley trade from UK and Europe to North Africa
- Potential future UK barley or meat imports from Europe
- Telecoupled climate justice and policy influences
#### Agents
- UK policymakers implementing LULUCF mitigation scenarios
- North African governments relying on imported feed barley
- International bodies shaping climate and trade governance
#### Causes
- UK mitigation policies prioritizing forests over cropland
- Global climate agreements driving emission reductions
- Historical trade dependence of Algeria and Tunisia on northern barley
#### Effects
- Reduced exportable barley surplus from UK and possibly Europe
- Heightened food and feed vulnerability in Algeria and Tunisia
- Widening global north south food gap and geopolitical tensions

### Cross-Coupling Interactions
- UK intracoupled land decisions propagate as telecoupled supply shocks to Algeria and Tunisia
- Climate mitigation benefits in UK coincide with externalized food insecurity risks in global south
- Trade competition allows powerful northern importers to outcompete vulnerable southern buyers

### Research Gaps or Limitations
- Barley impacts in Algeria and Tunisia inferred from static food balance data not forward simulations
- Food balance approach fixes utilization shares ignoring structural and behavioral changes
- No integrated modeling of coupled futures for both UK and importing global south countries

### Search Keywords
- telecoupling barley trade climate mitigation justice
- UK LULUCF policies Algeria Tunisia food security
- global north south food gap land based mitigation

### Extraction Confidence
high
