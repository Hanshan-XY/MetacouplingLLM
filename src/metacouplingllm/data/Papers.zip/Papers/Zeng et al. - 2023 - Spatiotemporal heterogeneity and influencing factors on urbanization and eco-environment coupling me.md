# Spatiotemporal heterogeneity and influencing factors on urbanization and eco-environment coupling me

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:18:06.402104+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Zeng et al. - 2023 - Spatiotemporal heterogeneity and influencing factors on urbanization and eco-environment coupling me.pdf
- Year: unknown
- DOI: 10.1007/s11356-022-22042-8
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This study analyzes how urbanization and environmental conditions in China interact over space and time, focusing on both local linkages and longer-distance network connections that resemble telecoupling. The authors examine 30 provincial-level units (excluding Hong Kong, Macao, Taiwan, and Tibet) from 2008 to 2017, grouping them into eastern, central, and western China.

Using an entropy-weighted indicator system, they build composite indices for urbanization and eco-environmental status. These are combined via a coupling coordination degree model and a decoupling index to track how well urban development and environmental quality move together, and whether environmental pressure is growing faster or slower than urbanization. Spatial autocorrelation (global Moran and LISA), a gravity model, and social network analysis are used to construct and interpret a cross-provincial coupling coordination network. Finally, a spatial Durbin panel model based on the STIRPAT framework assesses the roles of population, income, technology, environmental regulation, and network centrality.

Results show that, nationally, coordination between urbanization and environment improves slowly but remains mostly in a basically uncoordinated state, often with the environment lagging behind urban development. Decoupling analysis indicates that weak decoupling is common, but many provinces also experience strong negative decoupling, an unsustainable pattern. Spatially, there is significant but modest clustering: Shanghai forms a high-high cluster, while several western provinces form expanding low-low clusters. The constructed network is dense in the east and sparse in the west, with increasing connectivity over time. Provinces like Shandong and Henan occupy central network positions and act as key conduits.

The spatial regression indicates that technological progress and environmental regulation investments strongly enhance coordination, higher income has mixed local-positive and spillover-negative effects, population growth undermines coordination, and central network positions tend to bear heavier environmental burdens. The paper explicitly interprets the cross-provincial coordination network as a telecoupled system, showing how interprovincial flows and dependencies shape urban-environment outcomes beyond simple local coupling.

## Structured Metacoupling Extraction

### Coupling Classification
- Mainly intracoupling of urbanization and eco-environment within Chinese provinces; telecoupling via interprovincial network.

### Intracoupling
#### Systems
- Provincial urbanization subsystem (population, economy, space, society) in China.
- Provincial eco-environment subsystem (pressure, state, response) in China.
- Man-land system focusing on urban development and environmental quality.
#### Flows
- Local resource use, emissions, land conversion within provinces.
- Internal investment in environmental pollution control.
- Local technological upgrades affecting energy intensity.
#### Agents
- Provincial and municipal governments.
- Urban residents and enterprises.
- Research and planning institutions.
#### Causes
- Rapid urbanization and economic growth increasing environmental pressure.
- Policy push for high-quality coordinated urbanization.
- Population growth and income changes within provinces.
#### Effects
- Mostly uncoordinated coupling with eco-environment lagging.
- Gradual rise of coupling coordination degree over 2008–2017.
- Intra-provincial environmental degradation where population and industry concentrate.

### Pericoupling
#### Systems
- Neighboring provinces within eastern, central, western regions.
- Urban agglomerations such as Beijing-Tianjin-Hebei cluster.
- Yangtze River Delta and adjacent inland provinces.
#### Flows
- Cross-boundary air and water pollution between adjacent provinces.
- Transfer of high-pollution industries to nearby poorer regions.
- Daily commuting, trade, and infrastructure linkages among neighboring provinces.
#### Agents
- Regional governments coordinating environmental policies.
- Industrial firms relocating across provincial borders.
- Transport and energy network operators.
#### Causes
- Spatial spillover of UECCD due to geographic proximity.
- Relocation of energy-intensive sectors from rich to nearby poorer areas.
- Regional integration through transport infrastructure expansion.
#### Effects
- Local Moran clustering: low-low clusters spreading across western neighbors.
- High-income coastal provinces exporting environmental pressure inland.
- Neighboring provinces influenced by each other’s environmental regulations.

### Telecoupling
#### Systems
- Networked provinces across China linked via UECCD gravity relations.
- Core coastal provinces and distant western interior provinces.
- Urban agglomerations connected through national transport and information systems.
#### Flows
- Long-distance spillovers of technological progress improving distant coupling.
- Telecoupled UECCD influence via social network centrality and gravity links.
- Nationwide diffusion of environmental regulations and green technologies.
#### Agents
- Central government shaping nationwide urbanization and environmental policy.
- Provinces with high betweenness centrality (e.g., Shandong, Jiangsu, Henan).
- Firms and capital reallocating production across distant regions.
#### Causes
- Globalization, internal trade, and large-scale migration cited as telecoupling drivers.
- National infrastructure like high-speed rail tightening distant linkages.
- Central policies promoting coordinated, cross-regional urbanization.
#### Effects
- Eastern key nodes radiate positive coupling to distant provinces.
- Central network provinces bear heavier environmental pressure.
- Telecoupled structure modestly inhibits local UECCD where centrality is high.

### Cross-Coupling Interactions
- Local coupling conditions shape a province’s position and influence in the national UECCN.
- Network centrality feeds back, altering local eco-environmental stress and coordination.
- Attribute-based hotspots and coldspots differ from network-based key governance nodes.

### Research Gaps or Limitations
- Focuses on interprovincial telecoupling; does not model global cross-border linkages explicitly.
- Uses gravity and SNA; does not include explicit physical pollution transport modeling.
- Temporal scope limited to 2008–2017; ignores later policy and structural changes.

### Search Keywords
- urbanization eco-environment coupling China network
- telecoupling UECCD gravity SNA
- spatial Durbin technological innovation environmental regulation

### Extraction Confidence
high
