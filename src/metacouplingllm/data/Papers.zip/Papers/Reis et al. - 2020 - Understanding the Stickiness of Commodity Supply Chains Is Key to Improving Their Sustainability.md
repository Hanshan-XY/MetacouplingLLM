# Understanding the Stickiness of Commodity Supply Chains Is Key to Improving Their Sustainability

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:03:18.893294+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Reis et al. - 2020 - Understanding the Stickiness of Commodity Supply Chains Is Key to Improving Their Sustainability.pdf
- Year: 2020
- DOI: 10.1016/j.oneear.2020.06.012
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This article develops and applies the concept of geographic stickiness in global commodity supply chains, using Brazilian soy exports as a case. Stickiness is defined as the tendency for trade relationships between specific places and firms to remain stable over time and through shocks. The authors distinguish three dimensions: persistence (stability over time), resistance (ability to withstand shocks), and recovery (ability to return to a stable configuration after disruption).

The study focuses on the Brazil soy export system, linking subnational logistics hubs, trading companies, and importing countries between 2003 and 2017. Using Trase data, the authors build a temporal network of exports and apply network metrics (topological overlap and its temporal extensions) to quantify how similar the configuration of trade linkages is across years. They examine both the entire network and specific actors, and compare stickiness to market share, zero-deforestation commitments (ZDCs), and deforestation risk indicators.

Results show that a small number of large traders dominate exports and have significantly stickier sourcing and selling patterns than numerous small traders that participate intermittently. Key logistics hubs and major importing countries also display higher stickiness than the average. Over short intervals, year-to-year configurations change only slightly, but cumulative changes over 15 years are substantial. Traders with higher stickiness tend to be those with greater soy-related deforestation risk and are more often signatories of ZDCs. Spatial analysis reveals that frontier regions in the Amazon and Cerrado exhibit strong, enduring connections to particular traders.

The paper is directly relevant to telecoupling and metacoupling research: it analyzes how distant production and consumption regions are durably linked through corporate actors, and how these stable ties shape land-use outcomes and deforestation leakage. The authors argue that understanding stickiness is critical for evaluating the likely effectiveness, spillovers, and accountability of supply chain governance, especially zero-deforestation initiatives, but they note that the paper mainly offers a conceptual and methodological foundation rather than a full telecoupling impact assessment.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling in Brazilian soy supply chain linking farms, traders, and distant consumer countries.

### Intracoupling
#### Systems
- Brazilian soy production landscapes and local logistics hub municipalities
- Individual soy trading companies operating within Brazil
#### Flows
- Soybeans and derived products moving from farms to local logistics hubs
- Information on zero deforestation commitments within company operations
#### Agents
- Soy farmers and cooperatives
- Local grain warehouses and processors
- Brazil based soy traders and exporters
#### Causes
- Expansion of soy cultivation for export revenues
- Infrastructure investments creating long term local trader presence
#### Effects
- Local deforestation and land use change near soy frontiers
- Regional socio economic development tied to export logistics

### Pericoupling
#### Systems
- Brazilian agricultural frontiers in Amazon and Cerrado regions
- Neighboring Brazilian regions supplying different traders
#### Flows
- Soy flows shifting between Amazon and Cerrado frontiers
- Leakage of deforestation pressure across adjacent biomes
#### Agents
- Traders reallocating sourcing among Brazilian frontiers
- Regional governments influencing land use policies
#### Causes
- Amazon Soy Moratorium restricting expansion in monitored areas
- Search for new areas with available cleared or convertible land
#### Effects
- Displacement of soy driven deforestation to Cerrado frontier
- Changing regional stickiness patterns among logistics hubs and traders

### Telecoupling
#### Systems
- Brazil as major soy exporting country
- Consumer markets in Europe, China, and other importing nations
- Global financial and governance systems influencing commodity trade
#### Flows
- International soy exports from Brazilian logistics hubs via traders to countries
- Deforestation risk embodied in traded soy volumes
- Governance signals through zero deforestation commitments and NGO campaigns
#### Agents
- Multinational soy trading corporations with large market shares
- Retailers and food companies in importing countries
- NGOs and multi stakeholder initiatives promoting zero deforestation
#### Causes
- Rising global demand for animal feed, biofuels, and vegetable oil
- Consumer and NGO pressure for forest friendly sourcing
- Trade policies, price shocks, and climatic events affecting supply
#### Effects
- Forest loss and carbon emissions in producing regions driven by distant consumption
- Creation and effectiveness of zero deforestation commitments in supply chains
- Potential leakage of deforestation across regions and commodities

### Cross-Coupling Interactions
- Stickiness of trader region relations mediates how distant consumer pressure affects local deforestation.
- Zero deforestation agreements in one biome can redirect expansion and risk to neighboring biomes.
- Stable trader links to both sources and markets enhance transmission of sustainability signals along the chain.

### Research Gaps or Limitations
- Limited ability to attribute causal impacts of specific shocks on stickiness and land use.
- Lack of detailed data on domestic soy supply chains and non export uses.
- Need for systematic thresholds and metrics for resistance and recovery dimensions of stickiness.

### Search Keywords
- soy supply chain stickiness Brazil deforestation risk traders
- zero deforestation commitments telecoupling Trase temporal network
- Amazon Soy Moratorium leakage Cerrado commodity governance

### Extraction Confidence
high
