# Integration of a local fish market in Namibia with the global seafood trade Implications for fish t

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:29:42.061875+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Bronnmann et al. - 2020 - Integration of a local fish market in Namibia with the global seafood trade Implications for fish t.pdf
- Year: unknown
- DOI: 10.1016/j.worlddev.2020.105048
- OA status: green
- License: cc-by-nc-nd
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This article analyzes how a small inland fish market in Katima Mulilo, northeastern Namibia, has become intertwined with global seafood trade and what this means for traders and sustainability. The setting is a freshwater fish market supplied mainly from the Zambezi-Chobe floodplains and, after 2009, from Lake Liambezi. The work is clearly framed within the telecoupling and market-integration literature.

The geographic focus is the Zambezi Region of Namibia, with links to Zambia, the Democratic Republic of Congo, China, and ultimately major seafood importers in Europe, the United States, and Japan. The system context is small-scale, largely freshwater capture fisheries and local trading, influenced by regional aquaculture expansion and global tilapia trade.

The authors combine two main empirical approaches using data from January 2008 to December 2016: (1) time-series analysis of monthly prices for three dominant tilapia species at the Katima market, compared with the FAO Fish Price Index; and (2) hedonic price models on more than 59,000 individual fish observations, relating inflation-adjusted prices per kilogram to species, fish length, river water levels, year, and season.

Cointegration tests show that prices for the three main tilapia species move in a stable long-run relationship with the global seafood price index, and that the law of one price is not rejected. This implies that, although fish from Katima are not directly exported to rich-country markets, local prices are effectively governed by global competition, mediated by regional trade and Chinese tilapia imports. Hedonic results indicate that larger fish command price premia and that, after controlling for size, seasonality, and flood conditions, real prices paid to traders rose substantially over the study period.

The paper is explicitly about telecoupling: it documents distant market export, competition, and spillover mechanisms linking a remote African freshwater market to global seafood demand. However, it does not demonstrate whether higher prices are sustainable or pro-poor in the long term, nor does it assess ecological impacts on fish stocks or nutritional consequences for low-income consumers.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via global seafood prices; some regional pericoupling; limited explicit intracoupling focus.

### Intracoupling
#### Systems
- Katima Mulilo local fish market and surrounding Zambezi-Chobe-Lake Liambezi fisheries
- Namibian inland freshwater fishery governance and local livelihood system
#### Flows
- Local trade of fresh tilapia and other species between fishers, traders, and Katima residents
- Nutrient and protein provision from freshwater fish to local households
#### Agents
- Small-scale fishers operating on Zambezi floodplains and Lake Liambezi
- Local fish traders and vendors in Katima Open Market
- Local consumers purchasing small quantities for household meals
#### Causes
- National policy prioritizing subsistence use of freshwater fisheries over commercialization
- Seasonal flooding patterns affecting fish abundance and accessibility
- Household livelihood seasonality in farming and livestock influencing market participation
#### Effects
- Higher real fish prices over time for traders and possibly fishers
- Potential pressure on freshwater stocks, especially larger tilapia-sized fish
- Uncertain impacts on local food security and consumer access to fish

### Pericoupling
#### Systems
- Katima Market and regional Zambian urban markets including Copperbelt cities
- Lake Liambezi fishery and Zambian aquaculture sector
- Namibian and regional African markets linked by new bridge and roads
#### Flows
- Fresh tilapia shipped on ice from Katima to Zambian towns and border areas
- Frozen tilapia and marine fish moved regionally between Namibia, Zambia, DRC, South Africa, Mozambique
- Price signals transmitted across regional freshwater and aquaculture markets
#### Agents
- Intermediaries and traders transporting fish by pickup trucks across borders
- Zambian aquaculture firms producing mainly farmed tilapia
- Regional urban consumers with growing purchasing power, especially mining workers
#### Causes
- Bridge construction and road upgrades connecting Namibia and Zambia
- Copper price booms reopening Zambian mines and raising incomes
- Expansion and commercialization of Zambian tilapia aquaculture
#### Effects
- Expanded market access and larger demand pool for Katima fish
- Segmentation of tilapia by size and quality for higher-income consumers
- Regional competition between wild, farmed, and imported tilapia products

### Telecoupling
#### Systems
- Katima inland freshwater market in Namibia
- Global seafood trade hubs in EU, USA, Japan represented by Fish Price Index
- Chinese tilapia production and export system
#### Flows
- Global price information and cointegrated fish price dynamics reaching Katima Market
- Frozen tilapia imports from China into Namibia with onward re-export regionally
- Large-scale Namibian marine exports to EU potentially influencing national seafood pricing
#### Agents
- International seafood traders and processors shaping Fish Price Index bundle
- Chinese tilapia exporters supplying Southern African markets
- National-level policymakers and trade authorities managing seafood exports and imports
#### Causes
- Globalization and trade liberalization in seafood markets
- High-income country demand for diverse seafood species and tilapia products
- Technological advances such as mobile phones improving market information flow
#### Effects
- Law of One Price holds between Katima tilapia and global seafood index
- Rising real fish prices for Katima traders despite increased supply
- Potential long-distance feedbacks on resource exploitation and local governance

### Cross-Coupling Interactions
- Telecoupled global prices amplify effects of regional infrastructure and aquaculture growth on Katima prices.
- Regional trade links transmit global demand shocks into local Namibian freshwater fisheries.
- Marine export telecoupling and Chinese imports indirectly influence inland tilapia market structure.

### Research Gaps or Limitations
- Fish stock status and long-term sustainability under increased prices remain unquantified.
- Distribution of gains along the value chain and role of powerful intermediaries is unclear.
- Nutritional and food security impacts of higher prices on local consumers not directly measured.

### Search Keywords
- Katima Mulilo Namibia freshwater fish market globalization
- tilapia price cointegration Fish Price Index telecoupling
- Lake Liambezi Zambezi aquaculture Zambia Chinese tilapia imports

### Extraction Confidence
high
