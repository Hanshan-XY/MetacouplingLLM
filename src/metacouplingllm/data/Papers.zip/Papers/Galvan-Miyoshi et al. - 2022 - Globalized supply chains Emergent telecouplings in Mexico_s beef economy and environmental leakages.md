# Globalized supply chains Emergent telecouplings in Mexico_s beef economy and environmental leakages

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:45:55.972807+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Galvan-Miyoshi et al. - 2022 - Globalized supply chains Emergent telecouplings in Mexico_s beef economy and environmental leakages.pdf
- Year: unknown
- DOI: 10.1016/j.gloenvcha.2022.102486
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
The paper examines how Mexico’s beef sector was transformed by trade liberalization, especially after NAFTA, and how this restructuring created new telecouplings and environmental leakages. The study focuses on Mexico and its linkages with the United States and Central America within a globalized beef-corn-feedlot system.

The authors develop a conceptual model of a shift from a mainly domestic, pasture-based cattle system to a globally integrated feedlot-based supply chain. Using mixed methods, they combine a scientific survey of 159 Mexican feedlots, official Mexican and US trade statistics, national agricultural censuses, land cover data, and detailed records from sanitary inspection points on cattle movements. Regression models are used to estimate grazing land requirements and to infer the scale of cross-border calf flows and associated deforestation and greenhouse gas (GHG) emissions.

They identify three major telecouplings: Mexican beef exports to the US and other countries; US corn exports to Mexico; and a largely informal flow of feeder calves from Central America into Mexican feedlots. Trade liberalization lowered grain prices, encouraged foreign investment, and enabled rapid expansion of feedlot production. Beef and corn production in Mexico became much more land- and time-efficient per animal, and national deforestation rates declined overall.

However, the analysis shows that total land used for the beef supply chain increased substantially when grazing land and imported feed are fully counted, including land in Central America needed to raise contraband calves. Estimated pasture expansion outside Mexico offsets or surpasses forest recovery within Mexico. The study calculates that about 14 percent of GHG emissions attributable to Mexico’s post-NAFTA beef supply chain occur in Central America, mainly from enteric fermentation and some from deforestation.

This is explicitly a telecoupling/metacoupling study. It demonstrates how productivity gains and apparent national-level land sparing in Mexico are undermined by externalized land use and emissions, raising critical concerns for carbon accounting and nationally determined contributions under the Paris Agreement.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling among Mexico, United States, and Central America via beef, corn, and calf trade

### Intracoupling
#### Systems
- Mexico domestic beef supply chain and grazing lands
- Mexico corn production and cropland
- Mexico forest and pasture land systems
#### Flows
- Movement of calves from Mexican ranches to domestic feedlots
- Corn and forage from Mexican farms to cattle operations
- Land conversion from forest to pasture and cropland
#### Agents
- Mexican ranchers and feedlot operators
- Mexican retail and meatpacking companies
- Mexican federal statistical and environmental agencies
#### Causes
- National adoption of feedlot technologies and intensification
- Domestic demand for beef and dairy products
- Agricultural policies and historical price supports
#### Effects
- Shift from grass-fed hacienda model to feedlot-based system
- Expansion of domestic pasture area despite higher productivity
- National GHG emissions increase from larger cattle herd

### Pericoupling
#### Systems
- Southern Mexico border regions adjoining Guatemala
- Central and northern Mexican feedlot clusters
- Frontier municipalities along Mexico–Guatemala boundary
#### Flows
- Regional cattle movements recorded at sanitary inspection points
- Truck shipments of feeder calves from border to interior feedlots
- Unregistered cross-border flows blending into local herds
#### Agents
- Border cattle traders and transporters
- State sanitary inspection stations and officials
- Local ranchers in frontier municipalities
#### Causes
- Geographic proximity enabling informal cross-border trade
- Feedlot demand outpacing local calf production
- Limited enforcement capacity along porous borders
#### Effects
- Concentration of feeder flows in a few border municipalities
- Growth of regional feedlot hubs receiving frontier cattle
- Partial masking of trade volumes in official statistics

### Telecoupling
#### Systems
- Mexico beef production system
- United States grain and beef market system
- Central American cattle ranching landscapes
#### Flows
- Beef exports from Mexico to US and other global markets
- Corn exports from United States to Mexican feedlots
- Contraband feeder calves from Central America to Mexico
#### Agents
- International grain and meat corporations and retailers
- Mexican, US, and Central American trade and agricultural agencies
- Climate governance bodies managing Paris Agreement commitments
#### Causes
- Trade liberalization through GATT, NAFTA, and USMCA
- Falling grain prices enabling feedlot expansion
- Rising global demand for grain-fed beef products
#### Effects
- Integrated transnational beef-corn supply chain formation
- Deforestation leakage from Mexico to Central America
- Telecoupled GHG emissions embedded in Mexican beef exports

### Cross-Coupling Interactions
- Reciprocal telecoupling where Mexico sends beef and receives US corn
- Nested telecoupling where Mexican exports depend on Central American calves
- Environmental spillovers where deforestation and GHG shift to supplying countries

### Research Gaps or Limitations
- Limited data for unregistered slaughterhouses and informal cattle operations
- Use of Mexican stocking densities as proxy for Central America conditions
- Assumptions about all new pasture arising from forest conversion

### Search Keywords
- Mexico beef telecoupling NAFTA Central America corn feedlots
- deforestation leakage pasture expansion GHG emissions cattle trade
- trade liberalization land sparing Borlaug hypothesis Mexico-US supply chain

### Extraction Confidence
high
