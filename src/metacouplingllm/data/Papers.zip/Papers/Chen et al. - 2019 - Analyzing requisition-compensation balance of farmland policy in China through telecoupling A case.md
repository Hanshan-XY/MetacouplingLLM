# Analyzing requisition-compensation balance of farmland policy in China through telecoupling A case

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:36:05.576434+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Chen et al. - 2019 - Analyzing requisition-compensation balance of farmland policy in China through telecoupling A case.pdf
- Year: unknown
- DOI: 10.1016/j.landusepol.2019.01.031
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
The paper examines Chinas requisition-compensation balance of farmland (RCBF) policy using a telecoupling perspective, focusing on the middle reaches of the Yangtze River Urban Agglomerations (MRYRUA) from 1995 to 2015. This region includes major urban clusters in Hubei, Hunan, and Jiangxi provinces, where rapid urbanization has converted large areas of farmland to construction land.

The study embeds RCBF in a metacoupling framework by treating urban areas that requisition farmland as receiving systems and rural, often mountainous, areas that provide compensatory farmland as sending systems, linked by flows of land, capital, and policy. It evaluates four dimensions of balance: land quantity, land quality, agricultural productivity, and ecosystem services.

Using Landsat-derived land use maps (30 m), soil datasets, DEM, NDVI (1 km), and provincial grain statistics, the authors calculate: a RCBF index via land use transfer matrices; topographic and soil differences using gravity center analysis and soil indicators (texture, organic content, pH, erosion); productivity via NDVI-based grain yield allocation to 1 km grids; and ecological change using an ecosystem services value (ESV) model calibrated for China.

Results show that total farmland area and aggregate grain productivity were more than compensated, mainly by converting dry land and exploiting new farmland in mountainous areas. However, this compensation came with poorer physical conditions: higher elevation and slope, coarser soils, less favorable pH, and higher erosion risk. Ecologically, the policy generated substantial net losses in ecosystem services, driven especially by converting forests and water bodies into farmland, while urban reclamation of construction or unused land slightly improved services locally. Two problematic patterns emerge: paddy fields in lowland plains are lost while drier, inferior uplands are added; and ecosystem burdens are shifted from urban cores to peripheral rural and mountain areas.

The paper is directly about telecoupling/metacoupling, using the framework to reveal cross-regional feedbacks, vicious circles in land finance and land abandonment, and asymmetric distribution of ecological costs and economic benefits in the RCBF system.

## Structured Metacoupling Extraction

### Coupling Classification
- Primarily telecoupling between urban construction regions and distant rural compensation regions within China.

### Intracoupling
#### Systems
- Urban agglomeration land system inside MRYRUA.
- Mountainous rural land system inside each province.
#### Flows
- Internal conversion between farmland, forest, water and construction land.
- Local grain output and ecosystem services changes.
#### Agents
- County governments managing land conversion.
- Local farmers deciding cultivation or abandonment.
#### Causes
- Urbanization and industrialization within agglomerations.
- Local fiscal pressure and development targets.
#### Effects
- Farmland loss in plains and expansion on slopes.
- Decreased local farmland quality and ecological value.

### Pericoupling
#### Systems
- Neighboring counties within the same province.
- Plain counties and adjacent mountain counties.
#### Flows
- Requisitioned plains farmland balanced by nearby mountain farmland.
- Spatial spillover of soil erosion and ecosystem degradation.
#### Agents
- Prefecture and provincial departments coordinating counties.
- Developers shifting projects across nearby jurisdictions.
#### Causes
- Shortage of reserve farmland around major cities.
- Policy requirement for no net farmland loss regionally.
#### Effects
- Compensatory farmland pushed into nearby mountains.
- Uneven productivity and RCBF index among adjacent counties.

### Telecoupling
#### Systems
- Farmland requisition (urban receiving) system in developed areas.
- Farmland compensation (rural sending) system in resource-rich areas.
- Spillover ecosystems in ecologically fragile mountain regions.
#### Flows
- Capital and land-transfer fees from urban to rural regions.
- Policy directives, quotas, and RCBF performance assessments.
- Land-use change: forest, grassland, water converted to compensatory farmland.
#### Agents
- Central government designing RCBF and zoning policies.
- Provincial and county governments implementing requisition-compensation.
- Stakeholders occupying farmland: developers, industries, urban residents.
#### Causes
- Demand for construction land, economic growth, and globalization.
- Fiscal reliance on land-lease revenues by local governments.
- Abundant reserve land but limited funds in rural compensation areas.
#### Effects
- Vicious circle: land finance drives more farmland requisition.
- Vicious circle: steep farmland compensation leads to abandonment and poverty.
- Large ecosystem service losses in sending areas, limited gains near cities.

### Cross-Coupling Interactions
- Telecoupled capital and policy flows reshape intracoupling in both urban and rural land systems.
- Pericoupling farmland shifts mediate telecoupled demands between distant requisition and compensation systems.
- Ecosystem degradation in sending regions feeds back to national food security and policy tightening.

### Research Gaps or Limitations
- Limited integration of economic and social equity balances in the evaluation framework.
- Productivity estimates depend on NDVI and statistics; management and climate drivers underexplored.
- Drivers of RCBF dynamics under newer cross-provincial policies need further long-term analysis.

### Search Keywords
- requisition-compensation balance of farmland China telecoupling
- MRYRUA land use ecosystem services
- farmland policy RCBF quantity quality productivity ecological balance

### Extraction Confidence
high
