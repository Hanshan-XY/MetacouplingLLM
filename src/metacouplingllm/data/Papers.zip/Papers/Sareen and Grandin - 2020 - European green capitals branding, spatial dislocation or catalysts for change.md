# European green capitals branding, spatial dislocation or catalysts for change

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:04:10.430119+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Sareen and Grandin - 2020 - European green capitals branding, spatial dislocation or catalysts for change.pdf
- Year: unknown
- DOI: 10.1080/04353684.2019.1667258
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper examines how the European Green Capital (EGC) award functions within Europes urban sustainability governance, using Oslo (2019) and Lisbon (2020) as focal cases. The geographic scope is European, but the analysis emphasizes how cities interact with wider regional and global systems.

The authors treat cities as both discursive projects and material hubs, and develop a framework for assessing accountability along two axes. First, they analyse EGC as performative discourse: how the label and application process shape narratives, branding, coalitions, and citizen engagement. Second, they analyse telecoupled materiality: how urban sustainability initiatives are connected to distant resources, emissions, and supply chains, and whether these links are acknowledged or hidden.

Methods combine document analysis of EGC applications, city climate and energy strategies, limited interviews, field observations in Oslo and Lisbon, and secondary sources. They apply an accountability matrix that distinguishes between hollow versus substantive accountability, and between local versus translocal spatial scales.

In Oslo, the EGC agenda strongly targets territorial emissions via climate budgeting, green procurement, and transport electrification, but largely omits consumption-based emissions and international travel. In Lisbon, the EGC agenda stresses smart-city efficiency, solar deployment inside city limits, and circular-economy narratives, but gives little attention to real estate pressures, energy justice, regulatory barriers to citizen energy, or global supply chains for technologies.

The paper argues that the EGC framework tends to reward optimization of local indicators while underemphasizing transboundary impacts. This can displace environmental burdens to other regions rather than reduce them overall. Both cities use EGC branding to catalyse some local change, yet only weakly address telecoupled effects of their policies.

The study is explicitly about telecoupling and metacoupling. It uses telecoupling concepts to show that current urban award schemes insufficiently capture cross-scale socioecological interactions, and recommends integrating indicators for consumption, aviation, and supply-chain impacts to strengthen systemic, not merely local, sustainability transitions.

## Structured Metacoupling Extraction

### Coupling Classification
- Strongly telecoupling focused; also treats intra-urban and peri-urban sustainability linkages.

### Intracoupling
#### Systems
- Oslo municipal territory and governance system
- Lisbon municipal territory and governance system
- European Green Capital award mechanism
#### Flows
- Urban energy use and greenhouse gas emissions within city boundaries
- Local transport and mobility patterns inside cities
- Intra-urban infrastructure investments and public procurement
#### Agents
- Municipal governments of Oslo and Lisbon
- European Commission award administrators
- City residents and local businesses
#### Causes
- Urban sustainability transitions framed around low carbon futures
- Competition for European Green Capital branding
- Polycentric, networked urban sustainability governance
#### Effects
- Local emission reduction targets and climate budgets
- Urban mobility changes such as car free centers and EV promotion
- City branding as sustainability leaders and role models

### Pericoupling
#### Systems
- Urban cores and surrounding peri urban regions
- Metropolitan transport and housing systems
- Regional energy and waste management networks
#### Flows
- Commuter transport between suburbs and city centers
- Electricity flows from regional grids to cities
- Peri urban green space use by urban residents
#### Agents
- Metropolitan and regional authorities
- Transport agencies and utilities
- Suburban communities near the capitals
#### Causes
- City densification and mobility strategies
- Location of renewable energy and waste facilities near cities
- Recreational and lifestyle planning in peri urban areas
#### Effects
- Potential displacement of emissions to metropolitan fringes
- Unequal access to upgraded transport and services
- Changing land use and real estate pressures around cities

### Telecoupling
#### Systems
- European capitals and distant production regions
- Transnational city networks such as C40 and Covenant of Mayors
- Global fossil fuel and renewable technology supply chains
#### Flows
- Telecoupled material flows of vehicles, solar panels, construction machinery
- Emission impacts from consumption and international travel by city residents
- Knowledge, norms and governance practices circulating through city networks
#### Agents
- Multilevel governance actors including EU institutions
- Global manufacturers and energy corporations
- Translocal city networks and partner municipalities
#### Causes
- Fragmented, voluntary global sustainability governance
- Urban demand driving distant production and emissions
- Use of awards and rankings as soft policy instruments
#### Effects
- Spatial dislocation of environmental burdens outside city boundaries
- Limited accounting for consumption based and aviation emissions
- Opportunities to reconfigure translocal assemblages toward decarbonization

### Cross-Coupling Interactions
- Local climate actions can reduce territorial emissions while increasing distant supply chain emissions.
- Urban densification may cut local transport emissions yet stimulate more long distance air travel.
- City procurement can reshape global technology markets, affecting distant production systems.

### Research Gaps or Limitations
- Scarce operational tools for cities to measure and govern telecoupled impacts systematically.
- Award criteria underemphasize consumption based emissions and aviation, constraining accountability.
- Limited discussion of cities’ roles as headquarters for industries sustaining unsustainable practices.

### Search Keywords
- European Green Capital telecoupling accountability
- urban sustainability spatial dislocation Oslo Lisbon
- performative discourse telecoupled materiality cities

### Extraction Confidence
high
