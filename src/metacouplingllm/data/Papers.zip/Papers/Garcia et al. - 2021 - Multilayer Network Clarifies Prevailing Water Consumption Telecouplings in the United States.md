# Multilayer Network Clarifies Prevailing Water Consumption Telecouplings in the United States

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:46:21.122354+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Garcia et al. - 2021 - Multilayer Network Clarifies Prevailing Water Consumption Telecouplings in the United States.pdf
- Year: unknown
- DOI: 10.1029/2020WR029141
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines how US regions are interconnected through indirect, or virtual, blue water consumption embodied in goods and services, using a multilayer network framework grounded in the telecoupling concept. The geographic scope is the conterminous United States, disaggregated into 115 regions (65 major cities and 50 state or remainder-of-state units) and 41 economic sectors, including agriculture, manufacturing, and services.

The authors construct an environmental multiregional input-output (E-MRIO) model for 2012, combining commodity flow data, input-output tables, socioeconomic information, and sectoral water consumption coefficients. From this they derive a supra-adjacency matrix of virtual water flows among all region-sector pairs, representing approximately 4,700 nodes and tens of millions of potential links. They analyze three network dimensions: connectivity (via strength distributions), mesoscale structure (community detection using modularity maximization), and node importance (a random-walk-based betweenness centrality adapted to multilayer networks). They also compare results to an aggregated single-layer (monolayer) network.

The multilayer network is highly connected, with each node linked on average to about two-thirds of all nodes. Intersectoral (interlayer) flows represent more than half of all connections and dominate inflows, indicating that aggregating sectors into a monolayer obscures critical cross-sector supply-chain pathways. Strength distributions for in- and outflows are heavy-tailed, largely driven by food-related sectors and populous regions, implying that some nodes wield disproportionate influence and that the system may be vulnerable to cascading shocks.

Community analysis reveals five major telecoupled clusters spanning distant regions, including a strong West-to-East virtual water transfer from western producers (notably California) to eastern consumers. In contrast, the monolayer network yields more spatially contiguous, basin-like communities, underemphasizing long-distance telecouplings. Centrality analysis shows that large cities act as bottlenecks where virtual water tends to accumulate and recirculate, reinforcing their role as critical hubs in national hydro-economic telecouplings.

The paper explicitly addresses telecoupling/metacoupling by revealing how distant US regions are linked through supply chains and by demonstrating that multilayer methods better capture these systemic water-consumption connections than traditional monolayer approaches.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong domestic telecoupling via interregional virtual water trade within the conterminous United States

### Intracoupling
#### Systems
- Urban and rural regions within the same US community region
- Economic sectors within a single US region
#### Flows
- Intralayer virtual water exchanges within one economic sector
- Self-loops representing sectoral recirculation in the same region
#### Agents
- Local industries and service providers
- Municipal governments managing water and infrastructure
#### Causes
- Local production and consumption structure within regions
- Sectoral input requirements inside regional economies
#### Effects
- Regional water footprints of production and consumption
- Virtual water accumulation in populous cities

### Pericoupling
#### Systems
- Neighboring US regions within the same multilayer community
- Basins and adjacent economic regions such as Colorado River area
#### Flows
- Short and medium distance virtual water trade among nearby regions
- Regional commodity flows derived from freight data
#### Agents
- Regional producers and processors of food commodities
- State-level water and economic planners
#### Causes
- Geographic proximity lowering trade frictions
- Shared basin infrastructure and transport corridors
#### Effects
- Spatially contiguous communities in monolayer network
- Concentration of flows within specific hydrologic regions

### Telecoupling
#### Systems
- Western US water-exporting regions and Eastern US consumer cities
- Five interregional communities of the multilayer virtual water network
- Large metropolitan areas and distant agricultural regions
#### Flows
- Long-distance virtual blue water transfers embedded in goods and services
- West-to-East virtual water exports from California and other western states
- Interlayer flows linking multiple economic sectors across regions
#### Agents
- Large US cities acting as virtual water sinks and network bottlenecks
- Agricultural and food-processing sectors supplying distant consumers
- National-level policymakers using input-output and water data
#### Causes
- Final demand for goods and services driving remote water use
- Complex multi-sector supply chains across 115 US regions
- Economic specialization in food production and manufacturing
#### Effects
- Heavy-tailed distributions of virtual water inflows and outflows
- Communities representing dominant long-range water-consumption linkages
- Increased vulnerability to cascading shocks such as widespread drought

### Cross-Coupling Interactions
- Interlayer flows account for majority of network connectivity and strongly shape telecoupled patterns
- Ignoring interlayer couplings in monolayer models misestimates regional water footprints and centrality
- Multilayer communities differ markedly from monolayer communities emphasizing distant over local linkages

### Research Gaps or Limitations
- International virtual water trade is excluded; only domestic US interactions analyzed
- Study uses a single year of data, limiting temporal dynamics assessment
- Green water and some sectors are omitted, focusing only on blue water and 41 sectors

### Search Keywords
- virtual water telecoupling United States multilayer network
- environmental multiregional input output blue water
- urban water footprint supply chain communities centrality

### Extraction Confidence
high
