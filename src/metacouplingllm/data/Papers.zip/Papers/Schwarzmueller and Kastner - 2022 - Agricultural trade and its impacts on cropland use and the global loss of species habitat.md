ORIGINAL ARTICLE

![](images/fc11c8236bf42fc614099b7c3d933e6562c85c8ec6a013313a81bfa2367797d0.jpg)

# Agricultural trade and its impacts on cropland use and the global loss of species habitat

Florian Schwarzmueller1 $\textcircled{1}$ · Thomas Kastner1

Received: 26 August 2021 / Accepted: 8 March 2022 / Published online: 12 May 2022 © The Author(s) 2022

# Abstract

Agricultural expansion and intensifcation are threatening biodiversity worldwide, and future expansion of agricultural land will exacerbate this trend. One of the main drivers of this expansion is an increasingly global trade of agricultural produce. National and international assessments tracking the impact of agriculture on biodiversity thus need to be expanded by a consumption-based accounting of biodiversity loss. In this study, we use global trade data, provided by the Food and Agriculture Organisation of the United Nations (FAO), to construct national trade profles for 223 countries, at the level of 191 produced items and over the timespan of 15 years. We show how bilateral trade data and a national biodiversity indicator, the Species Habitat Index (SHI), can be combined to quantify consumption-based impacts of agricultural trade on biodiversity. We found that the cropland area for agricultural trade has increased from 17 (in 2000) to $2 3 . 5 \%$ (in 2013) of the global total cropland area. Especially, countries in Western Europe, North America, and the Middle East, create a large part of their biodiversity footprint outside their own country borders, because they import large amounts of agricultural products from areas where the SHI records high biodiversity loss. With our approach, we can thus identify countries where consumptionbased interventions might be most efective for the protection of global biodiversity. Analyses like the one presented in this study are needed to complement territorial sustainability assessments. By taking into account trade and consumption, they can inform cross-border agreements on biodiversity protection.

Keywords Agricultural trade $\cdot$ Telecoupling $\cdot$ Consumption-based accounting $\cdot$ Biodiversity loss

# Introduction

Land-use change is one of the major drivers of current biodiversity loss (Millennium Ecosystem Assessment 2005; Mazor et al. 2018). For terrestrial and freshwater systems, it has had the “largest relative negative impact [on biodiversity] since 1970” (Díaz et al. 2019). Most of this land-use change can be attributed to the expansion of agricultural land, which, to date, covers almost half of all habitable land on earth (Ellis et al. 2010; Ritchie and Roser 2013). The impact of this agricultural expansion on biodiversity is strong, with more than $6 0 \%$ of the species currently listed as threatened or nearly threatened by the IUCN being directly

afected by agricultural activity (Maxwell et al. 2016). This picture is even more pronounced for threatened mammal (more than $7 0 \%$ ) and bird species (more than $8 0 \%$ ) (Tilman et al. 2017).

The recent global distribution of agricultural expansion shows two trends: First, agricultural expansion is more prominent in some countries than in others. For example, the permanent or temporary expansion of cropland is the main driver of deforestation in Latin America, Sub-Saharan Africa, and Southeast Asia (Curtis et al. 2018). The same pattern can be found when looking at regional biodiversity threats (Tilman et al. 2017). Second, agricultural expansion is only partly driven by an increased domestic demand. Especially, in South America and Southeast Asia, a lot of habitat conversion is associated with the production of exported products (Pendrill et al. 2019). While many developed countries (plus China and India) have increased their domestic forest areas over the last years, the deforestation associated with their imports has increased with

tropical forests being the most threatened biome (Hoang and Kanemoto 2021).

The need for food and other agricultural products is predicted to increase between 35 and $5 0 \%$ from 2010 to 2050 (van Dijk et al. 2021). This is partly due to the predicted increase in world population to 10 billion people by the year 2100 (Gerland et al. 2014) but also to structural changes such as urbanization, and per capita increases in income and associated changes in dietary composition (FAO 2017; van Dijk et al. 2021). An increased demand for food and other agricultural products will put additional pressure on the world’s ecosystems (Tilman et al. 2011) and is predicted to lead to an increase in agricultural land of about 100 million hectares until 2050 (FAO 2017). Again, these are predicted to be occurring especially in tropical and sub-tropical areas at the expense of forests rich in biodiversity (Alexandratos and Bruinsma 2012).

The observed pattern of an increased consumption in some parts of the world driving severe environmental impacts in others calls for the use of consumption-based accounting methods that allow calculating “imported impacts”. These enable tracing environmental problems from the place where they are occurring, for example those associated with agricultural production, to countries where the product is consumed, i.e., where the underlying drivers originate. Such accounting methods have been developed to track embedded impacts of trade in terms of greenhouse gas emissions (Hertwich and Peters 2009), water use (Hoekstra and Mekonnen 2012), land use (Würtenberger et al. 2006), and impacts on biodiversity (Lenzen et al. 2012; Chaudhary and Kastner 2016; Marques et al. 2019).

Several studies that looked at the impact of agricultural trade and consumption on biodiversity found that the majority of impacts are caused by developed and densely populated countries (with a high GDP), or regions where agricultural land use is limited by climatic conditions (Chaudhary and Kastner 2016; Marquardt et al. 2019). These countries are projected to drive the most extinctions (Chaudhary and Brooks 2019) with a large part of their cropland and biodiversity footprint being caused by imports (Wilting et al. 2017; Shaikh et al. 2021). However, some studies have found that, over the last years, middle- and low-income countries have become more important in driving global land-use change (Bjelle et al. 2021) with increases in biodiversity footprints being more closely related to increases in income than in high-income countries (Wilting et al. 2017). These studies also list South America, Southeast Asia, and sub-Saharan Africa as being the most afected regions (Chaudhary and Brooks 2019), with international trade and production for exports being growing drivers (Chaudhary and Kastner 2016; Marques et al. 2019; Shaikh et al. 2021).

All of these studies chose diferent metrics for the biodiversity impacts that vary in taxonomic extent or underlying

data sources. For this study, we focus on the Species Habitat Index (SHI) as an estimate of changes in country-level biodiversity patterns that are caused by changes in land use (Jetz and Thau 2015; Powers and Jetz 2019). The SHI estimates the loss of natural species’ habitat on a country level by measuring the change in habitat availability for a country’s species assemblage (see method section for more details on how it is calculated). Consistent with the other data (Tilman et al. 2017), the SHI also estimates the most severe habitat loss for countries in South America, South-East Asia, and sub-Saharan Africa.

In this study, we build on the existing literature and expand it by (a) translating agricultural trade data into data on cropland area required for production, (b) disaggregating animal products into the respective feed items used for their production, (c) looking at changes in countries’ trade patterns over time, and (d) using a biodiversity index directly linked to land-use change and the resulting loss of habitats. We do this using data on the production and trade of agricultural products to estimate recent trends in global agricultural land use. We show how these trends are driven by a changing consumption by focusing on three diferent aspects. First, we quantify, on the level of individual countries, their relative import dependency, indicating how much of their cropland footprint occurs outside their borders. Second, we look at the trade and production of certain products and their share in a country’s export portfolio. Finally, we use bilateral trade data to calculate “imported” biodiversity threats associated with the consumption of agricultural products. To complement the SHI, we derive new indices that consider the consumption-side impacts.

By doing so, we address the following research questions:

1. What global patterns of trade and consumption can be observed and how have they evolved in the recent past?   
2. What is the relationship between import dependence and a land-use-based biodiversity indicator, i.e., do exporting countries have a higher loss in species’ habitats than importing countries?   
3. What products are driving the expansion of agricultural areas in the countries that experience the highest loss of species’ habitats?   
4. How can a consumption-based measure of imported species’ habitat loss be designed to complement the production-based perspective? What insights can be obtained by such an additional measure?

The inclusion of the consumer perspective is a necessary step forward in the debate around sustainable food systems. The data shown in this study can be used to quantify the demand side of the production and trade of agricultural products, and indices like the ones presented here can complement existing national indices in ranking sustainability

eforts. To facilitate the discussion, we made all the data used in this study, as well as the respective R-scripts available as an online repository (https://doi.org/10.5281/zenodo. 5751294).

# Materials and methods

In the following, we describe the calculation fow and the data used to calculate consumption-based accounts of cropland use and show how to integrate these accounts with the SHI indicator. Figure 1 shows a fow diagram of the data processing and calculation steps, with the subsection in the method section corresponding to the steps highlighted in the fgure.

# Materials

We used FAOSTAT trade data (FAO 2020), which includes bilateral trade fows of 481 products between 223 countries. This data is available from 1986 to 2018 and it consists of

![](images/e735f5f36e7a3a2c46974124b8eea6eee83d401ec538c14a620553e0ee37ab1e.jpg)  
Fig. 1 Flow diagram of the necessary steps of the calculation (middle), the input data (left), and the decisions taken in the process (right)

reported imports and exports, measured in tons. We also used FAOSTAT production data for primary crops and livestock items. This data contains information about the production in tons and, for crops, the yield (in tons per hectare).

For the conversion of animal products into cropland items used as feed, we included additional information from the FAOSTAT Food Balances (old methodology) for both crops and livestock. These contain information on the quantity of crop products used as animal feed for 173 countries.

# SHI as indicator for environmental intactness

The SHI is a measure for ecosystem intactness, estimated by the Map of Life (MOL) project (Jetz and Thau 2015; Powers and Jetz 2019, mol.org/indicators). It is calculated as the sum of suitable habitat of a country’s species assemblage compared to a baseline in the year 2000. The estimations are based on species data covering all terrestrial biomes as well as land-cover information from Landsat and MODIS satellites at a resolution of $1 \mathrm { k m } ^ { 2 }$ . The database includes records for over 20,000 species of terrestrial vertebrate (mammals, birds, reptiles, and amphibians) and invertebrate animals, as well as plants with over 300 million validated location records.

The National SHI is estimated as average habitat decline of all species in a country. For example, an SHI decrease of 0.01 means that all species in this country have, on average, experienced a $1 \%$ contraction in their habitat range compared to the baseline. The indicator has been calculated annually for the years 2001–2013 (epi.yale.edu/downloads, Wendling et al. 2020).

# Methods

# Harmonizing trade data entries

Reported trade data between 200 countries across 30 years are not always complete or consistent. There are, for example, sometimes diferences between a reported import from country A importing from country B, and the corresponding report of an export from country B to country A. There are also sometimes trade fows missing from reports (Gehlhar 1996). To harmonize these reports, we decided to prioritize import reports as being more reliable and only used reported exports to fll missing fows. This is a reasonable assumption and feasible for such a huge dataset. For the entire global trade data, yearly values show diferences below $3 \%$ , in a version that prioritizes reported export fows over reported imports. However, for individual countries and specifc trade links, these diferences can be bigger. We show the specifc diferences and the sensitivity of our results toward this assumption in the Appendix.

# Converting traded items to primary products

The FAOSTAT crop production database contains production data (tons, area harvested, and yield) for 191 primary products. We matched the 481 traded items to these primary products using information about dry-matter content (Krausmann et al. 2008; Kastner et al. 2014; Alexander et al. 2017). The trade volume of each traded item was thus multiplied by the ratio of its dry mass and the dry mass of its respective primary product. Detailed information on the matching of the items and the conversion factors can be found in the online data repository. There is a special case for traded and produced sugar that required a more sophisticated transformation, as sugar is processed from the primary crops sugar cane and sugar beet. Details on this can also be found in the Appendix.

# Identifying producing and consuming countries

The FAOSTAT data is designed to capture all trade fows. Thus, it necessarily includes double counting of products within supply chains. For example, if country A imports products from country B and exports part of it to country C, those would result in separate entries in the database. While this captures the individual trade fows, it does not allow a straightforward link between the production (i.e., cultivation of the respective crop) and consumption (i.e., the physical use of the products derived from it, either as food or for material or energetic purposes) of these products.

We thus calculated the apparent consumption following Kastner and colleagues (Kastner et al. 2011) where data on imports and exports of a country (of both primary crops and products processed from them), plus the production of primary crops are used to calculate: (1) import serving a country’s consumption, (2) export originating from a country’s production, as well as (3) consumption originating from a country’s own production. This method eliminates data on re-exports and associated issues of double-counting trade fows. This enables linking consumption patterns to environmental impacts of agricultural production, as both consuming and producing countries for crop products are clearly identifed.

For the mathematical formulation of the approach, please refer to the original publication (Kastner et al. 2011). Please note that, in contrast to their approach, we used the Moore–Penrose generalized inverse of the matrix (Ben-Israel and Greville 2003) provided by the pinv() function in the pracma R-package which enables these calculations also for singular input matrices (Borchers 2019). The results for non-singular matrices and the interpretation of the values match those of the approach described in the original publication (Kastner et al. 2011).

# Accounting for the consumption of animal products

While the production and consumption of primary animal products can be established in the same way as for other agricultural items, their production itself consumes agricultural products via the use as feed. To account for agricultural production embedded in the trade of animal products, we calculated the amount and composition of animal feed for each country and each year. We did this using additional information from the FAOSTAT Food Balances (old methodology) on feed use of primary products, and a set of weighting factors. This allowed us to calculate how many tons of feed input are needed to produce one ton of the respective animal product. The values in the crop database were then adjusted by subtracting the amount of crop products used as feed calculated via this procedure to avoid double counting. For instance, if a country imports large amounts of animal feed and exports large amounts of animal products produced from it, its consumption of the respective crop will be lower after the application of this calculation step and redistributed to the countries that import and consume the animal products.

In FAOSTAT, commodity balance items are reported in a diferent product resolution than in the trade or production data (e.g., as “other oil crops” or “vegetables”). We thus re-attribute the commodity balance values to the respective FAO primary items according to the country’s proportional supply.

# Converting tons to area

As a fnal step, and to calculate the area impact of agricultural production, we transformed the fows of primary products (in tons) into area harvested required for their production using annual and country-specifc yield information of the producing country (Kastner et al. 2014). Please note that our values correspond to the area harvested each year, which is diferent from total cropland area, due to multi-cropping and fallow areas (Monfreda et al. 2008).

# Linking bilateral trade data with SHI as environmental indicator

To estimate a country’s contribution to the global loss in species’ habitat via the consumption of agricultural products, we calculated two indicators of “consumed Species Habitat” (cSH).

For the frst indicator, we summed up all incoming trade fows of a consumer country $( j )$ in the years from 2000 to 2013, including the share of domestic production that is consumed domestically, after multiplying it with the reported loss in SH in the producing country $( i )$ We then normalized the value by dividing it by the total

of incoming trade fows, i.e., the apparent consumption. Trade fows from countries that did not have an SHI (countries with land areas less than $1 0 0 \mathrm { k m } ^ { 2 } ,$ ) were ignored for this calculation

$$
\mathrm {c S H} _ {-} \mathrm {a v} _ {j} = \frac {\sum_ {i} \operatorname {t r a d e} _ {j , i} * (1 0 0 - \mathrm {S H I} _ {i})}{\sum_ {i} \operatorname {t r a d e} _ {j , i}}.
$$

This value indicates the average amount of species’ habitat lost per hectare consumption in country $j$ . Comparing this to the original SHI (cSH_av—SHI) shows how much higher or lower the average impact of a consumed hectare is compared to one of domestic production.

For the second indicator, we multiplied cSH_av by the ratio between incoming (consumption) and outgoing (production) trade fows of a country

$$
c \mathrm {S H} _ {-} \mathrm {r e l} _ {j} = c \mathrm {S H} _ {-} \mathrm {a v} _ {j} * \frac {\sum_ {i} \mathrm {t r a d e} _ {j , i}}{\sum_ {i} \mathrm {t r a d e} _ {i , j}}.
$$

This gives an understanding of how much a country is relying on production that is causing habitat loss. Comparing this to the original SHI shows whether a country’s consumption or their production is the main driver of their species habitat footprint. Consequently, this comparison indicates whether consumer-side or production-side interventions would have the larger efect.

Relating the SHI to the expansion of agricultural land does not mean that we assume that it is the only driver of habitat loss. However, it assumes that this relationship is constant over time and across countries.

# Results

The resulting dataset is large and complex and can be used to answer a number of questions. Following the research questions outlined above, we group them into three different categories. The frst part focusses on national-level trade and consumption patterns. The second part focuses on the results at a primary product level. In the third part, we used bilateral trade information to quantify “consumed” environmental impact estimated by changes in Species Habitat Index and corrected for a consumption

perspective. All subsequent values of import, export, production, or consumption refer to the respective area needed for these components, not the actual trade volumes.

# National trade profles and their recent dynamics

The resulting database contains data on 223 countries, for which we quantifed fve headline values: (1) production, the amount of cropland in a country (as reported in the FAOSTAT database), (2) export, the amount of cropland in a country for export production, (3) local, the amount of domestic cropland for local consumption (calculated as diference between production and export), (4) import, the amount of cropland supplying a country’s consumption from imports, and (5) consumption, the amount of cropland required for a country’s (apparent) consumption, (import + local). Figure 2 shows how the fve values relate to each other.

In Fig. 3, we show results for the 25 largest contributors to agricultural production and consumption (complete results can be found in the Supplementary Information). Together, these countries host more than $7 3 \%$ of the global cropland area and their consumption requires $6 8 \%$ of global cropland area. Using the fve headline values and the ratios between them, we could characterize trade profles of all these countries. First, the size of the bars indicates the total area these countries contribute to the agricultural production and consumption. We see that this is dominated by China and India, who together account for more than $2 5 \%$ of both total production and consumption.

Second, if the import (red bar in Fig. 3) is bigger than the export (green), countries can be characterized as net importers in terms of cropland area. In Fig. 3, this also means that the total bar of a net importer is right-heavy, which is for example the case for China, Mexico, Iran, Germany, and Japan. On the other hand, net exporters are characterized by a larger green bar and a left-heavy total

![](images/6e87087098a0a184cde9c30cdf99a26631dbd453eb8e667ab85c294ef477021c.jpg)  
Fig. 2 National trade profle of the United States of America in 2012 (as median of 2011–2013) using fve headline values (see text for the defnition). This example shows that production in the US used 102.77 ha of cropland, of which they exported around $4 0 \%$ . At the same time, they consumed agricultural products produced on 74.80 ha of which they imported about $1 7 \%$ . This makes the USA a net exporter of agricultural products in 2012, with a large part of their domestic production $( \sim 6 0 \% )$ being consumed locally

![](images/39c7f36b72e239a7c7e9238484192702c208b1ede3bfa01a5cdd4cd21f474c92.jpg)  
Fig. 3 National trade profles of the 25 largest contributors to the global production and consumption of cropland areas for 2012. Values are in million hectares of cropland area harvested. Numbers show “export” (next to the green bar), “local” (in the middle), and “import” (next to the red bar). The values for total production and consumption are not shown for visualization reasons, but can be calculated as “export” $^ +$ ”local” (for production), or “local” $^ +$ “import”  (for consumption), respectively (see also Fig.  2). The black line is centered through the middle of the brown bar, helping to visualize whether a country is a net exporter (green bar is bigger than the red, the sum is left-heavy) or a net importer (red bar bigger than green, right-heavy)

(India, USA, Brazil, Argentina, Canada, Ukraine, Australia, and Kazakhstan). All other countries in this list have an export-to-import ratio close to 1.

Finally, we can distinguish countries based on the relative amount of local production that is not exported (“local”, brown bars in Fig. 3). This allows us to identify countries that exhibit balanced trade patterns but vary in their contribution to the global trade of agricultural products. Nigeria and Pakistan, for example, consume many of their produced goods locally and do not contribute a lot to international trade, whereas France relies more on imports, but also exports a lot, i.e., has a relatively smaller “local” component.

A diferent way of characterizing a country’s trade profle is by calculating the relation between a country’s relative export areas (share of export areas in the total production

area) and relative import areas (areas for imports divided by total area for consumption). Placing the results along two axes shows the relevance of trade for the country and whether a country can be considered a net importer or a net exporter in terms of cropland area (Fig. 4).

Figure 4a shows a conceptual overview of this representation by indicating where some of the extreme cases would lie in such a plot. We plotted the respective bars from Fig. 3 to allow comparison. This visualization allows us to get a sense of the distribution in the entire dataset in the year 2012 (Fig. 4b). In this graph, countries that are located in the upper left triangle are considered net importers of cropland area, whereas those in the bottom-right triangle are net exporters of cropland area. Countries that are located close to the diagonal are more or less balanced in terms of cropland trade.

Generally, we found that there are more importing than exporting nations and that there are quite a few countries that rely heavily on imports, such as Japan, Korea, Saudi Arabia, and The Netherlands, with more than $7 5 \%$ of their consumed area being imported. Another group of major importing countries, including the United Kingdom, Germany, Italy, and Egypt, still import more than half of their consumption in terms of area. On the side of exporting countries, there are a few which export more than half of their production, including France, Malaysia, Côte d’Ivoire, and Paraguay. There are also quite a large number of countries in the bottom-right corner that mainly produce for their own domestic demand and do not import a lot.

The positions of countries in Fig. 4b are entirely dependent on relative values and do not refect absolute trade volumes. This is why, for example, two of the biggest importing countries, China (CHN) and India (IND), are plotted next to countries like the Philippines (PHL) and Madagascar (MDG), respectively. Their total imports and exports are much higher (see Fig. 3 or Appendix), but so is their local production and consumption. Thus, their respective ratios of export overproduction and import overconsumption are similar.

For the highlighted countries, we also plotted the change of relative import and export through time (from 2000 to 2012). With only a few exceptions, all highlighted countries increased their relative import during that time (moving up on the y-axis). At the same time, most of the countries also increased their relative export (moving right on the x-axis). For the entire dataset, we found that 159 countries increased their relative imports, 127 increased their relative exports, and 108 showed increases in both values.

# Product‑level trade profles

Looking at data at the level of individual products provides in-depth insights into patterns and dynamics in specifc

![](images/bf1ab55756c42ef976ba27511b514ad49d4de8c5680859b2784fa43f2e821211.jpg)

![](images/ec94bae1c71b43c2052726075b0b2ab6c56192fb760ba5bf5cb4eebaca496e96.jpg)  
Fig. 4 a Conceptual plot of four extreme cases of national trade profles: Japan (JPN) is importing most of its consumption and exports only very little, Australia (AUS) exports more than $8 0 \%$ of its production and only imports very little. The other two cases, France (FRA) and Pakistan (PAK), both have a balanced trade statistic (relative export/relative import $\approx 1$ ). However, they difer in the amount of production consumed locally. Pakistan consumes a lot of its local production and thus scores lower on both relative export and relative import than France, which has a much higher gross fux. b Values of   
relative export and relative import for all 223 countries in the dataset for the year 2012. Selected countries are labeled with their respective ISO3 Codes. Red dots represent the 20 countries with the largest import of agricultural products; green dots are countries that show the strongest decrease in Species Habitat Index. Two countries are part of both groups, Vietnam (VNM) and Indonesia (IDN), they are colored in purple. For these 38 countries, we also show with lines, how their position along the axes has changed from the year 2000 (beginning of the line) to 2012 (end of the line, colored dot)

countries but is too complex to present for the entire dataset. We thus picked three countries, Paraguay, Malaysia, and Côte d’Ivoire as examples (Fig. 5). These are the countries with the highest species habitat loss, according to the SHI. All three use more than half of their cropland area for export production (see Fig. 4b). They also represent three diferent world regions and diferent production systems that can be considered representative for these regions.

We found that the exports of these three countries are all dominated by a single product group. Paraguay mainly reported exports of soybeans $( 6 6 \% )$ , maize $( 1 6 \% )$ , and wheat $( 1 1 \% )$ , as well as some other cereals and oilseeds. Most of its exports $( 6 7 \% )$ were found to be used as animal feed in other countries. Malaysia’s exports in 2012 were dominated by palm oil $( 8 6 \% )$ and rubber $( 1 1 \% )$ . Some of the palm oil and some other oilseed crops were found to be used as feed for animal products (totalling only about $4 \%$ ). Finally, Côte d’Ivoire reported exports of cocoa $( 5 7 \% )$ , cofee $( 1 1 \% )$ , rubber $( 3 \% )$ , and cashew nuts $( 2 0 \% )$ , as well as some oilseeds (totalling about $7 \%$ ). The share of products used as animal feed was negligible (less than $1 \%$ ).

An additional analysis of the diferences in production area between the years 2000 and 2012 showed that the most exported goods were also the ones responsible for most of the expansion of agricultural areas in the respective countries (see Supplementary Data, Sheet 5). For Paraguay, we

found that soybeans were responsible for $6 6 \%$ of the total expansion in agricultural area. In Malaysia, oil palms had a share of $1 4 2 \%$ of the total expansion, meaning that their production replaced the existing production systems on top of the expansion into previously unused land. Finally, for Côte d`Ivoire, we could show that cashews and cocoa both contributed roughly a third to overall expansion $34 \%$ and $3 0 \%$ , respectively).

# Bilateral trade data and consumption‑based species habitat indices

Finally, the dataset also allowed us to look at the bilateral information, i.e., corrected exports from producer to consumer country. In Fig. 6, we display export fows from countries with a high loss in SH (more than $2 \%$ of species habitat lost from 2000 to 2013). The export fows from these 20 countries equalled about $1 9 . 6 \%$ of the total trade volume in 2012. We found that the picture is dominated by exports from Brazil, which is exporting to almost every other country, but with the vast majority of $3 2 \%$ of its exports going to China, followed by $3 . 9 \%$ to Japan, $3 . 5 \%$ each to Iran and Germany, and $3 . 2 \%$ each to South Korea and France. Interestingly, India, which is also among the largest importers (in terms of total area), only imports around $0 . 5 \%$ of Brazil’s exports. For the three countries we highlighted in Fig. 5, we

![](images/07ceba1fec83b3439f8d240c72f9a6e5a19d30fbf1d3d87842893098e6fbb1e3.jpg)

![](images/34f1dacbf80531b30a8f36560d9370534e4c55a538371eab46a2fd33f822992c.jpg)  
Fig. 5 Composition of exports of the three countries with the most severe loss in species’ habitat in 2013: Paraguay, Malaysia, and Côte d’Ivore. This hierarchical treemap splits the entirety of the export volume along three levels: The frst split diferentiates whether the product is consumed directly (Food), or whether it is used as feed for the production of animal products (Feed) (gray transparent boxes); The second split occurs at the level of product classes which are depicted by the diferent colors; and   
fnally, the last level shows the primary product itself indicated by the labels. The size of each box corresponds to its contribution to the total export. We omitted the names of small quadrants for a better readability. Although the visualization does not allow a direct comparison between the displayed countries, it is worth noting that the cropland areas devoted to export production are quite similar (PAR 4.36 Mha, MYS 4.32 Mha, and CIV 4.81 Mha)   
Fig. 6 Export fows from the countries with more than $2 \%$ loss in SH (bottom). The other countries are ordered according to SH loss from lowest at the left (SAU, EGY) to highest on the right (JPN, THA). The largest importers are shown in black (and with ISO codes), whereas all other countries are grayed out

found that they not only difer in the items they export, but also where the exports go to. For Paraguay, we found that $1 3 \%$ of the country’s exports go to Brazil, $9 \%$ to Russia, and $6 . 4 \%$ to Germany. Malaysia’s exports go mainly to China $( 2 1 \% )$ , India $( 1 1 \% )$ , Pakistan $6 . 4 \%$ , not shown in Fig. 6), and the US $( 5 . 8 \% )$ . Finally, Côte d’Ivoire reports $1 4 \%$ of exports going to the US, $1 2 \%$ to India, and $7 \%$ to Germany.

This bilateral trade information can be used to assess “relocated” environmental impacts, such as the loss in species habitat quantifed by the SHI. In the original dataset of SH loss (Fig. 7a), countries like Paraguay, Honduras, Brazil, Madagascar, Côte d’Ivoire, Malaysia, and Indonesia show high values, indicating that they lost a lot of species habitat in the years from 2001 to 2013 (between 4 and $9 \%$ ). On the other hand, most countries in Europe, Africa, and the Middle East have small values of SH loss, meaning that they lost almost no additional habitat since 2000.

The SHI estimates habitat conditions in the producing country. To quantify the impact of consumption on habitat loss, we calculated new indices of consumed habitat loss based on a combination of the original SHI data and the trade data (see methods). These consumption-based indices reveal a strikingly diferent pattern. The measure for the average habitat loss per consumed hectare (cSH_av) shows that quite a number of countries have higher values for consumption than for production (Fig. 7b). These results highlight that in these countries, each hectare linked to consumption is, on average, associated with a higher value of SH loss than the country has in the original SHI data. This is particularly true for countries in Western Europe, North America, and the Arabic Peninsula which have relatively low rates of species’ habitat loss domestically but import substantial loss from countries with higher SH loss. Interestingly, some countries also show high values in cSH_av despite not being net importers. This happens because their

![](images/6b7a92ffd59e2904c687acf74bb338526e75018bd1d80ec66975d99d7f9b4d3a.jpg)  
a   
Decline in Species Habitat

![](images/4b24cde6afaa16f57791fa0a3063c4c169567babe0cf33606f7e06fb53d65ab9.jpg)  
b   
Average impact of consumption

![](images/c2813125836957483194d6621a04859ec270b4fd61be938c960599aeb7dc0825.jpg)  
Impact of consumption relative to production

![](images/1ea993a0e2c8d942300062c25ee51044c2ee4094fc66d98ae7fe626412063f48.jpg)

![](images/c5b10a80ad11e25634dc710bec0ac5cd338a50c74a6e77fa7b85e6967557c0c1.jpg)  
Fig. 7 Maps of loss in Species Habitat Index (SHI). a shows the original data on loss in SHI estimated by the Map of Life project. Colors indicate the percentage of habitat lost between the years 2000 and 2013. b and c show estimated complementary SH indices that account for virtual trade fows of cropland. b shows the values as mean of the SHIs supplying a country’s cropland consumption, weighted by the amount of cropland demand per source country. c Further adapts this by multiplying the country values of b with the   
ratio of cropland area consumption divided by domestic cropland use, implying that SH loss will be allocated from net exporting toward net importing countries. Colors in b and c indicate changes compared to the original SHI data (a). Lower values are indicated by blue colors, whereas higher values are shown in red colors. Countries in gray show no or very small changes. Countries with no data are shown in white

imports are mainly stemming from countries with SH losses higher than the domestic values (Chile, Uruguay, Australia, and New Zealand).

Countries where the value of cSH_av is lower than the original SHI are those countries where the domestic SH loss is higher compared to the average SH loss of their trade partners. This means that the pressure on domestic species habitats is higher, on average, than the pressure of the countries where they source their imports. These countries include, for example, Guatemala, Malaysia, Côte d’Ivoire, Madagascar, Indonesia, Mexico, Japan, and Finland.

The second indicator, cSH_rel, calculates the consumption-based species habitat loss relative to a country’s production in terms of cropland area (Fig. 7c). This gives additional information on a country’s net trade patterns and suggests how much importing countries rely on production in other countries with a higher SH loss. By comparing the values to the original SHI data, we can show whether a country’s total production or consumption is the main driver of current global habitat loss. The general picture is similar to the comparison with cSH_av. However, there are some marked changes. Especially, the big net exporters of cropland areas in the Americas and those in Southeast Asia/Oceania have lower values. On the other hand, countries that consume a lot compared to their production, i.e., net importers of cropland, show now markedly higher values. Examples here include Iceland, Western Europe, Northern Africa, Southern Africa, The Middle East, China, and New Zealand.

Table 1 shows the original ranking of selected countries according to the SHI and the ranking of the same countries in the two new indices. The values for all countries, as well as the maps with the absolute values can be found in the Appendix.

# Discussion

Slowing biodiversity loss caused by agricultural production is a complex task that goes beyond the traditional conservation approaches as the sole focus on production-side solutions will necessarily create conficts between production and conservation goals (Henle et al. 2008). Sustainable solutions thus require an additional consumption-level perspective which eventually allows the easing of pressure on the world’s land systems (Erb et al. 2016). In this study, we show that by using data on trade and production of agricultural products, we can (1) identify countries that rely heavily on the import of agricultural production and thus create a large land-use footprint outside their borders; (2) align relative imports and exports with impacts on local biodiversity threats; (3) identify individual exported products that make up substantial amounts of a country’s production and thus contribute to this land-use displacement; and (4)

Table 1 Countries’ ranking in the original SHI data and the two new indices cSH_av and cSH_rel. Values are shown for the top and bottom ten countries according to the original SHI ranking   

<table><tr><td>Country</td><td>Rank SHI</td><td>Rank cSH_av</td><td>Rank cSH.Rel</td></tr><tr><td>Iceland</td><td>1</td><td>117</td><td>163</td></tr><tr><td>Western Sahara</td><td>2</td><td>1</td><td>1</td></tr><tr><td>Bahamas</td><td>3</td><td>85</td><td>152</td></tr><tr><td>Oman</td><td>3</td><td>96</td><td>158</td></tr><tr><td>Vanuatu</td><td>5</td><td>3</td><td>3</td></tr><tr><td>Timor-Leste</td><td>6</td><td>5</td><td>6</td></tr><tr><td>Central African Republic</td><td>7</td><td>2</td><td>2</td></tr><tr><td>Eritrea</td><td>7</td><td>6</td><td>8</td></tr><tr><td>Iraq</td><td>9</td><td>25</td><td>47</td></tr><tr><td>Yemen</td><td>10</td><td>52</td><td>102</td></tr><tr><td>...</td><td></td><td></td><td></td></tr><tr><td>Viet Nam</td><td>156</td><td>152</td><td>136</td></tr><tr><td>Belize</td><td>157</td><td>156</td><td>123</td></tr><tr><td>Côte d&#x27;Ivoire</td><td>158</td><td>157</td><td>111</td></tr><tr><td>Honduras</td><td>159</td><td>155</td><td>134</td></tr><tr><td>Cambodia</td><td>160</td><td>159</td><td>141</td></tr><tr><td>Laos</td><td>161</td><td>162</td><td>147</td></tr><tr><td>Madagascar</td><td>162</td><td>163</td><td>146</td></tr><tr><td>Guatemala</td><td>163</td><td>161</td><td>143</td></tr><tr><td>Malaysia</td><td>164</td><td>158</td><td>137</td></tr><tr><td>Paraguay</td><td>165</td><td>166</td><td>100</td></tr><tr><td>Nicaragua</td><td>166</td><td>165</td><td>148</td></tr></table>

use bilateral trade data to design additional indicators for “traded” biodiversity loss.

# Major importers and exporters of agricultural products: state and trends

Our data shows a broad spectrum of national trade patterns, from countries that rely almost entirely on imports to countries that use up to $8 0 \%$ of their cropland area for export production. Although previous studies have suggested fxed thresholds for the classifcation of countries as importers or exporters (MacDonald et al. 2015), our data shows that there is a more continuous distribution of national trade statistics. Also, we could show that these values are dynamic over time and have changed considerably between 2000 and 2012. Observing such temporal trends is important, for instance, to observe if stricter local environmental policies lead to an overall reduction of impacts or to a leakage of environmental burdens to other countries (Lima et al. 2019).

The temporal trends shown in Fig. 4b suggest that there is a trend toward more imports, but also more exports. This general trend toward an increased importance of

international trade is not necessarily a bad thing, as trade of agricultural commodities is considered to increase food security through substitution efects and changes in dietary diversity (Godfray et al. 2010; Martin 2017). However, with current trade policies and production conditions, benefts are not distributed equally and are heavily skewed toward developed countries (Xu et al. 2020; Geyik et al. 2021).

Our data also shows that in 2012, there were still quite a few countries in the bottom-left corner (Fig. 4b) that, despite also showing an increase in exports and imports, still heavily rely on domestic production. If populous countries like India, Nigeria, and Pakistan would increase their agricultural trade volumes in line with past trajectories of other countries, this would greatly afect the world’s trade network, as well as their domestic agricultural systems (GRAIN 2020).

# Products that contribute to land‑use displacement

Our product-level analyses indicate that overall exports are often dominated by a few commodities. Our three examples of Paraguay, Malaysia, and Côte d’Ivoire show that these differ between countries, often linked to the climatic niches of the crops (DaMatta and Ramalho 2006; Pirker et al. 2016). Additional analyses show that also most of the production of these dominating commodities is exported. For Paraguay, we found that $9 8 \%$ of the soybean production is exported, for Malaysia, it is $7 3 \%$ of all palm oil produced, and for Côte d’Ivoire, we found export shares of $9 9 \%$ for cocoa, $7 4 \%$ for cofee, and $1 0 0 \%$ for rubber, respectively. Our results also show that, in these countries, the dominating crops are also the ones driving the expansion of agricultural area between the years 2000 and 2012. According to the MOL and the IUCN, the loss of habitat associated with this expansion is threatening such iconic species as the Gian Armadillo (Priodontes maximus), which is severely impacted by agricultural expansion in Paraguay; the Bornean Orangutan (Pongo pygmaeus) which cannot survive in the expanding oil palm plantations of Malaysia; and the Zebra Duiker (Cephalophus zebra) which has lost almost all of its remaining habitat in Côte d`Ivoire where it is confned to primary rainforests in the south-west.

However, the use of national trade and production data does only allow for correlative analyses. That means, we can show where an expansion of production coincides with an increase in exports (see Figs. 4 and 5). Such national-level data are not necessarily well suited to inform sub-national interventions (Godar and Gardner 2019). A spatially explicit analysis of soy and sugar production in Brazil, for example, showed that exports to China are linked to less deforestation than those to the EU, because they source from diferent regions in Brazil (Godar et al. 2015). Such a fne-scaled approach is the aim of the TRASE initiative (www.trase.

earth) but presently only feasible for a small number of producer countries and a subset of produced items.

The production of agricultural products for the global market increases the risks associated with global market volatility. This can lead to sharp increases in domestic commodity prices, as for example, soybean prices in Brazil (Flexor and Leite 2017), but also to drastic price drops, for example, recently reported for cocoa (Voora et al. 2019). In general, the export of agricultural produce as an income stream is considered a good way of increasing the GDP, especially of developing countries, and access to markets and associated benefts for a country’s GDP is one of the Sustainable Development Goals (SDG 17.11, United Nations 2017). However, in the past, economic pressure has led to unsustainable production modes such as large monocultures (Benton et al. 2021) and has caused widening inequalities in land ownership (Anseeuw and Baldinelli 2020).

Production systems, such as cofee, palm oil, rubber, or cocoa, are also among the biggest threats to biodiversity (Lenzen et al. 2012). Especially, when production systems replace ecosystems formerly rich in biodiversity, such as tropical forests, these impacts are most severe. This is particularly true for oilseeds, including soybeans (Fehlenberg et al. 2017; Marques et al. 2019), as well as for cofee, cocoa, and rubber (Chaudhary and Kastner 2016).

The general trade-of between economic benefts and socio-ecological consequences is debated in the recent literature (Lambin and Meyfroidt 2011; Klasen et al. 2016; Grass et al. 2020) and mechanisms like, for example, international certifcation standards (Tscharntke et al. 2015) have been discussed to guide future developments toward more sustainable solutions. A recent paper, for example, discusses the need for agricultural land in the context of the land-system change planetary boundary framework and a resulting “fair-share” allocation of the remaining land area (Shaikh et al. 2021). Such data and this debate are very much needed as the increased demand for food due to a growing world population (Gerland et al. 2014) and developments like the demand for biofuels (Cudlínová et al. 2020) lead to an everincreasing pressure on land systems.

# Using bilateral trade data to calculate an index of imported species’ habitat loss

Country-level sustainability metrics, such as the SHI, are helpful in estimating progress toward established policy goals, such as the Sustainable Development Goals (United Nations 2017), and in guiding future management and policy targets. However, by their design, they typically do not take into account distant impacts and are thus falling short in an important aspect of globalization. Several studies have shown that global biomass fows, such as the trade of agricultural products, can lead to quite severe diferences in

where the environmental impact is happening and where it is caused. For example, $3 0 \%$ of the threats for species listed by the IUCN were due to international trade, with the USA, Japan, and the European Union having a total of $4 4 \%$ of their biodiversity footprint linked to imports from other countries (Lenzen et al. 2012). Similarly, Western Europe and North America were found to be responsible for $4 8 \%$ of the global reduction in bird species richness (Marques et al. 2019), and industrialized countries with a high GDP were shown to be the main importers of biodiversity impacts, mainly caused in tropical countries (Chaudhary and Kastner 2016).

Using the SHI as an indicator of biodiversity, we can go beyond endangered species (as in Lenzen et al. 2012) or specifc species groups (as in Marques et al. 2019). The SHI ofers an insight into the global distribution of animal and plant species habitats and their vulnerability based on the best data currently available. Our results, however, echo those of the previously mentioned studies. We found a general trend of the indices for an imported habitat loss being higher in the Global North. The higher values in cSH_av in these countries, compared to the original SHI, show that their footprint in loss of species habitat occurs mainly outside their borders, whereas the pattern of the cSH_rel suggests that their consumption is dependent on production in countries with a higher loss in suitable species habitat. Although the trends are similar, they are weaker for big producers (like the USA) and stronger for small producers (like Iceland and the Netherlands). This is in sharp contrast to the original SHI data, where countries in North/Western Europe and the Middle East ranked highest. We found that they drop in ranks (Table 1) when considering the consumption side of species’ habitat loss. On the other hand, we did not necessarily fnd a rise in rank for countries with a high SH loss. This is due to the fact that most of their consumption is produced locally. However, if they are major crop exporters, they have a higher rank in cSH_rel (like Paraguay or Côte d’Ivoire). Such a complementary index can thus help in creating a more complete picture of habitat loss driven by agricultural expansion.

Our results help to provide information and stimulate discussions for designing more efective policies for biodiversity conservation. For instance, based on the results, we can identify where consumer-side or producer-side interventions would have the greatest efect on global biodiversity threats. In a country where most of the habitat loss is associated with production (e.g., Brazil, Paraguay, Argentina, Malaysia, Guatemala, and others that appear dark blue in Fig. 7c), production-side measures, like protected areas or reforestation, would have the greatest efect on local biodiversity. Countries with a high external footprint (red colors in Fig. 7c) would contribute best by promoting changes in domestic consumption patterns or diets. However, it will be necessary to address both production and consumption

issues when redesigning our world’s food systems in support of biodiversity (Benton et al. 2021).

# Limitations

A global-level analysis naturally comes with the caveat that reporting is not always of the same quality in all countries. The FAO data used in this study rely on input from national agencies that might vary in quality. We tried to deal with this by preferring reported imports over reported exports (see Methods). We explored the consequences of this choice in an additional analysis that can be found in the Appendix. We found that on a global level, the results were very similar. However, on a national level and on the level of individual trade links, there were some marked diferences. Please refer to the Appendix for a more detailed analysis.

Another issue we tried to solve is the varying product resolutions in diferent data products of the FAO. The production data, for example, has a detailed reporting of all the crops (e.g., linseeds, safower seeds). The Commodity balance data, however, group the less important items into groups like “other oilcrops”. As we used these data to calculate the feed use of these items, we had to later disaggregate them again into the production data resolution. We did this using production quantities, which means that we could not account for a preferential use of some of these crops in an aggregate as feed. These problems with reporting can lead to a scenario where a country exports more of a product than it reports on production. As a consequence of the normalization algorithm, this creates negative values for domestic consumption (as domestic consumption + expor $=$ production). These have to be dealt with when doing additional analyses. For the calculation of cSH_av and cSH_rel, as well as for the visualizations in Figs. 5 and 7, we excluded them. By directly relating the species habitat loss to the production of agricultural products, we neglected potential other drivers like logging or mining. Although agricultural expansion is by far the most widespread form of land-cover change (Foley 2005; Díaz et al. 2019), this introduces some uncertainty when these products are traded between diferent countries. Future research could implement similar data on, for example, forest product trade to refne this approach. Also, there is a trade-of between “expansion of” and “intensifcation on” existing agricultural areas to meet increased demand. The SHI is linked to the former, but biodiversity loss has also been reported for the latter (Beckmann et al. 2019). Additional biodiversity metrics on population sizes in agricultural areas could thus complement this approach (see for example Kehoe et al. 2017).

Finally, using national-level data on trade, production, and biodiversity impacts, we cannot provide a spatially explicit or regional analysis. This is one reason why we

decided to use the SHI as a biodiversity indicator, as its national-level resolution fts the FAO data. Moving beyond the national level would open a number of interesting future research avenues. A spatially explicit biodiversity indicator (e.g., Hoskins et al. 2020) could be coupled with spatially explicit land-use data (e.g., You et al. 2014) and fner resolved trade data. This could explicitly assess which crops are responsible for an increased threat to biodiversity, and when coupled with highly resolved trade data, how much of it is due to an increase in exports.

# Conclusion

A substantial amount of agricultural goods is produced for export. In 2013, $2 3 . 4 \%$ of all area under cropland production were used for the production of exported goods which is an increase from around $1 7 \%$ in the year 2000. This development, along with an increase in domestic demand, has led to quite a number of problematic developments, such as the reduction of species’ habitat. However, the most severe consequence is that it has led to a quite substantial split between countries that sufer from environmental problems and the ones that proft from them. The analyses presented in this study, and the data that come with it, allow quantifying the consumer side of global agricultural trade, thus making it possible to trace impacts of the demand side in this complex issue. Data like this can be used to design new nationallevel indicators, accounting for the efect of international trade. Such measures, in turn, can inform policies around the “trade” of environmental impacts and the conservation of remaining habitats.

Supplementary Information The online version contains supplementary material available at https://doi.org/10.1007/s11625-022-01138-7.

Acknowledgements We gratefully acknowledge funding by the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation) under project No. KA 4815/1-1, the German Federal Ministry of Education and Research within the framework of the TransRegBio project (Grant 031B0901A), and the German Federal Ministry for Economic Cooperation and Development.

Funding Open Access funding enabled and organized by Projekt DEAL.

Data availability statement All the data used in this study, as well as the respective R-scripts are available as an online repository (https:// doi.org/10.5281/zenodo.5751294).

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if changes were made. The images or other third party material in this article are

included in the article's Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article's Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http://creativecommons.org/licenses/by/4.0/.

