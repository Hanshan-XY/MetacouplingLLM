# Importing food damages domestic environment Evidence from global soybean trade

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:07:10.140995+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Sun et al. - 2018 - Importing food damages domestic environment Evidence from global soybean trade.pdf
- Year: unknown
- DOI: 10.1073/pnas.1718153115
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This paper examines how international soybean trade affects nitrogen pollution in importing countries, challenging the usual focus on environmental burdens in exporting regions.

The study looks at the global soybean system, with Brazil and the United States as the main exporters and 15 major importing countries, and then zooms in on Heilongjiang Province in northeastern China, a key soybean region in the worlds largest soybean-importing country.

Using a meta-analysis of 168 agronomic studies from six continents, the authors compare nitrogen balances per hectare for soybeans and for four crops that often replace soybeans in importing countries: wheat, corn, rice, and vegetables. Nitrogen balance is defined as fertilizer nitrogen applied minus nitrogen taken up by harvested crops, so positive balances indicate surplus nitrogen that can pollute water, soil, and air. The meta-analysis shows that soybean fields generally have negative or low nitrogen surpluses due to biological nitrogen fixation and low fertilizer needs, whereas the replacement crops have substantially higher positive nitrogen balances.

The authors then link these crop-level differences to changes in land use in top soybean-importing countries between 2010 and 2014. In several destinations, soybean area shrank and was converted mainly to corn and rice, flipping national nitrogen balances on those lands from net removal to large surpluses. Overall, nine major importers saw their aggregate nitrogen balance on converted land shift sharply toward excess, implying increased domestic nitrogen pollution.

An intensive household survey in Heilongjiang, combined with provincial statistics, confirms this pattern. As soybean area declined and land shifted to corn and rice, both per hectare nitrogen application and total provincial nitrogen surplus rose. Decomposition analysis attributes roughly half of the increase to crop conversion and half to higher fertilizer rates.

The paper explicitly applies telecoupling and metacoupling frameworks, showing how distant trade flows trigger land-use and nutrient changes in importing regions. It demonstrates that food imports can create hidden environmental costs at the receiving end, not only in exporting frontiers, and calls for broader assessment of trade-induced environmental impacts and shared responsibility across the coupled sending, receiving, and spillover systems.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via global soybean trade; some intracoupling within importing regions; limited explicit pericoupling.

### Intracoupling
#### Systems
- Agricultural landscapes within soybean importing countries
- Heilongjiang provincial farming system in Northeast China
#### Flows
- Nitrogen fertilizer applied to domestic croplands
- Water use for domestic corn and rice irrigation
#### Agents
- Local farm households and cooperatives
- Provincial and national agricultural agencies
#### Causes
- Domestic crop conversion from soybeans to wheat corn rice vegetables
- Pursuit of higher yields using more fertilizer inputs
#### Effects
- Rising nitrogen surplus and pollution in soils waters and air
- Increased provincial nitrogen imbalance and resource burdens

### Pericoupling
#### Systems
- Not identified.
#### Flows
- Not identified.
#### Agents
- Not identified.
#### Causes
- Not identified.
#### Effects
- Not identified.

### Telecoupling
#### Systems
- Soybean exporting regions in Brazil and United States
- Soybean importing countries including China and other top destinations
- Global agri food trade network for soybeans and substitute crops
#### Flows
- International soybean shipments from Brazil and United States to multiple importers
- Virtual transfer of land use change and nitrogen impacts via trade
- Capital and price signals driving cheaper imported soybeans
#### Agents
- International grain traders and commodity companies
- Farmers in exporting and importing countries
- Global institutions like FAO and national trade ministries
#### Causes
- Global demand for soybeans as food feed and industrial input
- Price competitiveness of imported soybeans versus domestic production
- Trade liberalization and policies incentivizing soybean imports
#### Effects
- Conversion of soybean fields in importers to nitrogen demanding crops
- Increased nitrogen fertilizer use and pollution within importing countries
- Additional water requirements and environmental responsibilities debate across nations

### Cross-Coupling Interactions
- Telecoupled soybean imports trigger intracoupled crop conversion and nitrogen pollution in importing regions
- Environmental spillovers in exporting areas interact with hidden pollution in importing countries
- Trade driven land use changes for other crops like corn and vegetables echo soybean related patterns

### Research Gaps or Limitations
- Nitrogen surplus used as aggregate pollution proxy without tracking specific air or water pathways
- Limited analysis of other traded goods and broader resource impacts beyond soybeans and nitrogen
- Underestimation of nitrogen pollution by omitting deposition mineralization and residual soil nitrogen

### Search Keywords
- telecoupling soybean trade nitrogen pollution importing countries
- crop conversion soybeans to corn rice vegetables
- Heilongjiang China nitrogen balance international food trade

### Extraction Confidence
high
