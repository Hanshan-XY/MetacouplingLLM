LETTER • OPEN ACCESS

# Welfare-based allocation of telecoupled biodiversity loss in global crop trade

To cite this article: You Lyu and Li Chai 2025 Environ. Res. Lett. 20 124054

View the article online for updates and enhancements.

# You may also like

Critical minerals for electric vehicles: atelecoupling review Datu Buyung Agusdinata, Hallie Eakin and Wenjuan Liu   
Perspectives on tipping points in integrated models of the natural and human Earth system: cascading effects and telecoupling Christian L E Franzke, Alessio Ciullo, Elisabeth A Gilmore et al.   
Global virtual water trade and thehydrological cycle: patterns, drivers, and socio-environmental impacts Paolo D’Odorico, Joel Carr, Carole Dalin et al.

# ENVIRONMENTAL RESEARCH

LETTERS

![](images/d4e141eb05fd1a16dbdd92fa4ed78393e3f6ef1b80a1341065929fa6b9381ec6.jpg)

Check forupdates

# OPEN ACCESS

RECEIVED

4 June 2025

REVISED

10 November 2025

ACCEPTED FOR PUBLICATION

27 November 2025

PUBLISHED

4 December 2025

Original content from this work may be used under the terms of the Creative Commons Attribution 4.0 licence.

Any further distribution of this work must maintain attribution to the author(s) and the title of the work, journal citation and DOI.

![](images/67e0c1a3cf4685e7d33c874f826def00d821158c115dec4af040fb00e7038325.jpg)

# LETTER

# Welfare-based allocation of telecoupled biodiversity loss in global crop trade

# You Lyu1 and Li Chai $^ { 1 , 2 , 3 , * } \oplus$

1 International College Beijing, China Agricultural University, Beijing, People’s Republic of China   
2 College of Economics and Management, China Agricultural University, Beijing, People’s Republic of China   
3 Beijing Food Safety Policy & Strategy Research Base, China Agricultural University, Beijing, People’s Republic of China   
∗ Author to whom any correspondence should be addressed.

E-mail: chaili@cau.edu.cn

Keywords: biodiversity loss, land-use change, telecoupling, agricultural trade, multi-regional input–output analysis

Supplementary material for this article is available online

# Abstract

Crop cultivation occupies substantial areas of land globally, contributing to biodiversity loss. In the context of globalization, the transnational flow of biodiversity loss footprints caused by international crop trade has raised questions about the allocation of ecological responsibility. However, most existing research tends to attribute such loss exclusively to either consumers or producers, which overlooks a more equitable perspective that integrates both parties’ responsibilities. By drawing upon welfare economics, this study allocates the biodiversity loss arising from crop trade between producers and consumers. We developed a high-resolution distribution map illustrating the allocation of export-induced biodiversity loss among consumers and producers. We also trace the origin of biodiversity loss allocated to consumers. These findings provide a basis for global ecological compensation initiatives and assist policymakers in optimizing land-use strategies.

# 1. Introduction

Global biodiversity is facing unprecedented threats, with agricultural production systems recognized as a major driver of this crisis (Rukikaire and Pitsilidi 2021). By driving large-scale land-use change, agrifood systems transform natural ecosystems, destroy habitats, deplete wildlife populations, and degrade essential ecological functions (Tilman et al 2017, Benton et al 2021, Kong et al 2021). Currently, agriculture occupies approximately $3 8 \% { - } 5 5 \%$ of the Earth’s habitable land (Ellis et al 2010, FAO 2022, Boakes et al 2024), and food consumption is estimated to account for nearly $5 0 \%$ of global land-related biodiversity loss (Marquardt et al 2019).

Globalization has intensified these pressures through the expansion of international trade, which now accounts for over $9 0 \%$ of net land-use change impacts worldwide (Cabernard et al 2024). Global supply chains increasingly decouple consumption from environmental impacts, accelerating biodiversity loss in regions far from final demand (Lenzen

et al 2012, Zeng et al 2022). This spatial disconnect— conceptualized as telecoupling (Hull and Liu 2018) means that consumption in high-income countries often drives land-use change and biodiversity loss in lower-income, biodiversity-rich regions (Kastner et al 2021, Wang et al 2024). For example, food demand from developed economies can lead to deforestation in tropical regions or the outsourcing of agricultural expansion to areas of high conservation value (Cabernard et al 2024). Recent evidence also shows that geopolitical shocks such as the Russia–Ukraine war have telecoupled impacts on cropland expansion and biodiversity risk far beyond the conflict zone, further exacerbating global ecological imbalances (Chai et al 2024).

These telecoupled patterns pose a fundamental challenge for global biodiversity governance. To support effective compensation mechanisms and equitable conservation strategies, it is essential to quantify biodiversity loss embodied in agricultural trade and identify where environmental costs are incurred—and who is responsible for them.

Proper responsibility allocation for biodiversity loss requires integrating two key perspectives. The first is the concept of telecoupled effects, where environmental degradation in producer countries is driven by demand in consumer countries (Liu et al 2013). The second is the life-cycle perspective, which recognizes that biodiversity impacts can occur at any stage along the supply chain, not only at the point of final production (Lenzen et al 2007).

Building on these perspectives, biodiversity loss associated with cropland occupation can be analyzed along two dimensions: spatially—by distinguishing between domestically and trade-induced impacts— and methodologically—by applying productionbased or consumption-based accounting frameworks. A widely used tool for quantifying tradeembedded biodiversity loss is the multi-regional input–output (MRIO) model, which links speciesthreat drivers to economic sectors through concordance matrices and tracks their flow across global supply chains (Lenzen et al 2012).

Within international trade systems, responsibility allocation is central to ecological accountability. Traditional approaches assign responsibility either to producers, who are held accountable for direct land-use impacts (Peters and Hertwich 2008, Kanemoto et al 2014, Liu 2015, Karakaya et al 2019, Tukker et al 2020), or to consumers, who indirectly drive biodiversity loss through their demand (Guan et al 2009, Davis and Caldeira 2010, Steininger et al 2016, Duus-Otterström and Hjorthen 2019). For instance, consumer-oriented frameworks use the Leontief inverse matrix to extend final demand through all tiers of production, and then multiply by environmental intensity coefficients to assign ecological impacts to final purchasers (Munksgaard and Pedersen 2001, Davis and Caldeira 2010, Pan et al 2017). While production-based accounting is widely applied—particularly in climate governance instruments such as national GHG inventories under the Kyoto Protocol and Paris Agreement (Afionis et al 2017)—it has been criticized for enabling responsibility leakage across borders (Hertwich and Peters 2009). In contrast, consumption-based methods emphasize the role of consumer behavior as the ultimate driver of environmental degradation (Sun et al 2022).

However, both production- and consumptionbased approaches have notable limitations. They often fail to fully capture the complexity of global trade systems and the interdependence between producers and consumers (Lambin et al 2001). Attributing environmental responsibility solely to one party risks misallocating accountability and obscuring the true impact chains—paralleling challenges observed in carbon leakage (Lenzen et al 2007, Cao et al 2023, Tang et al 2024b). In practice, the benefits of global supply chains are distributed among multiple actors, implying that biodiversity loss should

also be regarded as a shared responsibility (Sun et al 2022). The concept of shared responsibility has received increasing scholarly attention (Ferng 2003, Lenzen et al 2007, Andrew and Forgie 2008, Cadarso et al 2012). Applications have ranged from national and provincial analyses (Qian et al 2019) to environmental justice accounting frameworks that seek fairer allocations beyond market-based logic (Sun et al 2022). However, many of these models lack a mechanism to differentiate responsibilities at the sectoral or product level within trade flows.

In this study, we develop a welfare-based framework to allocate biodiversity loss responsibility between producers and consumers in international crop trade. Rather than assuming that externalities are already internalized in markets, we adopt a normative approach: if biodiversity loss were priced, the distribution of economic surplus could serve as a basis for fair responsibility sharing. This enables us to link ecological impacts to the economic benefits derived from trade, even when biodiversity costs remain unpriced. Our framework supports commodity-level attribution across trade flows and spatially explicit mapping of biodiversity responsibility. Given the absence of well-established international biodiversity compensation mechanisms, our approach provides a forward-looking tool for responsibility allocation and contributes to closing current governance gaps in global biodiversity protection.

# 2. Method

We assessed biodiversity loss from global crop production and attributed it to both producers and consumers using high-resolution ecological data, international trade modeling, and a welfare-based responsibility-sharing framework. Detailed model equations and data processing steps are provided in the supplementary information (supplementary method section).

Biodiversity loss from cropland occupation was estimated by overlaying spatial crop distribution data with biodiversity impact coefficients across global ecoregions. We used gridded production data from the CROPGRIDS database (Tang et al 2024a), covering 173 crop types, which were aggregated into eight crop groups aligned with the EXIOBASE classification (Stadler et al 2020). Biodiversity impact coefficients were drawn from Chaudhary et al (2015), covering terrestrial taxa including mammals, birds, amphibians, and reptiles. The resulting maps quantify biodiversity loss at a $0 . 0 5 ^ { \circ }$ resolution by crop group and country.

We applied a global MRIO model based on EXIOBASE to trace biodiversity loss through international trade across 49 countries and 200 commodities. This enabled us to distinguish losses driven by domestic consumption from those embodied in

exports. We then constructed satellite accounts linking the spatial distribution of biodiversity loss to economic trade flows. These satellite accounts extend the MRIO framework to incorporate biodiversity-related impacts and trace how trade links to spatial patterns of biodiversity loss.

To allocate trade-related biodiversity loss between producers and consumers, we adopted a welfarebased approach following Jakob et al (2021) and Cao et al (2023). We first monetized biodiversity impacts using species-specific price indices from Lucas et al (2023), then calculated the unit biodiversity external cost for each bilateral trade flow. Country- and commodity-specific elasticities were estimated using the Global Trade Analysis Project model (Aguiar et al 2022), following the approach of Wang et al (2024), by simulating price shocks and observing trade responses. These elasticities were used to simulate market adjustments under biodiversity-inclusive pricing. Changes in consumer and producer surplus were then used to allocate biodiversity loss proportionally to each party’s welfare gains from unpriced externalities.

The final outputs include gridded estimates of biodiversity loss linked to domestic production, exports, and their respective attribution to producers and consumers. To further identify areas under the most severe ecological pressure, we used a quantilebased approach to define biodiversity loss hotspots (Kuemmerle et al 2016). Specifically, we classified the top $1 0 \%$ of grid cells with the highest total biodiversity loss as hotspot regions. Additional methodological details are provided in the supplementary information.

# 3. Results

# 3.1. Distribution of biodiversity loss

Global crop production has led to substantial biodiversity loss through land occupation, totaling 570.2 species lost per year. This impact is spatially concentrated in tropical biodiversity hotspots near the equator, particularly in South America, Southeast Asia, and sub-Saharan Africa (figure 1(a)). Among all ecoregions, the Mindanao–Eastern Visayas rainforests in the southern Philippines exhibit the highest loss (16.0 species/year), followed by the Alto Paraná– Atlantic forests in Brazil, Paraguay, and Argentina (14.7), the Luzon rainforests (11.8), the Eastern Guinean forests in West Africa (11.2), and the Peninsular Malaysian rainforests (10.2) (supplementary table S1). A complete list of biodiversity loss by ecoregion—including total, export-induced, and responsibility-allocated values—is available in supplementary table S1.

Building on this, we further isolate the share of biodiversity loss driven by international trade. Export-induced loss accounts for 229.7 species/year—representing $4 0 . 3 \%$ of the total

(figure 1(b)). These losses remain concentrated in biodiversity-rich crop-exporting regions. The top five ecoregions in terms of export-related loss are again dominated by Southeast Asia and South America: Mindanao–Eastern Visayas rainforests (10.5), Alto Paraná–Atlantic forests (10.1), Luzon rainforests (7.3), Peninsular Malaysian rainforests (6.8), and the Eastern Guinean forests (6.5).

For export-related biodiversity loss, only $3 1 . 9 \%$ is attributed to producer. Producer-attributed biodiversity loss (figure 1(c)) is primarily concentrated in regions with intensive crop production for both domestic and export markets. These include central and eastern Brazil (e.g. Cerrado and Atlantic forests), the inland areas of the Indochinese Peninsula and Indonesia, parts of Central America, and the Sudanian Savanna. These areas experience high ecological pressure from land use while serving as key suppliers in global agricultural trade networks.

In contrast, $6 8 . 1 \%$ of export-related biodiversity loss is attributed to international consumers, amounting to 156.5 species/year—equivalent to $2 7 . 5 \%$ of the overall biodiversity loss (figure 1(d)). The highest consumer-attributed losses are found in the Alto Paraná–Atlantic forests (7.2), Mindanao– Eastern Visayas rainforests (6.7), Luzon rainforests (4.5), the Araucaria moist forests in southern Brazil (4.5), and the Peninsular Malaysian rainforests (4.5). These areas represent hotspots where ecological damage is locally concentrated but driven by demand elsewhere. This structure is further disaggregated by responsibility attribution (figure 1(e)).

Furthermore, the identified areas under the most severe ecological pressure are concentrated in the humid tropics (figure 2), including parts of Southeast Asia, Central and South America, and coastal West Africa.

# 3.2. Comparative allocation of biodiversity loss at the national level

At the national scale, total biodiversity loss from cropland occupation is heavily concentrated in a few tropical agricultural economies. India reports the highest loss (84.4 species/year), followed by Indonesia (49.8), the Philippines (46.6), Brazil (42.5), and China (31.2) (supplementary table S2). These countries combine large agricultural areas with high biodiversity sensitivity, making them global hotspots for land-useinduced ecological loss.

When focusing on export-induced biodiversity loss, the Philippines (29.3 species/year) and Brazil (26.2) rank highest, followed by Mexico (13.8), Sri Lanka (10.9), and Colombia (9.8). Notably, China and the United States, while high in total loss, rank lower in export-induced loss, reflecting their relatively lower dependence on agricultural exports. The national-level structure of biodiversity loss responsibility—decomposed into domestic, producer, and consumer attribution (figure 3).

![](images/98628d4afea0070051b7feecbaf76d2d2df18ea2b25ad6a677280828e060aa69.jpg)  
a

![](images/cd5f46fad942bd936ec2eec04f43d0a0b5b66c9bee787fe99434aa473dad9eec.jpg)  
b

![](images/1e7c60d868c75b1d616dada3a292fd92474796fece85e157c4cb87047a09fd70.jpg)  
C

![](images/a8c9ad4254640634f8c986cdd264af9903fb20df7a34608918ae40441a92734d.jpg)  
d

![](images/773ef02d549a120eae11d1761c68c4d809ffe082a6bfff4cb5316b388ddb8918.jpg)  
0

![](images/8c6b6b009315196d4d0aa68e8e6641d9e33813c9d8180b98b32e439883c1362e.jpg)  
(25,50]

![](images/fe1bd30af557b5a8d736fb34361dfc1f3490163f77940680cc688026fde4c151.jpg)  
(0,1]

![](images/25d845a7c76c0a72f83912125736554d0449e5fb5ed735df0e362d6bdc0a9eec.jpg)  
(50,100]

![](images/34091d5e12fb3c48c09c3a9e6488a43f683902571174fbcc7a55f8e6038802c4.jpg)  
(1,2]

![](images/8adda0bf5b3e5f47a67a6d05040d93ff2beb13ae6c17a90b34571f5faab4f734.jpg)  
(100,3000]

![](images/ff98ba843c99e1b47347124dd706c62cc29d752b86d0f57535ed3dfcd5bec253.jpg)  
(2,5]

![](images/77001d19935c20a9fcf55ef7ed406b4910fc14c7e954b98a6a3453baccd5b438.jpg)  
(3000,20000]

![](images/8480aa574edb7625217bbb2e5b09a7cf2d0cee30579fd1019ee78e67bddd1f14.jpg)  
(5,25]   
Unit: $\pmb { 1 0 } ^ { - 5 }$ species/year

![](images/94f42c8074f91f55a3d7e39b1456eb397ad7b48822f2989d64dcaf2bab74428d.jpg)  
e   
Figure 1. Global biodiversity loss from cropland occupation and its trade-related allocation. (a) Total biodiversity loss; (b) loss induced by export; (c) export-induced loss allocated to producers; (d) export-induced loss allocated to consumers; (e) flow diagram illustrating the proportional relationships among (a)–(d), with $4 0 . 3 \%$ of total loss linked to exports, and $6 8 . 1 \%$ of that attributed to consumers.

In terms of consumer-induced biodiversity loss, which reflects the portion of export-related loss attributed to foreign demand, the Philippines (18.7), Brazil (18.6), and Mexico (8.7) again lead globally, followed by Sri Lanka (7.4) and Indonesia (7.2). These countries not only suffer biodiversity loss domestically but also export significant portions of it through international agricultural trade (supplementary table

S2). In contrast, producer-induced biodiversity loss, which reflects the portion of export-related loss attributed to domestic production, is generally lower, with the Philippines (10.5), Brazil (7.6), Mexico (5.0), Sri Lanka (3.5), Malaysia (3.1), and Colombia (3.0) being the top contributors (supplementary table S2). Crop-level differences also shape national profiles of consumer-induced biodiversity loss. A full list of

![](images/5bee962f4ebdf3ffbef37d7cd4190c3d2bc783854f45988771d47f78c12abe94.jpg)  
Figure 2. Global biodiversity loss hotspots resulting from crop production driven by foreign consumption. Hotspots are defined as the top $1 0 \%$ of grid cells with the highest biodiversity loss, primarily attributed to international consumer demand.

![](images/51b3c646891b8975f202e79c4d465e9731656e10c2396aee61410675812af033.jpg)  
Figure 3. National-level attribution of biodiversity loss from crop production (top 35 countries). Bars show the decomposition of biodiversity loss into three components: export-induced loss allocated to consumers (orange), export-induced loss allocated to producers (light blue), and loss induced by domestic consumption (dark blue). The overlaid line indicates the share of total biodiversity loss in each country that is attributed to foreign consumers. The pie chart summarizes the global proportions of biodiversity loss attributed to consumers, producers, and domestic demand.

biodiversity loss values by country and by attribution type is provided in supplementary table S3. For example, in the Philippines, vegetables, cereals, and rice are the primary crops driving biodiversity impacts. In Brazil, oil crops and cereals dominate, while in Mexico, vegetables and cereals are the major contributors.

Among the countries with the highest total biodiversity loss, several also exhibit a high share of loss attributed to international consumption. This proportion is particularly elevated in Australia $( 5 4 . 8 \% )$ , Malaysia $( 4 9 . 6 \% )$ , and Paraguay $( 4 8 . 2 \% )$ , highlighting the spatial decoupling between ecological impact and consumption (figure 3).

![](images/ce00259faf07f7db8bf13f2d979dafd63e9c3ed670672c8354d90977e948d3b4.jpg)  
Figure 4. Bilateral trade flows of biodiversity loss attributed to consumers under the responsibility allocation framework. The figure presents the 80 largest flows (in species/year) resulting from international crop trade, visualized using a chord diagram.

# 3.3. Tracing the origin of biodiversity loss allocated to consumers

By tracing the international flows of biodiversity loss under the responsibility allocation framework, we identify key consumption–production linkages that drive biodiversity pressure across borders. These flows reflect the portion of biodiversity loss from crop production that is economically attributed to consumer countries, rather than physically occurring there.

Globally, the five largest bilateral trade flows responsible for consumer-attributed biodiversity loss are: China’s import from Brazil (8.0 species/year), the United States’ import from Mexico (5.7), the United States’ import from Indonesia (1.2), the United States’ import from Brazil (1.1), and China’s import from Indonesia (1.0) (figure 4). These top flows highlight a highly concentrated structure of global environmental responsibility.

A broader analysis reveals a pronounced asymmetry between biodiversity-exporting and biodiversity-consuming countries (figure 4). Tropical regions such as Brazil, Mexico, Indonesia, and Colombia serve as major sources of biodiversity loss, while high-consumption economies such as the United States, Germany, and Japan are identified as primary drivers through their import demand. The United States and China alone account for a substantial share of global consumer-induced biodiversity loss, drawing from diverse sourcing regions across Latin America, Southeast Asia, and sub-Saharan Africa.

# 4. Discussion

This study quantifies biodiversity loss from cropland occupation associated with export crop production and allocates responsibility from both productionand consumption-based perspectives. Our findings reveal that $6 8 . 1 \%$ of this loss is attributable to consumers, underscoring the dominant role of international demand in driving ecological degradation. At the same time, the spatial distribution of these loss hotspots highlights the intersection of agricultural expansion and global biodiversity vulnerability. This result reinforces the view that consumption in highincome countries exerts disproportionate pressure on biodiversity-rich regions through global trade—a hallmark of telecoupled environmental systems (Liu et al 2013) and providing important spatial targets for conservation and policy intervention. By tracing biodiversity loss across supply chains, our analysis contributes to emerging efforts to uncover the hidden ecological costs of international agri-food networks (Lenzen et al 2012, Zeng et al 2022). While previous studies have traced biodiversity impacts of food or timber trade, our surplus-based attribution model adds a new dimension by directly linking ecological damage with welfare gains along the supply chain, offering a clearer logic of accountability.

To further support ecological accountability, we developed a high-resolution global map of consumerallocated biodiversity loss. This spatially explicit footprint reveals strong heterogeneity across agricultural landscapes and helps identify hotspot regions of

biodiversity loss—such as Southeast Asia, Central America, and West Africa—where export-oriented agriculture overlaps with areas of high species vulnerability (Cabernard et al 2024). For example, Brazil and the Philippines stand out as both major exporters of crops with high biodiversity impacts and areas with high externalized ecological pressure. Such patterns not only reflect biophysical conditions but also market structures, with certain crops (e.g. oilseeds, vegetables) linked to high biodiversity loss intensities and elastic international demand. These results provide empirical support to the broader literature on regionalized biodiversity loss , while emphasizing that biodiversity costs are often borne by regions with weaker regulatory capacity or lower access to sustainable production technologies.

Several policy implications arise from our study. First, it provides a scientific foundation for international ecological compensation by clarifying national-level responsibilities. Such accounting can support more equitable burden-sharing, particularly for countries that serve as global suppliers but bear disproportionate biodiversity costs (Green et al 2019, Bragadóttir et al 2024). Second, it enables more targeted interventions—such as regulating high-impact crops, promoting sustainable practices, reinforcing ecological restoration, and spatially optimizing landuse policies—to address trade-driven biodiversity loss (Plumptre et al 2025). For consumer countries, especially in the Global North, this highlights the importance of adopting sustainability standards across supply chains (Maney et al 2024, Sun et al 2025), such as sourcing certification, import screening for biodiversity risk, and investment in producer-country conservation programs. These measures could help internalize biodiversity externalities through market channels (Mehrabi and Giagnocavo 2024), even in the absence of formal global compensation systems.

Our results also expand the empirical evidence base linking biodiversity loss to global agricultural trade. We find that $4 0 . 3 \%$ of global biodiversity loss from crop production is linked to internationally traded crops, exceeding previous estimates of around $3 0 \%$ (Lenzen et al 2012).

Notably, while only about $1 5 \%$ of global crop production (by physical volume) enters international trade, it accounts for over $4 0 \%$ of biodiversity loss from cropland occupation. This disproportionate impact reflects the fact that many export-oriented crops are grown in biodiversity-rich regions (Meltzer et al 2024)—such as soybeans in Brazil (Molotoks et al 2024), palm oil in Southeast Asia (Andriyanningsih et al 2024), and tropical fruits or nuts in West Africa (Guedes et al 2024)—where ecosystem vulnerability is high and land conversion tends to be more ecologically damaging (Wiebe and Wilcove 2025). This asymmetry reinforces the need to examine not only the volume of trade, but also the spatial and ecological characteristics of traded production, which tend

to concentrate environmental burdens in the Global South.

Our producer- and consumer-level attribution also complements recent calls to refine responsibility accounting in environmental assessments (Sun et al 2022), by highlighting asymmetric benefits and costs across nodes in the supply chain. Moreover, the spatial correspondence between our consumerattributed biodiversity loss and independently identified global biodiversity hotspots lends further credibility to our approach (Cabernard et al 2024), while pointing to persistent governance gaps in addressing telecoupled biodiversity risks. Although concepts like telecoupling have become central in land system science (Hull and Liu 2018), operational frameworks to assign responsibility across space and actors remain limited—our study offers one pathway forward.

Compared to greenhouse gas emissions—where pricing and regulation have increasingly been used to assign responsibility—biodiversity loss remains largely unpriced and unregulated (Jakob et al 2021). The absence of established global mechanisms to internalize biodiversity externalities heightens the relevance of our welfare-based allocation method. By aligning ecological responsibility with economic benefit, our approach provides a pragmatic and forward-looking tool to support more accountable biodiversity governance in global supply chains. Importantly, the approach is scalable and adaptable, allowing for integration with national biodiversity strategies, supply chain disclosure policies, and emerging biodiversity footprint metrics under frameworks such as the Taskforce on Nature-related Financial Disclosures.

This study has several limitations. First, the analysis relies on global datasets at a $0 . 0 5 ^ { \circ }$ resolution and on biodiversity threat coefficients that are not species-specific. While spatially comprehensive, these data may not fully capture ecological variation across regions and taxa. Second, we apply a uniform biodiversity pricing scheme, which may overlook the disproportionate ecological value of certain species or ecosystems. Third, we use average biodiversity loss coefficients derived from previous studies (e.g. Chaudhary et al 2015), and assume a uniform rate of biodiversity loss over time, as a simplifying assumption that does not capture nonlinear ecological responses (e.g. habitat saturation effects) or temporal nonlinearities. Fourth, our analysis focuses on biodiversity loss from existing cropland occupation, rather than land expansion, excluding potential future agricultural growth. Fifth, we limit the scope to terrestrial vertebrate taxa (amphibians, reptiles, mammals, birds), which may not fully capture the broader biodiversity impacts, especially on invertebrates or aquatic species. Future research could address these issues by integrating finer-resolution land-use data, dynamic biodiversity coefficients, and differentiated valuation frameworks, as well as incorporating

more complex ecological dynamics and broader biodiversity considerations.

# 5. Conclusion

This study reveals that international crop trade plays a substantial role in global biodiversity loss, with $6 8 . 1 \%$ of export-related impacts attributable to consumers. Major importing countries externalize biodiversity pressures to producer regions, including Southeast Asia, South America, and Africa, where many ecosystems are already vulnerable. While biodiversity loss is concentrated in these production areas, its primary drivers lie in global consumption patterns. Furthermore, countries with large domestic demand also contribute significantly to biodiversity loss through both internal land use and imported crops. These findings highlight the need for consumption-based accounting in biodiversity governance to more equitably assign responsibility and support effective global conservation strategies.

