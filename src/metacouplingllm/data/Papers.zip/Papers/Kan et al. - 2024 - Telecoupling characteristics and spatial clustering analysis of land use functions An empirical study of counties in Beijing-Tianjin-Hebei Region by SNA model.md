# Telecoupling characteristics and spatial clustering analysis of land use functions An empirical study of counties in Beijing-Tianjin-Hebei Region by SNA model

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:49:02.440594+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Kan et al. - 2024 - Telecoupling characteristics and spatial clustering analysis of land use functions An empirical study of counties in Beijing-Tianjin-Hebei Region by SNA model.pdf
- Year: unknown
- DOI: 10.3969/j.issn.1004-9479.2024.09.20222198
- OA status: unknown
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: no license info, oa_status=unknown

## Copyright-Safe Summary
This article examines how different land use functions in the Beijing-Tianjin-Hebei (BTH) region are linked over long distances and organized into spatial networks, using telecoupling as the main conceptual lens. The study area covers 149 county-level units in Beijing, Tianjin, and Hebei Province.

The authors evaluate three categories of land use functions - production, living, and ecological - for 2010, 2015, and 2020. They build a 24-indicator system (covering agriculture, non-agricultural production, human settlements, social welfare, and ecological capacity, maintenance, and regulation) and compute composite function scores using an entropy-weight TOPSIS method applied to multi-source spatial and socioeconomic data. To capture cross-county interaction, they use an improved gravity model to estimate potential functional link strengths, differentiate near versus distant links, and then construct directed, weighted telecoupling networks for each function. Social network analysis (SNA) metrics, including centrality indicators and block modeling (CONCOR), are used to reveal network structure and spatial clustering of counties into role types.

Results show clear functional differentiation and evolution. Over 2010-2020, production functions generally weaken and are stronger in the southeast than northwest; living functions improve markedly and shift from a dual-core to more polycentric, balanced pattern; ecological functions rise overall but display pronounced polarization between mountainous/coastal and central plain areas. All three functions form telecoupled small-world, scale-free networks with a pronounced core-periphery pattern and relatively low overall density. A few highly central counties in and around Beijing, Tianjin, and key ecological areas dominate long-distance exchanges, while many counties in southern and central Hebei remain weakly integrated.

Block modeling identifies four spatial clusters for each function, corresponding to five roles: main spillover, main beneficiary, intermediary, two-way spillover, and isolated clusters. This work is explicitly grounded in the metacoupling/telecoupling framework, emphasizing that remote functional linkages, not just local spatial patterns, are crucial for understanding and governing coordinated, sustainable land use in the BTH megaregion.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling focus among county land use functions; intra-regional but beyond neighborhood distances.

### Intracoupling
#### Systems
- Human–land system within each county in Beijing-Tianjin-Hebei Region
- Internal interactions among production, living, ecological land functions per county
#### Flows
- Local provision of products, services, and ecosystem functions within counties
#### Agents
- County governments and planning agencies
- Local residents and enterprises
#### Causes
- Rapid urbanization and extensive land use
- Local socio-economic development and policy changes
#### Effects
- Trade-offs among production, living, ecological functions inside counties
- Spatial differentiation of land use functions over time

### Pericoupling
#### Systems
- Neighboring counties within Beijing-Tianjin-Hebei
- Subregional clusters such as Jing-Jin-Tang and central Hebei
#### Flows
- Short-distance flows of labor, goods, and services between adjacent counties
- Spillover of urban expansion and infrastructure into nearby counties
#### Agents
- Adjacent county governments coordinating development
- Regional transport and infrastructure operators
#### Causes
- Geographical adjacency and commuter movements
- Regional integration and coordinated development strategies
#### Effects
- Formation of core-periphery patterns around Beijing and Tianjin
- Local clusters of high or low land use function levels

### Telecoupling
#### Systems
- Counties across Beijing-Tianjin-Hebei linked beyond near-distance thresholds
- Core metropolitan counties and distant peripheral agricultural or ecological counties
- Functional blocks identified in telecoupling networks
#### Flows
- Long-distance flows of agricultural and industrial products
- Telecoupled commuting and access to living services across cities
- Long-range ecological service connections and environmental pressures
#### Agents
- Core counties like Beijing urban area, Tianjin Binhai, key Hebei cities
- Peripheral grain-producing and ecological conservation counties
- Regional and national policymakers promoting coordinated development
#### Causes
- Economic globalization and regional integration policies
- Transport network expansion and factor reallocation
- Differentiated regional functions and comparative advantages
#### Effects
- Scale-free, small-world telecoupling networks with core-periphery structures
- Role differentiation: main spillover, main beneficiary, mediator, two-way spillover, isolates
- Uneven participation of southern Hebei, hindering full functional synergy

### Cross-Coupling Interactions
- Telecoupled production, living, ecological networks overlap but have distinct cores and blocks
- Ecological telecoupling can amplify or constrain production and living telecoupling patterns
- Block-level roles differ by function, shaping multi-functional regional synergy or fragmentation

### Research Gaps or Limitations
- Gravity-model links approximate actual flows; real interaction data are missing
- County-level cross-sectional data limit representation of fine-scale dynamics
- Drivers and spatial effects of telecoupling not fully quantified; mainly structural analysis

### Search Keywords
- telecoupling land use functions Beijing Tianjin Hebei
- SNA entropy-weight TOPSIS small-world scale-free
- production living ecological function network blocks

### Extraction Confidence
high
