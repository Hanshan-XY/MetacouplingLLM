# Analysis of the proximity and telecoupling mechanism of cultivated land use change A case study of

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:11:35.357656+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Wu et al. - 2023 - Analysis of the proximity and telecoupling mechanism of cultivated land use change A case study of.pdf
- Year: unknown
- DOI: 10.11821/dlyj020221377
- OA status: unknown
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: no license info, oa_status=unknown

## Copyright-Safe Summary
This study examines how both nearby and distant socio-economic processes drive cultivated land use change in Chinas Yangtze River Economic Belt (YREB), a core grain production and consumption region. It explicitly applies the metacoupling framework (local, adjacent, and distant couplings) to cultivated land, combined with new economic geography ideas.

Geographically, the work covers all prefecture-level cities in the YREB, embedded within a national context through interprovincial trade. The land system context is long-term cropland conversion to construction land, forest, and grass, under rapid urbanization, industrialization, and expanding transport networks.

The authors integrate several datasets: seven phases of Landsat-based land use maps from 1990 to 2020, road and rail networks for key years to derive travel-time accessibility, socioeconomic statistics for cities, and a 2017 multiregional input-output table for 31 provinces. They construct: (1) a land use transition matrix to track local conversions; (2) an input-output model with an explicit cultivated land factor to estimate embodied cropland flows and net virtual land imports/exports between provinces; and (3) a second-order spatiotemporal autoregressive model that replaces physical distance with time-based accessibility (1-5 hour thresholds) to identify proximity and telecoupling effects on cropland change, controlling for globalization, marketization, fiscal decentralization, and urbanization indicators.

Results show strong local conversion of cropland mainly to construction land in major urban agglomerations and to forest/grass elsewhere. Several coastal and central YREB provinces are net recipients of embodied cropland, while interior provinces such as Guizhou, Anhui, and Jiangxi are net suppliers, often to neighboring YREB provinces, creating a spatially clustered telecoupled land-use system. From 2005 to 2020, cropland change exhibits significant spatial dependence driven by improved accessibility, strongest within about 2-3 hours travel time and weakening beyond that. Local land endowment, land-based local finance, and urbanization consistently drive cropland loss, while globalization and marketization show heterogeneous effects. The paper is clearly about telecoupling/metacoupling, demonstrating how transport-enabled flows of goods, people, and capital couple local, neighboring, and distant land systems and informing cross-regional cultivated land protection and policy design.

## Structured Metacoupling Extraction

### Coupling Classification
- Explicit metacoupling study integrating intra, peri, and telecoupling of cultivated land use in YREB

### Intracoupling
#### Systems
- Prefecture level cities within the Yangtze River Economic Belt local human land systems
- Cultivated land parcels within each citys administrative boundary
#### Flows
- Conversion of cropland to construction land forest land and grassland within cities
- Local food production and consumption supported by nearby cropland
#### Agents
- Municipal and county governments pursuing land finance and urban expansion
- Farmers and agricultural enterprises managing cropland and land transfers
- Urban residents influencing dietary demand and land conversion
#### Causes
- Urbanization industrialization and city expansion occupying cropland
- Local land finance incentives under fiscal decentralization
- Changes in local diet structure and non grain crop cultivation
#### Effects
- Decline of cropland area and shift to construction forest and grass land
- Path dependence of cropland loss reducing future protection flexibility
- Intensified local food security and ecological pressure

### Pericoupling
#### Systems
- Neighboring prefecture level cities within 1 to 3 hours travel time
- Adjacent YREB provinces exchanging agricultural products
#### Flows
- Embodied cropland transferred via interprovincial agricultural trade within YREB
- Labor and capital flows between nearby cities affecting cropland change
- Short distance commodity and service flows enabled by improved transport
#### Agents
- Provincial and municipal governments coordinating regional development
- Transport and infrastructure planners expanding road and rail networks
- Regional agribusiness firms trading grain and agricultural products
#### Causes
- Improved transport accessibility creating time space compression within 2 3 hours
- Regional market integration and urban agglomeration growth
- Neighboring provinces specializing in grain supply versus processing consumption
#### Effects
- Strong spatial autocorrelation of cropland change within 2 3 hours
- Net cropland exporting provinces compensating neighboring deficit provinces
- Enhanced cropland conversion along transport corridors near large city clusters

### Telecoupling
#### Systems
- YREB provinces and distant grain producing provinces such as Heilongjiang and Jilin
- Cross provincial city systems connected beyond 3 hours travel
- National scale food production consumption network involving YREB
#### Flows
- Virtual cropland embodied in interprovincial grain and agri product trade
- Long distance capital and investment shaping land use and industry
- Information and policy signals reallocating production regions
#### Agents
- Central government shaping grain security and cropland protection policies
- Large scale agribusiness and food processing enterprises trading nationally
- Statistical and scientific institutions compiling multi regional input output tables
#### Causes
- Spatial separation between national food production bases and YREB consumers
- National marketization globalization and trade liberalization
- Differences in cropland endowment productivity and income across provinces
#### Effects
- Heilongjiang Jilin Inner Mongolia acting as major net virtual cropland exporters
- Guizhou Anhui Jiangxi exporting embodied cropland to richer YREB provinces
- Shifting environmental and land pressure from consuming to producing regions

### Cross-Coupling Interactions
- Transport accessibility links intracoupling land conversion with peri and telecoupled trade effects
- Local land finance and urbanization interact with regional accessibility to amplify cropland loss
- Labor and capital mobility change sign and strength across distance thresholds

### Research Gaps or Limitations
- Intercity input output flows unavailable so analysis confined to provincial scale trade
- International trade and foreign virtual cropland not included in telecoupling assessment
- Model mainly captures accessibility time thresholds may omit other distance dimensions

### Search Keywords
- Yangtze River Economic Belt cultivated land metacoupling
- transport accessibility virtual cropland input output China
- spatial autoregressive model proximity telecoupling farmland

### Extraction Confidence
high
