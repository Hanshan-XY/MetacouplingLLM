# Understanding and achieving sustainable consumption Integrating international political economy and

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:53:44.054725+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Liu - 2024 - Understanding and achieving sustainable consumption Integrating international political economy and.pdf
- Year: unknown
- DOI: 10.1002/bsd2.321
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Conceptual\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This conceptual paper examines why contemporary consumption patterns remain environmentally unsustainable and what policies could redirect them, by combining international political economy (IPE) and psychological perspectives. It is global in scope, with particular attention to structural inequalities between developed and developing countries, and it explicitly engages with telecoupling as a framework for understanding distant socioeconomic-environmental linkages.

From an IPE perspective, the author argues that unsustainable consumption is reinforced by unequal exchange relations in globalized production networks, where affluent countries externalize ecological burdens to poorer regions. A second macro-level driver is the lack of systematic telecoupling analysis in policy and assessment: national sustainability indicators often ignore cross-border material flows, rebound effects, and spillover impacts, so a country can appear sustainable while degrading environments elsewhere. Third, governments face a political-ecological trade-off: maintaining growth and consumption is tightly linked to political legitimacy, so policies lean toward green consumerism rather than absolute reductions in consumption.

From a psychological perspective, three main individual-level mechanisms are highlighted. First, socially constructed and ever-escalating needs, supported by consumer culture and marketing, generate a cycle where rising consumption fails to deliver lasting satisfaction. Second, environmental concern is often weak or superficial, undermined by limited awareness of hidden supply chain impacts and by short-term self-interest. Third, low self-efficacy leads individuals to doubt that their own sustainable choices matter within large-scale collective problems.

Building on this diagnosis, the paper proposes integrated policy directions: globally redistributive economic measures and environmental justice principles to rebalance exchange relations; telecoupled governance systems that track and regulate distant impacts; multi-stakeholder networks that mobilize NGOs, media, and communities; and micro-level strategies to decouple happiness from consumption, raise environmental awareness via pricing, incentives, and information, and strengthen consumer self-efficacy. The paper is explicitly about telecoupling and metacoupling, using these ideas to argue that sustainable consumption must be addressed as a multi-scalar, interconnected system rather than a purely national or individual issue.

## Structured Metacoupling Extraction

### Coupling Classification
- Conceptual paper on sustainable consumption explicitly discusses telecoupling and global cross-border interactions.

### Intracoupling
#### Systems
- National economies balancing growth, equity, and environmental sustainability.
- Individual consumers within societies shaped by norms and marketing.
- Domestic governance and policy systems targeting consumption patterns.
#### Flows
- Household demand for goods and services within a country.
- Information and norms about happiness, status, and green behavior.
- National fiscal incentives, subsidies, and regulations influencing consumption.
#### Agents
- National governments and public agencies.
- Individual consumers and households.
- Domestic NGOs, media, and community organizations.
#### Causes
- Political need for economic growth and high consumption.
- Socially constructed needs and consumerist culture.
- Low environmental concern and weak self-efficacy among citizens.
#### Effects
- Persistently high material throughput and resource use.
- Entrenchment of unsustainable lifestyles and debt-based consumption.
- Limited effectiveness of national green consumption policies.

### Pericoupling
#### Systems
- Neighboring or regionally linked countries in trade blocs.
- Regional supply and value chains for energy and biomass.
- Transboundary environmental governance within regions.
#### Flows
- Trade in energy carriers and biomass between nearby countries.
- Regional diffusion of sustainability standards and labels.
- Cross-border pollution and resource extraction impacts.
#### Agents
- Regional organizations and trade alliances.
- Exporters and importers in adjacent countries.
- Regional NGOs and advocacy networks.
#### Causes
- Search for cheaper resources and transport routes regionally.
- Imported sustainability strategies shifting burdens to neighbors.
- Partial regional coordination without full telecoupling analysis.
#### Effects
- Apparent sustainability gains in richer neighbors.
- Environmental justice tensions among regional partners.
- Leakage of emissions and resource pressures across borders.

### Telecoupling
#### Systems
- Developed consumer economies demanding resource-intensive imports.
- Developing producer countries bearing production and waste burdens.
- Global climate and ecological systems affected by distant consumption.
#### Flows
- Long-distance trade in goods, biomass, and energy commodities.
- Capital, technology, and knowledge transfers across continents.
- Embodied emissions, resource use, and waste in traded products.
#### Agents
- Multinational firms coordinating global supply chains.
- International organizations and climate finance institutions.
- Consumers in rich countries driving distant production.
#### Causes
- Unequal exchange relations and historical responsibility disputes.
- Lack of robust telecoupling governance and assessment frameworks.
- Globalized supply chains obscuring production impacts from consumers.
#### Effects
- Ecological and social burdens displaced to poorer distant regions.
- Rich-country sustainability illusion based on imported impacts.
- Telecoupled side effects undermining global sustainability goals.

### Cross-Coupling Interactions
- National green policies can externalize impacts through telecoupled trade, worsening conditions in producer regions.
- Consumer ignorance of distant impacts weakens support for telecoupled governance reforms.
- Telecoupled burdens intensify domestic justice debates over intergenerational and intragenerational equity.

### Research Gaps or Limitations
- Limited operational telecoupling frameworks to quantify distant impacts of national consumption.
- Insufficient integration of psychological factors into telecoupled governance design.
- Political and capacity constraints hinder implementation of redistributive and telecoupled policies.

### Search Keywords
- sustainable consumption telecoupling international political economy psychology
- unequal exchange imported sustainability rich country illusion
- consumer self-efficacy environmental concern global supply chains

### Extraction Confidence
high
