# Ecological restoration is not sufficient for reconciling the trade-off between soil retention and wa

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:48:27.059145+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Jiang et al. - 2021 - Ecological restoration is not sufficient for reconciling the trade-off between soil retention and wa.pdf
- Year: unknown
- DOI: 10.1016/j.scitotenv.2020.142139
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This article examines whether large ecological restoration and soil-water conservation programs can simultaneously reduce soil erosion and maintain water yield, using a catchment-governance and metacoupling perspective.

The study compares two major restoration regions in China: the semi-arid Loess Plateau in the midstream Yellow River and the humid Karst Plateau in the upstream-midstream Pearl River. Both are global hotspots of water-driven soil erosion. The authors combine long-term remote sensing (NDVI, MODIS evapotranspiration and energy variables), climate and runoff records, soil data, and RUSLE-based erosion modeling at 1 km resolution. They use Budyko-based climate elasticity and double mass curve methods to separate effects of climate variability from human interventions on runoff and sediment fluxes, and apply nonparametric tests to detect change points and trends.

Vegetation cover increased strongly after China’s Grain for Green Program and associated restoration projects, and modeled soil erosion declined markedly in both regions. Sediment loads at river gauges dropped by more than two-thirds, with ecological restoration and engineering measures (dams, terraces, check dams) explaining over 70 percent of the decrease; climate trends played a minor role.

Hydrological responses differed sharply by climate zone. On the Loess Plateau, higher vegetation cover was tightly linked to greater evapotranspiration, lower albedo and land-surface temperature, and significant reductions in runoff and soil moisture, intensifying midstream–downstream competition for scarce water and contributing to Yellow River delta shrinkage via reduced sediment supply. In the humid Karst Plateau, vegetation gains did not significantly alter runoff, although sediment export still declined.

The paper explicitly applies a metacoupling framework: local restoration (intracoupling) improves soil retention and land productivity but generates spillovers via altered water and sediment regimes that affect midstream water security (pericoupling) and downstream deltas and estuaries (telecoupling). The authors conclude that ecological restoration alone cannot reconcile soil retention–water yield trade-offs. Integrated catchment governance must balance soil and water supply-demand across upstream, midstream, and downstream, optimize the spatial mix of engineering and natural measures, and explicitly account for cross-regional telecoupled effects.

## Structured Metacoupling Extraction

### Coupling Classification
- Study explicitly frames soil water dynamics as intracoupling, pericoupling, and telecoupling in one catchment.

### Intracoupling
#### Systems
- Loess Plateau catchments in Yellow River midstream
- Karst Plateau catchments in Pearl River upstream midstream
#### Flows
- Soil erosion and retention within subcatchments
- Local runoff generation and evapotranspiration
- Soil moisture use by restored vegetation
#### Agents
- National and provincial restoration agencies
- Local farmers participating in conversion programs
- Water resources and river basin authorities
#### Causes
- Large scale ecological restoration and soil conservation projects
- Afforestation and grass planting on cropland and degraded hillslopes
- Check dams reservoirs terraces and engineering soil conservation
#### Effects
- Strong decline in soil erosion and sediment yield locally
- Reduced local water yield and soil moisture in drylands
- Improved land productivity but higher ecosystem water consumption

### Pericoupling
#### Systems
- Upstream and midstream Loess Plateau subcatchments
- Midstream Plateau areas and adjacent river reaches
- Karst Plateau upstream and midstream Pearl River sections
#### Flows
- Sediment and nutrients transported from hillslopes to rivers
- Runoff volumes moving from subcatchments to mainstem
- Water abstracted for irrigation industry and domestic use
#### Agents
- River basin commissions managing water and sediment
- Hydropower and dam operators in middle reaches
- Agricultural and industrial water users near rivers
#### Causes
- Implementation of soil and water conservation across neighboring subcatchments
- Increasing water withdrawals for agriculture cities and industry
- Dam and reservoir construction modifying flow and trapping sediment
#### Effects
- Stable runoff but reduced sediment in humid Karst Plateau reaches
- Reduced sedimentation in midstream reservoirs and channels
- Altered nutrient cycling and water quality along river corridors

### Telecoupling
#### Systems
- Loess Plateau midstream and Yellow River downstream delta
- Karst Plateau and Pearl River estuary and delta
- Midstream restoration areas and downstream cities and farmlands
#### Flows
- Runoff volume delivering water from midstream to downstream users
- Sediment flux shaping estuary and delta morphology
- Ecosystem service benefits and trade offs transmitted downstream
#### Agents
- Downstream municipalities and agricultural beneficiaries
- National planners designing ecological restoration mega projects
- Delta reclamation developers and coastal managers
#### Causes
- Excessive afforestation reducing midstream runoff in arid regions
- Sediment trapping by upstream restoration and engineering measures
- Rising downstream water demand from population and economic growth
#### Effects
- Aggravated downstream water scarcity and allocation conflicts
- Reduced sediment deposition and slowed delta or estuary growth
- Trade offs between upstream soil retention and downstream water services

### Cross-Coupling Interactions
- Intracoupling soil retention gains trigger telecoupled water scarcity and delta shrinkage downstream
- Pericoupling sediment reduction modifies telecoupled estuary formation and coastal morphology
- Catchment governance must jointly manage local erosion control and distant water sediment needs

### Research Gaps or Limitations
- Gully erosion and detailed sediment routing not fully represented in erosion modeling
- Trade offs assessed mainly via runoff and sediment not full ecosystem service spectrum
- Remote sensing products and empirical models introduce uncertainties needing better calibration

### Search Keywords
- Loess Plateau Karst Plateau ecological restoration telecoupling
- soil retention water yield trade off Yellow River Pearl River
- integrated catchment governance sediment delta formation

### Extraction Confidence
high
