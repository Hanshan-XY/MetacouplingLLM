# Assessing the impact of China_s timber industry on Congo Basin land use change

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:45:31.932945+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Fuller et al. - 2019 - Assessing the impact of China_s timber industry on Congo Basin land use change.pdf
- Year: unknown
- DOI: 10.1111/area.12469
- OA status: green
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: green OA without permissive license (none)

## Copyright-Safe Summary
This paper studies how Chinas growing timber industry and downstream furniture exports are linked to land-use change in the Congo Basin, and how these connections span multiple distant regions, exemplifying telecoupling.

Geographically, the analysis focuses on five Congo Basin countries that trade wood with China (Cameroon, Central African Republic, Democratic Republic of Congo, Gabon, Republic of Congo), China as a processing hub, and the United States as a major consumer of Chinese wood furniture.

The authors combine two main data sources from 2001-2015: satellite-based estimates of annual tree-cover loss (University of Maryland Global Forest Change data) and official trade statistics (UN Comtrade and Chinese/US sources) for wood (code 44) and furniture (code 94), supplemented by data on domestic wood consumption, labor costs, timber prices, and logging roads. They use panel regression to relate national tree-cover loss to timber exports to China, rural population growth, palm-oil exports, and logging-road density, and separate regressions to identify drivers of Chinese timber imports from the Congo Basin.

Over the 15-year period, cumulative wood exports from the Congo Basin to China more than doubled, while exports to the EU fell sharply. Trade patterns shifted after Gabon banned log exports in 2010, with Cameroon and Republic of Congo emerging as the leading suppliers. Statistical modeling shows that among several candidate drivers, only the share of a countrys wood exports going to China is significantly associated with higher tree-cover loss; rural population growth, palm-oil production, and logging roads are not significant in the multivariate model.

A second set of models finds that US imports of Chinese wood furniture are strongly correlated with Chinese timber imports from the Congo Basin, whereas Chinese domestic wood consumption plays a minor role. This implies a multi-step telecoupled chain: US consumers drive Chinese furniture production, which in turn amplifies timber extraction and forest loss in the Congo Basin. The paper is explicitly about telecoupling, illustrating how distant demand shapes land-use change in a biodiversity-rich tropical forest region and highlighting implications for governance, certification, and consumer awareness.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling among Congo Basin forests, Chinese timber processing, and US furniture consumption.

### Intracoupling
#### Systems
- Congo Basin forest ecosystems within Central African timber concessions
- National land use and forestry governance in Cameroon, Gabon, Republic of Congo, CAR
#### Flows
- Domestic logging and timber extraction within Congo Basin countries
- Local land use change including deforestation and road expansion
#### Agents
- Central African logging companies and concession holders
- National forestry and environmental agencies in Congo Basin states
- Local rural communities engaged in small scale forest use
#### Causes
- Forest governance frameworks and enforcement capacity within each Congo Basin country
- Economic incentives for timber extraction in national economies
#### Effects
- Tree cover loss and habitat fragmentation within Congo Basin forests
- Impacts on biodiversity, carbon storage, and ecosystem services locally

### Pericoupling
#### Systems
- Neighboring Congo Basin producer countries trading timber regionally
- China and European Union as competing nearby markets for African hardwood
#### Flows
- Shift of timber exports from EU markets toward China over time
- Diversion of Gabonese log exports toward other Central African suppliers
#### Agents
- Congo Basin governments adjusting export regulations and log bans
- Regional timber traders reallocating sourcing among nearby countries
#### Causes
- Policy changes like Gabon log export ban altering regional trade patterns
- Relative demand and price shifts between China and EU for African wood
#### Effects
- Increased timber exports from Cameroon and Republic of Congo after Gabon restrictions
- Spatial redistribution of deforestation pressures within Central Africa

### Telecoupling
#### Systems
- Congo Basin forest and land use system in Central Africa
- Chinese timber processing and furniture manufacturing hubs
- US consumer market for imported wooden furniture
#### Flows
- Exports of logs and sawnwood from Congo Basin to China
- Exports of finished wooden furniture from China to the USA
- Financial flows from US consumers ultimately funding Congo Basin timber extraction
#### Agents
- Chinese state owned and private timber companies operating in Central Africa
- Chinese furniture manufacturers and export firms
- US retailers and consumers purchasing Chinese made wooden furniture
#### Causes
- Rising US demand for low cost Chinese wooden furniture
- China role as global processing hub for timber supply chains
- Chinese development assistance and investment facilitating resource access in Africa
#### Effects
- Positive statistical link between Chinese timber imports and Congo Basin tree cover loss
- US demand strongly correlated with Chinese wood imports from Central Africa
- Threats to biodiversity hotspot and ecosystem services in Congo Basin

### Cross-Coupling Interactions
- US demand influences Chinese furniture exports, driving Chinese timber imports, which increase Congo Basin deforestation
- Gabon log export ban reduced Chinese imports there, shifting harvesting pressure to Cameroon and Republic of Congo
- Domestic Chinese wood use less influential than US demand in explaining Congo Basin timber imports

### Research Gaps or Limitations
- Tree cover data limited to 2001 2015 with small sample size and remote sensing errors
- Model excludes other important deforestation drivers like agriculture and smallholder clearing
- Trade statistics may be biased by misreporting or unrecorded timber and furniture flows

### Search Keywords
- Congo Basin timber China US furniture telecoupling
- deforestation Chinese wood imports Central Africa
- global supply chains biodiversity land use change

### Extraction Confidence
high
