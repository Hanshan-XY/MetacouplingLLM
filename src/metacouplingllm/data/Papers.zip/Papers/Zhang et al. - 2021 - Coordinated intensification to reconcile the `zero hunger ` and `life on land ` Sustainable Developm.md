# Coordinated intensification to reconcile the `zero hunger ` and `life on land ` Sustainable Developm

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:18:31.744648+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Zhang et al. - 2021 - Coordinated intensification to reconcile the `zero hunger ` and `life on land ` Sustainable Developm.pdf
- Year: unknown
- DOI: 10.1016/j.jenvman.2021.112032
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines how future global cropland expansion could be organized to support two Sustainable Development Goals (SDGs): zero hunger (SDG 2) and life on land (SDG 15). It is explicitly framed in a telecoupling / metacoupling context because global food demand is met through spatially redistributed production, with distant biodiversity impacts.

The authors build a global, spatially explicit optimization model at 0.25-degree resolution to allocate 17 major crops by 2030. They maximize agricultural rent to farmers while enforcing minimum food production and various conservation constraints. Inputs include FAO demand projections, crop potential yields, production and transport costs, and data on land cover, forests, protected areas, Key Biodiversity Areas, and intact habitats. Biodiversity impacts are estimated using a countryside species-area relationship for endemic birds and mammals. Scenarios compare cropland expansion with vs. without yield-gap closure, and with forest conservation targets applied globally vs. nationally.

Closing yield gaps on existing cropland can reduce new land requirements by roughly two-fifths relative to expansion without intensification, and it also cuts projected bird and mammal extinctions by more than half. Nonetheless, several tropical and subtropical crops (notably sugarcane, cassava, oil palm, cotton, bananas, coconuts) still need area expansion. The optimal locations concentrate along the tropical belt, especially Venezuela and eastern Brazil, the Congo Basin, parts of East and West Africa, Myanmar, Laos, and Indonesia, revealing strong telecouplings between global food demand and tropical ecosystems.

Strict forest and protected-area conservation greatly lowers intact habitat loss and species extinctions but substantially reduces total agricultural rents. When forest-loss limits are set for each country rather than globally, habitat and forest loss fall further, with only moderate extra economic cost and somewhat higher bird extinctions. Overall, the work shows that coordinated, spatially optimized intensification and expansion can significantly, but not fully, ease trade-offs between global food security and terrestrial biodiversity under telecoupled land systems.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong global telecoupling of food demand, cropland expansion, and biodiversity tradeoffs
- Pericoupling among neighboring tropical countries via land conversion and conservation spillovers

### Intracoupling
#### Systems
- National agricultural land systems balancing food production and habitat protection
- Within-country forest and habitat networks under conservation thresholds
#### Flows
- Domestic crop production to meet national food demand
- Internal land conversion from natural habitats to cropland
#### Agents
- National governments setting forest and conservation policies
- Local farmers responding to agricultural rents
#### Causes
- National implementation of forest loss limits below five percent
- Domestic pursuit of food security and SDG targets
#### Effects
- Reduced national forest and intact habitat loss under tighter constraints
- Shifts of cropland expansion to lower rent habitats domestically

### Pericoupling
#### Systems
- Neighboring tropical countries along the agricultural frontier
- Regional protected area and key biodiversity area networks
#### Flows
- Regional shifts of cropland from Venezuela and Congo Basin to Southeast Asia and Africa
- Spatial leakage of habitat conversion across nearby countries
#### Agents
- Regional blocs and neighboring governments coordinating or competing for cropland
- Agribusinesses operating across adjacent tropical countries
#### Causes
- Regionally concentrated suitable land with high potential yields
- National forest thresholds displacing expansion into nearby nations
#### Effects
- Clustered habitat conversion across tropical belts in South America, Africa, Southeast Asia
- Regional redistribution of agricultural rents and biodiversity loss

### Telecoupling
#### Systems
- Global food demand and trade system for major crops
- Tropical producer countries and temperate consumer countries
- Global biodiversity and conservation network including protected areas and KBAs
#### Flows
- International crop supply driven by projected 2030 global demand
- Virtual land and biodiversity loss embodied in exported agricultural products
- Financial returns from agricultural rents accruing to producer nations
#### Agents
- International organizations promoting SDGs and conservation conventions
- Global food companies and commodity traders
- Multilateral climate and PES schemes like REDD plus
#### Causes
- Rising global food demand and historical consumption trends
- International SDG commitments for zero hunger and life on land
- Global optimization of cropland to maximize rents under conservation constraints
#### Effects
- Concentration of future cropland expansion in few tropical nations
- Global tradeoffs between food security, biodiversity, and equity
- Cross-border shifts in species extinction risk and habitat conversion

### Cross-Coupling Interactions
- Global coordination scenario allows higher global rents but concentrates forest loss in some countries
- Nationally constrained scenario lowers intact habitat and forest loss yet modestly reduces rents
- Protected area exclusion globally displaces expansion into less profitable, often nonforest habitats

### Research Gaps or Limitations
- Model omits explicit trade and multi sector economic dynamics beyond agricultural rents
- Climate change, crop displacement, and mixed cropping only partially considered conceptually
- Focuses mainly on SDGs 2 and 15, excluding other relevant SDGs like poverty and energy

### Search Keywords
- telecoupling land use SDG zero hunger life on land
- agricultural intensification spatial optimization biodiversity tradeoffs
- tropical cropland expansion forest conservation global coordination

### Extraction Confidence
high
