# Identification and apportionment of the drivers of land use change on a regional scale Unbiased rec

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:10:20.274789+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Wang et al. - 2016 - Identification and apportionment of the drivers of land use change on a regional scale Unbiased rec.pdf
- Year: unknown
- DOI: 10.1016/j.agee.2015.11.004
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper develops and tests a quantitative framework to identify and allocate the contributions of different drivers to regional land use change, focusing on cropland and urban land in Jiangxi Province, China. The work is situated in land-system science, which increasingly emphasizes complex, multi-scale, and telecoupled human-environment interactions. Although the paper uses the language of telecoupling and complexity, it does not explicitly analyze distant flows (such as trade or migration networks) in a formal telecoupling/metacoupling framework; instead, it concentrates on regional-scale drivers and interactions.

The authors integrate remote sensing, GIS, and machine learning. Land cover maps from 1995 and 2005 are interpreted into six classes, and township-level transition rates for cropland and urban land are calculated as response variables. Candidate drivers include 31 anthropogenic and biophysical indicators, filtered using a spatial autoregressive model down to 12 key variables (e.g., population measures, sectoral GDP, rural income, Engel coefficient, temperature, elevation). Policy-driven land conversion programs are encoded as a categorical variable. Annual change rates of all indicators form the explanatory dataset.

Land use drivers are analyzed using unbiased recursive partitioning methods: conditional inference trees (CIT) for transparent rule-based segmentation, and random forests (RF) for robust variable importance and interaction assessment. Spatial autocorrelation is explicitly considered, and model performance is evaluated with pseudo-R2, ROC-AUC, and cross-validation.

Results show that cropland dynamics are dominated by changes in rural income and land conversion policy, with population and primary-sector GDP also important; biophysical factors such as elevation play a secondary but nontrivial role. Urban expansion is mainly linked to shifts in the Engel coefficient, growth in tertiary-sector output, rural income, and temperature. Anthropogenic variables explain most variance in both cropland and urban change, but important nonlinearities and interactions are revealed between socioeconomic and biophysical drivers. The framework demonstrates how machine learning can disentangle complex, multi-driver land use dynamics at regional scale and provides a basis for more informed land use planning; however, explicit telecoupled flows remain largely implicit rather than formally modeled.

## Structured Metacoupling Extraction

### Coupling Classification
- Primarily intracoupling within Jiangxi; conceptually linked to broader telecoupled land systems.

### Intracoupling
#### Systems
- Cropland, urban, forest, grassland, water, barren land within Jiangxi Province townships.
- Socioeconomic system of Jiangxi residents, industries, and local governments.
- Biophysical environment of Jiangxi, including elevation, temperature, and climate hazards.
#### Flows
- Land conversion between cropland, urban areas, forest, grassland, and water bodies.
- Flows of income, wages, remittances, and local consumption expenditures.
- Implementation of provincial and national land-conversion subsidies and incentives.
#### Agents
- Farmers, migrant workers, and rural households managing land and livelihoods.
- Township, provincial, and national government agencies implementing land policies.
- Local industries, service sectors, and construction enterprises driving urban growth.
#### Causes
- Changes in rural income, population density, and sectoral GDP at township level.
- Land conversion programs targeting forest, lake, grassland restoration from cropland.
- Biophysical constraints such as elevation and temperature shaping feasible land uses.
#### Effects
- Cropland expansion or loss clustered by income, policy presence, and population growth.
- Urban land expansion linked to declining food expenditure share and service economy growth.
- Altered ecosystem services, conservation outcomes, and spatial land-use heterogeneity.

### Pericoupling
#### Systems
- Jiangxi Province interacting with neighboring provinces through migration and markets.
- Upstream and downstream areas around Poyang Lake and adjacent catchments.
#### Flows
- Rural outmigration and remittance transfers between nearby regions.
- Regional commodity and labor flows affecting local land-use profitability.
#### Agents
- Migrant workers moving between Jiangxi and nearby urban centers.
- Regional planners coordinating conservation and development across provincial borders.
#### Causes
- Regional economic imbalances and policy differences driving migration and degradation.
- Conservation programs responding to floods and droughts across multiple provinces.
#### Effects
- Cropland pressure displaced from conservation zones to other regional localities.
- Redistribution of environmental impacts and agricultural production within the region.

### Telecoupling
#### Systems
- Global land-system and climate change context influencing Jiangxi land dynamics.
- International markets and broader Chinese urbanization affecting local demand.
#### Flows
- Abstracted flows of global demand for food, materials, and ecosystem services.
- Diffusion of agricultural technologies and policy ideas from broader networks.
#### Agents
- National-level policymakers responding to global environmental and food concerns.
- International research and assessment bodies shaping land-use narratives.
#### Causes
- Global environmental change and telecoupled land-system feedbacks on regional land use.
- Rising national affluence and technology affecting local land-use decisions.
#### Effects
- Alignment of Jiangxi land transitions with global patterns of agricultural intensification.
- Contribution of local land changes to wider greenhouse gas and biodiversity outcomes.

### Cross-Coupling Interactions
- Income, population, and policy interact with elevation and temperature to shape land transitions.
- Regional migration and remittances link local cropland dynamics with external labor markets.

### Research Gaps or Limitations
- Important drivers like infrastructure, market access, and management practices not explicitly modeled.
- Dependence on land-cover classification accuracy and relatively coarse remote sensing data.
- Method requires large sample sizes; performance weaker for small-sample applications.

### Search Keywords
- Jiangxi land use change drivers recursive partitioning random forest
- cropland urban expansion policy income Engel coefficient China
- anthropogenic biophysical indicators spatial autocorrelation telecoupled land systems

### Extraction Confidence
high
