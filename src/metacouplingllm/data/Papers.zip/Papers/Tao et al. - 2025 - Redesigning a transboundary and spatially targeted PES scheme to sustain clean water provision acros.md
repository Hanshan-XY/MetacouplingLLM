# Redesigning a transboundary and spatially targeted PES scheme to sustain clean water provision acros

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:08:13.900246+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Tao et al. - 2025 - Redesigning a transboundary and spatially targeted PES scheme to sustain clean water provision acros.pdf
- Year: unknown
- DOI: 10.1016/j.ecoser.2025.101788
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper examines how to redesign a payment for ecosystem services (PES) program to improve drinking water quality in a highly urbanized, transboundary watershed in eastern China. The focal case is the Xinan River Watershed, which spans Anhui and Zhejiang provinces and supplies Lake Qiandao, a major reservoir for more than 10 million people and for a leading bottled water company. The system is explicitly framed as metacoupled, linking upstream rural producers, downstream cities, and nationwide corporate water consumers via hydrologic ecosystem service flows.

The authors combine biophysical modeling, spatial optimization, and economic valuation. They use the InVEST Nutrient Delivery Ratio model with 30 m land cover, terrain, soil, and climate data to map total nitrogen (TN) export across 26 subwatersheds, calibrating against monitoring stations. Three land management options are simulated on croplands in subwatersheds that exceed national TN thresholds: conversion of cropland to forest, partial land retirement, and nitrogen fertilizer reduction. These are applied under alternative spatial targeting rules (by pollution contribution, distance to streams, slope) and random allocation. For each scenario, they compare TN reductions with crop production losses and then monetize benefits as avoided water treatment costs. Next, they quantify how clean water from Lake Qiandao is allocated among local residents, the nearby Hangzhou metropolis, and a national bottled water company, and assess how these beneficiaries might share PES costs.

Results indicate that a pollution-based targeting strategy focused on a small share of cropland is far more cost-effective than uniform measures. Reforesting or partially retiring only about 8 percent of the most polluting croplands would cut TN export by roughly one quarter and bring key subwatersheds below regulatory thresholds. The associated annual compensation to farmers, based on avoided treatment costs, is several times their foregone agricultural income. If this amount were paid proportionally by all beneficiaries of clean water, a modest 1.8 percent increase in municipal water tariffs and bottled water prices would suffice, with the bottled water corporation acting as a keystone telecoupled actor.

The study is explicitly about metacoupling and telecoupling, demonstrating how ecosystem service flow analysis across intracoupled, pericoupled, and telecoupled systems can support more equitable, spatially targeted, and transboundary PES design.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong integration of intra, peri, and telecoupling via hydrologic ecosystem service flows and PES.

### Intracoupling
#### Systems
- Xin an River Watershed headwater socio ecological system
- Upstream Anhui and downstream Zhejiang subwatersheds
#### Flows
- Nitrogen pollution flows from croplands to streams and reservoir
- Clean water provision from restored upstream lands to local users
#### Agents
- Upstream and downstream farmers managing croplands and forests
- Local watershed residents using municipal surface water
- Provincial and local governments designing current PES
#### Causes
- Intensive fertilized agriculture and sloping cropland erosion
- Urban water demand relying on surface water sources
- Existing watershed PES confined to administrative boundaries
#### Effects
- Elevated nitrogen at watershed outlet above national standard
- High treatment costs for local water utilities
- Inefficient broad PES spending with declining returns

### Pericoupling
#### Systems
- Xin an River Watershed linked with Lake Qiandao reservoir
- Adjacent Hangzhou metropolis supplied by diversion project
#### Flows
- Bulk freshwater transfer through pipelines from reservoir to Hangzhou
- Economic value flows via municipal water tariffs and bills
#### Agents
- Hangzhou municipal water utility and authorities
- Households and firms in Hangzhou consuming diverted water
- Interprovincial governments implementing bi directional PES
#### Causes
- Urbanization in Yangtze River Delta increasing drinking water needs
- Engineering diversion infrastructure extending reservoir service area
- Policy focus on interprovincial ecological compensation
#### Effects
- Hangzhou receives majority of reservoir withdrawals and benefit value
- Justified inclusion of Hangzhou users as PES payers
- Potential for fairer cost sharing beyond headwater residents

### Telecoupling
#### Systems
- Xin an River Watershed and Lake Qiandao as water source system
- Nationwide consumer market for bottled water and beverages
#### Flows
- Commercial extraction of reservoir water for bottling and distribution
- Revenue flows from national consumers to bottled water corporation
- Proposed reverse financial flows to upstream farmers via PES
#### Agents
- Nongfu Spring bottled water corporation as keystone actor
- Nationwide bottled water and soft drink consumers
- Central government overseeing national ecological compensation pilots
#### Causes
- Corporate branding around pristine headwater drinking water
- Market demand for packaged drinking water across China
- Absence of explicit responsibility for corporate water source impacts
#### Effects
- Telecoupled users capture most economic benefits from clean water
- Corporation expected to fund majority of PES compensation
- Need for governance and labeling to secure corporate participation

### Cross-Coupling Interactions
- Metacoupling framework links nitrogen reduction in focal watershed to monetary benefits in adjacent and distant systems.
- Redesigned PES redistributes costs from local governments to cross regional households and corporate actors.
- Pollution reduction in upstream Anhui benefits downstream Zhejiang cities and telecoupled national consumers simultaneously.

### Research Gaps or Limitations
- Current scheme excludes forest stewards who maintain low nitrogen export without land use change.
- Only nitrogen considered; other pollutants and multiple ecosystem services remain unpriced in PES design.
- Model relies on InVEST calibration; future work should test process based models and climate land use changes.

### Search Keywords
- Xin an River metacoupling PES
- Lake Qiandao bottled water telecoupling
- spatial targeting nitrogen export China watershed

### Extraction Confidence
high
