# Complex regional telecoupling between people and nature revealed via quantification of trans-boundary ecosystem service flows

Yanwen Wang $^{1,2,3}$ | Song Hong $^{2}$ | Jinzhu Wang $^{3,4}$ | Jingyu Lin $^{3,5}$ | Hang Mu $^{2}$ | Liyuan Wei $^{2}$ | Zhen Wang $^{6}$ | Brett A. Bryan $^{3}$

$^{1}$ School of Economics and Management, China University of Geosciences, Wuhan, China; $^{2}$ School of Resource and Environmental Sciences, Wuhan University, Wuhan, China; $^{3}$ Centre for Integrative Ecology, Deakin University, Melbourne, Vic, Australia; $^{4}$ Deakin-SWU Joint Research Centre on Big Data, Faculty of Science, Engineering and Built Environment, Deakin University, Melbourne, Vic, Australia; $^{5}$ Guangdong Provincial Key Laboratory of Water Quality Improvement and Ecological Restoration for Watersheds, School of Ecology, Environment and Resources, Guangdong University of Technology, Guangzhou, China and $^{6}$ College of Resources and Environment, Huazhong Agricultural University, Wuhan, China

# Correspondence

Song Hong

Email: songhongpu@126.com

Zhen Wang

Email: sinoo@mail.hzau.edu.cn

# Abstract

1. Quantifying and mapping trans-boundary ecosystem service (ES) flows can help identify dependencies and responsibilities for promoting economic development and environmental sustainability between nations, but few studies have focused on ES flows beyond national boundaries.   
2. Our case-study region—Central Asia—hosts one of the largest dryland areas in the world, and this ecosystem is vulnerable to climate variability and anthropogenic impacts. Understanding ES supply, demand and flows is essential for supporting human wellbeing, livelihoods and economic development.   
3. In this study, we mapped the supply, demand and flows of four ES including freshwater provision, food provision, carbon sequestration and cultural (recreation) services between the five Central Asian nations of Kazakhstan, Kyrgyzstan, Uzbekistan, Tajikistan and Turkmenistan for the year 2016. We quantified the spatial patterns in ES supply and demand at local and regional scales, driven by environmental heterogeneity and socio-economic development, and revealed complex telecoupling of ES flows between nations. Kazakhstan provided the greatest amount of ES to other countries, especially food provision and carbon sequestration, while Uzbekistan was the biggest ES beneficiary, especially from freshwater and food provision services.   
4. Our analysis of trans-boundary ES flows helps to understand the complex telecoupling and rich interdependencies between people and nature between different countries. This information is essential for policy making to balance human and ecological needs, enhance the management of natural capital, and sustain ES provision in our metacoupled world.

# KEYWORDS

Central Asia, demand, ecosystem services, flows, supply, telecoupling

# 1 | INTRODUCTION

Under climate change and intensifying human pressures, maintaining and improving natural capital, ecosystem services (ES) and human wellbeing is a primary challenge (Díaz et al., 2018). To understand nature's contributions to people, it is critical to quantify the potential supply and demand of ES as well as flows of ES to beneficiaries (Bagstad et al., 2020; Bryan et al., 2018; Burkhard et al., 2014). ES supply can be described as the capacity to provide a specific bundle of ecosystem goods and services in a given area and time period, while human demand for ES is the sum of all ecosystem goods and services used by people and is a prerequisite for actually obtaining benefits from nature (Burkhard et al., 2012; Wolff et al., 2015). Flows link ES supply and demand—sources and beneficiaries—and these are an important consideration in ES assessments as a large share of ES are typically consumed far from where they are produced (Yu et al., 2013). The link between the production and consumption of ES can be approximated by inter-regional ES flows, which depend on the distribution of natural capital, physical links, economies and trade, as well as policy and regulation (Koellner et al., 2019; Schröter et al., 2018).

With beneficiaries increasingly connected to ES sources, and inter-regional ES flows over distance becoming more and more common as globalisation advances, the interactions between people and nature are becoming linked as metacoupled social-ecological systems (i.e. two or more coupled systems interacting potentially over large distances; Liu, 2017; Liu et al., 2013). To reflect social-ecological interactions between coupled yet distant systems, the concept and framework of telecoupling has been proposed (Liu et al., 2013), which was developed by integrating existing disciplinary concepts of teleconnections and globalisation. Distant interactions can be viewed as telecoupling, which is gaining traction in studies of ES flows (Friis, 2019; Liu et al., 2019) and is a useful concept for identifying the function of distant ES and assessing their contributions to people (Liu et al., 2019).

Since national borders can act as barriers to trade and flows of materials, energy and people, many ES studies have focused on closed national systems (i.e. areas located within a geopolitical or topographic border; Koellner et al., 2018). Quantifying trans-boundary ES flows holds great potential for ES accounting and for linking biodiversity and ecosystems to human wellbeing through the flows of ES, both of which have potential to maintain or improve the supply of ecosystem services (Maes et al., 2012). By calculating ES flows and identifying trans-boundary ES telecoupling (Xie et al., 2019), greater integration of development and conservation (Bagstad et al., 2013; Li et al., 2019) and fairer access to the benefits to enhance people's wellbeing can be achieved (Ernstson, 2013; Low & Gleeson, 1998; Martinez-Harms et al., 2018). There is therefore

a need for tools and methods to assess trans-boundary ES flows to enhance regional and global sustainability, support environmental governance and decision-making, and raise public awareness of environmental protection (Burkhard et al., 2013; Hou et al., 2018; Kleemann et al., 2020).

ES are diverse and flow across space in complex ways (Bagstad et al., 2013). Studies have begun to map and quantify global and trans-boundary ES flows to understand mechanisms and impacts across borders (e.g. continental, national and sub-national). For instance, Schröter et al. (2018) used a conceptual framework and four case studies to analyse ES flows (i.e. coffee trade, species migration and dispersal, flood protection and information flows on giant pandas). Their framework improved knowledge of interregional telecoupling of people and nature and provided decision support for policy makers and governments. Schirpke et al. (2018) integrated different data sources to map cultural ES supply, demand and flows and explored societal preferences in the European Alps and their surrounding areas. Based on the analysis of spatio-temporal patterns, their results provided a basis for decision-making and landscape planning for enhancing cultural ES. Ala-Hulkko et al. (2019) quantified and mapped the supply and demand balance of food provisioning services across Europe using an accessibility analysis and provided practical solutions to enhance responses to the growing demand for food and energy across trade barriers in Europe. Other studies have assessed the flows of ES embedded in traded goods between service-providing areas and beneficiaries (La Notre et al., 2020). Although some research on trans-boundary ES flows at global and regional scales is emerging (Schröter et al., 2018; Verhagen et al., 2017; Xie et al., 2019), few attempts have been made to explicitly quantify ES supply, demand and flows across national borders (Kleemann et al., 2020; Koellner et al., 2019).

Recent advances have been made in the development of methods for mapping ES flows (Bagstad et al., 2014; Vallecillo et al., 2019; Vrebos et al., 2015), which have potential for mapping trans-boundary flows. Generally, the spatial characteristics of ES flows are simulated and mapped based on the interaction between supply and demand (Baró et al., 2016; Schirpke, Candiago, et al., 2019). ES supply is usually determined by the spatial distribution of natural capital, while demand is related to socio-ecological factors such as demographics, marketing, social and behavioural norms, and access to technology (Wolff et al., 2015). Additionally, under our accounting framework, the process of moving from baseline assessments of ES supply (the amount of ES provided by the ecosystem) to actual flows of ES requires an interaction with demand (La Notre et al., 2019). Further analyses of spatial patterns can provide information on the biophysical capacity of an area to maintain future ES (Owuor et al., 2017; Villamagna et al., 2013). In addition, Burkhard et al. (2012) proposed a concept based on a matrix connecting spatially distinct landscape

units to ecological integrity and ES supply and demand. This framework combined remotely sensed data, land surveys, land cover data and socio-economic data to reveal scale mismatches between supply and demand and depict the spatial and temporal characteristics of ES supply-demand budgets to provide information for ecosystem management and decision-making (Hein et al., 2006; Ji et al., 2020). The agent-based Service Path Attribution Networks (SPANs) model which considers provision source, spatial competition among users and landscape effects, has also been used to quantify ES flows (Bagstad et al., 2013; Johnson et al., 2012; Qin et al., 2019). Inescapably, as ES are so diverse, a variety of different models and data need to be integrated to quantify supply, demand and flows.

In this study, we use an integrated, quantitative approach to assess trans-boundary ES flows across the five countries of Central Asia—Kazakhstan, Kyrgyzstan, Uzbekistan, Tajikistan and Turkmenistan—which comprise one of the largest dryland grassland regions in the world. We integrated a range of models and environmental and socio-economic data to quantify the trans-boundary supply, demand and flows of four ES (i.e. freshwater provision, food provision, carbon sequestration and recreation) across Central Asia. We quantified the degree of telecoupling through identifying trans-boundary ES flows for each country and provide recommendations to support policy making for the protection, management and sustainability of natural capital and ecosystem services and their contributions to people in Central Asia.

# 2 METHODS

# 2.1 Study area

Central Asia—our study area—located in the core of the Asian continent (35°08'N–55°25'N and 46°28'E–87°29'E), spans an area of $\sim 4$ million km² (Figure 1). Comprising the five Asian republics of the former Soviet Union (Chen et al., 2013) it accounts for one-third of the arid regions of the world (Bai et al., 2011) and has fragile ecosystems that are vulnerable to climate variability and anthropogenic activities (Wang et al., 2020). Elevation gradually increases from the western Caspian lowlands to the eastern Altai, Tianshan and Pamirs Mountains. Central Asia has a distinctive continental arid and semiarid climate, with $\sim 90\%$ of the area receiving less than $400~\mathrm{mm}$ of rainfall per year (Hamidov et al., 2016; Li et al., 2019). Due to its unique geography, $73.2\%$ of its land area is covered by grassland, $16.6\%$ by barren land and $5.6\%$ by cropland (Figure 1c). Currently, the population of the region is more than 70 million people (World Bank, 2019; Uzbekistan 31.8 million, Kazakhstan 17.8 million, Kyrgyzstan 6.1 million, Tajikistan 8.7 million and Turkmenistan 5.7 million). Central Asia has a rich cultural history, through its nomadic peoples and its key role in the Ancient Silk Road, enabling the movement of goods, people, information, wealth and culture between Asia and Europe (Kuzmina, 2008; Laruelle & Peyrouse, 2013).

Under the centralised management of the Soviet Union, regional integration provided substantial benefits for material and trade

flows between republics (Kaminski & Mitra, 2012; Zhiltsov, 2016). But Soviet leaders tended to focus on industrial development while ignoring ecological problems (Wang, Hong, et al., 2019) leading to significant adverse trans-boundary environmental impacts such as the shrinkage of the Aral Sea (Micklin, 1988). Following the collapse of the Soviet Union in 1991, the five Central Asian countries gained independence and adopted different methods for transitioning from a collective economy to a market economy (Mirzabaev, 2013). This led to additional environmental problems, which affected local livelihoods, restricted economic development, increased social instability and tested relations between nations (Patnaik, 2016; Tookey, 2007). Equity in the use of ES among countries has also become a central issue (Cai et al., 2002; Simoncini et al., 2019).

# 2.2 Definitions

We define the supply, demand and flows of four ES based on the UN System of Environmental Economic Accounting-Ecosystem Accounting (SEEA EA, 2021) and other recent research (Table 1).

# 2.3 | Quantifying ecosystem services, supply, demand and flows

# 2.3.1 | Freshwater

The provision of freshwater ES can be calculated using freshwater yield (i.e. the amount of run-off across the landscape; Li et al., 2017). We used the water yield module in InVEST 3.6.0 to estimate water yield in Central Asia (Sharp et al., 2018), considering the influences of land use, soil type and vegetation but without distinguishing between surface, subsurface and base flows (Qin et al., 2019). The water yield model is based on annual average precipitation and evapotranspiration using the Budyko curve. Annual water yield for each pixel $(Y_{xj})$ with land use/land cover (LULC) can be determined as follows (Li et al., 2017; Qin et al., 2019; Zhang et al., 2001):

$$
Y _ {x j} = \left(1 - \frac {\mathrm {A E T} _ {x j}}{P _ {x}}\right) \times P _ {x}, \tag {1}
$$

where $Y_{xj}$ denotes the annual water yield on pixel $x$ with LULC $j$ , $AET_{xj}$ represents the actual evapotranspiration and $P_x$ is the annual precipitation on pixel $x$ . Additionally, $\frac{AET_{xj}}{P_x}$ reflects water balance, which is an approximation of the Budyko curve, proposed by Fu (1981) and Zhang et al. (2001) as follows:

$$
\frac {\mathrm {A E T} _ {x j}}{P _ {x}} = 1 + \frac {\mathrm {P E T} _ {x j}}{P _ {x}} - \left[ 1 + \left(\frac {\mathrm {A E T} _ {x j}}{P _ {x}}\right) ^ {\omega} \right] ^ {1 / \omega}, \tag {2}
$$

where $\mathsf{PET}_{xj}$ is the potential evapotranspiration on pixel $x$ , $\omega$ is a nonphysical parameter representing natural climate-soil properties, which can be calculated following the formula proposed by Donohue et al. (2012):

![](images/9d257e007cd42076f1555f6393e145ea7e39ee09b0a965c7fd7c235501ec6349.jpg)  
FIGURE 1 Location of the study region. (a) Map of Central Asia, (b) topography and major water bodies and (c) land cover. Land cover data were obtained from the MODIS Terra Aqua Combined Land Cover product MCD12Q1 (https://modis-land.gsfc.nasa.gov/landcover.html). Digital elevation model (DEM) data were obtained from the Shuttle Radar Topography Mission (SRTM) database (http://srtm.csi.cgiar.org/). The terrain map was obtained from Esri, USGS and NOAA

$$
\omega_ {x} = Z \frac {\mathsf {A W C} _ {x}}{P _ {x}} + 1. 2 5, \tag {3}
$$

where $Z$ is an empirical constant and $\mathsf{AWC}_x$ is the available water capacity on pixel $x$ . We assembled data layers for the key parameters of average annual precipitation, annual potential evapotranspiration, root-restricting soil depth, plant available water content, land use/land cover and watersheds (Table S.1.1).

We estimated anthropogenic freshwater demand as water consumption by agricultural, domestic and industrial uses (Boithias et al., 2014). Corresponding data in the five Central Asian countries were obtained from the Food and Agriculture Organisation's (FAO) AQUASTAT dataset (FAO, 2016). Since some relevant data

were scarce in 2016, we used the average value of other years to estimate freshwater consumption (Table S1). We combined these data with land-use type, population density and gross industrial production to visualise the spatial distribution of water consumption (Li et al., 2017; Xie et al., 2019). Total freshwater demand was calculated as:

$$
D _ {x} = D _ {\text {a g r}, x} + D _ {\text {d o m}, x} + D _ {\text {i n d}, x} = \operatorname {A g r} \times C _ {x} + \operatorname {D o m} \times P _ {x} + \operatorname {I n d} \times G _ {x}, \tag {4}
$$

where $D_{\mathrm{agr},x}D_{\mathrm{dom},x}$ and $D_{\mathrm{ind},x}$ represent agricultural, domestic and industrial water consumption for pixel $x$ respectively. Agr denotes irrigation water per unit of cropland and $C_x$ indicates the area of cropland on pixel $x$ . Dom indicates the amount of water consumed per person and $P_x$ denotes population of pixel $x$ . Ind indicates the amount of water

TABLE 1 Definition of the supply, demand and flows of freshwater provision, food provision, carbon sequestration and cultural ecosystem services in this study   

<table><tr><td></td><td>Supply</td><td>Demand</td><td>Flows</td></tr><tr><td>Freshwater provision</td><td>The physical amount of water yield from natural systems, which largely depends on climatic and topographic factors. The supply of water ES plays a vital role in human survival and development (Boithias et al., 2014; Chen et al., 2020)</td><td>Consumption of water resources by people via living and production activities, and emphasising the spatial distribution of anthropogenic demand for water (Li et al., 2017; Qin et al., 2019)</td><td>Freshwater ES flows were calculated as the portion of a country&#x27;s total freshwater ES demand that is met by run-off from another country</td></tr><tr><td>Food provision</td><td>The capacity of cultivated fields (i.e. cropland) to provide agri-food products (Ala-Hulkko et al., 2019; Schröter et al., 2014)</td><td>Human final consumption of food during a given reference period. Population is one of the most influential determinants of food demand</td><td>Trade and transport of agri-food products from areas of food production (supply) to areas of consumption (demand) (Ala-Hulkko et al., 2019)</td></tr><tr><td>Carbon sequestration</td><td>The capacity of vegetation to capture and store atmospheric carbon dioxide in biomass (Li, Li, et al., 2019), which reduces the amount CO2 in the atmosphere and resultant global warming</td><td>Carbon demand was created via the assumption that, as signatories to the Paris signatories Climate Agreement, all five Central Asian nations would need to become carbon neutral. This creates scarcity and demand for carbon sequestration to offset national greenhouse gas emissions calculated as the total anthropogenic greenhouse gas emissions produced across all sectors of the economy for each country (Davis &amp; Caldeira, 2010)</td><td>Carbon flows were calculated as the embodied greenhouse gas emissions in goods and services that are traded between countries. Under the Sustainable Development Goal (SDG) 12 principle of responsible consumption and production, we assumed the responsibility for offsetting the emissions embodied in traded goods accrue to the consumer country, rather than the producer. Thus, greenhouse gases emitted by one country via processes of production of goods and services that are ultimately exported to another country creates a flow of carbon services equal to the emissions embodied in the traded goods and services</td></tr><tr><td>Cultural services</td><td>Non-material benefits that people derive from human-ecological relations (Chan et al., 2011; Tew et al., 2019). We interpret supply as the recreation potential and possibility to benefit from natural ecosystems without human input (Schirpke et al., 2018) via the biophysical attributes and accessibility to people</td><td>The direct use of areas for recreation by beneficiaries, mapped as the locations where the beneficiaries live, rather than where the recreational services were accessed (Schirpke et al., 2018; Wolff et al., 2015)</td><td>The actual level of use of specific areas for recreation and the number of people participating in actual recreation activities within a given time and place. Tourist arrivals and the number of overnight stays are regarded as key indicators (Burkhard et al., 2012)</td></tr></table>

consumed by industry per ten thousand USD of production and $G_{x}$ refers to total gross industrial production on pixel x. The total amount of water consumed for each grid cell was obtained by summing the three types of water consumption.

We calculated freshwater ES flows across the five countries via surface water run-off for the three major trans-boundary rivers: the Amu Darya, Syr Darya and Chu river. Run-off was calculated as flow accumulation based on three components: water yield, water consumption and flow direction (Li et al., 2017; Xie et al., 2019; Supporting Information S.2). The calculation of water yield is described above. Flow direction was calculated based on a digital elevation model (DEM) and stream network data, with the DEM data obtained from the Shuttle Radar Topography Mission (SRTM) at

90 m grid-cell resolution. We considered that, after satisfying local water demand, surplus run-off flows to downstream countries (Lin et al., 2020; Figure S2). As not all run-off is used by beneficiaries, only that portion that meets demand was formally considered to be freshwater ES flows. Hence, ES flows were calculated as the portion of a country's total freshwater ES demand that is met by run-off from another country.

# 2.3.2 Food

We quantified food supply, demand and flows based on crop production, consumption and trade. Crop categories including fibre

crops, cereals, coarse grain, fruit, oil crops, pulses, roots and tubers and vegetables were consistent in calculating crop supply, demand and flows. Previous research has indicated that the capacity of cultivated lands can be used to map food supply (Schröter et al., 2014). We used the MODIS product MCD12Q1 to map croplands for the five Central Asian countries in 2016. This dataset reflects the spatial capacity to produce crops, including cultivated fields and uncultivated areas. To obtain information on food production efficiency in each country, we used data from the FAO (http://www.fao.org/faostat/en/#data/QC, Table S2) which specifies the total crop production harvested per unit of land. Thus, the spatial distribution of food ES supply (crop yield per hectare) was computed by dividing the spatial layer of total crop production by the total cropland area for each country. To derive food supply for human consumption, we considered a supply-chain food loss (e.g. production, harvest, post-harvest and transportation; Ala-Hulkko et al., 2019) of $20.7\%$ (FAO, 2019).

We used a raster database of the Central Asian population (https://landscan.ornl.gov/landscan-datasets) and food consumption data to generate the food demand spatial layer. Data on the average quantity of food consumed per capita per year for the five Central Asian countries were obtained from FAOSTAT's New Food Balance Sheets (2016, Table S3). Crop demand for each country was calculated by multiplying the respective quantity of food consumption per capita per year with population density.

Biophysical flows can be interpreted as the transportation of goods between a sending and receiving system via trade (Schröter et al., 2018). Based on previous research, we used international food (crop) trade data in 2016 to depict food flows among Central Asian countries. Data were obtained from the resourcetrade-earth (Chatham House, 2018; Table S4).

# 2.3.3 | Carbon sequestration

We used net primary productivity (NPP) to estimate the carbon sequestration supply service. NPP not only represents actual situation of vegetation but also the degree of variation in ecosystem carbon sequestration. The Carnegie-Ames-Stanford approach (CASA) model was developed to evaluate NPP at both global and regional scales (Guo et al., 2020; Potter et al., 1993; Wen et al., 2018). The simulation was determined by two factors, that is, absorbed photosynthetically active radiation (APAR) and use of light energy $(\varepsilon)$ , as follows:

$$
N P P _ {A} (x, t) = A P A R (x, t) \times \varepsilon (x, t), \tag {5}
$$

where $x$ is the pixel location and $t$ is time. APAR $(x, t)$ denotes the photosynthetically active radiation absorbed by the vegetation canopy at pixel $x$ in time $t$ and $\varepsilon(x, t)$ represents the actual light-use efficiency of pixel $x$ in time $t$ , which is the efficiency of vegetation for fixing solar energy, and is largely influenced by temperature and moisture

(Li et al., 2012; Potter & Klooster, 1997; Zhang, Liang, et al., 2018). APAR(x, t) and $\varepsilon(x, t)$ can be calculated as:

$$
A P A R (x, t) = S O L (x, t) \times F P A R (x, t) \times 0. 5, \tag {6}
$$

$$
\varepsilon (x, t) = T _ {1} (x, t) \times T _ {2} (x, t) \times W (x, t) \times \varepsilon_ {\max }, \tag {7}
$$

where $\mathrm{SOL}(x,t)$ is the total solar radiation of pixel $x$ in time $t$ , $\mathrm{FPAR}(x,t)$ denotes the fraction of photosynthetically active radiation absorbed by vegetation, the constant value 0.5 represents the proportion of the total solar radiation available for vegetation. $T_{1}(x,t)$ and $T_{2}(x,t)$ represent the stress effects on light-use efficiency at low temperature and high temperature respectively. $W(x,t)$ is the water stress coefficient, it can be calculated by following equation (Piao et al., 2001):

$$
W (x, t) = 0. 5 + 0. 5 \times \left[ E (x, t) / P (x, t) \right], \tag {8}
$$

where $E(x, t)$ is the estimated evapotranspiration of pixel $x$ in time $t$ , and $P(x, t)$ is the potential evapotranspiration of pixel $x$ in time $t$ . Both of these parameters can be computed following Piao et al. (2001) and Yu et al. (2009). $\varepsilon_{\text{max}}$ is the maximum light-use efficiency under ideal conditions (derived from Zhu et al., 2007). Further information on maximum light-use efficiency and the CASA model can be obtained from Zhu et al. (2005, 2007). We applied monthly solar radiation, monthly average temperature, monthly total precipitation, NDVI and land cover datasets to calculate above parameters of CASA model (Yu et al., 2009).

The spatial distribution of demand for carbon sequestration can be approximated by greenhouse gas emissions (Xie et al., 2019). To make this connection, we assume that under the global Paris Climate Agreement, nations will need to become carbon neutral. This policy assumption creates a demand for carbon sequestration equal to national anthropogenic greenhouse gas emissions. We used the emission coefficient approach proposed by the Intergovernmental Panel on Climate Change (2007), which has been widely used in research in greenhouse gas emissions estimation (Hovenga et al., 2016; Wang, Zhao, et al., 2019) and national greenhouse accounting. While it is difficult to quantify spatial disparities in greenhouse gas emissions, we estimated the spatial distribution of carbon sequestration demand based on per capita greenhouse gas emissions and the distribution of population density (Li et al., 2019) as follows:

$$
C _ {e} = \sum_ {x = 1} ^ {X} \rho (x) \times \varphi (x), \tag {9}
$$

where $C_e$ denotes the total amount of greenhouse gas emissions (i.e. demand for carbon sequestration), $\rho(x)$ is the population density on pixel $x$ acquired from the Landscan population database, and $\varphi(x)$ represents the annual carbon emissions per person on pixel $x$ , obtained from the Carbon Dioxide Information Analysis Centre (https://cdiac.ess-dive.lbl.gov/, Table S5).

To identify the trans-boundary flows of carbon, we quantified the flows of embodied $\mathrm{CO}_{2}$ in traded goods from producer/exporter countries to consumer/importer countries using multi-regional input-output (MRIO) analysis. The logic of this is underpinned in the principle of responsible consumption and production (SDG12). Under SDG12, we assumed that the responsibility for offsetting the emissions embodied in traded goods and services accrue to the consumer country, rather than the producer. We used the Eora dataset (https://www.worldmrio.com/footprints/carbon/, Table S6) to calculate consumption-based accounting emissions for each country. The flows of carbon emissions follow the transfer of $\mathrm{CO}_{2}$ emissions embodied in the processes of commodity production in a producer/exporter country (largely via energy consumption and transport) to meet demand in a consumer/importer country via international trade (Li et al., 2020). Embodied $\mathrm{CO}_{2}$ inflows for consumer/importer countries reflect the carbon emissions of producer/exporter countries emitted in the process of meeting demand for imported products. Conversely, embodied $\mathrm{CO}_{2}$ outflows for a producer/exporter country refer to the emissions resulting from the production of goods exported to meet consumer demand for products by consumer countries (Supporting Information S.3).

# 2.3.4 Cultural (Recreation)

Cultural ES refer to the non-material benefits that people derive from human-ecological relations (Chan et al., 2011; Tew et al., 2019). We assessed the supply of cultural ES considering both the recreation potential of nature and its accessibility (Martinez-Harms et al., 2018, 2021). We considered conservation land uses (e.g. protected areas, national parks, wilderness areas and nature reserves), water bodies and mountains in Central Asia in evaluating recreation potential. These areas were mapped and assigned a value of 1 (zero elsewhere) to indicate areas of recreation potential (Paracchini & Capitani, 2011; Schirpke et al., 2018). Accessibility influences recreation service use by people (Ala-Hulkko et al., 2016; Koppen et al., 2014; Schirpke et al., 2018; Wolff et al., 2015) and is determined by regional topography, land cover type and transportation infrastructure such as railways, highways and paved and unpaved roads. We calculated impedance with weights assigned to land cover type, topography (slope and elevation) and transport networks (from OpenStreetMap; Supporting Information S.4). This impedance layer was then used to calculate accessibility to areas of recreation potential using a cost-distance function.

The size and composition of a population determines the demand for cultural ES (Wolff et al., 2015). Previous studies have reported that population density has an important effect on the utilisation of cultural ES (Aiba et al., 2019; van Zanten et al., 2016; Weyland & Laterra, 2014). Hence, we used population density as a proxy for local recreational demand (Verhagen et al., 2017).

Cultural ES flows reflect the actual use of cultural ES by beneficiaries (Burkhard et al., 2014; He et al., 2019). We used tourist

numbers (excluding non-Central Asian visitors) in Central Asian countries in 2016 to quantify cultural ES flows, reflecting outdoor recreation use in terms of visitation rates. Tourist arrivals were obtained from the World Tourism Organisation (https://www.e-unwto.org/, Table S7), which contains inbound and outbound tourism data by country. Since inbound tourism data for Turkmenistan in 2016 were lacking, we only considered cultural ES flows between the other four countries.

# 2.4 Assessing telecoupling intensity

To reveal the degree of telecoupling effects of multiple ES between countries, we developed a metric describing telecoupling intensity, which reflects trans-boundary ES interdependence between countries. Telecoupling intensity quantifies the proportion of ES inflows from other countries contributing to the total ES demand met within a given country. The equation is as follows:

$$
\mathrm {T I} _ {i j s} = \frac {\text {F l o w} _ {j i s}}{\text {D e m a n d} _ {i s}}, \tag {10}
$$

where $\mathsf{T}\mathsf{l}_{ijs}$ denotes the degree of telecoupling intensity of country $i$ with country $j$ for ecosystem service $s$ , $\mathsf{Flow}_{jis}$ represents the flow of ES $s$ from country $j$ to country $i$ and $\mathsf{Demand}_{is}$ is the total domestic demand for ES $s$ of country $i$ . Values of telecoupling intensity near zero for a country indicate that most of its domestic ES demand is met within its own borders, whereas a value near to 1 indicates a high degree of telecoupling and dependence of country $i$ upon country $j$ for the provision of ES $s$ .

# 3 | RESULTS

# 3.1 Water

The supply, demand and flows of freshwater ES were spatially clustered within Central Asia (Figure 2). Supply was concentrated in the upper catchments of rivers in Kyrgyzstan, Tajikistan and the east of Kazakhstan. Lower supply capacity was distributed in downstream areas such as Turkmenistan, Uzbekistan and most of Kazakhstan (Figure 2a,d). Uzbekistan exhibited the highest demand for water (58,264 GL) while other regions with high demand were distributed in the south of Turkmenistan, the borders between Kazakhstan and Kyrgyzstan and the southwest of Tajikistan (Figure 2b,d). Comparing water supply and demand, Uzbekistan and Turkmenistan showed large deficits (i.e. local water demand was greater than supply).

All countries excluding Kazakhstan provided water provisioning service flows to neighbouring countries, while Kyrgyzstan was the only one that did not receive water flows from others (Figure 2c,d). Net flow (i.e. the difference between total inflows and total outflows) in Tajikistan and Kyrgyzstan was negative; in these two countries,

![](images/efb1af88c953b0308a735ba9d082adc733e97522873d589b1656e6ae43e39e34.jpg)

![](images/1353b03523f04a4417cd931daf1618147a97f7d66c9d1ddce5526022b995012c.jpg)

![](images/1f78c317ef677206c0c6483f093e7942fb537caffa51b7d4dc34a1f22907d189.jpg)

![](images/eb5f53ae5c663269211c1a3886fc8931dfe1858626ea0d519cae44281dfab6a2.jpg)  
FIGURE 2 Water (a) supply, (b) demand, (c) service flows among countries and (d) flows summaries in five Central Asian countries in 2016. KAZ, Kazakhstan; KGZ, Kyrgyzstan; TJK, Tajikistan; TKM, Turkmenistan; UZB, Uzbekistan

![](images/363abcdf6c793543c59d1a5f06f8a1c4b613f8dea1881ebf5b1b7c16fd71d58c.jpg)

![](images/45ba86a9c4772bc7d2a3118bc227b860fad1314531f6e3cf6113fbaf69b944bd.jpg)

![](images/89fd370f290ea2c427139221f2e6ae112eb9bd9d3c5e482a487651b2a3a22d89.jpg)

![](images/6f44563e864ce9cdfd8d3830dc53a71c594d43faa99a7afe11264e28f7850042.jpg)  
FIGURE 3 Food (a) supply, (b) demand, (c) service flows among countries and (d) flows summaries in five Central Asian countries in 2016. KAZ, Kazakhstan; KGZ, Kyrgyzstan; TJK, Tajikistan; TKM, Turkmenistan; UZB, Uzbekistan. Note: trade with the rest of the world is not presented

the total outflows of water (20,483 and 15,649 GL respectively) were greater than the total inflows of water (4,573 and 0 GL respectively). For the other three countries, the physical inflows of water provision were greater than corresponding physical outflows.

# 3.2 | Food

Our analysis showed substantial spatial variation in food provisioning services via crop supply, demand and flows across Central Asia (Figure 3). Crop supply matched the spatial distribution of cultivated land and was concentrated in the northern regions of Kazakhstan and Kyrgyzstan, the east of Uzbekistan and the southern areas of Turkmenistan and Tajikistan. Food demand mirrored population density and was centralised in the Fergana Valley (i.e. eastern Uzbekistan, northern Tajikistan and southern Kyrgyzstan; Figure 3b). Food demand in Uzbekistan and Kazakhstan was much higher than in the other three countries (Figure 3b,d).

Kazakhstan played an important role in providing food to other countries (Figure 3c,d), with a crop export volume of 4.37 million tonnes, of which $65.1\%$ flowed to Uzbekistan, $26.9\%$ to Tajikistan and the remaining $8\%$ to Kyrgyzstan and Turkmenistan. Kazakhstan only received 0.6 million tonnes of food from the other countries, while they generally exhibited net positive inflow. The trans-boundary inflows and outflows of food were substantially different for Uzbekistan, where inflows (2.85 million tonnes) were much larger than outflows (0.49 million tonnes).

# 3.3 | Carbon sequestration

Carbon sequestration supply was mainly distributed in the northern and south-western areas (Figure 4a). Kazakhstan sequestered 2,253 million tonnes of carbon in 2016 via net primary production, approximately 3.5-fold the total carbon sequestration service provided by the other four countries. The spatial distribution of carbon sequestration demand showed a very different pattern to that of supply, being high in cities and surrounding areas (Figure 4a,b). Kazakhstan also had the highest demand for carbon sequestration (~275 million tonnes), followed by Uzbekistan (99 million tonnes) and Turkmenistan (77 million tonnes; Figure 4d).

The flows of carbon among countries were similar, except for Tajikistan, which had low outflow (Figure 4c). More specifically, Kazakhstan, Kyrgyzstan and Turkmenistan showed negative net inflow, while Tajikistan and Uzbekistan showed positive values (Figure 4d). Tajikistan had the highest carbon net inflow (0.8 million tonnes).

# 3.4 Cultural

We found high spatial variation in the supply, demand and flows of the recreational service across the study area (Figure 5). The highest cultural ES supply values were concentrated in mountain ecosystems, especially in Kyrgyzstan and Tajikistan (Figure 5a), but these areas typically showed low ES demand (Figure 5b). In contrast,

![](images/08ed0bedb126824ce7d77866003bf00b4d795096c4a30acbc921c3bdb279d818.jpg)

![](images/1c7e59e3cbd8178451c941e23c77580ac115562e8daf90d7ab6acf72ebed5e19.jpg)

![](images/c8268ab566354139e47e7192e22f3c1001caae822ab900c4b6e9cda0b0bfec69.jpg)

![](images/e64620ca7cecbc68eaa093e86118798cb421fc1a4169f8b624bdaec3a84b4a49.jpg)  
FIGURE 4 Carbon sequestration (a) supply, (b) demand, (c) service flows among countries and (d) flows summaries in five Central Asian countries in 2016. KAZ, Kazakhstan; KGZ, Kyrgyzstan; TJK, Tajikistan; TKM, Turkmenistan; UZB, Uzbekistan

cultural ES demand was clustered in urban agglomerations, especially in the eastern areas of Uzbekistan (Figure 5b).

In 2016, the number of inbound visitors in Kazakhstan and Kyrgyzstan reached more than 4.0 and 3.1 million, respectively, making the two countries the largest tourism destinations in Central Asia. There were more than 3.9 and 2.8 million outbound visitors in Kazakhstan and Uzbekistan respectively. Uzbeks accounted for $60\%$ of total international tourists to Kazakhstan, while Kazaks travelled mostly to Kyrgyzstan (comprising $\sim 80\%$ of Kyrgyzstan's inbound visitors). Kyrgyzstan showed the highest recreation potential capacity and showed the largest net flow.

# 3.5 Telecoupling of ecosystem service flows in Central Asia

Telecoupled interdependencies between Central Asian countries displayed complex directional relationships ranging from strong dependencies for some ES to no telecoupling relationships at all (Table 2; Figure 6). Freshwater telecoupling was characterised by complex and strong interdependencies as the major trans-boundary rivers crisscrossed national borders several times. Turkmenistan was strongly telecoupled with Uzbekistan (82.82%), Tajikistan with Uzbekistan (38.82%) and Uzbekistan with Tajikistan (35.15%), Kyrgyzstan (25.63%) and Turkmenistan (18.66%). For food ES, Tajikistan (50.84%), Uzbekistan (21.72%) and Kyrgyzstan (14.29%) were strongly telecoupled with Kazakhstan. For carbon ES, telecoupling intensity was generally lower, with the major dependency being Tajikistan on Turkmenistan (7.73%). For cultural ES, Tajikistan showed strong telecoupling to Kyrgyzstan (28.92%), Kazakhstan (24.73%) and Uzbekistan (20.20%), and Kazakhstan was strongly telecoupled with Kyrgyzstan (20.72%).

# 4 | DISCUSSION

We quantified the supply, demand and flows of water provision, food provision, carbon sequestration and recreation among five Central Asian countries and found complex patterns and telecoupling of ES flows from local to trans-boundary scales. Uzbekistan was the biggest ES beneficiary, especially in terms of water and food provision. Kazakhstan was the biggest supplier of food and carbon ES, while Tajikistan was relatively isolated from the other countries and on the periphery of ES flows, providing and receiving few ES from outside its national border. Each country had a net surplus (i.e. where supply exceeded demand) for all ES except water provision as Uzbekistan and Turkmenistan relied on water flows from Tajikistan and Kyrgyzstan to meet demand.

# 4.1 Effect of trans-boundary ES flows

Our analysis showed heterogeneous spatial relationships in ES supply and demand in Central Asia. Spatial mismatches occurred

between natural ecosystems and human-dominated environments where some regions with substantial supply capability had low demand, while in other areas where ES demand outstripped supply, demand was met by distant ecosystems (e.g. recreation; La Notre et al., 2019; Schirpke et al., 2019; Vallecillo et al., 2019). The relationship between supply, demand and flows is complex (Bryan et al., 2018; Schroter et al., 2018) and some services showed high levels of dependency on a spatially constrained supply (e.g. food provision; Figure 4), while other services (e.g. water provision) were delivered continuously to other countries to fulfil demand (Schirpke, Egarter Vigl, et al., 2019). Cultural ES flows were determined not only by nature and scenery but also accessibility, tourism infrastructure and reputation (Schägner et al., 2016; Schirpke, Egarter Vigl, et al., 2019). Thus, the supply of ES was mainly driven by natural factors (e.g. climate, vegetation and landscape conditions) and demand was largely driven by human consumption patterns (Kleemann et al., 2020; Odum, 2007).

Telecoupled ES flows reflected complex interactions between people and nature (Liu et al., 2013; Xie et al., 2019). For instance, cotton production contributes about $13\%$ of GDP in Uzbekistan through exports (mainly to China, Russia, and Turkey; Djanibekov & Finger, 2018). However, due to a high dependence on irrigation, Uzbekistan relies on water inflows from Tajikistan and Kyrgyzstan. As a result, the environment and economy of Uzbekistan, Tajikistan and Kyrgyzstan are linked via cotton production, providing a microcosm for the high level of interdependence among these countries. Unsustainable management of cotton production may cause fluctuations in agricultural trade, degrade ecosystems (particularly water-dependent ecosystems) and their carbon sequestration ability, and impact the contributions to people from ecosystems in remote regions (Cerilli et al., 2020). In another example, Central Asia has a broad range of mineral resources (e.g. coal, oil, gas, precious metals and non-ferrous metals), that are unevenly distributed throughout the five countries. After the collapse of the Soviet Union, to seek new economic and commercial opportunities, governments established unprecedented international trade cooperation in minerals, crude oil and natural gas. Over the past two decades, Kazakhstan's economy has depended heavily on the export of petroleum and minerals (Wang, Hong, et al., 2019). However, fossil fuel production and use have significant implications for carbon emissions. Thus, the greenhouse gas emissions embodied in the trade in these commodities are significant for importer countries who need to offset their emissions through capturing and storing atmospheric carbon dioxide (Liddle, 2018; Zheng et al., 2020).

# 4.2 | Implications for management and decision-making

Our results revealed that there are distinct patterns of supply, demand and flows for multiple ES reflecting a telecoupled relationship and interdependence between people and nature across the five Central Asian nations. As trans-boundary ES flows are affected

![](images/2fc9e1d73bfb9f99e7daebfb4be9c021b5335a659f3b59cc20e823235e0d4f31.jpg)

![](images/bfd0d2703801b4955ad88b80fe3da335bc8155f6d0f2c0d99a46a320078b1e09.jpg)

![](images/1f54fb00154e00cffd356b1d479e3f0cbdf6ca1b14b10684967f498bc09a69d7.jpg)

![](images/f2704d46a5128584ea5f90f9646fb1913759c912278e708a1e66e65856129175.jpg)  
FIGURE 5 Cultural service (a) supply, (b) demand, (c) service flows among countries and (d) flows summaries in Central Asian countries in 2016 (Note: data for Turkmenistan were excluded in (c) and (d) due to a lack of availability). Since recreation supply could not be quantified through tourist numbers, we set a secondary Y axis to show the relative recreation potential for the five countries. KAZ, Kazakhstan; KGZ, Kyrgyzstan; TJK, Tajikistan; TKM, Turkmenistan; UZB, Uzbekistan

by both local and distant governance regimes, an overarching and connected governance system is needed to achieve ES sustainability (Kleemann et al., 2020; Oberlack et al., 2018). Human intervention is required to manage ES flows and achieve a balance between the use of natural resources and the maintenance of ES (Schirpke, Egarter Vigl, et al., 2019; Verburg et al., 2015). Assessment of transboundary ES flows can provide insights into policy interventions for ecosystem protection and interregional cooperation. Furthermore, long-term management of ES and sustainable development is essential for the improvement of the regional economy and security as well as enhancing peace and stability between neighbouring countries.

# 4.2.1 Water

Historical freshwater scarcity has put pressure on human development in Central Asia (Uitto & Duda, 2002). Water ES provision is not only determined by the local socio-ecological context but also by the regional climate, topography, hydrology and upstream demand (Kleemann et al., 2020). Our results showed substantial spatial variation in water ES supply in Central Asia, as well as in water demand. In particular, Uzbekistan and Turkmenistan showed large deficits in water ES and were dependent on the flows of water from upstream countries Tajikistan and Kyrgyzstan. Heavy water dependence, especially by agriculture, has led to conflict over water resources within and between countries (Russell, 2018). Enhanced cross-border cooperation in water management is a prerequisite to avoid further water conflicts and to stabilise bilateral relations (Uitto

& Duda, 2002). Governing water resources sustainably and equitably requires effective engagement by a diverse range of stakeholders and decision makers. Integrated watershed governance should be considered based on natural boundaries instead of basing water management on national borders. Countries sharing watersheds need to collaborate to establish water sharing rules to safeguard common interests in access to water resources.

Examples exist of Central Asian countries collaborating to share limited water resources fairly and to optimise water management in recent decades. For instance, in 1992, the Interstate Coordination Water Commission of Central Asia, comprised of the five Central Asian countries, was founded with a focus on the water issues concerning the two main rivers, that is, the Amu Darya and Syr Darya, particularly in water allocation and protection of water resources (Tooley, 2007). However, cooperation among five independent countries is more difficult than under the centralised management of the former Soviet Union as national borders have become more of a barrier (Russell, 2018). Thus, stronger and more effective actions are needed to establish an equitable and fair convention for water management. First, evaluating the availability and adequacy of existing international water conventions is necessary (Rahaman, 2012). Assessment of trans-boundary ES flows and a consideration of spatial heterogeneity in the distribution of natural resources should inform fairer resource allocation (Kleemann et al., 2020). Second, the enforcement of these conventions is essential (Rahaman, 2012) to encourage more efficient water use, alleviate scarcity and maintain balance between water supply and demand. Each country should implement both international and domestic water treaties. As upstream countries, Kyrgyzstan and Tajikistan need more effective participation

TABLE 2 Telecoupling intensity of four ES among five Central Asian countries. ES Beneficiary and ES Provider denote the ecosystem service benefiting country and ecosystem service provisioning country respectively   

<table><tr><td rowspan="2">ES beneficiary</td><td rowspan="2">ES provider</td><td colspan="4">Telecoupling intensity (%)</td></tr><tr><td>Water</td><td>Food</td><td>Carbon</td><td>Cultural</td></tr><tr><td rowspan="4">Kazakhstan</td><td>Kyrgyzstan</td><td>2.87</td><td>0.40</td><td>0.17</td><td>20.72</td></tr><tr><td>Uzbekistan</td><td>4.51</td><td>8.19</td><td>0.24</td><td>11.13</td></tr><tr><td>Tajikistan</td><td>0.00</td><td>1.78</td><td>0.01</td><td>0.11</td></tr><tr><td>Turkmenistan</td><td>0.00</td><td>0.06</td><td>0.30</td><td>0.00</td></tr><tr><td rowspan="4">Kyrgyzstan</td><td>Kazakhstan</td><td>0.00</td><td>14.29</td><td>4.62</td><td>18.27</td></tr><tr><td>Uzbekistan</td><td>0.00</td><td>0.64</td><td>6.33</td><td>2.28</td></tr><tr><td>Tajikistan</td><td>0.00</td><td>0.78</td><td>0.12</td><td>1.81</td></tr><tr><td>Turkmenistan</td><td>0.00</td><td>0.05</td><td>1.60</td><td>0.00</td></tr><tr><td rowspan="4">Uzbekistan</td><td>Kazakhstan</td><td>0.00</td><td>21.72</td><td>1.18</td><td>2.54</td></tr><tr><td>Kyrgyzstan</td><td>25.63</td><td>0.01</td><td>0.71</td><td>0.36</td></tr><tr><td>Tajikistan</td><td>35.15</td><td>0.00</td><td>0.00</td><td>0.01</td></tr><tr><td>Turkmenistan</td><td>18.66</td><td>0.00</td><td>0.18</td><td>0.00</td></tr><tr><td rowspan="4">Tajikistan</td><td>Kazakhstan</td><td>0.00</td><td>50.84</td><td>4.04</td><td>24.73</td></tr><tr><td>Kyrgyzstan</td><td>0.00</td><td>0.02</td><td>3.24</td><td>28.92</td></tr><tr><td>Uzbekistan</td><td>38.82</td><td>0.00</td><td>0.51</td><td>20.20</td></tr><tr><td>Turkmenistan</td><td>0.00</td><td>0.00</td><td>7.73</td><td>0.00</td></tr><tr><td rowspan="4">Turkmenistan</td><td>Kazakhstan</td><td>0.00</td><td>3.58</td><td>0.40</td><td>0.00</td></tr><tr><td>Kyrgyzstan</td><td>0.00</td><td>0.10</td><td>0.11</td><td>0.00</td></tr><tr><td>Uzbekistan</td><td>82.82</td><td>0.00</td><td>0.69</td><td>0.00</td></tr><tr><td>Tajikistan</td><td>0.00</td><td>0.00</td><td>0.02</td><td>0.00</td></tr></table>

![](images/44c09c1904ce095dece923fadb3c93fd84cb605fc8578483d3b85f899d06176d.jpg)  
Ecosystem service telecoupling

![](images/60fbe933cf2466287a920bb1abc54741c4dfb19a1aaa52c0e90882c78fff8fa1.jpg)  
FIGURE 6 Summary of the telecoupling relationships among five Central Asian countries for the four ecosystem services: Freshwater, food, carbon, and cultural. Shown are all telecoupling relationships with $\mathrm{TI} > 1\%$

in the protection of water ecosystem of the region's shared rivers (Xie & Ibrahim, 2021; Ziganshina & Janusz-Pawletta, 2020). Actions such as enhancing irrigation technology and improving water resource management are required to promote more efficient agricultural water use. Furthermore, improving water efficiency in mining, energy and metallurgic industries, as well as increasing awareness of water conservation for citizens, will also help reduce water demand.

# 4.2.2 | Food

Our analysis highlights trade as an important trans-boundary flow for connecting ES-providing areas with beneficiaries. In Central Asia, a combination of local food production and imports secure food availability (Fischer et al., 2018). Under the substantial disparity in grain production and national economic power in the five

Central Asian countries, significant fluctuations in international food prices may threaten food security in countries with scarce arable land such as Kyrgyzstan and Tajikistan (Zhang et al., 2018). Also, our results (Figure 3; Table 2) illustrate that the two countries imported a large proportion of food ES. The dry climate in Uzbekistan and Turkmenistan presents a barrier to increasing food production. Combined with a large population size which drives food demand, maintaining a sustainable food system and ensuring food security is challenging for Uzbekistan. In addition, investment in agricultural research and development is insufficient to substantially boost agricultural production in most Central Asian nations, with the potential exception of Kazakhstan (Morgounov et al., 2001). Thus, considering the biophysical limitations and unstable food system, changing traditional agricultural product structures, promoting the cultivation of crops suitable for arid conditions, and enhanced international trade are all necessary to achieve a better balance between food supply and demand and enhancing food security (Geyik et al., 2021; Magrach & Sanz, 2020). Central Asian nations should strengthen cooperation in all aspects of the food system in order to meet food security and nutrition challenges, transitioning to more modern, productive, industrial and globalised food production and trade systems (Dupouy & Gurinovic, 2020; Kuslits et al., 2021). These transitions must occur in culturally appropriate ways which build upon local traditional ecological knowledge to ensure that livelihoods and food security of local people and communities are genuinely improved (Li et al., 2021).

# 4.2.3 | Carbon

Following market economic reform in the late 1990s, greenhouse gas emissions in Central Asia have increased along with economic growth (Karakaya & Ozcağ, 2005). Over the same period, markets have emerged as an effective tool for managing environmental goods and services, particularly carbon emissions (Settre et al., 2019), and emissions trading could help Central Asian countries curb their climate impacts. Based on our analysis (Figure 4), countries with high emissions such as Kazakhstan, Uzbekistan and Turkmenistan could purchase carbon offsets or the right to emit more from low-emitting countries (i.e. Tajikistan and Kyrgyzstan), potentially achieving cost-effective carbon emissions reduction. Ecological compensation could be included into these schemes to address trade-offs between economic development and ecosystem protection (Gao et al., 2020). Considering the ecological, social and economic disparities among the five Central Asian countries, ecological compensation could be implemented for local service providers through technological assistance, educational services and preferential policies (e.g. tax reductions or exemptions; Yu et al., 2020). Such policy mechanisms could compensate for foregone opportunities for development incurred from environmental conservation and ecological restoration (Bennett et al., 2018; Xiong & Li, 2019; Yu et al., 2020). The above-mentioned schemes could not only realise the objective of

cross-regional energy conservation and greenhouse gas emissions abatement, but also create conditions for promoting coordinated development among countries to achieve carbon neutrality in Central Asia.

# 4.2.4 Cultural

With the development and acceleration of economic globalisation, demand for cultural ES—in particular, outdoor recreation—has grown and local livelihoods have become more and more dependent upon the economic activity generated by cultural ES. Our results highlight the abundant natural resources, natural beauty and excellent recreation potential across Central Asia (Figure 5), and there is significant potential to further develop high quality international tourism opportunities. After the collapse of the Soviet Union, Central Asian counties have begun to develop their own tourism industries (Werner, 2003). Due to the disparity in economic position, some of the poorer countries like Tajikistan have several barriers to development such as a lack of transportation, infrastructure and facilities; limited tourism service capacity, and; limited expertise (Dermastia et al., 2017). To better exploit cultural ES potential and sustainably increase the benefits to all countries in Central Asia, several measures are required. First, developing a systematic tourism development plan to enhance regional natural attributes and improve cultural ES provision capability is vital. Second, investments in public infrastructure such as transportation and accommodation are urgent to meet recreation demand. Care must be taken to minimise the impacts of tourism infrastructure development on natural capital, in particular, ensuring that infrastructure does not impact on the provision of the very recreation and amenity services that attract tourists in the first place. Third, adopting positive and effective measures to protect ecosystem biodiversity, and maintain and restore ecological structure and function is paramount. Tourism development must occur in parallel with comprehensive planning for environmental management and ES protection. Furthermore, international tourism cooperation is needed to further expand to increase cultural ES complementarity among countries.

# 4.3 Limitations and uncertainty

Our study has a number of limitations particularly related to the uncertainty of model inputs and the complexity associated with modelling supply, demand and flows for four ES. Data availability is limited in Central Asia. To address this problem, we used multiple types of proxy data to represent ES supply, demand and flows. For instance, we used international tourist arrivals to quantify cultural ES flows even though part of these flows involve business activities instead of recreation. In addition, for food, we used crop production only and did not consider livestock which comprise a significant part of Central Asian diets. The results of the InVEST model also has

limitations. The InVEST water yield model is based on a simplification of the hydrological cycle, which only considers precipitation and evaporation and does not reflect all hydrological processes (Cong et al., 2020). For certain ES flows such as water, using a biophysical model may be a better option (Xie et al., 2019). Moreover, for some rival and excludable ecosystem goods with established markets such as food and freshwater, quantifying supply, demand and flows were more straightforward than for other non-rival and/or non-excludable services such as carbon sequestration and cultural services due to complex and uncertain ES flow mechanisms and processes and an absence of markets. Capturing the supply-demand relationships of these non-market ES required the use of multiple proxy datasets and models as well as policy assumptions (e.g. carbon neutrality) for creating markets.

Most ES are not purely ecosystem services provided solely via natural capital as they often involve the input of other forms of capital. Food, for example, not only involves natural capital but also human, built and financial capital via agricultural production. In addition, forms of capital other than natural also substantially contribute to food ES flows through processes like post-harvest processing and transportation. Here, we have ignored the contribution of human, built and financial capital to the supply and flows of food and other ES following recent typologies (SEEA EA, 2021). Future consideration of ES as food provision should attempt to disentangle nature's contribution from that of built, human and financial capital to better assess ES and to prevent unintended negative consequences of policy implementation (Vallecillo, La Notte, Kakoulaki, et al., 2019).

In quantifying the supply of carbon sequestration ES, we used net primary productivity of vegetation and did not consider ecosystem emissions, particularly via the breakdown of biomass and soil carbon loss, which are likely to be material. Future studies should consider using formal IPCC carbon accounting guidelines for calculating greenhouse gas emissions removals via land use, land-use change and forestry (LULUCF) activities rather than NPP alone, ensuring permanence and additionality of carbon sequestration. Another limitation is that we assessed trans-boundary ES flows the within the five Central Asian countries only and did not consider inflows and outflows of ES from other countries which are also likely to be significant. In addition, quantifying uncertainty is very challenging in trans-boundary ES assessments (Hamel & Bryant, 2017; Kleemann et al., 2020; Koellner et al., 2019), mostly due to the complexity of the modelled systems (Green et al., 2005; Kleemann et al., 2020). While uncertainty is likely to be significant, we do not expect it to have a material effect on our conclusions.

# 5 CONCLUSION

We combined multiple models with a range of environmental and socio-economic data to map the supply, demand and flows of four ES across five Central Asian countries. Our results showed different patterns for each ES flow from local to trans-boundary scales and revealed telecoupled interdependencies between people and nature

between specific countries for specific ecosystem services. Our research provided a number of recommendations for trans-boundary ES assessments and ES sustainability in arid and semi-arid regions, including strengthening cross-border cooperation for resource administration to provide better access to ES and optimise management; enhancing enforcement of the international conventions to sustain a balance between ES supply and demand; adjusting and optimising the supply infrastructure (e.g. agri-food cultivation) to relieve demand pressure; implementing ecological compensation to address trade-offs between ES, economic development and ecosystem protection. Our study illustrated that to seek a better balance between socioeconomic development and the sustainable supply of ES, the identification and quantification of trans-boundary ES telecoupling is crucial.

# SUPPORTING INFORMATION

Additional supporting information may be found in the online version of the article at the publisher's website.

How to cite this article: Wang, Y., Hong, S., Wang, J., Lin, J., Mu, H., Wei, L., Wang, Z., & Bryan, B. A. (2022). Complex regional telecoupling between people and nature revealed via quantification of trans-boundary ecosystem service flows. People and Nature, 4, 274-292. https://doi.org/10.1002/ pan3.10298
