# Quantification of embedded phosphorus in Mexican agriculture

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:48:01.094154+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Javier Alcantara-Plazola and de la Barrera - 2021 - Quantification of embedded phosphorus in Mexican agriculture.pdf
- Year: 2021
- DOI: 10.1016/j.spc.2021.07.011
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines how much phosphorus is contained in Mexican crop production and how this contributes to national and global phosphorus flows. It focuses on Mexico as a major agricultural exporter and potential hotspot in the planetary phosphorus cycle, with relevance to environmental limits and food security.

The authors quantify phosphorus embedded in harvested biomass for 38 key crops from 1980 to 2015, grouped as forages, cereals, fruits and vegetables, legumes, and cash crops. They combine official Mexican production and harvested-area statistics with crop-specific phosphorus contents compiled from agronomic and food composition literature, following a country-level accounting method previously developed for embedded phosphorus. Phosphorus embedded per crop is calculated either by multiplying tissue concentration by production mass or by multiplying areal phosphorus uptake by harvested area.

Over 35 years, Mexican agriculture produced roughly 5.5 billion tonnes of crops containing about 4.4 million tonnes of phosphorus. Total crop output rose by nearly 150 percent and embedded phosphorus by about 85 percent. Forages became the dominant production category, reflecting expansion of livestock systems; by the 2000s they accounted for over 40 percent of production and nearly 40 percent of embedded phosphorus, with sorghum forage particularly important. Cereals contributed a similar share of embedded phosphorus, mainly through maize. Cash crops such as sugarcane, avocado, agave, coffee, and soybean represented about one-third of production but less than one-fifth of embedded phosphorus, with sugarcane especially prominent. Fruits, vegetables, and legumes together made up a small share of total phosphorus removal but showed strong growth, driven in part by export-oriented horticulture after trade liberalization.

The paper explicitly links these trends to international trade agreements and growing exports of fruits, vegetables, sugar, tequila, and meat, positioning Mexico as an important exporter of embedded phosphorus. It is therefore directly relevant to telecoupling and metacoupling by highlighting how domestic fertilizer use and soil phosphorus depletion are connected to distant consumers via globalized food supply chains, and by calling for country-level phosphorus balances to assess sustainability and planetary boundary pressures.

## Structured Metacoupling Extraction

### Coupling Classification
- Telecoupling of Mexican agricultural phosphorus exports within globalized food and feed trade networks.

### Intracoupling
#### Systems
- Mexican agricultural regions and soils supplying phosphorus to national food and feed production.
- Domestic livestock and poultry sector consuming forage and grains.
- Mexican cities receiving phosphorus in food and waste streams.
#### Flows
- Embedded phosphorus in crops moving from rural fields to urban consumers.
- Phosphorus fertilizers applied to croplands from domestic or imported sources.
- Phosphorus transfer from soils into livestock products via forage and grains.
#### Agents
- Mexican farmers and livestock producers managing fertilizer and forage.
- National agricultural authorities and extension programs.
- Domestic food industry and retailers distributing agricultural products.
#### Causes
- Population growth increasing national food demand.
- Diet shift toward more meat and animal products.
- Fertilizer subsidies and uneven access to agricultural inputs.
#### Effects
- Rising phosphorus extraction from Mexican soils over 1980-2015.
- Potential soil phosphorus depletion in low input farms.
- Risk of phosphorus losses to Mexican freshwater and coastal ecosystems.

### Pericoupling
#### Systems
- Mexico and neighboring North American trade partners.
- Border livestock and forage production regions.
- Shared transboundary aquifers supporting irrigated agriculture.
#### Flows
- Embedded phosphorus in meat and feed traded within North America.
- Virtual water and phosphorus jointly exported through regional trade.
- Fertilizer and agricultural inputs moving among neighboring countries.
#### Agents
- North American trade institutions implementing NAFTA and USMCA.
- Cross border meat packing and feed companies.
- Regional water and agricultural regulators.
#### Causes
- Regional trade liberalization under NAFTA and USMCA.
- Rising meat demand in North American markets.
- Competitive advantages of Mexican horticulture and cash crops.
#### Effects
- Expansion of forage production for regional meat supply chains.
- Increased pressure on shared water and nutrient resources.
- Strengthened dependence on regional agricultural markets.

### Telecoupling
#### Systems
- Mexican agricultural system exporting crops, fruits, vegetables, and meat.
- Importing countries, especially the United States and global markets.
- Global phosphorus mining regions supplying fertilizer.
#### Flows
- Embedded phosphorus in exported fruits, vegetables, sugarcane products, avocado, and tequila.
- Embedded phosphorus and water in traded agricultural commodities.
- Imported mineral phosphorus fertilizers from distant mines.
#### Agents
- International agribusiness firms and commodity traders.
- Foreign consumers buying Mexican agricultural products.
- Global fertilizer producers and mining corporations.
#### Causes
- Global food system integration and demand for Mexican exports.
- Geographical concentration of phosphorus mineral reserves.
- Trade agreements enabling large scale agricultural exports.
#### Effects
- Net phosphorus outflow from Mexican soils to distant consumption centers.
- Contribution to global alteration of the phosphorus biogeochemical cycle.
- Potential future fertilizer supply risks for export dependent agriculture.

### Cross-Coupling Interactions
- Telecoupled export demand reinforces intracoupled forage expansion and livestock intensification.
- Pericoupled North American meat trade amplifies Mexican phosphorus and water extraction.
- Global fertilizer supply telecoupling constrains domestic phosphorus budgets and soil sustainability.

### Research Gaps or Limitations
- National phosphorus balance incomplete; imports, losses, and recycling only partly quantified.
- Export destinations and detailed trade based phosphorus flows not fully resolved.
- Reliance on self reported agricultural statistics may underestimate true phosphorus extraction.

### Search Keywords
- embedded phosphorus Mexican agriculture telecoupling
- phosphorus flows NAFTA USMCA livestock forage
- virtual water nutrient trade planetary boundaries

### Extraction Confidence
high
