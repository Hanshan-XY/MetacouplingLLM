# Fragmented sustainability governance of telecoupled flows: Brazilian beef exports to China

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:06:06.930724+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Sondergaard et al. - 2024 - Fragmented sustainability governance of telecoupled flows Brazilian beef exports to China.pdf
- Year: 2024
- DOI: 10.1080/09640568.2022.2118570
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This article examines how sustainability is (and is not) governed in the rapidly expanding, telecoupled beef trade from Brazil to China. It focuses on a South-South linkage where Chinese demand for animal protein increasingly shapes land use, deforestation, and rural livelihoods in Brazil.

Geographically, the study considers Brazil as the sending system and China as the receiving system, applying the telecoupling framework (systems, flows, agents, causes, effects) as an organizing lens. It concentrates on Brazilian livestock frontiers in the Amazon and Cerrado, and on Chinese import, sanitary, and trade institutions.

Methodologically, the authors combine qualitative and quantitative sources: Brazilian diplomatic archives, interviews with Brazilian officials, corporate reports from major meatpackers, public trade and deforestation statistics, and Trase supply chain data that traces beef exports back to producing municipalities and estimates associated deforestation risk.

The analysis shows that bilateral governance between Brazil and China has strongly prioritized trade expansion and sanitary-phytosanitary (SPS) issues, while largely ignoring environmental and social consequences. High-level commissions and strategic plans address market access and slaughterhouse licensing, but not deforestation or climate impacts. Environmental ministries have minimal involvement in the bilateral architecture.

In Brazil, public regulation is anchored in the Forest Code, but weak enforcement and political rollback enable extensive illegal clearing. Private governance – notably the Cattle Agreements (TAC and G4) and company commitments by JBS, Marfrig, and Minerva – has reduced deforestation among some direct suppliers, yet suffers from gaps such as indirect supplier leakage and incomplete coverage of smaller slaughterhouses. In China, sustainability expectations on beef imports are nascent and mostly voluntary, leaving China as a major leakage market for deforestation-risk beef.

The paper is explicitly grounded in telecoupling and metacoupling concepts. It demonstrates how fragmented, flow-blind governance across sending and receiving systems allows large telecoupled beef flows to carry significant embedded deforestation, greenhouse gas emissions, and social harms, and argues that coordinated, flow-centered policies in both countries are needed to align this South-South trade with stated climate and sustainability pledges.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling between Brazilian beef regions and Chinese consumer markets; intra- and peri-couplings mostly implicit.

### Intracoupling
#### Systems
- Brazilian cattle ranching regions including Amazon and Cerrado biomes
- Chinese domestic meat and food sector systems
#### Flows
- Internal Brazilian cattle movements among breeders, fatteners, slaughterhouses
- Domestic beef distribution and consumption in Brazil and China
#### Agents
- Brazilian ranchers and smallholders within frontier regions
- Brazilian meatpackers and domestic retailers
#### Causes
- Brazilian agrarian expansion and extensive ranching practices
- Weak enforcement of Brazil Forest Code and land tenure issues
#### Effects
- Local deforestation, biodiversity loss, and GHG emissions in Brazilian biomes
- Labor abuses and smallholder marginalization in Brazilian cattle regions

### Pericoupling
#### Systems
- Brazilian frontier municipalities supplying export slaughterhouses
- Neighboring domestic and regional beef markets acting as leakage sinks
#### Flows
- Leakage of noncompliant cattle to unsupervised slaughterhouses
- Beef re-exports via Hong Kong as transit to Mainland China
#### Agents
- Smaller Brazilian slaughterhouses operating with weaker controls
- Intermediary cattle traders laundering animals between suppliers
#### Causes
- Partial supply chain monitoring focused on direct suppliers
- Market power asymmetries allowing parallel noncompliant chains
#### Effects
- Spatial shifting of deforestation and illegality within Brazil
- Undermining of zero-deforestation and TAC, G4 agreements

### Telecoupling
#### Systems
- Sending system: Brazilian livestock production and export logistics
- Receiving system: Chinese beef import, processing, and retail networks
- Spillover systems: EU, US, global financial and ESG governance arenas
#### Flows
- Large-scale exports of Brazilian beef and bovine products to China and Hong Kong
- Capital, investment, and credit flows tied to meatpackers and Chinese buyers
- Information flows via trade, SPS protocols, ESG guidelines, NGO campaigns
#### Agents
- Brazilian government ministries, embassies, and export promotion agencies
- Chinese customs, agricultural regulators, and meat industry associations
- Large meatpackers JBS, Marfrig, Minerva plus Chinese import companies
#### Causes
- Rising Chinese meat demand and dietary shifts, intensified by swine disease
- Brazilian comparative advantages and active export-oriented diplomacy
- Globalization and chain-based governance replacing local land regulation
#### Effects
- Embedded deforestation, emissions, and biodiversity loss in exported beef
- Regulatory leakage as noncompliant beef redirected from stricter markets to China
- Social impacts including forced labor cases and vulnerable smallholder livelihoods

### Cross-Coupling Interactions
- EU and US sustainability pressures on meatpackers indirectly influence practices for China-directed supply chains
- Chinese demand growth amplifies Brazilian intracoupling pressures on forests and smallholders
- Financial ESG norms in global markets link telecoupled trade to corporate and investor behavior

### Research Gaps or Limitations
- Limited quantitative data on post-2017 embedded deforestation risks for China-bound beef
- Sparse analysis of concrete sustainability implementation by Chinese importers and banks
- Need for stronger integration of bilateral environmental pledges with enforceable trade measures

### Search Keywords
- telecoupling Brazilian beef exports China governance deforestation
- China Brazil beef trade regulatory leakage TAC G4 Forest Code
- meatpackers JBS Marfrig Minerva ESG deforestation risk

### Extraction Confidence
high
