# Unraveling the quantity and sustainability of cross-scale ecosystem service flows: A meta-coupling framework perspective

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:53:56.743744+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Liu and Pan - 2025 - Unraveling the quantity and sustainability of cross-scale ecosystem service flows A meta-coupling f.pdf
- Year: 2025
- DOI: 10.1007/s11629-025-9679-z
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper examines how ecosystem services move across space and scales, and how sustainable those flows are, using a metacoupling perspective. The study area is the Jing River Basin (JRB) on the Chinese Loess Plateau as the focal system, the neighboring Guanzhong Plain Urban Agglomeration (GPUA) as the proximate system, and the Middle Reaches of the Yellow River (MRYR) as the distal system. The focus is on three services aligned with the water-food-energy nexus but operationalized as water yield, food production, and carbon sequestration.

Using 2020 data, the authors apply InVEST models to estimate spatially explicit supply of water, food, and carbon, combine this with population- and consumption-based demand, and then use a breakpoint gravity model to derive interregional ecosystem service flows (ESFs). They embed these flows in the metacoupling framework (internal, adjacent, and distant couplings) and evaluate sustainability with a Techno-Ecological Synergy (TES) index, which compares supply and demand at multiple nested scales.

Within the JRB, water supply is highest in the south, while food and carbon supply are more evenly distributed. Certain counties act as strong exporters, particularly for food and carbon. At larger scales, the JRB exports substantial water to the GPUA and sends food and carbon primarily to neighboring and more distant parts of the MRYR. These outward flows reinforce regional food security and ecological resilience beyond the basin.

Sustainability indicators show that the JRB is self-sufficient for all three services. For food, internal sustainability is already high, and coupling with the GPUA further improves the index, illustrating positive cross-scale synergies. In contrast, water flows underline dependency of urban and downstream regions on upstream ecosystems.

The paper is explicitly about metacoupling/telecoupling: it operationalizes the metacoupling framework for ESFs, quantifies internal, proximate, and distant flows, and links them to multi-scale sustainability metrics. It demonstrates how cross-scale service exchanges and policy coordination can enhance overall system sustainability and provides a template for cross-basin governance on the Loess Plateau and similar regions.

## Structured Metacoupling Extraction

### Coupling Classification
- Strongly metacoupled study integrating intra, adjacent, and distant ecosystem service flows and sustainability.
- Core example of intra, peri, and telecoupled water, food, and carbon services on Loess Plateau.
- Applies metacoupling and techno ecological synergy for cross scale ES flow assessment.

### Intracoupling
#### Systems
- Jing River Basin focal system within Loess Plateau.
- Counties and districts inside Jing River Basin.
- Local human ecological system of semi arid basin.
#### Flows
- Internal flows of water production among basin counties.
- Intra basin food supply redistribution between surplus and deficit counties.
- Carbon sequestration and emission balance within basin.
#### Agents
- County governments managing land, water, and agriculture.
- Farmers, residents, and local industries using ecosystem services.
- Local environmental and water resource agencies.
#### Causes
- Spatial mismatch between ES supply and local demand.
- Historical soil erosion, ecological degradation, and restoration policies.
- Local population density, irrigation, and land use patterns.
#### Effects
- Improved basin level food and carbon self sufficiency.
- Uneven water availability and local water stress in northern basin.
- Enhanced internal ecological resilience when ES surpluses exist.

### Pericoupling
#### Systems
- Jing River Basin as upstream ecological provider.
- Guanzhong Plain Urban Agglomeration adjacent receiving system.
- Shared county scale units spanning focal and adjacent zones.
#### Flows
- Upstream water production flowing from basin into urban agglomeration.
- Food exports from basin surplus counties to nearby cities.
- Carbon sequestration support and ES spillovers to urban periphery.
#### Agents
- Urban governments of GPUA including Xi an core districts.
- Regional planners coordinating basin urban resource use.
- Agricultural supply chain actors linking basin and cities.
#### Causes
- High urban demand for water, food, and ecological regulation.
- Economic integration and transport connectivity between basin and GPUA.
- Policy driven ecological compensation and restoration goals.
#### Effects
- GPUA reliance on basin water and food for development.
- Increased food sustainability index for basin when coupled with GPUA.
- Potential upstream ecological pressure from downstream urbanization.

### Telecoupling
#### Systems
- Jing River Basin as focal upstream system.
- Middle Reaches of Yellow River as distal system.
- Broader Yellow River Basin ecological and economic network.
#### Flows
- Cross basin water production moving from focal to distal areas.
- Long distance food supply flows across middle Yellow River counties.
- Regional carbon sequestration contributions supporting distal sustainability.
#### Agents
- Provincial and river basin management authorities.
- Interregional markets for agricultural and energy products.
- National agencies implementing Loess Plateau and Yellow River policies.
#### Causes
- Interdependent watershed hydrology and soil water conservation needs.
- Trade in agricultural goods and energy resources across region.
- National strategies for ecological barrier and SDG achievement.
#### Effects
- Distal systems gain food security and ecological regulation from basin flows.
- Collaborative support strengthens basin sustainability indicators.
- Telecoupled flows create governance needs for cross basin coordination.

### Cross-Coupling Interactions
- Three tier structure links intra basin dynamics with adjacent urban and distal river systems.
- Same ES types (water, food, carbon) operate simultaneously across all coupling distances.
- Techno ecological synergy metrics explicitly compare sustainability across focal, proximate, distal scales.

### Research Gaps or Limitations
- Study area limited to Jing River Basin and nearby Yellow River segments, omitting wider networks.
- Only water, food, and carbon services analyzed; regulating and cultural services excluded.
- Single year 2020 data and limited socioeconomic, model validation detail constrain dynamics.

### Search Keywords
- metacoupling ecosystem service flows Jing River Basin Guanzhong Plain Middle Yellow River
- techno ecological synergy water food carbon Loess Plateau sustainability
- breakpoint model InVEST cross scale ES flows SDGs China

### Extraction Confidence
high
