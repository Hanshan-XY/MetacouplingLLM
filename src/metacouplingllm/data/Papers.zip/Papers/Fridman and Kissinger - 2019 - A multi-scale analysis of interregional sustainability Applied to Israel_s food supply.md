# A multi-scale analysis of interregional sustainability Applied to Israel_s food supply

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:44:28.284129+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Fridman and Kissinger - 2019 - A multi-scale analysis of interregional sustainability Applied to Israel_s food supply.pdf
- Year: unknown
- DOI: 10.1016/j.scitotenv.2019.04.054
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper develops and applies a method to assess the sustainability of interregional food systems across multiple spatial scales, using Israel as a case. The study focuses on how Israels crop consumption depends on and affects distant production regions, linking to telecoupling by explicitly tracing flows between sending and receiving systems and to metacoupling through analysis across nested spatial units.

Geographically, the work is global in scope but emphasizes major sending regions in Eurasia (notably Ukraine and European Russia) and South America (Argentina, Brazil, Paraguay), plus other biodiversity‑rich areas such as West Africa and Ethiopia. The authors operate within the context of international crop trade and land use, treating Israel as a highly import‑dependent food system.

Methodologically, the study combines FAO bilateral trade and production data (for more than 140 primary crops) with the SPAM global crop production grid at 5 arc‑minute resolution. Trade flows are traced back to producing grid cells, converted into cropland footprints and calorie flows, and then aggregated into several spatial layers: countries, biomes, ecoregions, river basins and sub‑basins, and first‑level administrative units. Additional datasets on biodiversity loss and conservation priorities are used for impact interpretation.

Key findings show that over 60 percent of Israels crop tonnage, and more than 85 percent of its cropland footprint and calorie supply, come from imports. Most imported cropland lies in temperate grasslands and temperate broadleaf forests, with significant dependence on tropical forests and grasslands that are conservation priorities. A few ecoregions and river basins account for disproportionate biodiversity risks and potential water quality pressures, especially in the Black Sea and South American river systems. Sub‑national analysis reveals yield gaps within key exporting countries, indicating scope for intensification but also trade‑offs with local ecosystems and communities.

The paper is explicitly about telecoupling/metacoupling. It demonstrates how multi‑scale spatial analysis can reveal hidden environmental hotspots, shared interests, and trade‑offs in globally connected food systems, and proposes a transferable framework for national food security and sustainability assessments.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via Israels food imports; multi-scale sending systems and remote environmental impacts analyzed.

### Intracoupling
#### Systems
- Israel domestic agriculture and food consumption system
- Local Israeli ecosystems and water resources
#### Flows
- Domestic crop production to Israeli consumers
- Local land and water use for food production
#### Agents
- Israeli farmers and agribusiness
- Israeli consumers and policymakers
#### Causes
- Population and income growth driving higher food demand
- Limited domestic land and water availability
#### Effects
- High reliance on imports for cereals and oil crops
- Domestic pressure on local ecosystems partly displaced abroad

### Pericoupling
#### Systems
- Israel and nearby Mediterranean or regional trading partners
- Shared river basins or ecoregions spanning neighboring countries
#### Flows
- Regional trade of selected crops and processed foods
- Cross-border impacts within shared ecoregions or watersheds
#### Agents
- Neighboring-country producers and exporters
- Regional governance bodies when present
#### Causes
- Geographic proximity and existing trade links
- Shared environmental systems like ecoregions and basins
#### Effects
- Regionally shared ecosystem service changes
- Potential regional policy coordination needs

### Telecoupling
#### Systems
- Israel as receiving system dependent on imported food
- Major sending systems in Eurasia South America United States
- Tropical and temperate biomes and ecoregions supplying crops
#### Flows
- International trade of primary crops and processed products to Israel
- Embodied cropland land water and nutrients in traded food
- Embodied biodiversity loss and water quality impacts in exporting regions
#### Agents
- Export-country farmers traders agribusinesses
- National governments shaping trade and agricultural policy
- International organizations concerned with food security and conservation
#### Causes
- Globalized food system and comparative yield advantages
- Israels limited resources and high import dependence
- Weak biophysical or economic feedback from distant impacts to consumers
#### Effects
- Remote land-use change and habitat conversion in sending systems
- Species loss especially in tropical and conservation-priority ecoregions
- River and coastal degradation in Black Sea and South American basins

### Cross-Coupling Interactions
- National trade dependence links to biome ecoregion and watershed impacts across scales.
- Agricultural intensification to supply imports trades off with downstream water quality and coastal habitats.
- Conservation policies in tropical sending regions can affect Israels food security and global sustainability.

### Research Gaps or Limitations
- Analysis constrained to 2005 due to SPAM temporal coverage though newer grids now exist.
- Exports from grid cells assumed proportional to national export structure due to missing destination data.
- Impacts largely characterized via literature review; need global consistent impact datasets beyond species loss.

### Search Keywords
- Israel food system telecoupling cropland footprint SPAM
- interregional sustainability multi-scale analysis biomes ecoregions watersheds
- virtual land trade species loss Black Sea basin cereal oil crops

### Extraction Confidence
high
