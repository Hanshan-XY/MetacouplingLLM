# Telecoupled land-use changes in distant countries

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:06:59.155456+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Sun et al. - 2017 - Telecoupled land-use changes in distant countries.pdf
- Year: unknown
- DOI: 10.1016/S2095-3119(16)61528-9
- OA status: hybrid
- License: cc-by-nc-nd
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This research examines how international soybean trade reshapes agricultural land use patterns in key producing and consuming regions, using a telecoupling framework to highlight distant socioeconomic-environmental linkages. The study focuses on three strongly connected countries: China as the main importer (receiving system), Brazil as a major exporter (sending system), and the United States as a competing exporter (spillover system). Within these, the authors analyze Heilongjiang Province, Mato Grosso State, and the U.S. Western Corn Belt, which are leading soybean production regions and closely tied through trade with China.

The system context is explicitly telecoupled: soybean and monetary flows link the three regions, while trade policies, prices, technology, and conservation measures act as drivers. Using satellite-based soybean maps from around 2005 and 2010 (primarily MODIS-derived products, harmonized to 250 m resolution), the authors perform pixel-level change detection to map soybean gain and loss. They then apply moving window analysis at multiple spatial scales to quantify the clustering and density of change, and overlay global terrestrial ecoregions to assess potential implications for biodiversity.

Results show strong spatial heterogeneity and clustering of soybean changes, which differ across regions and scales. Heilongjiang experiences widespread soybean loss exceeding gains, with some gain hotspots but overall contraction of soybean area. Mato Grosso exhibits roughly offsetting gains and losses, indicating stable total area but spatial relocation of soybean fields, including some expansion outside sensitive Cerrado ecoregions. In the Western Corn Belt, soybean gains and losses are adjacent and largely balanced, with modest net increases mainly in intermediate-density soybean landscapes.

The paper is directly about metacoupling/telecoupling. It demonstrates how distant trade relations drive spatially explicit land-use changes in sending, receiving, and spillover systems, and argues that identifying hotspots of gain and loss can inform coordinated policies on food security, biodiversity conservation, and pollution control across interacting countries.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling among Brazil, China, USA via soybean trade and land-use change

### Intracoupling
#### Systems
- Heilongjiang agricultural and ecological system within China
- Mato Grosso agroecosystem including Cerrado and Amazon fringe
- Western Corn Belt mixed corn-soybean production landscape
#### Flows
- Domestic soybean redistribution and crop rotations
- Local land conversion between soybean and other crops
- Internal nutrient and pesticide pollution within farmlands
#### Agents
- Local farmers and farming cooperatives
- Provincial or state agricultural agencies
- Domestic traders and processors
#### Causes
- Crop price fluctuations and farm profitability
- Weather anomalies affecting planting choices
- National agricultural and conservation policies
#### Effects
- Regional soybean gain and loss hotspots
- Encroachment into biodiversity rich ecoregions
- Changes in landscape continuity and field size patterns

### Pericoupling
#### Systems
- Neighboring Brazilian states around Mato Grosso
- Chinese provinces adjacent to Heilongjiang
- US states surrounding the Western Corn Belt
#### Flows
- Cross-border grain trade and logistics within each country
- Spread of farming practices and technologies regionally
- Regional movement of agricultural labor
#### Agents
- Regional grain elevators and transport companies
- Interprovincial or interstate governments
- Regional environmental organizations
#### Causes
- Spillover of land-use policies to nearby regions
- Expansion of transport infrastructure and ports
- Competition for cropland among neighboring areas
#### Effects
- Shift of soybean expansion into neighboring non-protected areas
- Regional clustering of cropland change near borders
- Shared environmental pressures across adjoining ecoregions

### Telecoupling
#### Systems
- China as soybean importing receiving system
- Brazil as soybean exporting sending system
- United States as spillover soybean exporter
#### Flows
- Transcontinental soybean shipments from Brazil and USA to China
- Financial flows from Chinese buyers to exporters
- Virtual land and biodiversity impacts embodied in trade
#### Agents
- International grain corporations and traders
- National governments and trade negotiators
- World Trade Organization and global certification schemes
#### Causes
- Chinese tariff reductions and WTO accession
- Genetically modified soy adoption increasing export competitiveness
- Rising Chinese demand for feed and edible oil
#### Effects
- Soybean land decline in Chinese receiving region
- Deforestation pressure and Cerrado conversion in Brazil
- Stabilization or growth of US soybean area amid competition

### Cross-Coupling Interactions
- Brazilian export growth reduces US soybean share in Chinese imports
- China import demand redirects Brazilian expansion away from protected Amazon areas
- Trade driven land-use shifts alter biodiversity risk distribution across three countries

### Research Gaps or Limitations
- Focus on spatial patterns; limited quantitative analysis of socioeconomic drivers and agents
- Relies on remote sensing products with resolution and temporal constraints
- Future work needed on complete telecoupling components and policy translation

### Search Keywords
- telecoupling soybean trade China Brazil USA
- spatial soybean land-use change Heilongjiang Mato Grosso Western Corn Belt
- biodiversity ecoregions cropland expansion Cerrado Mongolian steppe

### Extraction Confidence
high
