# Connected by oil A framework to analyze the connected sustainability histories of the Niger and Rhi

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:09:21.889220+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Veraart et al. - 2020 - Connected by oil A framework to analyze the connected sustainability histories of the Niger and Rhi.pdf
- Year: unknown
- DOI: 10.1016/j.exis.2019.12.004
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
The paper develops and tests a historical framework for analyzing how sustainability gains and costs are linked and redistributed across distant regions through oil infrastructure. It focuses on the oil-based connection between the Niger Delta in Nigeria and the Rhine Delta in the Netherlands from about 1950 to 2015.

Geographically, the study centers on Nigeria and the Netherlands, with particular attention to the Niger Delta oil fields and the Rotterdam-Rhine industrial-port complex. The authors use the Conference of European Statisticians small indicator set for measuring sustainable development, complemented by qualitative historical and political-economic literature. They adapt the CES dashboards for well-being here-and-now and later, and conceptually foreground the elsewhere dimension to capture telecoupled resource flows.

Empirically, they reconstruct how Royal Dutch Shell and other firms built a transcontinental oil chain, how oil reshaped national economies, and how this fed into broader sociotechnical transitions in energy, transport, industry, and consumption. Quantitative indicators track trends in income, inequality, health, education, environmental quality, energy use, and natural capital in both countries. For Nigeria, they also discuss subnational disparities and conflicts in the Niger Delta.

The main findings are: oil clearly connects the long-term sustainability trajectories of both deltas; both countries saw large improvements in material well-being, life expectancy, and education, while environmental indicators worsened, especially in oil-producing regions. Environmental harm in the Dutch Rhine Delta was partly mitigated by regulation; in the Niger Delta it remains severe and fuels social conflict. The analysis shows that transcontinental sustainability trade-offs are not a simple zero-sum pattern where the global North gains and the global South loses: both ends of the chain experienced economic benefits and environmental burdens, though Nigeria faces sharper inequality, governance problems, and ecological degradation.

The study is explicitly about telecoupling and metacoupling. It proposes a global sustainability history approach that combines telecoupled resource-chain analysis with standardized indicator dashboards, while warning against data gaps, methodological nationalism, and Eurocentric assumptions embedded in existing monitoring tools.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via transcontinental oil chain linking Niger and Rhine deltas since 1950s

### Intracoupling
#### Systems
- Dutch national economy and Rotterdam petrochemical harbor complex
- Nigerian national economy and Niger Delta oil region
- Local social ecological systems in Delta oil communities
#### Flows
- Domestic redistribution of oil revenues and public investments
- Internal migration to Rotterdam and Port Harcourt urban areas
- Energy, pollution and land use changes within each country
#### Agents
- Dutch governments, Rotterdam port authority, Dutch industries
- Nigerian federal and state elites, NNPC, local authorities
- Local communities, environmental NGOs, protest movements
#### Causes
- Postwar industrialization and energy transition strategies
- State reliance on oil rents and neglect of agriculture
- Environmental regulation emergence and local pollution conflicts
#### Effects
- Rising material well being and education with local pollution hotspots
- Deepening inequality, conflict and degradation in Niger Delta
- Shifts in biodiversity, air and water quality within both nations

### Pericoupling
#### Systems
- Gulf of Guinea regional oil economies
- Rhine transnational industrial corridor
- Neighboring African and European states linked to oil trade
#### Flows
- Cross border oil, labor and pollution within Gulf of Guinea
- Petrochemical products and fuels along Rhine corridor
- Shared governance of transboundary oil fields and marine impacts
#### Agents
- Multinational oil companies operating in several Gulf states
- Regional bodies like Gulf of Guinea Commission
- Cross border workers, traders and smugglers
#### Causes
- Expansion of offshore and onshore oil infrastructure regionally
- Harbor competition and clustering of petrochemical industry
- Weak regional governance and porous borders
#### Effects
- Diffusion of environmental risk and social unrest across neighbors
- Regional economic integration around oil logistics
- Spatial redistribution of employment and pollution

### Telecoupling
#### Systems
- Niger Delta extraction landscapes in Nigeria
- Rhine Delta refining and consumption landscapes in Netherlands
- Broader global oil network including US and Europe
#### Flows
- Crude oil shipped Port Harcourt to Rotterdam and other ports
- Capital, technology, management and expertise within Shell network
- Embedded environmental impacts via traded oil and gas flaring
#### Agents
- Royal Dutch Shell and partner oil firms
- OECD, UNECE and national statistical offices designing indicators
- NGOs, courts and transnational advocacy networks
#### Causes
- Postcolonial resource strategies and global energy demand growth
- Search for low sulfur crude under stricter air regulations
- Corporate strategies of vertically integrated oil majors
#### Effects
- Coupled economic gains and environmental losses in both regions
- Non zero sum sustainability trade offs along supply chain
- Legal debates on foreign direct responsibility of multinationals

### Cross-Coupling Interactions
- Oil driven transitions in energy, transport and industry link local, regional and global systems
- Environmental regulations in North shift extraction and pollution burdens Southward
- National level averages hide subnational hotspots within globally linked chains

### Research Gaps or Limitations
- Data scarcity and reliability issues, especially historical and Nigerian statistics
- National indicator focus underrepresents intra national inequalities and conflict zones
- Risk of Eurocentric, present day concepts shaping interpretation of Southern histories

### Search Keywords
- Niger Delta Rhine Delta oil telecoupling sustainability history
- Royal Dutch Shell foreign direct responsibility Nigeria Netherlands
- CES sustainability monitor here now later elsewhere indicators

### Extraction Confidence
high
