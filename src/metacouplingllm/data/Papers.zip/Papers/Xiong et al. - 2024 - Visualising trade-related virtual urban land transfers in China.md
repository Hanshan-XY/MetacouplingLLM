# Visualising trade-related virtual urban land transfers in China

Jieyang Xiong, Liwei Wang, Tao Song & Haimeng Liu

To cite this article: Jieyang Xiong, Liwei Wang, Tao Song & Haimeng Liu (2024) Visualising traderelated virtual urban land transfers in China, Regional Studies, Regional Science, 11:1, 696-700, DOI: 10.1080/21681376.2024.2407410

To link to this article: https://doi.org/10.1080/21681376.2024.2407410

![](images/415762edd32ade2627ea32dd224e0d62264acd117cde55cc2aae29d0a9447c7e.jpg)

![](images/78dffaf2687ed0f62be5a2c64f0cae526f1bd6cad33f80219d8605dc5155ea9c.jpg)

![](images/854d6d26b8658883a46e69562838e3a8332adb0a60f88f0f806a98e47dbdbd3b.jpg)

![](images/3d330bed70a02f934d5d67df179a061fdd25fcf6f49d48640ef34deaed052a92.jpg)

![](images/a30254e756487f5260e649f5dffa66f78521bee201a7cd92468c5453367b2f49.jpg)

![](images/80d1f774517e1bba527d32e1b961955eebbf9104de83c0a2b59cea503475a5ec.jpg)

$\circled{5}$ 2024 The Author(s). Published by Informa UK Limited, trading as Taylor & Francis Group

Published online: 11 Oct 2024.

Submit your article to this journal

Article views: 721

View related articles

View Crossmark data

# Visualising trade-related virtual urban land transfers in China

Jieyang Xiong a,b, Liwei Wang $\textcircled{1}$ c , Tao Song a, b and Haimeng Liu a,b

# ABSTRACT

As a type of environmental footprint, the concept of virtual land captures the indirect land use embedded in our consumption and trade activities. Utilising the environmentally-extended multi-regional input– output model (EEMRIO) and Kaleidoscope diagram, we visualise for the first time the interprovincial flow of virtual urban land in China. It unveils the intricate urban network connections and the telecoupled interactions between human activities and land use amidst China’s rapid urbanisation phase. The results indicate that the eastern region of China emerges as the primary net beneficiary of virtual urban land, whereas the western region stands as the principal net contributor. The local urban land in $6 5 \%$ of the provinces suffices for their own consumption demands. However, provinces like Zhejiang, Henan, and Jiangsu rely heavily on inter-provincial urban land to fulfil their consumption requirements. Inter-regional trade plays a pivotal role in facilitating the flow of land resources, significantly easing the strain between human demands and land availability in the developed coastal provinces of eastern China. Yet, it imposes additional ecological pressure on the more ecologically vulnerable areas in the west. The insights from this research are poised to offer valuable guidance for the Chinese government in harmonising urban development strategies, industrial distribution and the allocation of construction land on a national scale.

# ARTICLE HISTORY

Received 31 May 2024; Accepted 17 September 2024

# KEYWORDS

Virtual urban land; urbanisation; multi-regional input-output model; Kaleidoscope visualisation; China

JEL

Q37; Q56; R15

Over the last three decades, China has witnessed the world’s most rapid urbanisation. From 1990 to 2022, its urban population burgeoned from 325.3 million to 920.7 million, positioning China as the country with the largest urban populace. Meanwhile, urban construction land expanded from $1 1 , 6 0 8 \mathrm { k m } ^ { 2 }$ to $5 9 , 4 5 2 \mathrm { k m } ^ { 2 }$ , with an average annual growth rate of $5 . 2 \%$ . However, only $1 2 \%$ of China’s total land area comprises suitable plains for urban construction and agriculture, leading

CONTACT Haimeng Liu liuhm@igsnrr.ac.cn

a Institute of Geographic Sciences and Natural Resources Research, Chinese Academy of Sciences (CAS), Beijing, People’s Republic of China   
b College of Resources and Environment, University of Chinese Academy of Sciences, Beijing, People’s Republic of China   
c Academy of Macroeconomic Research, National Development and Reform Commission, Beijing, People’s Republic of China

to urban population densities that significantly surpass the global average (Jiao et al., 2023). This imbalance intensifies the challenge of meeting urban land demand (Liu et al., 2024). The rapid expansion of urban land in China has led to a reduction in arable land, forests and grasslands around cities, posing threats to China’s food security and diminishing the quality of ecosystems and biodiversity in these regions (Liu & Zhou, 2021). In response, the Chinese government has begun to implement the ‘three red lines’ policy (Jiang et al., 2016), imposing strict limitations on urban land expansion to safeguard essential ecological territories and arable lands from further reduction.

In this context, scholars have extensively studied the expansion of urban land and the conversion of land use types (Ding & Li, 2019; Liu et al., 2012; Seto et al., 2012). However, from the perspective of consumption, a considerable amount of goods consumed by city dwellers – including materials like steel and plastics essential for urban infrastructure, as well as the productive services critical for city functioning – are procured from other regions. This procurement process inherently involves utilising land in those other cities for production and service provision. This concept of land embedded in products is referred as ‘virtual land’. Distinguished from actual land, virtual land emphasises the relationship between the production and trade of goods and the use of land resources, transcending the immovable attributes of actual land and enabling the remote management and utilisation of land resources. Therefore, through the lens of interregional trade, we visualise the interprovincial transfer of virtual urban land induced by multi-regional input–output and analyse local consumption and remote occupation of urban land use, aiming to provide a new observational perspective for enhancing the efficiency of urban land use and promoting urban sustainable development within the context of an increasingly networked global urbanisation and telecoupling between humans and nature (Espey et al., 2024; Liu et al., 2013).

We employed the environmentally-extended multi-regional input–output (EEMRIO) model to estimate virtual urban land use (Qiang et al., 2013). It associates intermediate input–output tables with environmental/resource satellite tables, then inputs resource utilisation data for each region and, after a series of calculations, outputs virtual resource consumption data for each region. Initially, adhering to China’s land classification standard (GB50137-2011), we gathered various urban land use data from 31 provinces (no data from Taiwan). This included mining, industrial, public facilities, transportation and logistics, commercial services, and public administration and services land. The data were sourced from the ‘China Urban Construction Statistical Yearbook’ and China’s Third Land Survey (https://gtdc.mnr.gov.cn/Share#/thirdSurvey). While China’s urban land classification standards are sometimes subject to slight change, in most cases it is feasible to link the industrial sector to the urban land classification. In the second step, utilising the urban land use data alongside the 2017 China Multi-Regional Input–Output Table for Industry Value Added released by the Carbon Emission Accounts and Datasets (CEADs) (Zheng et al., 2021), we computed the direct land use coefficients, i.e., the amount of urban land directly inputted per unit of output by each sector. In the third step, through the application of the EEM-RIO, incorporating the Multi-Regional Input–Output Table and these direct land use coefficients, we estimated the virtual urban land and its transfer situation across various provinces and the four major regions in China. This included the calculation of local virtual urban land resulting from local consumption, as well as the inflow and outflow of virtual urban land. The unit of measurement for virtual land is also square kilometres. Finally, we utilised the Kaleidoscope diagram for visualisation, which, compared to the chord diagram, provides a clearer depiction of inflows and outflows (Gu & Xu, 2022). Given that our study primarily addresses the effects of inter-provincial trade within China, we excluded virtual urban land attributed to international imports and exports from our analysis.

In Figure 1a, we compare the actual urban land quantities of each province with the virtual urban land for local consumption, alongside the virtual urban land outflow (brown colour). The

![](images/cf20715f7b7619b37e32d96a18c9523b87dcd072a3cd066ad760269bb50e9460.jpg)

![](images/b8f81a854e2b4ebb997c8c5eeaf660fd4fa93e7917dc812dec3865033d55a2ed.jpg)  
Figure 1. Trade-related virtual urban land transfers in provincial China. (a) Comparison between actual urban land and virtual urban land. (b) Transfers of virtual urban land across 31 provinces and four major regions.

virtual urban land for local consumption is made up of local (yellow colour) and inflowing virtual land (green colour), both driven by local consumption, and we present the two parts in a stacked format. The results show that in $6 5 \%$ of the provinces, the virtual urban land required for local consumption is less than the actual urban land available locally, indicating that the local land supply meets local demands. However, in 10 provinces, such as Beijing, Zhejiang, Jiangsu, Henan and Hubei, the virtual urban land occupied by local consumption exceeds the actual urban land supplied locally, especially in Henan and Zhejiang, where virtual urban land exceeds $6 0 \%$ and $4 8 \%$ of the actual urban built-up area, respectively, occupying a significant amount of land from other distant provinces. Additionally, from the supply side perspective, western provinces such as Inner Mongolia, Xinjiang, Shanxi and Qinghai are major areas of virtual urban land outflow, with their contributions amounting to $6 8 \%$ , $6 0 \%$ , $5 8 \%$ and $6 0 \%$ of their actual urban land, respectively.

Figure 1b clearly illustrates the virtual urban land transfer in (deep colour) and out (light colour) in each province. On a macro scale, virtual urban land flows from the northwest towards the southeast regions of China. China’s involvement in inter-provincial flow of virtual urban land covers an area of $2 3 , 4 3 7 \mathrm { k m } ^ { 2 }$ , accounting for $4 0 \%$ of China’s actual urban land area. Eighteen provinces in China are net recipients of urban land, while twelve provinces, including Inner

Mongolia, Shandong, Xinjiang and Qinghai, serve as net contributors. The eastern and central regions are net recipients of urban land, receiving net inflows of $2 8 5 5 \mathrm { k m } ^ { 2 }$ and $1 4 7 7 \mathrm { k m } ^ { 2 }$ , respectively. Conversely, the western and northeastern regions act as net donors, with virtual urban land net outflows amounting to $3 0 8 4 \mathrm { k m } ^ { 2 }$ and $1 2 4 5 \mathrm { k m } ^ { 2 }$ , respectively. Except for Tianjin, Hebei and Shandong, all provinces in the eastern region are net recipients of virtual urban land. Regional trade promotes the market-oriented flow of land resources, effectively alleviating the tense human-land relationship in developed coastal provinces of the east. However, it also increases additional ecological pressure on environmentally sensitive areas in the western region.

Utilising a Kaleidoscope diagram to visualise the flow of virtual urban land in trade interactions provides a more intuitive understanding of how urbanisation remotely occupies land resources – a key aspect often neglected in previous research. These insights are crucial for decision-making in China, assisting in resolving significant human-land conflicts by harmonising urbanisation development, industrial distribution and the construction land allocation on a national scale.

