Article

# Decrypting Spatiotemporal Dynamics and Optimization Pathway of Ecological Resilience Under a Panarchy-Inspired Framework: Insights from the Wuhan Metropolitan Area

An Tong , Yan Zhou * , Jiazi Zheng and Ziqi Liu

Department of Urban Planning, School of Urban Design, Wuhan University, Wuhan 430072, China; an.tong@whu.edu.cn (A.T.); 2020302091011@whu.edu.cn (J.Z.); wincentliu000@gmail.com (Z.L.)

* Correspondence: joyeezhou@whu.edu.cn

# Highlights

What are the main findings?

A nested local–global assessment (2000–2020) revealed a slight decline in ecological resilience, with notable east–west disparities.   
Integrating XGBoost-SHAP with DBN uncovered the evolving causal network of ecological resilience and pinpointed forest and construction land as key drivers.

What is the implication of the main finding?

Provides a panarchy-inspired framework using remote sensing, offering a new tool for assessing and managing ecological resilience across scales.   
The framework provides transferable guidance for sustainable land management in rapidly urbanizing regions.

![](images/94cb4ca07911203d74987265c8724fa1502af0d85bdab115f6cf4f4447fdfc1b.jpg)

Academic Editors: Dehua Mao and Maria Laura Carranza

Received: 14 September 2025

Revised: 23 November 2025

Accepted: 4 December 2025

Published: 5 December 2025

Citation: Tong, A.; Zhou, Y.; Zheng, J.; Liu, Z. Decrypting Spatiotemporal Dynamics and Optimization Pathway of Ecological Resilience Under a Panarchy-Inspired Framework: Insights from the Wuhan Metropolitan Area. Remote Sens. 2025, 17, 3941. https://doi.org/10.3390/ rs17243941

Copyright: $^ ©$ 2025 by the authors. Licensee MDPI, Basel, Switzerland. This article is an open access article distributed under the terms and conditions of the Creative Commons Attribution (CC BY) license (https://creativecommons.org/ licenses/by/4.0/).

# Abstract

Environmental degradation from rapid urbanization significantly threatens ecological resilience (ER). Nevertheless, accurately evaluating ER remains a persistent challenge. Prior studies’ limited attention to resilience’s cross-scale complexity has hindered evidence-based management. This study, based on long-term time series remote sensing and multi-source data, developed a cross-scale spatiotemporal ER analysis framework integrating landscape ecology and panarchy perspectives. A local “resistance–adaptation–recovery” substrate resilience evaluation was combined with telecoupling-based global network resilience to quantify multi-scale ER from 2000 to 2020. Key drivers across time scales were identified using a hybrid XGBoost–SHAP and genetic algorithm (GA)–optimized dynamic Bayesian network (DBN), and spatial optimization scenarios were simulated with patch-generating land use simulation (PLUS) model. ER decreased slightly from 0.4856 in 2000 to 0.4503 in 2020, with dynamic fluctuations across periods. A clear spatial pattern emerged, with higher ER in the east and lower in the west. Forest land contributed strongly to ER, while construction and cropland reduced it. Spatial composition factors—especially the proportions of forest and construction land—were dominant drivers, outweighing structural factors such as landscape pattern. DBN backward inference revealed nonlinear threshold effects among socio–natural–spatial drivers. Scenario-based simulations confirmed that regulating spatial composition via our optimization pathway can enhance ER. This is particularly effective when expanding forestland in mountainous regions while restraining the growth of built-up areas. This study proposes an integrated framework of “resilience assessment—driver analysis—spatial optimization,” which not only advances the theoretical basis for nested ER assessment but also offers a transferable approach for optimizing

spatial patterns and sustainable land management, thereby enhancing ecological resilience in rapidly urbanizing regions.

Keywords: ecological resilience; spatiotemporal evolution; driving mechanism; pattern optimization; dynamic Bayesian network; panarchy

# 1. Introduction

The global acceleration of urbanization has increased the frequency of urban disasters, resulting in issues such as habitat loss and landscape fragmentation [1–3], which severely impair ecosystem functions and constrain sustainable urban development and conservation outcomes. Under increasing external pressures, regional ecosystems are exposed to growing risks, and ecological resilience (ER) has thus garnered wide academic attention for its relevance to conservation and restoration practice [4–7].

ER is defined by its core functions of resistance, adaptability, and recovery [8,9], which enable systems to absorb disturbances and persist [10,11]. ER is often applied to issues such as sustainable development [12], ecological vulnerability [13], biodiversity conservation [14]. In disaster risk management, ER enhances a system’s resistance and adaptive capacity, for example, against large-scale floods [15–17]. In vulnerable ecosystems such as oceans [18], forests [19,20], and wetlands [21], it helps buffer against regime shifts by boosting adaptive capacity. ER can also support human well-being, such as food security [22]. This contextual application emphasizes that ER is not a single concept, but a set of manageable system characteristics [23].

However, accurately assessing ER remains a fundamental challenge [24,25]. Many studies focus on targets under a single disaster [26]. While such targeted approaches help identify specific resilience deficiencies, they may neglect the holistic and uncertain nature of resilience [27,28]. To better capture multidimensional complexity, integrated evaluation frameworks have been developed, including the Pressure–State–Response model [29] and generalized 3R framework [9,30]. Data sources such as remote sensing and statistical panel data are widely used in ER measurement. But many assessments rely on simplified spatial units (e.g., grids, patches), leading to low-dimensional models that may neglect finegrained spatial heterogeneity [31,32]. For instance, Zhou et al. employed urban panel data to examine ER in over 200 cities [33]. Lee et al. used statistical data to analyze coarse-grained spatiotemporal patterns of ER [12]. Although these studies address multiple resilience dimensions, they may overlook heterogeneous spatial patterns [27] and often fail to account for complex spatial interactions and cross-scale effects—such as those conceptualized in panarchy—limiting their ability to characterize resilience in interconnected landscapes [34].

Research on the drivers of ER has traditionally emphasized socio-economic and natural factors. For example, Wang et al. revealed the influence of urbanization on ER [9], and Lu et al. explored effects of population size and technological level on resilience [31]. A limited number of studies have begun to incorporate spatial drivers; Beita et al., for instance, highlighted the importance of structural and functional factors in shaping ER within spatial networks [35]. Nonetheless, the field still predominantly focuses on local systems, with limited attention to nonlinear drivers such as spatial configuration, hindering the understanding of ER’s global characteristics [36]. Moreover, traditional studies primarily employ statistical techniques like regression and gravity models [9,37] which struggle to capture complex nonlinear feedback [38]. More recently, machine learning methods such as Bayesian networks (BNs) have gained traction for analyzing multi-variable interactions, given their ability to handle nonlinearity [39]. BNs are widely applied in habitat

suitability, risk assessment, and ecosystem services (ES) studies [39–41]. However, few studies integrate cross-scale temporal dynamics; for example, the role of historical legacies in shaping future resilience is often overlooked [42], leaving long-term dynamic processes poorly represented.

In summary, current ER studies often fail to adequately capture the cross-scale spatiotemporal dynamics. How to enhance ER across space–time scales remains a “black box” problem [43], with few frameworks addressing its full-cycle characteristics [44], including potential temporal lag effects [45,46]. Many studies rely on simplified spatial assumptions or low-resolution data [24,31], offering limited guidance for fine-grained land management. Translating evolutionary mechanisms into long-term spatial optimization reveals a clear gap between theoretical understanding and practical implementation [37]. There is a pressing need to shift from single-scale, localized assessments toward multi-scale assessments that incorporate cross-scale ecological interactions [47], leverage long-term datasets, and apply network analysis to better understand resilience dynamics [48,49].

The Outline of the Development Plan for the Yangtze River Economic Belt requires the construction of a green development axis along the river, and the ecological security of Wuhan Metropolitan Area (WMA) is closely linked to the basin’s sustainable development [50]. Compared to individual cities, a cross-regional collaborative perspective of agglomerations is better suited to addressing transboundary ecological risks [51]. The Three-Year Action Plan for the Wuhan Metropolitan Area identifies ecological network construction as a key task. Wuhan’s 15th Five-Year Plan also emphasizes the need to improve the ecological network system, strengthen comprehensive environmental management, and enhance urban safety. However, existing ER studies remain limited in transboundary contexts, as enhancing one city’s resilience may inadvertently transfer risks to others through systemic linkages [51]. Exploring network resilience mechanisms can enhance the efficiency of ecological conservation across the agglomeration [52]. Enhancing the ER of WMA is essential for mitigating extreme climate risks—with the potential to serve as a reference model for similar urban clusters worldwide.

Therefore, this study develops a novel cross-scale ER analysis framework from the perspectives of panarchy and telecoupling theories. It evaluates ER across spatial scales (through nested local–global analysis) and temporal scales (via dynamic Bayesian network (DBN)) from 2000 to 2020 in WMA, integrating multi-dimensional assessments into a unified optimization pathway. The main research objectives are: (1) To implement a panarchy-inspired resilience assessment unifying local substrate resilience and global network resilience for characterizing ER spatiotemporal stability. (2) To integrate XGBoost-SHAP with DBN modeling to objectively identify dominant ER drivers and their causal pathways over time. (3) To introduce a DBN-PLUS reverse inference optimization framework enabling scenario-based ecological space optimization. The scientific significance of this work lies in its pioneering effort to evaluate cross-scale resilience through a panarchy lens, thereby enriching the theoretical framework for resilience measurement and contributing to a more holistic understanding of its dynamics. Practically, this research proposes innovative pathways for optimizing spatial patterns, which supports ER enhancement through land-use planning under resource constraints. The proposed optimization framework provides quantitative recommendations guided by mechanisms for resilience management in rapidly urbanising regions.

# 2. Conceptual Foundations of the Theoretical Framework

# 2.1. Connotation of the Substrate Resilience

Since ecological resilience is inherently natural, it is essential to consider foundational ecological elements [53]. In assessing this ecological basis—termed the “local substrate

resilience”—mainstream theory draws on evolutionary resilience, defining it as the coexistence and interplay of three ecosystem capacities in response to disturbances: resistance, adaptation, and recovery [54]. This conceptualization reveals three disturbance phases characterizing resilience: shock, damage, and learning [55]. These three components together constitute the full-cycle response of resilience: (1) resistance reflects preparatory and defensive capacities before a disturbance; (2) recovery embodies the ability to absorb and rebound during it; and (3) adaptability represents reorganization and transformation afterward. Operationalizing these three capacities—emphasizing their coexistence, interaction, and shifting dominance across phases—aligns with nonequilibrium theory. The essence of evolutionary resilience lies in the proportional evolution and dynamic balance of these capacities throughout disturbance cycles [54].

# 2.2. Theoretical Framework: Panarchy-Inspired Ecological Resilience Assessment

However, many previous ER assessments are limited to a narrow range of spatial and temporal scales, which to some extent results in a simplified and incomplete understanding of ecosystems [56,57]. Disturbances often exhibit hidden, cross-scale spatiotemporal effects that may not be fully captured by local indicators, which frequently rely on remote sensing imagery or coarse-grained datasets [53]. For example, resilience at one scale or time period may come at the expense of another [58,59]. (1) Temporally, conventional methods often overlook the dynamic nature of resilience. Analytical approaches capable of capturing temporal interactions remain underutilized in resilience analysis [60]. (2) Spatially, alongside local couplings, telecouplings also exert significant influence. Both telecoupling and panarchy models emphasize that resilience assessments must consider not only local unit stability but also cross-scale interactions [61]. Feedback occurs between ‘top-down’ and ‘bottom-up’ processes: local changes (e.g., in habitat patches) can cascade to influence broader landscapes [34,57]. Conversely, neglecting spatial effects and cross-scale interactions can lead to severe consequences—for instance, poorly informed restoration projects may result in zero-sum outcomes [57]. Therefore, beyond evaluating local substrate resilience, it is necessary to design a more responsive and dynamic resilience index to address hidden spatial effects, such as teleconnections, that the substrate-based perspective may overlook.

Integrating insights from telecoupling and panarchy into a new resilience evaluation framework requires combining local and global attributes. Complex network theory offers a powerful tool for this purpose, as it captures both nodal properties and global network dynamics, providing an effective method for analyzing telecoupling in line with panarchy principles [62]. For instance, constructing urban environmental networks and conducting topological analyses show that resilience properties—such as vulnerability—are determined more by a node’s network position (e.g., connectivity, centrality) than by its intrinsic local traits [25,63,64]. Adopting dual indicators to capture both within-scale and cross-scale resilience can help address these limitations and promote a balance between local restoration and global coordination [61].

# 3. Study Area and Data Source

# 3.1. Study Area

The WMA, located in eastern Hubei Province (Figure 1), encompasses nine prefecturelevel cities (Wuhan, Huangshi, Ezhou, Xiaogan, Huanggang, Xianning, Xiantao, Tianmen, and Qianjiang) and covers an area of $5 8 , 0 0 0 ~ \mathrm { k m } ^ { 2 }$ . As the most vital region in Hubei, the WMA serves as one of the most dynamic and robust growth poles under China’s Central Rise Strategy. From 2000 to 2020, the area of construction land increased by $1 3 4 2 . 5 7 ~ \mathrm { k m } ^ { 2 }$ , while cropland declined by $1 4 7 1 . 4 0 ~ \mathrm { k m } ^ { 2 }$ and water bodies expanded by

$4 1 0 . 4 9 \mathrm { k m } ^ { 2 }$ . Although the region retains a sound ecological base, the degree of ecological land fragmentation has intensified in central and western areas, weakening ecosystem stability and posing significant threats to regional ecological security [65].

![](images/b2d1ec8d53b6878839e37d63b6463139e6151956edf07f7d2d63bf1e85358ea9.jpg)

![](images/02959710ad7c5e92e207d6192fb4dae926753635704ecf7c99a029a8564aaa5b.jpg)

![](images/73e3aad179f60e1ebf72b18af9b59890b2be2d799e5140c3b07d3afc9a44a373.jpg)  
Figure 1. Study area. (a) The location of the research area in Hubei Province; (b) Land use in the Wuhan Metropolitan Area in 2020; (c) Other long-term land use in the Wuhan Metropolitan Area.

# 3.2. Data Source

This study collected physical geographic and socio-economic data for 2000, 2005, 2010, 2015, and 2020 from multiple sources to support the ER assessment (Table 1; Figures S1 and S2). Raster data were resampled to a spatial resolution of $1 \times 1$ km using ArcGIS 10.8. Continuous variables, including vegetation index, evapotranspiration, temperature, precipitation, and elevation, were discretized using the natural breaks method and reclassified based on their distributional characteristics.

Table 1. Data sources.   

<table><tr><td>Data</td><td>Data Format</td><td>Spatial Resolution</td><td>Data Sources/Processing</td></tr><tr><td>Normalized difference vegetation index (NDVI)</td><td>Raster</td><td>1 km</td><td>EARTHDATA
(https://www.earthdata.nasa.gov/ (accessed on 28 June 2024))</td></tr><tr><td>Precipitation</td><td>Raster</td><td>1 km</td><td>National Tibetan Plateau Data Center
(https://data.tpdc.ac.cn/zh-hans/data/faae7605-a0 f2-4d18-b28f-5cee413766a2 (accessed on 28 June 2024))</td></tr><tr><td>Temperature</td><td>Raster</td><td>1 km</td><td>China Meteorological Data Service Centre,
National Meteorological Information Centre
(https://data.cma.cn/ (accessed on 28 June 2024))</td></tr><tr><td>Evapotranspiration</td><td>Raster</td><td>1 km</td><td>National Tibetan Plateau Data Center
(https://data.tpdc.ac.cn/zh-hans/data/faae7605-a0 f2-4d18-b28f-5cee413766a2 (accessed on 20 November 2024))</td></tr><tr><td>Soil data</td><td>Raster</td><td>1 km</td><td>Harmonized World Soil Database (HWSD) version 2, International Institute for Applied Systems Analysis (IIASA) (https://gaez.fao.org/pages/hwsdhtps: //iasa.ac.at/ (accessed on 22 July 2024))</td></tr></table>

Table 1. Cont.   

<table><tr><td>Data</td><td>Data Format</td><td>Spatial Resolution</td><td>Data Sources/Processing</td></tr><tr><td>Net Primary Production (NPP)</td><td>Raster</td><td>500 m</td><td>NASA MODIS_MOD17A3
(https://search.earthdata.nasa.gov/search (accessed on 1 July 2024))</td></tr><tr><td>Land use data</td><td>Raster</td><td>30 m</td><td>Resource and Environmental Science Data Platform, Chinese Academy of Sciences
(https://www.resdc.cn/ (accessed on 21 July 2024))</td></tr><tr><td>Digital elevation model (DEM)</td><td>Raster</td><td>30 m</td><td>Geospatial Data Cloud
(http://www.gscloud.cn (accessed on 20 November 2024))</td></tr><tr><td>Slope</td><td>Raster</td><td>30 m</td><td>Calculated in ArcGIS</td></tr><tr><td>Road</td><td>Vector</td><td>-</td><td>Open Street Map
(http://www.openstreetmap.org (accessed on 21 July 2024))</td></tr><tr><td>Population density</td><td>Raster</td><td>1 km</td><td>EARTHDATA
(https://www.earthdata.nasa.gov/ (accessed on 22 July 2024))</td></tr><tr><td>Gross national product (GDP)</td><td>Raster</td><td>1 km</td><td>Resource and Environmental Science Data Platform, Chinese Academy of Sciences
(http://www.resdc.cn/ DOI),2017.DOI:10.12078/2017121102 (accessed on 20 November 2024))</td></tr><tr><td>Nighttime lighting</td><td>Raster</td><td>500 m</td><td>NPP-VIIRS-like nighttime light data
(https://doi.org/10.7910/DVN/YGIVCD (accessed on 20 November 2024))</td></tr></table>

# 4. Methods

The technical framework of this study is illustrated in Figure 2: (1) Comprehensive assessment of nested ecological resilience: The local-scale ER (termed here as “local perspective”) considers site-specific attributes, which is then modified through network-based global resilience (termed here as “global perspective”) to account for spatial teleconnections. The integrated result offers a holistic understanding of panarchy-inspired ER patterns. (2) Driving mechanism analysis: Building on the ER assessment results, we employ an integrated XGBoost–SHAP–DBN approach to identify key drivers and their causal network over time, enabling a dynamic interpretation of ER evolution. (3) Spatial pattern optimization: Based on the identified drivers and dynamic rules, the DBN–PLUS model is combined to simulate future land-use scenarios and derive spatial pattern optimization strategies under resilience enhancement objectives. These three steps are designed to form a coherent workflow—from assessment and diagnosis to intervention—ensuring that the optimization strategies are based on a strong understanding of ER dynamics and drivers.

# 4.1. Nested Ecological Resilience Assessment

# 4.1.1. Local Substrate Resilience: “Resistance–Recovery–Adaptation”

As ecosystems face increasing stress and disturbance, local ecological resilience has become a critical academic focus. The “resistance–recovery–adaptation” framework originated from studies on urban and regional resilience to external shocks. Ecosystem service value represents the ecological conditions and functions that sustain human well-being, and its persistence under external disturbances reflects ecosystem resistance. Previous studies show that ecosystem stability is closely related to adaptability, so the structural stability of the landscape can characterize adaptability [9], and landscape heterogeneity and connectivity indices are key components to evaluate landscape stability. Ecosystem recovery can be reflected by the degree of recovery of different land use types. Based on the above three properties of ER, this study evaluates local ER using indicators such

as ecosystem service value (O), landscape pattern indices (A), and ecological recovery coefficients (R) (details in Supplementary Materials).

![](images/5b13fae298edb4df1c569fdb04adf14464a6b60de6d21d04fa02a305ad7d75b0.jpg)  
Figure 2. Research framework (The dynamic Bayesian network part in the figure is briefly supplemented in the form of a schematic diagram. For instance, the yellow dashed arrows indicate the influence between different time slices, and the black solid arrows represent the effect of the independent variable (X) on the dependent variable (Y)).

The Local ER index is calculated as the geometric mean of standardized resistance, adaptability, and recovery values:

$$
\mathrm {E R} = \sqrt [ 3 ]{\mathrm {O} ^ {\prime} \times \mathrm {A} ^ {\prime} \times \mathrm {R} ^ {\prime}} \tag {1}
$$

where $\mathrm { O ^ { \prime } , A ^ { \prime } } .$ , and $\mathbb { R } ^ { \prime }$ are the standardized resistance, adaptability, and recovery indices, respectively.

# 4.1.2. Global Resilience Modification: “Structure–Quality–Function”

Current ER assessments often fail to account for the structural heterogeneity of ecosystems. Incorporating global resilience with telecoupling offers a necessary complement to local assessments [62]. Ecosystem is essentially a spatial network, and ecosystem resilience can be measured by ecological network resilience to some extent in order to reflect the overall state of spatial resilience [66]. In this study, network resilience is quantified using ecological network resilience metrics based on complex network theory [67], which helps adjust local ER estimates to account for spatial connectivity and cross-scale interactions—a dimension often missing in traditional studies. Below, we identify EN and build network resilience through the “structure–quality–function” framework.

# (1) Ecological Network

Ecological sources are identified by equally weighting and overlaying ecological sensitivity, landscape connectivity, and ecosystem services, with high-ranking patches selected as sources. Landscape connectivity is assessed via MSPA and Conefor 2.6, while ecosystem services cover biodiversity, carbon sequestration, water conservation, soil retention, and recreation service. Ecological sensitivity integrates NDVI, land use, elevation, slope, precipitation, and soil erosion using AHP-weighted overlays [68,69]. The resistance surface, constructed from land use, distance to roads/railways, NDVI, elevation, and slope via expert scoring and nighttime light data correction, reflects constraints on species movement. Ecological corridors are delineated using circuit theory in Linkage Mapper 3.0 to simulate connectivity between sources based on resistance surfaces. The indicators were selected based on the specific characteristics of the study area and guided by existing literature (for more details on indicator meanings, selection rationale, and calculation methods, see the Supplementary Materials).

# (2) Network Resilience

As a global network characterization, ecological network resilience is reflected in the resilience of maintenance elements in structure, function and quality dimensions, and the stability against external disturbances. Therefore, considering ecological network resilience [67,70], six indicators are selected (Figure S4): Structural resilience: Ecological space involves the constituent elements of ecosystems and their spatial configuration. In ecological networks, structure refers to ecological sources, corridors, and how they are connected to each other. Structural resilience consists of three dimensions: complexity, connectivity, and aggregation coefficient. Quality resilience: pay attention to the composition of ecological network (EN) itself, such as the quality of the ecological source. Source quality can be measured by the area of the ecological source and the ratio of its habitat risk to a standardized value. Functional resilience: It focuses on the core function of EN to achieve the efficient flow of energy, matter, and information. It is mainly embodied in the resilience of the functional importance of ENs, including two aspects: transmissibility and diversity. The transmissibility is closely related to the patency of the corridors between nodes. The high patency ensures the rapid migration of ecological flows between nodes, enhances the ability of the network to resist crises. On the other hand, diversity describes the fault tolerance of the network, that is, when a corridor is damaged, alternative pathways connecting ecological sources can maintain network function [70].

Finally, these six indicators are standardized, and the structural resilience index ST, quality resilience index QU, functional resilience index FU and overall resilience index OR of ENs are calculated using the equal weight method:

$$
\mathrm {S T} = \left(\mathrm {A} ^ {\prime} + \mathrm {C} ^ {\prime} + \mathrm {S} ^ {\prime}\right) / 3 \tag {2}
$$

$$
\mathrm {Q U} = \mathrm {S Q} / \tag {3}
$$

$$
\mathrm {F U} = \left(\mathrm {T R} ^ {\prime} + \mathrm {A} ^ {\prime}\right) / 2 \tag {4}
$$

$$
\mathrm {O R} = (\mathrm {S T} + \mathrm {Q U} + \mathrm {F U}) / 3 \tag {5}
$$

where $\mathrm { A } ^ { \prime } =$ agglomeration index, $C ^ { \prime } =$ connectivity index, ${ \boldsymbol { \mathrm { S } } } ^ { \prime } = { \boldsymbol { \mathrm { \Omega } } }$ complexity index, $\mathrm { S Q ^ { \prime } = }$ source quality, $\mathrm { T R ^ { \prime } = }$ transmissibility index, and $\mathrm { A L ^ { \prime } = }$ diversity index (all normalized).

# 4.1.3. Nested Ecological Resilience: Cross-Spatial Scale Calculation

In order to synthesize the advantages of the above two perspectives, network resilience can be regarded as a useful supplement to substrate resilience [53], thus, global resilience serves as a corrective factor for local resilience, yielding the final nested ER. This also helps to comprehensively consider the full-cycle characteristics [54] and inherent properties [4,71] of ER. Local and network resilience values are integrated using inverse distance weighted interpolation, which assumes that closer spatial units exert stronger influence [36]. This yields a spatially continuous map of integrated ER for the WMA.

# 4.2. Driving Mechanism of Ecological Resilience Based on Hybrid Machine Learning

# 4.2.1. Preliminary Selection of Driving Factors Based on XGBoost-SHAP

Nineteen indicators across natural, socio-economic, and spatial pattern dimensions were initially selected (Table S9). Based on prior research, the representative spatial pattern mechanisms affecting ER can be divided into spatial composition and spatial structure dimensions. Spatial composition includes metrics such as the proportional area of land use types [44], while spatial structure comprises landscape pattern indices [36,72].

To balance computational complexity and practical applicability in decision-making [73], we applied a two-step method to identify key variables: We first defined causal relationships using prior knowledge constraints, and then applied XGBoost–SHAP-based feature selection. The gradient boosting decision tree ensemble method XGBoost was combined with SHAP values to quantify feature importance [74], thereby identifying dominant drivers [75].

# 4.2.2. Dynamic Bayesian Network: Resilience Modeling Across Time Scales

Bayesian networks are effective tools for representing and reasoning about causal relationships [76]. However, static BNs are insufficient to capture the temporal dynamics of ecological systems [77]. DBNs address this by integrating BNs with Markov chains, introducing a time dimension to capture dependencies across time steps and reveal variable evolution patterns. DBNs consist of a prior model, which defines initial conditions and causal relationships among nodes, and a transition model, which describes how variables evolve from past time $( t - 1 )$ to the next time (t). DBNs can compute the joint probabilities across temporal nodes to analyze the spatiotemporal drivers of ER [46].

This study utilizes the pgmpy package in Python 3.12 to construct the DBN model, enabling inference, diagnosis, and evaluation. After discretizing the data using the natural breaks method, the dataset was split into training and testing sets in a 4:1 ratio to ensure model robustness. However, DBN is prone to local optima traps and is dependent on subjective assumptions [73,78]. The robustness of traditional algorithms is poor, so we used genetic algorithm (GA)—a global optimization method—to optimize the DBN structure [78]. The initial population $( N = 6 0 )$ ) included structures informed by expert knowledge, XGBoost– SHAP analysis, and random generation. The Bayesian information criterion (BIC) was used as the fitness function, with the algorithm iterating for 200 generations. The study initially attempted to construct transition networks using the pgmpy package and learn interslice dependencies via GA. We followed simplified modeling approaches from previous

studies [45], where ER was modeled as a dynamic node linking adjacent time-slice BNs. Parameter learning was carried out using the Expectation-Maximization (EM) algorithm, which estimates the conditional probability tables (CPTs) from historical data.

# 4.3. Multi-Scenario Optimization of Land Use from the Perspective of Ecological Resilience Improvement

The PLUS model is a land-use simulation system [79], integrating the land expansion analysis strategy and a multitype random patch seed cellular automata model [80], with high simulation accuracy [81]. In this study, the 2020 land-use map was set as the baseline to simulate the land-use pattern in 2035 under different ER target scenarios.

This study established the natural development scenario, compared it with the ecological protection scenario, and verified the effect of improving ER. In the PLUS v1 model, three scenarios were defined in total (parameters listed in the Supplementary Materials). (1) Scenario 1 (Natural development scenario) was established as the baseline. It simulated a future with limited socio-ecological changes that followed historical trends, without targeted ER management. (2) Scenarios 2 and 3 were conceived as ER-optimized scenarios with incremental enhancement goals. These were structured around an ecologyprioritized development paradigm designed to enhance ER, modeling outcomes under graduated management intensities—Scenario 3 representing the most stringent. The specific parameterization for these scenarios, such as the demand for each land use type in 2035, was informed by key regulatory factors identified through the DBN’s reverse inference mechanism.

# 5. Results

# 5.1. Ecological Resilience Assessment and Spatiotemporal Evolution

# 5.1.1. Evolution Characteristics of Local Ecological Resilience Based on the “Resistance– Adaptation–Recovery” Model

The spatiotemporal evolution of ecosystem service value was assessed through weighted overlay analysis and reclassification, revealing a persistent spatial pattern of higher values in the east and lower in the west, with consistently low values in central urban areas and minimal change over time (Figure 3a–e). The ecological recovery coefficient exhibited significantly high values in the mountainous regions in the south and northeast. Adaptation coefficient values were dispersed throughout the WMA, with particularly high concentrations in the eastern part and low-value clusters forming in the northwest and partially in the central region. Overall, local ER remained relatively stable during the study period, showing minimal spatiotemporal fluctuation (Figure 3p–t). Spatially, areas with high local resilience were consistently located in the peripheral zones of the WMA, particularly in mountainous regions and around lakes with favorable ecological conditions. In contrast, areas with low resilience were concentrated in urban built-up zones and intensively developed surroundings. In terms of land use types, high-resilience areas were dominated by forests and grasslands, moderate- and high-resilience areas were mainly composed of grasslands, water bodies, and croplands, and low-resilience areas primarily by construction land. According to ecological sensitivity analysis, cropland and construction land subject to anthropogenic disturbances exhibited elevated ecological risks and lower recovery capacity.

![](images/6567dbb7ba0a7bc6e01762ae60dac7e09daafe3eddc189859cf23870dc9d55d6.jpg)  
Figure 3. Temporal and spatial dynamics of local ecological resilience based on the “Resistance– Adaptation–Recovery” model.

Temporally (Figure 4), from 2000 to 2020, the local resilience components showed relative spatial stability, with resilience declining in some built-up areas and increasing in scattered regions elsewhere. In particular, resilience levels improved during 2005–2010 and 2015–2020, while other intervals remained generally stable.

![](images/ec9d1e06599668ea98c6992b20c520684d43113aff8de47ebceddf464c5404d8.jpg)  
Figure 4. Trends in local ecological resilience in the WMA.

# 5.1.2. Evolution Characteristics of Global Ecological Resilience Based on Complex Networks

Significant spatial heterogeneity was observed in the ecosystem services of the WMA (Figure 5). Soil conservation, carbon sequestration and oxygen release, water conserva-

tion, and habitat quality showed generally consistent spatial distributions, with habitat quality and soil conservation showing the strongest gradients—generally higher in the east and lower in the west. High-value areas were concentrated in the Dabie and Mufu Mountains, while central and eastern flatlands had lower risk of soil erosion. Although cultural service values displayed no clear overall spatial trend, local heterogeneity was evident. From 2000 to 2020, carbon sequestration levels remained relatively stable, with slight increases in northern Wuhan (Macheng and Hong’an). Water conservation levels changed mainly in the eastern high-value regions; increases were observed in southeastern Huangshi and Xianning before declining, while Xiaogan showed continuous improvement. Habitat quality, soil conservation, and cultural services remained largely stable over the 20-year period.

![](images/db413187f98462f099aa5bead0bf9f8cab553582861562560079cd0bf66e4c0c.jpg)

![](images/1daa16421a724c388a63db377961ad27a8d7d110a2d7847822408f85dd6de996.jpg)

![](images/46a1b38d961f2a1c1ea5c3d07e2a7c046014cd4b477800b0932fea3e14131d3b.jpg)

![](images/ca57a0774e07d83f24d96e12321fa968f7e3da89f2795b1de73ed649f57c1e23.jpg)

![](images/bbb7a5abab703327ca8fe7be754fe7147c17514739ac7aaecfaad02edc8dcb26.jpg)

![](images/bf387abbf4034d4fa2ed70b38dfb3e822a1e31f3e46bde52b52b44202e5b7e97.jpg)

![](images/66b2c4e33eff9423016e47e66361869851cce36041945a69ead8a43b20ffa704.jpg)

![](images/ba6f25eb7e29f6ed1786e13eb28c8ca683c209d4bc2561739765d7a320a5da81.jpg)

![](images/4bbfaa5c132d8e56ef27f725b58ea58ff78c07f73049b5d9746d33864c156749.jpg)

![](images/a8bbb45b71d0196a3017dd4bea1a559a81184be7a53e55f427a0051981ea74ba.jpg)

![](images/7dc958be297ae89ee2a2eb9be901120531cce24d20dbcd844db1b9ccdcd843ad.jpg)

![](images/b085c7b0bb9c9c8bbb1b650390615544c91216206b06587540109bf0f0b8390c.jpg)

![](images/db3690008dc33be398f6cdca892d440ef8a48151c3b20d824db0d80d57bb6de6.jpg)

![](images/885b79b289a80dea7caedb222fa2aa31471608bf7b465362c6213010008001c6.jpg)

![](images/e00f14aea89448ee9ffa3f5bee1efdd8430108a97def75c56d9036ce1fa7d9c5.jpg)

![](images/d3eb6a9c0d7eb560ce572f23bf79ccffe3757fe8558bc1d9201775762693953c.jpg)

![](images/b97c607111a499465102d54026923d8493e2d90b90ca312a4c3f6f5e98dd60c5.jpg)

![](images/6edbe93078c19e54f41497e4b244d3086d5d0faaa9642b1be6adad612a414ccf.jpg)

![](images/4888a1e01d7af99747a19658579d0595dde7a439c80a8560ab8d7298956985d7.jpg)

![](images/f2ea4e384edbb2a05fe740c9f584842fa9be2c4ccd44920ee24bebb49f3583e2.jpg)

![](images/b0550c7a9946d3e60c3d33cec601628a2112acd81009258594714765781d73e1.jpg)

![](images/68579d1378174a20d091701c2534d0d691dba66f79fbac81b92873a832daa89f.jpg)

![](images/56439d8643eb7666d0e4385a064171e3cb02746ab825d4a34ce7d38f9043e2c2.jpg)

![](images/cffd3e2ef3cb1fd80f4751b18ec1a83acb801bdd8106766b1491773d9e0d7c6c.jpg)

![](images/fd0fb425e08e3141a41a5a39bd5fd6439b43fa6029a2b172e060c6cad55ec8f7.jpg)  
Figure 5. Spatial distribution of ecosystem services from 2000 to 2020.

Ecological sensitivity exhibited a stable spatial pattern of higher values in the northeast and south, and lower values elsewhere (Figure 6). The central built-up area of WMA was a persistent low-sensitivity zone that expanded over time. In terms of landscape connectivity,

high connectivity persisted in southern and northeastern patches, whereas connectivity declined in fragmented patches along the Yangtze River and northern areas over time.

![](images/d84bb054e8bbce17a88a870dd191e9559c6c55c4342aa2221e771514430c76f1.jpg)  
Figure 6. Spatial distribution of ecological sensitivity and landscape connectivity from 2000 to 2020.

Regarding the spatiotemporal dynamics of the ecological network (Figure 7), major ecological sources were located in peripheral zones of the WMA, particularly in northeastern and southern regions. However, scattered smaller sources gradually disappeared over time. Ecological corridors primarily connected the major sources in the north and south, and some fragmented features such as rivers and forest belts were forced to pass through expanding urban built-up areas. As urban expansion continued, ecological corridors became narrower and more constrained. Spatial patterns of global ER were largely established by 2000 and remained stable in subsequent years. Notably, resilience in the southern region declined significantly, likely due to urban encroachment on ecological spaces. Although some local improvements were observed between 2015 and 2020, these did not substantially alter the overall resilience pattern.

# 5.1.3. Evolution of Comprehensive Ecological Resilience

The revised comprehensive ER showed more pronounced hierarchical differentiation while maintaining the overall spatial distribution pattern of high resilience in the southeast and northeast and low resilience in the central and western regions (Figure 8). Compared with local resilience, areas of forestland in the Dabie and Mufu Mountain ecological sources exhibited higher resilience levels due to adjustments based on complex network analysis. To further explore the temporal dynamics of ER, pairwise comparisons were made between adjacent time slices. Changes in ER were primarily concentrated in urban areas and dense forest regions. From 2000 to 2015, resilience in the urban core declined annually, followed by a slight rebound in 2020. Overall, ER remained relatively stable from 2000 to 2015 but declined sharply between 2015 and 2020. Based on natural breaks, the distribution of ER across intervals was analyzed (Figure S5). High-ER areas accounted for $9 . 5 \%$ in 2005 but dropped to just $1 \%$ after 2010. The mean ER values across the years 2000–2020 were 0.4856, 0.4978, 0.4756, 0.4835, and 0.4503, respectively, highlighting the temporal fluctuations of integrated resilience in the Wuhan Metropolitan Area.

![](images/82f2f0c9a5407938195bb041d42b3831c604d8e106044462f536f5b7923d8e37.jpg)

![](images/23fb171ac6d89bcd38a8a24b17d47d05542eb56aa888bba2aded2aa47c167e77.jpg)

![](images/699d0b3d579e79b7128e4b2daccc372c590043f5c0b76bd67bc1834e15770a9e.jpg)

![](images/0cbccc1bc429f6c7f81351364cb82ed05efa2acd39259574b8936e8be384561c.jpg)  
Figure 7. Ecological network resilience.

![](images/d452fcf68d525ee7a42447e111bddeae52d7777575a93e872ed207db8f9b0978.jpg)

![](images/570e4d616f700a1cc97c5d46553351ba614bb99b2da038b8b0a7a21427eefb7b.jpg)

![](images/864d6b23d53e3227058b912ea53167c61f46f248e04608bc7903e9b5ebefa530.jpg)

![](images/5a2f7e12f7e80aa915a2df64d958f9a79d2cb72b3e52842a959b451b33ca0c96.jpg)

![](images/034e56a6c67cade7ca5982152fea59c021ec9adae06c96a5cf7572e2ad471c87.jpg)  
Figure 8. Spatiotemporal evolution of comprehensive ecological resilience from 2000 to 2020.

# 5.2. Driving Mechanism of Ecological Resilience

The results of XGBoost-SHAP model indicated that elevation was the most influential driving factor, followed by land use type, while socio-economic factors had relatively minor effects (Figure 9). Positive drivers of high ER included elevation, Shannon evenness, forest proportion, slope, and vegetation index, whereas negative drivers included cropland proportion, built-up land proportion, and net primary productivity. Based on the variable importance rankings from XGBoost and expert knowledge, ten key factors were selected as parent nodes for prior Bayesian model construction: elevation, slope, precipitation, land use type, vegetation index, cropland proportion, forest proportion, construction land proportion, Shannon evenness, and patch density. In summary, the mean absolute SHAP value showed that spatial composition factors such as land use $( \mathrm { S H A P } = 0 . 1 6 )$ ) are more influential for ER than spatial structural factors such as Shannon evenness index $( \mathrm { S H A P } = 0 . 1 0 ) ,$ ).

![](images/26660b055679d09a9e102b9efcb6a2bdd90e5dde4aec45bd2b87f09adb609fcb.jpg)

![](images/a39a860e72400d0efb3394da16b9d96ca45e6df8bc2a46049b6c0c559bd414e8.jpg)  
Figure 9. SHAP summary plot and importance ranking of ER driving factors.

The static Bayesian network comprised 11 nodes and 21 edges, achieving $7 8 . 6 1 \%$ accuracy and high AUC values for low, high, and middle ER states (Supplementary Materials). The final DBN expanded to 55 nodes and 109 edges (Figures 10 and S7). To identify the key drivers of ER change over time, a sensitivity analysis was conducted on the transition network (Figure S8). The results showed that the major driving factors of ER included elevation, slope, land use, and forest proportion at time $\mathrm { t , }$ as well as elevation, slope, and patch aggregation (PD) at time t − 1. All causal pathways were ranked by sensitivity strength, and those with higher strengths were considered more critical (Table S13). For example, one of the strongest causal paths identified was: dem $( \mathrm { t } - 1 )  \mathrm { l u l c } ( \mathrm { t } - 1 )  \mathrm { c r o p }$ $( \mathrm { t } - 1 ) $ forest $( \mathrm { t } - 1 )  \mathrm { E R } ( \mathrm { t } - 1 )  \mathrm { E R }$ (t). To further explore the ecological response mechanism, a comparative analysis was performed using the transition network between the 2000 and 2005 time slices. The three ER states were separately set to the highest level to observe changes in the posterior probabilities of other nodes. The results showed that as the ER_1 state increased from low to high, the probabilities of low states in directly connected nodes—such as SHEI, DEM, LULC, FOREST, and NDVI—decreased to varying degrees, while CONSTR and CROP exhibited an increase in their low-state probabilities (Figure 11).

![](images/80b1cfa3506cddaa24bef35908087af1909e9d3be26447396fa03c8bafba59bc.jpg)  
Figure 10. Dynamic Bayesian network (Bar charts indicate the prior probability distributions of each node. The number label represents the proportion of each variable in the current situation under the corresponding state value. The straight arrow indicates the effect from the independent variable to the dependent variable. The circular curve arrow indicates the action across time).

# 5.3. Multi-Scenario Ecological Spatial Optimization Based on DBN and PLUS Models

To enhance practical relevance, land use type—an actionable variable—was selected for ecological spatial optimization. Specifically, reverse reasoning was performed using the DBN. By adjusting the probability distribution of ER, the corresponding changes in land use categories were observed. This enabled the identification of optimal land use configurations that align with ER enhancement objectives. The results indicated that the proportions of forestland, cropland, and built-up land varied significantly with changes in ER (Figure 12). For example, when ER was set to $1 0 0 \%$ low, the probability of forest area falling into the low-value interval increased by $2 5 \%$ , the medium interval decreased by $4 \%$ , and the high interval decreased by $2 1 \%$ ; meanwhile, cropland in the high-value interval increased by $2 1 \%$ . This suggests that high forest coverage corresponds to higher ER. Under ideal conditions—where forestland proportion is entirely in the high-value interval, and cropland and built-up land are entirely in low-value intervals—ER increased by $4 0 \%$ , indicating that spatial reallocation of these land types contributes significantly to resilience improvement. Given that existing built-up land is difficult to convert, the ER optimization scenarios prioritized increasing forestland while limiting built-up land expansion. The simulation results for 2035 (Kappa coefficient: $0 . 8 4 5 > 0 . 7 5$ ; overall accuracy: 0.897) showed that cropland and forestland combined accounted for more than $7 5 \%$ of the total area under all scenarios, characterizing a typical rural landscape (Table 2, Figure 12). In the ER-optimized scenarios, forestland expansion came at the cost of reduced cropland.

To further validate that increasing forest area enhances ER, the study re-evaluated ER under all three scenarios (Figure 12). In the optimized scenarios, forest expansion in the Mufu and Dabie Mountains led to improved resilience and broader ecological influence zones. By contrast, in the natural development scenario, outward expansion of built-up land reduced ecological connectivity among major sources, increased landscape fragmentation, and decreased resilience. The proportion of high resilience regions increases from $3 . 1 8 \%$ in the base year of 2020 to $5 . 2 8 \%$ in scenario 1, $5 . 9 6 \%$ in scenario 2 and $5 . 0 7 \%$ in scenario 3 in

2035, indicating that there is a threshold effect of land use factors represented by forests on ER. The results highlight that in regions dominated by rural landscape characteristics, modifying spatial patterns via ecological land use, especially through forest expansion, can improve regional ER.

![](images/2efaa0dcd64021ff3155914ca404ef86799ee10a75dc50aea2ec93b86490c8e2.jpg)

![](images/7485135a9ed427a3d4d937fa7ab60893fa98bc11d710ff97e7b69d21cd6f32e6.jpg)

![](images/a28f188ee076ce21ebea507d7b729b83e122c7e9bd5aad6cad4a43966c6dc37f.jpg)

![](images/d13ab127ef9b44e024d824e0ad49c7d3fcd8d28fb8fa55693a8dcd6364056fcd.jpg)

![](images/688f922c3c73efb4ad93a3bd354d0227ebc139ccd78a1ad8a8fee2668430add6.jpg)

![](images/a6d50f5f87de365f844aeb552142f9601c1a55cd29c4c11a393ba23e7160a4f7.jpg)

![](images/35b53427c887b6214a2208012b8740120a5e09363c625da45a7bfeb085bbc688.jpg)

![](images/3d94a7ea2afba6f31d96a97ab00cdcb1816e6a4f6b830bc9e1181018ab56ef66.jpg)

![](images/3f9521c8c2f41e7193c118e6c5dc10e9464f94c834bb6d6eabd9123bad7b3005.jpg)

![](images/590080a8d074e4bb123679ccff1439f0252e5ef2f31107cb9eaf28c7ea8a88af.jpg)

![](images/119840a3f3ea4bf52af62c308ce254edb241ef22eff438227a285436ede949e2.jpg)

![](images/56a3942c9762bf0c996d3470dffe6dac6b68e00f25bdfbacf62558466f089659.jpg)

![](images/678e3541b65b88628223c9df5f1e0c0a7aefe3f2fb59936a27aa64427e5497c1.jpg)

![](images/1490e0821082e6ab9660a22cb38be85246450e50cf176b67cf11475bd92377c1.jpg)

![](images/ec941739e21ec47647195dfabb06c97f69dcb9a5258203907a05c3971804721c.jpg)

![](images/d813afabd2f3769d26cca5a6e14d7f1923773fe3efa739b810f80a561b993f0d.jpg)

![](images/fc83fcac9e6a699bcf72a07da9885c9fe822f5a337fe7ebae95c4fc0fe4f730d.jpg)

![](images/c3aa22d26c0f79b2ef27fc01af5e0f5955f1c2cd5fe047e4fc7ea12b19ac2a19.jpg)

![](images/51cc33f47139d85583403946cb20d00fbd5f949c711594ca59706f7103987958.jpg)

![](images/3f746f1c8d6e5bbf05f02cfa8cfaa2feaf050b4ac6f0121efda3ffbb30b87ed7.jpg)

![](images/2d25d0c99f7aed70f48ebf954a5e377a6ac0d8265f2b7129f2c832e9263fb6d8.jpg)

![](images/4ef2728e7424c65def031b96db146fae4c6c855b1a0f13482c24b0a249d5ab2c.jpg)  
Figure 11. The response relationship of the driving factor with the change of ER.

Table 2. Land-use proportions under different ecological spatial scenarios in WMA.   

<table><tr><td rowspan="2">Land Use Type</td><td colspan="4">Proportion of Land Types in Different Scenarios</td></tr><tr><td>Current</td><td>Scenario 1: Natural Development</td><td>Scenario 2: Moderate Forest Expansion</td><td>Scenario 3: Large Forest Expansion</td></tr><tr><td>Cropland</td><td>0.4913</td><td>0.4767</td><td>0.4622</td><td>0.4060</td></tr><tr><td>Forest</td><td>0.3001</td><td>0.2978</td><td>0.3299</td><td>0.3862</td></tr><tr><td>Water</td><td>0.1046</td><td>0.1055</td><td>0.1046</td><td>0.1046</td></tr><tr><td>Construction land</td><td>0.0761</td><td>0.0926</td><td>0.0761</td><td>0.0761</td></tr></table>

![](images/2dce46bcd54bb1831fe9b040a0d0d02ea72a0f60ff139d49cc897d47550dae74.jpg)  
(a) Current land use   
in 2020

![](images/a66d5f5540f71e20360c472f5a1b97673606f27b718e8ae212c568f3a7719d2d.jpg)  
(b) Land use in scenario 1:   
Natural Development scenario

![](images/90e63123d3eb34c57156359fda74db215fde28857de8036cae87a0c13f917a1c.jpg)  
(c) Land use in scenario 2:   
Small growth in forest

![](images/58dd2658135bcffe2a60cf0bff1363c44191ff8a1b2c52796baf20093086135c.jpg)  
(d) Land use in scenario 3:   
Substantial growth in forest

![](images/61510de73472bfbf1fb89f75ffc4c411f22a75e566b6b6d379be7dffb2bbb44c.jpg)  
(e) Current ecological resilience   
in2020

![](images/81a58450db7226f0f01272a8234ff76be1ebbea2e8eacf8abf69f5f6dbbb120e.jpg)  
(f) Ecological resilience in scenario 1:   
Natural Development scenario

![](images/cadc0f1f9a5480c89cdbf50b1d0859c11c48dd13e005c3f4965b828d950a7478.jpg)  
(g)Ecological resilience in scenario 2:   
Small growth in forest

![](images/717077062df75da43959a7dec7dc74eaf6d1f0963b53a0cb3c506b346e38bab6.jpg)  
(h) Ecologicalresilience in scenario 3:   
Substantial growth in forest   
Land Use for Cropland Cropland   
(a)-(d)

![](images/868e4165940c8ba651613e11bdbe47e926fcdcf417efe5e8f0746bdfe255bdcf.jpg)  
Forest Grass   
1 Water   
Construction land Barren   
Ecological Resilience   
for(e)-(h)   
High: 2.3   
Low: 0.0

![](images/8812d8c4b1fc96be98085e09fb33fb2f487c26f29d899a2738e0b8cb7c629564.jpg)

![](images/05b2e1810063461122517425b8cfe54db3da5a83fe44dbe16d7f3b2d4c10e595.jpg)  
Figure 12. Multi-scenario simulation of ecological spatial configurations and corresponding resilience states.

# 6. Discussion

6.1. Advancing Spatial Resilience Assessment: From Local Attributes to Panarchy in Cross-Scale Framework

This study constructed an integrated assessment framework encompassing both “local substrate” and “global network” resilience to analyze the ER of the WMA. The local resilience, evaluated based on the “resistance–adaptation–recovery” model, reflects the intrinsic capacity of ecosystems to withstand disturbances. The network resilience considers the connectivity and interactions among ecological elements, emphasizing global properties such as inter-element connectivity, complexity, and redundancy. Applying panarchy thinking in ER assessment necessitates moving beyond single-scale evaluations [6,34]. Conventional assessments primarily rely on panel or remote sensing data [31], often employing simplified assumptions and single-scale frameworks. Failure to account for telecoupling effects results in incomplete risk evaluations that address local symptoms while exacerbating problems elsewhere or across scales. Our methodology explicitly incorporates spatial complexity and cross-regional connectivity, including network topology [82]. By simultaneously considering localized restoration (e.g., vegetation rehabilitation) and top-down governance (e.g., regional policies), regional resilience can be enhanced. Conversely, neglecting nested interdependencies may amplify vulnerabilities, as shown in the Changzhi mining district case: localized interventions proved ineffective without coordinating landscape-scale corridor connectivity [32]. This integrated approach provides a more holistic understanding of ecosystem stability and adaptability while advancing spatial resilience research. It will help avoid “island-style” assessment blind spots, provide scientific basis for cross-domain resilience management like watershed governance and urban agglomeration coordination, and facilitate realizing the panarchy vision where “local restoration serves global stability, and global regulation empowers local adaptation” [34,56].

# 6.2. Spatiotemporal Responses of Ecological Resilience to Socio–Natural–Spatial Drivers

Results show that the evolution of ER is closely associated with land use transitions [83,84]. Rapid urbanization has led to a reduction in cropland and ecological land, thereby weakening regional ER. Terrain shapes the spatial layout of land use, thereby influencing ecosystem distribution and connectivity [85]. Landscape metrics, such as diversity and patch aggregation, exert a considerable influence on ER [86]. Gu et al. reported a positive correlation between patch aggregation and ecological vulnerability, suggesting that heterogeneous patches may impede each other’s ecological functions, reducing overall landscape connectivity [87]. Spatial attributes such as landscape connectivity also directly affect ER [11]. Conversely, landscape metrics negatively correlated with ecological vulnerability—such as contagion, aggregation index, and Shannon diversity—indicate that landscapes with high patch connectivity, rich biodiversity, and dominant ecological patches demonstrate greater resistance to disturbances [87]. Similar evidence has been found in urban settings [88]. Although this study did not include population data due to its complex aggregation effects, previous research confirms that population agglomeration affects ER [89].

Understanding the spatiotemporal responses of controllable drivers such as spatial composition provides a feasible basis for guiding spatial layouts to improve ER in practice. Further analysis shows that in urban–rural integrated landscapes characterized by rural spatial features, spatial pattern factors generally exert a stronger driving influence on ER than socioeconomic or uncontrollable natural factors. Among spatial factors, composition elements (e.g., land use types) have a greater impact than structural elements. This finding is consistent with results from studies on ecosystem service interactions [90]. According to spatial resilience theory, spatial pattern affects the physical dependence and ecological processes among system elements, which in turn influence ER [91]. Moreover, the impacts of land cover change driven by climate change and urbanization tend to exceed those of structural spatial change, highlighting the foundational role of ecosystems in supporting resilience. This study also identifies a threshold effect among resilience-driving factors such as spatial composition and landscape configuration, echoing previous findings [92]. Under the DBN framework, thresholds imply that when factors such as land composition fall within specific value ranges, the probability of enhanced ER increases (Figure 8).

# 6.3. Policy Implications and Advantages of Enhancing Ecological Resilience Using the DBN-PLUS Framework

The long-term knowledge embedded in the DBN-PLUS facilitates understanding of these latent interactions under dynamic and uncertain conditions, thereby offering planners policy recommendations and orientations. Our study helps identify the fast and slow variables that affect ER [73], which are critical to the long-term success of conservation efforts. This study further integrates the XGBoost-SHAP model and a GA-optimized DBN, overcoming limitations of conventional approaches that rely on expert knowledge. Through DBN-based backward inference, this framework identifies and adjusts key controllable resilience drivers from low-resilience states to high-resilience states, thereby guiding land use restructuring under different policy scenarios. Ecological management policies should prioritize the following actions:

(1) Conservation-oriented land use planning should aim to optimize both land use quantity and spatial configuration [93]. Policy-making should employ scenario analysis to anticipate land cover impacts on resilience and proactively designate ecological buffer zones and protected areas to mitigate future disturbances [94]. Future policies should more strictly control unregulated urban expansion and promote ecological restoration programs such as natural forest conservation, reforestation, and greening

of previously developed land, especially in peri-urban transition zones of high conservation value. These actions should be embedded in a robust and flexible governance framework that supports multi-objective spatial coordination to ensure effectiveness.

(2) Ecological engineering should aim to increase the number and diversity of green patches to improve landscape heterogeneity, evenness, and connectivity—a strategy directly supported by our findings that increased patch density and Shannon evenness enhance resilience. Specific measures include: restoring wetlands, grasslands, or forests in farmland areas can diversify landscape elements [95,96] and moderately fragmenting large forest patches to create canopy gaps that can increase edge effects and biodiversity [97]. In high-density urban areas, the construction of parks, green roofs, and ecological nodes, as well as the establishment of green wedges and corridors, can enhance landscape connectivity [98].

(3) Another policy orientation is to incorporate DBN for long-term monitoring and adaptive policy adjustment, while fostering cross-sectoral collaboration among conservation agencies, planning departments, and regional governance bodies. Given the adaptive nature of ER, DBN models enable a shift from static assessments to ongoing, real-time monitoring, informing long-term protection and restoration strategies [46]. Furthermore, by integrating diverse natural and socio-economic variables and incorporating stakeholder feedback, DBN can promote interdepartmental communication and the integration of multiple planning approaches [73]. We recommend establishing a cross-departmental platform centered on DBN outcomes to institutionalize this collaborative approach.

# 6.4. Deficiencies and Prospects

First, this study adopts a state-based resilience assessment approach [30], suitable for long-term macro-scale analysis in metropolitan regions facing complex disturbances. However, future work should refine assessments by incorporating dynamic process-based methods at finer scales, targeting specific disturbances or system dynamics to better capture micro-scale resilience mechanisms. While this approach is suitable for long-term temporal analysis, it cannot substitute for process-based assessments of dynamic resilience. Future research should integrate both static and dynamic perspectives to enhance understanding of resilience mechanisms and management strategies. Furthermore, ER should not be confined to natural system parameters—growing attention must be given to social–ecological resilience as a core research direction [99]. Second, training a DBN model requires continuous time-series data to accurately capture dynamic changes in resilience. However, as the model’s structural complexity increases across multiple temporal and variable dimensions, the computational demands grow significantly [73]. While simplified assumptions balance feasibility and accuracy [45], future work should enhance causal inference across time slices using more nodes and advanced algorithms to improve DBN predictive performance. Finally, network-based indicators need to be promoted to refine complex network metrics specifically for quantifying cross-scale resilience and remote coupling strength. More crossscale case studies should be carried out to enrich empirical evidence to test the integration framework, such as assessing how regional network topology affects the restoration of locally disturbed ecosystems.

# 7. Conclusions

This study integrates hybrid machine learning models to propose a framework for cross-spatiotemporal modeling and spatial optimization of ER. Inspired by panarchy thinking, we analyze the spatiotemporal evolution of ER from 2000 to 2020 by combining “local” resilience—based on the “resistance–adaptation–recovery” framework—with “global” net-

work resilience from a telecoupling perspective. Using XGBoost-SHAP and DBN, we identify the causal network of resilience drivers. Leveraging the backward inference mechanism of the DBN, we simulate land use patterns under multiple scenarios, exploring pathways to enhance ER. Key findings include:

(1) ER exhibited a distinct spatial gradient characterized by higher values in the east and lower values in the west. ER remained relatively stable, with a slight decline from 0.4856 in 2000 to 0.4503 in 2020. Forest land demonstrated higher resilience due to its ecological value and role as habitat space.   
(2) Elevation and spatial pattern factors—particularly spatial composition and structure— were identified as the dominant drivers of ER. Among these, the proportion of forest land had a significant positive impact, while higher proportions of cropland and construction land suppressed ER.   
(3) The key drivers of ER exhibited time-lag effects, and by maintaining DBN-identified spatial composition variables within critical thresholds, future land use layouts can increase the probability of ER enhancement.

These findings contribute to advancing the theoretical understanding of cross-scale ER assessment and its driving mechanisms. They also provide spatially explicit guidance for conservation-oriented land use planning. The proposed framework, which integrates dynamic assessment with spatial optimization, can be applied to other metropolitan areas to support ecological conservation and sustainable landscape management under increasing environmental pressures.

Supplementary Materials: The following supporting information can be downloaded at: https: //www.mdpi.com/article/10.3390/rs17243941/s1, Figure S1: Spatial distribution of long-time series meteorological and vegetation data; Figure S2: Spatial distribution of long-time series socioeconomic and natural data; Figure S3: Indicator selection and calculation of ecosystem services; Figure S4: Calculation of resilience assessment indicators for complex networks; Figure S5: ER frequency distribution from 2000 to 2020; Figure S6: ROC curves of the three states of ER; Figure S7: Dynamic Bayesian network model; Figure S8: Bayesian model sensitivity analysis. Table S1: The mean runoff coefficient value of LULC; Table S2: The sensitivity of habitat types to each threat factor; Table S3: Habitat suitability and sensitivity of habitat types to each threat factor; Table S4: Weighting of recreation services; Table S5: Classification criterion of influence factors and sensibility in WMA; Table S6: Resistance factor; Table S7: Table of ecosystem service value of different land use types; Table S8: Landscape pattern index; Table S9: Status of the nodes; Table S10: Neighborhood weight; Table S11: The setting of the cost matrix for land type conversion in natural scenarios; Table S12: The setting of the land type conversion cost matrix in the forest land growth scenario; Table S13: Model verification confusion matrix; Table S14: Critical path strength with node annotation. References [9,27,36,45,68,69,100–115] are cited in the Supplementary Materials.

Author Contributions: Conceptualization, A.T., Y.Z. and Z.L.; methodology, A.T. and J.Z.; software, A.T., J.Z. and Z.L.; writing—original draft preparation, A.T. and J.Z.; writing—review and editing, A.T. and Y.Z.; visualization, A.T. and J.Z.; supervision, Y.Z. All authors have read and agreed to the published version of the manuscript.

Funding: This research is supported by National Key Research and Development Program of China (No. 2023YFB3906703) and National Natural Science Foundation of China (No. 72474164, 72174158).

Data Availability Statement: Publicly available datasets were analyzed in this study. The data sources and access links are indicated in the text.

Conflicts of Interest: The authors declare that they have no known competing financial interests or personal relationships that could appear to have influenced the work reported in this paper.

# Abbreviations

The following abbreviations are used in this manuscript:

ER Ecological Resilience

EN Ecological Network

ES Ecosystem Service

DBN Dynamic Bayesian Network

GA Genetic Algorithm

PLUS Patch-Generating Land Use Simulation

BNs Bayesian Networks

WMA Wuhan Metropolitan Area

LEAS Land Expansion Analysis Strategy

CARS Multitype Random Patch Seed Cellular Automata Model

EM Expectation-Maximization Algorithm

CPTs Conditional Probability Tables

BIC Bayesian Information Criterion

NDVI Normalized Difference Vegetation Index

NPP Net Primary Production

DEM Digital Elevation Model

GDP Gross national Product

