# Tightening ecological management facilitates green development in the Qilian Mountains

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:51:31.287743+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Li et al. - 2019 - Tightening ecological management facilitates green development in the Qilian Mountains.pdf
- Year: 2019
- DOI: 10.1360/TB-2019-0209
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This paper analyzes how stricter ecological management in the Qilian Mountains of northwestern China affects ecosystems, water resources, regional economies, and broader ecological benefits, with explicit attention to telecoupling.

The study is situated in a key ecological barrier region that supplies water to six inland river basins and lies along the Silk Road Economic Belt. It uses a large integrated expedition combining satellite remote sensing, drone surveys, extensive field work, glacier and permafrost measurements, ecosystem sampling, and socioeconomic and online questionnaire surveys across China.

On the biophysical side, the authors document overall ecological improvement under a warmer and wetter climate: forest upper treelines have moved upslope and shrubs have expanded; grasslands are largely stable with modest net area gains; major lakes have generally enlarged. Populations and habitat of rare species such as snow leopard are recovering, aided by reduced human disturbance. However, local overgrazing in the central-eastern Qilian causes grassland degradation, and groundwater overuse shrinks some internal lakes.

Glaciers have lost substantial area and volume over the last half-century, with accelerated loss since 2007. Model results suggest glacier meltwater contributions to river flow will soon pass a tipping point, after which runoff will decline. Permafrost is also degrading; estimated ground-ice melt over the last decade releases water comparable to about one-tenth of the annual river discharge, but is expected to diminish as permafrost disappears within several decades.

On the human side, severe restrictions on mining, hydropower, and other damaging activities sharply reduced local environmental pressures but caused short-term drops in industrial output. Using InVEST and environmental-economic accounting, the team values local gains in ecosystem services and pollution reduction. To capture telecoupled benefits, they estimate nationwide willingness to pay for Qilian ecosystem protection, yielding a national-level ecosystem service value far exceeding local economic losses.

The paper is directly about telecoupling: it quantifies how ecosystem services generated in Qilian create large external benefits for distant populations and argues for enhanced national ecological compensation to support green, livelihood-compatible development in this critical source region.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via ecosystem services from Qilian Mountains to downstream China and Silk Road regions

### Intracoupling
#### Systems
- Qilian Mountains ecosystems and protected areas
- Local pastoral and mining based economies
- Headwaters of six inland river basins
#### Flows
- Water from glaciers and permafrost to local rivers
- Local land use and pollution changes
- Ecosystem services within regional socioecological system
#### Agents
- Local governments and park administration
- Pastoralists farmers miners tourism operators
- Chinese research institutes and expeditions
#### Causes
- Tightened ecological regulations and enforcement since 2016
- Historical overgrazing mining hydropower expansion
- Climate warming and increasing precipitation
#### Effects
- Improved local vegetation and rare species recovery
- Short term regional economic losses and livelihood risks
- Reduced local pollution and enhanced ecosystem services

### Pericoupling
#### Systems
- Qilian Mountains and downstream Hexi Corridor oases
- Qilian headwaters and neighboring inland basins
- Qilian region and adjacent provincial economies
#### Flows
- River runoff and groundwater affecting downstream agriculture
- Ecological compensation and fiscal transfers within China
- Regional tourism and transport along the corridor
#### Agents
- Provincial and municipal governments
- Downstream farmers herders industries
- Regional water and park management agencies
#### Causes
- Water scarcity and desertification control needs
- Reforms in national park and protection systems
- Adjustment of regional industrial and land structures
#### Effects
- Altered water availability for downstream users
- Regional industrial slowdown then partial recovery
- Greater demand for intra regional ecological compensation

### Telecoupling
#### Systems
- Qilian Mountains as national ecological barrier
- Rest of China benefiting from ecosystem services
- Silk Road Economic Belt countries and corridors
#### Flows
- Telecoupled ecosystem services valued by national residents
- Monetary willingness to pay for Qilian protection
- Knowledge and models for transboundary basin governance
#### Agents
- National government and central reform bodies
- Chinese residents providing potential payments
- International actors in Silk Road green development
#### Causes
- National ecological security and desertification prevention goals
- Silk Road infrastructure and green development initiatives
- Recognition of large national scale ecosystem service value
#### Effects
- Huge national scale ecosystem service valuation far exceeding local GDP
- Policy proposals for increased national ecological compensation
- Qilian experience used as template for other Silk Road basins

### Cross-Coupling Interactions
- Local restrictions on mining grazing and hydropower trade off with distant ecosystem benefits
- National payments proposed to offset local economic losses from providing telecoupled services
- Climate driven glacier permafrost change reshapes water flows affecting local regional and distant users

### Research Gaps or Limitations
- Ecosystem service valuation relies on stated willingness to pay with inherent uncertainties
- Permafrost meltwater contributions to runoff remain partially constrained by subsurface factors
- Long term socioeconomic impacts on vulnerable households require further monitoring

### Search Keywords
- Qilian Mountains telecoupling ecosystem services
- glacier permafrost water resources Hexi Corridor
- ecological compensation green development China

### Extraction Confidence
high
