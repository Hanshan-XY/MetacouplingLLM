# Multi-scale telecoupling effects of land use change on ecosystem services in urban agglomerations –A

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:55:40.095241+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Liu et al. - 2023 - Multi-scale telecoupling effects of land use change on ecosystem services in urban agglomerations –A.pdf
- Year: unknown
- DOI: 10.1016/j.jclepro.2023.137878
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
The study examines how land use and land cover change (LUCC) affects ecosystem services (ES) within and across urban agglomerations, using a telecoupling perspective and multiple spatial scales. The case is the Middle Reaches of the Yangtze River Urban Agglomerations (MRYRUA) in central China, covering three metropolitan areas: Wuhan (growth type), Chang-Zhu-Tan / C-Z-T (semi-growth), and Poyang Lake (cultivating).

Within the broader metacoupling/telecoupling framework, the paper explicitly focuses on telecoupled interactions: how LUCC in one city or county influences ES in other, often distant, parts of the urban agglomeration through flows of people, capital, policies, and environmental processes.

Land use data from 1990 to 2020 (30 m resolution) and biophysical datasets (DEM, soils, climate, etc.) are combined in the InVEST model to quantify four regulating/supporting ES: carbon storage, soil conservation, water purification (via N and P export), and habitat quality. These are aggregated into a composite ES index. LUCC is captured mainly by a land use intensity index, with a land use diversity index for robustness. To represent telecoupling, the authors build a Spatial Lag of X (SLX) econometric model with gravity-based and economic-distance spatial weight matrices, estimating how local LUCC and remote LUCC (spatially weighted LUCC in other units) affect local ES at county and city scales and by metropolitan level.

Results show modest but widespread intensification of land use, dominated by conversion of cropland, forest, and grassland to construction land, especially in the C-Z-T area. Carbon storage, soil conservation, and habitat quality generally decline or fluctuate downward; water purification improves slightly overall but worsens in highly urbanized corridors. At both county and city scales, higher land use intensity significantly reduces ES, and LUCC in other places also depresses local ES, with the negative telecoupling effect strengthening at larger spatial scales. By metropolitan level, telecoupling from LUCC in the growth-type Wuhan area further harms ES, whereas in semi-growth and cultivating regions, telecoupled LUCC can modestly enhance ES, mainly via siphon effects that slow land conversion in peripheral areas.

The paper is directly about telecoupling/metacoupling and highlights the need to integrate cross-regional LUCC interactions into land use and ecological governance.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling focus; also analyzes intra- and nearby cross-county/city interactions.

### Intracoupling
#### Systems
- Local land use systems within MRYRUA counties and cities
- Metropolitan internal socioecological systems
#### Flows
- Local land use change affecting ecosystem service provision
- Internal material and energy flows within each metropolitan area
#### Agents
- County and city governments within each metropolitan area
- Local enterprises and farmers
#### Causes
- Urbanization and construction land expansion
- Conversion of cropland and forest to built-up land
#### Effects
- Reduced carbon storage and habitat quality
- Fluctuating soil conservation and improved water purification in some areas

### Pericoupling
#### Systems
- Adjacent counties within same city
- Neighboring cities inside the MRYRUA
#### Flows
- Short-distance material, energy and information spillovers
- Spatial spillover of LUCC-driven ecological impacts
#### Agents
- Nearby local governments showing competition and imitation
- Regional planning and infrastructure agencies
#### Causes
- Geographic proximity and shared river basins
- Policy diffusion and local government peer effects
#### Effects
- Spatial clustering of ecosystem service degradation
- Negative ecological externalities in neighboring jurisdictions

### Telecoupling
#### Systems
- Growth, semi-growth, cultivation metropolitan areas within MRYRUA
- Remote yet economically linked cities and counties
#### Flows
- Intercity flows of labor, capital, technology, information
- Remote policy, land development and factor market linkages
#### Agents
- Central and local governments engaged in competition imitation
- Enterprises and farmers adopting external practices
#### Causes
- Economic integration and regional development strategies
- Demonstration, imitation and siphon effects of land policies
#### Effects
- Remote LUCC constrains or enhances local ecosystem services
- Scale dependent negative telecoupling that strengthens with aggregation
- Positive telecoupling via siphon effects in less developed metros

### Cross-Coupling Interactions
- Telecoupled LUCC magnifies or offsets local LUCC impacts on ecosystem services
- Demonstration imitation and siphon processes connect intra, peri and telecouplings

### Research Gaps or Limitations
- Ecosystem service assessment limited to four regulating/supporting services
- Biophysical parameter uncertainty in InVEST modules
- Spatial scope restricted to county city scales and one urban agglomeration

### Search Keywords
- telecoupling land use ecosystem services urban agglomeration Yangtze
- spatial spillover SLX gravity weight LUCC ES
- demonstration imitation siphon effect metropolitan scale coupling

### Extraction Confidence
high
