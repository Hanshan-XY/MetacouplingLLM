# One BioregionOne Health An Integrative Narrative for Transboundary Planning along the US-Mexico Bo

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:02:11.500234+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Pezzoli et al. - 2014 - One BioregionOne Health An Integrative Narrative for Transboundary Planning along the US-Mexico Bo.pdf
- Year: unknown
- DOI: 10.1080/13600826.2014.951316
- OA status: green
- License: none recorded
- Category: Journal Articles\Conceptual\Telecoupling
- Closed-access reason: green OA without permissive license (none)

## Copyright-Safe Summary
This conceptual paper develops the One Bioregion-One Health (OBROH) narrative as a framework for transboundary planning along the US-Mexico border, with a particular focus on the California-Baja California region. The authors respond to global stresses such as climate change, disease emergence, and environmental degradation by arguing for bioregional, place-based approaches that integrate urban planning, public health, and ecosystem restoration.

Geographically, the work centers on several cross-border watersheds and city-regions, including the Tijuana River Watershed, the New River and Salton Sea system, and other US-Mexico sister cities. The system context is one of tightly linked human settlements and ecosystems where pollution, disease vectors, and water flows ignore the political boundary.

Methodologically, the article is primarily theoretical and descriptive. It assembles literature on healthy city planning, One Health, environmental epidemiology, and bioregionalism, then illustrates concepts through case examples: watershed-based collaborations, binational surveillance initiatives (e.g., Early Warning Infectious Disease Surveillance and One Border/One Health), community-engaged research in Tijuana canyons, and binational training programs for health professionals and students.

The main contribution is to merge bioregional thinking with the One Health paradigm, framing health as an outcome of human-animal-environment interactions across a shared bioregion rather than within separate national jurisdictions. OBROH emphasizes integrated watershed management, cross-sector and cross-border governance, civically engaged universities, leadership development, and justice-oriented notions of access to ecosystem services. In a forward-looking section, the authors explicitly link OBROH to environmental epidemiology, telecoupling, and a proposed concept of bioregional justice.

The discussion of telecoupling is conceptual but explicit: it highlights distant socio-economic and environmental interactions, stresses that border-region health cannot be understood without considering extra-local flows of contaminants, organisms, and resources, and suggests telecoupling as a useful lens for multi-scale policy and research. Overall, the paper is directly relevant to telecoupling/metacoupling as it connects local bioregional planning along the border to global flows, cross-scale linkages, and distant drivers of health and environmental change.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong focus on transboundary intra- and peri-coupling; conceptually extends to global telecoupling.

### Intracoupling
#### Systems
- Urban neighborhoods and canyons within Tijuana River Watershed
- Communities along New River and Salton Sea
- Local health, water, and ecosystem systems in San Diego and Tijuana
#### Flows
- Local sewage, stormwater, and solid waste into nearby waterways and estuaries
- Spread of contaminants and disease vectors within watersheds
- Local knowledge, surveillance data, and community engagement within each side
#### Agents
- Local residents and community leaders in colonias and canyons
- Municipal health and environmental agencies
- Local NGOs, universities, and health professionals
#### Causes
- Unplanned urbanisation and inadequate infrastructure in canyon settlements
- Agricultural and industrial pollution discharges
- Poverty, weak local governance, and fragmented planning
#### Effects
- Heightened local exposure to toxicants and infectious diseases
- Degraded urban ecosystems and reduced resilience
- Local health inequities and environmental injustice

### Pericoupling
#### Systems
- US–Mexico transfrontier city-regions like San Diego–Tijuana
- Mexicali–Calexico and shared Mexicali–Imperial Valley
- Binational Tijuana River and New River watersheds
#### Flows
- South-to-north water, sediment, sewage, and pollutants across the border
- Cross-border spread of vectors, zoonotic and drug-resistant diseases
- Binational data, training, and surveillance information exchanges
#### Agents
- US and Mexican federal, state, and local health authorities
- Binational networks like One Border One Health and Border Health Consortium
- Good Neighbor Environmental Board and USGS watershed initiative
#### Causes
- Shared watersheds spanning the international border
- Intense cross-border mobility, trade, and daily commuting
- Asymmetric regulations, infrastructure, and institutional capacities
#### Effects
- Transboundary disease risks and beach closures on US side
- Joint ecological restoration and watershed management initiatives
- Demand for harmonised protocols, health diplomacy, and joint governance

### Telecoupling
#### Systems
- US–Mexico border bioregion linked to global disease and trade networks
- Global One Health and Global Health governance systems
- International academic and funding networks supporting border research
#### Flows
- International travel, migration, and trade spreading pathogens and contaminants
- Global funding, research agendas, and training programs influencing border initiatives
- Diffusion of One Health, bioregionalism, and telecoupling concepts
#### Agents
- WHO, NSF, NIH, and international scientific societies
- Global One Health and environmental epidemiology communities
- Cross-regional surveillance networks like HAIRS and EpiSouth
#### Causes
- Globalisation of health risks, climate change, and economic integration
- Emergence of novel infectious diseases and bioterrorism concerns
- Global policy shifts toward integrated ecosystem and health governance
#### Effects
- Border region used as case study for global One Health practice
- Adoption of watershed-based, bioregional planning influenced by global science
- Need to manage distant drivers through telecoupling-informed policies

### Cross-Coupling Interactions
- Telecoupled disease and trade dynamics reshape peri-coupled border health planning
- Local ecological restoration interacts with regional watershed governance and global funding agendas
- Binational training and diplomacy embed global One Health norms into local practice

### Research Gaps or Limitations
- Scarcity of robust epidemiological studies linking contaminants like New River pollution to health outcomes
- Difficulty integrating multi-scale data and bridging epistemic, analytical, and socio-economic gaps
- Limited institutionalised mechanisms for sustained binational data sharing and joint decision-making

### Search Keywords
- One Bioregion One Health US Mexico border watershed telecoupling
- Tijuana River New River ecological restoration environmental epidemiology
- One Border One Health binational surveillance leadership training

### Extraction Confidence
high
