# The impacts of warfare and armed conflict on land systems

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:28:28.717565+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Baumann and Kuemmerle - 2016 - The impacts of warfare and armed conflict on land systems.pdf
- Year: unknown
- DOI: 10.1080/1747423X.2016.1241317
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper examines how warfare and armed conflict act as abrupt shocks to land systems worldwide and how they reshape land use and land cover. It has global scope, focusing mainly on Asia, Africa, the Middle East, and to a lesser extent the Americas and Europe.

The authors combine two main components. First, they overlay a high-resolution global conflict event dataset from the Uppsala Conflict Data Program (1989-2014) with maps of anthropogenic biomes and land systems. Second, they conduct a systematic review of 38 spatially explicit case studies that link armed conflict to land-use or land-cover change, drawing largely on remote sensing and some statistical data.

Spatial analysis shows that conflict is highly concentrated in densely populated and intensively used systems. Urban areas and village landscapes, though occupying a small share of global land, host a disproportionately large share of conflict events. Extensive croplands also experience elevated conflict frequency, whereas wildlands, forests, and remote rangelands are comparatively less affected than their area would suggest.

The case studies reveal that conflict influences land systems in diverse, context-dependent ways rather than pushing change in a single direction. Common outcomes include agricultural abandonment where people are killed, conscripted, displaced, or deterred by mines and violence; forest loss from military operations, illegal logging, and mining; and, in some instances, forest recovery or reduced commercial use where insecurity deters exploitation. Post-conflict periods can bring recultivation and renewed expansion of agriculture or logging, often mediated by institutional change and investment flows.

The paper explicitly engages with the telecoupling/metacoupling perspective. It shows that conflict often creates long-distance linkages: displaced people establish agriculture and settlements elsewhere; refugee and remittance flows alter resource use in both origin and destination areas; and trade sanctions or market disruptions shift logging, mining, and agricultural production between regions. These dynamics couple nearby and distant land systems, with impacts that can be immediate yet persist for decades, making armed conflict an important but under-studied driver of metacoupled land-system change.

## Structured Metacoupling Extraction

### Coupling Classification
- Paper treats warfare impacts on land as local shocks that can create telecoupled land-system linkages.

### Intracoupling
#### Systems
- Conflict zones in dense settlements and village landscapes
- Cropland, rangeland, and forest land systems within war-affected countries
- Protected areas and mining or logging frontiers inside conflict regions
#### Flows
- Local displacement of farmers and rural residents within conflict regions
- Changes in local extraction of timber, fuelwood, and minerals
- Altered local agricultural production, abandonment, and recultivation
#### Agents
- National armies, rebel groups, militias, and paramilitaries
- Local farmers, herders, loggers, and miners
- Government agencies, local authorities, and conservation managers
#### Causes
- Armed conflict outbreaks as abrupt socio-political shocks
- Weak governance, corruption, and reduced law enforcement during conflict
- Insecurity, violence, and landmine contamination restricting land use
#### Effects
- Agricultural abandonment near frontlines and unsafe areas
- Forest loss from combat, illegal logging, and conflict-financed resource extraction
- Forest recovery and reduced commercial use where access becomes too risky

### Pericoupling
#### Systems
- Rural areas neighboring cities under siege or bombardment
- Host communities adjacent to refugee or IDP camps
- Border regions between belligerent states or internal fronts
#### Flows
- Short-distance refugee and IDP movements into nearby safer zones
- Expansion of smallholder farming and fuelwood collection around camps
- Spillover of illegal logging and small-scale mining into neighboring districts
#### Agents
- Internally displaced households and nearby host communities
- Local traders, middlemen, and small entrepreneurs
- Border security forces and local administrations
#### Causes
- Proximity to conflict lines driving near-field displacement
- Local demand for food, shelter, and energy in receiving areas
- Security vacuums spreading from core conflict zones
#### Effects
- Increased land-use intensity around settlements hosting displaced people
- New or expanded villages and peri-urban areas near conflict frontiers
- Local deforestation and land degradation surrounding large camps

### Telecoupling
#### Systems
- Conflict-affected regions such as Caucasus, Congo Basin, Middle East
- Distant agricultural frontiers or resettlement zones within same country
- International trade partners and sanctioning states
#### Flows
- Refugee migration to distant regions and countries
- Teleconnected trade in timber, minerals, and agricultural commodities
- Capital flows, sanctions, and changing foreign investment patterns
#### Agents
- Refugees, diasporas, and remittance senders
- International traders, investors, and corporations
- Foreign governments, NGOs, and international organizations
#### Causes
- Conflict-driven refugee crises creating distant resettlement and farming
- Trade embargoes and sanctions altering export markets
- Shifts in foreign investment away from insecure resource sectors
#### Effects
- Agricultural expansion in distant safe regions receiving displaced farmers
- Reduced or increased logging and mining tied to international demand changes
- Reorganization of national and regional food and timber supply chains

### Cross-Coupling Interactions
- Refugee flows connect conflict zones, nearby hosts, and distant farming frontiers.
- Trade sanctions couple war-torn producers with alternative international suppliers.
- Remittances and diaspora links feed back to land-use decisions in origin regions.

### Research Gaps or Limitations
- Few quantitative studies directly link georeferenced conflict data with land-use change globally.
- Limited coverage for conflict-prone regions like India, Pakistan, Southeast Asia, and parts of Africa.
- Telecoupling mechanisms, time-lagged legacies, and regime shifts in land systems remain poorly quantified.

### Search Keywords
- armed conflict land-use change telecoupling refugees deforestation agricultural abandonment
- urban warfare settlement systems anthromes remote sensing conflict databases
- resource extraction illegal logging mining sanctions trade land-system shocks

### Extraction Confidence
high
