# Local and tele-coupling development between carbon emission and ecologic environment quality

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:27:16.631897+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: An et al. - 2023 - Local and tele-coupling development between carbon emission and ecologic environment quality.pdf
- Year: unknown
- DOI: 10.1016/j.jclepro.2023.136409
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines how carbon emissions and ecological environmental quality evolve together, both within and between regions, in China’s Yangtze River Economic Belt (YREB) from 2000 to 2019. The YREB is a major national growth corridor with intense energy use and serious environmental pressures.

The authors construct a regional carbon emissions dataset by linking statistical energy consumption (nine major fuels, IPCC factors) with long-term, corrected nighttime light imagery, allowing emissions to be mapped at fine spatial resolution. Ecological environmental quality is assessed with an enhanced remote sensing ecological index (RSEInew). This index extends the classic four-component RSEI (greenness, moisture, dryness, surface temperature) by adding a PM2.5-related indicator derived from MODIS data, so that air pollution is explicitly included. Principal component analysis is used to combine the five standardized indicators.

To investigate system interactions, the study applies the Local and Telecoupling Coordination Degree (LTCCD) model, which extends traditional coupling-coordination analysis by incorporating both local (within-province) and telecoupled (distance-weighted inter-provincial) interactions between carbon emissions and ecological quality.

Results show that total carbon emissions in the YREB increased more than fivefold and have not peaked; eastern coastal provinces such as Jiangsu and Zhejiang are major emitters with substantial mitigation potential. Overall ecological quality declined slightly, with most areas remaining in medium or good condition, but heavily industrialized northeastern parts of the belt experienced pronounced degradation. The upgraded RSEInew highlights worse conditions in areas with high PM2.5.

The LTCCD analysis suggests that most provinces have reached at least basic coordination between emissions and ecological quality, and that telecoupling tends to narrow regional disparities and better reveal cross-boundary interactions. Provinces with strong economies or high-quality ecosystems can influence neighboring regions through emission spillovers and ecological buffering.

The paper explicitly uses the telecoupling/metacoupling framework, demonstrating how near- and long-distance interactions between carbon emissions and ecological quality shape regional sustainability and providing a basis for coordinated emission reduction and environmental protection policies.

## Structured Metacoupling Extraction

### Coupling Classification
- Focuses on both local coupling and telecoupling between carbon emissions and ecological environment quality

### Intracoupling
#### Systems
- Carbon emission system within Yangtze River Economic Belt provinces
- Ecological environment quality system of regional land areas
#### Flows
- Intra-provincial carbon emissions from energy consumption
- Local impacts of PM2.5 and other pollutants on ecosystems
- Feedback of vegetation carbon uptake on local emissions
#### Agents
- Provincial and municipal governments in the Yangtze River Economic Belt
- Energy intensive industries and manufacturing sectors
- Local residents driving urbanization and energy demand
#### Causes
- Rapid regional economic growth and industrialization
- Rising energy consumption and fossil fuel use
- Urban expansion replacing vegetation with construction land
#### Effects
- Degradation or stagnation of local ecological environment quality
- High carbon emission hotspots around major cities
- Local coordination or imbalance between emissions and environment

### Pericoupling
#### Systems
- Neighboring provinces within the Yangtze River Economic Belt
- Adjacent urban agglomerations and economic zones
#### Flows
- Short distance atmospheric pollution and PM2.5 spillover
- Regional diffusion of carbon emissions between nearby provinces
- Shared infrastructure and industrial chains across borders
#### Agents
- Regional development zones spanning multiple provinces
- Interprovincial regulatory and planning bodies
- Enterprises operating across neighboring provinces
#### Causes
- Clustered industrial development along the Yangtze River
- Coordinated regional development strategies and policies
- Spatial agglomeration of cities in economic belts
#### Effects
- Spatial clustering of similar ecological environment levels
- Peri-regional convergence in coupling coordination degree
- Stronger coordination in integrated subregions like Chengdu Chongqing

### Telecoupling
#### Systems
- Upstream, midstream, downstream subsystems of Yangtze River Economic Belt
- High emission coastal provinces and inland ecological provinces
#### Flows
- Long distance atmospheric transport of emissions affecting remote EEQ
- Telecoupled interactions of capital, resources, population, information
- Policy and technology spillovers improving distant coordination
#### Agents
- National government shaping western development and delta integration
- Yangtze River Delta city cluster as telecoupling hub
- Less developed ecological provinces influencing neighbors via carbon sinks
#### Causes
- National strategies like western development and river economic belt
- Integrated regional planning and economic networks
- Cross regional energy and resource trade patterns
#### Effects
- Remote influence of high EEQ provinces on surrounding coordination
- Enhanced coupling coordination where telecoupling is strong
- Reduced coordination where external influence is weak or negative

### Cross-Coupling Interactions
- LTCCD model combines local CCD with distance weighted telecoupling between provinces
- Telecoupling can raise coordination in some provinces and lower it in others
- Regional integration reduces disparities in CE EEQ coordination over time

### Research Gaps or Limitations
- Previous studies rarely analyzed joint local and telecoupled CE EEQ coordination
- Traditional RSEI ignored air quality thus underrepresenting urban ecological conditions
- Study does not quantitatively decompose drivers of CE EEQ coupling patterns

### Search Keywords
- local and telecoupling carbon emissions ecological environment Yangtze River Economic Belt
- LTCCD model remote sensing ecological index PM2.5
- coupling coordination carbon emission EEQ regional integration

### Extraction Confidence
high
