# Mahi-mahi metacouplings quantifying human-nature interactions in dolphinfish (Coryphaena hippurus)

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:30:32.124097+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Carlson - 2025 - Mahi-mahi metacouplings quantifying human-nature interactions in dolphinfish (Coryphaena hippurus).pdf
- Year: unknown
- DOI: 10.1017/sus.2025.3
- OA status: gold
- License: cc-by-nc-nd
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This study applies the metacoupling framework to quantify and interpret human-nature interactions in global dolphinfish (Coryphaena hippurus) fisheries from 1950 to 2019, and to project future dynamics to 2035. The work is explicitly about metacoupling and telecoupling, using dolphinfish as a case to demonstrate multiscalar linkages.

The geographic scope is worldwide, focusing on 19 exclusive economic zones (EEZs) plus the high seas, chosen because they host substantial catches from at least three fishing sectors. The system context is marine social-ecological systems in which dolphinfish support industrial, artisanal, recreational, and subsistence fisheries.

Catches (including legal, illegal, and reconstructed unreported catch) were taken from the Sea Around Us database, which integrates FAO and other sources across 280 EEZs. The author interprets total catch as metacouplings and partitions it into intracouplings (within a nations own EEZ), pericouplings (adjacent EEZs), and telecouplings (distant EEZs or high seas). Time series for six fishing types were modeled with ARIMA, including cross-sector regressors to estimate interactions among sectors and to forecast catches by EEZ and sector for 2020-2035.

Globally, total dolphinfish catch shows a long swing: growth to the late 1990s, a brief drop, another increase to about 2012, followed by decline, aligning with independent evidence of falling abundance and body size in parts of the range. Intracouplings dominate overall, but about one-tenth of catch involves pericoupled or telecoupled fishing, and high-seas telecouplings are substantial.

Artisanal fishing is the leading sector in over half of focal EEZs, while industrial fleets account for roughly half of global metacouplings, with recreational and subsistence shares smaller but locally important. Common interaction patterns include mutual reinforcement between industrial and artisanal sectors, and in some EEZs, negative effects of industrial fishing from neighboring EEZs on local artisanal catch. Projections suggest increasing artisanal and small-scale industrial catches in many EEZs, stable telecoupled catches, and worrying declines in subsistence catches in several places, raising equity and nutrition concerns. The paper argues that metacoupling-informed management can better account for these cross-scale linkages and tradeoffs.

## Structured Metacoupling Extraction

### Coupling Classification
- Strongly metacoupled fishery with dominant intracoupling and notable peri and telecouplings
- Applies full metacoupling framework across 19 national EEZs plus high seas

### Intracoupling
#### Systems
- National EEZ dolphinfish systems such as China, Pakistan, USA coasts
- Island EEZ dolphinfish systems such as Niue, Wallis and Futuna
- Within-EEZ social ecological systems of dolphinfish and fishing sectors
#### Flows
- Dolphinfish catches within a nations own EEZ over 1950 2019
- Sectoral harvest flows among industrial, artisanal, subsistence, recreational fleets
- Nutritional and economic benefits from locally caught dolphinfish
#### Agents
- Industrial fleets operating inside home EEZ
- Artisanal, recreational, and subsistence fishers in each EEZ
- National fisheries agencies and domestic policymakers
#### Causes
- Fishing demand for food, income, sport, and culture
- National management rules, gear and season regulations
- Environmental variability such as ocean warming and productivity shifts
#### Effects
- Up and down long term trends in intracoupled dolphinfish catches
- Documented declines in abundance and body size in some regions
- Changes in livelihoods, nutrition, and angler satisfaction

### Pericoupling
#### Systems
- Neighboring EEZ pairs such as China and adjacent Asian EEZs
- Regional dolphinfish systems in Mediterranean and Caribbean basins
- Donor recipient EEZs where nearby nations fish each others waters
#### Flows
- Industrial catches taken by neighboring countries in adjacent EEZs
- Pericoupled flows especially around China, Mexico, Philippines, Libya
- Cross border movement of fishing effort affecting local artisanal sectors
#### Agents
- Pericoupled industrial fleets from nearby nations
- Artisanal fishers in donor EEZs impacted by neighbors
- Regional fisheries managers coordinating or conflicting policies
#### Causes
- Proximity of productive dolphinfish grounds across EEZ boundaries
- Asymmetric or misaligned fishing regulations between neighbors
- Economic incentives for industrial fleets to expand regionally
#### Effects
- Negative impacts of pericoupled industrial fleets on artisanal catches in some EEZs
- Moderate share of total metacouplings but locally important conflicts
- Projected declines in some pericoupled industrial catches

### Telecoupling
#### Systems
- High seas dolphinfish system beyond national jurisdiction
- Distant water connections linking island EEZs to large fishing nations
- Global dolphinfish trade and consumption network
#### Flows
- Telecoupled industrial catches in distant EEZs and high seas
- High seas harvests dominated by nations like Venezuela and USA
- Historically large telecoupling peak followed by decline after late 1980s
#### Agents
- Distant water industrial fleets (e.g., Taiwan, Japan, USA, France)
- International regional fishery organizations and treaties
- Global seafood markets influencing remote fishing effort
#### Causes
- Search for profitable offshore dolphinfish stocks
- Limited governance and ownership in high seas areas
- Technological advances enabling long range fishing fleets
#### Effects
- Around one tenth of global dolphinfish catches from distant systems
- Telecouplings contributing to stock declines and smaller fish sizes
- Stakeholder concerns about international pressures on local fisheries

### Cross-Coupling Interactions
- Bidirectional positive links between intracoupled industrial and artisanal sectors in many EEZs
- Negative impacts of distant or neighboring industrial fishing on local artisanal sectors in some EEZs
- Positive links where artisanal or recreational fishing supports subsistence or other sectors

### Research Gaps or Limitations
- Ecological and stock assessment data for dolphinfish remain limited in many regions
- Sea Around Us reconstructed catch data introduce uncertainty despite reducing underreporting bias
- Human livelihood, cultural, and nutritional outcomes of metacouplings are only partially quantified

### Search Keywords
- dolphinfish Coryphaena hippurus metacoupling EEZ telecoupling pericoupling
- artisanal industrial recreational subsistence fisheries ARIMA projections
- Sea Around Us reconstructed catch high seas distant water fleets

### Extraction Confidence
high
