# Migration as a feature of land system transitions

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:02:52.063199+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Radel et al. - 2019 - Migration as a feature of land system transitions.pdf
- Year: unknown
- DOI: 10.1016/j.cosust.2019.05.007
- OA status: closed
- License: none recorded
- Category: Journal Articles\Review\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This review examines how human migration is intertwined with land system transitions, with a primary focus on Latin America. It argues that movements of people, money, and ideas are integral components of changing rural and urban landscapes, both where migrants leave and where they arrive.

The authors synthesize three main research domains. First, they review how environmental and land-use change influence out-migration. Studies show that land degradation, climate variability, land grabbing, and shifts toward large-scale or mechanized agriculture can push people to move, but rarely as a single cause. Structural inequalities in land tenure, markets, and governance shape how land and climate pressures translate into mobility, immobility, or local adaptation.

Second, the paper assesses migration impacts on migrant-sending regions. Out-migration interacts with labor loss, remittances, and local institutions to reshape agriculture, forest cover, land tenure, and rural livelihoods. Evidence on forest transitions is mixed: in some places out-migration and reduced farming support forest regrowth, while in others remittances finance agricultural expansion or intensification. Overall, migration effects are highly context-specific and often modest, mediated by market opportunities, infrastructure, tenure regimes, and social organizations.

Third, the review considers migration impacts on destination areas. Earlier work emphasized smallholder colonization of forest frontiers and associated deforestation; more recent dynamics include urban expansion and the displacement of small farmers by export-oriented agribusiness. The authors also point to amenity migration by wealthier groups and its potential to convert working landscapes into conservation or leisure spaces, though empirical work in Latin America remains limited.

The paper explicitly engages telecoupling and metacoupling. It highlights how migration creates cross-scale linkages between sending and receiving land systems through remittances, multi-sited households, and translocal social networks. These connections mean land-use change in one place is often co-produced with changes elsewhere. The authors argue that land system science needs more explicit attention to migration-driven telecouplings, displacement processes, and inclusive institutions to manage increasingly complex, multi-user landscapes.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling focus linking migrant origins and destinations via people, capital, ideas
- Includes intracoupling within rural land systems undergoing agrarian and demographic transitions
- Pericoupling present through regional rural urban and frontier linkages in Latin America

### Intracoupling
#### Systems
- Latin American rural agrarian landscapes with smallholders and changing tenure
- Urbanizing regions linked to nearby rural hinterlands
- Closed or closing agricultural frontiers within single countries
#### Flows
- Household labor shifts between farm and nonfarm work
- Local circulation of remittances and savings
- Knowledge exchange on farming, conservation, adaptation
#### Agents
- Small-scale farming families and multi-sited households
- Local institutions managing land, water, and forests
- Amenity migrants reshaping nearby rural localities
#### Causes
- Agrarian liberalization and market integration within countries
- Land degradation and local climate variability
- Structural land inequality and landholding reconcentration
#### Effects
- Mixed trends of forest loss and regrowth in sending areas
- Persistence of semi-subsistence agriculture via subsistence migration
- Emergence of new rurality with diversified livelihoods

### Pericoupling
#### Systems
- Neighboring rural regions linked by short-distance labor migration
- Rural areas and regional secondary cities
- Border regions exchanging seasonal agricultural workers
#### Flows
- Temporary and circular regional labor movements
- Remittances and small-scale capital across nearby regions
- Commodity flows from frontier expansion to regional markets
#### Agents
- Regional labor migrants and seasonal workers
- Agro-industrial firms expanding soy, cattle, flex crops
- Regional cooperatives and producer networks
#### Causes
- Expansion of mechanized agriculture and flex crops displacing labor
- Regional commodity booms and busts
- Policy incentives opening or closing nearby frontiers
#### Effects
- Displacement of peasants to adjacent regions and cities
- Regional forest degradation from in-migration to frontiers
- Changing regional land tenure through migrant land purchases

### Telecoupling
#### Systems
- Latin American migrant-sending rural communities and distant foreign cities
- Amenity destinations in tropical countryside and wealthy Global North origins
- Global agricultural commodity frontiers and distant consumer markets
#### Flows
- International labor migration and return migration
- Large remittance transfers shaping land investment
- Ideas, identities, and environmental values circulating transnationally
#### Agents
- International migrants and transnational households
- Transnational agribusiness and land investors
- States and global climate or conservation initiatives
#### Causes
- Globalization of commodity markets and macroeconomic shocks
- Income and wellbeing inequalities between countries
- Climate change driving adaptation and displacement programs
#### Effects
- Migration-driven forest transitions and new conservation regimes
- Telecoupled remittance landscapes altering labor regimes and land values
- Amenity migration transforming land from production to recreation

### Cross-Coupling Interactions
- Migration creates telecoupled links while simultaneously reshaping local land labor dynamics
- Land grabs and climate projects displace people, triggering new regional and international flows
- Urbanization, frontier closure, and migration jointly reconfigure multi-scalar land systems

### Research Gaps or Limitations
- Limited empirical work directly framing migration as telecoupling in land system science
- Poor understanding of links between land degradation, not just climate, and migration
- Sparse evidence on amenity and return migration impacts on land systems

### Search Keywords
- migration telecoupling Latin America land system transitions
- remittances forest transition subsistence migration
- agrarian change amenity migration land grabbing

### Extraction Confidence
high
