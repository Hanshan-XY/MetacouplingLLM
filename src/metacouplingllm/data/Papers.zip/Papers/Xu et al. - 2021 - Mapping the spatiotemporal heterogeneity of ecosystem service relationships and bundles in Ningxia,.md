# Mapping the spatiotemporal heterogeneity of ecosystem service relationships and bundles in Ningxia,

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:13:37.293973+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Xu et al. - 2021 - Mapping the spatiotemporal heterogeneity of ecosystem service relationships and bundles in Ningxia,.pdf
- Year: unknown
- DOI: 10.1016/j.jclepro.2021.126216
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines how multiple ecosystem services interact over space and time in Ningxia, an ecologically fragile, arid to semi-arid region in northwestern China. The work is not framed explicitly as a telecoupling or metacoupling case, but it does reference an increasingly metacoupled world and provides subregional evidence on internally coupled socioecological processes that could inform metacoupling analyses.

The authors evaluate eight land-based ecosystem services: four provisioning services (agricultural products, water supply, hay, livestock products) and four regulating services (wind erosion control, water conservation, soil retention, carbon sequestration). Services are mapped on 30 m grids for 2000, 2005, 2010, and 2015 using established biophysical models (InVEST, CASA, erosion equations) and statistical yearbook data. Spearman rank correlations are calculated at grid, county, and regional scales to reveal tradeoffs and synergies among services and with ecological (climate, radiation, vegetation) and socioeconomic (GDP, population) drivers. K-means clustering of county-level service values identifies ecosystem service bundles.

Spatial patterns show strong north-south contrasts: most services peak in the wetter southern mountains, while wind erosion control is highest in the central arid belt and agricultural production concentrates in the irrigated north along the Yellow River. Over 2000-2015, crop and hay production rise, whereas most regulating services decline. Agricultural production tends to be negatively related to other services across scales, indicating competition with grassland- and forest-based functions and water availability. In contrast, most other service pairs are positively associated, especially grassland-based provisioning (hay, livestock) with regulating services and with water-related functions.

Three persistent bundles emerge: a Northern Agricultural bundle dominated by intensive farming and strong links to economic indicators; a Central Arid Sandstorm Prevention bundle focused on wind erosion control under harsh conditions; and a Southern Mountainous High Provision-Regulation Synergy bundle where multiple provisioning and regulating services co-occur at high levels. These bundles mirror ecological gradients and policy interventions, offering spatially explicit guidance for differentiated ecosystem and land-use management that balances production and regulation functions within an internally coupled regional system.

## Structured Metacoupling Extraction

### Coupling Classification
- Primarily intracoupling within Ningxia, with some pericoupling to surrounding deserts and Yellow River basin

### Intracoupling
#### Systems
- Northern irrigation agricultural zone of Ningxia
- Central arid sandstorm control zone
- Southern mountainous ecological conservation zone
#### Flows
- Ecosystem services among counties within Ningxia
- Water and sediment dynamics within Yellow River segment in Ningxia
- Policy driven land use and grazing changes across Ningxia
#### Agents
- County and regional governments of Ningxia
- Farmers and livestock herders in Ningxia
- National agencies implementing ecological projects
#### Causes
- Climatic gradients in precipitation and temperature from south to north
- Agricultural expansion and intensive irrigation in northern plain
- Ecological restoration projects and grazing bans
#### Effects
- Spatial tradeoffs between crop production and regulating services
- Synergies among grassland services and regulation in southern mountains
- Formation of three distinct ecosystem service bundles

### Pericoupling
#### Systems
- Ningxia and adjacent deserts forming dust source sink relations
- Ningxia and downstream Yellow River regions relying on water regulation
- Ningxia and surrounding Loess Plateau ecological corridor
#### Flows
- Windborne sand and dust affecting nearby regions
- Riverine water flow and water conservation services to downstream
- Propagation of regional shelterbelt and sand fixation benefits
#### Agents
- Central government managing Three North Shelterbelt
- Regional water resource managers in Yellow River basin
- Neighboring provincial authorities coordinating desertification control
#### Causes
- Location in transition between humid and arid regions
- Role as ecological security barrier for northwestern China
- National ecological construction and regional development plans
#### Effects
- Reduced sandstorms benefiting neighboring areas
- Influence of Ningxia water regulation on basin level security
- Regional scale coupling between agriculture and desert control

### Telecoupling
#### Systems
- Not identified.
#### Flows
- Not identified.
#### Agents
- Not identified.
#### Causes
- Not identified.
#### Effects
- Not identified.

### Cross-Coupling Interactions
- Tradeoffs in northern agriculture may weaken regional sandstorm protection services
- Grassland restoration enhances both local livelihoods and downwind dust mitigation
- Economic growth phases altered links between ecosystem services and regional development

### Research Gaps or Limitations
- Ecosystem service bundles analyzed only on supply side, demand patterns not mapped
- Drivers of temporal changes and inconsistencies among services not fully disentangled
- Interaction effects of multiple socioecological drivers not dynamically modeled

### Search Keywords
- Ningxia ecosystem service bundles tradeoffs synergies
- spatiotemporal heterogeneity socioecological drivers China
- wind erosion prevention water conservation agricultural production

### Extraction Confidence
high
