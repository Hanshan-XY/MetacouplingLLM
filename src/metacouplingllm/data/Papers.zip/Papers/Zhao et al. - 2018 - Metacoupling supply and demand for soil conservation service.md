# Metacoupling supply and demand for soil conservation service

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:19:53.317366+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Zhao et al. - 2018 - Metacoupling supply and demand for soil conservation service.pdf
- Year: unknown
- DOI: 10.1016/j.cosust.2018.05.011
- OA status: closed
- License: none recorded
- Category: Journal Articles\Conceptual\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This conceptual review develops a metacoupling perspective on soil conservation as an ecosystem service, emphasizing that most previous work has measured only biophysical supply and largely ignored human demand and feedbacks. The geographic discussion is global, with illustrative emphasis on Chinas Loess Plateau, and is framed within coupled human-nature systems and cross-regional linkages.

The authors propose a three-part assessment framework: first, quantify potential and actual soil conservation service supply; second, assess and map social demand; third, compare supply and demand and design policies to narrow gaps. They suggest redefining soil conservation supply using the difference between a maximum tolerable erosion rate and the observed erosion rate, rather than using bare soil as a baseline. This approach ties soil regulation more explicitly to long-term soil productivity and human needs.

Demand is linked to societal targets such as the UN Sustainable Development Goals, focusing on food security, water quality, and land conservation. Beneficiaries include local farmers, downstream reservoir operators, and coastal and global actors affected by sediment and carbon fluxes.

Using Liu s metacoupling framework, the paper interprets soil conservation flows across scales: intracoupling within an upstream watershed (on-site soil and productivity benefits), pericoupling to adjacent downstream reaches (water quality and reservoir lifespan), and telecoupling to distant systems (land-ocean sediment transfer and global carbon cycling). Soil conservation is treated as a one-directional service moving along erosion-transport-deposition pathways.

The authors also advance a disturbance effect transmutation hypothesis, illustrated with the Grain for Green program on the Loess Plateau. Large-scale restoration improves soil conservation and carbon sequestration locally but can create soil desiccation and water shortages, and alter downstream hydrology and wetlands. They argue for multi-scale tradeoff analysis between soil conservation and other ecosystem services to avoid unintended negative outcomes.

The paper is explicitly about metacoupling/telecoupling, offering a generalizable conceptual framework rather than new empirical data.

## Structured Metacoupling Extraction

### Coupling Classification
- Paper explicitly applies metacoupling to soil conservation, covering intra, peri, and telecouplings.

### Intracoupling
#### Systems
- Upstream farming landscapes as coupled human nature systems
- Local Loess Plateau restoration socio ecological system
- On site agricultural fields and nearby communities
#### Flows
- Local soil retention and reduced on site erosion
- Soil fertility and crop productivity benefits
- Local water regulation and sediment trapping
#### Agents
- Local farmers managing cropland and vegetation
- Ecosystem managers implementing restoration projects
- Local governments setting soil conservation targets
#### Causes
- Land use and vegetation cover changes affecting erosion
- Implementation of Grain for Green restoration policies
- Local pursuit of food security and soil fertility
#### Effects
- Improved soil conservation and carbon fixation locally
- Emergence of dried soil layers and local water shortage
- Changes in ecosystem service bundles and tradeoffs

### Pericoupling
#### Systems
- Upstream service providing catchments
- Midstream river reaches with reservoirs and cities
- Adjacent agroecosystems within same basin
#### Flows
- Sediment and water moving from upstream to midstream
- Soil conservation benefits for reservoir lifespan
- Propagation of water shortage to nearby regions
#### Agents
- Reservoir operators and hydropower managers
- Downstream and midstream water users
- Regional environmental and water agencies
#### Causes
- Upstream vegetation restoration reducing runoff and sediment
- Regional soil loss tolerance thresholds and standards
- Policies targeting sediment control and clean water
#### Effects
- Extended reservoir operation but altered inflow regimes
- Midstream water scarcity linked to upstream restoration
- Degradation risks for downstream wetlands and riparian habitats

### Telecoupling
#### Systems
- Upstream erosive basins like Loess Plateau
- Downstream delta and coastal ocean systems
- Global climate and carbon cycle system
#### Flows
- Land ocean sediment transfer altered by conservation
- Export and burial of soil carbon in distant sinks
- Teleconnected impacts on global carbon budget
#### Agents
- National planners pursuing Sustainable Development Goals
- International climate and development organizations
- Global food and environmental security stakeholders
#### Causes
- Large scale restoration and conservation programs
- Human accelerated erosion and subsequent control measures
- Global goals for zero hunger, clean water, life on land
#### Effects
- Changes in global carbon exchange due to erosion control
- Impacts on downstream and marine ecosystems far from source
- Cross scale feedbacks between soil conservation and climate

### Cross-Coupling Interactions
- Upstream restoration simultaneously improves local soil retention and reduces sediment for distant coastal systems
- Local water shortages from restoration propagate to regional rivers and wetlands
- Soil conservation decisions driven by global SDGs reshape local and regional service flows

### Research Gaps or Limitations
- Beneficiaries and benefiting areas of soil conservation often not explicitly identified or quantified
- Limited integration of biophysical service supply with socio economic demand and feedbacks
- Need better methods to determine soil loss tolerance for diverse regions and scales

### Search Keywords
- metacoupling soil conservation ecosystem services
- soil loss tolerance T value erosion control
- Loess Plateau Grain for Green sediment water tradeoffs

### Extraction Confidence
high
