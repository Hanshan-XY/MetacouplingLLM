# Identifying agents of change for sustainable land governance

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:27:29.684491+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Andriamihaja et al. - 2021 - Identifying agents of change for sustainable land governance.pdf
- Year: unknown
- DOI: 10.1016/j.landusepol.2020.104882
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This paper examines how to identify and empower actors who can drive transitions toward sustainable land governance in a strongly telecoupled setting. The study focuses on two landscapes in northeastern Madagascar (Maroantsetra District), where global conservation agendas and international cash crop markets for vanilla and cloves shape local land use, intensifying competition between farming and forest protection.

The authors develop and apply a conceptual and methodological framework that combines agency analysis with social network analysis. Agency is operationalized through actors aims (social, economic, environmental) and their access to different resource types (natural, human, physical, financial). The network dimension is captured through measures of degree centrality and bridging roles across governance levels (village to international) and sectors (public, private, voluntary). Data were collected from 2016 to 2019 using focus groups, an actor survey, and secondary sources, yielding detailed information for 62 organizations.

Analysis proceeds in three steps: coding and quantifying aims; classifying actors by resource portfolios; and mapping relational profiles in the land governance network. A principal component analysis then explores how aims, resources, and network positions co-occur, and a typology of actor types and potential agents of change is derived.

The study finds no actor who simultaneously combines mixed sustainability-oriented aims, strong resource access, and a central bridging position. Economic actors (notably district-level cash-crop collectors) tend to hold both substantial resources and influential network roles, but focus narrowly on income generation. Conservation and development organizations often have sustainability-related aims and resources, but weaker integration into cross-level, cross-sector networks.

Although the paper is grounded in telecoupling, it does not use the full metacoupling framework. Its primary contribution to telecoupling research is empirical: it demonstrates how distant conservation and commodity-market actors shape local land governance, and proposes a systematic way to identify and connect complementary actors so that potential change agents can be transformed into effective ones via value learning, resource sharing, and network-building.

## Structured Metacoupling Extraction

### Coupling Classification
- Explicitly analyzes telecoupled land governance; also covers local network dynamics and multi-level linkages.

### Intracoupling
#### Systems
- Village-level social-ecological systems in Morafeno and Mahalevona municipalities, northeastern Madagascar.
- Local land governance networks combining conservation and smallholder cash crop production.
- Community organizations, local authorities, farmers, and intermediaries managing land and resources.
#### Flows
- Local exchanges of goods, money, and information among farmers, intermediaries, and village institutions.
- Interactions within village governance over land, forests, and cash crops.
- Knowledge and influence flows within local associations and traditional authorities.
#### Agents
- Smallholder farmers producing vanilla, cloves, and subsistence crops.
- Local cash crop intermediaries and collectors operating in villages.
- Village-level public authorities and community-based resource management groups.
#### Causes
- Need to secure livelihoods through cash crops and subsistence farming.
- Local implementation of conservation rules and protected area management.
- Existing social structures and village-level governance institutions.
#### Effects
- Land competition between agriculture and conservation within villages.
- Local conflicts regarding deforestation, inequality, and environmental justice.
- Differential empowerment of local actors based on resources and network position.

### Pericoupling
#### Systems
- Village and district-level land governance systems in Maroantsetra District.
- District and regional administrations interacting with village communities.
- Protected areas and surrounding agricultural landscapes within the region.
#### Flows
- District-level regulation, enforcement, and support affecting village land use.
- Commodity flows from villages to district collectors and regional traders.
- Information and funding between regional conservation projects and local implementers.
#### Agents
- District forestry departments and other government offices.
- District-level cash crop collectors and traders.
- Regional NGO branches coordinating conservation activities.
#### Causes
- Administrative mandates to control forests, land, and agricultural exports.
- Regional development and conservation agendas shaping land use priorities.
- Market organization requiring aggregation of products at district level.
#### Effects
- Reinforced land competition and deforestation linked to cash crops.
- Unequal influence of district and regional actors over local resources.
- Formation of cross-level coalitions and governance gaps.

### Telecoupling
#### Systems
- Northeastern Madagascar land systems producing vanilla, cloves, and hosting tropical forests.
- International conservation regimes and NGOs implementing global biodiversity agendas.
- Global agricultural commodity markets and international financial institutions.
#### Flows
- Exports of vanilla, cloves, and other products to global markets.
- Inflows of conservation funding, projects, and international NGO interventions.
- Transnational information, norms, and policies around SDGs and sustainability.
#### Agents
- International NGOs managing protected areas and conservation programs.
- Global buyers, importers, and commodity chains for vanilla and cloves.
- Multilateral organizations and donors such as development banks and UN-related bodies.
#### Causes
- Global demand for high-value cash crops driving land revaluation.
- International conservation targets motivating forest protection projects.
- Telecoupled sustainability agendas framed around SDGs and climate, biodiversity goals.
#### Effects
- Displacement and leakage of land uses, shifting deforestation pressures.
- Heightened inequality and environmental justice concerns for local communities.
- Unsustainable production practices and waste management challenges linked to global markets.

### Cross-Coupling Interactions
- Telecoupled commodity and conservation demands intensify local land competition and intralocal conflicts.
- District and national intermediaries mediate flows between global markets and village producers.
- Multi-level actor networks link distant institutions to local land decisions via goods, money, and information.

### Research Gaps or Limitations
- Incomplete actor coverage due to unsurveyed or unresponsive organizations across levels.
- Subjectivity in coding actors aims; limited intercoder validation.
- Network measures constrained by level clustering; some centrality metrics underutilized.

### Search Keywords
- telecoupled land governance Madagascar agents of change social network analysis
- vanilla clove global commodity chains conservation NGOs Maroantsetra
- sustainability transformation agency analysis multi-level land governance

### Extraction Confidence
high
