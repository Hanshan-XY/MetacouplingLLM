# China_s Environment on a Metacoupled Planet

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:54:40.233610+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Liu et al. - 2018 - China_s Environment on a Metacoupled Planet.pdf
- Year: unknown
- DOI: 10.1146/annurev-environ-
- OA status: unknown
- License: none recorded
- Category: Journal Articles\Review\Metacoupling
- Closed-access reason: no license info, oa_status=unknown

## Copyright-Safe Summary
This review synthesizes recent research on major environmental issues in China using the metacoupling framework, which examines human-nature interactions within China, between China and neighboring countries, and with distant nations. It covers air quality, biodiversity, climate change, and water quantity and quality, as well as China’s growing role in global sustainability governance.

Geographically, the focal system is China, but the paper repeatedly links domestic dynamics to cross-border trade, investment, pollution transport, species migration, and resource flows. System context is national-scale environmental change under four decades of rapid economic growth, urbanization, and dietary and consumption shifts.

The article is a narrative review drawing on diverse datasets and studies (e.g., national monitoring networks, remote sensing, economic and health statistics, life cycle and input-output analyses, and policy documents). It does not present new primary data; instead it integrates existing empirical findings.

Key findings include: severe but recently improving air and water quality; persistent water scarcity; ongoing biodiversity loss despite large protected area and restoration programs; and China’s central role in global greenhouse gas emissions, balanced by substantial but smaller carbon sequestration in expanding forests and other ecosystems. The paper emphasizes that many impacts are displaced through domestic and international trade: heavily polluting production is often located in poorer interior provinces, while wealthier coastal and foreign consumers benefit; virtual water and embedded emissions move through supply chains; and Chinese imports of timber, food, and other commodities shift environmental burdens abroad.

The review is explicitly about metacoupling/telecoupling. It applies these concepts to show how flows of goods, capital, people, organisms, information, and pollutants connect China with adjacent and distant systems, generating feedbacks and spillovers. It argues that environmental governance must move from fragmented, place-based measures toward nexus approaches (e.g., water-food-energy-climate) and flow-centered governance that explicitly manages cross-scale, cross-border linkages.

## Structured Metacoupling Extraction

### Coupling Classification
- Highly relevant to intra, peri, and telecoupling via metacoupled China focused on air, water, biodiversity, climate.

### Intracoupling
#### Systems
- National socioecological system of China as focal country
- Urban industrial regions versus interior rural provinces
- Key ecosystems such as forests, grasslands, wetlands, rivers, coasts
#### Flows
- Domestic trade of goods embodying pollution, carbon, and virtual water
- Physical transfers of water via major interbasin diversion projects
- Movements of species, people, capital, and information inside China
#### Agents
- Central and local governments and environmental ministries
- Farmers, industries, utilities, and urban households
- Scientific community, NGOs, protected area managers
#### Causes
- Rapid economic growth, urbanization, dietary shifts, population increase
- Coal based energy, motorization, industrial structure, low resource efficiency
- Land use change, overextraction, pollution from agriculture and factories
#### Effects
- Mixed trends in air, water, biodiversity, and ecosystem services
- Health impacts, premature deaths, economic losses, resource conflicts
- Forest recovery, increased carbon sequestration, but ongoing habitat loss

### Pericoupling
#### Systems
- China and neighboring Asian countries such as India, Japan, Korea
- Transboundary river basins and regional seas around China
- Regional trade and investment networks in East and Southeast Asia
#### Flows
- Cross border air pollutants and dust affecting nearby countries
- Regional trade in fossil fuels, food, timber, and manufactured goods
- Species invasions and wildlife migrations across shared borders
#### Agents
- Neighboring national governments and regional organizations
- Cross border traders, investors, and logistics companies
- Transboundary river and marine management bodies
#### Causes
- Regional economic integration and supply chains
- Shared atmospheric and hydrological systems
- Regional demand for energy, food, and raw materials
#### Effects
- Downwind and downstream pollution impacts in adjacent countries
- Shifts in regional land use, forests, and biodiversity patterns
- Shared climate mitigation responsibilities and regional diplomacy

### Telecoupling
#### Systems
- China and distant partners such as United States, Brazil, European Union
- Global commodity production regions like Brazilian Cerrado
- Worldwide conservation and climate governance systems
#### Flows
- International trade of food, timber, fossil fuels, manufactured products
- Foreign direct investment and China overseas direct investment
- Panda loans, tourism, knowledge and technology transfer
#### Agents
- Multinational firms, investors, and supply chain intermediaries
- International organizations and treaty bodies
- Zoos, conservation agencies, research institutions abroad
#### Causes
- China demand for commodities and export driven manufacturing
- Comparative advantages and global market forces
- International agreements like WTO, Paris Agreement, Aichi Targets
#### Effects
- Embodied emissions, pollution, and resource use redistributed globally
- Forest loss or gain and agricultural expansion in partner countries
- Symbolic diplomacy and conservation awareness through panda loans

### Cross-Coupling Interactions
- Metacoupling framework links intra, peri, and telecouplings around air, biodiversity, climate, and water nexus
- Domestic conservation and import substitution shift environmental burdens abroad and among provinces
- Trade, FDI, and virtual water create feedbacks between Chinese policies and global sustainability goals

### Research Gaps or Limitations
- Need rigorous long term evaluation of large national environmental programs and policy mixes
- Insufficient attention to spillover, rebound, and feedback effects across sectors and regions
- Limited integration of nexus and metacoupling approaches into operational governance and modeling

### Search Keywords
- China metacoupling telecoupling intracoupling pericoupling
- air biodiversity climate water nexus China
- virtual water embodied emissions trade FDI panda loans

### Extraction Confidence
high
