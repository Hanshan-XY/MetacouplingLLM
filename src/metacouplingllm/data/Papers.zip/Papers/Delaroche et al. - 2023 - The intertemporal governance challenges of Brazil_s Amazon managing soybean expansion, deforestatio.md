# The intertemporal governance challenges of Brazil_s Amazon managing soybean expansion, deforestatio

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:40:36.690249+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Delaroche et al. - 2023 - The intertemporal governance challenges of Brazil_s Amazon managing soybean expansion, deforestatio.pdf
- Year: unknown
- DOI: 10.1007/s11625-022-01149-4
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This article examines how three governance challenges in the Brazilian Amazon have become tightly interlinked over time: agrarian expansion, forest protection, and urban flood management. The geographic focus is on Mato Grosso and Pará states, with detailed attention to the municipality of Paragominas in eastern Pará. The broader system context is the telecoupled soybean trade between Brazil and China/Europe and associated deforestation policies.

The authors combine three analytical approaches: Networks of Adjacent Action Situations (NAS), the Combined IAD-SES framework, and the telecoupling framework. They use mixed methods: multi-site fieldwork (over two years in total), more than 250 semi-structured interviews with farmers, officials, NGOs, and residents, ethnographic observation of policy processes, and land-use change analysis based on satellite data.

Empirically, they trace how anti-deforestation measures (federal command-and-control programs and the Soy Moratorium) successfully reduced direct forest clearing for soy in the Amazon biome, but also pushed soybean expansion onto existing pasture. Around Paragominas, this led to large soybean monocultures concentrated on sloping pasturelands close to rivers, while flatter plateau forests were left standing. This land-use configuration increased runoff, soil erosion, and river siltation, interacting with dams, urban growth, and climate variability to intensify flood risks in Paragominas.

The paper shows that local authorities have limited options to relocate or redesign soy production because of past land clearing patterns, legal forest conservation requirements, and market rules tied to the Soy Moratorium. At the same time, earlier experience with federal blacklisting for deforestation pushed Paragominas to innovate through multi-stakeholder environmental governance; this institutional memory now shapes emerging collective responses to flooding, including new municipal flood committees.

The study is explicitly about telecoupling and, more broadly, metacoupling. It demonstrates how distant commodity demand and cross-scale governance arrangements create cascading, intertemporal linkages between rural land-use decisions and urban flood governance, highlighting that urban climate risks cannot be addressed in isolation from regional land and trade governance.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via China Brazil soybean trade; intra regional links create peri and intra couplings

### Intracoupling
#### Systems
- Urban Paragominas socio ecological system with flood risk and land use change
- Agricultural frontier in Paragominas municipality combining soybean, pasture, forests
#### Flows
- Runoff and sediment from soybean fields and pastures into local rivers and canals
- Local information flows among municipal government, farmers, NGOs, lawyers
#### Agents
- Paragominas city government, local prosecutors, legal aid lawyers, civil society groups
- Local farmers, cattle ranchers, environmental consultants and producer unions
#### Causes
- Historical cattle ranching near waterways followed by soybean expansion on former pastures
- Unplanned urban expansion, small dams and river degradation increasing flood exposure
#### Effects
- Increased urban flood frequency and severity in Paragominas
- Creation of municipal flood crisis committee and emergency management plans

### Pericoupling
#### Systems
- Rural Pará agricultural landscapes supplying soybean and cattle
- Mato Grosso soybean regions influencing neighboring Pará frontier
#### Flows
- Farmer migration and investment from Mato Grosso into Pará soybean areas
- Road, river, rail logistics linking inland farms to Amazon export ports
#### Agents
- Regional farmers, ranchers, trader companies active in both states
- State level environmental agencies and municipal governments
#### Causes
- Regional infrastructure expansion reducing transport costs to river ports
- Pasture clearing in Pará enabling later soybean conversion
#### Effects
- Pasture to soybean conversion concentrating near waterways
- Regional changes in water regimes affecting downstream municipalities

### Telecoupling
#### Systems
- Brazilian Amazon and Cerrado as sending soybean systems
- China and Europe as distant soybean receiving systems
#### Flows
- International soybean commodity trade from Brazil to China and Europe
- Environmental governance information flows via NGOs and multinational traders
#### Agents
- Multinational traders, banks, exporters associations, environmental NGOs
- Brazilian federal ministries, IBAMA, INPE satellite monitoring agency
#### Causes
- Rising global soybean demand driving land investment and expansion
- International pressure over deforestation prompting Soy Moratorium and PPCDAm
#### Effects
- Soy Moratorium shifting expansion from forests to already cleared pastures
- Cascading land use and hydrological effects increasing flood risk in Paragominas

### Cross-Coupling Interactions
- Telecoupled soybean demand triggers regional land conversion that alters local hydrology and urban floods
- Soy Moratorium governance constrains local land use options for flood mitigation near rivers
- Policy learning on deforestation control in Mato Grosso transferred to Paragominas flood governance

### Research Gaps or Limitations
- Limited subnational water governance data compared to land use governance detail
- NAS based SES analysis does not fully cover all sending, receiving, spillover systems

### Search Keywords
- Paragominas floods soybean telecoupling governance
- Soy moratorium Mato Grosso Para NAS CIS

### Extraction Confidence
high
