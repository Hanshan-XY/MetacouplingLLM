# Mapping geography_s engagement with the Sustainable Development Goals Research foci, contributions,

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:01:09.515774+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Ni et al. - 2025 - Mapping geography_s engagement with the Sustainable Development Goals Research foci, contributions,.pdf
- Year: unknown
- DOI: 10.1016/j.geosus.2025.100376
- OA status: gold
- License: none recorded
- Category: Journal Articles\Review\Metacoupling
- Closed-access reason: no license info, oa_status=gold

## Copyright-Safe Summary
This review examines how the academic discipline of geography has engaged with the United Nations Sustainable Development Goals (SDGs) and related sustainability debates since 2010. Its geographic scope is global, but it pays particular attention to the uneven distribution of research and collaboration between Global North and Global South. The work is set in the broader context of the SDG framework and the 2030 Agenda, with special interest in how geography, as a field linking social and biophysical systems, contributes to monitoring, understanding, and implementing the goals.

Using Web of Science data for 122 core geography journals (2010-2024), the authors apply a three-level search strategy based on SDG terms, sustainability keywords, and an SDG indicator word list. They compile over 70,000 articles and use bibliometric methods, including collaboration and co-citation networks and keyword co-occurrence clustering, to reveal publication trends, intellectual foundations, thematic clusters, and SDG overlaps.

Six major research themes emerge: climate change impacts and governance; agricultural landscapes and environmental sustainability; resilience and adaptive capacity in social-ecological systems; land use change and metacoupling impacts; urban growth and transport accessibility; and biodiversity and ecosystem services. The explicit metacoupling focus (flows and feedbacks across distant human-environment systems) sits mainly within the land-use and trade-related cluster, linking geographically separated causes and impacts. The analysis shows strong cross-referencing among environmental SDGs (11, 13, 14, 15), while SDG 1 (No Poverty) and SDG 10 (Reduced Inequalities) are comparatively isolated in geography journals.

The authors argue that geography advances the SDGs in four ways: spatial analysis for assessment; regional studies to localize goals; human-environment research to reveal synergies and trade-offs; and contributions to science-policy interfaces. They also highlight imbalanced international collaboration dominated by China, the US, and the UK, and call for future work on integrated human-physical approaches, post-2030 agenda-setting, and careful use of AI. Telecoupling and metacoupling are therefore central to one of the six themes but not the exclusive focus of the paper.

## Structured Metacoupling Extraction

### Coupling Classification
- Primarily intracoupling within regional socio-ecological systems and telecoupling via land use and trade flows.

### Intracoupling
#### Systems
- Regional social-ecological systems within cities, agricultural landscapes, and protected areas.
- National land systems linking urban growth, biodiversity, and ecosystem services.
- Local communities interacting with nearby ecosystems for livelihoods and risk management.
#### Flows
- Local land use change altering biodiversity, ecosystem services, and carbon storage.
- Intra-urban mobility and accessibility affecting services, emissions, and social equity.
- Local policy, information, and governance decisions shaping environmental management.
#### Agents
- Local governments, planners, and regulatory agencies within a country or city.
- Farmers, landowners, urban residents, and vulnerable community groups.
- Researchers, NGOs, and knowledge brokers operating mainly within regions.
#### Causes
- Urbanisation, agricultural intensification, and conservation policies reshaping local land use.
- Structural inequalities in access to infrastructure, services, and environmental benefits.
- Context-specific governance choices, institutional capacity, and planning paradigms.
#### Effects
- Spatially uneven vulnerability, exposure to climate risks, and disaster impacts.
- Trade-offs between food production, biodiversity conservation, and ecosystem services.
- Changes in local resilience, social equity, and SDG progress within regions.

### Pericoupling
#### Systems
- Neighbouring urban and rural regions connected by commuting and resource sharing.
- Adjacent countries linked through regional collaboration networks in geography.
- Border landscapes where land, water, and species cross administrative boundaries.
#### Flows
- Cross-boundary commuting, transport, and service accessibility between nearby settlements.
- Regional knowledge, data, and technology sharing among neighbouring countries.
- Short-distance ecological flows such as species movement and watershed processes.
#### Agents
- Regional organisations, cross-border planning bodies, and city networks.
- Neighbouring national research institutions collaborating on SDG topics.
- Transboundary conservation managers and basin authorities.
#### Causes
- Regional integration policies and shared environmental challenges across borders.
- Need to coordinate transport, climate adaptation, and land management regionally.
- Research funding and programmes encouraging regional SDG collaboration.
#### Effects
- Core-periphery collaboration patterns within regions, often favouring stronger economies.
- Shared ecological risks and cumulative impacts across neighbouring territories.
- Opportunities for joint SDG localisation and harmonised indicator systems.

### Telecoupling
#### Systems
- Distant producer landscapes and consumer regions linked via global supply chains.
- Global North and Global South knowledge systems connected through SDG research.
- Remote ecosystems affected by international markets, climate policy, and finance.
#### Flows
- International trade in agricultural commodities driving land use change elsewhere.
- Capital, climate finance, and debt instruments influencing SDG implementation.
- Information, publications, and collaboration within global geography networks.
#### Agents
- Multinational firms, certification bodies, and international development organisations.
- Donor governments, multilateral agencies, and global research consortia.
- Commodity traders and financial actors shaping distant land decisions.
#### Causes
- Global demand for food, biofuels, and raw materials reallocating land abroad.
- International climate and biodiversity agreements steering national policies.
- Asymmetric power relations between Global North and South in SDG governance.
#### Effects
- Deforestation, biodiversity loss, and emissions in exporter regions serving distant markets.
- Displacement of environmental pressures via leakage and outsourced production.
- Inequitable benefits and burdens of SDG-related global initiatives.

### Cross-Coupling Interactions
- Metacoupling framework connects intracoupling in land systems with pericoupling and telecoupling via trade and policy.
- Urban consumption regions telecouple to distant agricultural frontiers, altering local socio-ecological resilience.
- Global research collaborations influence local SDG assessment and localisation, reinforcing core-periphery dynamics.

### Research Gaps or Limitations
- Limited integration of poverty and inequality goals with environmental SDGs in metacoupling analyses.
- Underrepresentation of non-English and non-geography-journal SDG research and local knowledge.
- Need for deeper causal modelling of distant driver pathways and governance within metacoupling.

### Search Keywords
- metacoupling land use telecoupling geography SDGs trade-offs
- telecoupling agricultural commodities deforestation SDG 12 SDG 15
- spatial resilience human-environment interactions geography SDG assessment

### Extraction Confidence
high
