# Spatial variation and influencing factors of the effectiveness of afforestation in China_s Loess Pla

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:11:22.111193+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Wu et al. - 2021 - Spatial variation and influencing factors of the effectiveness of afforestation in China_s Loess Pla.pdf
- Year: unknown
- DOI: 10.1016/j.scitotenv.2020.144904
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study evaluates how effectively large-scale afforestation under Chinas Grain-to-Green Program (GTGP) has improved vegetation conditions across the Loess Plateau and why results vary from place to place. The Loess Plateau is a semi-arid, erosion-prone region in north-central China where GTGP has converted extensive cropland and barren land to forest and grassland as part of a national payment for ecosystem services (PES) strategy.

The authors work at the county level, which matches the main implementation unit of GTGP. They use MODIS NDVI time series (2000-2015) to track vegetation change and official statistics on annual afforestation area, climate, and socioeconomic indicators. For each county, they regress annual NDVI on lagged cumulative afforestation degree, precipitation, and temperature. The regression coefficient linking NDVI to cumulative afforestation is interpreted as afforestation effectiveness, and only counties with significant coefficients and no temporal autocorrelation are retained. They then relate effectiveness to a suite of local and non-local (metacoupled) factors using correlation and multiple regression.

Afforestation contributed significantly to greening in 214 of 319 afforested counties, but the magnitude of effect varied widely. Higher effectiveness occurred in more humid counties with low pre-program vegetation, higher rural non-farm employment, and greater rural out-migration. Effectiveness was lower where cumulative afforestation was already high, initial NDVI was high, grain production intensity was greater, and investment in fixed assets was larger. These patterns suggest biophysical limits (water availability, site suitability) and strong links between ecological outcomes and broader development, labor, and migration dynamics that connect each county to surrounding and distant systems.

The paper explicitly applies the metacoupling framework by distinguishing local drivers from non-local influences such as migration and capital investment. It shows how telecoupled labor flows and regionally or externally driven infrastructure development can enhance or undermine PES outcomes. The proposed framework can be transferred to other PES programs to assess spatially variable effectiveness and to better integrate ecological restoration with cross-scale socioeconomic processes.

## Structured Metacoupling Extraction

### Coupling Classification
- Focuses mainly on intracoupling within Loess Plateau counties; includes some peri and telecoupled drivers.

### Intracoupling
#### Systems
- Loess Plateau counties under Grain-to-Green afforestation program
- County-level social economic systems of rural households
- Local ecosystems experiencing vegetation restoration and soil erosion control
#### Flows
- Financial PES subsidies to farmers for converting cropland to forest or grassland
- Land-use change from cropland and barren land to planted forest and grassland
- Local labor reallocation between farming and non-farm employment
#### Agents
- County governments implementing Grain-to-Green policies
- Rural households deciding land conversion participation
- National agencies funding and supervising PES implementation
#### Causes
- Historic deforestation, soil erosion, floods and droughts triggering restoration policies
- National PES strategy to balance ecosystem conservation and rural development
- Local economic structure, grain dependence and household income needs
#### Effects
- Increased NDVI and vegetation cover across much of the plateau
- Reduced soil erosion and enhanced ecosystem services such as carbon storage
- Spatially variable afforestation effectiveness across counties

### Pericoupling
#### Systems
- Neighboring Loess Plateau counties with different afforestation degrees
- Upstream Loess Plateau and downstream Yellow River areas
- Adjacent rural and nearby urbanizing regions
#### Flows
- Sediment and water flows from plateau to downstream river reaches and deltas
- Rural-to-nearby-urban migration within provinces
- Spillover of agricultural production when grain output declines locally
#### Agents
- Farmers migrating to nearby towns or prefecture cities
- Provincial governments coordinating cross-county GTGP efforts
- Downstream water managers affected by sediment reductions
#### Causes
- Soil erosion in plateau counties degrading downstream river systems
- Infrastructure development and urban expansion around restoration areas
- Economic opportunities in nearby urban centers attracting rural labor
#### Effects
- Improved downstream sediment regulation due to upstream afforestation
- Possible increased land pressure in neighboring agricultural areas
- Urban growth potentially offsetting some local greening benefits

### Telecoupling
#### Systems
- Loess Plateau Grain-to-Green region within China
- Distant Chinese regions importing food or labor
- Global community interested in large-scale PES outcomes
#### Flows
- Rural migrants moving from plateau counties to distant cities
- National financial transfers funding GTGP across provinces
- Knowledge and policy diffusion on PES and restoration internationally
#### Agents
- Central Chinese government designing and financing GTGP
- Urban employers in distant regions hiring migrant workers
- International researchers and organizations tracking PES performance
#### Causes
- National ecological security and disaster prevention priorities
- Demand for urban labor in coastal or distant metropolitan areas
- Global initiatives promoting forest restoration and carbon sequestration
#### Effects
- Reduced local land pressure through out-migration of rural labor
- Potential externalization of food production to other regions
- Loess Plateau case informing PES design in other countries

### Cross-Coupling Interactions
- Local land restoration interacts with regional migration and investment, altering afforestation effectiveness.
- Declining grain production locally may shift agricultural burdens to other regions.
- Infrastructure investment promotes development but can undermine local vegetation gains.

### Research Gaps or Limitations
- Afforestation degree ignores species choice and management differences.
- NDVI cannot separate GTGP forests from other vegetation or programs.
- County-scale analysis omits fine-scale terrain and soil variability.

### Search Keywords
- Loess Plateau Grain-to-Green afforestation NDVI
- payment for ecosystem services metacoupling China
- rural migration nonfarm employment vegetation restoration

### Extraction Confidence
high
