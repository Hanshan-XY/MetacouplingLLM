# Landscapes—a lens for assessing sustainability

Marie C. Dade $\cdot$ Aletta Bonn $\cdot$ Felix Eigenbrod $\bullet$ María R. Felipe‑Lucia $\bullet$ Brendan Fisher · Benjamin Goldstein $\bullet$ Robert A. Holland $\cdot$ Kelly A. Hopping $\bullet$ Sandra Lavorel $\bullet$ Yann le Polain de Waroux · Graham K. MacDonald $\bullet$ Lisa Mandle $\cdot$ Jean Paul Metzger $\cdot$ Unai Pascual $\bullet$ Jesse T. Rieb $\cdot$ Améline Vallet · Geof J. Wells $\cdot$ Carly D. Ziter $\cdot$ Elena M. Bennett $\bullet$ Brian E. Robinson

Received: 21 June 2024 / Accepted: 6 November 2024 / Published online: 22 January 2025 $^ ©$ The Author(s), under exclusive licence to Springer Nature B.V. 2025, Corrected publication 2025

# Abstract

Context There are urgent calls to transition society to more sustainable trajectories, at scales ranging from local to global. Landscape sustainability (LS), or the capacity for landscapes to provide equitable access to ecosystem services essential for human wellbeing for both current and future generations, provides an operational approach to monitor these transitions. However, the complexity of landscapes

complicates how and what to consider when assessing LS.

Objectives To identify important features of landscapes that remain challenging to consider in LS assessments and provide guidance to strengthen future assessments.

Methods We conducted two workshops to identify the complex features of landscapes that remain

M. C. Dade $( \boxtimes )$ School of Agriculture, Food and Ecosystem Sciences, University of Melbourne, Burnley, VIC, Australia e-mail: marie.dade@unimelb.edu.au

M. C. Dade · Y. le Polain de Waroux $\cdot$ G. K. MacDonald · J. T. Rieb $.$ G. J. Wells $.$ B. E. Robinson Department of Geography, McGill University, Montreal, QC, Canada

A. Bonn $\cdot$ M. R. Felipe-Lucia Department of Biodiversity and People, Helmholtz Centre for Environmental Research - UFZ, Leipzig, Germany

A. Bonn Friedrich Schiller University Jena, Institute of Biodiversity, Jena, Germany

A. Bonn $\cdot$ M. R. Felipe-Lucia German Center for Integrative Biodiversity Research (iDiv) Halle-Jena-Leipzig, Leipzig, Germany

F. Eigenbrod $\cdot$ R. A. Holland School of Geography and Environmental Science, University of Southampton, Southampton, UK

M.R.Felipe-Lucia Departamento de Conservación de la Biodiversidad y Restauración de Ecosistemas, CSIC-Instituto Pirenaico de Ecología (IPE, CSIC), Jaca, Huesca, Spain

B.Fisher Rubenstein School of Environment and Natural Resources, University of Vermont, Burlington, VT, USA

B.Fisher Gund Institute for Environment, University of Vermont, Burlington, VT, USA

B. Goldstein School for Environment and Sustainability, University of Michigan, Ann Arbor, MI, USA

B. Goldstein Department of Bioresource Engineering, McGill University, Montreal, QC, Canada

K. A. Hopping Human-Environment Systems, Boise State University, Boise,ID,USA

under-considered in LS assessments, and developed guidelines on how to better incorporate these features. Results We identify open and connected boundaries and diversity of values as landscape features that must be better considered in LS assessments or risk exacerbating ofstage sustainability burdens and power inequalities. We provide guidelines to avoid these pitfalls which emphasize assessing ecosystem service interactions across interconnected landscapes and incorporating local actors’ diverse values.

Conclusions Our guidelines provide a stepping stone for researchers and practitioners to better incorporate landscape complexities into LS assessments to inform landscape-level decisions and actions.

Keywords Nature’s Contributions to People ·

Landscape Management $\cdot$ Social-Ecological

Systems $\cdot$ Sustainability $\cdot$ Telecoupling $\cdot$ Values about Nature

# Introduction

Anthropogenic activities continue to undermine the sustainability of ecosystems, with sustainability referred to as the ability for ecosystems to support the

needs of both present and future generations while maintaining healthy functioning (Kates 2011; IPBES 2019). In 2021 the Kunming Declaration stressed the need for societies to transition to more sustainable trajectories to maintain ecosystem health (CBD 2021). Global agreements, such as the Global Biodiversity Framework, aim to achieve this transition by promoting landscape level management that enhances sustainable ecosystems (Leadley et  al. 2022). Knowing whether these eforts are efective will require monitoring sustainability across landscapes. Thus, many organizations are developing protocols and metrics to monitor changes in sustainability in response to anthropogenic activities (Xu et  al. 2021). However, questions remain around the scope of sustainability assessments, and their ability to assess sustainability at the landscape level.

Landscapes are regarded as an ideal level at which to assess and monitor sustainability eforts (Wiens 2013). Landscapes are a type of place-based, socialecological system where people directly (and indirectly) interact with ecosystems, creating unique land systems that are embedded in cultural identity (Bohnet and Beilin 2015; Wu 2021). Many environmental management actions infuencing sustainability at scales ranging from the local (e.g. property) to the

national and global are implemented at the landscape level (Moallemi et  al. 2020). However, despite the centrality of landscapes in environmental decisionmaking, knowledge gaps about how to assess landscape-level sustainability remain.

An explicit, operationalizable sustainability defnition is required to enable sustainability assessments of landscapes. The concept of sustainability is broad, making it difcult to assess or measure. Sustainability involves simultaneously considering environmental, economic and societal wellbeing (Wu 2013). Therefore, evaluating if management actions afect sustainability of a landscape requires accounting for interactions between anthropogenic actions and environmental conditions at the landscape level (Wu 2013). Ecosystem services (ES), co-produced with anthropogenic assets and realized as wellbeing benefts to people, are a common framing for assessing multiple aspects of such interactions (Fisher et al. 2009; Palomo et al. 2016), and for capturing humannature interactions (Wu 2013). By assessing ES capacity (the potential to deliver ES), demand (the ES desired by communities) and fow (the ES accessible to the communities) within a landscape it is possible to begin to capture environmental, economic and social wellbeing (Villamagna et al. 2013). Thus, the ES framing can be used to explicitly operationalize and evaluate many aspects of sustainability within landscapes.

In order to operationalize landscape sustainability, here we defne landscape sustainability (LS), using Wu’s (2013) defnition, as the capacity for a landscape to consistently provide equitable access to diverse ES essential for supporting the wellbeing of multiple actors, both now and into the future. While the ES concept has been critiqued as a metric of sustainability (de Groot et  al. 2010; Saunders 2020) and other framings for understanding human-nature interactions exist, e.g. Nature’s Contributions to People (Díaz et al. 2018), the concept of ES has begun to permeate policy worlds and thus remains useful for assessing sustainability at the landscape level. ES assessments have been buoyed by extensive development of tools available to measure ES and dis-services (Blanco et  al. 2019), calculate monetary and non-monetary value, and incorporate nature into decision-making by perceiving ecosystems as natural assets (Obst et  al. 2016). For example, Fang et  al. (2015) developed a framework to integrate ES dynamics into LS

assessments, and Potschin and Haines-Young (2013) built a place-based assessment framework focusing on ES drivers within landscapes.

While the integration of ES methods to understand LS has advanced in recent decades, the scope of existing ES assessment approaches remains limited. Most approaches are discipline specific,which creates challenges for harmonizing LS assessments. Furthermore, often ES approaches consider only one (biophysical) dimension of sustainability (e.g., deforestation rates or human appropriation of net primary productivity) or operate at a single scale without considering other places that are impacted (Erb et al. 2009; Wu 2021). While some alternative approaches do consider multiple scales (e.g., telecoupling), they are insufciently integrated into LS assessments (Liu et  al. 2013). Researchers focusing on assessing LS need to develop methods that explicitly integrate the key features that occur across landscapes (e.g., drivers and interactions) meaningfully into LS assessments, and which can also be feasibly implemented by practitioners (Bennett et al., 2021). Such an approach would assist in assessing progress in meeting sustainability targets, including the Global Biodiversity Framework targets.

The authors of this paper participated in two four-day workshops in 2021 to identify challenges and pathways forward for assessing LS to support sustainability targets, such as the Global Biodiversity Framework. All authors have expertise in LS and come from a range of disciplines, including landscape ecology, sustainability science, environmental justice, social-ecological system science, engineering, and land system science, ensuring multiple perspectives were captured. This paper aims to outline the key challenges to assessing LS that were identifed in these workshops, and to provide guidance and future research directions for researchers focused on developing approaches to assess LS. We identifed two core challenging features of landscapes that remain insufciently integrated into LS assessments but are crucial for measuring LS: (1) landscapes’ open boundaries, and (2) the interaction between the diversity of values and institutions (i.e. rules, norms and customs) that structure humannature interactions and the power dynamics that infuence these interactions. We outline how these challenging features afect LS in Fig. 1, and below we discuss these two features, detailing key challenges with real world examples that demonstrate

![](images/4e5d56fd5c4cf7b4ccaee65e057b7e7bbd689351ce1adf6ab71e5e5c55c47334.jpg)  
Fig. 1 Conceptual diagram depicting the links between landscape sustainability (the capacity for landscapes to equitably provide essential ES for both current and future generations) and the challenging landscape features discussed in this paper: landscapes’ openness (red arrows and text), and the interaction of values and institutions (blue arrows and text) with ecological processes. Landscape openness infuences the capacity of a landscape to provide and beneft from ecosystem services (ES)   
because it creates positive and negative fows of ES to and from connected landscapes (see connected landscape 1 and 2) and other scales (red arrows). Diverse Values about nature and institutions both in the landscapes and connected landscapes, are key social-ecological attributes and mechanisms that infuence ES management and thus ES capacity, fow and demand in landscapes. Furthermore, which ES are managed is determined by power relations among actors

the dynamics presented in Fig.  1, and outline how to better account for these features in future LS research.

While these challenges have garnered some attention, they have often been considered in isolation. Further, bringing a landscape-scale lens to these issues is important: landscapes are the intermediate space where actions, decisions, and programs play out on the ground, afecting not just private lands and property, but spilling over and creating positive and negative externalities for society. This perspective paper brings a unique landscape vantage point to integrating material fows and social challenges into ways of thinking about the land and ecosystems we depend on. Such a perspective grounds previous suggestions for assessing landscapes or ES and develops a more operational approach.

# Challenge 1: Landscapes are open and connected

The boundary of a landscape is necessarily arbitrary and fuzzy, refecting various perspectives (Wylie 2011). Regardless, landscapes afect, and are afected by, actions and decisions from social-ecological processes operating in other landscapes and at multiple nested scales (Cumming et al. 2012; Liu et al. 2013). As shown in Fig.  1, these interactions can infuence landscape-level social-ecological outcomes by changing ES capacity, demand and fows to and from other landscapes and scales. Methods for measuring and assessing LS that account for the openness and connectedness of landscapes remain underdeveloped. We summarize these complexities in terms of the nestedness and connectedness of landscapes using an abstract “focal landscape” in relation to impacts on

other distal landscapes (Pascual et al. 2017) to ground our discussion.

# Complexity 1: Scale nestedness

Actions, drivers, and decisions occurring at one scale (e.g., landscape) can infuence sustainability outcomes at larger (e.g., a region made up of multiple landscapes) and smaller (e.g., plot located within a landscape) scales, as shown in Fig.  1 (Cash and Moser 2000; Scholes et  al. 2013). For example, in Lisbon, Portugal, policies geared to increase urban densifcation can improve the LS of the city landscape through increased urban greenspace provision (via land sparing) and decreased motorized transport that enhance ES such as local climate regulation and recreation opportunities (Elliot et  al. 2022). However, the increased population accommodated by urban densifcation could lead to a greater demand for food from other landscapes, and the consequent risk of intensifying agricultural practices with the associated degradation of agroecosystems. Thus, as demonstrated in the red lines in Fig.  1, LS is improving at the urban landscape level, due to the net increase in local climate regulation following urban densifcation, but sustainability is decreasing at the larger regional scale, due to net losses in ES, including climate regulation, within associated agroecosystems due to greenhouse gas emissions from increased intensive agriculture (Elliot et  al. 2022). Assessments that fail to account for cross-scale interactions could mis-calculate the LS impact of management within a focal landscape. It is therefore critical to consider multiple nested scales, and the aggregate (e.g., regional or global) sustainability outcomes when assessing the LS of any given mechanism within a focal landscape.

# Complexity 2: Landscape connectedness

Landscapes are connected through interactions between ES capacity and demand, and material, energy and human fows in ways that afect the LS of both the focal and connected landscapes (Liu et al. 2013). As shown in Fig. 1, ES interactions between a focal landscape and other landscapes (e.g., via trade, species movement, information fows) impact the potential provision of ES in the focal landscape but can externalize the ecological costs to the connected

landscapes providing the ES. For example, marketing strategies across United States (US) urban landscapes has led to increasing demand for avocados, with many urban residents regarding avocadoes as an important provisioning ES (Magrach and Sanz 2020). However, it is often not climatically feasible or proftable to grow avocados in US urban landscapes. Approximately $8 7 \%$ of avocados are imported from the Michoacán region of Mexico to the USA, demonstrating connected landscapes where access to a provisioning ES (food) increases in US landscapes due to ES fows from Michoacán landscapes (Cho et al. 2021). While this reduces pressures on US landscapes due to the reduced water consumption from not cultivating avocadoes, this is ofset by impairing LS in Michoacán, as avocado production is associated with deforestation, and water scarcity, and reduced climate regulation (Cho et  al. 2021). Therefore, US landscapes may have improved their LS by not growing avocados themselves, but it has led to a telecoupled LS burden within Michoacán landscapes. Thus, LS assessments should account for the sustainability impact that the focal landscape has on other landscapes to appreciate potential LS tradeofs between connected landscapes (Pascual et al. 2017).

# Challenge 2: Diverse values and institutions

Assessing LS typically requires choosing which ES to assess, often by identifying which ES are valued by the people inhabiting the landscape (Wu 2021; IPBES 2022). Institutions (the rules, norms, and customs that structure human interactions with nature) and the diversity of values about nature (the importance that people assign to nature) held by diferent actors infuence which ES are used, valued and desired, and by whom, as shown in Fig.  1 (Sutherland et  al. 2023). Institutions do not only regulate behavior given existing values, but also form and legitimize those values, for example embedding into the culture what is the right thing to do (Kinzig et  al. 2013). Failing to account for interactions between ES values and institutions in LS assessments risks defning and assessing LS in ways that only beneft particular, usually more empowered, actors given their values, which can reduce the wellbeing of marginalized groups whose ES values and needs can be obscured, afecting LS (Pascual et al. 2023). Furthermore, the LS defnition

implies considering both environmental sustainability and social justice as inseparable elements, increasing the importance of recognizing and respecting the diversity of knowledge systems, values and worldviews within landscapes (Pascual et al. 2023).

# Complexity 1: Diversity of values

While people value nature in diferent ways, three main justifcations are typically expressed about the importance of nature: the direct and indirect benefts it provides to well-being (instrumental value), nature’s inherent value independent of human experience (intrinsic value), as well as via the meaningful relationships that form between humans and nature (relational values) (Pascual et  al. 2023). These values exist across cultures but are expressed diferently through behavior and practices. While people connected to a landscape typically hold diverse values, this is often not well refected by the institutions that underpin landscape management (Pascual et  al. 2023). For example, within a forested landscape, one group may value the forest for timber, another may value the aesthetic aspects of intact trees, and others may value the forests for spiritual reasons. These values are closely interwoven with diferent knowledge systems and worldviews (e.g. anthropocentric, or ecocentric) which tie to varying perspectives of what LS should look like (Pascual et al. 2023; Sutherland et  al. 2023). The existence of diverse values associated with landscapes can lead to contrasting and irreconcilable perspectives about which landscapes features, including ES, ought to be prioritized for improving LS, as shown in blue in Fig.  1 (Vigliano Relva and Jung 2021). For example, across east African grasslands the invasive woody species Prosopis julifora has transformed the landscapes to scrublands (Linders et al. 2021). This transformation is regarded as either improving LS, or not, depending on which stakeholder values are considered. Charcoal producers prefer the transformed landscape, as it increases charcoal and fuelwood—ES important to their livelihood, while tourists and pastoralists prefer the landscape untransformed, as P. julifora reduces food production, cultural and aesthetic values—ES important to their livelihood (Linders et  al. 2021). Therefore, the interplay among the diversity of values makes it challenging to defne LS for a given landscape, and choose the essential ES to measure. However, even

when decisions must prioritize one set of values over another, LS assessments must consider the variety of values that are and are not included in transparent ways and justify such consideration.

# Complexity 2: Social power dynamics

The values and knowledge of powerful actors with decision-making agency can strongly infuence which ES are deemed valuable or important to measure for LS, as shown in Fig. 1 (Vallet et al. 2020). This can lead to decisions that ignore the values of minority groups for outcomes that favor the wellbeing of powerful actors, potentially leading to environmental injustice (Berbés-Blázquez et  al. 2016). Power is here understood as the capacity to infuence the goals, process, and outcomes of environmental governance (Morrison et  al. 2019). Power asymmetries refer to the uneven distribution of power among actors. For example, the Mariño watershed, Peru, contains agricultural and grassland landscapes that provide many ES important for LS, including tourism, food production and climate regulation, and government agencies have the greatest power over ES management (Vallet et al. 2019). However, farmers and rural populations have negligible management power but are among the greatest users of ES (Vallet et  al. 2019). Therefore, the government could restrict access to ES with the aim of ensuring long term provision of ES for a wider set of people at the expense of local farmers and rural populations. The unequal power dynamics between these groups has implications for whose vision of a sustainable future is enacted. As shown in the blue section of Fig.  1, this could lead to LS assessments orientated towards beneftting the governments’ interests, while farmers, not involved in decision-making, could experience losses in the ES they depend on, or these ES not being considered in LS assessments.

# Considerations for assessing landscape sustainability

Researchers from multiple disciplines have developed approaches to address the openness of landscapes and the diversity of values and institutions, but methods to address both together are largely absent in the literature. Telecoupling integrates landscape nestedness and connectedness into LS assessments (Koellner

et al. 2019) but remains largely silent on incorporating values. Similarly, metrics that capture diverse values and institutional attributes (e.g. polycentric governance) can indicate how well institutions consider values and power relations among actors connected to landscapes (Cash et al. 2006; Ostrom 2010), but these approaches typically remain silent on ES interactions across landscapes and scales. A systematic approach combining multiple frameworks could address these challenging landscape features within LS assessments, better informing sustainability decisions and targets.

Frameworks to assess LS vary greatly but generally consist of three broad over-arching stages: (1) Defne the question and scope; (2) Identify the ES indicators to assess and defne targets; and (3) Measure and evaluate the ES dynamics of the landscape (Potschin

and Haines-Young 2013; Wu 2013; Fang et al. 2015; Dale et  al. 2019). In this section, we provide an initial guideline, consisting of seven actions, detailing how and where to address diverse values and institutions, and the openness of landscapes within these three broad stages (Fig. 2). We also provide a list of potential methods to implement these seven actions (Table 1). By providing actions under the three overarching stages of LS assessments our guideline can easily be incorporated into the diferent landscape sustainability assessments available, providing better consideration of the two challenging features. Since landscapes are complex systems, any LS assessment will contain uncertainties and can often only consider a subset of interactions and values to ensure it can be feasibly implemented. Our guideline aims to provide a starting point for capturing the challenging features

![](images/cc3e6cada58ab0b915048f61ddcae78dd812ddfe07ac87ee7b54ed346a40b166.jpg)  
Fig. 2 A fowchart depicting the initial guideline for how and where to implement actions addressing the openness of landscapes and diverse values and institutions into LS assessments

Table 1 Suggested methods that could be used at each step of the proposed guideline to address the diversity of values and the openness of landscapes in sustainability assessments   

<table><tr><td>Actions</td><td>Key Methods</td><td>Key methodology references</td></tr><tr><td>1. Determine the question(s) through co-design or consultation</td><td>Co-design research methods (e.g. consultation, surveys, stakeholder/rightsholder workshops)</td><td>Moreau et al. 2023
Busse et al. 2023</td></tr><tr><td>2. Define the focal landscape boundary</td><td>Co-design research methods (e.g. consultation, surveys, stakeholder/rightsholder workshops)
Mapping of socio-political and bioregional boundaries</td><td></td></tr><tr><td>3. Identify stakeholders and rightsholders, and their values</td><td>Qualitative surveys and interviews
Consultations and workshops
Literature review
Q methodology</td><td>IPBES 2022
Termansen et al. 2023
Daw et al. 2011
Martín-López et al. 2019</td></tr><tr><td>4. Identify the ecosystem services to be assessed based on stakeholder and rightsholder values</td><td>Literature review
Consultations and workshops
Qualitative surveys and interviews</td><td>Cole et al. 2023
Felipe-Lucia et al. 2022</td></tr><tr><td>5. Identify ecosystem service capacity, flow and demand dynamics within the landscape</td><td>Ecosystem service modelling
Spatial analysis
Participatory GIS
Consultations and workshops
Political-industrial ecology</td><td>Olander et al. 2018
Neyret et al. 2023
Sutherland et al. 2023
Cousins and Newell 2015</td></tr><tr><td>6. Map ecosystem service flows across connected landscapes and scales</td><td>Telecoupling
Supply chain mapping
Ecosystem service modelling
Spatial analysis
Consultations and workshops</td><td>Koellner et al. 2019
Schroter et al. 2018
Goldstein and Newell 2020</td></tr><tr><td>7. Repeat Actions 2–5 for relevant connected landscapes</td><td>See methods for Actions 2–5</td><td>See literature for Actions 2–5</td></tr></table>

and should be used as a tool for understanding diferent perspectives and marginal changes in LS, rather than providing a single objective value for LS.

Action 1: Determine the question(s) through co-design or consultation

The multi-faceted nature of LS means it is not feasible to assess all aspects of LS for a given landscape. Determining the question of interest in the initial planning stage of an assessment will help frame which ES to assess. The question may, for example, revolve around an activity (e.g., expanding avocado production), or a policy mechanism within the landscape (e.g., urban densifcation). Co-design and consultation with stakeholders and rightsholders to frame the question will ensure meaningful and diverse values are considered early on (Eichler Inwood et  al. 2018; Martín-López et  al. 2019). The co-design of a research question with multiple stakeholder and

rightsholder groups will also help reduce the risk of social power dynamics infuencing the question framing.

Action 2: Defne the focal landscape boundary

Delineating landscape boundaries is a crucial initial step for assessing ES interactions across connected landscapes and determining the rightsholders and stakeholders impacted. Boundaries may be identifed based on predetermined social-political, bioregional, or social-ecological system boundaries, but should align with the question identifed (Action 1). Furthermore, stakeholders and rightsholders should be consulted when identifying the boundary to ensure that the way in which they live and experience the landscape is accounted for (Eichler Inwood et  al. 2018). Action 1 and 2 may also be an iterative process, as determining the boundary could lead to the identifcation of further rightsholders and stakeholders who may be consulted to defne the question.

Action 3: Identify stakeholders and rightsholders, and their values

Relevant stakeholders and rightsholders may have been identifed in Actions 1 and 2, but here all impacted actors are identifed. Once identifed, their values about nature, and potential value conficts can be determined (Daw et  al. 2011). Identifying and accounting for the values held by diferent people improves transparency in decision-making and helps mitigate the infuence of asymmetric power relations on decision-making (Ainscough et al. 2019). In many cases it may not be possible to identify the values of all groups, due to resource limitations, confict between values, participation bias and difculty transcribing values into writing. In these cases, a structured critical refection on which values to include should be conducted using methods discussed in Table  1, such as qualitative surveys and workshops. An iterative approach can also be conducted afterwards, where Actions 1–3 are repeated with input from all stakeholders and rightsholders.

Action 4: Identify the ecosystem services to be assessed based on stakeholder and rightsholder values

The ES should be identifed through their ability to support the values about nature identifed in Action 3 (Chan et al. 2018). It is likely that not all identifed values, and the ES identifed from these, will be conducive to improving or contributing to LS. ES identifed should be based on the values of diferent stakeholder and rightsholder groups, but also chosen based on how they contribute to LS, based on the defnition of LS (the capacity for a landscape to consistently provide equitable access to diverse ES essential for supporting the wellbeing of multiple actors, both now and into the future). Therefore, consultations with stakeholders and rightsholders may need to be conducted to choose a fnal list of ES that is equitable, diverse and supports the wellbeing of multiple actors long term (Ainscough et al. 2019). This approach may not identify all ES important to LS, as some ES may not have an actor to provide a voice for them. Therefore, in consultation with stakeholders and rightsholders, ES experts may also propose the addition of other valuable ES not directly identifed in Action 3 that have less perceived benefts. For example, people

could identify nature as important for recreation, but not identify the need for trees to regulate temperature (Peckham et  al. 2013). Stakeholders and rightsholder should be consulted on the fnal list of ES for transparency.

Action 5: Identify ecosystem service capacity, fow and demand dynamics within the landscape

Indicators of capacity, demand and fow of the chosen ES, and the mechanisms or drivers that infuence these ES dynamics, should be determined at this stage. Indicators of the ES and the mechanisms and drivers will enable changes in ES capacity, fow and demand dynamics to be captured, ensuring the environmental, economic and social sustainability dimensions are considered under current and future scenarios, and based on the question of interest. This will help determine the location and quantity of ES that are provided or desired within the focal landscape now and into the future, whether demand for the ES is greater or smaller than the capacity, and how the mechanisms or drivers infuence these dynamics, and in turn infuence LS. The mechanisms and drivers identifed should be linked to the question of interest (identifed in Action 1). For example, a question revolving around the LS impact of expanding urban farming within a city landscape may include food production as an ES of interest and measure this ES using area of food production or harvest quantity as an indicator for capacity, population size as an indicator for demand and the sale of locally produced food as the fow within the focal landscape (Colasanti and Hamm 2010). Mechanisms that infuence the ES dynamics in this example could include technology, policies, cultural practices, and market value (Artmann and Sartison 2018). Identifying the capacity, demand and fow dynamics, and the impact of the mechanisms and drivers on these, for each ES identifed in Action 4 can also determine if trade-ofs are occurring among the ES (Dade et  al. 2019). This is due to mechanisms likely afecting other ES of interest, potentially leading to conficts between diferent ES users. Indicators should be selected that are capable of measuring ES capacity, demand and fow under diferent mechanisms or drivers, to allow these dynamics to be measured under diferent scenarios (Olander et al. 2018; Mandle et al. 2021).

# Action 6: Map ecosystem service fows across connected landscapes and scales

The connectivity between landscapes and the relevant scales should be determined by identifying which landscapes are supplying ES to the focal landscape to meet demand (identifed in Action 5) (Schröter et al. 2018). Flows from connected landscapes can be determined through trade data or economic data as well as interviews with stakeholders and rightsholders. For example, Kleemann et al. (2020) measured ES fows across connected landscapes using trade data. The geographic locations of the connected landscapes can then be used to identify the larger scales afected (e.g. national scales). Focal landscapes may have many connected landscapes, and thus it may be infeasible to identify all such ES based telecouplings (Kleemann et  al. 2020). Therefore, this step is about identifying and prioritizing the connected landscapes through ES in-and out-fows in relation to the initial question identifed (Action 1).

Action 7: Repeat actions 2–5 for relevant connected landscapes

An iterative process of applying these actions to connected landscapes can be used to identify changes in LS in other places or at larger scales (e.g., regional scales) under the question of interest, and the associated drivers and mechanisms (Action 1). For example, if the initial question focused on the impact that ending forest harvesting within the focal landscape will have on LS, changes in timber harvesting in connected landscapes to meet demand in the focal landscape should be assessed, including the impact this will have on other essential ES within the connected landscapes (Mayer et  al. 2005). This impact can then be integrated into the LS assessment for the focal landscape. As the aim is to only assess how landscapes directly linked to the focal landscape are afected, steps 6 and 7 do not need to be conducted for the connected landscapes (as the landscapes linked to the connected landscapes are outside the scope of the assessment).

# Conclusions

ES provide an operational approach to assessing sustainability at the landscape level, which can help

monitor and assess societal eforts to transition to more sustainable trajectories. However, failure to account for the complex social-ecological features of landscapes can lead to oversimplifed assessments of LS that will not fully capture all elements of LS, such as of-stage burdens and power asymmetries. Here, we highlight two key complex features of landscapes – their openness and the diversity of values of stakeholders – that, even though often neglected, must be integrated into LS assessments to improve operationality. Our seven-action guideline and accompanying tools provide guidance to both decision-makers and researchers on how to integrate diferent stakeholder values and connected landscapes into LS assessments. Our focus on the landscape scale emphasizes needed granularity to operationalize LS and to address complexities simultaneously. By providing an integrative and comprehensive framework for assessing LS our guideline can help inform sustainability goals across multiple scales, including the Global Biodiversity Framework 2030 goals, to inform sustainable transitions and equitable land management.

Acknowledgements The workshops that generated this paper were funded by the McGill Sustainability Systems Initiative Landscapes Theme, McGill University. AB and MFL acknowledge the support of the German Centre for Integrative Biodiversity Research (iDiv) funded by the German Research Foundation (DFG-FZT 118, 202548816). MFL also acknowledges that her contract is part of the RYC2021-032828-I Grant, fnanced by MCIN/AEI/https://doi.org/10.13039/50110 0011033 and by the European Union “NextGenerationEU”/ PRTR. SL acknowledges support from ANR project RECON-NECT. JPM was funded by the National Council for Scientifc and Technological Development (CNPQ, 309767/2021-0). GW acknowledges support from the EU’s Horizon 2020 programme under the Marie Skłodowska-Curie grant agreement No. 101024588. UP acknowledges Basque Centre for Climate Change’s Maria de Maeztu excellence accreditation 2023–2026 (Ref no. CEX2021-001201-M) provided by Grant No. MCIN/ AEI/https://doi.org/10.13039/501100011033. BG acknowledges The Natural Sciences and Engineering Research Council of Canada through the Discovery Grant programme (Grant number: RGPIN/03440-2021).

Author contribution MCD, EMB and BER led the study conception and design with contributions from all other authors. MCD wrote the manuscript and all other authors provided edits and approved the fnal manuscript.

Funding This article was funded by the McGill Sustainability Systems Initiative, McGill University, Deutsche Forschungsgemeinschaft, DFG-FZT 118,202548816, DFG-FZT 118, 202548816, Natural Sciences and Engineering Research Council of Canada, RGPIN/03440-2021, Agence Nationale de la

Recherche, Conselho Nacional de Desenvolvimento Científco e Tecnológico,309767/2021-0,H2020 Marie Skłodowska-Curie Actions,101024588.

Data availability No datasets were generated or analysed during the current study.

