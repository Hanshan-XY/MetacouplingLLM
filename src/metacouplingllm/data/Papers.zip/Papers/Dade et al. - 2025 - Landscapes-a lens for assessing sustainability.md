# Landscapes-a lens for assessing sustainability

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:39:37.054296+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Dade et al. - 2025 - Landscapes-a lens for assessing sustainability.pdf
- Year: unknown
- DOI: 10.1007/s10980-024-02007-7
- OA status: hybrid
- License: cc-by-nc-nd
- Category: Journal Articles\Conceptual\Telecoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This conceptual paper proposes landscapes as a practical scale and lens for assessing sustainability, with a particular focus on ecosystem services and social-ecological interactions. The work is global in scope and not tied to a single country or case study, although it draws on examples from cities, agricultural regions, and rangelands worldwide. It speaks to systems where land-use decisions, ecosystem services, and human well-being are jointly considered, such as landscape planning, conservation, and resource governance.

The authors build on two expert workshops with scholars from landscape ecology, sustainability science, environmental justice, and related fields. Through these discussions, they identify persistent blind spots in landscape sustainability assessments and then co-develop a set of practical guidelines. No new empirical datasets are analyzed; the paper instead synthesizes existing literature and case examples.

Two core challenges are emphasized. First, landscapes have open, porous boundaries and are embedded in networks of material and ecosystem-service flows across scales. Ignoring cross-scale linkages and telecouplings can misrepresent sustainability gains in one place that are offset by burdens elsewhere, such as through trade, land-use displacement, or shifted environmental impacts. Second, landscape assessments often inadequately represent diverse values, institutions, and power relations. Which ecosystem services are prioritized typically reflects dominant actors and governance structures, potentially overlooking marginalized groups, relational and intrinsic values, and issues of justice.

To address these gaps, the authors offer a seven-step guideline that embeds stakeholder and rightsholder engagement, value pluralism, and telecoupling into landscape sustainability assessment. Steps include co-defining questions and boundaries, systematically mapping who benefits or loses, and tracing ecosystem-service capacity, flows, and demand both within focal landscapes and across connected regions.

The paper is directly relevant to telecoupling and broader metacoupling research. It integrates telecoupled flows and multi-scale interactions with attention to values and power, providing an operational bridge between telecoupling frameworks and on-the-ground landscape sustainability assessments.

## Structured Metacoupling Extraction

### Coupling Classification
- Conceptual paper on landscape sustainability integrating intra-, peri-, and telecoupling via ecosystem service flows.

### Intracoupling
#### Systems
- Focal landscape as place based social ecological system
- Urban landscape managing green space and transport
- Watershed and agroecosystem mosaics
#### Flows
- Local ecosystem service capacity demand and flow interactions
- Within landscape tradeoffs among multiple ecosystem services
- Internal material energy and information exchanges
#### Agents
- Local residents farmers and pastoralists
- Municipal planners and government agencies
- Tourism operators and charcoal producers
#### Causes
- Local land use policies and management decisions
- Cultural practices and knowledge systems
- Technology markets and demographic change
#### Effects
- Changes in local wellbeing and justice
- Altered landscape structure and ecosystem functions
- Unequal access to key ecosystem services

### Pericoupling
#### Systems
- Focal landscape and neighboring agroecosystems
- Urban region containing multiple landscapes
- Adjacent grassland forest and scrubland areas
#### Flows
- Regional food supply for nearby cities
- Tourism between city and surrounding nature areas
- Migration and daily commuting across landscapes
#### Agents
- Regional planners and basin authorities
- Neighboring rural communities
- Provincial or regional governments
#### Causes
- Urban densification increasing regional food demand
- Watershed management decisions upstream downstream
- Spread of invasive species across nearby landscapes
#### Effects
- Intensified agriculture and ecosystem degradation nearby
- Redistribution of sustainability burdens within region
- Cross boundary conflicts over land and water

### Telecoupling
#### Systems
- US urban consumer landscapes
- Michoacan avocado producing landscapes in Mexico
- Distant timber or forest supply regions
#### Flows
- International trade in avocados as provisioning service
- Telecoupled ecosystem service burdens via supply chains
- Information and market signals shaping distant land use
#### Agents
- Consumers retailers and marketers
- Export oriented farmers and agribusinesses
- National governments and trade institutions
#### Causes
- Global dietary trends and marketing campaigns
- Trade liberalization and price incentives
- Policies protecting forests in importing regions
#### Effects
- Deforestation water scarcity and lost regulation services abroad
- Apparent sustainability gains masking offstage burdens
- Telecoupled injustices and externalized environmental costs

### Cross-Coupling Interactions
- Local sustainability gains can shift burdens to regional and distant landscapes
- Telecoupled trade interacts with local power shaping who benefits from ecosystem services
- Values and institutions mediate impacts of cross scale ecosystem service flows

### Research Gaps or Limitations
- Limited operational methods to jointly capture openness values and power in assessments
- Telecoupling tools rarely integrate diverse values and justice considerations
- Value focused frameworks often ignore multi scale ecosystem service flows

### Search Keywords
- landscape sustainability ecosystem services telecoupling
- open landscape boundaries values institutions power
- cross scale social ecological assessments framework

### Extraction Confidence
high
