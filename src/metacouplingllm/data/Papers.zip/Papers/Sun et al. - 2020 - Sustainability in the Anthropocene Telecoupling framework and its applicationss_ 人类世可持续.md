# Sustainability in the Anthropocene Telecoupling framework and its applicationss_ äººç±»ä¸–å¯æŒç»­

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:07:22.402627+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Sun et al. - 2020 - Sustainability in the Anthropocene Telecoupling framework and its applicationss_ äººç±»ä¸–å¯æŒç»­.pdf
- Year: unknown
- DOI: 10.11821/dlxb202011010
- OA status: unknown
- License: none recorded
- Category: Journal Articles\Review\Telecoupling
- Closed-access reason: no license info, oa_status=unknown

## Copyright-Safe Summary
This review paper examines how the telecoupling framework can support sustainability research in the Anthropocene, when human activities tightly connect distant places. Telecoupling is defined as socioeconomic and environmental interactions that link multiple coupled human and natural systems over long distances. The authors focus on global applications but highlight detailed examples from China.

The framework decomposes any telecoupling into sending, receiving, and spillover systems connected by flows of material, energy, and information. Within each system, human and natural subsystems are represented through agents, causes, and effects. A key emphasis is on feedbacks both within and between systems and on explicitly internalizing externalities that arise in distant places.

Using Web of Science and CNKI, the authors identify 145 peer-reviewed papers that adopt telecoupling as a main analytical lens between 2013 and late 2020. Application domains include food trade, land use and land cover change, long-distance water transfer, tourism, species migration, urbanization, and energy. They argue that misuse and incomplete use of the framework remain common, especially in defining systems and drivers.

Three Chinese case studies illustrate different ways of applying telecoupling. A qualitative study on the Miyun Reservoir upstream land conversion project frames Beijing as a receiving system and Hebei as a sending system, highlighting cross-regional win-wins in water supply, water quality, and farmer income as well as overlooked spillover systems. A quantitative analysis of international soybean trade shows that major importing countries, including China and particularly Heilongjiang Province, can suffer increased nitrogen pollution as cropping patterns shift, challenging the view that importers always gain environmental benefits. A study of the Grain-to-Forestry program in Wolong Nature Reserve demonstrates strong feedbacks: habitat restoration increases wildlife damage to crops and in turn raises farmers willingness to enroll more land in reforestation.

The paper is explicitly about telecoupling/metacoupling. It discusses terminology, the role of spillover systems, and modeling tools such as GTAP, agent-based models, and an online Telecoupling Toolbox. The authors argue that telecoupling offers a cross-scalar systems perspective valuable for managing major Chinese initiatives and global sustainability challenges.

## Structured Metacoupling Extraction

### Coupling Classification
- Primarily about telecoupling; also discusses intracoupled CHANS and spillover systems; peri-scale links implicit.

### Intracoupling
#### Systems
- Local coupled human and natural systems such as watersheds and nature reserves
- On-site farming systems before policy or trade interventions
#### Flows
- Local water, nutrients, and ecosystem services within a region
- Feedback of land use change on local biodiversity and pollution
#### Agents
- Local farmers and households managing land and water
- Reserve managers and local governments
#### Causes
- Local land use policies like grain to green
- Population growth and economic development pressures
#### Effects
- Changes in local water quality and quantity
- Biodiversity shifts and altered habitat conditions
- Household livelihood and income structure changes

### Pericoupling
#### Systems
- Neighboring provinces linked by water transfer and compensation
- Adjacent farmland zones near newly reforested areas
#### Flows
- Regional water transfers over moderate distances
- Wildlife movement from protected forests into nearby cropland
#### Agents
- Provincial governments negotiating water and compensation
- Regional infrastructure and water authorities
#### Causes
- Interprovincial projects like irrigation change for downstream supply
- Expansion of reforestation near agricultural frontiers
#### Effects
- Regional reallocation of water scarcity and treatment costs
- Crop damage from wildlife in bordering farmlands
- Regional shifts in employment and land use

### Telecoupling
#### Systems
- Distant sending, receiving, and spillover CHANS across countries and provinces
- Examples: Brazil, China, United States in soybean trade
- Central government, Wolong Reserve, downstream regions in ecological programs
#### Flows
- Trade in soybeans and other agricultural commodities
- Interbasin water transfers and ecological compensation payments
- Information, finance, technology, and policy directives
#### Agents
- Farmers, traders, and agribusiness firms
- National and provincial governments designing policies
- International negotiators and global consumers
#### Causes
- Globalization, population growth, and changing diets
- Demand for food, timber, and ecosystem services
- Technological feasibility of long distance water transfer and transport
#### Effects
- Displacement of land use and pollution across borders
- Importing countries also suffering environmental burdens like nitrogen pollution
- Improved habitats and reduced downstream flood risk via reforestation

### Cross-Coupling Interactions
- Telecoupled trade reshapes local cropping patterns and pollution in importing regions
- Water transfer project links upstream livelihoods, downstream urban supply, and external spillover zones
- Ecological compensation triggers feedbacks between national policy, local behavior, and regional risk

### Research Gaps or Limitations
- Need clearer identification and analysis of spillover systems and their agents
- Inconsistent or incorrect use of sending, receiving, and spillover definitions in applications
- Limited integrated modeling linking global trade models with regional agent based simulations

### Search Keywords
- telecoupling framework CHANS spillover systems
- soybean trade nitrogen pollution importing countries
- water transfer ecological compensation Wolong reforestation feedback

### Extraction Confidence
high
