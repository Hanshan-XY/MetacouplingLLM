# Drivers of Human Stress on the Environment in the Twenty-First Century

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:40:59.721615+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Dietz - 2017 - Drivers of Human Stress on the Environment in the Twenty-First Century.pdf
- Year: unknown
- DOI: 10.1146/annurev-environ-
- OA status: unknown
- License: none recorded
- Category: Journal Articles\Review\Telecoupling
- Closed-access reason: no license info, oa_status=unknown

## Copyright-Safe Summary
This review article synthesizes conceptual frameworks and empirical research on what drives human pressures on the environment in the 21st century. It is global in scope and treats the Earth as a complex set of coupled human and natural systems rather than focusing on a single country or sector.

The author first contrasts six influential frameworks. Two are quantitative driver models: IPAT/Kaya and its stochastic extension STIRPAT, which regress environmental stress (such as emissions or land conversion) on population, affluence, and technology; and decomposition/input-output approaches that separate total impact into scale, composition, and technique, often using energy and material flow accounts. Four are systems schemes used in assessments and governance: DPSIR, the Millennium Ecosystem Assessment (MA) framework, coupled human and natural systems (CHANS) and its telecoupling extension, and Ostroms social-ecological systems (SES) framework. These emphasize feedbacks, nonlinearity, thresholds, resilience, and multilevel governance.

The article then reviews four major empirical traditions: (1) macrocomparative cross-national analyses using STIRPAT-type models for emissions, ecological footprints, deforestation, and pollution, including tests of environmental Kuznets and political-economy effects such as trade, investment, and inequality; (2) household energy-consumption research grounded in social psychology, examining how values, norms, and decision heuristics shape behavior and how interventions like feedback or social comparison can unlock a behavioral wedge; (3) land-change science that combines remote sensing with household data to link demographic and livelihood dynamics to deforestation, intensification, and biodiversity loss; and (4) commons research on how institutional arrangements and polycentric governance affect the use of shared resources such as forests, fisheries, and the atmosphere.

Telecoupling and related CHANS/SES work are explicitly treated as key to understanding action at a distance, such as how global markets, tourism, or payments for ecosystem services reshape distant ecosystems. The paper itself is not a focused telecoupling case study, but it embeds telecoupling within a broader metacoupling-style view of multiscale, interconnected socio-environmental systems and calls for integrated, cross-scale research to inform policy.

## Structured Metacoupling Extraction

### Coupling Classification
- Conceptual review of global human-environment couplings including telecoupling, mostly macro and multi-scale.

### Intracoupling
#### Systems
- Nation-level socio-environmental systems with internal drivers and stresses.
- Local communities managing land, energy, or commons within one region.
#### Flows
- Domestic energy use, pollution, and resource extraction within national borders.
- Household-level flows of land, labor, and inputs affecting nearby ecosystems.
#### Agents
- Households, firms, and consumers making resource use decisions.
- National and subnational governments regulating environment and economy.
#### Causes
- Population, affluence, and technology influencing domestic environmental stress.
- Institutional arrangements and norms shaping local resource use.
#### Effects
- National greenhouse gas emissions, pollution, land use change, biodiversity loss.
- Local ecosystem degradation or resilience affecting human well-being.

### Pericoupling
#### Systems
- Neighboring regions linked by land use, trade, and shared watersheds.
- Regional commons such as fisheries, rangelands, and river basins.
#### Flows
- Cross-border trade in resources, energy, and agricultural products.
- Pollution and water flows moving across adjacent jurisdictions.
#### Agents
- Regional governments and river basin organizations.
- Cross-border communities using shared commons.
#### Causes
- Regional infrastructure expansion, markets, and policy harmonization.
- Shared governance rules and conflicts over common-pool resources.
#### Effects
- Regional land cover transitions and deforestation fronts.
- Distributed impacts on water quality, fisheries, and livelihoods.

### Telecoupling
#### Systems
- Distant coupled human-natural systems connected through globalization.
- Example: Wolong Nature Reserve linked with international society.
#### Flows
- International trade, investment, and tourism affecting remote ecosystems.
- Payments for ecosystem services and global conservation finance.
#### Agents
- Multinational firms and investors driving distant land use change.
- International NGOs, global conventions, and foreign governments.
#### Causes
- Global economic growth, neoliberal reforms, and world-system position.
- Long-distance transport of pollutants and invasive species.
#### Effects
- Remote deforestation, biodiversity loss, and carbon emissions driven by distant demand.
- Ecologically unequal exchange and shifted environmental burdens.

### Cross-Coupling Interactions
- Telecoupled trade reshapes local land use while national policies mediate responses.
- Global drivers interact with household decisions, producing context-dependent environmental outcomes.
- Polycentric governance links local commons institutions with higher-level political economies.

### Research Gaps or Limitations
- Lack of multi-scale longitudinal data linking individuals, households, and geopolitical units.
- Limited integration across macrocomparative, household, land change, and commons traditions.
- Contextual effects of institutions, culture, and power often under-measured in empirical work.

### Search Keywords
- drivers of environmental stress and telecoupling
- STIRPAT DPSIR CHANS SES Millennium Ecosystem Assessment
- macrocomparative analysis household energy land change commons

### Extraction Confidence
high
