# Tracing Austria_s biomass consumption to source countries A product-level comparison between bioene

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:48:48.868183+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Kalt et al. - 2021 - Tracing Austria_s biomass consumption to source countries A product-level comparison between bioene.pdf
- Year: unknown
- DOI: 10.1016/j.ecolecon.2021.107129
- OA status: hybrid
- License: cc-by-nc-nd
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This paper analyzes how biomass consumed in Austria is connected to global production systems, focusing on how much comes from domestic versus foreign sources and how this varies by use type. The geographic focus is Austria, but sourcing patterns are mapped worldwide. The work is clearly situated in telecoupling research, addressing spatial disconnects between places of biomass production and consumption and using a footprint perspective compatible with metacoupling.

The authors develop a physical, consumption-based accounting framework with high product resolution and explicit separation of three use categories: food, energy, and materials. They combine FAO and Eurostat trade and production data with Austrian national statistics on agriculture, forestry, energy, and biofuels, plus detailed process-chain models for wood industries. An origin-tracing algorithm converts traded and processed products back into primary biomass equivalents and allocates them to producing countries, including embodied feed in animal products and feedstock in liquid biofuels. The temporal focus is mainly 2010-2013.

Austria’s total primary biomass footprint is about 25 million tons of dry matter per year, with roughly 57 percent agricultural and 43 percent forest biomass. Energy uses dominate (about 40-plus percent), followed by food and then material uses. Overall, 55 percent of the footprint comes from Austrian agriculture and forestry, about 30 percent from neighboring Central European countries, and roughly 8 percent from non-EU countries. Contrary to public perceptions, bioenergy is actually more regionally sourced than food and materials: only a small share of energy-related biomass originates outside the EU, largely because Austrian bioenergy relies heavily on domestic and nearby wood. In contrast, food and material sectors show stronger telecoupled links, especially through imported livestock feed from the Americas and textiles based on cotton and wool from overseas.

The study highlights that even a country with high apparent self-sufficiency exerts substantial biomass pressure abroad. It shows how telecoupled biomass flows differ by product and use, and argues that EU-level governance is crucial because most foreign biomass embodied in Austrian consumption is still produced within the Union.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via Austria centered biomass trade; limited but notable intra and peri linkages.

### Intracoupling
#### Systems
- Austrian agroforestry and energy system
- Austrian livestock and feed system
#### Flows
- Domestic wood and fuelwood to industry and households
- Domestic crops and grass to food and bioenergy uses
#### Agents
- Austrian farmers and foresters
- Domestic wood processing and bioenergy firms
#### Causes
- High forest cover and strong wood industry
- National bioenergy and self sufficiency policies
#### Effects
- Local land use and habitat change
- Domestic air emissions from biomass combustion

### Pericoupling
#### Systems
- Austria and neighboring Central European countries
- Austria and EU single market biomass chain
#### Flows
- Roundwood, sawnwood, paper between Austria and neighbors
- Biofuels and livestock products traded within EU
#### Agents
- Central European wood and paper industries
- EU based crop and livestock producers
#### Causes
- EU market integration and trade agreements
- Regional price differences and industry demand
#### Effects
- Shared regional forest and land pressures
- Cross border environmental and governance challenges

### Telecoupling
#### Systems
- Austria and South American feed crop regions
- Austria and global cotton and wool suppliers
- Austria and overseas oilseed and palm oil regions
#### Flows
- Soybean and protein feed embodied in meat and eggs
- Oil crops and plant oils embodied in biodiesel
- Natural fibres, textiles, charcoal imports
#### Agents
- Foreign crop and livestock producers and traders
- Global biofuel and textile corporations
- International commodity and shipping actors
#### Causes
- Austrian demand for cheap protein feed and textiles
- Biofuel mandates and renewable energy targets
- Consumer preference for meat and imported products
#### Effects
- Land use change and biodiversity loss abroad
- Externalized environmental footprints and leakage risks
- Reduced Austrian control over sustainability impacts

### Cross-Coupling Interactions
- Telecoupled feed imports enable domestic meat exports and perceived self sufficiency
- Pericoupled wood trade feeds domestic bioenergy, linking material and energy uses
- Subsidized EU biofuel demand amplifies overseas land and resource pressures

### Research Gaps or Limitations
- Limited post 2013 data and potential breaks in food balance methodologies
- Simplified treatment of textiles and secondary wood products due to data gaps
- Origin tracing proportionality assumption limits spatial precision of footprints

### Search Keywords
- Austria biomass telecoupling origin tracing
- biomass trade land footprint consumption based
- bioenergy food material regionality EU

### Extraction Confidence
high
