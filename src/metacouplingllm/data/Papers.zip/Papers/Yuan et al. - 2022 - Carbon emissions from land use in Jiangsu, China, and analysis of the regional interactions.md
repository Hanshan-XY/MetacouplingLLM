# Carbon emissions from land use in Jiangsu, China, and analysis of the regional interactions

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:17:12.964499+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Yuan et al. - 2022 - Carbon emissions from land use in Jiangsu, China, and analysis of the regional interactions.pdf
- Year: unknown
- DOI: 10.1007/s11356-022-19007-2
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines how land use in Jiangsu Province, eastern China, shapes energy‑related carbon emissions and how those emissions are redistributed across China through interprovincial trade. The authors frame the problem using the telecoupling concept, treating Jiangsu and other provinces as interconnected human‑environment systems linked by commodity and emission flows.

Using 2012 data, they first calculate energy‑related carbon emissions for 30 Chinese provinces with an emissions‑coefficient approach, then reallocate those emissions to land‑use categories (industrial‑mining, urban, rural residential, transport, agricultural, special land). They rely on national energy statistics, multi‑regional input‑output (MRIO) tables, land survey data, and, for Jiangsu, detailed land‑use and industrial enterprise datasets plus DMSP/OLS nighttime lights. MRIO analysis reveals carbon embodied in interprovincial trade, which is then reassigned to land types and spatially downscaled in Jiangsu using industrial point data and calibrated night‑light grids.

China emitted about 2.27 billion tonnes of carbon in 2012, with coal as the main source. Jiangsu contributed roughly 6 percent of this total and showed rising emissions from 2006 to 2017. Industrial‑mining land, though occupying a small area, produced over 70 percent of national and about 80 percent of Jiangsu emissions, highlighting industrial land as the dominant anthropogenic carbon carrier.

Telecoupling results show Jiangsu as a net exporter of land‑based embodied carbon. Net outflows from Jiangsu’s urban and industrial‑mining land mainly go to northern and central provinces such as Hebei, Shandong, Shanxi, and Inner Mongolia, which generally have higher carbon intensity per unit GDP. In contrast, Jiangsu receives substantial embodied emissions from many southern and western provinces, including Guangdong, Shanghai, and Yunnan. Within Jiangsu, imported, trade‑driven emissions concentrate in southern metropolitan cores (Suzhou, Wuxi, Nanjing) for urban land, and in industrial belts around city fringes and along the Yangtze River, including Xuzhou in the north.

The work explicitly applies the telecoupling framework, linking distant economic trade to spatially explicit land‑based emissions. It underscores that land use, industrial structure, and regional trade together create asymmetric emission responsibilities, with implications for ecological compensation, carbon trading, and differentiated land‑use and climate policies.

## Structured Metacoupling Extraction

### Coupling Classification
- Explicit telecoupling of land based carbon via Chinese interprovincial trade
- Also analyzes intracoupling within Jiangsu through land use and spatial patterns

### Intracoupling
#### Systems
- Jiangsu province land system with construction and agricultural land
- Urban centers versus surrounding industrial belts inside Jiangsu
- Southern versus northern Jiangsu development zones
#### Flows
- Energy related carbon emissions from land use activities within Jiangsu
- Carbon relocation between land use types through land conversion
- Export driven emissions shifted within Jiangsu cities
#### Agents
- Provincial and municipal governments in Jiangsu
- Industrial enterprises above designated size
- Urban residents and local service sectors
#### Causes
- Industrialization and construction land expansion in Jiangsu
- Urbanization and residential consumption growth
- Land use intensity and economic development patterns
#### Effects
- Very high emissions from industrial and mining land in Jiangsu
- South north emission gradient and urban emission hotspots
- Increased mitigation pressure on southern Jiangsu cities

### Pericoupling
#### Systems
- Jiangsu and neighboring eastern coastal provinces
- Jiangsu and central China provinces
- Industrial corridors along the Yangtze River
#### Flows
- Bidirectional trade of industrial products and services
- Regionally shared air pollution alongside carbon
- Export driven emissions clustered along Yangtze corridor
#### Agents
- Provincial governments coordinating regional development
- Regional manufacturing and energy companies
- Planning and environmental agencies along Yangtze
#### Causes
- Regional production specialization and industrial clustering
- Demand from nearby provinces for manufactured goods
- Logistics advantages along the Yangtze River
#### Effects
- Concentration of industrial emissions along the Yangtze
- Uneven regional environmental pressure among neighbors
- Need for differentiated land and emission policies by city

### Telecoupling
#### Systems
- Jiangsu land system as key sending and receiving system
- Other Chinese provinces as coupled human natural systems
- National trade network linking provincial land emissions
#### Flows
- Embodied land use carbon in interprovincial trade
- Net carbon outflows from Jiangsu to northern and central provinces
- Net carbon inflows to Jiangsu from southern and western provinces
#### Agents
- Central and provincial governments governing trade and emissions
- Enterprises driving interprovincial production and exports
- Statistical and research institutions supplying MRIO data
#### Causes
- Economic growth and consumption demand across provinces
- Trade driven relocation of emission intensive production
- Differences in economic and land carbon intensities
#### Effects
- Jiangsu as major net exporter of land based carbon
- Less developed industrial provinces receive large net emissions
- Inequitable distribution of environmental burdens and responsibilities

### Cross-Coupling Interactions
- Telecoupled trade flows reshape intracoupled urban and industrial emission hotspots within Jiangsu
- Pericoupled Yangtze industrial belt mediates national telecoupled carbon transfers
- Land use planning decisions locally influence national telecoupled emission patterns

### Research Gaps or Limitations
- Land use classes and energy items only approximately matched, creating systematic uncertainty
- Industrial spatial simulation excludes smaller enterprises and detailed industrial land polygons
- Single year MRIO analysis limits understanding of temporal telecoupling dynamics

### Search Keywords
- Jiangsu land use carbon telecoupling MRIO
- embodied carbon interprovincial trade China
- construction land industrial mining urban emissions

### Extraction Confidence
high
