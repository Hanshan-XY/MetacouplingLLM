# Environmental governance in globally telecoupled systems Mapping the terrain towards an integrated

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:38:24.461311+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Cotta et al. - 2022 - Environmental governance in globally telecoupled systems Mapping the terrain towards an integrated.pdf
- Year: unknown
- DOI: 10.1016/j.esg.2022.100142
- OA status: gold
- License: cc-by-nc-nd
- Category: Journal Articles\Review\Telecoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This article reviews how environmental governance engages with global telecouplings - that is, distant connections created by trade, investment, migration, and other cross-border flows that generate environmental impacts.

The authors focus on worldwide flows of commodities, people, and finance that cross at least one national border. They use the telecoupling framework of sending, receiving, and spillover systems, and ask how negative environmental effects of these flows are governed. Their work is explicitly global in scope and firmly situated in the telecoupling/metacoupling literature.

Using PRISMA-based procedures, they systematically searched Scopus for English-language journal articles (2011-2018) that simultaneously addressed: (1) cross-border flows, (2) environmental problems, and (3) governance responses. They screened thousands of records and coded 120 articles in depth, examining flows, impacts, governance instruments, actors, and theoretical lenses.

Most studies analyze commodity trade, especially forestry products, biofuels, palm oil, soy, metals and minerals, fisheries, and waste. Flows predominantly run from the Global South to both North and South. Environmental burdens are mainly documented in sending regions, including deforestation, biodiversity loss, water and soil degradation, and greenhouse gas emissions.

Governance responses are dominated by public regulation (national laws, EU directives, multilateral agreements) and, for some flows, voluntary certification and labeling. National governments remain central actors, even where private standards are important. Governance challenges are more numerous for inter-regional and global flows, centering on policy incoherence, diverging interests, legitimacy concerns, and high transaction costs. The literature is fragmented across disciplines and theoretical traditions (global value chains, global environmental governance, political ecology, telecoupling, etc.), with limited cross-citation and collaboration.

The authors propose a forward agenda around six themes: problem-centered research starting from impacts; telecoupling and displacement of environmental burdens, especially via Northern decoupling strategies; growing importance of South-South telecouplings; the ambivalent role of states in both inducing and mitigating telecoupling; complex interactions among public-private and place-based vs. flow-based governance; and the need for comparative analysis across different types of flows.

## Structured Metacoupling Extraction

### Coupling Classification
- Conceptual and empirical review of governance in globally telecoupled systems; strong focus on telecoupling.

### Intracoupling
#### Systems
- Not identified.
#### Flows
- Not identified.
#### Agents
- Not identified.
#### Causes
- Not identified.
#### Effects
- Not identified.

### Pericoupling
#### Systems
- Not identified.
#### Flows
- Not identified.
#### Agents
- Not identified.
#### Causes
- Not identified.
#### Effects
- Not identified.

### Telecoupling
#### Systems
- Sending systems producing commodities or resources.
- Receiving systems where consumption or disposal occurs.
- Spillover systems affected indirectly via diverted or transit flows.
#### Flows
- International trade in commodities like palm oil, soy, timber, metals, fish, biofuels, wastes.
- Financial flows tied to extractive industries and resource frontiers.
- Movements of people as migrants or tourists linked to environmental pressures.
#### Agents
- States, regional organizations, and international public bodies shaping rules.
- Firms across supply chains: investors, producers, traders, retailers, certifiers.
- Civil society actors and multi-stakeholder initiatives influencing standards.
#### Causes
- Global demand for resources and agricultural products in North and emerging Southern markets.
- Trade liberalization, investment incentives, and sectoral policies expanding cross-border chains.
- Governance gaps, weak enforcement, and fragmented policy regimes across jurisdictions.
#### Effects
- Deforestation, habitat loss, biodiversity decline, soil and water degradation in producer regions.
- Greenhouse gas emissions and pollution redistributed across distant regions.
- Burden shifting from consumption centers to exporting regions, often Global South.

### Cross-Coupling Interactions
- Interaction of place-based regulations with flow-based instruments like certification or trade bans.
- Polycentric mixes of public and private governance across levels create synergies and conflicts.
- Northern consumer-driven standards intersect with emerging Southern public standards and South-South trade.

### Research Gaps or Limitations
- Fragmented scholarship with weak cross-citation and limited integration of theoretical lenses.
- Under-study of South-South telecoupling, spillover systems, and non-consumer-facing commodities like sand.
- Limited comparative analysis of why different flows display distinct governance instrument profiles.

### Search Keywords
- telecoupling environmental governance global value chains
- global flows trade certification deforestation
- polycentric governance supply chain regulation

### Extraction Confidence
high
