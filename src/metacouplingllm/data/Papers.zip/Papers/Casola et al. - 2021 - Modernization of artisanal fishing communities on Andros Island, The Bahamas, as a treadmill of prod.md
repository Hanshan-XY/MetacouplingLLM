# Modernization of artisanal fishing communities on Andros Island, The Bahamas, as a treadmill of prod

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:31:51.098460+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Casola et al. - 2021 - Modernization of artisanal fishing communities on Andros Island, The Bahamas, as a treadmill of prod.pdf
- Year: unknown
- DOI: 10.1016/j.ocecoaman.2020.105487
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper examines how artisanal fishing communities on Andros Island, The Bahamas, experienced rapid modernization from the 1960s to the 1980s, and how their accounts relate to major social-environmental theories, including telecoupling and world-systems perspectives.

Geographically, the study focuses on multiple settlements across Andros, a so-called family island that historically depended on small-scale fisheries and gardening. The broader system context links Andros to the national core of Nassau/New Providence, as well as to international tourism and markets in the United States and United Kingdom.

The authors use a qualitative, emic approach. They conducted semi-structured interviews with 31 fishers aged 49-90 in 2018, using snowball sampling. Interview questions probed perceived changes in fishing practices, drivers of change, and perceived benefits and harms. Transcripts were coded thematically by two researchers to identify recurring patterns.

Participants described a shift from largely self-provisioning livelihoods based on small gardens and low-technology, nearshore fishing in wooden sail or sculling boats, toward motorized fiberglass vessels, diving-based harvest, and intensified extraction of conch, lobster, and finfish for distant markets and the tourism industry centered in Nassau. They perceived sharp declines in nearshore fish abundance, increasing dependence on imported food and purchased fuel and equipment, growing financial risk, and erosion of community-oriented sharing norms. At the same time, they recognized new opportunities in wage labor, guiding, and higher education, often off-island.

The findings align strongly with treadmill-of-production theory and an internalized world-systems logic, where Nassau functions as a domestic core exploiting peripheral islands such as Andros. Telecoupling is central: foreign tourists and off-island demand transmit new technologies (diving gear, motors) and market pressures that reshape local fishing and degrade local ecosystems, while benefits accrue mainly elsewhere. The study finds little evidence that modernization to date fits ecological modernization theory, though the authors suggest that expanding higher education and better enforcement of conservation policies could eventually move Andros toward more sustainable outcomes.

Thus, the paper is explicitly about telecoupling/metacoupling, using Andros as a case of tourism- and market-driven cross-scale interactions that restructure coastal livelihoods and environments.

## Structured Metacoupling Extraction

### Coupling Classification
- Study explicitly analyzes telecoupling via tourism and national core periphery dynamics
- Also addresses intracoupling within Andros fisheries and pericoupling with Nassau
- Links modernization, treadmill of production, and world systems theory to metacoupling

### Intracoupling
#### Systems
- Artisanal fishing communities on Andros Island
- Local Andros marine ecosystems and fisheries
- Andros household and community social systems
#### Flows
- Harvest of fish, conch, and lobster for subsistence then sale
- Spread of diving practices among Andros youth
- Shift from homegrown food and gardens to store groceries
#### Agents
- Andros artisanal fishers and their families
- Local shop owners, fish buyers, lodge owners
- Community leaders, pastors, local elders
#### Causes
- Local adoption of motors, fiberglass boats, diving gear
- Perceived depletion of nearshore fish prompting behavior change
- Generational shifts away from gardening and subsistence
#### Effects
- Declining nearshore fish, conch, and grouper stocks
- Greater financial risk and dependency on cash income
- Erosion of sharing norms and community cohesion

### Pericoupling
#### Systems
- Andros Island as resource periphery
- Nassau and New Providence as national core
- Other Bahamian family islands and marine protected areas
#### Flows
- Seafood shipments from Andros to Nassau tourism markets
- Labor migration of young Androsians to Nassau jobs
- National policies, education and enforcement institutions extending to Andros
#### Agents
- Nassau tourism operators and seafood buyers
- Bahamian government ministries and local districts
- Bahamas National Trust and Department of Marine Resources
#### Causes
- Expansion of Nassau tourism and urban economy
- National infrastructure investments in communications and electricity
- Creation of parks and fisheries regulations centered in core regions
#### Effects
- Concentration of modernization benefits in Nassau over Andros
- Intensified fishing pressure to supply urban and tourist demand
- Protected areas with weak local compliance and enforcement

### Telecoupling
#### Systems
- United States and British tourism origin regions
- Bahamas national tourism sector including Nassau
- Andros Island receiving telecoupled influences
#### Flows
- International tourists traveling to Bahamian destinations
- Transfer of diving techniques, equipment, and boating technology
- External market demand and prices for seafood species
#### Agents
- American and British tourists teaching diving
- Cruise lines, airlines, international tour companies
- Global seafood market intermediaries and investors
#### Causes
- Postwar globalization and growth of Caribbean mass tourism
- Improved international flights and cruise connectivity
- Rising global appetite for tropical seafood and marine recreation
#### Effects
- Acceleration of Andros fishing modernization and motorization
- Overharvest and ecological degradation concentrated on Andros
- Youth drawn into tourism-linked jobs off island or abroad

### Cross-Coupling Interactions
- Telecoupled tourism amplifies Nassau demand, which pericouples Andros resource extraction
- Intracoupled technological adoption on Andros is triggered by foreign tourists and Nassau markets
- World systems like hierarchy emerges within nation, shaping both peri and telecoupling outcomes

### Research Gaps or Limitations
- Qualitative single case focused on elder fishers limits generalizability
- Telecoupling analysis largely descriptive without quantitative flow measurements
- Limited empirical data on external actors such as foreign fleets and tourists

### Search Keywords
- Andros Island Bahamian fisheries modernization telecoupling
- treadmill of production world systems tourism core periphery
- artisanal fishing globalization Nassau seafood markets

### Extraction Confidence
high
