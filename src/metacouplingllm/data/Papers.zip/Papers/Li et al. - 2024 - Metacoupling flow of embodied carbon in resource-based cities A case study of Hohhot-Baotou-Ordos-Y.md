# Metacoupling flow of embodied carbon in resource-based cities A case study of Hohhot-Baotou-Ordos-Y

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:52:49.295191+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Li et al. - 2024 - Metacoupling flow of embodied carbon in resource-based cities A case study of Hohhot-Baotou-Ordos-Y.pdf
- Year: unknown
- DOI: 10.1016/j.energy.2024.134041
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This article analyzes how carbon emissions embodied in trade flow within and beyond a cluster of resource-dependent cities in northwestern China, using the metacoupling framework. The focal region is the Hohhot-Baotou-Ordos-Yulin (HBOY) urban agglomeration, a major coal, gas, and mineral base spanning Inner Mongolia and Shaanxi provinces. Adjacent systems are defined as the rest of Inner Mongolia and Shaanxi; all other Chinese provinces form the distant system. The work explicitly applies metacoupling concepts (intracoupling, pericoupling, telecoupling) and is directly about metacoupling/telecoupling.

The authors build a nested city-province multi-regional input-output (MRIO) model for 2017, link it to a sectoral CO2 inventory for 30 merged sectors (later grouped into seven), and compute carbon flows driven by final demand. They then compare a no-trade benchmark with trade scenarios (only adjacent trade, only distant trade, both) to assess how trade shifts the burden of emission reduction.

Within HBOY, Ordos is the sole net exporter of embodied carbon to the other three cities, mainly through heavy industry supplying construction and services. Between HBOY and adjacent regions, trade is slightly import-dominated: HBOY brings in more embodied carbon than it sends out, largely via heavy industry exchanges with the rest of Inner Mongolia and Shaanxi. In contrast, HBOY exports a large surplus of embodied carbon to distant provinces, especially coastal and central-eastern provinces that consume energy-intensive construction and industrial products. Embodied carbon imports from adjacent and distant systems are similar in magnitude, but exports to distant regions are several times higher.

Scenario analysis shows that adjacent trade modestly eases HBOY’s emission reduction pressure, while distant trade greatly increases it, particularly for mining and heavy industry. The study generalizes these results to Chinese resource-based cities, showing that most act as net embodied carbon producers for other regions. The authors call for responsibility-sharing and carbon compensation mechanisms between resource suppliers and beneficiary regions, using metacoupling analysis to design fair, cross-scale policy responses.

## Structured Metacoupling Extraction

### Coupling Classification
- Strongly relevant to intra, peri, and telecoupling of embodied carbon among Chinese regions.

### Intracoupling
#### Systems
- Four-city HBOY agglomeration as focal system
- Individual HBOY cities: Hohhot, Baotou, Ordos, Yulin
- Internal sectors: mining, heavy industry, services, construction
#### Flows
- Embodied carbon transfers among HBOY cities via intermediate and final demand
- Sectoral flows mainly from heavy industry and mining to construction and services
- Ordos exports embodied carbon to other HBOY cities
#### Agents
- City governments and firms in HBOY resource and industrial sectors
- Heavy industry, mining, and construction enterprises in HBOY
- Households and final consumers within HBOY
#### Causes
- Local demand for construction, infrastructure, and services
- Resource extraction and processing for HBOY economic development
- Industrial structure dominated by mineral and energy industries
#### Effects
- Ordos becomes main internal carbon exporter; others net importers
- Increased internal carbon reduction pressure on HBOY mining and heavy industry
- Local emissions mostly serve consumption outside production locations

### Pericoupling
#### Systems
- HBOY focal system linked with Nei Mongol and Shaanxi provinces
- Adjacent system includes areas of Nei Mongol and Shaanxi outside HBOY
- Shared regional policy and industrial chains across provincial borders
#### Flows
- Two-way embodied carbon trade between HBOY and adjacent system
- Net embodied carbon import by HBOY from adjacent provinces
- Heavy industry carbon flows into HBOY construction and services
#### Agents
- Provincial governments of Nei Mongol and Shaanxi
- Heavy industry and mining firms in adjacent regions
- Regional planners coordinating HBOY development plans
#### Causes
- Geographical proximity enabling integrated supply chains
- Policy coordination for joint development of energy and heavy industry
- Adjacent regions supplying raw materials and intermediate goods
#### Effects
- HBOY imports relieve some local emission reduction pressure overall
- Hohhot benefits from adjacent imports; Ordos and Yulin face higher burdens
- Nearby regions experience significant outflow of embodied carbon

### Telecoupling
#### Systems
- HBOY focal system and distant Chinese provinces beyond Nei Mongol, Shaanxi
- Southeastern coastal provinces as major distant receivers
- National energy and materials market linking HBOY to rest of China
#### Flows
- Large net embodied carbon exports from HBOY to distant system
- Heavy industry carbon flows to distant construction and service sectors
- Coal, energy-intensive products driving substantial virtual carbon transfer
#### Agents
- Energy and heavy-industry enterprises in HBOY exporting nationwide
- Construction and manufacturing sectors in distant importing provinces
- National policymakers setting carbon neutrality and trade rules
#### Causes
- National demand for energy, steel, cement, and chemical products
- Economic specialization of HBOY as resource and energy base
- Interprovincial trade patterns favoring production in resource-based cities
#### Effects
- HBOY bears large production-based emissions serving distant consumption
- Telecoupling greatly increases HBOY carbon reduction pressure
- Distant provinces gain consumption benefits with lower local emissions

### Cross-Coupling Interactions
- Similar import volumes from adjacent and distant systems but much higher exports to distant regions.
- Trade scenarios show adjacent flows mitigate, telecoupled flows amplify HBOY reduction pressure.
- Sectoral heavy industry flows link intra, peri, and telecoupling across multiple destinations.

### Research Gaps or Limitations
- City-level MRIO data outdated and constructed with simplifying assumptions.
- Adjacent versus distant system boundaries partly subjective and domestically limited.
- International trade and other environmental elements beyond CO2 not fully incorporated.

### Search Keywords
- metacoupling embodied carbon HBOY China MRIO
- resource-based cities peri telecoupling carbon flows
- interprovincial trade carbon leakage compensation mechanisms

### Extraction Confidence
high
