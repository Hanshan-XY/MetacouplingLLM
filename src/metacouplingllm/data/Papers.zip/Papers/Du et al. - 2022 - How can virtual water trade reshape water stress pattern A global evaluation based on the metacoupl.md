# How can virtual water trade reshape water stress pattern A global evaluation based on the metacoupl

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:42:02.531105+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Du et al. - 2022 - How can virtual water trade reshape water stress pattern A global evaluation based on the metacoupl.pdf
- Year: unknown
- DOI: 10.1016/j.ecolind.2022.109712
- OA status: gold
- License: cc-by-nc-nd
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This paper examines how international trade in virtual water - water embodied in products - alters global patterns of water stress, using the metacoupling framework. The study is explicitly about metacoupling and telecoupling.

The authors conduct a global analysis for 2005-2015, combining the Eora multi-regional input-output database with environmental extensions to estimate virtual water flows among 190 economies. They distinguish three kinds of water use linkages: intracoupling (domestic water used for domestic consumption), pericoupling (virtual water traded between neighboring countries), and telecoupling (virtual water traded between distant countries). Water stress is assessed with an indicator consistent with UN SDG 6.4.2, comparing total withdrawals to renewable water resources after reserving a fixed share for environmental flows. Multiple trade scenarios are constructed: no trade, real-world trade, only-nearby trade, and only-distant trade.

Globally, local water supplies satisfy about four-fifths of water consumption. Cross-border virtual water is dominated by distant trade; distant imports are roughly five times larger than nearby imports. Developed countries import much more virtual water per country than developing ones and are far more reliant on it, though this reliance declined over time while developing countries dependence increased. Countries with lower per capita renewable water show higher dependence on virtual water imports than water-abundant countries.

Scenario analysis shows that, relative to a no-trade world, virtual water trade generally lowers average global water stress, with telecoupled trade responsible for almost all of the net relief. Yet the benefits are uneven: in 2005 trade reduced water stress in most developed countries but increased it in a majority of developing countries. Over time, this imbalance weakened somewhat. Trade tends to alleviate stress in the most water-scarce countries while raising it in many better-endowed ones.

The work demonstrates how metacoupling offers a systematic way to separate local, nearby, and distant water linkages, attribute environmental effects to different trade distances, and inform more equitable and sustainable water and trade policies.

## Structured Metacoupling Extraction

### Coupling Classification
- Global assessment of intracoupling, pericoupling, telecoupling in virtual water trade and water stress

### Intracoupling
#### Systems
- National coupled human natural systems using domestic water for internal consumption
- Countries grouped as developed versus developing for internal water use
- Countries grouped by water stress levels based on per capita renewable resources
#### Flows
- Internal water footprint supporting most national consumption
- Domestic water withdrawals for goods and services used domestically
- Domestic water used to produce exports in absence of trade
#### Agents
- National governments managing internal water withdrawals
- Domestic producers and consumers demanding water intensive products
- Water resource and planning agencies within countries
#### Causes
- Population growth and economic development driving local water demand
- Climate variability influencing renewable internal water resources
- National policies on water conservation and resource exploitation
#### Effects
- Local water resources provide about four fifths of global water consumption
- Internal withdrawals determine baseline SDG 6.4.2 water stress levels
- Changes in internal use modify dependence on virtual water imports

### Pericoupling
#### Systems
- Neighboring countries trading water intensive products
- Adjacently linked sending and receiving systems via shared borders
- Regional groups engaging in nearby virtual water exchanges
#### Flows
- Virtual water embedded in traded goods between bordering countries
- Nearby virtual water imports that are much smaller than distant imports
- Cash and commodities exchanged alongside regional virtual water flows
#### Agents
- Neighboring national governments and customs authorities
- Regional trade blocs facilitating cross border commerce
- Firms and supply chains operating in border regions
#### Causes
- Geographical proximity reducing transaction and transport costs
- Regional integration policies and trade agreements
- Complementarities in land, water, and production structures among neighbors
#### Effects
- Nearby trade accounts for minor share of global virtual water transfers
- Pericoupling slightly reduces average global water stress
- Nearby imports alleviate stress in about half of countries but worsen some

### Telecoupling
#### Systems
- Distant sending countries exporting virtual water through products
- Distant receiving countries importing virtual water to support consumption
- Spillover countries indirectly affected by reconfigured trade and water use
#### Flows
- Large scale virtual water transfers between non bordering countries
- Distant imports roughly five times volume of nearby imports globally
- Net distant virtual water flows from water scarce to water rich regions
#### Agents
- National governments engaging in long distance trade policies
- Multinational companies organizing global supply chains
- International organizations monitoring trade, water and sustainability
#### Causes
- Global demand for food, goods, and services overriding local water limits
- Comparative advantages in water, land, labor, and technology
- Trade liberalization and globalization of production networks
#### Effects
- Distant trade contributes nearly all global water stress alleviation
- Telecoupling often eases stress in developed and water rich countries
- Telecoupling can intensify stress in many developing and water scarce exporters

### Cross-Coupling Interactions
- Comparison of intracoupling versus intercoupling intensity by development and water endowment groups
- Trade scenarios isolate contributions of nearby versus distant telecoupling to water stress changes
- Internal water use and external virtual flows jointly shape SDG 6.4.2 water stress patterns

### Research Gaps or Limitations
- Limited temporal detail in water intensity data within chosen input output database
- Neighbor versus distant classification based only on shared borders not continuous distance
- Need for further metacoupling studies on specific systems, spillovers, and multi resource nexuses

### Search Keywords
- metacoupling virtual water trade telecoupling water stress SDG 6.4.2
- intracoupling pericoupling distant nearby trade global input output Eora
- renewable water per capita water stress warning line Falkenmark

### Extraction Confidence
high
