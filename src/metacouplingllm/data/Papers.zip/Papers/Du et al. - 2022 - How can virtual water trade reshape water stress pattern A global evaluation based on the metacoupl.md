# How can virtual water trade reshape water stress pattern? A global evaluation based on the metacoupling perspective

![](images/6b6d9ba10ebbe5127055c26368b9d3ed2e4a42a913419ac0aec604a906ed2a48.jpg)

Yueyue Du a, Dandan Zhao b,c, Sijing Qiu a, Feng Zhou a, Jian Peng a,*

$^{a}$ Laboratory for Earth Surface Processes, Ministry of Education, College of Urban and Environmental Sciences, Peking University, Beijing 100871, China   
<sup>b</sup> Water & Development Research Group, Department of Built Environment, Aalto University, PO Box 15200, 00076 Espoo, Finland   
$^{c}$ School of Environmental Science and Engineering, Southern University of Science and Technology, Shenzhen 518055, China

# ARTICLEINFO

# Keywords:

Virtual water trade

Environmental impacts

Water stress

Trade scenarios

Metacoupling

Telecoupling

# ABSTRACT

With water scarcity increasingly becoming a growing global risk, it is prevalent to explore water supply-demand interaction within and beyond national borders driven by global virtual water trade and its effects on water sustainability. However, there is little study on system integration of differential environmental impacts of various types of trade. Based on metacoupling framework highlighting human-nature interactions across spacewithin a place (intracoupling), between adjacent places (pericoupling), and between distant places (telecoupling), this study quantified the linkages and intensities of three kinds of coupling processes during global virtual water trade for the first time. Correspondingly, water stress changes under a set of trade scenarios were evaluated based on the indicator of UN SDG 6.4.2 to distinguish the influence of trade taking place on different spatial scales. Results show that during 2005-2015, local water resources supported $80\%$ of global water consumption. Distant virtual water import was about 5 times in volume as large as adjacent virtual water import, alleviating $99.8\%$ of global average water stress. Virtual water trade reduced water stress in $86\%$ of developed countries and increased that in $71\%$ of developing countries in 2005. Owing to trade, water stress in many countries with poor water resources endowment declined while that of many with relatively good endowment went up from 2005 to 2015. Our findings can help to systematically understand the influence of virtual water trade on water stress change and provide scientific guidance for sustainable water management and regional regulations.

# 1. Introduction

The sustainable management of global water resources is critical to achieving productivity and maintaining ecological security (Hoekstra, 2014; WEF, 2020). Water conservation would enable national economies, agricultural and food sectors to better adapt to climate change and to meet the needs of a growing population (Bo et al., 2021; D'Odorico et al., 2019; Mekonnen and Hoekstra, 2016), which has been highly called for in the United Nations' Sustainable Development Goals for 2030 (Hoekstra et al., 2017; UN-Water, 2021; Vanham et al., 2018). In this context, studies on virtual water (indicating the water embedded in a product, that is, the water consumed during its process of production) are increasingly popular (Clark et al., 2015; Dalin et al., 2012). Virtual water trade can provide an alternative way of supplying water resources without adverse environmental consequences and reducing local water pressure (Antonelli et al., 2017). Relevant theories have been applied in

water-scarce countries and regions to some extent since proposed (Arto et al., 2016; Cai et al., 2020; Hoekstra and Mekonnen, 2012).

The integrated framework of metacoupling involves human-nature interactions across space- within a place (intracoupling), between adjacent places (pericoupling), and between distant places (telecoupling) (Liu, 2017). It is a useful tool for depicting human interaction with nature and with its unique systematic viewpoint and interdisciplinary approach (Liu and Yang, 2013; Liu et al., 2015). By introducing feedbacks and trade-offs of multiple systems (i.e., sending, receiving and spillover system) (Liu, 2017), the novel metacoupling framework helps to improve policy effectiveness in terms of global trade, transnational land transaction, species invasion, knowledge dissemination, and ecosystem management (Carlson et al., 2018; Dou et al., 2018; Lenschow et al., 2016; Sun et al., 2018).

With respect to the application into water-related research, the metacoupling framework provides a standard, systematic and flexible

tool for evaluating water sustainability of various systems such as urban, agriculture, drylands, groundwater systems (Deines et al., 2015; Luetkemeier et al., 2021; Xu et al., 2020a; Yao et al., 2020). For example, Deines et al. (2015) analyzed the water-stressed megacity of Beijing's imported water supply which involves three types of water telecouplings: inter-basin water transfers via South-to-North Water Diversion Project, virtual water imports, and Payment for Ecosystem Services Programme to upstream regions in order to increase water supply quantity and quality. Yao et al. (2020) evaluated telecoupling effects of vegetable trade and tourism on water saving and poverty alleviation in drylands and revealed that water sustainability was determined by climate and social attributes. Luetkemeier et al. (2021) sorted literature-based examples of European groundwater systems, and elaborated on telecoupling processes such as trade and seasonal tourist flows which can induce groundwater depletion and contamination but may also help to conserve the resource. Xu et al. (2020a) explored impacts of irrigated agriculture on food-energy-water- $\mathrm{CO}_{2}$ nexus across metacoupled systems, treating North China Plain and the rest of China as food sending and receiving systems, respectively.

However, only a few studies have applied the metacoupling framework to quantify the interaction and the associated impacts of various kinds of water use (Du et al., 2022a, Du et al., 2022b). For instance, Du et al. (2022a) evaluated the extent to which virtual water transfer deviates from possible ideal expectations (i.e., virtual water flows from water-abundant regions to water-scarce ones), and its impact on global water use sustainability. Furthermore, referring to the ideas of sending system and receiving system of metacoupling framework, Du et al. (2022a) quantified national contribution to global virtual water trade vulnerability based on virtual water export network and tracked responsibility for such national contribution based on virtual water import network. In another example, Du et al. (2022b) analyzed the local and non-local drivers of consumption-based water use of different sectors and provinces in China based on the perspective of metacoupling. The insufficient attention to water-related metacouping research would potentially lead to a lack of systematic understanding of virtual water's role on the interconnected feedback of global and local water consumption.

National water consumption is usually supported by internal water footprint (water footprint of goods and services produced in this exact country and used for domestic consumption) and virtual water import (Arto et al., 2016; Hoekstra et al., 2011), which corresponds to intracoupling and intercoupling respectively in the context of metacoupling framework. The intracoupling process, internal water footprint, reflects the interplay between local natural and human systems in terms of water resource exploitation and water conservancy (Vanham and Bidoglio, 2013). The intercoupling process, virtual water flow between countries, can be further divided into pericoupling (virtual water transfer between adjacent countries) and telecoupling (virtual water transfer between distant countries). Taking virtual water flow as a carrier, virtual water trade creates interactions between coupled human and natural systems of different countries (Xu et al., 2020b). For instance, a country with scarce water resources but rich cultivated land may export virtual water by selling grain to a water-rich country with a high population density and poor land resources, which exacerbates its water pressure (Brindha, 2017; Duarte et al., 2016). During this process, human social systems in water-rich countries affect natural systems in water-poor countries by diverting their demands through trade.

Ignoring transnational interactions leads to a partial understanding of the mechanisms behind global environmental change and is therefore likely to undermine efforts to achieve global sustainability (Liu et al., 2015). Assessing the pattern of virtual water flow transferring from relatively water-deficient countries to relatively water-rich countries and its temporal changes will help clarify the role of virtual water trade in alleviating regional water shortage (Distefano and Kelly, 2017). Quantifying virtual water transfers between distant countries and neighboring ones helps reveal potential key virtual water trading

partners for a given country. Comparison between pericoupling and telecoupling relationships can also show socioeconomic and ecological impacts from countries with different geographical distances. Nevertheless, there are no studies yet on reshaping global water stress patterns under virtual water transfer based on the metacoupling framework. Besides, although the overall assessment about the dependence on foreign water resources and global water stress exists (Clark et al., 2015; Distefano and Kelly, 2017), performance and trends of types of country groups under different trade processes need to be further clarified.

Based on the above research gaps, this article is the first to evaluate the impacts of various types of global virtual water trade on water stress patterns with the guidance of metacoupling framework. Main objectives and work flows as follows: (1) to reveal the coupling linkage and quantify the intensity of intracoupling, pericoupling and telecoupling process, and the supporting role of different coupling types in meeting national water demand; (2) to analyze the impact of virtual water trade corresponding to various coupling types on the relationship between national water supply and demand by comparing changes in water stress change under with-trade and without-trade scenarios. Furthermore, the differential impact between developing countries and developed countries, and between countries with rich or poor water resources endowment is expected to be revealed; (3) to discuss different roles of nearby virtual water trade and distant virtual water trade in reshaping water stress pattern by comparing the water stress change under only-nearby-trade scenarios and only-distant-trade scenarios.

# 2. Methods

# 2.1. Environmentally-extended input-output analysis

Environmental expansion input-output analysis (EEIO) is developed based on the economics input-output analysis (Lenzen et al., 2013). It is mainly used to evaluate the environmental impact and its flow in products and services implicit in trade (Kitzes, 2013). At present, there are some mainstream EEIO databases including WORLD Input-Output Database (WIOD), Inter-country and Global Input-Output Accounting Table (FIGARO), OECD Inter-country Input-Output Table (OECD-ICIO), Global Trade Analysis Project (GTAP) of Agricultural Economics Department, Purdue University, EXIOBASE Database of Leiden University, and Eora Global Supply Chain Database (Eora) of the University of Sydney (Wang et al., 2020).

The Eora database is selected for this study considering its high resolution in time, space and sectors, especially in spatial resolution. In particular, some countries with small economies have little data available in the statistical system of the United Nations. However, based on a variety of realistic data combined with optimization algorithm, Eora covers 190 economics around the world, meeting our data needs for global-level evaluation (https://www.worldmrio.com). The following is how it works:

Assuming there are $m$ countries and every country has $n$ sectors and $k$ kinds of final demand, the monetary output of sector $i$ in country $R$ can be acquired by the following formula (Fang et al., 2021):

$$
x _ {i} ^ {R} = \sum_ {S = 1} ^ {m} \sum_ {j = 1} ^ {n} Z _ {i j} ^ {R S} + \sum_ {S = 1} ^ {m} \sum_ {t = 1} ^ {k} y _ {i t} ^ {R S} \tag {1}
$$

where $x_{i}^{R}$ is the total monetary output of Sector $i$ in Country $R$ , $Z_{ij}^{RS}$ the monetary value of goods or services imported from Sector $i$ in Country $R$ to Sector $j$ in Country $S$ for intermediate use, and $y_{it}^{RS}$ represents the final demand $t$ of Country $S$ that is supported by sector $i$ of country $R$ . The above formula can be further deformed into:

$$
X = (I - A) ^ {- 1} Y = L Y \tag {2}
$$

where $I$ is the identity matrix; $L$ , also known as $(I - A)^{-1}$ , is the Leontief inverse matrix. It is the complete demand coefficient matrix, suggesting

direct and indirect monetary effects from a unit change in the final demand. $X$ is $[x_i^R]$ and $Y$ is $[y_{it}^{RS}]$ in the formula (1). $A$ is the matrix of direct input coefficient and equals $[a_{ij}^{RS}]$ , which represents the monetary input from Sector $i$ in Country $R$ to produce per unit output of Sector $j$ in Country $S$ .

$$
a _ {i j} ^ {R S} = Z _ {i j} ^ {R S} / x _ {j} ^ {s} \tag {3}
$$

By the addition of supplementary environmental accounts, the biophysical input-output balance can be calculated using the following equation:

$$
d _ {i} ^ {R} + \sum_ {S = 1} ^ {m} \sum_ {j = 1} ^ {n} \varepsilon_ {j} ^ {S} Z _ {j i} ^ {S R} = \varepsilon_ {i} ^ {R} x _ {i} ^ {R} \tag {4}
$$

where $d_i^R$ is the direct water resource intensity coefficient, denoting the direct freshwater withdrawal by Sector $i$ in Country $R$ . Meanwhile, $\varepsilon_i^R$ is termed as embodied water resource intensity coefficient, denoting the total (direct and indirect) freshwater used by Sector $i$ in Country $R$ to produce goods or services (Chen et al., 2018). Then water resources embodied in imports (FI), exports (FE) can be formulated as:

$$
F I ^ {R} = \sum_ {S = 1 (S \neq R)} ^ {m} \sum_ {j = 1} ^ {n} \left(\sum_ {i = 1} ^ {n} \left(\varepsilon_ {j} ^ {S} Z _ {j i} ^ {S R}\right) + \sum_ {t = 1} ^ {k} \left(\varepsilon_ {j} ^ {S} f _ {j t} ^ {S R}\right)\right) \tag {5}
$$

$$
F E ^ {R} = \sum_ {i = 1} ^ {n} \sum_ {S = 1 (S \neq R)} ^ {m} \left(\sum_ {j = 1} ^ {n} \left(\varepsilon_ {i} ^ {R} Z _ {i j} ^ {R S}\right) + \sum_ {t = 1} ^ {k} \left(\varepsilon_ {i} ^ {R} f _ {i t} ^ {R S}\right)\right) \tag {6}
$$

# 2.2. Water stress warning line

The difference of water resources endowment is one of the driving factors of virtual water transfer. There are various indicators of water resources endowment, such as water resource density (the ratio of total water resources to land area), surface water resource proportion (the ratio of surface water resources to total water resources), precipitation, runoff depth, etc. This paper finally adopts the index of "renewable water resources per capita" (PWRC), originally proposed by Falkenmark et al. (1989) and commonly used by the Food and Agriculture Organization of the United Nations (FAO) in the comprehensive evaluation of water resources development and utilization. For example, according to 2012 statistics, China's PWRC was just $2007\mathrm{m}^3$ per person per year, only 25 percent of the world average. Based on the value of PWRC, the FAO

![](images/4fbbee6d54a1021b21cbf94f4be9d3d9e55869a1c0732774fe6276b1ffcb04bf.jpg)  
Fig. 1. Water stress warning line.

developed a water-stress warning line system with $1700\mathrm{m}^3$ per person per year being the threshold (Fig. 1). This is also the most widely-used standard to evaluate water shortage across the world.

As shown in Fig. 1, the level of PWRC of $1700\mathrm{m}^3$ per person per year is defined as the water stress threshold. If the amount of PWRC is higher than this standard, the country's water shortage will occur irregularly or locally. Below the threshold, water stress often occurs in countries or regions. Below $1000\mathrm{m}^3$ per person per year, water scarcity significantly limits economic development and human health and well-being. Below $500\mathrm{m}^3$ per person per year, water becomes a major constraint on basic living security (Damkjaer and Taylor, 2017). For the convenience of presentation, different water shortage degrees are expressed as relatively water abundance (level 1, PWRC $\geq 1700$ ), is experiencing water stress (level 2, $1000 \leq \mathrm{PWRC} < 1700$ ), water scarcity (level 3, $500 \leq \mathrm{PWRC} < 1000$ ) and severe scarcity (level 4, PWRC $< 500$ ). In other words, the worse the water resource endowment is, the higher the water pressure level is.

# 2.3. Conceptual model for applying the metacoupling framework to global virtual water trade

Growing population, ever-changing climate patterns, rapidly increased water demand, institutional policies, and land-use transitions all interact to influence available water supply and use, potentially with nonlinear effects and feedbacks. Therefore, global water use systems are coupled human and natural systems (CHANS; Liu et al., 2007) where socio-economic and environmental components interact in complex ways and need to take a systems approach (Deines et al., 2015; Luetkemeier et al., 2021).

To reflect human-nature interactions between distant CHANS, the framework of telecoupling (socioeconomic and environmental interactions over distances) has been developed (Liu et al., 2013). It can be complementary to existing frameworks while crucially expanding their scope to address multiple interacting systems more fully, thus addressing key features of global water consumption and virtual water trade. However, no frameworks have explicitly integrated human-nature interactions between adjacent coupled systems. Thus, metacoupling framework was further proposed on the basis of telecoupling framework (Liu, 2017). The meta-coupling processes include intracoupling and intercoupling, the latter of which is further divided into pericoupling and telecoupling. There are five major components in metacoupled systems (and also apply to the telecoupled systems): (1) connected CHANS that fulfil roles of sending, receiving and spillover systems; (2) flows of material, energy and information among these CHANS which produce effects; (3) agents who facilitate or hinder flows; (4) causes that produce the different kinds of coupling processes; and (5) effects generated.

The integration of metacoupling frameworks can be fully reflected via various flows involving regional integration (e.g., one country imports grain from another country, thus forming a substitution between these exporters in terms of agricultural water spillovers), sectoral integration (e.g., one agricultural sector supplies another industrial sector with raw materials), and process integration (e.g., final water demand drives intermediate water consumption). The addition of a metacoupling framework into water-related research may provide a systematic perspective to understand the inter-regional and inter-sectoral water linkages, which helps decision makers consider how to develop and integrate sustainable water management policies. Particularly, flow-based governance should be encouraged to investigate the relationship between systems and make tailored responses, by tracking where and how key virtual water flows start, develop, and end (Liu, 2017; Liu et al., 2013).

In Fig. 2, we develop a conceptual model for applying the metacoupling framework to global water use systems including domestic water consumption and international virtual water trade. Virtual water exporters and importers are the sending and receiving systems,

![](images/7d717639e3f0374e60b7f8fa9165aac19c83a6fb9f7b7eab694a17c7be91aa8b.jpg)  
Fig. 2. Different kinds of coupling types and processes in the global virtual water trade.

respectively. Other components involve flows (virtual water and cashes), causes (drivers of water consumption or virtual water trade), effects (influence of virtual water trade on domestic water stress), and agents (countries, economics and multinational companies involved in the supply chain, etc.). The intracoupling process refers to the local water consumption within the country, and the intercoupling includes pericoupling (i.e., importing virtual water import from neighboring countries) and telecoupling (i.e., importing virtual water for distant countries) (Fig. 2).

Applying the metacoupling framework to virtual water trade issue, we quantify and compare the intensity of intracoupling and intercoupling in three dimensions: the global overall, developing countries versus developed ones, and countries above water stress warning line versus countries below water stress warning line. The absolute value of intracoupling and intercoupling intensity is defined as the volume of internal water consumption and virtual water import. The proportional relationship between the intracoupling and intercoupling is expressed as:

$$
r _ {1} = \frac {\text {v o l u m e o f v i r t u a l w a t e r i m p o r t}}{\text {v o l u m e o f i n t e r n a l w a t e r c o n s u m p t i o n}} \tag {7}
$$

The larger the value of $r_1$ is, the higher the ratio of water import to internal water consumption is. That is to say, the greater the support of virtual water import to meet local water consumption demand is, and the higher the reliance on imported water is.

Breaking down the intercoupling into pericoupling and telecoupling, we can express the relationship between the pericoupling and telecoupling as the following formula:

$$
r _ {2} = \frac {\text {v o l u m e o f n e a r b y v i r t u a l w a t e r i m p o r t}}{\text {v o l u m e o f d i s t a n t v i r t u a l w a t e r i m p o r t}} \tag {8}
$$

where the nearby virtual water import refers to virtual water imported from neighboring countries, and the distant water import refers to virtual water imported from the remote country. The sum of the two is equal to the amount of virtual water import, namely the numerator of $\mathbf{r}_1$ . The greater the value of $\mathbf{r}_2$ is, the higher the reliance on water imported

from neighboring countries is.

# 2.4. Water stress change under different trade scenarios

The current main approaches for assessing the interaction and impacts of water use include indicator systems (Schlor et al., 2018), system dynamic models (Zhang et al., 2019; Wang et al., 2019), and input-output (Feng et al., 2014; Zhao et al., 2021a, Zhao et al., 2021b) or ecological network analysis (Wu et al., 2016; Yang et al., 2012). For instance, Cai et al. (2021) exclusively developed the composite SDG 6 index on the basis of the SDG 6 targets to investigate what policy measures were adequate to curb water risk. Yao et al. (2020) adopted a composite water scarcity index to evaluate the vegetable trade and tourism on both water-saving and poverty alleviation, including three sub-indicators of the availability, affordability and adaptability. Wang et al. (2019) used the Bow river basin of Canada as a case study to provide users with social, economic and environmental assessments by introducing a comprehensive modeling framework for Integrated Water Resources Management (IWRM). In this study, we combined the approaches of indicator system and input-output analysis together, employing the water stress to characterize the environmental impact of water use under the guidance of metacoupling framework.

To be specific, UN SDG Indicator 6.4.2 defines the level of water stress, which is measured by the proportion of freshwater withdrawal to freshwater resources available (https://knowledge.unccd.int/drought-toolbox-action/un-sdg-642-water-stress-methodological-guide). Freshwater withdrawal as a proportion of available freshwater resources is the ratio between total freshwater withdrawn by major economic sectors and total renewable freshwater resources, after taking into account environmental water requirements. This indicator is also known as water withdrawal intensity and will measure progress towards SDG Target 6.4.

The global indicator on water stress tracks the level of pressure that human activities exert over natural freshwater resources, indicating the environmental sustainability of the use of water resources. A high level of water stress has negative effects on social and economic development,

increasing competition and potential conflict among users. This calls for effective supply and demand management policies. Securing environmental flow requirements is essential to maintaining ecosystems healthy, resilient and available for future generations. This indicator addresses the environmental component of the target 6.4.

Based on this concept, we attempt to identify the influence of water import (in terms of virtual water net importing countries) or external water demand (in terms of virtual water net exporting countries) on local water pressure by comparing water stress change under with-trade scenario and without-trade scenario. Thus, we are able to explore the influence of virtual water trade which takes place under the interaction between local water supply, local water demand, foreign water supply, and foreign water demand.

The basic hypothesis of this paper is as follows: under without-trade scenario, virtual water net importers will generate more local water withdrawals and have a greater negative effect on local water resources (indicating internal renewable water resources, that is, long-term average annual flow of rivers and recharge of aquifers generated from endogenous precipitation). Double counting of surface water and groundwater resources is avoided by deducting the overlap from the sum of the surface water and groundwater resources. This is because with the help of virtual water trade, countries acting as virtual water net importers can save water resources consumed by domestic production through import. Under without-trade scenario, local water resources of virtual water net exporters could provide more support for local consumption. In this case, local water withdrawals could be reduced given there is no need to meet foreign demand.

The original formula of UN SDG Indicator 6.4.2 is as follows:

$$
\text {Water stress} (\%) = \frac {T F W W}{T R W R - E F R} * 100 \tag{9}
$$

where water stress refers to local water pressure of a target country. TFWW is the total freshwater withdrawal, namely the total freshwater drawn by major economic sectors. TRWR is the amount of total renewable freshwater resources in a country. EFR refers to environmental flow requirements. Although in the actual situation, environmental flow requirements have different values in each watershed (Acreman and Dunbar, 2004), this paper only roughly estimates on the national scale and considers that the same EFR ratio factor is possible to be used globally. Referring to the standard proposed by Richter et al. (2012) - "environmental water demand is $80\%$ of monthly runoff", the EFR of each country is finally assigned to be $80\%$ of its TRWR.

Next, several trade scenarios are proposed based on SDG Indicator 6.4.2 (Table 1).

Local water stress under with-trade scenario:

$$
\text {R a t i o} = \frac {L}{T ^ {*} 0 . 2} \tag {10}
$$

Local water stress under without-trade scenario:

Table 1 Water stress under different trade scenarios.   

<table><tr><td>Trade scenarios</td><td>Scenario interpretation</td><td>Water stress</td></tr><tr><td>Without-trade scenario</td><td>No trade at all. All countries cannot rely on virtual water import</td><td>L+Vimport_net/T*0.2.</td></tr><tr><td>With-trade scenario</td><td>Global trade exists in the real world</td><td>L/T*0.2.</td></tr><tr><td>Only-distant-trade scenario</td><td>Virtual water trade only takes place between distant countries</td><td>L+Vimport_distant-Vexport_distant/T*0.2</td></tr><tr><td>Only-nearby-trade scenario</td><td>Virtual water trade only takes place between nearby countries</td><td>L+Vimport_neighbor-Vexport_neighbor/T*0.2</td></tr></table>

$$
\text {R a t i o} ^ {*} = \frac {L + V _ {\text {i m p o r t - n e t}}}{T ^ {*} 0 . 2} \tag {11}
$$

where $L$ represents local water withdrawal, $T$ is the total national renewable water resources, $V_{import\_net}$ is the volume of virtual water net import.

Change in water pressure affected by trade can be expressed as follows:

$$
\text {C h a n g e} = \text {R a t i o} - \text {R a t i o} ^ {*} \tag {12}
$$

Degree of change in local water stress:

$$
\text {D e g r e e o f c h a n g e} = \frac {\text {R a t i o} - \text {R a t i o} ^ {*}}{\text {R a t i o} ^ {*}} \tag {13}
$$

The virtual water net import is a vector containing both quantity and direction information, so the modified formula is applicable to both the net importing country and the net exporting country.

In addition, with-trade scenario is further divided into scenario with only nearby trade and scenario with only distant trade. According to the definition of metacoupling framework, the former means that virtual water trade only takes place between neighboring countries, while the latter means that virtual water trade only takes place between distant countries (Xu et al., 2020b). The state of adjacent and distant depends on whether two countries share a border. The formula for water stress change considering trade sources is as follows:

Under only-nearby-trade scenario, the change of water stress with the influence of trade:

$$
C _ {\text {n e i g h b o r}} = \frac {L}{T * 0 . 2} - \frac {L + V _ {\text {i m p o r t . n e i g h b o r}} - V _ {\text {e x p o r t . n e i g h b o r}}}{T * 0 . 2} \frac {V _ {\text {e x p o r t . n e i g h b o r}} - V _ {\text {i m p o r t . n e i g h b o r}}}{T} * \tag {14}
$$

Under only-distant-trade scenario, the change of water stress with the influence of trade:

$$
C _ {\text {d i s t a n t}} = \frac {L}{T * 0 . 2} - \frac {L + V _ {\text {i m p o r t - d i s t a n t}} - V _ {\text {e x p o r t - d i s t a n t}}}{T * 0 . 2} \frac {V _ {\text {e x p o r t - d i s t a n t}} - V _ {\text {i m p o r t - d i s t a n t}}}{T} * \tag {15}
$$

Under only-nearby-trade scenario, degree of change in local water stress:

$$
D _ {\text {n e i g h b o r}} = \frac {C _ {\text {n e i g h b o r}}}{\frac {L + V _ {\text {i m p o r t} - \text {n e i g h b o r}} - V _ {\text {e x p o r t} - \text {n e i g h b o r}}}{T ^ {*} 0 . 2}} = \frac {T ^ {*} C _ {\text {n e i g h b o r}}}{5 ^ {*} \left(L + V _ {\text {i m p o r t} - \text {n e i g h b o r}} - V _ {\text {e x p o r t} - \text {n e i g h b o r}}\right)} \tag {16}
$$

Under only-distant-trade scenario, degree of change in local water stress:

$$
D _ {\text {d i s t a n t}} = \frac {C _ {\text {d i s t a n t}}}{\frac {L + V _ {\text {i m p o r t} , \text {d i s t a n t}} - V _ {\text {e x p o r t} , \text {d i s t a n t}}}{T ^ {*} 0 . 2}} = \frac {T ^ {*} C _ {\text {d i s t a n t}}}{5 ^ {*} \left(L + V _ {\text {i m p o r t} , \text {d i s t a n t}} - V _ {\text {e x p o r t} , \text {d i s t a n t}}\right)} \tag {17}
$$

where $C_{\text{neighbor}}$ is water stress change under the influence of nearby trade, $C_{\text{distant}}$ is water stress change under the influence of distant trade, $D_{\text{neighbor}}$ is degree of water stress change under the influence of nearby trade, $D_{\text{distant}}$ is degree of water stress change under the influence of distant trade, $V_{\text{import\_neighbor}}$ is the volume of virtual water import from neighboring countries, $V_{\text{export\_neighbor}}$ is the volume of virtual water export to neighboring countries, $V_{\text{import\_distant}}$ is the volume of virtual water import from distant countries, $V_{\text{export\_distant}}$ is the volume of virtual water export to distant countries.

# 3. Results

# 3.1. The metacoupling process in global virtual water trade

# 3.1.1. Global overview

The metacoupling intensity of global virtual water trade was shown in Fig. 3. Compared with cross-border trade, local water resources were

![](images/f6b20f1e14d39f19581f07fa9f60046232b141bec97b0acf2b54911c7dc9a693.jpg)

![](images/94c6bb83434581bf5c2a0e432765b177e2a49380025931f452f70c7e1d404a57.jpg)  
Fig. 3. (a). Quantity of internal water consumption, nearby and distant virtual water trade. (b). Ratio of virtual water trade to internal water consumption and that of nearby virtual water trade to distant virtual water trade.

the main source of local water needs, accounting for about $80\%$ of the total global water consumption (Fig. 3a). In cross-border trade, the amount of distant virtual water transfer was much higher than that between neighboring countries, and the ratio of the latter to the former was about 0.2 (Fig. 3b).

From 2005 to 2015, internal water consumption increased while the support of virtual water for local water demands decreased slightly. Intracoupling intensity was larger than that of intercoupling, which phenomenon was indicated by the ratio of virtual water import to international water consumption (Fig. 3b). The intensity of intracoupling and pericoupling was becoming higher while the telecoupling intensity was getting slightly lower, which was indicated by the ratio of nearby virtual water import to distant virtual water import (Fig. 3b).

# 3.1.2. Comparison of developing and developed countries

Deconstructing the world into developed countries and developing ones, we attempt to explore the influence of different coupling forms such as intracoupling, pericoupling, and telecoupling on water resources utilization. The results were shown in Fig. 4.

(1) The absolute value of intracoupling intensity and intercoupling intensity: the total and average volume of virtual water imports in developed countries were larger than those in developing ones, but the gap between developing and developed countries was narrowing. The total volume of virtual water import of 35 developed countries was about 1.4 times that of 129 developing countries in 2015, which number was 2.2 times in 2005. The average virtual water import volume of each developed country was about 5.2 times that of each developing country in 2015, which number was 8.2 times in 2005 (Fig. 4a and Fig. 4b).   
(2) The proportional relationship of intracoupling intensity and intercoupling intensity: Consistent with the global trend, both developing and developed countries showed that local water resources were the main source of local water demands, but virtual water imports in developed countries supported local water demands more than that in developing ones. However, although developed countries were highly dependent on virtual water import, this dependence decreased over time. In contrast, the dependence of developing countries on virtual water imports has increased over time. The ratio of virtual water import to internal water consumption was about 0.1 in developing countries. This ratio in developed countries was 6-9 times higher than that in developing ones (Fig. 4c).   
(3) The proportional relationship of pericoupling intensity and telecoupling intensity: in line with the global situation, in terms of cross-border virtual water trade, developing countries and

developed ones both showed a greater volume of distant virtual water import than nearby virtual water imports (i.e., the value of $\mathbf{r}_2$ is $< 1$ ). Nevertheless, the difference between distant import and nearby import was less in developing countries compared with that of developed ones (Fig. 4c).

# 3.1.3. Countries above and below water-stress warning line

Based on the amount of renewable water per capita in each country, we deconstructed the globe into groups of countries above water stress line (PWRC $\geq 1700$ per capita per year) and groups of countries below water stress line (PWRC $< 1700$ ). We then investigated the influence of different coupling forms, such as intracoupling, intercoupling, pericoupling and telecoupling, on water resources utilization. The results were shown in Fig. 5.

We can extract information from three aspects according to Fig. 5 as follows:

(1) The absolute value of intracoupling intensity and intercoupling intensity: the total and the average value of virtual water import in countries below the water-stress warning line were both larger than those above the water-stress warning line, and the gap between these two kinds of countries was widening. The average virtual water import volume of countries below the water-stress warning line was about 2.57 times that of countries above the water-stress warning line in 2015, which number was 2.40 times in 2005 (Fig. 5a and Fig. 5b).   
(2) The proportional relationship of intracoupling intensity and intercoupling intensity:

Consistent with the global trend, local water resources were the main source of local water demands for countries above and below the water-stress warning line. However, countries below the water resources warning line were less dependent on local water resources and more dependent on virtual water import than countries above the water resources warning line. Countries above the water-stress line (PWRC $>1700$ per capita per year, relatively water abundance), relied more on virtual water import, and this dependence increased over time. On the contrary, the dependence of countries below the water-stress warning line on virtual water imports decreased over time despite their relative scarcity of water resources. The ratio of virtual water import to internal water consumption in countries above the water-stress warning line was about 0.1, while this ratio in countries below the water-stress warning line was three times that of countries above the warning line (the higher the ratio, the greater the support of virtual water import to local water consumption demand) (Fig. 5c).

(3) The proportional relationship of pericoupling intensity and telecoupling intensity: in line with the global situation, in terms of cross-border virtual water trade, countries above or below the water-stress warning line both showed a greater volume of distant virtual water import than nearby virtual water imports (i.e., the value of $\mathbf{r}_2$

![](images/435c05e8890bce33c4dd5bcfa8bc8b2b9f31ffaebcc0481ec670fc7cd2e9b491.jpg)  
(a)

![](images/b385de122998596b7486a850d9412439c020350b269ad35337fbf2e296df3a06.jpg)  
Total volume of water from different sources (billion $\mathbf{m}^3$ )   
Average volume of water from different sources (billion $\mathbf{m}^3$ )

Fig. 4. (a). Total volume of water use supported by different sources in developing and developed ones. (b). Average volume of water use supported by different sources. (c). Ratio of virtual water trade to internal water consumption and that of nearby virtual water trade to distant virtual water trade in developing countries and developed ones.   
![](images/32a416123141a261863bade749ddbac1c2b218ce3f47b17ad4828b4d722160d5.jpg)  
Nearby virtual water import/distant virtual water import   
Virtual water import/internal water consumption

is $< 1$ ). Nevertheless, the gap between distant import and nearby import was smaller in countries above the water-stress warning line compared with that of countries below the water-stress warning line (Fig. 5c).

# 3.2. Scenarios of change in local water stress with and without-trade

# 3.2.1. With and without trade scenarios: The global overview

Fig. 6 shows the spatial and temporal patterns of local water stress in 2005 and 2015 under the scenario of with-trade and without-trade respectively, and also the difference of the two.

Virtual water trade reshaped the global water stress pattern to a large extent, making the global water stress show an overall decrease under the influence of trade. Virtual water trade eased water stress in $41\%$ of countries and exacerbated water stress in $59\%$ of countries in 2005. In 2015, virtual water trade eased water stress in $46\%$ of countries and exacerbated that in $54\%$ (Fig. 6).

# 3.2.2. With and without trade scenarios: Developing and developed countries

The impact of virtual water trade on global water stress pattern was different between developed and developing countries. For individual countries, virtual water trade tends to ease local water stress in more developed countries and exacerbate it in more developing ones. However, this imbalanced moderating effect has diminished over time. In 2005, virtual water trade reduced water stress in 86 percent of developed countries and increased that in 71 percent of developing countries. In 2015, virtual water trade alleviated water stress in $83\%$ of developed countries and increased that in $65\%$ of developing ones (Fig. 7a).

In terms of the average characteristics of country groups, developed and developing countries showed a similar pattern to global countries in 2005 and 2015: the decrease in degree of water stress in countries where trade alleviated water stress was greater than the increase in degree of water stress in countries where trade aggravated water stress. In addition, the average decrease in water stress among developing countries

![](images/f74004f95cb3ac0d7e9f7f1a14d06531f0fd8c70181659b820eb6b7e4afd7881.jpg)  
Total volume of water from different sources (billion $\mathbf{m}^3$ )

![](images/b749b6615e763046084e13b284782a657c7efdc8ab23b01dd21acf95ac74f4ac.jpg)

Average volume of water from different sources (billion $\mathbf{m}^3$ )

Fig. 5. (a) Total volume of water use supported by different sources in countries above and below the water-stress warning line. (b) Average volume of water use supported by difference sources in countries above and below the water-stress warning line. (c) Ratio of virtual water trade to internal water consumption and that of nearby virtual water trade to distant virtual water trade in countries above and below the water-stress warning line.   
![](images/1013b1418ca4dd70096b4bfaf39e8210e60585e9d7815f0f4d9d9defb1de3095.jpg)  
Nearby virtual water trade/distant virtual water trade   
Internal water consumption/virtual water trade

was more pronounced. In 2005 or 2015, the average water stress in both developed and developing countries was lower under with-trade scenario than under without-trade scenario. This is also consistent with the overall characteristics of global water stress reduction under the influence of trade in the previous section.

# 3.2.3. With and without trade scenarios: countries above and below water-stress warning line

The impact of virtual water trade on global water stress pattern was different among countries with different water resources endowments. Virtual water trade tends to alleviate water stress of more countries with relatively poor water resources endowment while aggravating water stress of more countries with relatively good water resources endowment. Using the level of renewable water resources per capita to present the water resources endowment, we can find that under the influence of trade, the change of water stress in 4th level countries (severe scarcity) was mainly decreasing. Meanwhile, the change of water stress for countries in level 3 (water scarcity), level 2 (is experiencing water stress), and level 1 (relatively water abundant), was mainly rising. The tendency of water stress rising due to trade was more obvious in countries with relatively better water resource endowment. Taking 2005 as an example, compared with no trade scenario, for the 4th level country

group, the ratio of countries where water stress dropped to those where water stress increased was 3:1. In contrast, for the 3rd level country group, the ratio of countries decreasing water stress to those increasing water stress was 1:1.25. For the 2nd level and 1st level countries, the ratio of decreasing and increasing water stress was 1: 1.75 (Fig. 7b).

# 3.2.4. Only-nearby-trade and only-distant-trade scenarios

Compared with nearby trade, distant trade has played a more important role in alleviating global water stress, contributing to the $99.8\%$ of the water stress alleviation. This is partially due to the fact that the number of distant countries was larger than that of nearby countries, leading to stronger and more intensive trade ties between distant countries than the adjacent countries.

In 2005, for example, nearby trade alleviated local water stress in $49\%$ of the global countries, exacerbated it in $37\%$ of countries. The remaining $14\%$ of countries were not affected by nearby trade such as Bahrain sharing no land-borders with others (Fig. 8a-b). Finally, nearby trade reduced the average level of global water stress by $0.4\%$ .

In contrast, in 2005, distant trade eased local water stress in $40\%$ of the global countries, which reduced water stress by an average of $81.7\%$ (Fig. 8c-d). Meanwhile, distant trade exacerbated local water stress in $60\%$ of the global countries, with an average increase of $18.4\%$ (Fig. 9).

![](images/b2c37e40c1f06ab61961bbf52a88ba433a0169c49e52f3878531bb9727e0e9d2.jpg)  
Fig. 6. The change pattern of domestic water stress under with-trade and without-trade scenarios.

![](images/8e3d3217515911a958bf8dfb90b2f9014ee6ee51fe9c93793bd46b552600aec6.jpg)

![](images/39fe03e896282eb5ed1278e2eb5f12c4682c288a7db4e6ef101f97370487032c.jpg)  
Fig. 7. (a) The change of domestic water stress in developing and developed countries under with-trade and without-trade scenarios. (b) The change of domestic water stress in countries with different water resource endowments under with-trade and without-trade scenarios.

Finally, distant trade reduced global water stress by $73.4\%$ . As a result of the combined effect of nearby trade and distant trade, global average water stress under the with-trade scenario was 14.018 lower in absolute value than that under the without-trade scenario (Fig. 9).

# 4. Discussion

# 4.1. Intracoupling and intercoupling of varying country groups

The metacoupling framework can easily depict the complex interactions between human and natural systems at various spatial distances which are coupled through virtual water trade, promoting the understanding of virtual water's role on the interconnected feedback of global and local water resources use (Xu et al., 2020b; Zhou et al., 2020).

In such context, this study interpreted the absolute intensity and relative proportion of intracoupling and intercoupling as well as their influence on water stress. Compared with developing countries, developed countries were more dependent on imported virtual water, especially virtual water imported from distant countries. Developed countries imported more virtual water than developing countries, but the gap between them became smaller. Compared with internal water consumption, developed countries were less and less dependent on imported virtual water from 2005 to 2015 while developing countries were more and more dependent on imported virtual water during 2005-2015.

Compared with countries above the water-stress warning line, countries below the water-stress warning line were more dependent on imported virtual water, especially those imported from distant countries. The virtual water import of countries below the water-stress

![](images/66a90f5a94da28098f24a61d5de0a2444c93b3a96f2684fa9a1ce5a84aed3d44.jpg)  
Fig. 8. (a) Amount of change in domestic water stress under only-nearby-trade scenario. (b) Magnitude of change in domestic water stress under only-nearby-trade scenario. (c) Amount of change in domestic water stress under only-distant-trade scenario. (d) Magnitude of change in domestic water stress under only-distant-trade scenario.

warning line was more than that of countries above the water-stress warning line, and the gap between the two became larger over time. Compared with internal water consumption, countries below the water-stress warning line were less and less dependent on imported virtual water from 2005 to 2015 while countries above warning line were more and more dependent on imported virtual water during 2005-2015.

The comparison of different coupling processes of water use, and that of different country categories (such as developing countries and developed ones, countries above and below water stress warning line) suggested that the phenomenon of virtual water outflow from waterscarce countries was relatively common (Lenzen et al., 2013). Countries with relatively good development level and abundant water resources had more priority in the use of global water resources, which is usually implemented in a way of using others' water to develop their own economy through virtual water trade (Arto et al., 2016; Clark et al.,

2015). From a policy perspective, such countries should take more responsibilities in improving the regional and global ecological environment through regional cooperation and technical assistance while enjoying the social benefits to avoid the unfair transfer of environmental responsibility (Du et al., 2022a).

# 4.2. Hotspots and possible influencing factors of water stress change

The result section showed the general situation of water stress change under the influence of virtual water trade. Here we focused on top countries of virtual water trade fluxes (Fig. S1 and S2), including USA, China, India, Japan, Germany, Russia, Indonesia, France, Thailand, UK, Brazil, Italy, Canada, Spain, Mexico, South Korea, Malaysia, and Australia. These a few countries became hotspots of global virtual water trade given that they together contributed $70\%$ of

![](images/52ebd61e29590b7ffd5d502a317c41fc2d2fcffedd5dfe40c8ca238726985974.jpg)  
Fig. 9. The average amount of change in water stress under different trade scenarios.

the total virtual water trade volume worldwide in both 2005 and 2015. Under the influence of virtual water trade, water stress changes among the hotspot countries varied greatly in the case of only-nearby-trade and only-distant-trade scenarios (Fig. S3). To figure out what factors directly affected such kind of difference, we constructed four groups of variables and calculated the Pearson Correlation Coefficient as shown in Table 2.

Table 2 shows that in the case of only-nearby-trade scenario, the change of domestic water stress under the influence of virtual trade is significantly negatively correlated with the net transfer volume of nearby virtual water trade. Similarly, in the case of only-distant-trade scenario, the change of domestic water stress is significantly negatively correlated with the net transfer volume of distant virtual water trade. This indicates the fact that net trade situation would act as a direct influencing factor to the amount and magnitude of change in domestic water stress, which is in line with the comparison between with-trade and without-trade scenarios.

# 4.3. Highlights and contributions

This study has implications for both sustainability research and management because it is the first to develop a conceptual model for applying the metacoupling framework to global water use systems including domestic water consumption and international virtual water trade. Based on such conceptual model, we were able to distinguish and

quantify-three forms of water resource utilization and also three kinds of coupling processes during global virtual water trade for the first time. Three forms of water resource utilization included domestic water extracted to produce goods and services for domestic use, domestic water extracted to produce goods and services used by foreign countries, and foreign water extracted to produce goods and services for domestic use. Three types of coupling referred to intracoupling (internal water footprint), pericoupling (virtual water transfer between adjacent countries), and telecoupling (virtual water transfer between distant countries). In such context, the relationship between domestic water supply, domestic water demand, oversea water supply, and oversea water demand was creatively indicated by water stress change under a set of trade scenarios such as with-trade, without-trade, only-nearby-trade, and only-distant-trade. Based on the UN SDG Indicator 6.4.2 (a classical water-stress indicator which is measured by the proportion of freshwater withdrawal to freshwater resources available), we quantified the change of water stress under several trade scenarios. Such an idea of index transformation is similar to that of the existing literature which assesses regional water stress alleviation in China due to physical and virtual water transfer (Zhao et al., 2015). Therefore, the rationality of our index construction is supported to a certain extent. But what is unique is that our indicators are more detailed in terms of different virtual water trade processes. Compared with previous literature which failed to incorporate the metacoupling perspective, our study enabled

Table 2 Corrlation coefcient between water-stress change and amount of net-virtual-water trade for hotspot countries with maximum volume of virtual water transfer.   

<table><tr><td>Variable</td><td>A1_2015</td><td>A2_2015</td><td>B1_2015</td><td>B2_2015</td><td>A1_2005</td><td>A2_2005</td><td>B1_2005</td><td>B2_2005</td></tr><tr><td>C_2015</td><td>0.678***</td><td>0.689***</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>D_2015</td><td></td><td></td><td>-0.581**</td><td>0.666***</td><td></td><td></td><td></td><td></td></tr><tr><td>C_2005</td><td></td><td></td><td></td><td></td><td>0.655***</td><td>0.746***</td><td></td><td></td></tr><tr><td>D_2005</td><td></td><td></td><td></td><td></td><td></td><td></td><td>-0.548**</td><td>-0.651***</td></tr></table>

Note that (1) the variable A1 represents the amount of change in domestic water stress under only-nearby-trade scenario; A2: Magnitude of change in domestic water stress under only-nearby-trade scenario; B1: Amount of change in domestic water stress under only-distant-trade scenario; B2: Magnitude of change in domestic water stress under only-distant-trade scenario; C: Net virtual water volume of nearby trade; D: Net virtual water volume of distant trade. (2) For A1, A2, B1 and B2, a positive value indicates that domestic water stress increases under the influence of virtual water trade, while a negative value indicates that domestic water stress decreases. For C and D, net virtual water transfer volume of nearby-trade is that the virtual water imported from neighboring countries minus the virtual water exported from neighboring countries; net virtual water transfer volume of distant-trade is that the virtual water imported from distant countries minus the virtual water exported from distant countries; for C and D, positive values indicate net import while negative values net export. (3) * represents significant correlation at the level of 0.1 (bilateral), ** represents significant correlation at the level of 0.05 (bilateral); *** represents significant correlation at 0.01 level (bilateral); the blank area indicates that correlation analysis is not carried out.

stakeholders to deconstruct the trade processes and thus systematically understand the environmental influence of virtual water trade taking place on different spatial scales. Furthermore, it is conducive to promoting an interdisciplinary approach to research given that the metacoupling framework is well suited to the identification of knowledge gaps in CHNAS-related issues (CHANS is shorted for coupled human and natural systems) (Liu et al., 2007, Liu et al., 2013).

In addition, this study makes a contribution by providing the possibility and flexibility to extend the emerging metacoupling framework to other spatial scopes, system types and environmental fields (Kapsar et al., 2019), conducive for translating science into practical strategies. For example, we can define appropriate system boundaries according to the specific research targets, downscale the socioeconomic and environmental interactions across countries to sub-national level and focus on the flows within an intracoupled system. Given the fact that virtual water flows embedded in trade is inextricably interlinked with flows of other resources, products and services such as finance, energy, pollution, biodiversity and water-related ecosystem services (Xu et al., 2020b), we can facilitate nexus analysis (e.g., water-food-energy-carbon emission nexus) based on the environmental accounts of multiple input-output databases (Chen et al., 2018; Xu et al., 2020a). By doing so, it will undoubtedly promote the understanding of causes and effects of virtual water trade from a broader cross-disciplinary background, and thus formulate more comprehensive and effective water management policies, which is exactly what the metacoupling framework advocated.

# 4.4. Limitations and future directions

The study was subjected to such limitations as uncertainties in raw water use data. Environmental accounts of the Eora database are a little weak in portraying temporal variation of virtual water flow given the same water use intensities each year in spite of the changing economic inputs. Only the total water consumption in 2000 divided by the total value of production could be used to get sectoral water intensity considering data availability. Despite the imperfections, the study is significant because so far there are no annual updates on water use. Another point of concern is that we exemplify distant versus adjacent systems based on the shared boundaries, following the classical definition of metacoupling framework. Considering the relatively rough distance properties at the present stage, quantitative and precise geographical concepts can be introduced in the next step. For example, the actual distance between national capitals, main ports, or territorial geometric centers. The quantification of distance can be even extended to the social or cultural distances depending on the specific topic of interest.

For future direction, we suggest the continuous dig into different aspects of a particular metacoupling and formulate a "paper series" given the complexity and umbrella-conception feature of the metacoupling framework (Kapsar et al., 2019). This single paper is just our first step to display the overall interaction of sending systems and receiving systems by quantifying the intensity, linkage and effects of varied coupling processes during global virtual water trade. Metacoupling framework provides a social-ecological context for adjacent and distant interactions and the systems, flows, agents, causes, and effects involved (Liu et al., 2015; Liu, 2017). More characteristics of the framework will be explored in the next steps to ultimately advance the science and practice of sustainability in ways that use information on both local, nearby, and distant socioeconomic and environmental interactions.

# 5. Conclusions

This study focuses on the global virtual water trade pattern and dynamic during 2005-2015 based on the coupling framework. Involving three forms of water resource utilization (that is, domestic water extracted to produce goods and services for domestic use, domestic water extracted to produce goods and services used by foreign countries,

foreign water extracted to produce goods and services for domestic use), two major issues are explored.

(1) Spatial-temporal pattern of global virtual water trade linkages. Specifically, two aspects were included such as the proportional relationship and absolute value of intracoupling, pericoupling, and telecoupling intensity, and the supporting role of different coupling types in meeting national water demand;   
(2) Effects of global virtual water trade. Based on the changes of individual countries' water stress in different trade scenarios, the relationship among local water supply, local water demand, foreign water supply, and foreign water demand under the background of global virtual water trade was clarified.

# The main conclusions are as follows:

(1) Local water resources supported $80\%$ of global water consumption; the amount of distant virtual water imports was about 5 times as large as nearby virtual water import; developed countries' water consumption was 6-9 times more dependent on virtual water import than that of developing countries; countries below the water-stress warning line $(1700\mathrm{m}^3$ per capita per year) were 3 times more dependent on virtual water import than countries above the water shortage warning line.   
(2) Based on trade scenario analysis, the indicator of water stress was constructed to assess the environmental effects of virtual water trade. Virtual water trade has reshaped the water stress pattern and reduced the global water stress overall. Compared with pericoupling process, distant trade corresponding to telecoupling process has eased $99.8\%$ of the global average water stress. Virtual water trade tends to ease local water stress in more developed countries and exacerbate it in more developing ones. However, this imbalanced moderating effect has diminished over time. Virtual water trade alleviated the water stress of many countries with relatively poor water resources endowment, while aggravated the water stress of many countries with relatively good water resources endowment.

# Appendix A. Supplementary data

Supplementary data to this article can be found online at https://doi.org/10.1016/j.ecolind.2022.109712.

