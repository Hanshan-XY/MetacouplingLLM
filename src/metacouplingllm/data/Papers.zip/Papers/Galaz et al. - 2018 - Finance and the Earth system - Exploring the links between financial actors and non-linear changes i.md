# Finance and the Earth system - Exploring the links between financial actors and non-linear changes i

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:45:44.850482+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Galaz et al. - 2018 - Finance and the Earth system - Exploring the links between financial actors and non-linear changes i.pdf
- Year: unknown
- DOI: 10.1016/j.gloenvcha.2018.09.008
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This paper investigates how large financial actors are connected to biomes that play a disproportionate role in regulating the global climate, and how those links might influence non-linear climate tipping dynamics. The focus is global, but the empirical analysis centers on two key forest systems: the Amazon rainforest in Brazil and boreal forests in Canada and Russia. These biomes are recognized as climate tipping elements because land use change and deforestation there can trigger feedbacks that destabilize regional and global climate.

The authors combine Earth system and sustainability science with corporate finance. They first identify the main land use drivers in each biome, then the industrial sectors most responsible (Brazilian beef and soy, and wood-pulp-paper in Canada and Russia). From these sectors they select the largest firms by market share, and use the Orbis database to map equity ownership and debt ratios. They then identify financial institutions that hold significant shares across multiple focal companies, emphasizing blockholdings (generally above 5 percent) and aggregate ownership concentrations.

The analysis reveals a small group of large, mostly US-based institutional investors and banks that hold notable stakes in many of the dominant firms affecting these forests. The big passive asset managers in particular collectively own sizeable fractions of several companies in each biome. Because ownership is concentrated and firms are relatively dependent on external finance, these investors together have substantial, yet largely unused, leverage over corporate strategies linked to deforestation and forest degradation.

The paper is directly relevant to telecoupling and metacoupling. It shows how distant financial decisions in major financial centers telecouple to ecological change in remote forest biomes and, through climate feedbacks, back to societies worldwide. The authors argue that current green finance debates overlook these non-linear Earth system dynamics and the latent governance role of these financial giants, and call for further research on how investment mandates, fiduciary duty, and stewardship practices could be aligned with maintaining climate-critical tipping elements.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via global finance linking distant investors to climate tipping biomes

### Intracoupling
#### Systems
- Amazon forest socioecological system in Brazil
- Canadian boreal forest socioecological system
- Russian boreal forest socioecological system
#### Flows
- Local land use change within each forest biome
- Beef and soy supply chains within Brazil
- Timber and pulp production within Canada and Russia
#### Agents
- Agribusiness and forestry corporations operating in selected biomes
- Local producers and supply chain intermediaries
- National regulators and environmental agencies
#### Causes
- Deforestation and forest degradation driven by beef and soy expansion
- Industrial logging and wood processing in boreal forests
- Interactions between climate change and local land use pressures
#### Effects
- Altered forest cover and ecosystem resilience
- Changed albedo and regional energy balance
- Heightened risk of crossing biome specific tipping points

### Pericoupling
#### Systems
- Neighboring regions around Amazon forest frontiers
- Adjacent Canadian and Russian forest management regions
- Regional commodity markets near production zones
#### Flows
- Cross border trade in beef, soy, timber between nearby countries
- Diffusion of land use practices across regional frontiers
- Regional climate feedbacks affecting surrounding areas
#### Agents
- Regional traders and processors
- Subnational governments and provincial regulators
- Regional banks and lenders
#### Causes
- Regional demand for agricultural and forest commodities
- Infrastructure expansion and frontier development
- Policy differences across neighboring jurisdictions
#### Effects
- Leakage of deforestation to nearby areas
- Shared regional climate and hydrological impacts
- Spillover of corporate and financial standards locally

### Telecoupling
#### Systems
- Global financial centers in North America and Europe
- Amazon and boreal forest tipping element regions
- Worldwide climate and Earth system
#### Flows
- International equity and debt capital to biome modifying firms
- Global trade in beef, soy, pulp, paper, wood products
- Transmission of climate risks into financial portfolios
#### Agents
- Large asset managers and institutional investors labeled Financial Giants
- International banks, pension funds, insurance companies
- Transnational agribusiness and forestry corporations
#### Causes
- Search for returns in resource intensive sectors
- Limited consideration of nonlinear climate tipping risks
- Passive index investing and concentrated global ownership
#### Effects
- Amplified or reduced pressure on critical forest biomes
- Potential to influence multiple tipping elements simultaneously
- Systemic financial and climate risks from tipping events

### Cross-Coupling Interactions
- Single financial actors hold stakes across companies in Amazon and boreal systems simultaneously
- Telecoupled capital flows reshape local land use drivers within distant forests
- Corporate governance decisions in financial centers propagate to multiple biomes

### Research Gaps or Limitations
- Opaque data on loans and private company ownership constrains full capital flow mapping
- Study focuses on equity in two forest related cases, other tipping elements unexamined
- Limited analysis of how identified investors actually use their latent governance power

### Search Keywords
- telecoupling finance tipping elements Amazon boreal
- financial giants climate stability deforestation
- institutional investors global environmental change

### Extraction Confidence
high
