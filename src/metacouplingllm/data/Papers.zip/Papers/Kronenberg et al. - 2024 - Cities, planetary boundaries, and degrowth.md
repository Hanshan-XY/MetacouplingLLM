# Cities, planetary boundaries, and degrowth

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:50:38.875721+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Kronenberg et al. - 2024 - Cities, planetary boundaries, and degrowth.pdf
- Year: unknown
- DOI: 10.1016/S2542-5196(24)00025-1
- OA status: gold
- License: cc-by-nc-nd
- Category: Journal Articles\Commentary\Telecoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This commentary examines how urbanization, planetary boundaries, and degrowth intersect, with a global focus but special attention to high-income countries. It is not an empirical study but a conceptual and synthetic contribution, drawing on planetary boundaries research, degrowth literature, and recent reports from IPCC, IPBES, and WHO.

The authors argue that cities, although occupying a small fraction of Earths surface, function as global hubs of production, consumption, and decision-making whose impacts are telecoupled far beyond their borders. Urban areas depend on distant hinterlands for food, energy, materials, and water, while exporting pollution, waste, and social-ecological burdens. Urban lifestyles, including those adopted in peri-urban and rural areas, are framed as key drivers of transgressing planetary boundaries such as climate change, biodiversity loss, land-system change, and novel entities.

The paper identifies three intertwined phenomena linking cities to planetary boundaries: (1) production and consumption systems structured around dispersed supply and concentrated urban demand; (2) multiple forms of environmental disconnect (spatial, economic, cognitive-emotional) that obscure cities dependence on nature and on distant communities; and (3) novel urban environments and technological-chemical entities that create new ecological and evolutionary conditions.

Degrowth is proposed as a framework to realign cities with a safe operating space for humanity. It explicitly challenges the growth imperative, unlike green growth or more growth-neutral approaches. The authors outline urban degrowth strategies to reduce throughput (for example, cutting waste, shifting diets, redesigning mobility, extending product lifetimes, circular and commons-based resource use), strengthen nature connection, and limit novel entities, while addressing power asymmetries and environmental injustice.

Telecoupling and broader metacoupling are central: the paper highlights how cities externalize environmental pressures and social costs to distant regions, and calls for policies that reduce these asymmetric flows, enhance regional self-sufficiency (especially food and energy), and integrate planetary boundaries with equity and health goals. The article emphasizes that operationalizing urban degrowth will differ between high-income and low- and middle-income contexts, but planetary boundaries create a shared constraint space.

## Structured Metacoupling Extraction

### Coupling Classification
- Mainly telecoupling of cities with distant hinterlands, plus peri linkages to regional surroundings.

### Intracoupling
#### Systems
- Urban social ecological technical systems within single cities
- Urban lifestyles and consumption patterns
- City level governance and planning institutions
#### Flows
- Energy and material throughput inside cities
- Urban waste, pollution, and greenhouse gas emissions
- Internal mobility and transport activity
#### Agents
- Urban residents and consumers
- Municipal governments and planners
- Local businesses and developers
#### Causes
- Growth oriented urban development and neoliberal urbanism
- High production and consumption driven lifestyles
- Environmental disconnect and ecological illiteracy in cities
#### Effects
- Local health issues and lifestyle diseases
- Urban environmental degradation and biodiversity loss
- Intra urban inequality, gentrification, social isolation

### Pericoupling
#### Systems
- Cities and their nearby hinterlands
- Urban cores with suburbs and exurbs
- Regional food and resource landscapes
#### Flows
- Regional food, water, and biomass to cities
- Daily commuting and transport between city and periphery
- Ecosystem services from peri urban green and blue areas
#### Agents
- Regional farmers and landowners
- Suburban and exurban households
- Regional planning and infrastructure agencies
#### Causes
- Urban sprawl, suburbanisation, and exurbanisation
- Search for cheaper housing outside city cores
- Infrastructure expansion fragmenting ecosystems
#### Effects
- Land system change around cities and habitat fragmentation
- Increased transport energy use and emissions
- Local freshwater pressure and nutrient pollution

### Telecoupling
#### Systems
- Global network of cities and planetary hinterlands
- High income cities and distant resource frontiers
- Cities in HICs and communities in LMICs
#### Flows
- Global supply chains for food, cotton, energy, materials
- Embodied emissions, waste, and novel entities in trade
- Capital, investment, and policy ideas promoting growth
#### Agents
- Transnational corporations and agri food companies
- Affluent urban consumers following globalised lifestyles
- International organisations like IPCC, IPBES, WHO
#### Causes
- Externalisation of urban environmental impacts to distant regions
- Global economic growth paradigm and trade liberalisation
- Unequal political power between urban centers and peripheries
#### Effects
- Pressure on multiple planetary boundaries beyond city territories
- Social and environmental injustice in distant producing regions
- Global climate change, biodiversity loss, and pollution

### Cross-Coupling Interactions
- Urban degrowth policies alter local metabolism and distant resource extraction simultaneously
- Environmental disconnect inside cities obscures peri and telecoupled ecological impacts
- Urban planning decisions shape regional land change and global supply chain pressures

### Research Gaps or Limitations
- Limited operationalisation of urban degrowth linked to specific planetary boundaries
- Need to downscale planetary boundaries for diverse cities and lifestyles
- Insufficient integration of LMIC perspectives and justice in degrowth strategies

### Search Keywords
- urban degrowth planetary boundaries telecoupling
- cities ecological footprint hinterlands externalised impacts
- urban lifestyles environmental disconnect novel entities

### Extraction Confidence
high
