Analysis

# Does agricultural trade reduce pressure on land ecosystems? Decomposing drivers of the embodied human appropriation of net primary production

![](images/2c0b392e94f6df94adac4cfdf0b1a9c6cf79f63fcb8a6412b47d9b8cd8c8fc6a.jpg)

Nicolas Roux a,\*, Thomas Kastner b, Karl-Heinz Erb a, Helmut Haberl a

a Institute of Social Ecology (SEC), Department of Economics and Social Sciences, University of Natural Resources and Life Sciences, Vienna, Schottenfeldgasse 29, 1190 Vienna, Austria   
b Senckenberg Biodiversity and Climate Research Centre, Senckenberganlage 25, D-60325 Frankfurt am Main, Germany

# ARTICLEINFO

# Keywords:

Land use

Land ecosystems

International trade

Embodied HANPP

Index decomposition analysis

Telecoupling

# ABSTRACT

Agriculture contributes to deforestation and the conversion of other terrestrial ecosystems, affecting important ecosystem functions. A growing share of the produced agricultural commodities is traded between countries. It is widely assumed that international trade reduces humanity's pressure on land ecosystems by optimizing the mix of origin, i.e. by sourcing products from countries where land is used more efficiently. We examined if recent changes in the origin of agricultural products reduced humanity's impact on a fundamental ecosystem function, the net primary production (NPP) of vegetation. We performed an index decomposition analysis on a dataset of human appropriation of net primary production embodied in bilateral trade flows of 392 agricultural products between 167 countries (eHANPP) from 1986 to 2011. We found that while changes in the origin of agricultural products globally reduced HANPP in the 1990s, this trend reversed since 1999. This turn is explained by the increased sourcing of agricultural products from tropical regions, for exports and domestic consumption. After 2008, countries – on average – increasingly sourced their agricultural products from less efficient regions than in 1986. Our results suggest that the potential of trade to reduce humanity's impact on land ecosystems has not been exploited in the recent past.

# 1. Introduction

Land is essential for human livelihood. It provides the food, carbon storage, space for biodiversity, and multiple other ecosystem services (IPCC, 2019). But pressure on land ecosystems is still on the rise, through deforestation, forest fragmentation, and the depletion of savannahs or other land ecosystems (Andronache et al., 2019; Qin et al., 2019; Strassburg et al., 2017). A large share of the pressure on land ecosystems has been attributed to the production and consumption of agricultural products (Curtis et al., 2018). Out of the total biomass harvested for agriculture, in 2000, $19\%$ went directly to food production, $71\%$ served to feed livestock, $4\%$ were used for bioenergy production, and the rest was supplied to other industrial sectors (Smith et al., 2013). Demand for agricultural products is expected to grow significantly over the next decades because of population growth and changing diets (Alexander et al., 2015; Alexandratos, 2012; Johnson et al., 2014).

This increasing demand for agricultural products can either be met

through expansion or intensification of agriculture (Johnson et al., 2014; Tilman et al., 2011). This implies that empirical studies need to use indicators encompassing both the extent and intensity of land use. However, pressure on land is often only measured in terms of land cover areas, mostly the reduction of forest cover (Steffen et al., 2015). This neglects the importance of land use intensity (Erb et al., 2016, 2013; Kuemmerle et al., 2013), and makes comparison across ecosystems difficult.

Alternatively, pressure on land can be measured by the intensity of human colonization of land ecosystems, i.e. the degree to which humans alter ecosystem functions for their own purposes (Erb, 2006; Fischer-Kowalski, 2011; Haberl et al., 2016). One of the essential functions of ecosystems is their Net Primary Production of vegetation (NPP). NPP represents the total amount of organic carbon (that is, trophic energy) fixed by autotrophs after respiration. It is the basis for plant growth and supplies the entire trophic energy for all heterotrophs, including animals, fungi, etc. (Haberl, 2002; Haberl et al., 2014, 2007). NPP as well favours biodiversity and ecosystem regulating services (Clough et al.,

2016; Costanza et al., 2007; Erb et al., 2005; Haberl et al., 2009; Haberl et al., 2005; Lauk and Haberl, 2007). The extent to which humans interfere in this process is called the Human Appropriation of Net Primary Production (HANPP). The HANPP indicator is the sum of the change in biomass productivity due to land use change (e.g. deforestation for cropland, or pasture expansion), and the biomass removed or destroyed by humans during harvest. Compared to area indicators, the HANPP reveals the difference between land use change in productive ecosystems (as in the tropics) and less productive ones. It therefore reflects both the extent and intensity of land use, and can be applied to various types of ecosystems, making it an insightful complement to conventional land cover indicators (Erb et al., 2016, 2013). At the global level, HANPP has been almost continuously increasing over the last century (Krausmann et al., 2013). It is estimated that humans were appropriating around $25\%$ of vegetation's potential net primary production around the year 2000, and around one-third of potential aboveground vegetation growth (Haberl et al., 2014).

The production of agricultural commodities is increasingly not solely serving local populations, but as well satisfying consumption in areas distant from the places of production (DeFries et al., 2010; Kastner et al., 2014). The value of international trade of agricultural products has been multiplied by nearly 40 since 1961 (FAOSTAT), giving rise to significant telecouplings between distant land systems (Eakin et al., 2014; Friis and Nielsen, 2019; Liu et al., 2018, 2013). Henders and colleagues show that between 2000 and 2011 the share of deforestation embodied in exports doubled from $18\%$ to $36\%$ of total deforestation (Henders et al., 2015). DeFries and colleagues as well claim that the degree of export orientation has become the most powerful discriminator between countries with high and low forest loss (DeFries et al., 2010). Understanding these telecouplings has hence become ever more important in explaining the drivers of land use (Lambin and Meyfroidt, 2011; Meyfroidt et al., 2013, 2010; Yao et al., 2018). Various approaches have been suggested to measure the land use embodied in international trade flows (Bruckner et al., 2019; Kastner et al., 2011; Yu et al., 2013). Among these, the embodied HANPP (eHANPP) indicator combines the strengths of the HANPP approach described earlier, with information about bilateral trade flows of biomass products, which makes it a good choice for our purposes (Erb et al., 2009; Haberl et al., 2009, 2012a; Kastner et al., 2015).

Connecting places of production and consumption enables us to isolate the effect of four important drivers of land use. Following conventional approaches, we look at the effect of (1) population growth, (2) consumption of agricultural biomass per capita (for food, feed and other purposes), and (3) land use efficiency. In addition, we analyze the effect of a fourth potential driver, i.e. the changes in the origin of consumed commodities. This includes for example the effect of importing goods rather than producing them domestically, or sourcing imports from one country rather than from another. This effect, which we refer to as the mix of origin effect, is of particular interest. Comparing the size of the population, consumption and technology effects remains interesting, but the direction of these effects on HANPP is rather straightforward: population growth and growing affluence drive HANPP upwards, whereas growth of land-use intensity reduces HANPP per unit of product and hence dampens the increases resulting from population and consumption growth (Alexander et al., 2015; Haberl et al., 2012b; Krausmann et al., 2009). On the other hand, the effects of relative changes between imports and domestic consumption patterns – i.e., the mix of origin effect – are more intricate; and they have so far not received enough attention in the land use literature. Moreover, the mix of origin effect lies at the core of controversies about international trade, notably in discussions about local versus global consumption, trade tensions or trade agreements. Therefore, a robust data-based analysis to empirically assess how changes in the origin of agricultural products affected ecosystem functions as NPP can be helpful.

A widespread assumption is that international trade can reduce pressure on ecosystems by optimizing the mix of origin, i.e. by sourcing

products from regions where land resources are used more efficiently. This idea partly comes from the adaptation of Ricardian or Heckscher-Ohlin economic reasoning to natural resources, and its derived efficiency gains (Lambin, 2012). Xu and colleagues found that the international trade improved 9 SDG indicators compared to a hypothetical no-trade scenario (Xu et al., 2020). Previously, the concept of water savings through international trade has been widely discussed (Chapagain et al., 2006; Dalin et al., 2012; Pastor et al., 2019). The idea has been taken up in the land use literature as well (Muller et al., 2006). Kastner and colleagues compared the current situation to a scenario where all crops would be produced domestically, and suggested that trade reduces global cropland area by $8\%$ (Kastner et al., 2014). Martinez-Melendez and Bennett as well argue that exports from the USA to Mexico are sparing 2.2 million ha of cropland (Martinez-Melendez and Bennett, 2016).

This study contributes to this debate through its comprehensive global approach. The eHANPP indicator covers both the global and regional scales, includes the effect on both cropland and grassland, and encompasses changes in area and intensity of land use. Moreover, the mix of origin approach allows us to depict and compare the effect of both changes in domestic consumption and international trade, revealing patterns that cannot be observed by counterfactual scenarios where all production is either domestic or globally traded. Finally, our decomposition analysis enables us to consistently compare the effect of origin to other drivers of land use.

Our approach hence allows us to systematically evaluate if the recent evolution in the origin of agricultural products and in international trade indeed optimized the world allocation of land use. To do so, we aim to answer the following questions: Where does the HANPP embodied in consumption originate from? How did changes in the origin of agricultural products affect the humanity's appropriation of land ecosystems? And what is the scale of the effect of changes in the origin of agricultural products compared to other drivers as changes in population, consumption per capita or technology?

# 2. Methods

To answer these questions, we first updated a global data set on HANPP embodied in consumption and bilateral trade flows. Given some limitations of the conventionally used LMDI decomposition, we used a new method for index decomposition analysis to analyze the effect of the mix of origin on global HANPP and compare it to the effect of changes in population, consumption, and HANPP intensity between 1986 and 2011.

# 2.1. Calculation of eHANPP associated with traded products

HANPP reflects the degree of human intervention in the process of net primary production of vegetation, affecting various ecosystem functions (Clough et al., 2016) and the amount of trophic energy available for other species (Erb et al., 2005). HANPP measures the difference between the potential net primary production $(\mathrm{NPP}_{\mathrm{pot}})$ , i.e. the vegetation growth that would be observed in the absence of human intervention, and the NPP actually remaining in ecosystems after harvest. HANPP includes both the change in vegetation growth due to land use change (i.e. the conversion of forest and natural vegetation to cropland or grassland), and the vegetation destroyed during harvest or grazing. The HANPP reflects the extent and intensity of land use, and differentiates between changing productive or less productive ecosystems. For detailed explanations of the HANPP components, see (Haberl et al., 2014). HANPP is usually displayed in mass of dry matter biomass per year, or through its Carbon (c.a. $1/2$ of the dry matter biomass) or energy content.

In order to link bilateral trade flows to their corresponding HANPP, we followed the embodied HANPP (eHANPP) approach. eHANPP measures the HANPP embodied in each nation's apparent consumption of

biomass-based products (Erb et al., 2009; Haberl et al., 2009). For our purposes, we measured eHANPP for agricultural products using bilateral trade data following a method described in detail by (Kastner et al., 2015). This approach relies on bilateral trade matrices (Kastner et al., 2011, 2014), covering flows of 392 crop and livestock products between 167 nations, taken from the FAO for the years 1986 to 2011. Trade flows are converted into flows of 147 primary products equivalents and corrected for re-exports (Kastner et al., 2014, 2011).

For cropland, these trade matrices are first converted into 'embodied hectares', i.e. cropland and grassland area-equivalents of traded products based on their respective yields (Kastner et al., 2014). For annual crops, embodied hectares are corrected by a multicropping factor, derived from the ratio between reported harvested areas and physical cropland areas from the FAO. eHANPP is calculated by multiplying embodied hectares by crop specific $\mathrm{NPP}_{\mathrm{pot}}$ factors (based on the global digital vegetation model LPJmL for the year 2000), and country specific HANPP per $\mathrm{NPP}_{\mathrm{pot}}$ factors taken from Krausmann et al., 2013 and Haberl et al., 2007. These HANPP factors HANPP per $\mathrm{NPP}_{\mathrm{pot}}$ factors were extrapolated from 2006 to 2011, based on a squared least-squares regression of the values between 1986 and 2005. HANPP on fallow land was finally added to the crop aggregate eHANPP to obtain the total flows of eHANPP coming from cropland. Fallow HANPP factors for 2006-2011 were set to the value of 2005. For detailed explanations, refer to (Kastner et al., 2015)

consumption of agricultural products per capita, HANPP intensity (HANPP per tonne of agricultural product), and the mix of origin.

The mix of origin effect is commonly understood as the effect on the total considered impact of a country (in this case HANPP), of sourcing consumption from countries with a higher or lower impact per unit of product than previously. For example, if a country with low domestic HANPP per unit of product increases its imports from a country with high HANPP per unit of product instead of producing domestically, it would worsen (i.e. increase) the mix of origin effect.

The LMDI decomposition method is a well-established index decomposition method, and has become the norm to measure these mix (or structure) effects (Alexander et al., 2015; Ang, 2004; Ang and Liu, 2007; Plank and Eisenmenger, 2018). We tested the LMDI method, but found that it was subject to a bias misallocating mix effects, such as mix of origin, sector mix or product mix effects. For further details about the misallocation of the LMDI, refer to Roux et al. (submitted).

Therefore, we developed the MESE (Marshall-Edgeworth with Structure Effects) index decomposition approach, which by construction better reflects the logic of mix effects.

Consider the following equation of the drivers of HANPP embodied in imports from an origin country o to a destination country d:

$$
e H A N P P _ {o d} = P _ {d} \cdot C _ {o d} \cdot I _ {o d} \tag {1}
$$

In this equation, $eHANPP_{od}$ denotes the HANPP embodied in con

$$
e H A N P P = \sum_ {\text {p r o d u c t s}} \text {t r a d e d b i o m a s s} (t d m) \cdot \frac {1}{Y i e l d} \text {m u l t i c r o p p i n g f a c t o r} \cdot \frac {N P P _ {p o t}}{h a} \cdot \frac {H A N P P}{N P P _ {p o t}} + H A N P P \text {f a l l o w}
$$

eHANPP from grassland and fodder crops is allocated to trade flows of ruminant products, using the corresponding HANPP factor (from Krausmann et al., 2013). Grassland and fodder crops HANPP factors were extrapolated from 2006 to 2011, based on a linear least-squares regression of the values between 2000 and 2005.

Trade flows of animal products are only represented as flows of embodied feed, fodder crops, and grazed biomass. For example, exports of beef that were fed with soycake would appear in the data as a flow of soybeans.

For consistency along the time series, countries as the Soviet Union or Yugoslavia that divided during the period were aggregated to their original size. Therefore, international trade between for example former soviet countries is observed as domestic consumption. Except these cases, all data were available at the country level. However, we decided to display solely the regional aggregates for clarity.

We finally proceeded some small data cleaning. Three points were interpolated (exports from Nigeria to Benin in 2007, from Malaysia to the Netherlands and from Equatorial Guinea to the Netherlands in 1997) based on visual plausibility checks (See appendix). Implausible points may be due to data not being reported for certain years in the trade data from the FAO, or may occur in the correction for reexports, when the bilateral trade data is inconsistent with the reported production data. Nonetheless, when applying the origin tracing algorithm, individual problematic trade links in the reported data propagate through the entire trade network causing issues in several trade links. Therefore, anomalies remain in the years 1997 and 2007.

# 2.2. Decomposition analysis

We decomposed the changes in global eHANPP by quantifying the contributions of changes in the following factors: population growth,

summption in country d sourced form country o,

$P_{d}$ the population in the destination country d,

$C_{od}$ the consumption per capita in country $d$ of products sourced from country $o$ , and.

$I_{od}$ the HANPP intensity (HANPP per tonne of product) of goods flowing from o to d.

For reading ease, the subscripts are omitted afterwards.

Taking the differential between time 0 and time t, one possible development of (1) is

$$
\begin{array}{l} e H A N P P ^ {t} - e H A N P P ^ {0} = \Delta C \cdot P ^ {t} \cdot P ^ {t} + \\ \Delta P \cdot C ^ {0} \cdot I ^ {\prime} + \tag {2} \\ \Delta I \cdot P ^ {0} \cdot C ^ {0} \\ \end{array}
$$

Where $\Delta \mathbf{X} = \mathbf{X}^{\mathrm{t}} - \mathbf{X}^{0}$

Set $\bar{I}_d = \frac{\text{total eHANPP in } d}{\text{total consumption in } d}$ the weighted average<sup>1</sup> of the HANPP intensities in all origin countries supplying country $d$ . Again, the subscript is omitted for clarity.

By adding and subtracting $\bar{I}_d$ to (2) and arranging, we can split the effect of a change in consumption per capita into a first part related to the average HANPP intensity (the consumption p.c. effect) and a second related to the difference between the intensity in each origin country and the average intensity (the mix of origin effect of consumption pc). Similarly, the effect of a change in population can be split in an average population effect, and a mix of origin effect of population:

$\overline{^{1}\bar{I}_{d} = \frac{\text{total eHANPP in d}}{\text{total consumption in d}}} = \sum \left(\frac{T_{C_{od}}}{T_{C_{d}}}\times \frac{eHANPP_{od}}{T_{C_{od}}}\right) = \sum \left(\frac{T_{C_{od}}}{T_{C_{d}}}\times I_{o}\right)$ where $TC_{od}$ is the total consumption in d sourced from o, and $TC_{d}$ is the total consumption in d.

$$
\begin{array}{l} e H A N P P ^ {t} - e H A N P P ^ {0} = \Delta C \cdot P ^ {t} \cdot \left(I ^ {t} - \bar {I} ^ {t}\right) + \\ \begin{array}{l} \Delta C \cdot P ^ {t} \cdot \vec {I} ^ {t} + \\ \cdot C ^ {0} \cdot \left(I ^ {t} - \vec {I} ^ {t}\right) + \end{array} \tag {3} \\ \begin{array}{c} \Delta P \cdot C ^ {0} \cdot \overline {{I}} ^ {t} + \\ \Delta I \cdot P ^ {0} \cdot C ^ {0} \end{array} \\ \end{array}
$$

Where:

$$
\begin{array}{l} \Delta C \cdot P ^ {t} \cdot \left(I ^ {t} - \vec {I} ^ {\dagger}\right) = c o n s u m p t i o n \text {p e r c a p i t a m i x o f o r i g i n e f f e c t} \\ \Delta P \cdot C ^ {0} \cdot \left(I ^ {t} - \vec {I}\right) = p o p u l a t i o n m i x o f o r i g i n e f f e c t \\ \Delta C \cdot P ^ {t} \cdot \bar {I} ^ {\dagger} = c o n s t r u c t i o n p e r c a p i t a e f f e c t \\ \Delta P \cdot C ^ {0} \cdot \vec {I} = p o p u l a t i o n e f f e c t \\ \Delta I \cdot P ^ {0} \cdot C ^ {0} = H A N P P i n t e n s i t y e f f e c t \\ \end{array}
$$

Total mix of origin effect $=$ consumption pc M.O.O.E. + population M.O. O.E.

For each effect, the regional or global result is given by the sum over all destination countries $d$ in the considered region and all origin countries $o$ in the world.

There are five other possible permutations between t and 0 for Eq. (2) and (3). All six permutations can be found in the Appendix. As in a classic additive Marshall-Edgeworth index, the final decomposition result is the arithmetic mean of all 6 permutations.

In this Marshall-Edgeworth with Structure Effects (MESE) index decomposition, as seen in Eq. (3) the population and consumption per capita effects are computed using the weighted average of the HANPP intensity of all countries of origin that are supplying the given consuming country. It hence reflects the effect of an increase in population or consumption per capita, assuming that this consuming country would source the additional consumption from its average supplier (with a higher weight for large suppliers).

On the other hand, the mix of origin effect reflects the increase in population and consumption per capita in a given consuming country, but weighted with the difference between the actual HANPP intensity of each flow and the weighted average HANPP intensity of all countries supplying that given consuming country. Therefore, a jump in consumption per capita sourced from producing countries with a higher than average HANPP intensity would increase the consumption per capita mix of origin effect. Similarly, if population grows faster in countries sourcing their products from comparatively HANPP intensive regions, the population mix of origin effect would increase. We hence define the total mix of origin effect as the total sum of the population mix of origin effect and the consumption per capita mix of origin effect.

In summary, in a MESE decomposition, the global mix of origin effect will be positive (i.e. will increase the HANPP), if and only if

- a country increases consumption sourced from an origin with a higher than average HANPP intensity, or decreases consumption from an origin with a less than average HANPP intensity (compared to the other countries this country is sourcing its products from), or   
- population increases faster in countries sourcing their products from HANPP intensive regions.

Due to the different evolution of global eHANPP before and after 1999, which was also characterized by different developments of the mix of origin effect, we decided to look at the decomposition separately for the two periods before and after 1999.

# 3. Results

# 3.1. Evolution changes in the origins of global eHANPP

Between 1986 and 2011, the evolution of the Human Appropriation of NPP embodied in the global consumption of agricultural products was characterized by two periods: a plateau (slightly decreasing) until 1999, and an increase thereafter (Fig. 1).

From 1986 to 1999, global eHANPP stagnated around 21.3 Gt of dry matter biomass per year. This stable period was a very peculiar phase in history, as it followed a century of continuously increasing HANPP (Krausmann et al., 2013). This stability was in fact almost exclusively due to the sharp decrease of HANPP in the soviet bloc after the fall of the USSR, which balanced increases in other regions as Sub Saharan Africa and Eastern Asia.

From the turn of the millennium onwards, eHANPP growth resumed and continued until 2011. Post-soviet economies stabilized, while consumption sharply increased in Sub Saharan Africa, as well as to a lesser extent in Eastern Asia. Global eHANPP eventually reached 24.1 Gt of dry matter biomass (c.a. 12 Gt of Carbon) per year in 2011.

Meanwhile, the share of HANPP embodied in international trade increased from $9.7\%$ of total eHANPP to $15.9\%$ between 1986 and 2011. This shows that HANPP associated to internationally traded products increased faster than HANPP related to domestic consumption.

Over the period, HANPP embodied in international trade mostly flowed from sparsely populated areas as the Americas or Australia to densely populated regions as Western Europe or Eastern Asia (Fig. 2, SI Fig. 1). eHANPP flowed mostly between high GDP countries, showing that the degree of inclusion into the globalized agriculture system highly depends on the level of economic development, both for importing and exporting regions (SI Fig. 2).

However, origins of agricultural products changed over the period. In 1986, North America had the largest HANPP embodied in its exports of agricultural products (480 Mt. dm/yr), followed by South America (340 Mt. dm/yr) and Oceania (320 Mt. dm/yr). Between 1986 and 2011

![](images/1b7b32134da8aa49f2df5d927e1b4e6fb350c4815ad4cbbe47f0d33cad46becc.jpg)

![](images/d550f383b63d607aa025f1c425f083b71168f5624f0cf2c9e8549e846e6bf0a9.jpg)  
Fig. 1. eHANPP in agricultural products between 1986 and 2011. eHANPP stagnated until 1999 because of the fall of the Soviet Bloc, and increased afterwards. The dotted line shows the gradual increase of international trade over the period.

![](images/14f834d917ec8af83b6366678aa53c370b7fdcfe601805199a38c712036547ae.jpg)

![](images/e446c6c09abfa5cef505843f49816ec86094b13b489ed0d5619f5dc328460877.jpg)  
Fig. 2. eHANPP flows in interregional trade in 100 Million tonnes dry matter per year of biomass in a) 1986 and b) 2011. The colour of the flow corresponds to the colour of the origin region. Note the different scales between a) and b). Total eHANPP traded across world regions increased from 180 Mt to 305 Mt dry matter per year between 1986 and 2011. eHANPP flowed mostly from the Americas, Oceania, and South East Asia, to Western Europe, Eastern Asia and the Middle East.

![](images/1ab54b00c359464a1345b7e9757fd7e385d392d48ccf0413bf180cdb5ceaa290.jpg)  
Fig. 3. Cumulative effect of the changes in the origins of agricultural products on global eHANPP. Changes in the origin of agricultural products reduced global eHANPP until 1999, but increased it afterwards. After 2008, the mix of origin was less efficient than in 1986.

total HANPP embodied in interregional exports from South America increased by 420 Mt. dry matter per year (more than doubled), those from former Soviet countries rose by 240 Mt. dm/yr (multiplied by 7.3), and those from SE Asia by 200 Mt. dm/yr (almost doubled) (Fig. 2). In 2011, South America was the largest exporter of embodied HANPP, followed by North America and South East Asia. The evolution of eHANPP flows for all regions is shown in SI Figs. 3 to 6.

# 3.2. Effect of the changes in the origins of agricultural products on eHANPP

The changes in the origin of agricultural products (within and across world regions, as well as changes in domestic consumption) had an ambivalent effect over the period. Changes in the mix of origin (MOO) effect decreased eHANPP by 0.3 Gt dm/yr in 1999 compared to 1986. Nevertheless, from 1999 onwards, the mix of origin deteriorated. Between 1999 and 2011, the mix of origin increased the global HANPP by 0.5 Gt dm/year. From 2008 onwards, the global mix of origin was less efficient than in 1986 (Fig. 3).

Variations of the mix of origin were linked to various processes, which relate to changes in domestic consumption and international trade within or across world regions (Fig. 4).

# 3.2.1. Changes in domestic consumption

Part of the mix of origin effect was due to changes in domestic consumption. The most noteworthy is the rise of domestic consumption in Sub Saharan Africa. There, population growth led to a rapid increase in total consumption. This increase in consumption was almost entirely covered domestically (Fig. 5). Because of extensive agriculture, high $\mathrm{NPP}_{\mathrm{pot}}$ , and important land degradation (also reflected in a high HANPP due to land use change), Sub-Saharan Africa was more HANPP intensive than the regions it imported from (SI Fig. 8). As domestic consumption grew faster than imports over the period, the mix of origin contributed to the rise in eHANPP, especially in Angola, Ethiopia-Eritrea, and Nigeria (SI table 9).

Rises in domestic consumption as well increased the mix of origin effect in other regions, especially South America (Brazil), South East Asia (Indonesia, Thailand) and Central America (Mexico). On the other hand, the increase in domestic consumption improved the mixed of origin in North Africa and Western Asia (because the productivity in the middle east is higher than its natural potential due to irrigation), and in China. Finally, the drop of domestic consumption in the Former Soviet Union and Canada reduced the mix of origin effect, while the reduction of domestic consumption in Japan increased the mix of origin effect (SI table 9).

# 3.2.2. Changes in international trade

Changes in international trade within our defined regions improved the mix of origin almost all over the period (Fig. 4), and hence contributed to the reduction of global eHANPP. This held for most regions, except North America, Former Soviet Union & Eastern Europe, and Central America. Most notable reductions of HANPP were due to exports from Argentina to other South American countries, trade between western European countries, and exports from China to South Korea or the USA to Canada. Some intraregional trade flows however, as exports from Canada to the USA worsened the mix of origin effect on eHANPP (SI table 10).

Changes in trade across world regions improved the mix of origin (Fig. 4), between 1986 and 1999. Among these, the exports from South East Asia and other regions to Sub Saharan Africa (especially Malaysia to Namibia), from South East Asia to Southern Asia (India), or from the USA to Mexico contributed most to the optimization of the mix of origin during this period (SI table 11). These exporters were indeed more HANPP efficient than other countries delivering to the respective importing country (SI Fig. 8).

Nevertheless, overall the evolution in interregional trade since 1999

![](images/829f47948ab49072c13ee1fd658f8576d3b9c30974ee32be3cbab63feffe948e.jpg)  
a)

![](images/419e5fca2c9f5856fc0bbd2178807c468847d835178ba751d49ff5a80848535d.jpg)  
eeeee eeeeee

![](images/08a0090f1c938692910c229555505b6bd20526e6d7866830d7c587e68b9fe845.jpg)  
c)

![](images/7f5e122885cac6074ce1a453f84e35867e8ca32908202c94391d6596a9d01791.jpg)  
Fig. 5. Origins of agriculture eHANPP consumed in Sub-Saharan Africa, including domestic consumption. This figure shows that the increase of eHANPP consumption in Sub Saharan Africa was almost entirely covered domestically.   
Fig. 4. a) Processes affecting the mix of origin (cumulative). b) and c) Flows affecting the mix of origin effect in 2011 compared to 1986 from a production perspective (b) and a consumption perspective (c). In b) columns stand for the region of production and colors for the region of consumption of each eHANPP flow. In c) columns stand for the region of consumption and colors for the region of production of each eHANPP flow. Black stands for domestic consumption and grey for intraregional trade flows. The height of the bar represents the contribution of each flow to the mix of origin effect on global eHANPP. After 1999, changes in domestic consumption mostly increased the mix of origin effect, especially in Sub Saharan Africa and South America. Changes in intraregional trade optimized the mix of origin all over the period. The rise of interregional trade improved the mix of origin before 1998, but significantly worsened it afterwards, mainly related to the rise of exports from South America and South East Asia to Eastern Asia, Western Europe, and to Northern Africa and Western Asia.

worsened the mix of origin effect on global eHANPP. This was mostly due to the rise in agricultural exports from South America and Southeast Asia to Eastern Asia and, to a lesser extent, to Western Europe, Former Soviet Countries, and North Africa & Western Asia (Fig. 4b and c). Among these, the surge of exports from Brazil, Indonesia, USA, Thailand and India to China, and from Ecuador to former soviet countries were the largest contributors to the mix of origin effect on HANPP (SI Table 11). Changes in imports from Brazil to the UK, Spain, Italy, or Germany played a large role until 2007 and decreased afterwards. Fig. 6 shows that total HANPP embodied in exports from South America increased from 358 to 858 million t dm/year. This rapid increase worsened the global mix of origin effect due to the high HANPP intensity of production in South America (high deforestation and other degradation of natural vegetation for agricultural production). Meanwhile, eHANPP exports from SE Asia upturned in 1997 and gradually increased until 2011, from 221 to 406 million t dm/year. While exports from SE Asia to Europe and Eastern Asia worsened the mix of origin, exports to Sub Saharan Africa and Southern Asia reduced eHANPP, given that both of them were more HANPP intensive than countries in SE Asia. Besides, the decline of exports from the USA to Brazil as well worsened the mix of

![](images/07873d2b51ff98b5bf5238d92076645d3b4fcb02fda0068e7a686770ee667857.jpg)  
Fig. 6. Interregional eHANPP exports from a) South America and b) South-East Asia, excluding domestic consumption and intra-regional trade. The dotted line (right axis) shows the percent of interregional exports in total HANPP embodied in the total production in this region. From the late 1990s, both South America and South East Asia suddenly started to increase their exports of eHANPP to multiple regions rapidly.

origin effect (SI Figs. 5 and 6, SI table 11b).

# 3.3. Comparing to other drivers of eHANPP

# 3.3.1. At the global level

At the global level, the mix of origin effect played a smaller role than changes in population, HANPP intensity, and per-capita consumption (Fig. 7). To see the absolute values of these drivers, refer to Fig. S8 in the appendix. Between 1986 and 1999, the mix of origin effect equalled $66\%$ of the effect of consumption per capita in absolute values, because of the small rise in global consumption, but corresponded to $7\%$ of the effect of HANPP intensity. Between 1999 and 2011, the effect of the mix of origin was $13\%$ of the consumption per capita effect over the same period. Its effect between 1986 and 2011 was around $3\%$ of total upward driving forces, and $7\%$ of the consumption per capita effect.

Throughout the entire observed period, HANPP was constantly being driven up by population growth (Fig. 7), especially in Sub-Saharan Africa, but as well in Southern Asia, South America, and South-East Asia (Fig. 8). At the global level, population growth was the only upward-acting driver of HANPP between 1986 and 1995.

The effect of changes in the consumption of agricultural biomass per capita was slightly negative until 1995, but rapidly increased thereafter (Fig. 7). This is mostly explained by the decrease in consumption during the fall of the Soviet bloc $(\mathrm{FSU}+)$ , which compensated for the rise of consumption per capita in other regions. Once consumption in the former Soviet bloc countries stabilized, the contribution of consumption per capita to global HANPP rapidly increased. Eventually, $36\%$ of the increase in eHANPP between 1986 and 2011 was due to the rise in consumption per capita, mostly due to changes in consumption patterns in Eastern and South-East Asia, but as well to a lesser extent in Sub-Saharan Africa, Southern Asia and South America (Fig. 8). Consumption per capita in developed countries was already high before the studied period, and even declined in North America. Note that the increase in biomass consumption as well includes the surge in feed and

grazing due to dietary changes and the growing consumption of animal products.2

The fall of HANPP intensity (HANPP per tonne of agricultural products), was able to compensate for the increase in population and consumption until 1999, but was not sufficient to counterbalance the rapid increase in consumption after 2000 (Fig. 7). The decrease in HANPP intensity was mostly driven by changes in South and South-East Asia, former Soviet countries and South America (Fig. 8). Note that because of the product aggregate level, the HANPP intensity may reflect technological changes as agricultural intensification (likely reducing HANPP intensity, as it reduces the gap between $\mathrm{NPP}_{\mathrm{act}}$ and $\mathrm{NPP}_{\mathrm{pot}}$ ), as well as changes in the product mix, through changes towards crops with a higher or lower HANPP intensity, or shifts between grazing and market feed.

# 3.3.2. At the regional level

Although the mix of origin effect was small at the global level, it was important in some regions (Fig. 9). Especially in western Europe, the mix of origin was the largest driver of eHANPP; over the period, the increase in HANPP embodied in western European consumption was mostly due to changes in the origin of agricultural products, rather than changes in consumption patterns. This was primarily linked to the rise of European imports from Brazil, mostly by the UK, Spain and Italy. The mix of origin effect was largest in absolute values in Eastern Asia. The MOO effect increased HANPP embodied in Eastern Asia's consumption by $400\mathrm{Mt}$ dm/yr, or $18\%$ of the total of upwards-pushing drivers (population, consumption/cap, and the MOO). This was mostly due to the increase in imports by China and Japan from South America, South and South-East Asia, USA and Australia, and to the decrease of domestic consumption in Japan. In Sub Saharan Africa and central America, the mix of origin effect contributed to the decrease in consumed eHANPP, through imports from more HANPP efficient countries. Decompositions for other world regions can be found in SI Fig. 7.

# 4. Discussion

Measured in HANPP, human pressure on land ecosystems via agriculture stagnated globally in the late 1980s and early 1990s, but increased again thereafter. The share of international trade rose, leading to important changes in the origin of agricultural products. Changes in the origin of agricultural products contributed to the stabilization of HANPP in the 1990s and to its surge from the late 1990s. After 2008, the global allocation of land was less efficient than in 1986 with respect to HANPP. These changes in origin played a comparatively small role at the global level, while population and consumption per capita growth were globally the main upward drivers of pressure on land. Gains in efficiency could counterbalance this trend until 1999, when global consumption growth was still sluggish due to the fall of the Soviet economies. Efficiency gains were however not sufficient to counterbalance the rise in eHANPP since the turn of the millennium. Nevertheless, the importance of the mix of origin greatly differed across world regions. Most noteworthy, changes in origin were the main driver of HANPP embodied in Western Europe's consumption, due to the rapid increase of imports from South America and South-East Asia.

Both, changes in domestic consumption and international trade, within or across world regions affected the evolution the mix of origin effect. The effect of domestic consumption was changing over time, but eventually worsened the mix of origin, especially because of the rise in domestic consumption in Sub Saharan Africa. There, deforestation and

![](images/8dfe66671f72498ac81aeacef85b255762c147208f0eb2a594b48210b41ab79c.jpg)

![](images/71d526f521d74b8e90a357b5d358bfaa6018a21225f29d99d6e988fb39936ae5.jpg)

Fig. 7. Decomposition of the trajectory of the global HANPP embodied in agricultural products from a) from 1986 to 2011, b) from 1986 to 1999 (with 1986 as a base year), and c) from 1999 to 2011 (with 1999 as a base year). Population growth linearly contributed to the growth in eHANPP over the entire period. The effect of consumption per capita was slightly negative until 1995 and rapidly increased thereafter. The drop in HANPP per unit of product could hinder the growth of eHANPP until 1999 but, but was not sufficient afterwards. At the global level, the mix of origin played a relatively small role. It contributed to the stabilization of eHANPP in the 1990s, but enhanced the eHANPP increase after 1999.   
![](images/89a9652890ccba93cf4223a8414281823158cb1c8b34c0604691c37466516725.jpg)  
Population Consumption per capita Mix of origin HANPP intensity eHANPP

land degradation is mostly linked to the rapidly growing population, because of the predominance of low yield, subsistence and shifting agriculture (Curtis et al., 2018; Kissinger et al., 2012). However, intra-regional trade and a small amount of agricultural imports that were sourced from more HANPP efficient regions improved the mix of origin of Sub Saharan Africa's consumption. Nevertheless, domestic consumption remains the norm because of high trade costs and difficult market access (Hertel, 2018). Increasing imports might therefore lower the pressure on Sub Saharan ecosystems. However, it has been argued that higher yields through sustainable intensification may be a better strategy in the long run (Abalu and Hassan, 1998; Gasparri et al., 2016; Kastner et al., 2014). Nonetheless, intensification can as well lead to rebound effects generating more deforestation (Kissinger et al., 2012). Hertel and colleagues similarly show that an African green revolution is likely to expand cropland use and $\mathrm{CO}_{2}$ emissions if markets are globally integrated, but could become land sparing if sustained over several decades (Hertel et al., 2014). Furthermore, Sub Saharan Africa is suspected

to be under high risk of further deforestation, especially for soy production caused by technology and knowledge transfers from South America (Gasparri et al., 2016). Intensification in Sub Saharan Africa therefore needs to be combined to efficient conservation strategies, including the protection of tropical forests and other natural ecosystems.

International trade within the regions analysed in this paper mostly reduced human pressures on land, as assessed with eHANPP, in the 1990s. During this period, various regional trade agreements emerged, including the Schengen Zone in Europe, Mercosur in South America, and, NAFTA in North and Central America. Although we did not study the causality of these agreements, the period of their implementation corresponds to reductions in HANPP linked to intraregional trade in these regions, mirroring the results from Martinez-Melendez and Bennett of land area savings from agricultural trade between the USA and Mexico (Martinez-Melendez and Bennett, 2016). This contrasts with the result from Xu et al. that trade across large distances is most beneficial for sustainability (Xu et al., 2020).

![](images/ae6a7dfe4efb62885c8588cd994a7426ce311188ec3788eaafbb7a40d6959e40.jpg)

![](images/b1564a23b4e31a1f239fc3dd2d8fbae82b72deec3597ddb6f8619281f2f08936.jpg)

![](images/a08a691732de09a0f657fff7ca6cf513b45b139a360a11bde4eaa1d05377013d.jpg)  
Fig. 8. Effect on agricultural eHANPP by world regions between 1986 and 2011 of changes in a) population, b) consumption per capita, c) HANPP intensity (HANPP per tonne of biomass). Not the different scales. Population growth boosted eHANPP in the Global South, especially in Sub Saharan Africa. The effect of consumption per capita was dominated by the consumption increases in East, Southeast and Southern Asia. The drop in HANPP per unit of product was most important in the global south. Refer to fig. S8 for country level data.

![](images/9f83eb66c7de35671408441adfc0052bec67656874465dc5924710d983589f5f.jpg)

![](images/49efb2d894c677872598f5a0ac05030fb106bca7fdf2487d7fda5d26e84f9bb1.jpg)

![](images/81a495666afff5e91795d5cbf640611af0b9e915e907aa2771fc03823551d51e.jpg)

Fig. 9. Decomposition of eHANPP in four world regions. In Western Europe $(\mathrm{EU}15+)$ , the mix of origin was the major driver explaining the rise in eHANPP. The MOO effect was the largest in Eastern Asia (different scales). The mix of origin reduced embodied HANPP mostly in Sub Saharan Africa and Central America.   
![](images/aca13fcc0512511bb817f35f742db502c60bd43d36128fac0222699cee513a3b.jpg)  
Population Consumption per capita Mix of origin HANPP intensity eHANPP

However, changes in interregional trade cancelled out benefits from intraregional trade from the late 1990s and outweighed them from the mid-2000s. Especially the acceleration of exports from tropical regions as South America and South East Asia to Europe and Asia greatly deteriorated the Human appropriation of NPP since the late 1990s. Generally, the tropics are characterized by higher impact on terrestrial ecosystems per unit of product than temperate regions (West et al., 2010). Exports of beef and Soy from South America have largely increased pressure on forest and other native vegetation in the Amazon, the Cerrado, or the Gran Chaco (Garrett and Rausch, 2016; Henders et al., 2015; Piquer-Rodriguez et al., 2018; Silva et al., 2017; Yao et al., 2018). Similarly, growing international demand for palm oil, either for biodiesel, food products or cosmetics is known to have boosted deforestation in South East Asia (Applanaidu et al., 2011; Henders et al., 2015; Rulli et al., 2019).

This evolution reflects important initiatives to liberalise global agricultural trade over the period. Among these, the General Agreement on Tariffs and Trade (GATT) Uruguay round was concluded in 1994, and culminated with the WTO's Agreement on Agriculture a year later. The latter aimed to enhance agricultural trade by limiting trade distorting domestic support, banning export subsidies and promoting market access to all signatories (WTO, 1995). It hence lead to the removal of various tariffs and other trade barriers, which significantly enhanced exports of agricultural commodities (Vollrath et al., 2009). China eventually entered the WTO in 2001, promising to limit domestic support and eliminate all agricultural export subsidies (Blancher and Rumbaugh, 2004). China consequently specialized in manufacturing according to its comparative advantage, hence boosting agricultural imports (Hertel, 2018). Meanwhile other trade agreements had been developed between world regions, as the EU-Chile association agreement signed in 2003.

Our results suggest that, on average, these efforts to liberalise trade have either not been sufficient to enhance trade where it would have increased the efficiency of land use, or that they often enhanced trade flows that increased pressure on land ecosystems, especially from tropical regions. Despite noticed gains from international trade, the global allocation of agricultural was overall less efficient with respect to NPP from the mid-2000s compared to 1986. As a contribution to the debate about potential land saving through international trade, we would hence argue that international trade may not always by itself optimize land use efficiency, challenging the environmental interpretation of Ricardian trade theory (Lambin, 2012).

Our results resonate with various trade theories. We first did not observe systematic resource efficiency gains predicted by Ricardian interpretations of land-use (Lambin, 2012). This may imply that the economic marginal productivity of land, and hence comparative advantage, does not reflect the environmental costs associated to land use. Similarly one may argue that international trade globally optimizes a bundle of social and natural inputs, but that land use may not have been optimized because of trade-offs with other resources. Pastor and colleagues indeed found that removing barriers to trade would optimize water use, but may enhance the conversion of forest and natural vegetation to agricultural land due to trade-offs between the allocation of water and land resources (Pastor et al., 2019). Our results could be interpreted through the lens of the Heckscher-Ohlin theorem (Jones, 1956), which states that when trade gets liberalised, each country tends to export goods whose production intensively requires the inputs that are abundant (and therefore cheaper) in that country. In other words, countries with abundant potential NPP (as in the tropics) and large available or un-regulated natural areas will be more likely to supply a lot of HANPP intensive products, as reflected in our results.

Note that we only analysed how international trade affected land use by reallocating the origin of agricultural products. However, international trade may as well affect the environment through other processes, as by changing supply and demand (e.g. by lowering the price of commodities), or affecting technology through the exchange of know-how

and intra-industry reallocation (Cherniwchan et al., 2017; Copeland et al., 2007). These effects should as well be considered to obtain a thorough picture of the effect of international trade on land use.

Finally, our reasoning was based solely on the eHANPP indicator, which despite its advantages, is not designed to reflect the entire panoply of sustainability aspects related to land and international trade. These have however been looked at in other studies using various approaches (Pace and Gephart, 2017). For example, modellers argue that full liberalisation of agricultural trade would increase global greenhouse gas emissions by more than $76\mathrm{Gt}$ cumulated $\mathrm{CO}_{2}$ emissions between 2005 and 2045, especially through the large shift of crops and beef production to South America (Schmitz et al., 2012; Verburg et al., 2009). Verburg et al. nonetheless argue that agricultural liberalisation could reduce emissions in the long run if spared surfaces in North America and Europe were converted back to natural vegetation, although this would still imply important losses of biodiversity. This reduction in GHG emissions would moreover happen after a significant time lag, hence increasing the risk of irreversible impacts by shooting over climate and ecosystem tipping points (Hirota et al., 2011; Lontzek et al., 2015; McBain et al., 2017; Reyer et al., 2015). Other important features related to land and international trade include the increasing specialisation of agricultural systems disturbing the nitrogen and phosphorus cycles (Billen et al., 2018; Schipanski and Bennett, 2012), pressure on material resources (Plank et al., 2018), or the loss of biodiversity (Chaudhary and Kastner, 2016; Lenzen et al., 2012).

Our study is as well constrained by the limitations linked to the calculation methods. For example, the physical trade matrices used to trace back trade flows to their first origin have been criticised for the truncation of supply chains and the omittance of agricultural products embodied in industrial sectors (Bruckner et al., 2015; Hubacek and Feng, 2016). Besides, countries which divided during the period (USSR, Yugoslavia, etc.), were aggregated to their largest level for consistency along the time series. This may have hidden further effects of international trade between the countries which used to be one. Finally, the MESE decomposition is sensitive to small values and data inconsistencies, which may have increased the importance of certain trade flows and years.

# 5. Concluding remarks

Humans are colonizing ecosystem functions such as NPP to produce agricultural commodities, leaving less energy for other species and ecosystem regulation. Recent changes in the origin of consumed agricultural commodities affected the degree to which humans are altering these ecosystem functions. Our results indicate that international trade may not always, by itself, reduce pressure on land ecosystems. Nevertheless, if explicitly framed to achieve sustainability goals, trade may as well be part of the solution. However, these benefits of trade may unlikely be achieved as a simple by-product of global trade liberalisation agendas. Sustainability and ecosystem conservation should hence become explicit, if not main target, in comprehensive trade regulations and global governance strategies.

# Appendix A. Supplementary data

Supplementary data to this article can be found online at https://doi.org/10.1016/j.ecolecon.2020.106915.

