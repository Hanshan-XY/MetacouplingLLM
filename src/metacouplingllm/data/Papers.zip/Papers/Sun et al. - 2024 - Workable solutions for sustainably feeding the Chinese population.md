# Workable solutions for sustainably feeding the Chinese population

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:07:34.839067+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Sun et al. - 2024 - Workable solutions for sustainably feeding the Chinese population.pdf
- Year: unknown
- DOI: 10.1016/j.resconrec.2024.107530
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines how China can meet its population´s food needs while lowering environmental impacts, using a metacoupling framework to connect domestic production and international trade. The geographic focus is mainland China, divided into North (sending system) and South (receiving system), and major soybean exporters Brazil and the United States (spillover systems).

The authors quantify carbon and water footprints, food supply and demand, and related economic costs for rice, wheat, corn, and soybeans across 31 Chinese provinces, plus soybeans produced in Mato Grosso (Brazil) and Illinois (US) and shipped to China. They aggregate these data to national and regional levels and compute food self-sufficiency and sufficiency rates based on calorie supply from crops and animal products. They also estimate how alternative scenarios affect United Nations Sustainable Development Goals (SDGs) scores for China, especially SDGs 2, 6, and 13.

Baseline results show that China´s domestic production provides about 92 percent of caloric needs and rises to 95 percent when soybean imports are included, at high carbon and water costs. Rice dominates environmental impacts, while domestic soybeans have relatively low total but high per-unit water use; imported soybeans have larger overseas footprints than domestic production.

Scenario analysis compares performance of smallholder and state-owned farms, changes in average farm size, shifts in soybean sourcing due to the China-US trade war, and prospective infrastructure upgrades in Brazil (Transoceanic Highway). Adopting best-performing practices from both farm types could cut agricultural carbon emissions by roughly one-third, reduce water use by about one-fifth, raise yields by about one-third, and push China´s food self-sufficiency beyond 100 percent. Other scenarios offer modest footprint reductions but much smaller gains.

This work is explicitly framed as a metacoupling analysis, integrating intra-national flows (North-South grain transfers) and international telecouplings (soybean trade) to identify low-investment, policy-aligned options for feeding China within a planetary safe operating space.

## Structured Metacoupling Extraction

### Coupling Classification
- Explicit metacoupling of Chinese food system; strong intra, peri, and telecouplings via crops and trade

### Intracoupling
#### Systems
- North China food production regions
- South China food consumption regions
- National Chinese food system including livestock feed
#### Flows
- Domestic transport of rice wheat corn soybeans from North to South
- Flows of irrigation water and on farm energy within provinces
- Capital and knowledge flows between smallholding and state owned farms
#### Agents
- Smallholding farmers and family farms
- State owned farm managers and technicians
- Chinese national and provincial governments
#### Causes
- Rising population and dietary shift toward animal products
- Policies favoring grain self sufficiency for rice wheat corn
- Legalization of land transfer expanding farm size
#### Effects
- High domestic carbon and water footprints of staple crops
- Regional food self sufficiency gaps especially in South China
- Changes in SDG 2 6 13 scores and overall SDG ranking

### Pericoupling
#### Systems
- North and South China as coupled sending receiving regions
- Neighboring Asian Pacific trading partners via maritime routes
#### Flows
- Interregional trade of domestically grown staples
- Near distance sea transport routes in Pacific region
#### Agents
- Regional logistics companies and port authorities
- Interprovincial planners coordinating grain transfers
#### Causes
- Spatial mismatch between production rich North and consumption rich South
- Infrastructure development along Pacific oriented routes
#### Effects
- Different regional carbon and water footprints per unit crop
- North China achieving surplus while South remains deficit

### Telecoupling
#### Systems
- China as major soybean importing system
- Brazilian soybean regions such as Mato Grosso
- US Midwest soybean regions such as Illinois
#### Flows
- Large scale soybean trade from Brazil and US to China
- Maritime and land based soybean transportation emissions
- Virtual water and embodied carbon in imported soybeans
#### Agents
- International grain traders and shipping companies
- Brazilian and US farmers and logistics operators
- Chinese policymakers reacting to China US trade war
#### Causes
- High Chinese dependence on imported soybeans for feed and oil
- China US trade war shifting import shares toward Brazil
- Brazilian transport infrastructure expansion like Transoceanic Highway
#### Effects
- Overseas emissions and water use exceeding domestic soybean footprints
- Slight reductions in global footprints by sourcing more from Brazil
- Telecoupled changes in Chinese SDG performance via trade scenarios

### Cross-Coupling Interactions
- Domestic production choices interact with overseas trade to determine national food sufficiency
- Infrastructure in Brazil alters environmental cost of meeting Chinese soybean demand
- Farm structure reforms within China modulate reliance on telecoupled soybean imports

### Research Gaps or Limitations
- Soil process emissions and gray water not yet included in footprint accounting
- Scenario solutions omit detailed assessment of social equity and farmer livelihoods
- Future policy dynamics climate change and trade politics introduce large uncertainties

### Search Keywords
- China food security metacoupling soybean trade
- carbon water footprints North South China
- Brazil US soybean transport Transoceanic Highway

### Extraction Confidence
high
