# Distal impacts of aquarium trade Exploring the emerging sandhopper (Orchestoidea tuberculata) artis

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:08:28.123641+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Tapia-Lewin et al. - 2017 - Distal impacts of aquarium trade Exploring the emerging sandhopper (Orchestoidea tuberculata) artis.pdf
- Year: unknown
- DOI: 10.1007/s13280-017-0906-x
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines how global demand from the aquarium trade has triggered a new small-scale shore-gathering fishery for the amphipod sandhopper Orchestoidea tuberculata on sandy beaches in central Chile (Region VI). The system links distant aquarium consumers and pet supply chains to coastal communities that traditionally rely on seaweed and shellfish, creating a clear telecoupling: the distal driver is aquarium food demand, the local effect is an emergent invertebrate fishery.

Using mixed qualitative and quantitative methods between 2007 and 2008, the authors combined participant observation, semi-structured interviews with 20 shore gatherers, and basic ecological measurements and catch-per-unit-effort (CPUE) estimates on two beaches. They also interviewed two companies and visited pet shops to reconstruct the value chain.

Gatherers use two trap-based methods at night during low spring tides, both baited with stranded kelp. A more capital- and labor-intensive trap design (buried plastic bags) delivers about double the CPUE per trap and three- to fourfold higher daily and annual catches than a simpler bottle trap. This higher-yielding technique defines a specialist group of gatherers who now obtain roughly similar annual income from sandhoppers and seaweed, while non-specialists still depend mainly on seaweed. Entry costs are low and the activity is unregulated and open access.

Local ecological knowledge is strong: gatherers time effort to sandhopper activity rhythms, track tidal cycles, recognize drivers of abundance, and informally rotate beach sectors. Most perceive a decline in sandhopper numbers and do not believe current techniques guarantee sustainability, yet nearly all report rising prices and few immediate problems, highlighting a tension between economic incentives and conservation.

National trade volumes reach at least tens of tons wet weight annually, with very large markups between beach and retail levels. The fishery was previously unrecorded and still lacks formal management. The authors emphasize that this distal effect of aquarium markets on Chilean sandy-beach ecosystems fits the telecoupling framework and constitutes an early warning case of a rapidly expanding, profitable, but ecologically unassessed coastal resource use.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via global aquarium trade; local intracoupling of Chilean sandy beach social-ecological system.

### Intracoupling
#### Systems
- Chilean sandy beach ecosystems in Region VI
- Coastal artisanal shore-gatherer communities near Bucalemu
#### Flows
- Harvest of sandhopper from intertidal zones
- Knowledge, labor, and income within shore-gatherer households
#### Agents
- Artisanal shore gatherers and families
- Local middlemen and processing companies
- National fisheries authority SERNAPESCA
#### Causes
- Local livelihood diversification from seaweed to sandhopper
- Low entry costs and high local sandhopper prices
- Open access shore-gathering conditions without specific rules
#### Effects
- Increased income and specialization for some gatherers
- Perceived sandhopper population decline on harvested beaches
- Emerging need for local management plans and monitoring

### Pericoupling
#### Systems
- Neighboring beaches Las Cruces and Las Trancas
- Regional fishery governance within Region VI of Chile
#### Flows
- Movement of gatherers and traps between nearby beaches
- Regional trade of dried sandhopper to processing firms
#### Agents
- Gatherers operating across multiple beaches
- Regional fisheries officers and programs
#### Causes
- Spatial spillover of profitable shore-gathering practice
- Regional open access and weak reporting of landings
#### Effects
- Potential regional underestimation of catch volumes
- Possible cumulative ecological impacts along coastlines

### Telecoupling
#### Systems
- Chilean coastal sandhopper fishery system
- International aquarium trade supply chains and consumers
#### Flows
- Dried sandhopper as aquarium animal food replacing imported scuds
- Global market demand and price signals for aquarium feed
#### Agents
- International aquarium industry and pet shops
- Importers and retailers of aquarium supplies
- Policy-makers considering telecoupled fishery management
#### Causes
- Rising global demand for aquarium species and feed
- Switch from imported Gammarus to locally sourced sandhopper
- Lack of attention to indirect effects of aquarium trade
#### Effects
- Rapid emergence of unregulated local sandhopper fishery
- Economic incentives driving specialization and effort increase
- Potential alterations of sandy beach food webs and ecosystem functions

### Cross-Coupling Interactions
- Global aquarium demand drives local sandhopper harvesting, which reshapes regional livelihoods and ecosystems.
- Local overharvest risks could feed back to global supply chains via scarcity or price changes.

### Research Gaps or Limitations
- Ecological impacts of sandhopper removal on sandy beach food webs remain unquantified.
- Spatial-temporal variation in CPUE and stock status across different beach morphodynamics is unknown.
- Official statistics likely underestimate catch; broader, long-term monitoring and stock assessments are missing.

### Search Keywords
- telecoupling aquarium trade sandhopper Chile
- artisanal shore gathering sandy beach fishery
- Orchestoidea tuberculata distal impacts

### Extraction Confidence
high
