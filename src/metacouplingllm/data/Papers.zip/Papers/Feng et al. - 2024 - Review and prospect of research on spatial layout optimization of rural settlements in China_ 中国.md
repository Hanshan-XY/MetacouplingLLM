# Review and prospect of research on spatial layout optimization of rural settlements in China_ ä¸­å›½

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:44:01.090312+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Feng et al. - 2024 - Review and prospect of research on spatial layout optimization of rural settlements in China_ ä¸­å›½.pdf
- Year: unknown
- DOI: 10.11821/dlyj020240064
- OA status: unknown
- License: none recorded
- Category: Journal Articles\Review\Telecoupling
- Closed-access reason: no license info, oa_status=unknown

## Copyright-Safe Summary
This review paper synthesizes Chinese research on how to optimize the spatial layout of rural settlements, understood broadly as village and small-town residential land. The work is national in scope but draws on case studies from diverse regions and terrains across China. It focuses on rural land-use restructuring within the wider system of rapid industrialization, urbanization, and strict national land policies.

Methodologically, the authors use a structured literature review based on Chinese and international databases, combined with inductive and logical analysis. They organize existing work into five components: concepts, spatio-temporal patterns, driving mechanisms, technical approaches, and optimization modes.

The review shows that definitions of rural settlements vary by discipline (geography, land management, sociology), but a geographic perspective emphasizes three basic properties: they are integrated socio-ecological systems, involve multiple interacting elements and functions, and exhibit strong scale effects from village to national level. Empirical studies reveal marked regional differentiation and clear geographic orientation: settlements tend to cluster in low, flat, accessible, agriculturally favorable areas, and overall have expanded in scale and density over recent decades.

Drivers of layout change and optimization are grouped into natural conditions, socio-economic processes, and policy-institutional frameworks. Their interaction generates wide-ranging social, economic, cultural, resource, and ecological impacts. For analysis and planning, researchers commonly combine 3S technologies (RS-GIS-GPS), econometric models, and emerging big-data and machine-learning tools. Planning ideas are often structured around grading, classification, and zoning, while practical optimization is summarized into four dominant modes: scale control, factor reorganization (people-land-industry), structural adjustment of land use, and functional upgrading or diversification.

In terms of telecoupling and metacoupling, the paper explicitly calls for future research to integrate remote urban-rural linkages and digital connectivity into models of rural settlement change, and to examine feedbacks between distant drivers (policies, labor flows, capital, information) and local spatial restructuring. It thus positions rural settlement optimization as a key arena where telecoupled land systems and digital transformations converge, but notes that most existing studies are still not framed directly within formal telecoupling or metacoupling theory.

## Structured Metacoupling Extraction

### Coupling Classification
- Mainly intracoupling within rural human land systems, with some telecoupling via urban rural land policies

### Intracoupling
#### Systems
- Rural settlements as human land coupled systems in Chinese villages
- Local agricultural land and surrounding ecosystems
- Village socio economic and cultural structures
#### Flows
- Internal land use change between housing, farmland, industry, ecology
- Circulation of labor, capital, and village public investment
- Information and policy directives within rural governance hierarchy
#### Agents
- Village households and collectives
- Township and county governments
- Local enterprises and cooperatives
#### Causes
- Local natural conditions such as terrain, soil, water, climate
- Village level economic development and infrastructure upgrades
- Local implementation of land and planning regulations
#### Effects
- Settlement expansion, hollowing, and spatial disorder
- Changes in rural livelihoods, income, and employment
- Impacts on local ecosystems, landscape, and ecological security

### Pericoupling
#### Systems
- Adjacent villages and township centers
- Nearby small and medium sized towns
- Regional agricultural and ecological zones
#### Flows
- Short distance commuting for work, services, and education
- Nearby relocation and village merging for land consolidation
- Regional infrastructure, transport, and service networks
#### Agents
- Township governments coordinating multiple villages
- County planners and land bureaus
- Regional construction and real estate firms
#### Causes
- Town radiation and urban expansion into nearby rural areas
- Regional infrastructure improvements changing accessibility
- Inter village land consolidation and resettlement policies
#### Effects
- Spatial clustering or dispersal of settlements within town hinterlands
- Regional differentiation in land use intensity and functions
- Redistribution of environmental and governance costs between neighbors

### Telecoupling
#### Systems
- Rural settlements and distant cities within China
- Sending rural regions and receiving urban industrial regions
- Rural areas and national level governance and policy system
#### Flows
- Rural to urban labor migration and remittances
- Transfer and trading of construction land quotas across regions
- Telecoupled policy instruments like land balance and index swaps
#### Agents
- Central government designing telecoupled land policies
- Provincial and prefecture governments trading land quotas
- Urban investors and developers using rural sourced indicators
#### Causes
- Rapid industrialization, urbanization, and globalization
- National strategies for urban rural integration and food security
- Remote coupling policies such as land quota linkage schemes
#### Effects
- Decoupling between rural population decline and construction land growth
- Cross regional redistribution of land development opportunities
- Feedback of telecoupled changes on rural landscapes and social structures

### Cross-Coupling Interactions
- Telecoupled land policies reshape local settlement layouts and pericoupled town village relations
- Urban demand and migration interact with local land systems via remote feedback loops
- Digital technologies connect rural physical space with virtual urban centered networks

### Research Gaps or Limitations
- Need deeper analysis of urban rural telecoupling and feedback with settlement change
- Limited integration of digital data and intelligent models into routine planning decisions
- Insufficient understanding of mixed rural space and its governance mechanisms

### Search Keywords
- rural settlements spatial layout China
- urban rural telecoupling land quota
- rural land consolidation optimization

### Extraction Confidence
high
