# Quantitative analysis of local coupling and telecoupling mechanism between urbanization and ecologic

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:20:59.568670+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Zhao et al. - 2025 - Quantitative analysis of local coupling and telecoupling mechanism between urbanization and ecologic.pdf
- Year: unknown
- DOI: 10.1016/j.ecolind.2025.113345
- OA status: gold
- License: cc-by-nc-nd
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This paper examines how urbanization and ecological environment quality interact locally and over distance in a major Chinese urban cluster, using an explicit telecoupling perspective.

The study focuses on the Chengdu-Chongqing Economic Circle (about 185,000 km2 in western China), a fast-growing megaregion with severe environmental pressures such as air pollution, water scarcity, erosion, and biodiversity loss. The authors argue that conventional analyses emphasize only within-city or within-region linkages, ignoring cross-regional influences among urban and ecological systems.

Using multi-source remote sensing and GIS data from 2000-2020, the authors construct two improved indices. First, they upgrade the remote sensing ecological index by adding a biological abundance component based on land-cover types, creating an MRSEI to better capture ecosystem status and biodiversity. Second, they refine the composite nighttime light index by incorporating built-up land area, generating an MCNLI that more accurately reflects urbanization, especially in smaller cities. They then integrate local coupling and distance-decay-weighted telecoupling into a Local and Tele-Coupling Coordination Degree (LTCCD) model to quantify how urbanization and ecological quality co-evolve across cities.

Results show rapid, spatially uneven urbanization, forming a dual-core ring structure centered on Chengdu and central Chongqing. Overall ecological quality remains generally good but declines over time, with a ring pattern of low quality in core cities, medium quality in central hills, and high quality in surrounding mountains. The LTCCD increases over the study period, indicating a shift from non-coordination to better coordination, but large inter-city disparities persist. High coordination clusters around the core cities, while central and peripheral areas lag, showing strong spatial clustering.

The work directly advances telecoupling/metacoupling research by operationalizing a joint local-telecoupling measure for urbanization-environment interactions and demonstrating how inter-city flows of people, capital, and information reshape regional human-environment linkages and sustainability prospects.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong focus on intracoupling and regional telecoupling between urbanization and ecological quality in CCEC

### Intracoupling
#### Systems
- Urbanization system within Chengdu Chongqing Economic Circle
- Local ecological environment quality within CCEC
#### Flows
- Land conversion from ecological land to construction land
- Local pollution emissions affecting air water soil
#### Agents
- Municipal and county governments in CCEC
- Local residents and enterprises
#### Causes
- Rapid urban expansion and industrialization inside the megalopolis
- Local policy focus on economic growth over environment
#### Effects
- Decreasing ecological quality in core cities
- Spatial pattern of dual core urbanization with peripheral better ecology

### Pericoupling
#### Systems
- Core cities Chengdu Chongqing and surrounding intermediate cities
- Intermediate hilly belts and adjacent peripheral mountainous areas
#### Flows
- Short distance commuting migration and infrastructure links
- Spillover of construction land and industrial parks
#### Agents
- Regional planning agencies of Sichuan and Chongqing
- Developers expanding from cores into nearby districts
#### Causes
- Core city radiation driving urbanization in neighboring districts
- Redistribution of population industry and investment to nearby areas
#### Effects
- Ring shaped gradients of urbanization and ecological quality
- Shift of many cities from low to basic coordination

### Telecoupling
#### Systems
- Urban ecological system of each CCEC city
- Other CCEC cities connected through factor flows
#### Flows
- Intercity flows of population capital technology information
- Telecoupled influence of one citys urbanization on others ecology
#### Agents
- National and provincial governments shaping megalopolis strategy
- Intercity economic actors and infrastructure operators
#### Causes
- Economic globalization and national policy promoting CCEC integration
- Strengthened interregional transport and information networks
#### Effects
- Higher LTCCD than local CCD due to positive teleconnections
- High high clusters of coordination around Chengdu and Chongqing cores

### Cross-Coupling Interactions
- Telecoupling amplifies or mitigates local urbanization impacts on ecology across cities
- High urbanization cores radiate coordination benefits yet degrade their own ecological quality

### Research Gaps or Limitations
- Telecoupling analyzed only within CCEC rather than with external regions
- Ecological index omits some ecosystem functions and service dimensions
- Urbanization proxy still constrained by nighttime light and land cover data resolution

### Search Keywords
- Chengdu Chongqing Economic Circle telecoupling
- urbanization ecological environment coupling coordination
- MCNLI MRSEI LTCCD remote sensing

### Extraction Confidence
high
