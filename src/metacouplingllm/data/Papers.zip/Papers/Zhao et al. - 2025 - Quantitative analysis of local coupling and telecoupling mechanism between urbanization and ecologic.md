# Quantitative analysis of local coupling and telecoupling mechanism between urbanization and ecological environment quality based on multi-source remote sensing data

![](images/3fe4e9f5cc189d5191a9906eb370e99fab3611bb7870d034f011f1037d36bec6.jpg)

Xiaoyan Zhao a,b,c , Shucheng Tan d,e,* , $\mathrm { d } , \mathrm { e } , ^ { \ast } \mathrm { e }$ Yongping Li f , Shamshad Khan

a Institute of International Rivers and Ecological Security,Yunnan University, Kunming 650500, PR China   
b School of Geography and Resource Science, Neijjiang Normal University, Neijiang 641000 Sichuan, PR China   
c Sichuan Key Laboratory of Ecological Environment Data Analysis and Green Development Intelligent Decision-Making for the Upper Yangtze River, Neijiang Normal University, PR China   
d School of Earth Science, Yunnan University, Kunming 650500, PR China   
e Yunnan International Joint Laboratory of Critical Mineral Resource, Kunming 650500, PR China   
f Office of International Exchange and Cooperation, Neijjiang Normal University, Neijiang 641000 Sichuan, PR China

# A R T I C L E I N F O

Keywords:

Urbanization

Ecological environment quality

Coupling mechanism

Chengdu-Chongqing Economic Circle

Sustainable development

# A B S T R A C T

Delving deeply into the interactive coupling mechanism between the ecological environment quality (EEQ) and urbanization has already become the key to the coupled human-environment, and the core element for achieving the goal of sustainable development. Following the continuous advancement of economic globalization, the longterm interaction models among regions have been continuously strengthened. The proposal of the telecoupling concept has expanded the analytical dimension of the research on the coupling mechanism between urbanization and the natural environment. However, standard measurement of the coupling mechanism between urbanization and the ecological environment only considers local coupling while ignoring telecoupling. The remote sensing ecological index (RSEI) approach for assessing EEQ does not account for the abundance index (AI) of biological species in an ecosystem. The accuracy of measuring the urbanization level (UL) of small areas by nighttime light (NL) data is not high due to the influence of resolution. Therefore, this study has improved the RSEI model and the nighttime light index (CNLI) model, and carried out a quantitative research on the local coupling and telecoupling coordination degree (LTCCD) between urbanization and the EEQ of the Chengdu-Chongqing Economic Circle (CCEC) from 2000 to 2020. The results show that: (1) The improved research methods can objectively and quantitatively evaluate the LTCCD between urbanization and the EEQ of the CCEC. (2) The development level of urbanization shows a significant growth trend, with a yearly average growth rate of $0 . 0 0 7 1 6 \mathrm { a } ^ { - 1 }$ , and spatially forms an urban circle development pattern of “dual-core-periphery structure”. (3) The entire EEQ is oscillating downward, with an average yearly increase rate of $- 0 . 0 0 3 4 9 \mathrm { a } ^ { - 1 }$ , and spatially presents a circular distribution pattern of “poor EEQ in core cities, average in intermediate hilly areas, and good in peripheral mountainous areas”. (4) The LTCCD value has a growth rate of $0 . 0 0 9 8 6 \mathrm { a } ^ { - 1 }$ , and the differences among cities are significant. The radiation ability of cities presents the spatial characteristics of “strong in core cities such as Chengdu and Chongqing, and weakened in central and marginal cities”. The urbanization and EEQ of the CCEC have experienced a development process from non-coordination to coordination. In order to promote regional economic development, natural environment protection, implement the concept of sustainable development, corresponding suggestions, and measures have been proposed based on city coupling and coordination levels.

# 1. Introduction

Since the onset of the Anthropocene (Steffen et al., 2015), economic development, technological advancements, population growth, and

migration have intensified exchanges and connections among regions, leading to the widespread emergence of large-scale urbanization across the globe. The global urbanization rate has witnessed rapid growth, with the most significant contributions coming from developing countries.

E-mail address: shchtan@ynu.edu.cn (S. Tan).

The majority of developing countries have made remarkable contributions to the increase in global urbanization rates (Bai et al., 2016; Liu et al., 2020). As per the 2022 World Cities Report named “Envisioning the Urban Future”, the proportion of the global population dwelling in cities is set to increase from $5 6 \%$ in 2021 to $6 8 \%$ in 2050 (World Urban Forum (WUF11)., 2022). From 1978 to 2022, China’s urbanization rate has shown a rapid upward trend, climbing from $1 7 . 9 2 \ \%$ to $6 5 . 2 2 ~ \%$ . Meanwhile, the urban population has increased by as many as 750 million, with a mean yearly growth rate reaching $1 . 0 6 \%$ . However, the model of urbanization development that pursues economic growth over environmental and resource degradation has brought about extremely serious problems with the environment and resources, such as the disorderly expansion of construction land, air pollution, water pollution, environmental destruction and resource shortages (An et al., 2022a; Oo et al., 2020). At the same time, the natural environment damaged and polluted by humans will restrict the development of urbanization in terms of space and quality (Zhang et al., 2020). How to scientifically coordinate the mutual coupling mechanism between urbanization and the environment is crucial to promoting the development of green, healthy, and sustainable cities as well as the preservation and sustainable growth of the natural environment.

In 1991, the World Health Organization highlighted two major global challenges: the degradation of the natural environment and the deteriorating standard of urban life (World Health organnization (WHO)., 1992). International Human Dimensions Programme on Global Environmental Change recognized environmental change and urbanization as significant scientific concerns in 2005 (Sanchez-Rodriguez et al., 2005). The International Scientific Council in November 2014, identified the sustainable development of urbanization and terrestrial ecosystems as key research priorities in its “Future Earth 2025 Vision.” (Fang et al., 2016b; Liu et al., 2015a). In October 2017, in response to the urbanization problems faced by China, the Chinese government pointed out that a new path of sustainable development and high-quality of urbanization should be built, which is low-carbon, environmentally friendly, harmonious between humans and the land, innovative, intelligent, and efficient (Fang, 2019). In conclusion, countries around the world are increasingly recognizing the importance of tackling natural and urban environmental issues. It can be seen from this that the research on the interactive coupling effect between the natural environment and urbanization has already become the frontier and popular topic in the fields of Earth system science.

Driven by the advancement of economic globalization and urbanization, the movement of key elements such as population, capital, technology, goods, and information has expanded spatial boundaries and strengthened interregional exchanges (Ma et al., 2020; Tang, 2022). Since the 1950 s, human activities have caused more drastic alterations to natural systems than at any other time in history, and the most prominent manifestation is the gradually increasing coupling effect between long-distance human activities and ecological systems (Liu et al., 2007). The new concept of telecoupling was put forward in response to the interactions between long-distance human-earth relationship coupling systems (Hull and Liu, 2018; Liu et al., 2016). Currently, the applied research on telecoupling primarily focuses on the fields of land use change (Boillat et al., 2017), ecosystem services (Schroter ¨ et al., 2018; Wang et al., 2015; Kolosz et al., 2018), and the interactive impacts of social economy and environment (Zimmerer et al., 2018; Abhishek et al., 2017). Therefore, the coupling relationship between natural environment and the urbanization has been redefined. According to Liu et al. (2016), it is now not only restricted to the interactive effects between the natual environment and the urbanization systems inside a region (local coupling), but also encompasses the nonlinear coupling (telecoupling) between the natual environment and urbanization systems outside the region and the ecological environment and urbanization systems inside the region. Consequently, the two-part process that connects urbanization to the natural environment has evolved telecoupling and local coupling.

As one of the five megalopolises in China (Fang et al., 2016c), the Chengdu-Chongqing Economic Circle (CCEC) consists of two main large cities, namely Chengdu and Chongqing, as well as the surrounding cities within a specific scope. Research data showed that for every $1 \ \%$ increase in China’s urbanization rate from 2006 to 2030, the amount of water used, the area of land used for construction, the energy used, and the ecological overloading that results are 1.88 times, 3.45 times, 2.89 times, and 2.42 times higher than those from 1980 to 2005. This situation is extremely prominent in megalopolises (Fang, 2009, 2014; Zhao et al., 2025), indicating that the CCEC is facing intense interactive stress from both urbanization and the natural environment (Tian et al., 2019; Fang et al., 2017). Currently, existing studies have carried out in-depth analyses of the local coupling relationship between natural environment and the urbanization. Xu et al. (2021b) and Yao et al. (2023) have respectively conducted quantitative studies on the local coupling mechanisms between urbanization and the natural environment in the eastern region of China, and in the demonstration areas of ecological civilization. Meanwhile, research has also been conducted on the concepts, principles, and mechanisms of the telecoupling between urbanization and the natural environment (Liu et al., 2015b; Martin-Lopez et al., 2019). In terms of the social economy and environment, earlier studies have examined the telecoupling of factors including land (Silva et al., 2020; Kan et al., 2023), food (Yao et al., 2018), energy (Fang et al., 2016a), and environmental pollution (Liu et al., 2017). To quantitatively examine the mechanism of coupling between the natural environment and urbanization, it is still unclear how to fully take into account both local coupling and telecoupling. Investigating the local coupling and telecoupling mechanisms between the biological environment and urbanization is therefore extremely important.

Remote sensing images possess the advantages of high precision, broad coverage, large time scale, rapid update, and strong objectivity. They can make up for the deficiencies of socio-economic statistical data, it is widely used to measure urbanization and ecological environment quality (EEQ) (Levin et al., 2020; Shan et al., 2019). There are several methods for measuring EEQ, such as the Pressure-State-Response model (PSR) (Liu, 2019; Ni, 2021), the Ecological Environment Index (EI) model (Wang et al., 2019; Yang & Li, 2022), and the RSEI (Xu, 2013). The PSR and EI models’ limitations include fixed outcomes and hard-toobtain indicators, as well as their inability to quantitatively assess the spatial distribution of EEQ (An et al., 2022b). The RSEI model offers the benefits of visualizing outcomes, having indicators that are simple to obtain, and not requiring weights to be specified (Zhao et al., 2025). Scholars utilize it extensively because it can achieve the accurate, quick, and real-time evaluation of regional EEQ (Xiong et al., 2021; Zhang et al., 2023a; Zheng et al., 2022). Nevertheless, the diversity of species in the local ecological context and the depletion of biological resources are still issues with the RSEI model. Therefore, we calculated the AI (Xu et al., 2021a) with reference to the “Technical Specification for Evaluation of Ecological Environment Status”(HJ 192–2015) and proposed an improved remote sensing ecological index(MRSEI) to enhance the applicability and scientific nature of the research results (Jia et al., 2021; Li et al., 2023b; Xu and Deng, 2022). The intensity and area of nocturnal light can be used to gauge the degree of urbanization. Tang et al. (2021) proposed the CNLI model constructed by nighttime light intensity and light area. However, the maximum spatial resolution of the currently available nocturnal light data is $5 0 0 \mathrm { ~ m ~ }$ . Measuring the urban construction situation in small areas by light area and intensity is not accurate enough, which affects the precision of the research results. We referred to the studies of Chen et al. (2020), Xu et al. (2021a), and Tang et al. (2021), added the index of construction land area to make up for the defect of low precision in measuring the construction situation of small cities by traditional data, and constructed an improved nocturnal light index (MCNLI) model to measure the degree of urbanization and improve the precision of the research results.

In summary, research on the natural environment and urbanization faces three challenges. Firstly, the traditional research on measuring the

EEQ fails to consider the impact of urbanization on the biological abundance of the ecosystem. Secondly, the measurement of the urban construction situation in small areas was inaccurate in the past when using NL data to measure the degree of urbanization because the maximum spatial resolution of the data was $5 0 0 \ \mathrm { m }$ . Thirdly, there is currently no quantitative analysis of the telecoupling mechanism between urbanization and the ecological environment. Hereafter, this research utilizes a MCNLI model to measure the level of urbanization and a MRSEI model to measure the EEQ using data from many remote sensing sources. A quantitative analysis of the degree of coupling coordination between urbanization and the natural environment in the CCEC from 2000 to 2020 has been conducted by combining the LTCCD model. The following are the research’s innovative points. Firstly, the MRSEI model constructed by the dryness (NDBSI), greenness (NDVI), heat (LST), AI and wetness (WET) is created to scientifically measure the EEQ. Secondly, the MCNLI model constructed by the NL intensity, area and construction land area indices is created to precisely gauge the degree of urbanization. Thirdly, the local coupling model is combined with the suggested telecoupling concept and model to perform a quantitative analysis of the interaction coupling mechanism between urbanization and the natural environment in the CCEC.

# 2. Materials

# 2.1. Study area

The CCEC spans $1 0 3 ^ { \circ } 3 6 ^ { \prime } \mathrm { E }$ to $1 0 5 ^ { \circ } 2 0 ^ { \prime } \mathrm { E }$ and $2 7 ^ { \circ } 5 0 ^ { \prime } \mathrm { N }$ to $2 9 ^ { \circ } 1 6 ^ { \prime } \mathrm { N }$ in latitude and longitude, with Chengdu and Chongqing serving as its cores. It is an essential region for western China’s high-quality growth. The CCEC comprises of 15 cities in Sichuan, as per the development plan of the CCEC document issued by the State Council of China in May 2016 (Except for some counties in Ya’an, Dazhou and Mianyang), as well as 27 districts (counties) in Chongqing and some areas of Kaizhou and Yunyang, which together cover an area of about $1 8 5 , 0 0 0 ~ \mathrm { k m ^ { 2 } }$ (Zhang et al., 2023b). Due to the large number of districts in Chongqing, considering that Yuzhong, Jiangbei, Dadukou, Shapingba, Nan’an, Beibei, Jiulongpo, Yubei and Ba’nan District are relatively concentrated geographically and are very closely connected from the perspectives of economy, urban construction and transportation hubs, these nine

districts are collectively named as the main urban area of Chongqing (Fig. 1). The terrain and landforms in the region are complex and diverse, there are numerous rivers, and the climate is pleasant. However, the natural ecosystem is greatly affected by human activities (Yu and Han, 2016). Boasting a remarkably high population density, by the end of 2022, the permanent population had soared to 98.745 million. The total economic output was 7.8 trillion yuan, and the per capita GDP was 79,000 yuan (Lin et al., 2023). From 2017 to 2022, the improvement degree of air quality in the Chengdu-Chongqing region was only $2 1 \ \%$ , lower than the national average level. The per capita water resources in the main urban area of Chongqing are only about $3 0 0 ~ \mathrm { { m } ^ { 3 } }$ , and the centralized collection rate of urban domestic sewage in the region is less than $6 0 ~ \%$ . The number of geological disasters that occurred in 2021 exceeded 2,000, and the area of soil and water erosion above the moderate level accounted for nearly $3 0 ~ \%$ in 2022. Under the influence of human activities, prominent ecological environmental issues, including air pollution, water resource shortage, geological disasters, soil erosion, meteorological disasters, and sharp reduction in biodiversity have emerged (Zhang et al., 2022). Thus, urbanization has impacted and harmed the ecological environment’s structure and function, and there is a misalignment and imbalance (gap) between the ecological environment’s sustainability and the healthy growth of urbanization (Liu et al., 2022). In conclusion, the Chengdu-Chongqing megalopolis is a demonstration area for the construction of urbanization in the western region and a crucial growth pole for high-quality economic development. Therefore, coordinating the coupling relationship between the urbanization of the megalopolis and the ecological environment is crucial to promoting the healthy development of cities and accomplishing the objective of regional sustainable development.

# 2.2. Study data

Landsat 5 TM, Landsat 8 OLI/TIRS remote sensing pictures, NL data, land use type are used in this research (Table 1). The China Land Cover Dataset, which spans the years 1985 to 2020, provides the land use type data (Yang and Huang, 2021). The NL data is the calibrated “NPP-VIIRSlike NTL Data” from the National Center for Systems Science Research (Chen et al., 2021). Xu Hanqiu’s RSEI model, which is made up of the WET, NDVI, NDBSI, and LST indices, did not assess AI as needed by the

![](images/c11d185a9c9ab32beff9919824545f3ced3dc1c758348c87f0ff092c6135d9a5.jpg)  
Fig.1. Location map of CCEC.

Table 1 Study Data Sources and Description.   

<table><tr><td>Data types</td><td>Data sources</td><td>Spatial resolution</td><td>Time scale (years)</td><td>Data purpose</td></tr><tr><td>Landsat 5 TM</td><td>GEE Platform( https:// earthengine. google.com/)</td><td>30 m</td><td>2000–2013</td><td>Calculate RSEI Indicators</td></tr><tr><td>Landsat 8 OLI/ TIRS</td><td>GEE Platform (https:// earthengine. google.com/)</td><td>30 m</td><td>2014–2020</td><td>Calculate RSEI Indicators</td></tr><tr><td>NPP- VIIRS- like NTL Data</td><td>China Earth System Science Data Center (https://www. geodata.cn/ data/)</td><td>500 m</td><td>2000–2022</td><td>Calculate urbanization level Indicators</td></tr><tr><td>Land use type</td><td>GEE Platform( https:// earthengine. google.com/)</td><td>30 m</td><td>1985–2020</td><td>Calculate AI Calculation building land area Indicators</td></tr></table>

HJ 192–2015 Considering the complex ecosystem and rich biomass in the study area, a new AI has been added to construct a MRSEI. The WET, NDVI, LST, and NDBSI indices are derived from Landsat series pictures using programming codes and are based on the Google Earth Engine (GEE) platform. The AI is calculated by referring to the HJ 192–2015 and obtaining the areas of different land types. The spatial distribution of human activities can be measured using NL data. Previous studies have demonstrated that the intensity and extent of lights are strongly correlated with the degree of urbanization(Chen et al., 2003; Levin et al., 2020). However, due to limitations in data accuracy, the measurement of urban development in smaller areas lacks precision. According to Chen et al. (2003), the area of land used for construction provides a more accurate indicator of the degree of urbanization.

Therefore, this study constructs a MCNLI using the intensity of lights, the area of lights, and the area of construction land. The NPP-VIIRS-like NTL Data is used to obtain the intensity and area of lighting indices. The area of construction land index is calculated and obtained through the land use type data.

# 3. Methods

Fig. 2 displays the study’s theoretical framework. Firstly, an analysis was conducted on the NPP-VIIRS-like NTL Data and land use type data to calculate the indicators such as NL intensity, NL area, and built-up land area. To gauge the degree of urbanization, the MCNLI model was created. Secondly, the Landsat series of remote sensing pictures and land use type data were analyzed and processed in order to compute the indicators of WET, NDVI, LST, AI, and NDBSI Thirdly, the coupling mechanism between urbanization and the natural environment in the CCEC was quantitatively analyzed using the LTCCD model. Countermeasures and recommendations were also proposed based on the coordination and coupling relationship between the two.

# 3.1. Construct the MCNLI model

The NL remote sensing refers to the conversion of the electromagnetic spectral information emitted from the Earth’s surface during cloud-free nights into images by satellites (Chen et al., 2019). NL intensity and area are often used to measure urbanization, they directly reflect the spatial variations of human activity on the Earth’s surface (Li et al., 2003; Levin et al., 2020). The nature of land use will vary as urbanization progresses, and the size of built land can reflect the extent of urbanization growth (Wu et al., 2018). Referring to the existing research results, this study constructed the indicators and weights (Chen et al., 2020; Tang et al., 2021; Xu et al., 2021a). The indicators of build land area (B), NL area (S), and NL intensity (I) are used to construct a model

![](images/de2236229644b17f59a4b5a22b3750c78899f5cd7c8795babecd169db4dfe46f.jpg)

![](images/e332aa2e6c2e1cce9458637dea8b47e9627b52f0aa4798d2d39da2cdba7d2afd.jpg)

![](images/b394d48fc51a4175a68fdcf3daf8b7cc5f640fa26f997dbc47072b0766169549.jpg)  
Fig.2. Research technology road map for local and telecoupling mechanism of urbanization and EEQ. (step1: calculate the level of urbanization; step2: calculate the EEQ; step3: calculate the LTCCD).

for measuring urbanization. The weights of nighttime light brightness, light intensity, and construction land area are set to 1/3 respectively. The formula for determining the degree of urbanization is:

$$
B _ {i} = \frac {\text {A r e a} _ {U}}{\text {A r e a} _ {B}} \tag {1}
$$

$$
I = \sum_ {j = 0} ^ {\mathrm {D N} _ {\max }} \mathrm {D N} _ {j} \times \frac {n _ {j}}{N \times \mathrm {D N} _ {\max }} \tag {2}
$$

$$
S _ {i} = \frac {\text {A r e a} _ {N}}{\text {A r e a} _ {S}} \tag {3}
$$

$$
\mathrm {M C N L I} = B _ {i} \times W _ {1} + I _ {i} \times W _ {2} + S _ {i} \times W _ {3} \tag {4}
$$

Where the proportions of regional building land and light are denoted by the letters $B _ { i }$ and $S _ { i } ,$ respectively. The aggregate area of the regional build’s land pixels is represented by $\mathbf { A r e a } _ { U } ,$ and that of the light pixels by $\mathbf { A r e a } _ { N } .$ . The regional total area is denoted by $\mathbf { A r e a } _ { B }$ and AreaS, respectively. N is the total number of pixels in the light, $n _ { j }$ is the number of pixels that match the $j .$ -th level of grey value, $\mathrm { D N } _ { \mathrm { m a x } }$ is the light’s maximum grayscale value, $\mathrm { D N } _ { j }$ is the grayscale value of the $j .$ -th level pixel inside the region, and I is the light’s intensity. $W _ { 1 }$ , $W _ { 2 } ,$ , and $W _ { 3 }$ are the pertinent weights.

# 3.2. Construct the MRSEI model

The RSEI model is based on the EI (Xu, 2013; Yang and Huang, 2021), offers advantages such as easy access to indicators, result visualization, and quantitative objectivity. It is often used in the evaluation of the EEQ (Chen et al., 2020; Chen et al., 2003). However, the RSEI model lacks an assessment of AI, resulting in low accuracy of the evaluation results (Levin et al., 2020). Therefore, based on this technical specification, referring to the research findings of scholars such as Xu et al. (2021a), Zhao et al. (2024), and Li et al. (2023b), we added the AI. The AI together with the greenness NDVI, WET, LST, and NDBSI indicators proposed by Xu (2013), constitute the MRSEI model, which can scientifically reflect the regional EEQ status.

$$
\mathrm {M R S E I} = f (\text {N D V I}, \text {W E T}, \text {N D B S I}, \text {L S T}, \text {A I}) \tag {5}
$$

Among them, the calculation formulas for NDVI, WET, NDBSI and LST can be found in Zhao et al. (2025). The calculation formula for AI can be referenced in Zhao et al. (2024). The following is the formula:

$$
\begin{array}{l} \mathrm {A I} = A \times (0. 3 5 \times \text {F o r e s t} + 0. 2 1 \times \text {G r a s s l a n d} + 0. 2 8 \times \text {W a t e r} + 0. 1 1 \\ \times \text {C r o p l a n d} + 0. 0 4 \times \text {B u i t} + 0. 0 1 \times \text {U n u s e d}) / \text {A r e a} \tag {6} \\ \end{array}
$$

# 3.3. Create the LTCCD model

The local coupling coordination degree(CCD) model is used to describe the strength of the interaction between two or more systems, which is reflected by the coupling degree and the comprehensive coordination index (Liu et al., 2007). Scholars have elaborated in detail on the theory of the local coupling and telecoupling relationship between urbanization and the ecological environment (Wang et al., 2014; Zhao et al., 2016; Cui et al., 2019; Ren et al., 2020). Chen and Liu (2012), through comparing various spatial interpolation methods, found that distance weighting approach (IDW) is an optimal spatial analysis method. This paper presents the inverse IDW, which is based on the CCD model, to obtain the LTCCD model. The degree of connection coordination between urbanization and the EEQ may be fully, properly, and scientifically reflected by this model (Li et al., 2023b). Here are the steps involved in the calculation: Firstly, determine the degree of local interaction between urbanization and the ecological environment first. The following is the calculating formula:

$$
C (U, E) = \sqrt {\frac {U \times E}{\left[ (U \times E) / 2 \right] ^ {2}}} \tag {6}
$$

Where $U$ stands for urbanization, E for ecological environment, and C $^ { ( U , E ) }$ for the degree of local coupling between $U$ and $E$ .

Next, figure out the degree of telecoupling and local coupling. IDW in ArcGIS is used to calculate the telecoupling degree based on the CCD model, and weighting is then used to determine the local coupling and telecoupling degree. It can be described as:

$$
C _ {\mathrm {s i}} = \mu \times C \left(U _ {i}, E _ {i}\right) + \lambda \times \left[ \frac {\sum_ {k = 1} ^ {n} W _ {\mathrm {i k}} \times C \left(U _ {i} , E _ {k}\right) + \sum_ {k = 1} ^ {n} W _ {\mathrm {k i}} \times C \left(U _ {k} , E _ {i}\right)}{2} \right] \tag {7}
$$

Where $C _ { s i }$ is the local coupling and telecoupling degree; $\mu = \lambda = 0 . 5$ , which are the weights of the local coupling and telecoupling degree; $U _ { k }$ and $U _ { i }$ are the values of MCNLI in region i and region $k$ respectively after standardization, and $E _ { k }$ and $E _ { i }$ are the values of MRSEI in region i and region $k$ respectively after standardization; i is the i-th region, n is the total number of regions, $k$ is an integer from 1 to $n$ , with the condition that $k \neq i ,$ , and $W _ { i k }$ is the weight based on the IDW, the calculation formula is as follows:

$$
W _ {\mathrm {i k}} = \frac {d _ {\mathrm {i k}} ^ {- p}}{\sum_ {k = 1} ^ {n} d _ {\mathrm {i k}} ^ {- p}} \tag {8}
$$

where $p$ is the power of the distance, typically set to 2, and $d _ { i k }$ is the distance between region i’s and region $k$ ’s administrative centers.

Third, determine the tele-effect and comprehensive local index. The local effect index is computed using IDW to determine the tele-effect index. The local and tele-effect index is defined as:

$$
T _ {\mathrm {s i}} = \mu \times T \left(U _ {i}, E _ {i}\right) + \lambda \times \left[ \frac {\sum_ {k = 1} ^ {n} W _ {i k} \times T \left(U _ {i} , E _ {k}\right) + \sum_ {k = 1} ^ {n} W _ {k i} \times T \left(U _ {k} , E _ {i}\right)}{2} \right] \tag {9}
$$

Where $T ( U _ { i } , E _ { i } ) = \alpha U _ { i } + \beta E _ { i } ,$ where $\alpha$ and $\beta$ are the weighting coefficients of $U$ and $E$ , respectively; $T _ { s i }$ is the local and tele-effect index; and $\mu = \lambda = 0 . 5$ are the contribution coefficients of $U$ and $E$ , respectively.

Finally, calculate the LTCCD. The formula is as follows:

$$
D _ {\mathrm {s i}} = \sqrt {C _ {\mathrm {s i}} \times T _ {\mathrm {s i}}} \tag {10}
$$

where $D _ { s i }$ denotes the LTCCD.

# 4. Results

# 4.1. The urbanization level in the CCEC

# 4.1.1. Verification of the MCNLI model and the CNLI model

Five indicators—the percentage of the population living in urban areas, the percentage of GDP from secondary and tertiary industries, population density, per capita GDP, and the area of built-up areas—are chosen to create the composite index (Cf) of UL in order to confirm the validity of the MCNLI and CNLI models (Chen et al., 2020). Cf is commonly used to assess the degree of urbanization (Tang et al., 2021). Fig. 3 displays the correlation fitting trend analysis by computing the MCNLI, CNLI, and Cf of the CCEC from 2000 to 2020. The figures show 111 sample points, with the horizontal axis representing Cf, the vertical axis representing MCNLI and CNLI, and the dots representing samples of 37 municipal administrative units in 2000, 2010, and 2020. Both the MCNLI and CNLI have coefficients of determination $\mathtt { R } ^ { 2 }$ of 0.885 and 0.847, respectively. The degree to which the regression line fits the observed values is better when the $\mathrm { R } ^ { 2 }$ value is near 1. The fitting degree of MCNLI to Cf is better than that of CNLI. Therefore, MCNLI can better represent the UL than CNLI.

# 4.1.2. The temporal change trend of the urbanization level in the CCEC

Fig. 4 was produced using statistical analysis of the urbanization

![](images/7b9ae605df811b932479c3479fa785d7393d8d85289222932a95bbf3ece8a056.jpg)

![](images/c8c1a68e8cdd46fb37944e57f0f80ac549d2a460a5cb54344e5ca16db1cee2e9.jpg)  
Fig.3. Correlation analysis of MCNLI, CNLI and Cf.

development progress of 36 cities in the CCEC between 2000 and 2020. With a growth rate of $0 . 0 0 7 1 6 \mathbf { a } ^ { - 1 }$ , the average yearly MCNLI values of these 36 cities show an exceptionally noticeable growth pattern, as seen in Fig. 4. Since 2010, the growth momentum of the UL among the 36

cities has notably accelerated. This is especially noticeable in places like Deyang City, Yongchuan District, Jiangjin District, Changshou District, Chengdu, and the central Chongqing metropolitan area. Additionally, on account of the diverse paces at which different cities develop in terms of urbanization, significant disparities in the MCNLI values of the 36 cities have emerged over the time scale. During the research period, the change rate of MCNLI in Pengshui County is rather insignificant, merely increasing from $- 0 . 0 1 7 8 \ \%$ in 2000 to $0 . 0 2 2 1 \ \%$ in 2020, which indicates a sluggish urbanization development pace. In contrast, the change rate of MCNLI in Jiangjin District is comparatively remarkable, surging from $0 . 0 6 2 1 \%$ in 2000 to $0 . 4 4 8 5 \%$ in 2020, suggesting a rapid urbanization development speed. In general, Chengdu’s and Chongqing’s primary urban area’s levels of urbanization development have consistently been far ahead of other regions, thoroughly manifesting the development potential and radiation capacity of these core cities as the urban agglomeration’s main hubs.

# 4.1.3. The spatial differentiation pattern of the urbanization level in the CCEC

To accurately examine the urbanization development degree of the CCEC’s spatial distribution pattern, research was carried out with districts and counties as units. The ArcGIS software was utilized to determined the MCNLI values of 145 districts and counties in the CCEC in 2000, 2005, 2010, 2015 and 2020, and Fig. 5 was obtained. It can be seen from the figure that from 2000 to 2020, the MCNLI of the CCEC exhibits significant spatial heterogeneity in spatial distribution. The spatial development of urban areas conforms to the theory of the circle layer (Sun, 2021). The regional spatial evolution has developed from a “single center − periphery structure” in 2000, 2005 and 2010 to a “multi-center − periphery structure” in 2015 and 2020. With Chongqing and Chengdu’s major cities serving as the center, regions such as

![](images/3f9df2dfee67ad3c9618967903d1368d855970200855efabc71d916e0e20e862.jpg)  
Fig.4. Rates of change of MCNLI in 36 cities of the CCEC from 2000 to 2020.

![](images/05fab5a2ab35d7d26c1641beadc00dd54b3adf8ca25f4a3a5dd8d87c05240520.jpg)  
Fig.5. Spatial distribution pattern of urbanization level by district (county) from 2000 to 2020.

Mianyang, Deyang, Yongchuan, Jiangjin and Changshou as the intermediate layer, and the remaining regions as the outer layer, the circle layer structure of the dual urban cores has gradually formed and strengthened. As cities move from the core circle to the outer circle, their degree of development progressively declines. The MCNLI index shows a spatial distribution pattern of a dual-core ring shape, decreasing from the inside to the outside. By referring to “the China Urban Construction Statistical Yearbook”, it was found that in the five research years, the urban population, GDP output value and Chengdu built-up area, and the primary urban area of Chongqing ranked at the forefront of the CCEC. Studies have shown that economic growth, industrial structure transformation, technological development, factor flow, policies and institutions are the dominant factors driving the urban development of the CCEC (Dong, 2022; Wang et al., 2022).

# 4.2. EEQ in the CCEC

# 4.2.1. Comparative analysis between the MRSEI model and RSEI model

Table 2 was produced by Principal Component Analysis (PCA) of the MRSEI and RSEI model indicators of the CCEC in 2020. The data shows that the first principal component for the MRSEI and RSEI has contribution rates of $8 3 . 2 1 ~ \%$ and $7 6 . 6 1 ~ \%$ , respectively, both of which are more than $7 5 ~ \%$ . When the first principal component of the PCA’s cumulative contribution rate surpasses $7 5 \ \%$ , statistical principles state that the greater the contribution rate, the more information the indicators can convey (Tang, 2022). Therefore, PC1 can convey the

majority of the data from both MRSEI and RSEI, but MRSEI is more capable of capturing the CCEC’s EEQ than RSEI. In addition, the PC1 loading values of the NDVI, WET and AI indicators of the MRSEI model are positive, playing a positive role in the EEQ. The PC1 loading values of NDBSI and LST are negative, playing a negative role in the EEQ, which is in line with Li et al. (2023a) and Zhao et al. (2024) research findings, and conforms to the actual situation. In the MRSEI model, the contribution value of the AI indicator to PC1 is the largest, followed by NDVI, which conforms to the setting of indicator weights in the HJ 192–2015, indicating that it is scientific and feasible for the MRSEI model to evaluate the EEQ of the CCEC.

The MRSEI and RSEI models were used to evaluate the EEQ of the research area in 2020, and the spatial differences in the research results were relatively large (Fig. 6). Fig. 6 illustrates how the MRSEI and RSEI indices of the CCEC indicate that the surrounding mountains have a higher EEQ than the hilly and intermediate plains The MRSEI takes into account the AI, which widens the gap in EEQ across the entire region and is reflected through the changes in regional colors. Combined with Table 2, the addition of the AI in the MRSEI has enlarged the gap in EEQ between urban regions and the surrounding mountainous areas. On a large regional scale, it indicates that natural environmental factors control the regional EEQ on a macroscopic level, while human activities interfere with and damage the EEQ on a microscopic level. Especially in densely populated urban areas, the destructive power of human factors on the EEQ is relatively strong (Wang et al., 2023; Yang et al., 2023).

In order to further verify the scientificity of the MRSEI model, 60

Table 2 Comparison of principal component analysis results between MRSEI and RSEI models.   

<table><tr><td></td><td>Index</td><td>PC1</td><td>PC2</td><td>PC3</td><td>PC4</td><td>PC5</td></tr><tr><td rowspan="7">MRSEI</td><td>NDVI</td><td>0.51863</td><td>0.47127</td><td>0.24737</td><td>0.52994</td><td>0.40850</td></tr><tr><td>WET</td><td>0.2848</td><td>0.32457</td><td>-0.71406</td><td>-0.46362</td><td>0.29782</td></tr><tr><td>NDBSI</td><td>-0.05476</td><td>-0.35113</td><td>0.38913</td><td>-0.39559</td><td>0.75218</td></tr><tr><td>LST</td><td>-0.56704</td><td>0.73363</td><td>0.2793</td><td>-0.24806</td><td>0.02263</td></tr><tr><td>AI</td><td>0.5704</td><td>0.10504</td><td>0.44663</td><td>-0.53495</td><td>-0.42184</td></tr><tr><td>Eigenvalue</td><td>0.3908</td><td>0.0491</td><td>0.0204</td><td>0.0094</td><td>0.0000</td></tr><tr><td>Eigenvalue contribution</td><td>83.21 %</td><td>93.65 %</td><td>98.01 %</td><td>100 %</td><td>100 %</td></tr><tr><td rowspan="6">RSEI</td><td>NDVI</td><td>0.49162</td><td>0.48569</td><td>0.41917</td><td>0.58881</td><td></td></tr><tr><td>WET</td><td>0.4788</td><td>-0.2206</td><td>-0.7798</td><td>0.3374</td><td></td></tr><tr><td>NDBSI</td><td>-0.38146</td><td>0.79911</td><td>-0.46454</td><td>-0.00995</td><td></td></tr><tr><td>LST</td><td>-0.61929</td><td>-0.27722</td><td>0.01593</td><td>0.73441</td><td></td></tr><tr><td>Eigenvalue</td><td>0.07577</td><td>0.03055</td><td>0.01624</td><td>0.00041</td><td></td></tr><tr><td>Eigenvalue contribution</td><td>76.61 %</td><td>91.45 %</td><td>99.65 %</td><td>100 %</td><td></td></tr></table>

![](images/3425e14563d0c7d5d0246353de8ce503133d00eafc1ecd2de04ec06a8a70a468.jpg)

![](images/cb4395aaf7825a3b3301addf6e988dcbc6aa72dfd00c4fcfe4b19d212402ec7a.jpg)  
Fig.6. EEQ of CCEC in 2020 Based on RSEI and MRSEI Models.

sample points were randomly selected using ArcGIS software, and a oneby-one comparative verification was carried out in combination with high-resolution remote sensing satellite images. In Fig. 6, a and b represent the EEQ of the RSEI and MRSEI models respectively, a1 and b1 are cultivated land in Chengdu, and a2 and b2 are forest land in Chongqing. By comparing with high-resolution remote sensing images, it was found that the MRSEI more accurately reflects the contour and distribution pattern of the cultivated land b1 and the construction land b1-1. The EEQ of construction land is poor, while that of cultivated land is good. The MRSEI clearly reflects the difference in EEQ between the forest land b2 and the quarry b2-2, the EEQ of the quarry is poor. Overall, it shows that the spatial information expressed by the MRSEI model is clearer and more complete, and is more consistent with the actual situation.

# 4.2.2. The temporal change trend of the EEQ in the CCEC

The EEQ of the study region is represented by the MRSEI. The EEQ’s pattern of change over time in each city is displayed in Fig. 7. The CCEC’s overall EEQ fluctuated downward during the study period, going from 0.73083 to 0.66087 at a growth rate of $- 0 . 0 0 3 4 9 \mathrm { a } ^ { - 1 }$ . The EEQ slightly declined from 2000 to 2005, improved and rose from 2005 to 2010, and significantly dropped from 2010 to 2020. The EEQ in Chengdu City, Meishan City, Dazhou City, Neijiang City, Rongchang District, Tongliang District, and Tongnan District has declined significantly. In Nanchuan District, Fengdu County, Pengshui County Ya’an City, Qijiang District, Qianjiang District, and Luzhou City, the EEQ has gradually decreased, and things are generally going well. In addition, the gap in EEQ between cities is obvious. As per the HJ 192–2015, the CCEC’s MRSEI score during the study period is higher than 0.6,

suggesting that the regional EEQ as a whole is well. Together with Fig. 4, it is evident that there is a negative relationship between urbanization and EEQ in regions where the degree of urbanization increased quickly after 2010.

# 4.2.3. The spatial change trend of EEQ in CCEC

The EEQ’s spatial distribution is illustrated in Fig. 8. In the study area, the EEQ follows a ring-shaped distribution pattern: ’relatively substandard in core cities, moderate in the intermediate hilly regions, and excellent in the peripheral mountainous areas. During the period from 2000 to 2020, The extent of the comparatively low EEQ in Chengdu and Chongqing’s major cities has been progressively enlarging. In the intermediate hilly regions, including Luzhou City, Neijiang City, Zigong City, Tongnan District, and Yongchuan District, the EEQ has exhibited a distinctly downward trend. In contrast, the EEQ in the peripheral mountainous areas remains relatively fine. Within the research period, as indicated in the “China Urban Statistical Yearbook” concerning the EEQ, the GDP output value, population density, and construction land area in in Chengdu and Chongqing’s key urban areas are all larger than those in other regions. Conversely, the cultivated land area and forest coverage rate are lower than those in other regions. The congregation of population and urban expansion have given rise to an increment in construction land area and a decrement in ecological land, consequently exerting a major impact on the EEQ (Tang et al., 2021; Lin et al., 2023).

# 4.3. Results of the LTCCD between urbanization and EEQ

# 4.3.1. Analysis of the results of CCD and LTCCD in the CCEC

The findings of the CCD (Fig. 9a) and LTCCD (Fig. 9b) comparing

![](images/d3f283e8f84f88a78484bd6b6b848a0a45869c107b9e8e912cfbed0a8c3652b5.jpg)  
Fig.7. The Temporal Variation Trends of the EEQ in Each City from 2000 to 2020.

![](images/b848ae77529caa25e6b0848bb35f72eb2ec7da97ba105cfd9676aac477056270.jpg)  
Fig.8. The Spatial Distribution Pattern of the EEQ in Each City from 2000 to 2020.

urbanization and EEQ are displayed in Fig. 9. From 2000 to 2020, the CCD and LTCCD values of the CCEC gradually increased, with annual change rates of $0 . 0 1 0 5 \mathsf { a } ^ { - 1 }$ and 0.00986a–1 respectively, suggesting that

there has been a gradual improvement in the coupling coordination between urbanization and EEQ. In addition, the annual average value of the LTCCD is greater than that of the CCD. The increase in the coupling

coordination shows that the flow of elements such as information, population, technology, and capital among regions has strengthened the inter-regional connections and optimized the spatial structure, which conforms to the actual situation. The study found that the internal connections in the CCEC have been enhanced, and the LTCCD exhibits the spatial characteristic of “strong in the core cities of Chengdu and Chongqing, and weak in the central and marginal cities”, and the relationship between EEQ and urbanization is important (Li et al., 2023a; Zhang, 2021). During the research period, the LTCCD between urbanization and EEQ has generally grown, as shown in Fig. 9b. However, the importance among cities has extended, highlighting the radiation ability of Chengdu City and the main urban region of Chongqing as key cities. Urban development positively feedbacks on the coupling mechanism of the surrounding areas. However, the radiation ability received by the underdeveloped central and marginal cities is greater than their own

development ability. It indicates that the LTCCD model considering telecoupling can better reflect the exchanges and interactions among regions than the CCD model, conforms to the natural law of urban agglomeration development, and verifies the rationality of LTCCD model.

# 4.3.2. Spatio-temporal Variation characteristics of the LTCCD between urbanization and EEQ

The MCNLI, MRSEI, and LTCCD change rates in the research area are shown in Table 3. With growth rates of $0 . 0 0 7 1 6 \mathbf { a } ^ { - 1 }$ and $0 . 0 0 9 8 6 \mathrm { a } ^ { - 1 }$ respectively, MCNLI and LTCCD generally displayed an upward trend throughout the study period. This suggests that there was a positive correlation between the degree of urbanization and the shifting trend of LTCCD. With a growth rate of $- 0 . 0 0 3 4 9 \mathrm { a } ^ { - 1 }$ , the MRSEI, on the other hand, showed a negative growth trend, indicating a negative association

![](images/0627b36e99235bf640f4d3e9ef88b7c0f177e101841415969c04b87a0e8ee9cc.jpg)

![](images/53779adcaadd5bfca16c404e6009b29f614568d0308ca461319fdb1cf97d917a.jpg)  
Fig.9. The change trend of the coupling coordination degree of cities in CCEC during the study period.

between LTCCD and EEQ. Therefore, at this point, the most significant factor affecting LTCCD was the degree of urbanization growth, and LTCCD levels would be negatively impacted by a deterioration in the EEQ.

The spatial distribution of LTCCD in each city (county, district) between 2000 and 2020 is displayed in Fig. 10. According to the range of LTCCD values and prior research (Li et al., 2023b; Yang et al., 2023; Dong et al., 2019), LTCCD is classified into four groups: severe disorder (0–0.3), low-level coordination (0.3–0.5), basic coordination (0.5–0.7), and superior coordination (0.7–1). The following are the features of the shifts in the different kinds of coupling coordination degree between urbanization and EEQ: (1) Severe disorder type: This sort of urbanization development is comparatively low, and the ecological environment is significantly stressed by social and economic construction as well as urban development. In 2000, the LTCCD types of Yibin, Mianyang, Meishan, Leshan, and Ya’an City were severely disordered and uncoordinated, but by 2020, they had transformed into a low-level coordinated state. The protection and management of the EEQ in such cities should be strengthened to promote a virtuous cycle between urban development and the ecological environment. (2) Low-level coordina tion type: These cities were located in the central hilly regions, accounting for $3 5 \% - 4 7 \%$ during the study period. The urbanization and EEQ are at a low-level coupling and coordination condition. The rate of urbanization growth lags behind changes in EEQ Population increase, resource consumption, and road construction put a strain on the ecological environment, which, in turn, limits social and economic development and urbanization construction. A good development model has not emerged between urbanization and the natural environment. (3) Basic coordination type: Cities of this type have shown a gradually expanding trend during the research period and are distributed in a ring shape in the northeast direction of the research area. From 2000 to 2020, Wanzhou District, Liangping District, Nanchong City, Dazhou City, Mianyang City, and Deyang City etc., developed from low-level coordination to basic coordination. From 2015 to 2020, Yongchuan, Jiangjin, Fuling, Qijiang, Nanchong, and Bishan District etc., developed from basic coordination to high-level coordination. The background of the EEQ is favorable, and the degree of city development is low. On the basis of safeguarding the EEQ, the degree of urban social and economic growth ought to be raised. (4) High-level coordination type: This type is distributed in Chengdu City, Chongqing’s central urban region, and their neighboring areas. The UL is high, the EEQ is good, and the UL and EEQ develop synchronously. In conclusion, $7 8 . 3 7 \ \%$ of the cities have experienced the transformation from low coupling to high coupling. The range of high-coupling cities in Chongqing has expanded, and the radiation effect of Chengdu City on surrounding cities has been strengthened. The LTCCD between urbanization and the natural environment

has has undergone a beneficial development process from being uncoordinated to coordinated, from antagonism to abrasion and dysregulation to coordination.

# 4.3.3. Spatial autocorrelation analysis of the LTCCD model

The spatial clustering characteristics of cities in 2000, 2010, and 2020 are examined using a spatial autocorrelation model in order to investigate the spatial dependency of urban units in the LTCCD, as illustrated in Fig. 11. The chart shows that in 2000, 2010, and 2020, the corresponding Moran’s I indices were 0.595, 0.704, and 0.571. The scatter points, which exhibit high-high agglomeration and low-low agglomeration, are mostly found in the third and first quadrants. This indicates that the LTCCD values have strong clustering characteristics in space, presenting a positive or negative correlation relationship. The major cities of Chongqing and Chengdu are home to the high-high LTCCD value agglomeration areas in the research area, whereas the southwest region is home to the low-low LTCCD value agglomeration areas.

# 5. Discussions

# 5.1. Analysis of the Reasons for the spatial heterogeneity of MRSEI in the CCEC

The MRSEI model was created in this work by including the AI of organisms into the RSEI model. By comparing the MRSEI and RSEI models (Fig. 6), it was found that the standard deviations of the MRSEI and RSEI models were 0.267 and 0.211 respectively. According to the studies of Xu et al. (2021a), Tang et al. (2021), and Zhao et al. (2024), a higher standard deviation indicates a higher degree of data dispersion, which verified that the MRSEI model is more scientific and adaptable than the RSEI model. The high-value regions of MRSEI and AI, like the nearby mountainous areas, are approximately equal in Fig. 12. The lowvalue regions of AI and MRSEI are essentially the same, such as the major cities of Chongqing and Chengdu, which is consistent with Liu et al. (2023) and Zhao et al. (2024) research findings. In the surrounding mountainous areas of the CCEC, the terrain is highly undulating, creating natural barrier zones. The vegetation is lush, human activity is minimal, biodiversity is rich, and EEQ is high. However, Chengdu and Chongqing’s major urban centers, urban expansion has led to a decrease in natural spaces and a rise in development land. Human activity intensity is high, vegetation cover is diminished, biodiversity is low, and the EEQ is poor. Referring to Fig. 1, it can be observed that points 1 and 2 in Fig. 12 represent the Emei Mountain Scenic Area and the major Chongqing metropolitan area, respectively, corresponding to high and low biodiversity values. The Emei Mountain Scenic Area, as a national

Table 3 The Change rate of MCNLI, MRSEI and LTCCD model in CCEC from 2000 to 2020. unit:a-1.   

<table><tr><td>Area</td><td>MCNLI</td><td>MRSEI</td><td>LTCCD</td><td>Area</td><td>MCNLI</td><td>MRSEI</td><td>LTCCD</td></tr><tr><td>Pengshui County</td><td>0.00015</td><td>-0.00025</td><td>0.00075</td><td>Nejiang City</td><td>0.00043</td><td>-0.00029</td><td>0.00046</td></tr><tr><td>Yibin City</td><td>0.00049</td><td>-0.00028</td><td>0.00073</td><td>Dazu District</td><td>0.00092</td><td>-0.00043</td><td>0.00073</td></tr><tr><td>Qianjiang District</td><td>0.00032</td><td>-0.00023</td><td>0.00091</td><td>Fuling District</td><td>0.00093</td><td>-0.00028</td><td>0.00094</td></tr><tr><td>Yaan City</td><td>0.00028</td><td>-0.00020</td><td>0.00066</td><td>Nanchuan District</td><td>0.00040</td><td>-0.00020</td><td>0.00078</td></tr><tr><td>Leshan City</td><td>0.00037</td><td>-0.00015</td><td>0.00060</td><td>Qijiang District</td><td>0.00077</td><td>-0.00020</td><td>0.00104</td></tr><tr><td>Meishan City</td><td>0.00061</td><td>-0.00026</td><td>0.00062</td><td>Liangping District</td><td>0.00041</td><td>-0.00012</td><td>0.00056</td></tr><tr><td>Mianyang City</td><td>0.00062</td><td>-0.00012</td><td>0.00075</td><td>Zhong County</td><td>0.00011</td><td>-0.00012</td><td>0.00046</td></tr><tr><td>Tongliang District</td><td>0.00071</td><td>-0.00031</td><td>0.00093</td><td>Yongchuan District</td><td>0.00102</td><td>-0.00040</td><td>0.00081</td></tr><tr><td>Yunyang County</td><td>0.00022</td><td>-0.00003</td><td>0.00040</td><td>Dianjiang County</td><td>0.00026</td><td>-0.00014</td><td>0.00050</td></tr><tr><td>Ziging City</td><td>0.00034</td><td>-0.00023</td><td>0.00046</td><td>Nanchong City</td><td>0.00055</td><td>-0.00033</td><td>0.00042</td></tr><tr><td>Rongchang District</td><td>0.00059</td><td>-0.00043</td><td>0.00056</td><td>Jiangjin District</td><td>0.00143</td><td>-0.00040</td><td>0.00096</td></tr><tr><td>Luzhou City</td><td>0.00042</td><td>-0.00046</td><td>0.00044</td><td>Hechuan District</td><td>0.00089</td><td>-0.00033</td><td>0.00067</td></tr><tr><td>Deyang City</td><td>0.00078</td><td>-0.00014</td><td>0.00079</td><td>Fengdu City</td><td>0.00041</td><td>-0.00021</td><td>0.00049</td></tr><tr><td>Ziayang City</td><td>0.00058</td><td>-0.00029</td><td>0.00056</td><td>Changshou District</td><td>0.00099</td><td>-0.00023</td><td>0.00090</td></tr><tr><td>Dazhou City</td><td>0.00048</td><td>-0.00002</td><td>0.00063</td><td>Wanzhou District</td><td>0.00056</td><td>-0.00007</td><td>0.00071</td></tr><tr><td>Tongnan District</td><td>0.00062</td><td>-0.00045</td><td>0.00062</td><td>Bishan District</td><td>0.00080</td><td>-0.00031</td><td>0.00068</td></tr><tr><td>Suining City</td><td>0.00056</td><td>-0.00029</td><td>0.00049</td><td>Chengdu City</td><td>0.00080</td><td>-0.00025</td><td>0.00045</td></tr><tr><td>Guangan City</td><td>0.00067</td><td>-0.00026</td><td>0.00050</td><td>Main Districts in Chongqing</td><td>0.00057</td><td>-0.00035</td><td>0.00031</td></tr></table>

![](images/f737c1180274a76eb1fab0af0d5b2186305317e080af5c8678c4d228f478cc10.jpg)  
(a)2000Year

![](images/5b7d3e0a141021259229cb6f604d2a9db18024e4e803b6fad1608bc0d13ab967.jpg)  
(b)2005Year   
(e)2020Year

![](images/7c1c762980175a6550e3cc604314ce5adce130e512601e63ff81724cd3f91fef.jpg)

![](images/f94c4d3ea287566643f4fcc52277359335e5767244afe43df49ccb87810cfe41.jpg)

(c)2010Year   
LTCCD   
![](images/8d0adcad1649003308c426349adfd798051942d2febf2c0eddccd55990c6983e.jpg)  
Severe disorder   
Low-level coordination   
Basic coordination   
Superior coordination

0100200 Km

![](images/f75e1c756b20c853100e8c2c50a6183a422af16756303fa3cd66d527a5c3155f.jpg)  
Fig.10. Spatial Distribution Pattern of Coupling Coordination Degree of Cities in CCEC.

![](images/1a70c261a605e51be9a68a188f410b6f18d1d236d374179da934244bd1f2eccc.jpg)

![](images/ed98717664a10fa657a21054afeec8db8f62898f4aec8f195d79a4354a391631.jpg)

![](images/bb446e0fc4b7b360f14f5c06786f3f9b651b426e50ba3d97f0fb7761dbe593f5.jpg)

![](images/82cdf07225332fca73db74e2a18ef6fa5b70c406dad5bdb3820dacd262d7e5da.jpg)

![](images/a7e81a56d44383b5ee9cb0ae9f3476622ca20f5dc50f16524770beef83e47205.jpg)

![](images/48fd5d54ea168dc698842bbeabdcd0ade54c020bc7417c7f0330962ce6788f20.jpg)

![](images/a7b8c5b0acab25eb319595bb96c0e3a16465f20aa464f5e8dec016f3b1ca87ad.jpg)

![](images/81e28debf8d728dc3b55979b55b28300eb532882db71f8b1e4a05ca3ebee00e1.jpg)

![](images/f731a7fbcdf7ed1b230c5906e40876973d918046269fc595c3ce87f9426f529d.jpg)

![](images/785ecc42ab7d4adc304cf3d11ad3fda28a6d10f78f52370c4f933c3f436f6d6b.jpg)  
Fig.11. Spatial auto-correlation Moran index of CCEC in 2000, 2010 and 2020 (the top), local auto-correlation clustering map (the middle), significance test of LTCCD model (the bottom).

![](images/dc6a806fbd08171cec6b6a0749089c2feeff09cd8906d7107bce84761b82d15d.jpg)

![](images/19643ffeeb3c842150fc26bc9b56caff6ebde1b2022b52ac9c1977e11f524519.jpg)

![](images/f89278832178129d3dffa0e50c4dc1e4dc6e0024355a86ccc53f2185f0703382.jpg)

![](images/b9f21608b24d459ad5978173e1bda8141126df59b4b8357bda5c9216d67735b7.jpg)

![](images/8919c5e61427e6ba7a1b8f2f0195e49ced1692fa4c0f36903c67c4fc53f56549.jpg)

![](images/b0ef4201d3bae826a83e8e369305238f15d5000978ae8a5c0984c4e7eaab8b50.jpg)

![](images/8caa9fccb5aef22840cf3ef4ac4de77ce382f9611ad6401f2eeb1836ed7eea4a.jpg)

![](images/d0073292ef8552ce5df8fa6b15d233d2722142dabcc9f39b17fa007b80eff4f0.jpg)

![](images/b8ce333bf45e0680a191b65fb1e26906cb5b382fb3ae9fb70802adebcd740cf9.jpg)  
Fig.12. Spatial differences between Landsat, MRSEI and AI in 2020 (a for AI results, b for Landsat imagery, c for MRSEI results).

key scenic and historic interest area, was once rated as a “Global Excellent Ecotourism Scenic Area” by the United Nations, with rich animal and plant resources and good biodiversity. The main urban area of Chongqing is greatly affected by human activities, with a large area of urban construction and less green land, and low biological abundance. Therefore, adding the AI to the RSEI model is the main reason for the expansion of the spatial differences between the surrounding mountainous areas and the hilly and plain areas in the CCEC.

5.2. The relationships among the urbanization level, EEQ, and LTCCD in the CCEC

To further explore the relationships among the urbanization level, EEQ, and LTCCD in the CCEC. We ranked the 145 cities in the research area in descending order, and taking districts and counties as units, drew the fitting relationship graph between the UL and EEQ, as well as the line graph of the relationship between the two and the local and telecoupling (Fig. 13). The curves reflect the changing trends of the UL and EEQ of each city within the duration of the research. The bubbles represent cities, and the color and size of the bubbles represent the change rate of

![](images/e7fccbc13b89fdbd0293f1711734d8ab9d5dfc80f5e88ac8842874ef177f9235.jpg)  
Fig.13. The Scatter Plot of the Relationship between Urbanization and EEQ in CCEC from 2000 to 2020.

the urbanization level, with the minimum value being $\boldsymbol { 0 } \mathbf { a } ^ { - 1 }$ and the maximum value being $0 . 0 0 1 4 3 \mathrm { a } ^ { - 1 }$ . A negative correlation between the UL and EEQ was discovered by fitting the ranking situation of the two variables to the near and far coupling coordination degree of the 145 cities. This finding is in line with the findings of Chen (2022) and Xu et al. (2021a) studies. Therefore, attaching importance to the functions of the ecosystem and coordinating the relationship between urbanization development and the natural environment protection is an inevitable requirement for encouraging the sustainable, high-quality, and healthful growth of urban areas. In addition, we also found that there is a consistent changing trend between the UL and the LTCCD, and there is a positive correlation between the two. There is an inconsistent changing trend between the EEQ and the LTCCD, and there is a negative correlation between the two, which further confirms Table 3. Therefore, we hypothesize that the CCEC is currently experiencing fast urbanization. At this point, the degree of urbanization is the primary factor influencing the LTCCD level, and the decline in EEQ has a detrimental effect on the LTCCD level.

# 5.3. Analysis and recommendations of CCEC

This study has analyzed urbanization, EEQ, and the coupling coordination degree between the two in the CCEC. From a sustainable development perspective, coordinating urbanization and EEQ is essential for achieving regional high-quality development (Zhao et al., 2017; Chen, 2022). In 2020, the degree of coupling coordination between urbanization and EEQ in the CCEC is separated into three categories, as shown in Fig. 10: low-level coordination, basic coordination, and highlevel coordination. The following recommendations and actions are advised in light of sustainable development, EEQ protection, and regional economic development. Firstly, The urbanization and EEQ in Chengdu and Chongqing’s main urban regions, Jiangjin, Qijiang, Nanchuan, Fuling, Changshou, and Wanzhou district, are highly coordinated. In terms of urban construction and EEQ protection, technological innovation should be encouraged to improve production efficiency. Adjust the layout and upgrade of the industrial structure. Encourage clean, low-carbon, and green energy.The government should encourage the orderly growth of urban construction, expand the area of green space, and optimize the planning and administration of land resources. Secondly, the urbanization and EEQ in Mianyang City, Deyang City, Dazhou City, Liangping District, Yongchuan District, Dazu District, Tongliang District, and Hechuan District are at a basic coordination level. The process of urbanization development should be accelerated while paying attention to EEQ protection. The government should improve its administrative capacity and level, optimize the management mode, and improve service levels. Attract investment to support the construction and growth of industrial parks, strengthen economic ties with core cities, and highlight the core cities’ radiation-driven role. At the same time, strengthen EEQ protection, management, and construction. Thirdly, the urbanization and EEQ in the remaining areas are at a low-level coordinated level. The urbanization and EEQ in such cities need to be improved and developed. In terms of the EEQ, key ecological function areas should be protected, and the improvement and governance of the environment in ecologically sensitive and fragile areas should be strengthened. Restore and improve EEQ through measures like turning agricultural land into forests, and planting trees and grass. Urbanization should be driven by industrial expansion, and secondary and tertiary industry development should be hastened in terms of urban construction.

# 6. Conclusions

Facing the serious resource and environmental problems brought about by the rapid development of urbanization, the concept and strategy of sustainable development provide theoretical support for coordinating urban construction and ecological environment protection.

In this study, we improved the measurement models for EEQ and urbanization level, combined the local coupling and telecoupling within the urban system, and quantitatively evaluated the coupling coordination degree between urbanization and EEQ in the CCEC.The key conclusions are as follows:

(1) The MRSEI model with the addition of the AI enables the scientific measurement of the regional EEQ. During the research period, the average MRSEI value of the CCEC is greater than 0.6, indicating that the overall EEQ of the region is good. Temporally, it shows a trend of ’slight decline-rise-rapid decline’, and spatially, it presents a distribution pattern where ’the EEQ in the main urban areas of Chengdu and Chongqing is poor, that in the central hilly areas is average, and that in the surrounding mountainous areas is good’.

(2) The MCNLI model, which takes into account the construction land area index, makes up for the data accuracy problem and enables the scientific and accurate measurement of the urbanization level. From 2000 to 2020, the urbanization development level increased rapidly, with a growth rate of 0.00716 a– 1. The urban development pattern evolved from a’ single-center-periphery structure’ to a ’multi-centerperiphery structure’. There are significant differences in the MCNLI values of the 36 cities in the spatio-temporal scale. Regional economic growth, industrial structure, science and technology, and government policies are the dominant factors driving urbanization development.

(3) The LTCCD model, which considers telecoupling, conforms to the actual situation of enhanced factor flow and interaction among cities and scientifically measures the coupling coordination degree between urbanization and EEQ. From 2000 to 2020, the LTCCD in the CCEC showed an upward trend, with a growth rate of $0 . 0 0 9 8 6 { \sf a } ^ { - 1 }$ , indicating that the coupling and coordination between urbanization and EEQ gradually improved. The study found that there is a positive correlation between the MCNLI value and the LTCCD value, and a negative correlation between the MRSEI value and the LTCCD value, indicating that at this stage, the UL is the decisive factor affecting the LTCCD level. However, attention should also be paid to the protection and management of the regional EEQ. Therefore, specific and effective measures and suggestions should be put forward according to the coupling coordination level of cities to promote the high-quality and sustainable economic development of the CCEC“.

