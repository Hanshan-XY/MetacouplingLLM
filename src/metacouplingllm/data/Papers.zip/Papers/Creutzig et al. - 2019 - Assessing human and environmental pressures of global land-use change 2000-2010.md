# Assessing human and environmental pressures of global land-use change 2000-2010

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:38:41.198961+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Creutzig et al. - 2019 - Assessing human and environmental pressures of global land-use change 2000-2010.pdf
- Year: unknown
- DOI: 10.1017/sus.2018.15
- OA status: gold
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: no license info, oa_status=gold

## Copyright-Safe Summary
This article analyzes how multiple human and environmental pressures on land changed worldwide between 2000 and 2010, and how these changes are spatially linked. The study is explicitly framed in a telecoupling/metacoupling context through its attention to distant drivers such as trade and climate change.

The authors assemble and harmonize several global gridded datasets at 0.5-degree resolution, covering population, livestock, cropland, terrestrial carbon, and biodiversity intactness. Livestock data are converted to standardized livestock units; biodiversity is estimated from a global species richness model and land-use dependent intactness indices; carbon stocks are simulated with the LPJmL dynamic vegetation model, corrected with satellite-based tropical deforestation data. Changes in density (per km2) between 2000 and 2010 are computed, co-occurrences are mapped, and principal component analysis is used to identify dominant patterns. A region-specific literature review and data on cropland embodied in trade complement the spatial analysis.

Globally, population and livestock densities rose in most areas, while cropland expanded mainly in tropical and savannah regions but declined in many temperate zones. Biodiversity intactness decreased almost everywhere. Carbon stocks increased in many boreal and some tropical regions but declined in parts of Latin America, Sub-Saharan Africa, and Southeast Asia where deforestation and agricultural expansion were strong. Co-occurrence analysis shows that increases in population, cropland, and livestock tend to appear together and are usually associated with losses of biodiversity and sometimes carbon.

Combining spatial results, trade data, and literature, the authors propose three land-use archetypes: consumer regions (e.g., Europe, North America, Oceania) with high per capita land footprints, agricultural intensification, and net land imports; producer regions (especially Latin America and parts of Southeast Asia) where export-oriented agriculture drives biodiversity and carbon loss through telecoupled trade; and mover regions (much of Asia and Africa) where rapid population growth and urbanization generate strong domestic land pressures, with relatively low export shares but rising dependence on imported land products. The paper argues that these telecoupled and regionally differentiated dynamics call for coordinated global land governance sensitive to trade, institutions, and climate impacts.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via trade and climate; intra and neighboring-region interactions also analyzed.

### Intracoupling
#### Systems
- National land systems combining cropland, pasture, forest, urban land, biodiversity, carbon
- Within-region archetypes: consumer, producer, mover land-use regimes
#### Flows
- Domestic land conversion between cropland, pasture, forest, urban uses
- Internal food, livestock, and bioenergy production for national populations
- Domestic emissions and carbon sequestration from land-use change
#### Agents
- National governments and land-use planners
- Farmers, ranchers, foresters, urban developers
- National conservation agencies and environmental institutions
#### Causes
- Population growth and urbanization within countries
- Domestic policies on agriculture, conservation, biofuels, afforestation
- National economic growth and dietary shifts
#### Effects
- Changes in domestic cropland, pasture, forest cover, urban expansion
- National biodiversity loss or partial recovery
- National carbon stock gains or losses in vegetation and soils

### Pericoupling
#### Systems
- Neighboring regions sharing biomes, e.g., Amazon basin countries
- Bordering regions like Eastern Europe and Western Europe
- Regional clusters such as Middle East and North Africa
#### Flows
- Regionally shared deforestation fronts and savannah conversion
- Cross-border food, timber, and livestock trade within macroregions
- Shared river-basin land-use impacts affecting adjacent countries
#### Agents
- Regional economic blocs and trade partnerships
- Transboundary agribusiness and forestry companies
- Regional development and river-basin authorities
#### Causes
- Regional market integration and agricultural specialization
- Shared policy frameworks like common agricultural policy
- Transboundary infrastructure, roads enabling frontier expansion
#### Effects
- Spatial clustering of land-use change hotspots across borders
- Regional biodiversity declines in shared ecosystems
- Regional carbon stock shifts in contiguous forests and savannahs

### Telecoupling
#### Systems
- Consumer regions: Europe, East Asia, Middle East and North Africa
- Producer regions: Latin America, South East Asia, Eastern Europe, Oceania
- Mover regions: South Asia, Sub-Saharan Africa, parts of East Asia
#### Flows
- Virtual cropland and pasture embodied in international crop and meat trade
- Telecoupled biodiversity and carbon loss driven by export-oriented commodities
- Climate-change impacts and CO2 fertilization affecting distant land systems
#### Agents
- International agribusiness and commodity traders
- Global consumers influencing demand via diets, biofuel use
- Multilateral bodies shaping climate and trade regimes
#### Causes
- Rising global food, feed, and bioenergy demand
- Trade liberalization and globalized supply chains
- Anthropogenic climate change altering productivity and disturbance
#### Effects
- Export-driven deforestation and habitat loss in producer regions
- Externalization of land footprint from rich importers to poorer exporters
- Telecoupled risks to food security, biodiversity, and carbon budgets

### Cross-Coupling Interactions
- Consumer imports from producers cause biodiversity and carbon loss abroad while enabling recovery at home
- Mover-region demand increasingly pressures both nearby producers and distant exporters
- Climate-driven productivity and carbon changes modulate trade-driven land-use outcomes

### Research Gaps or Limitations
- Limited temporal coverage; analysis ends 2010 and misses recent land-use dynamics
- Deforestation and biodiversity data partly model-based, with underestimation and spatial uncertainty
- Inadequate resolution for patch-level change and weak separation of demographic versus economic drivers

### Search Keywords
- global land-use change telecoupling 2000-2010 biodiversity carbon trade
- land footprint virtual land exports consumers producers movers archetypes
- population urbanization biofuels deforestation international trade climate impacts

### Extraction Confidence
high
