# Governing flows in telecoupled land systems

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:00:41.855812+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Munroe et al. - 2019 - Governing flows in telecoupled land systems.pdf
- Year: unknown
- DOI: 10.1016/j.cosust.2019.05.004
- OA status: green
- License: other-oa
- Category: Journal Articles\Review\Telecoupling
- Closed-access reason: green OA without permissive license (other-oa)

## Copyright-Safe Summary
This review paper examines how global telecouplings - long-distance flows of commodities, capital, information, people, and waste - reshape land systems and what this implies for sustainability governance. The geographic scope is global, with empirical illustrations from South America, Africa, Asia, and Central America. The authors work within land-system science and socioecological systems research, focusing on how distant production-consumption links and financial flows affect land use, deforestation, conservation, and rural livelihoods.

Methodologically, the paper is a narrative synthesis of recent empirical and conceptual studies on telecoupling, land-use change, and governance. It structures the literature around key flows and actors (states, firms, financial intermediaries, NGOs, consumers, and land users), drawing especially on work on global value chains, agribusiness frontiers (soy, beef, palm oil, timber), mining, and certification schemes.

The central argument is that sustainability in land systems can no longer be defined or governed solely within territorial boundaries. Distant interactions create spillovers, displacements, rebound and cascading effects, so interventions in one place may shift environmental pressures elsewhere or generate unexpected outcomes (for example, new deforestation frontiers or unforeseen timber demand). Governance therefore must move from a territory-based to a flow-based orientation, and be understood as collective decision-making across multilevel networks of state and nonstate actors.

Key findings include: (1) corporate and financial actors have major but often opaque influence over land-use outcomes; (2) private sustainability standards and supply-chain initiatives can reduce impacts but often face transparency limits, power asymmetries, and leakages; (3) civil society demand and global media can trigger reforms, yet benefits and burdens are unevenly distributed across places and social groups; and (4) enabling public policies, attention to actor power relations, and combinations of governance tools are required for more effective interventions.

The paper explicitly advances telecoupling and metacoupling research by highlighting how distant linkages create governance challenges and by identifying research priorities to use telecoupling insights normatively to steer land-system transformations toward sustainability.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong focus on telecoupling of land systems; discusses spillovers and distant feedbacks across territories.

### Intracoupling
#### Systems
- Local agricultural and forest landscapes under national policies
- Costa Rica forest and farming sectors
- Brazilian Atlantic forest transition regions
#### Flows
- Domestic land use change between agriculture and forestry
- Shifts from extensive to intensive farming
- Internal timber and food supply reorganization
#### Agents
- Local land users and smallholders
- National governments and regulators
- Domestic agribusiness firms
#### Causes
- National conservation and reforestation policies
- Domestic economic development strategies
- Property rights and land tenure changes
#### Effects
- Forest transition and plantation expansion
- Agricultural intensification in remaining farmlands
- New internal vulnerabilities and inequalities

### Pericoupling
#### Systems
- Brazilian Amazon and Cerrado frontiers
- Gran Chaco and Chiquitano regions
- Neighboring agricultural regions in South America
#### Flows
- Regional displacement of soybean expansion
- Cross-border shifts in deforestation frontiers
- Regional trade in timber and agricultural products
#### Agents
- Regional agribusiness investors
- Subnational governments and state agencies
- Regional civil society and NGOs
#### Causes
- Stricter forest rules in some states
- Search for deforestation havens with weaker regulation
- Efforts to retain more forestry value domestically
#### Effects
- Leakage of deforestation to laxer jurisdictions
- Uneven regional conservation outcomes
- Tensions between nationalist and global market agendas

### Telecoupling
#### Systems
- South American soy and cattle frontiers linked to global markets
- Costa Rica linked to international food and timber trade
- Colombian coffee landscapes connected to eco-consumers abroad
#### Flows
- Global trade in soy, beef, palm oil, timber, specialty coffee
- Capital, financial investments, and land grabbing funds
- Information and knowledge diffusion among transnational firms
#### Agents
- Multinational agribusiness and commodity traders
- International NGOs and certification schemes
- Distant consumers, financial intermediaries, global media
#### Causes
- Global demand for high-value agricultural commodities
- Sustainability standards and zero-deforestation commitments
- Financialization of land-based assets and deregulation agendas
#### Effects
- Deforestation displacement and new agricultural frontiers abroad
- Cascading cross-sector impacts like pallet wood demand
- Asymmetric benefits, vulnerabilities, and power across distant regions

### Cross-Coupling Interactions
- Policies in one region trigger land use and market shifts in other continents
- Supply chain interventions cause leakage and spillovers to spillover systems
- Information and media flows reshape corporate and consumer behavior worldwide

### Research Gaps or Limitations
- Limited understanding of power asymmetries and actor-to-actor influence in telecoupled networks
- Difficulty tracing causal chains between interventions and distant spillovers
- Need to assess combined effects of multiple policy tools across scales

### Search Keywords
- telecoupled land systems governance
- global commodity flows deforestation spillover
- sustainability standards supply chain transparency

### Extraction Confidence
high
