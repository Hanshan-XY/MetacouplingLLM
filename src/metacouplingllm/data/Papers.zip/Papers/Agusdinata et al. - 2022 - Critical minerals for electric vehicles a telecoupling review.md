TOPICAL REVIEW • OPEN ACCESS

# Critical minerals for electric vehicles: a telecoupling review

To cite this article: Datu Buyung Agusdinata et al 2022 Environ. Res. Lett. 17 013005

View the article online for updates and enhancements.

# You may also like

Ensuring fair and just participation of landconnected communities in critical minerals governance in Africa. Joshua Matanzima   
Putting community-centric justice into justtransitions from the Global South: the case of Indonesia’s nickel sector Rini Astuti, Sujatha Raman and Ardhitya Eduard Yeremia   
Cross-scale interactions of socio-- hydrological subsystems: examining the frontier of common pool resource governance in Arizona Abigail M York, Abigail Sullivan and Julia C Bausch

![](images/1a6c13d9af71ed3352b51f82d52c5410080ed678f74d8413cbd4edac557b5326.jpg)

![](images/c76f1d09d5f890d301cbe62d27dcf7478c8690dc3026ade1064a2d102604e62f.jpg)

# ENVIRONMENTAL RESEARCH

LETTERS

![](images/dc18fc96838d270858b22f509dcac22308d6dabf439d7dd719cc15efc438378c.jpg)

CrossMark

# OPEN ACCESS

RECEIVED

4 June 2021

REVISED

4 December 2021

ACCEPTED FOR PUBLICATION

31 December 2021

PUBLISHED

14 January 2022

Original content from this work may be used under the terms of the Creative Commons Attribution 4.0 licence.

Any further distribution of this work must maintain attribution to the author(s) and the title of the work, journal citation and DOI.

![](images/a335d3504ee6c71fd25c81d03ac1f33ca7d6e35b2992cb5c616f84c0cd7d63f0.jpg)

# TOPICAL REVIEW

# Critical minerals for electric vehicles: a telecoupling review

Datu Buyung Agusdinata $^ { \ast } \oplus$ , Hallie Eakin and Wenjuan Liu

School of Sustainability, Arizona State University, Tempe, AZ, United States of America Author to whom any correspondence should be addressed.

E-mail: bagusdin@asu.edu

Keywords: critical minerals, electric vehicles, resource governance, mineral supply chain, corporate social responsibility, public discourse, telecoupling

# Abstract

The rapid growth of electric vehicles adoption, which plays a crucial role to reduce transportation carbon emissions, is leading to a surge in demand for critical minerals such as cobalt, nickel, lithium, and rare earths. Efforts to systematically address the emerging sustainability issues associated with critical minerals have been challenged by complex mineral supply chains, and the distal and geographically dispersed nature of social-ecological impacts from mineral extraction and processing and eventual use. In this review, we apply a bibliometric analysis of the literature in the 2010–2020 period to analyze the state of research on the issues of critical mineral extraction impacts and the global governance responses. We use the concept of telecoupling to structure our literature search and analysis across four themes: (a) critical minerals global trade and supply chain, (b) sustainability and resource policy and governance, (c) mining corporate social responsibility, and (d) information feedback and public discourse. We find a growing attention to the social-ecological implications of critical mineral extraction, but also fragmentation among thematic domains that could impede progress towards more coordinated system governance. Based on the analyses, the paper concludes with a definition of some research and engagement opportunities around the telecoupling themes.

# 1. Introduction

The world faces a growing demand for critical minerals to meet expanding demand for clean energy and low-carbon technologies and to fuel the transition to cleaner energy futures (Bazilian 2018, Lèbre et al 2020, Sovacool et al 2020a). Electric vehicles (EVs) in particular will play a key role in decarbonizing the transportation systems. In the 2014–19 period, EVs sales have expanded by an annual average of $6 0 \%$ . The EVs minerals include graphite, cobalt, nickel, manganese, copper, lithium, aluminum, and rare earths. Given the current low recovery and recycling rate, most of the mineral supply will need to come from virgin materials, leading to an expansion of mining. Today, most critical mineral extractive activities take place in the Global South, while the majority of these minerals are embedded in products consumed in the industrial and urbanized Global North (e.g. US, Canada, Europe, Japan).

Nevertheless, there are growing concerns over the socio-environmental impacts of mineral extraction,

and a new recognition that these issues need to be addressed if EVs are to be promoted as sustainable technology. For example, Amnesty International has identified the use of child labor in cobalt production in the Democratic Republic of Congo, which produces over $6 0 \%$ of today’s supply, presenting an ethical issue for the industry (Amnesty International 2016). Nickel mining is causing environmental degradation to freshwater and marine ecosystems in Indonesia. Some of these areas are already weakened ecologically by demand for timber, and mining is putting additional habitat pressure on critically endangered species (Dominish et al 2019). Lithium mining activities in Chile are resulting in degraded environmental quality too, threatening the habitat and livelihood of endangered flamingo birds (Agusdinata et al 2018, Liu et al 2019). Practitioners and policymakers are now raising questions about how to systematically address the emerging issues associated with critical minerals, and what role science can play in providing a clear and consistent framework for governing their use (Ali et al 2017).

The distal impacts and externalities, however, are not always visible to the consumer. The demand for and supply of critical minerals is geographically bifurcated, with demand concentrated in the more affluent populations of the Global North and, to date, the supply concentrated in geographies of the Global South. Furthermore, the complex supply chains that characterize critical mineral use, and the fact that consumers are typically unaware of the use of critical minerals in their consumer products (Ali et al 2017), pose a challenge to altering the governance of critical mineral extraction. Consumer and shareholder awareness can play instrumental roles by elevating issues associated with the environmental and social negative externalities of supply chains, motivating institutional change (IRP 2020). Effective governance will require the involvement of knowledge, actors, and activities within and beyond the complex global mineral supply chain. The research community thus has a role to play in the documentation of the full range of environmental and social concerns associated with critical mineral extraction to enhance the availability of such information for industry, regulators, and consumers.

We review the literature on critical mineral extraction to explore the extent to which the externalities are being documented, how the corporate mining sector is receiving and responding to mineral extraction and what is being discussed in terms of governance of resource extraction and trade of these critical minerals. To encompass a broader range of potential impacts and outcomes associated with mineral extraction, we frame our analysis through the lens of telecoupling. Telecoupling is an analytical approach to explore the coupling of distal socialecological-technical systems through flows of, for example, material, information, technology, people, and the governance of such flows and connectivity (Liu et al 2013, Eakin et al 2014). Telecoupling is a useful framework for critical mineral extraction given the geographic concentration of regions of demand and supply, the potential for social and ecological primary (e.g. direct effects of the mining process), and secondary (e.g. implications for livelihood displacement, ecosystem disruptions) impacts, and the complexity of governance, given the diversity of geographically dispersed actors involved (civil society organizations, corporate entities, consumer groups, government regulators).

Our review builds on several recent publications that have highlighted the need for further work on the externalities of critical mineral extraction. Lee et al (2020b) argue that existing methodologies are currently insufficient in capturing the full suite of environmental, social, and governance concerns associated with copper mining; while they do not suggest a framework for addressing methodology gaps, this work illustrates the complexity of the challenge. As demand for EVs and other technologies

has grown, concerns have also been raised in relation to the security of the global supply (Wang et al 2020) and the geo-politics of the critical mineral supply chains (Kalantzakos 2020). Others have begun to highlight issues regarding social justice concerns in critical mineral extractions (Heffron 2020). Here we expand this work by pursuing a more systematic and integrated approach, with the aim of providing a framework through which the future contributions of knowledge can be assessed.

The remainder of the review is structured as follows. Section 2 introduces the telecoupling context of the research area and describes the bibliometric data used in the study. Section 3 presents key findings and discusses their significance. The paper concludes with a definition of research and engagement agenda.

# 2. Methodology and data

# 2.1. Telecoupling framework

Telecoupling framework is used to structure the bibliometric analysis as well as implications of the study (figure 1). A telecoupling lens aids the analysis by identifying the multiple domains of knowledge that are potentially needed for effective governance. The telecoupling heuristic goes beyond the consideration of primary, secondary, or even tertiary supply chain externalities of resource use; it also highlights the channels through which institutional, economic, or social changes trigger transformations in distal ‘receiving’ locations, as well as how knowledge of such transformations is fed back to such ‘sending systems’ to potentially stimulate shifts in governance (Eakin et al 2014).

A telecoupling framework thus demands integration of knowledge on social and environmental impacts in disparate geographies, with analysis on material and information flows, and knowledge on the nature of institutional change in industry actors, among consumers, and governing bodies. This paper thus employs a telecoupling lens to a priori create four categories of literature analysis:

(a) Critical minerals global trade and supply chain— Relevant aspects in this theme include the global mineral market and material flows for use in EVs and supply chain practices that support production of EVs.   
(b) Sustainability and resource policy and governance—Relevant aspects include sustainability policies in the sending systems and the governance of resources in the receiving systems.   
(c) Mining corporate social responsibility (CSR)— This theme covers CSR as a resource governance mechanism within supply chain actors linking sending and receiving systems.   
(d) Information feedback and public discourse—This theme concerns the flow of information, and how the general public and consumers react

![](images/c7f00739999b091d13bf2dfb0d24b7ba93d3467cb848e9c1d0f94b7a3644e002.jpg)  
Figure 1. Telecoupling framework as a structure for the literature review.

to information about social and environmental impacts in relation to mineral extraction.

# 2.2. Bibliometric data

We used different search strings to compile the recent literature in each of the above four domains as applied to critical mineral extraction and use (table 1). We apply a bibliometric analysis to help better understand (a) interactions between concerns of socioenvironmental impacts at sites of mineral extraction and end-product consumption and the global responses both by corporate, consumers, and policymakers, (b) research tendencies in terms of possible themes being focused on in the future and (c) thematic evolution of scientific papers published in this research field. Based on the milestones timeline analysis, we investigate research themes in the past 10 years: 2010–2020. We provide a summary of scientific papers published over time in this field (number, authors’ origin, journals, etc).

The research design for bibliometric analysis involved (a) an expansive search of peer-reviewed literature in the Web of Science database and (b) a manual analysis and multi-stage screening process of all articles to ascertain that selected articles would be those that:

Addressed only critical minerals, excluding mining and extraction activities on gold, coal, and oil; and that only low-carbon technologies are covered by excluding technologies such as lead batteries.   
Addressed only the interconnections between sending and receiving systems by including multinational mining operations and excluding those that are limited to local concerns.

• Focused on the role of cross-boundary (international) factors in affecting policies and practices and not on internal dynamics such as managing tensions and trade-offs between business and social performance.

We use the software Bibliometrix (https://bibliom etrix.org) to analyze the title, abstract, keywords, and authors of the selected literature. Based on the defined four telecoupling themes, we used the following Boolean search terms for 2010–2020 period (table 1).

For each aspect of the telecoupling framework, we report on the trends in scientific production (number of publications and geographical distribution), evolution of relationships among top research themes and research teams, and the authors of the most impactful publications. We uncover the knowledge structures in this literature by revealing the main themes and trends. The analyses include (a) a co-word network to define the most important and the most recent issues, (b) a factorial analysis to identify subfields of research themes, and (c) a thematic evolution analysis based on centrality and density measures.

# 3. Results and analysis of telecoupling themes

In this section, we perform a detailed analysis of the intellectual structure for each EVs critical minerals telecoupling theme. Subgroups of topics within each telecoupling theme are derived using hierarchical cluster analysis (Zupic and Caterˇ 2015), which reduces the dimensionality of data and represents it in a low dimensionality space. We use a dendrogram to

Table 1. Bibliometric data.   

<table><tr><td>Telecoupling theme</td><td>Search terms</td><td>No. of articles</td></tr><tr><td>Critical minerals trade and supply chain</td><td>(mining OR mineral* OR metal*) AND (&#x27;low carbon&#x27; OR &#x27;electric vehicle*&#x27;) OR batter* OR &#x27;electric car&#x27;) AND (&#x27;supply chain&#x27; OR trade)</td><td>58</td></tr><tr><td>Sustainability and resource policy and governance</td><td>(mining OR mineral* OR metal*) AND (&#x27;low carbon&#x27; OR &#x27;electric vehicle*&#x27;) OR batter* OR &#x27;electric car&#x27;) AND (&#x27;policy&#x27; OR &#x27;governance&#x27;)</td><td>17</td></tr><tr><td>Mining corporate social responsibility (CSR)</td><td>(mining OR mineral* OR metal*) AND (&#x27;low carbon&#x27; OR &#x27;electric vehicle*&#x27;) OR batter* OR &#x27;electric car&#x27;) AND (&#x27;corporate social responsibility&#x27; AND &#x27;multi-national&#x27;)</td><td>64</td></tr><tr><td>Information feedback and public discourse</td><td>(mining AND (mineral* OR metal*)) AND (&#x27;low carbon&#x27; OR &#x27;electric vehicle*&#x27;) OR batter* OR &#x27;electric car&#x27;) AND (&#x27;public opinion&#x27; OR &#x27;discourse&#x27; OR information OR &#x27;news media&#x27; OR &#x27;social media&#x27; OR feedback OR consumer)</td><td>9</td></tr></table>

![](images/20ee3ab99a0b18c96e80590f2366dfe1991435ff64d3ae6bf5b577a4bccf02d9.jpg)  
Figure 2. Topic clustering for critical minerals international trade and supply chain theme.

graphically visualize topic clusters based on the similarity of keywords. The clusters represent the keywords that often appear together and are shared in some fashion across a group of articles. Distant clusters imply that only a small fraction of articles use these words together and the keywords are not shared with other articles in the sample. The height in the dendogram measures the distance among words or cluster of words.

# 3.1. Theme 1: critical minerals international trade and supply chain

The topic clusters in this theme are summarized in figure 2. This suite of literature tends to focus on the motivation for adoption of EV (e.g. the drive

for a low-carbon economic future) (e.g. Bazilian 2018, Nansai et al 2019, Lee et al 2020a) and the risks posed in achieving that vision by relying on rare earth minerals from geographically concentrated and potentially politically unstable regions (Sun et al 2019, Nassar et al 2020, van den Brink et al 2020). The concept of criticality features prominently, as the availability of critical minerals is seen to be threatened by potential disruptions in regions of supply (Schmidt et al 2016, Olivetti et al 2017, Ballinger et al 2019, Cimprich et al 2019, Mateus and Martins 2020, Nassar et al 2020, Sun et al 2020, van den Brink et al 2020). Several articles discuss the potential need to shift mineral extraction to the regions of consumption (e.g. Europe) to improve the control

![](images/9a8e0f49db3aa16ffa1bf61ce6468aa28fcb0361cc9fcc375735552eb783358d.jpg)  
Figure 3. Topic clusters for sustainability, resource policy and governance theme.

and security of the supply chain (Sun et al 2019, Mateus and Martins 2020, Schmid 2020). A few articles address broader issues (beyond the threat to achieving low carbon objectives) of sustainability (environmental, social, and economic) related, for example to efforts to achieve the Sustainable Development Goals in regions of supply (Agusdinata et al 2018, Bazilian 2018, Hancock et al 2018, Stoycheva et al 2018, Zeuner 2018, Nansai et al 2019) but these are the minority in this group. The need for incorporating more comprehensive life cycle assessments (LCAs) to capture the full costs of mineral extraction and use is also highlighted (Stoycheva et al 2018, Weimer et al 2019, Lee et al 2020b).

# 3.2. Theme 2: sustainability, resource policy and governance

The topic clusters in this theme are summarized in figure 3. This literature raises questions concerning the need for improved governance of critical mineral extraction for sustainable transitions to a low-carbon economy (e.g. Bazilian 2018, Sovacool et al 2019, 2020b, Henry et al 2020). Several authors explore the actors that should be involved in such governance (e.g. Weiser et al 2015, Hancock et al 2018), and others focus on the role of problem-framing in how governance arrangements are organized (Nerlich 2011, Barandiar´an 2019, Henry et al 2020). Issues of social justice and just energy transitions surface in this literature (Sovacool et al 2019, Henry et al 2020) in

relation to how the benefits and burdens of mineral extraction are framed and narrated to motivate the focus of international governance. Given the prominent role of transnationals in mineral extraction, the potential and limitations of state action in governance efforts are also explored (Gavin 2015, Zhang et al 2019a, 2019b), with illustrations of institutional innovations in public–private partnerships (Weiser et al 2015, Hancock et al 2018). Several articles document the range of direct and indirect supply chain impacts across sites of production and consumption (Kotsadam and Tolonen 2015, Sverdrup 2016, Agusdinata et al 2018, Ardron 2018, Bazilian 2018) and call for improved recognition of such impacts and action. Importantly, the literature highlights the need for and limitations of national-level policy action (in supply- or demand origin countries) with implications for the intervention of international agencies such as World Trade Organization (WTO) (e.g. Prior et al 2013, Weiser et al 2015).

# 3.3. Theme 3: mining and corporate social responsibility

This body of literature explores what issues pertaining to critical minerals are rising to the attention of corporate actors, what actors are involved in motivating corporate action, and how corporate actors are responding to such pressures (figure 4). Conflict with communities in sites of mineral extraction is one prominent theme (Kemp et al 2011, Dam-de Jong

![](images/9d2e58e97da5a7077447df88dd18e6a6aa1c7dbb2e9dddddc74aff1bc172013d.jpg)  
Figure 4. Topic clustering for mining and corporate social responsibility theme.

2015, Mayes 2015, Rolston 2015, St-Laurent and Billon 2015, Banerjee 2018, Haslam 2018, Haslam et al 2018), indicating that mineral exploitation is often being met with resistance, motivating mining interests to alter their strategies in the field to address opposition directly (Lodhia and Hess 2014, Adler et al 2017, Arikan et al 2017, Buchanan and Marques 2018). Banerjee (2018), for example, explores the limitations of Corporate Social Responsibility protocols in managing conflicts, while St-Laurent and Billon (2015) explores innovations in institutional arrangements between corporations and communities to address emergent conflicts. Human rights violations are specifically raised in several articles, indicating an emergent focus on the relation of localized social impacts to internationally recognized justice norms, and implications for CSR (Hanna and Vanclay 2013, Pesmatzoglou et al 2014, Idemudia and Kwakyewah 2018). Mares (2018), for example, emphasizes the role of transparency laws in elevating human rights concerns, and Conde (2017) explores the strategies communities are employing to bring attention to their grievances. Environmental issues are less featured in this sample of the literature, with only a few articles identifying biodiversity impacts and carbon offsets (Virah-Sawmy et al 2014, Adler et al 2017) and water issues (Schoderer et al 2020) as concerns in CSR mining policy.

A significant segment of this literature focuses on the differential roles of specific stakeholders and institutional mechanisms in motivating and enforcing CSR policy, exploring the role of states and regulatory agencies (Radulescu 2013, Bodruzic 2015, Haslam

2018, Idemudia and Kwakyewah 2018, Boone Barrera 2019), non-governmental organizations (Lodhia and Hess 2014, Tsai and Wu 2018), and national, binational and international instruments (Dam-de Jong 2015, Paterno 2016, Grégoire 2019). Dong et al (2014) finds, for example, that increasingly international consumers have an impact over CSR, while ‘mining industry associations, local communities and employees are not considered as salient…’. The keyword analysis illustrates that issues of legitimacy, responsibility, accountability, ethics and responsibility, the mechanisms of interaction (licenses, performance metrics, self-regulation, reputation management) are emerging to pressure corporate action (particularly human rights, justice, and conflict). This literature also covers the motivations and conditions for firms to adopt CSR policies and alter their actions in the supply chain (Buchanan and Marques 2018, Dalla Via and Perego 2018, Parker and Cox 2018, Mateus and Martins 2020). Given the importance of information flow to corporations to signal salient impacts, a number of articles also focus on the state of CSR accounting in mining (Vintró and Comajuncosa 2010, Lodhia and Hess 2014, Pesmatzoglou et al 2014, Suescun Pozas et al 2015, Sauer and Seuring 2017, Larsen et al 2018, Böhling et al 2019, Vivoda and Kemp 2019).

# 3.4. Theme 4: information feedback and public discourse

The literature specifically focusing on information and communication channels overlaps thematically with the literature on resource governance described

![](images/69b2931cebb498d171f17f089549721e24cb32800632ab0c1755811ecef62244.jpg)  
Figure 5. Topic cluster for information feedback and public discourse themes.

above, and represents the smallest body of literature reviewed (figure 5). Here the keyword clusters suggest that the literature has not yet coalesced into a cohesive discourse or direction. Some of this nascent literature focuses on how corporations interact and communicate CSR related material to their clients and the public (Autesserre 2012, Lodhia 2014, Badera and Kocon´ 2015, Gonz´alez-Rodríguez et al 2019, Song and Wen 2020); and to a lesser extent, how the flow of information works the other way, from the public to corporations (Badera and Kocon´ 2015, Guyol-Meinrath 2015, Gong et al 2020). Schwartz and Nelson (2016), for example, explore the role of the Security and Exchange Commission as a mediator of information to industry. Two articles focus on the role of the media in framing the moral implications of mining (Badera and Kocon´ 2015) and amplifying concerns (Boulus and Dowding 2014). Autesserre (2012) discusses the potential for perverse consequences of international efforts to address human rights violations in ways that resonate with foreign audiences, resulting in an exacerbation of local impacts. Gong et al (2020) highlight the potential for big data analysis approaches in enhancing the communication of consumer interests to corporate actors. The keyword cluster analysis is less informative given the small sample size, but highlights the role of communication, media and problem framing, and public opinion; corporate strategies for stakeholder engagement; methods for assessing corporate–public interactions

and legal mechanism for holding corporations accountable.

# 3.5. Additional results of the bibliometric analysis 3.5.1. Evolution of research production

We found a trend of increasing numbers of articles on the telecoupling themes over the past 10 years (figure 6). The trend is unsurprising given the growing demand for EVs and the resulting coverage of various issues associated with EVs adoption. The distributions among themes, however, are uneven. CSR topics dominated the scientific discourse and exhibited a spike in 2018. This jump of interest was likely a response to the greater scrutiny in the so-called conflict minerals (Kim and Davis 2016) and human rights abuses and corruption involved in the extractions, especially of cobalt and coltan in Congo (Amnesty International 2016). These issues received a lot of coverage in the Western news media and targeted political leaders and US Tech companies to put pressure on them to improve mineral extraction governance (Pilkington 2016). Attention to trade and supply chain themes has been growing with the recognition of the criticality of supply, i.e. concerns over the geographically concentrated sources of supply and what this implies for supply chain stability. To a lesser extent, the growth trend is also reflected in scientific outputs in the policy and governance arena. The theme on information feedback and public

![](images/e9a21f129648344fb7f69bf5945ca27986d9f4c0d1e02f6beeb2145d471a9372.jpg)  
Figure 6. Annual science production across critical minerals telecoupling themes.

discourse is uneven and appears not to have gained much traction in the literature as of yet.

# 3.5.2. Authors’ collaboration network

To establish the level of collaboration among researchers globally—a potential indicator of flows of information from diverse regions affected by mineral extracted—we tabulated the country of origin of articles’ corresponding author and the involvement of cross-country collaboration (figure 7(a)). The North American and European countries as well as China and Japan produced the most publications. The US has the highest proportion of international collaborations (i.e. multi-country publications, or MCP) followed by Australia and China. Just two mineralproducing countries from the Global South, namely Chile and Peru, have produced articles with the corresponding author coming from these countries. Those publications also involved no international collaboration (i.e. only single-country publication, or SCP).

We further explored how authors collaborate across the globe by mapping authors’ collaboration networks based on the authors’ countries of origin (figure 7(b)). Three countries: US, Australia, and Japan, form the major international scientific collaboration network. It is notable that, unlike the other two countries, Japan is predominantly a mineralconsuming country. In contrast, most mineralsproducing countries in the Global South are poorly represented. Indonesia, a major mining country, for example, has no leading role in publication contributions. An increased presence of researchers

from producing regions in academic networks would likely contribute to a deeper knowledge about local conditions and contexts and hence close the gap of knowledge production between the Global South and Global North.

# 3.5.3. Evolution of research themes

We analyze the evolution of research themes represented in the period 2010–2020 by characterizing how important (centrality; based on no. of citations) and how-well developed (density; based on no. of publications) each theme was in the literature (figure 8). Given the measurements of centrality and density, the identified research themes can be classified into four thematic groups (Cobo et al 2011): (a) motor (high centrality and density), (b) basic and transversal (high centrality-low density), (c) emerging or declining (low centrality-low density), and (d) highly developed and isolated theme (low centrality-high density).

First, the motor themes center around two clusters: one defined by supply-chain sustainability, EV adoption and climate change, the other by trade, cobalt low-carbon technologies and LCA. These clusters suggest continued interest and exploration of the supply chain impacts of energy transitions. Issues of social justice, CSR and human rights, and the issue of mineral supply constraints and China as a global player are themes that are now relatively well developed in and of themselves, but as yet not substantially integrated with other thematic domains. Issues of corporate accountability and legitimacy, and the role of consumers and political

![](images/a3b665d1612f0539e95e6a40349467f37d136d2bf837c36a5403827fb51f13b4.jpg)  
(a)

![](images/f23226c7e21b6edc13d0be2511b9022156ca22a4e9aaa2554f56d2fd474b3dea.jpg)  
(b)   
Figure 7. Publication based on (a) corresponding author’s country and (b) collaboration network. Note: SCP: Single Country Publications; MCP: Multiple Country Publications; the color intensity is proportional to the number of publications.

institutions in monitoring the sector appear to be persistent themes of focus over the time period. Finally, issues of metal criticality and the relationship of mining to sustainable development are emergent areas of research, as yet lacking full development in the literature.

# 3.5.4. Interconnections of major research themes

A keyword co-occurrence analysis across all four thematic literatures provides an overview of the literature in all four subgroups. Figure 9 demonstrates

four clusters of keywords. The red cluster illustrates a discourse over the management of extractive industries and the role of metal extraction in sustainable development. The green cluster illustrates the attention specifically to cobalt and rare earth (i.e. neodymium) and the importance of China and international trade to meet the demands of low-carbon technologies. The blue cluster illustrates the concern over the stability of the supply chain (criticality) and the availability of critical minerals to meet future demand as countries transition to

![](images/3bade5e1a498e1a09d050bf08bc5adc91ec97adde5a060a993509ff4079313c0.jpg)  
Figure 8. Research themes evolution 2010–2020.

![](images/a063b7402bb67596998e776bb13eef05292242ccc1068c8df951acd33fa749ec.jpg)  
Figure 9. Interconnections of major themes based on keywords co-occurrence network.

EV. Finally, the orange cluster addresses the concern over governance of these issues, with a strong focus on mechanisms of corporate social responsibility, communication, and management of social conflict.

# 3.5.5. Connections between literature sources, keywords, and intellectual roots

Based on the keywords, we trace where such research is being published and which articles appear seminal in specific discussions (figure 10). This way we are

![](images/0770e28d0d932c374ff7e478b2562c4cb59ed67db00de050788bcf0397dae186.jpg)  
Figure 10. A Sankey plot of connections between literature sources, keywords, and references. Note: the height of each element indicates its relative importance. The red triangle indicates keywords closely related to telecoupling framework.

able to identify the proliferation of research content and its intellectual roots. In particular, the keywords that get at the core of telecoupling concept are highlighted.

This analysis highlights the dominance of literature on CSR in the mining sector, with among others Jenkins and Yakovleva (2006), Scherer and Palazzo (2011), and Owen and Kemp (2013) as some of seminal contributions. Some works are recognized for setting the stage of research on international minerals trade and material flows. Olivetti et al (2017), Sun et al (2017), and Hao et al (2017) focus on lithium trade. Others are more comprehensive in its coverage. Graedel et al (2015) (62 critical metals), Nansai et al (2014) (rare earth, platinum, and cobalt), and Deetman et al (2018) (copper, tantalum, neodymium, cobalt, and lithium). Common keywords across the sample tend to be explicitly supply chain focused: supply-chain, mining, material flows, and CSR.

While themes of social impacts, sustainability, and sustainable development in the mining sector are less featured in the articles’ keywords, Kapelus (2002) and Hilson (2002) could be considered a seminal work, with intellectual roots also in the work of Jenkins and Yakovleva (2006). The social dimensions of mining is featured in work published in Business and Society and Extractive Industries and Society journals. Human rights, while less featured in the literature keywords, has been promoted by Scherer and Palazzo (2011), and covered in publications in

Sustainability and Environment journals. Additional coverage of the environmental and sustainable development implications of mining are featured in J. of Cleaner Production, J. of Business Ethics, and Resource Conservation and Recycling publications.

Explicit attention to governance concerns appears to be more recent and governance is not a frequent keyword in our sample. Ali et al (2017) bring attention to this issue in emphasizing governance importance in sustainable supply management, with ties to prior work of Prno and Slocombe (2012) and Owen and Kemp (2013), which both take a critical look at the concept of the social license for mining operations. Resource Policy and Corporate Social Responsibility and Environmental Management are journals that have featured work on such issues of governance.

# 4. Discussion: key highlights and future research agenda

# 4.1. Key highlights on telecoupling themes

Framing our analysis through the analytical lens of telecoupling provides some constructive insight into the knowledge domains pertaining to critical mineral sustainability that are relatively well developed as well as those that are still nascent in development. Our analysis illustrates how the sustainability challenges of critical mineral extraction and use is, to date, largely framed from the perspective of the ‘sending’

regions of telecoupled signals. In other words, the sustainability challenges of critical minerals are defined in relation to the concerns of the countries of the Global North that are both promoting policies in support of EV adoption and low-carbon energy transitions, as well as the sites of significant consumer demand for products made with these minerals. For example, material life cycle analysis and improving the efficiency and reducing the carbon intensity of the supply chain appears to be a consolidated research theme. In addition, there is an emerging growth of research on the fragility or ‘criticality’ of the supply chain, given the increasing dependence of consumer countries on supplies from a few geographic regions, and the real risk of political or economic disruption to those supplies. We would expect more attention to this literature given that conflict associated with sites of mineral extraction would potentially derail low-carbon energy transitions in Europe, the United States, and elsewhere where such policies are progressing. The problem-framing employed in this literature may already be leading to new policy initiatives in the United States (White House 2021) and Europe (e.g. European Raw Materials Alliance (ERMA), https://erma.eu/) to secure mineral supplies through, for example, developing mineral extraction, processing and battery manufacturing capabilities domestically in order to secure more of the supply chain (National Research Council 2008).

A separate thematic domain, evident in the literature on organizations, institutions and corporate governance, is exploring how corporations respond to stakeholder demands and what institutional arrangements and innovations are emerging among civil society, corporations and state organizations to address emergent challenges. As evident in figure 5, this literature is perhaps not well integrated into the broader research on critical minerals. Nevertheless, it does address some of the emerging governance challenges that telecoupled systems pose in a globalized context. It is evident that increasing attention is being paid in this thematic domain to concerns of community development and the potential for conflict in mining regions. There is also increased documentation of the local impacts of mining activities, the implications for human rights and some attention to the role of mineral extraction in the pursuit of sustainable development goals. While nascent, the documented research on corporate–community institutional development and governance may be particularly productive in supporting the development of governance arrangements in critical mineral mining.

The literature covering methods of social and environmental accounting, metrics of impacts and modes and mechanisms of communication of information and social pressure are far less developed, but also beginning to give some insight into how knowledge on impacts translates into corporate and

public sector response. While it is to be expected that the formal rules and norms governing supply chain activities and corporate investments will influence supply chain actors, the extent to which such actors are sensitive to pressures emerging from impacts beyond their immediate domain of formal responsibility is a subject of evolving research. Some have posited that social movements—many associated with deep-rooted conflict in areas of resource extraction—may perform critical roles as feedbacks between recipient and sending regions in telecoupled systems (Boillat et al 2020). The growing interest in corporate–community relations and conflict may be one indication of the importance of this feedback mechanism. Work in sustainable and responsible supply chain management and corporate social responsibility has posited a diversity of factors and conditions determining the sensitivity of supply chain actors to information and pressures on social and environmental outcomes associated with their activities (Aguilera et al 2007, Fernando and Lawrence 2014).

# 4.2. Definition of research and engagement agenda from a telecoupling perspective

The research community can play an important role in improving the global and local governance of critical mineral extraction by filling knowledge gaps on distal impacts and supply chain externalities, evaluating how knowledge of such impacts is transmitted to actors of authority and responsibility, and making visible the innovative governance responses that may hold clues to how sustainable development goals and mineral extraction can be made more compatible. Here we outline four areas where more research activity is needed to support governance innovation.

# 4.2.1. Assessing proximate and more distal impacts

Addressing the socio-environmental impacts of minerals extractions within the SDG and CSR framework entails developing and implementing solutions to real problems at a local community level. An impactful implementation of SDG initiatives and efforts depends on meaningful engagements with a diverse group of societal stakeholders that include universities, governments, private companies, non-governmental organizations (NGOs), and communities (Lavery 2018). To facilitate such efforts, a more meaningful engagement among stakeholders between the Global South and North is needed. The engagement paradigm needs to shift from the ‘order, deliver, and pick up’ model, in which stakeholders ‘order’ a service and ‘pick up’ the solution provided by scientists (Brundiers and Wiek 2011) to an environment where knowledge and solution ideas are co-produced through shared learning and projects and initiatives are implemented through shared action, responsibility, and ownership. Higher education institutions can play a crucial role in bringing together a diverse group of societal stakeholders to

take actions and make an impact (Leal Filho et al 2019).

Another means of capturing the full extent of supply chain externalities may be through social LCA (SLCA). SLCA has obtained increasing popularity in the past several years as a method for evaluating the positive and negative social implications of a product’s life cycle from raw material extraction to final disposal—also known as cradle to grave (Benoˆıt-Norris et al 2011). Applications of the SLCA will increase awareness and encourage the improvement of social conditions of local communities by mining companies by making firm’s operational choices more explicit. Multi-criteria decision analysis (MCDA) methods such as analytical hierarchy process seeks to elicit broad stakeholders inputs that require judgmental assessment on company’s performance along several indicators categories (workers, local community, societies, supply chain, and consumers), providing a more balanced and inclusive approach.

# 4.2.2. Information flows on distal impacts

The literature we reviewed illustrates that there is a growing interest in and documentation of the range of impacts and concerns associated with both producing (receiving) and consuming (sending) systems. This body of literature, however, remains less widely cited and connected to the broader literature on supply chain governance and criticality. More attention could be given in the research community to the ways in which distal impacts are assessed, documented and communicated to public sector agencies, corporate actors and consumers. In previous work, we identified the need to address knowledge asymmetries among the stakeholders, especially the gaps between local communities and mining companies (Agusdinata et al 2018). Mining companies have stepped up their efforts for accountability by complying with national and international regulations and codes of conduct. Such mechanisms, however, rely heavily on external sources of formal data and information provided by experts and authorities, thereby neglecting local and traditional (indigenous) sources of knowledge and practices (Bavinck and Gupta 2014). In this setting, local communities have few avenues and options to voice their concerns and share their knowledge (Sosa and Zwarteveen 2014). Local knowledge may be particularly critical to capture in relation to the social-cultural and more intangible values and interests affected by mineral activities.

There is relatively little analysis to date of the role of the news and social media, non-governmental organizations and other private actors in communicating and disseminating knowledge on distal impacts to those actors in the supply chain that have the capacity to alter mining activities. Our analysis illustrated that the literature addressing information flows and

feedback was perhaps the least well-developed of the four thematic areas, and, as yet, poorly articulated with the other thematic domains. There is only a nascent understanding about the extent to which the media can play a role in channeling and amplifying sustainability concerns (e.g. Gómez-Carrasco et al 2021), and even less focus specifically on the role of media communicating local impacts of mineral mining back to sites of technology use. Media analyses can establish evidence of the effectiveness and limitations of news and social media reporting as a feedback mechanism in enhancing telecoupling governance.

# 4.2.3. Mobilization and governance innovation as response to distal impacts

Consumer awareness and mobilization through nongovernmental organizations can play a significant role in mobilizing corporate action to enhance sustainability (Lyon and Maxwell 2008). There is some evidence that consumers of low-carbon technologies are starting to have an awareness that such technologies use a multitude of minerals that could cause environmental degradation and harm in regions and communities of mineral extraction (IRP 2020, Kramarz et al 2021). Nevertheless, it is still unclear the extent to which awareness translates into consumer preferences and choices, regulatory reform or corporate innovation. More research is needed on what motivates consumers of EVs and where they access information about supply chain impacts (Ali et al 2017). Consumer surveys, preference assessments and research into the relationship of consumers’ knowledge over distal impacts and EV demand would help support the design of more effective points of leverage to encourage shifts in unsustainable supply chain practices. There is also a need for more work on the politics of collective action in relation to EV use and adoption, and the relationships among networks of consumer advocates, environmental groups and human rights organizations in actions to influence supply chain actors and policy-makers (Burns and LeMoyne 2001). Given the political mobilization of many environmental constituencies in support of EV adoption, how emergent evidence of distal impacts is addressed by such actors is of interest in understanding the complex process of sustainable energy transitions.

Our review also points to a growing focus on novel modes of mine-community interactions and governance arrangements. In this work, we see an opportunity to explicitly evaluate the implementation of sustainability initiatives in relation to the targets of the Sustainable Development Goals. In their attempts to implement CSR, emergent evidence suggests that most large mining transnational companies have failed to translate promises to communities into action plans (Responsible mining foundation 2020). Given companies’ high awareness of SDGs (Izzo et al 2020), there is an opportunity to adapt existing

corporate measurement and evaluation systems and improve CSR engagement in a way that contributes to sustainable development.

We see unique opportunities for transdisciplinary approaches to research (Schneider and Buser 2018). There are several ongoing multi-stakeholder initiatives with coalitions of industry, non-governmental and public actors that could serve as models for such work in critical mineral extraction, such as the Sustainable Coffee Challenge (Millard 2017), or the SeaBOS initiative for sustainable global fisheries (Österblom et al 2017), the Alliance for Responsible Mining (www.responsiblemines.org/en/), which works to advance artisanal and small scale mining and sustainable development, or the Extractive Industries Transparency Initiative (https://eiti.org/), a coalition of government, companies, and civil society to promote accountable management of extractive industry.

# 4.2.4. Global critical mineral governance

In our review, we found relatively little focus on intergovernmental or supra-national governance initiatives. Much of the research of the last decade positions mining within a global neoliberal regulatory regime, in which industry organizes to adopt voluntary standards and reporting requirements in lieu of more direct government regulation (e.g. Bodruzic 2015, Dalla Via and Perego 2018, Idemudia and Kwakyewah 2018, Tsai and Wu 2018). While the literature does raise issues related to the mining sector’s voluntary contributions to international sustainability initiatives such a human rights standards (e.g. Coumans 2011, 2017); the Sustainable Development Goals (e.g. Yakovleva et al 2017), biodiversity protection (e.g. Adler et al 2017), as yet, international cooperation specifically aimed at improving the sustainability of critical mineral mining has not consolidated. Given nascent efforts in this area (see IRP 2020), we would expect that in the future more literature will explore the implications and effectiveness of these governance efforts. Given the emphasis on industry-initiated standard setting and reporting, evolving international governance regimes will require collaboration among supranational bodies such as the United Nations or European Union, non-governmental organizations with international as well as local focus, and national and international industry associations.

The need for a global critical mineral governance through cooperation between government and nongovernment has just recently been recognized. The European Union, for example, issued the following statement in an event of the ERMA, a network of organizations from the public and private sectors covering the entire raw materials value chain: ‘… the reasons to explore sustainable mining in the EU are not only of economic and geopolitical nature. We also have a moral obligation. If we do not have an open debate about sustainable mining in Europe, without

taboos, we will continue in a situation where we import raw materials from mines far away from our homes and conveniently close our eyes on how they were sourced. It is high time that we are honest and take more responsibility ourselves. We need to work together and develop a European approach with high environmental and social standards which is backed by stakeholders (European Commission 2021)’.

# 4.3. The role of the interdisciplinary research community

Our review unsurprisingly demonstrates the dominant role of researchers from the Global North in multiple knowledge domains, and a coincident emphasis on issues of supply and criticality that are of significant concern in such regions. A telecoupling framework provides an opportunity to bring together researchers and other stakeholders from across the telecoupling spectrum and associated geographies to synergize intellectual resources to address the emerging issues around the world. Such a coalition of academics, NGOs, policymakers and private sector representatives could serve as a hub for research, education, and stakeholders/community engagement on the socio-environmental impacts of critical minerals extractions, use, and end-of-life. Innovations in research approaches, knowledge integration, and co-production will not only enhance the potential for governance of critical minerals, but also provide insights applicable to the management of other complex, globalized supply chains that play important roles in sustainability transitions.

# 5. Concluding remarks

Our review of the sustainability of critical minerals underlines a dilemma faced by modern society. On the one hand, the adoption of low-carbon technologies such as EVs is considered crucial to reduce GHG emissions and mitigate climate change. On the other, as more of these green technologies are adopted, a rapidly growing demand for critical minerals may result in collateral damages particularly in local communities and ecosystems affected by extraction activities. For the consumers, the fact that some of the minerals such as lithium and cobalt are hidden in EV components and the damages take place in distant locations may obscure such a dilemma. The use of these minerals is being touted as essential for low carbon transitions, yet social harms and environmental degradation from mineral extraction are now being recognized, initiating debates about the overall sustainability of low-carbon technologies. The urgency and importance of this issue provide an opportunity for a more meaningful and inclusive collaboration among all stakeholders. It is especially important to involve those who have been historically marginalized in extractive practices and industries, particularly indigenous communities. The

academic research community will also greatly benefit from the substantive empirical and theoretical contributions of researchers from mineral-producing countries.

Addressing the sustainability of EVs minerals requires not only improvements in supply chain practices and governance of resources but also a better way of thinking and conceptualizing the issue; a telecoupling framework, linking both systems of extraction and consumption as well as the multiple flows between them, may serve to help ensure research fills the knowledge gaps to improve opportunities for sustainable governance. By considering impacts, actors, policies, and their relationships in the sending and receiving systems, we argue that the framework can better capture the complexities and impacts associated with mineral extractions.

