Article

# Recontextualizing Telecouplings in Electricity-Driven Land Use Flows via Global Supply Chains

Xiao Li 1, Chaohui Li 1,2, Muhammad Yasin Gill 1, Mengyao Han $^ { 3 , 4 , * ( \oplus ) }$ , Yihong Liu 1, Ying Fan 5, Zhi Li 1 and Guoqian Chen $\mathbf { 1 } _ { \textcircled { 1 0 } }$

1 College of Engineering, Peking University, Beijing 100871, China; gqchen@pku.edu.cn (G.C.)   
2 Potsdam Institute for Climate Impact Research, 14412 Potsdam, Germany   
3 Institute of Geographic Sciences and Natural Resources Research, Chinese Academy of Sciences, Beijing 100101, China   
4 College of Resources and Environment, University of Chinese Academy of Sciences, Beijing 100049, China   
5 State Key Laboratory of Urban and Regional Ecology, Research Center for Eco-Environmental Sciences, Chinese Academy of Sciences, Beijing 100085, China   
* Correspondence: hanmy@igsnrr.ac.cn

# Abstract

The global energy transition is expected to require three to twenty times more land areas than fossil fuel-based power generation, making the availability of suitable land for the global energy transition a key challenge. Based on different types of energy resources, this study designs a telecoupling multi-regional input–output (MRIO) model to analyze cross-border electricity-driven embodied land appropriation patterns. The results show that the land footprint associated with renewable energy is substantially lower than that associated with conventional power generation. However, the growth rate of this footprint is 2.18 times higher than that of conventional electricity generation. China and Germany are identified as key export markets for wind- and solar- driven embodied land. The share of electricity-driven embodied land from China to the United States, Japan, and Germany declined, whereas the embodied land flowing to countries including South Korea, India, and Singapore increased. Embodied land-exporting nations face trilemma issues related to environmental degradation chain reactions, resource consumption threshold lines, and social distribution tensions, which may significantly affect decarbonization progresses. By integrating renewable power infrastructures and land use occupation, this analytical framework is expected to advance the understanding of energy–land nexus dynamics, providing theoretical foundations for cross-system governance in the implementation of carbon neutrality.

![](images/22344ef16474dd48eaacb7ea0bc96e56cee988aa96f671ff5e32659b653634ec.jpg)

Academic Editor: Brian D. Fath

Received: 18 July 2025

Revised: 23 September 2025

Accepted: 24 September 2025

Published: 28 October 2025

Citation: Li, X.; Li, C.; Gill, M.Y.; Han,

M.; Liu, Y.; Fan, Y.; Li, Z.; Chen, G.

Recontextualizing Telecouplings in

Electricity-Driven Land Use Flows via

Global Supply Chains. Land 2025, 14,

2150. https://doi.org/10.3390/

land14112150

Copyright: © 2025 by the authors.

Licensee MDPI, Basel, Switzerland.

This article is an open access article

distributed under the terms and

conditions of the Creative Commons

Attribution (CC BY) license

(https://creativecommons.org/

licenses/by/4.0/).

Keywords: multi-regional input-output analysis; embodied land; international trade; electricity-driven; renewable energy

# 1. Introduction

Countries worldwide are undergoing an energy transition owing to climate deterioration and rising energy demand. According to the International Energy Agency (IEA), electricity generation is the largest source of global $\mathrm { C O } _ { 2 }$ emissions [1], yet it is simultaneously leading the shift to net-zero by accelerating the deployment of photovoltaic, wind, and other renewables [2–4]. While existing studies have extensively compared conventional and renewable energy generation [5–7], this transition introduces critical environmental pressures [8], particularly land pressures. Renewable energy requires 10 to 20 times more

areas than fossil fuels to produce the same amount of electricity [9–12]. As countries continue to decarbonize, conflicts over arable land will intensify. Renewable infrastructures, such as wind and solar installations, impact soil quality [13] and biodiversity [14]. These problems position land resource pressures as an urgent multidisciplinary challenge, requiring systematic analysis to reconcile climate goals with ecological and socioeconomic sustainability [15]. In addition, the power production of photovoltaics (PV) has increased rapidly, with greater renewable land competition anticipated in the coming decades [16]. To address this issue, existing studies also evaluated the photovoltaic potential of different land types to identify suitable land for renewable energy production [17,18].

To date, life cycle assessment (LCA) [19–21] and multi-regional input–output (MRIO) analysis have been widely used to evaluate land use impacts [22]. However, LCA lacks uniform evaluation standards, while MRIO exhibits limited specificity regarding the electricity sector. In LCA studies, existing research indicates that hydropower achieves the highest land use density under static–indirect calculations, followed by wind and solar [6]. However, dynamic direct methods rank biomass second [23], whereas dynamic indirect approaches rank it first [24]. Introduced by Leontief [25], input–output analysis (IOA) has been extensively applied to assess ecological and environmental impacts within global supply chains, including energy [26], carbon [27], and land use [28]. Within specific sectors such as electricity, IOA quantifies resource consumption [29], environmental [30], economic impacts [31–33], and employment effects [34,35]. The MRIO has been widely employed to evaluate the embodied land use of all nations by identifying direct and indirect land occupation associated with global goods and services [24].

Existing MRIO-based literature includes time-series analyses of China’s land resources [36,37] and investigations into global land flows that reveal allocation imbalances [38,39]. Further studies mainly integrated embodied land use with international trade [37,40,41], embedded disparities in domestic trade [42], and multi-scale land use in domestic trade [43]. Concurrently, the driving factors of embodied land use are critically essential at different scales. Economic, technological, and institutional conditions have been identified as the primary drivers of European agricultural land use [44]. By examining natural and human factors, China’s 31,275 rural towns were analyzed using multiple data sources [45]. By building an ecological inventory and network, 13 cities in the Beijing– Tianjin–Hebei region of China were analyzed, revealing inter-city land flows and resource distribution inequality [46].

Telecoupling analysis contains three paradigms, i.e., intracoupling, pericoupling, and telecoupling. Liu et al. [47] examined the telecoupling of socioeconomic and ecological systems between nations through the flow of goods, resources, and information, and telecoupling transcends traditional geographical constraints. This paradigm shift has established telecoupling as a crucial tool for addressing sustainability challenges in the context of globalization. Recent methodological innovations also integrated telecoupling with multiregional input-output modeling, which decoded agricultural cropland displacement via trade networks [48,49]. Besides, Kosai et al. [50] evaluated transnational land disturbances triggered by the telecoupling effects of manufacturing for specific products. This approach enhances the understanding of issues such as biodiversity conservation [51], water security [52], and energy transitions [53], while also advancing newer disciplines, including carbon leakage through embodied emissions [54], labor market restructuring within global value chains [55], and food system transformations [56]. Notably, the growing scholarly application of telecoupling theory to trade-off phenomena across multiple domains has accelerated the progress of systemic sustainability assessments.

Building on the telecoupling method, Xiong et al. [57] integrated the World Input– Output Database (WIOD) tables to quantitatively examine nations’ contributions to

economic-environmental flows in metal trade and their variation across positions within contemporary global value chains (GVCs). Oberlack [58] used telecoupling to further advance the sustainable analyses of land governance in interrelated systems. López-Hoffman [59] applied telecoupling theory to calculate dependencies of migratory species providing services at widely separated sites, showing examples of telecoupled dynamics. Focusing specifically on the power sector, the telecoupling method anticipated would help build a systematic sustainability assessment framework.

Existing research has extensively investigated land occupation within national electricity sectors, however, a more pressing inquiry emerges under globalization: First, this study proposed a tele-connecting framework to integrate electricity-driven land use with mutil-regional input-output modeling; second, this study analyzed the power sector’s land appropriation and exhibited geospatial imbalances; third, this study identified the primary sources of electricity-driven embodied land flows by type. To address these interconnected issues, this study integrates multi-regional input-output modeling with telecoupling theory to track embodied land appropriations across transnational electricity systems, elucidating how territorial displacements and responsibility asymmetries manifest in international trade.

In this context, by integrating the telecoupling framework with the MRIO approach, this study examines the embodied land use associated with electricity generation across nations, which elucidates the transnational flows of electricity-driven embodied land appropriation and enables the systematic allocation of responsibility for land resource utilization. The study proceeds as follows: Section 2 details the telecoupling-MRIO methodology and data sources. Section 3 presents findings on electricity-driven embodied land use, its global flows, and sectoral sources. Section 4 discusses policy implications and governance strategies. Section 5 draws concluding remarks.

# 2. Methods and Data Sources

By combining telecoupling theory with multi-regional input–output analysis, this study explores the interaction between electricity-driven natural systems and socioeconomic systems between geographically distant countries. The telecoupling method identifies the sending and receiving systems, while MRIO quantifies the global flow of goods and the embodied transfer of land resources. These flows manifest as internal couplings within national boundaries, while international trade extends these interactions to neighboring countries and non-neighboring countries.

# 2.1. Telecoupling Mechanisms in Electricity–Land System Interactions

This study examines the concept of telecoupling and demonstrates how it improves the understanding of land use changes linked to electricity systems in a globalized world. The development of global supply chains has led to a spatial disconnect between the location where electricity is generated and where its land footprint is ultimately consumed. Identifying and promoting sustainable, equitable land use practices while phasing out unsustainable ones has thus become a complex challenge. By integrating land use changes with sustainability issues related to electricity, this study systematically examines the relevance of telecoupling research against the backdrop of rapid energy transition. This study reflects on several pressing issues in contemporary land use change and proposes a future agenda for advancing the understanding of sustainable land use change through interdisciplinary research.

Telecoupling theory conceptualizes reciprocal socio-ecological interactions across spatially disconnected systems, especially in the power sector. Globalization has spatialized this path, causing traded goods to carry ecological footprints rooted in both the production sites and manifested at the consumption end. At the national level, the production system

exhibits dual resource dependency, which relies directly on socioeconomic inputs such as labor and capital, as well as ecological assets such as water and land; however, it also accounts for indirect ecological costs embodied within supply chains, such as the electricity embodied in finished products. Industrial electricity demand drives power generation, which directly consumes land and coal resources. These ecological burdens are transmitted stepwise along the power supply chains, ultimately settling in the end products and forming a cross-system transmission path, from land to electricity to goods.

Through the integration of telecoupling theory and multi-regional input–output modeling, this study developed an energy-land nexus system framework within global trade networks, as illustrated in Figure 1. By mapping the pathway from land occupation through electricity to commodities, this study identifies the mutual influences between natural and human systems within a country and the remote impacts of natural and human systems across different countries. This nested systems perspective transcends the conventional single-system paradigm, offering a novel diagnostic tool for understanding emergent behaviors in global socio-ecological systems.

![](images/55f6026953b1774531739a23b7143a18a6c5c91ffeab8b0068fc95192e3a4d57.jpg)  
Figure 1. The telecoupling mechanism for global electricity-driven embodied land flows.

# 2.2. Multi-Regional Input–Output Modeling

To overcome the methodological limitations of traditional electricity-driven land occupation assessments, this study employed a multi-regional input–output model to quantify the embodied land use of power generation systems by energy type across different countries. Here, embodied refers to the electricity-driven land resources embodied in internationally traded commodities, that is, the land resources consumed for power generation to produce goods, which ultimately become an intrinsic component of the commodities themselves through global trade circulation. By integrating land use intensity coefficients (ha/GWh), this study established systematic linkages between electricity generation and territorial appropriation. To avoid double-counting electricity flows, our analysis focused exclusively on source-level generation data from the power sector, thereby limiting input–output computations to electricity-specific transactions within the MRIO framework.

The computation of embodied electricity-driven land use proceeds through sequential analytical stages. First, direct land occupation attributable to power generation is derived by multiplying national electricity output (GWh) by energy-specific land use intensity coefficients (ha/GWh). This is followed by the systematic incorporation of these territorial metrics into a multiregional input–output framework to trace land appropriation embodied

in transnational electricity flows. The calculation of the direct land area for different energy sources is as follows:

$$
\mathrm {L} = \mathrm {P} \times \mathrm {I} \tag {1}
$$

where L denotes direct land occupation (ha); P represents national electricity generation by energy type (GWh); I signifies energy-specific land use intensity coefficients (ha/GWh). For specific values, please refer to Table 1. The computation yields 189 countries and economies, and the columns correspond to different energy categories, including coal, gas, wind, and solar.

To calculate the embodied land area, the input–output method was adopted, modeling the global economy as a network comprising m regions and n sectors. This approach balances resource and energy inflows and outflows. The balance of embodied land flows through sector i in region r can be expressed as follows:

$$
\mathrm {e} _ {\mathrm {i}} ^ {\mathrm {r}} + \varepsilon_ {\mathrm {p i}} ^ {\mathrm {r}} \mathrm {p} _ {\mathrm {i}} ^ {\mathrm {r}} + \sum_ {\mathrm {t} = 1} ^ {\mathrm {m}} \sum_ {\mathrm {j} = 1} ^ {\mathrm {n}} \varepsilon_ {\mathrm {j}} ^ {\mathrm {t}} \mathrm {q} _ {\mathrm {j i}} ^ {\mathrm {t r}} = \varepsilon_ {\mathrm {i}} ^ {\mathrm {r}} \mathrm {o} _ {\mathrm {i}} ^ {\mathrm {r}} \tag {2}
$$

where $\mathrm { e _ { i } ^ { r } }$ is the onsite land resources usage by sector i in region $\mathrm { { r } ; \mathrm { { p } _ { i } ^ { r } } }$ is the primary inputs denoted by the society into sector i in region r; $\mathbb { q } _ { \mathrm { j i } } ^ { \mathrm { t r } }$ is the intermediate inputs from sector j into sector i in region r; $\mathrm { o _ { i } ^ { r } }$ is the sectoral output of sector i in region r; qrtij denotes the goods or services produced by sector i in region s as intermediate inputs into sector j in region t; $\mathrm { f _ { i C } ^ { r t } }$ represents the goods or services that are produced by sector i in region r as household consumption, consumption of non-profit institutions serving households or government consumption in region t; frtiR represents the goods or services that are produced by sector i in region r as the rest of final demand in region t; $\varepsilon _ { \mathrm { { p i } } } ^ { \mathrm { { r } } }$ represents the embodied land use intensity of primary inputs of sector i in region r; $\varepsilon _ { \mathrm { i } } ^ { \mathrm { r } }$ represents the embodied land use intensity of goods or services produced by sector i in region r; $\varepsilon _ { \mathrm { j } } ^ { \mathrm { t } }$ represents the embodied land use intensity of goods or services produced by sector j in region t.

Given that each term in Equation (2) represents interactions across multiple countries and sectors, we express these multidimensional relationships in the matrix form presented in Equation (3) as follows:

$$
\mathrm {E} + \varepsilon_ {\mathrm {p}} \hat {\mathrm {P}} + \varepsilon \mathrm {Q} = \varepsilon \hat {\mathrm {O}} \tag {3}
$$

$\mathrm { E } = [ \mathrm { e } _ { \mathrm { i } } ^ { \mathrm { r } } ] _ { 1 \times \mathrm { m n } ^ { \prime } } \mathrm { P } = [ \mathrm { p } _ { \mathrm { i } } ^ { \mathrm { r } } ] _ { 1 \times \mathrm { m n } ^ { \prime } } \hat { \mathrm { P } }$ $\mathbf { m n } \times \mathbf { m n }$ trix for diagon $\mathrm { P ; Q = \Big [ \mathsf { q } _ { j j i } ^ { t r } \Big ] _ { m n \times m n } ; }$ $\varepsilon = [ \varepsilon _ { \mathrm { i } } ^ { \mathrm { r } } ] _ { 1 \times \mathrm { m n } } ; \varepsilon _ { \mathrm { p } } = \left[ \varepsilon _ { \mathrm { p i } } ^ { \mathrm { r } } \right] _ { 1 \times \mathrm { m n } } ; \mathrm { O } = [ \mathrm { o } _ { \mathrm { i } } ^ { \mathrm { r } } ] _ { 1 \times \mathrm { m n } } ; \hat { \mathrm { O } }$ $\mathrm { m n } \times \mathrm { m n }$

The relationship between final demand and primary inputs in the input–output table can be represented by the socio-economic matrix [60,61]:

$$
\varepsilon_ {\mathrm {p c}} \sum_ {\mathrm {r} = 1} ^ {\mathrm {m}} \sum_ {\mathrm {i} = 1} ^ {\mathrm {n}} \mathrm {p} _ {\mathrm {i}} ^ {\mathrm {r}} = \sum_ {\mathrm {r} = 1} ^ {\mathrm {m}} \sum_ {\mathrm {i} = 1} ^ {\mathrm {n}} \sum_ {\mathrm {t} = 1} ^ {\mathrm {m}} \varepsilon_ {\mathrm {i}} ^ {\mathrm {r}} \mathrm {f} _ {\mathrm {i R}} ^ {\mathrm {r t}} \tag {4}
$$

The matrix form of the equation above can be written as follows:

$$
\varepsilon_ {\mathrm {p c}} \mathrm {P} _ {\text {s u m}} = \varepsilon \mathrm {F} _ {\mathrm {R}} \tag {5}
$$

where $\mathrm { P _ { s u m } }$ is the aggregated number of primary inputs; $\mathrm { F _ { R } }$ represents the $\mathbf { m } \mathbf { n } \times 1$ column matrix for the rest of final demand. Solving Equations (2) and (4) yields:

$$
\varepsilon = \mathrm {E} \left(\hat {\mathrm {O}} - \mathrm {Q} - \frac {1}{\mathrm {P} _ {\text {s u m}}} \mathrm {F} _ {\mathrm {R}} \mathrm {P}\right) ^ {- 1} \tag {6}
$$

To account for nations’ divergent roles in global trade networks, embodied land in final demand was quantified using dedicated formulations.

$$
\mathrm {E E L} = \sum_ {i = 1} ^ {\mathrm {n}} \sum_ {t = 1 (\mathrm {t} \neq \mathrm {r})} ^ {\mathrm {m}} \varepsilon_ {\mathrm {i}} ^ {\mathrm {r}} \mathrm {f} _ {\mathrm {i i}} ^ {\mathrm {r t}} \tag {7}
$$

# 2.3. Data Sources

Building upon the method outlined above, analyzing the global flows of embodied land resources from 2000 to 2020 requires three critical datasets: national electricity generation data for different energy sources, electricity-land intensity coefficients across power generation technologies, and global multi-regional input–output (MRIO) datasets. The first two datasets are detailed in the subsequent section, followed by a description of the MRIO database in the next subsection. Global trade data were obtained from the Eora MRIO database [62] that tracks resource use and environmental impacts throughout international supply chains. International trade data in the Eora database is widely used to analyze embodied carbon emissions, land use, and other environmental impacts, enabling crossborder quantitative analysis. The International Energy Agency (IEA) database provides extensive data on global energy production, consumption, and trade, covering various energy sources, such as electricity, oil, and natural gas [2]. This study utilized IEA data related to coal, gas, wind, and solar power generation across 189 countries and economies. To analyze the evolution of electricity-driven land use, data from 2000 to 2020 are examined in five-year intervals. The correlation between generation capacity and land area was calculated to assess each nation’s direct land requirements for power generation. After reviewing previous studies, any outliers or implausible data, such as data on wind power that solely accounted for the turbine area, were eliminated. The median of the remaining data was employed to estimate density. The final outcomes align with those reported by the United Nations Convention to Combat Desertification (UNCCD) [9]. All the statistical computations were performed using MATLAB (Version R2020b).

Table 1. The density of electricity–land coefficients.   

<table><tr><td>Energy</td><td>Intensity Coefficient (ha/GWh)</td><td>References</td></tr><tr><td>Coal</td><td>0.05</td><td>[5,7,63,64]</td></tr><tr><td>Gas</td><td>0.06</td><td>[5-7,63]</td></tr><tr><td>Wind</td><td>0.13</td><td>[6,24,63,65]</td></tr><tr><td>PV</td><td>0.17</td><td>[5-7,24,44,63,64,66-72]</td></tr></table>

# 3. Results

# 3.1. Direct and Embodied Electricity-Driven Land Use

Figure 2 compares the direct and embodied land footprints of four energy generation systems, i.e., coal, natural gas, wind, and solar resources. Contrary to conventional assumptions, fossil fuel systems exhibit a larger total direct land occupation than renewables, with coal occupying $4 . 5 8 \times 1 0 ^ { 5 }$ hectares compared to solar occupying $1 . 4 9 \times 1 0 ^ { 5 }$ hectares. This phenomenon stems from the fact that fossil fuels account for a much higher share of global electricity generation than renewable energy, with fossil fuels accounting for $3 5 . 1 4 \%$ while renewables account for only $3 . 0 6 \%$ . Although fossil energy has a lower land-use efficiency per unit of energy produced, it accounts for the vast majority of global energy demand, thereby increasing the total land footprint.

![](images/855af6c6be07218f637d90af7928de4cf9bf8a7adf6be7ca0cd6809354fc2ea5.jpg)  
a

![](images/c48b5fce0dca29bb6a70b0328251aed9f35525b5632b478726dfa80e6f61be63.jpg)  
b

![](images/454d53e27bf0ed11fb1b1d6e53bef2f2884e1f405b3e7a2b21a47e6a4734412c.jpg)  
e

![](images/0e74f6cd7d109ea36b425fe4cc1859169bc29d6a3c768efa6bdd5142d8b6691f.jpg)  
c

![](images/b838cf045d2620d3a6742735a7dea6faf390b4d0505ceb6a1bd692a5eb7c59fa.jpg)  
d

![](images/fb7e61087e5aae23bd9c652f38f9a366eca55e37324711eb4d03bd16ddac68c5.jpg)  
f   
Figure 2. Direct and embodied land use in the top ten countries by direct land occupation area. a–d show land use for coal (a), natural gas (b), wind (c), and solar (d) power generation. (e,f) show the growth rates of direct land occupation in China and the United States, respectively.

For coal power, China occupies the largest land area for power generation, with direct land use of $2 . 4 3 \times 1 0 ^ { 5 }$ hectares surpassing embodied land use of $2 . 2 3 \times 1 0 ^ { 5 }$ hectares, highlighting its significant role as a global embodied land provider for the power sector. India exhibited a similar role, with direct and embodied land use areas of $5 . 2 6 \times 1 0 ^ { 4 }$ and $4 . 9 6 \times 1 0 ^ { 4 }$ hectares for the power sector, respectively. The United States shows the most significant disparity, with direct electricity-driven land use being $6 . 8 2 \times 1 0 ^ { 4 }$ hectares less than embodied land use $( 1 . 1 4 \times 1 0 ^ { 5 }$ hectares), indicating a greater reliance on foreign land. A similar pattern was observed in Germany, France, the United Kingdom, Italy, and Norway. Although Japan and South Korea rely on global supply chains, with electricitydriven embodied land use areas of $2 . 6 9 \times 1 0 ^ { 4 }$ and $1 . 2 7 \times 1 0 ^ { 4 }$ hectares, respectively, these countries primarily depend on domestic land resources, with direct land use areas of $1 . 4 9 \times 1 0 ^ { 4 }$ and $9 . 5 9 \times 1 0 ^ { 3 }$ hectares, respectively. While North American and European countries rely more heavily on global supply chains to meet embodied land use related to coal power, developed East Asian economies show less dependency on global supply chain. Meanwhile, developing Asian nations largely supply the embodied land resources.

Figure 2b analyzes the natural gas power systems, revealing distinct regional variations in land use patterns. The United States led in both direct and embodied land footprints of $1 . 1 2 \times 1 0 ^ { 5 }$ hectares and $1 . 3 7 \times 1 0 ^ { 5 }$ hectares. Russia followed with the second-highest direct land use of $2 . 6 7 \times 1 0 ^ { 4 }$ hectares, whereas China ranked second in embodied land use of $3 . 7 3 \times 1 0 ^ { 4 }$ hectares. Among the top ten countries, all rely on global supply chains to meet the embodied land use of gas power generation, with Russia being the sole exception. With natural gas reserves representing approximately $1 9 . 9 \%$ of the global total, Russia contributes $2 . 0 4 \times 1 0 ^ { 4 }$ hectares of embodied land use to the international supply chain. Regarding wind power and solar power, China leads in direct land use, with $6 . 0 9 \times 1 0 ^ { 4 }$ hectares for wind and $4 . 6 9 \times 1 0 ^ { 4 }$ hectares for solar. Additionally, China accounted for the highest embodied land use for solar power at $4 . 6 8 \times 1 0 ^ { 4 }$ hectares, whereas the United States

led in wind power, totaling $7 . 4 0 \times 1 0 ^ { 4 }$ hectares. Notably, the United States demonstrates the most significant difference between direct and embodied land use for both wind and solar power, with direct land use being $2 . 1 4 \times 1 0 ^ { 4 }$ and $1 . 7 2 \times 1 0 ^ { 4 }$ hectares lower than embodied land use for wind and solar, respectively.

The growth rates of electricity-related direct land areas were analyzed for China, the largest exporter of embodied land, and the United States, the largest importer of embodied land. In China, the growth rate of coal-related direct land occupation showed a declining trend, decreasing from $1 . 0 5 \times 1 0 ^ { 8 }$ hectares/yr in 2010 to $7 . 8 6 \times 1 0 ^ { 7 }$ hectares/yr in 2020. The growth rate of natural gas-related direct land use demonstrated a relatively moderate increase, rising from $3 . 4 2 \times 1 0 ^ { 6 }$ hectares/yr in 2010 to $1 . 2 8 \times 1 0 ^ { 7 }$ hectares/yr in 2020. In contrast, the growth rates of direct land occupation for wind and solar power increased significantly after 2015, jumping directly from $1 . 3 5 \times 1 0 ^ { 7 }$ hectares/yr and $3 . 7 2 \times 1 0 ^ { 6 }$ hectares/yr to $1 . 0 3 \times 1 0 ^ { 8 }$ hectares/yr and $8 . 7 8 \times 1 0 ^ { 7 }$ hectares/yr, respectively. Meanwhile, the United States experienced negative growth in direct land occupation for coal power, improving from $- 7 . 1 9 \times 1 0 ^ { 6 }$ hectares/yr in 2010 to $- 5 . 0 3 \times 1 0 ^ { 7 }$ hectares/yr in 2020. The growth rates of direct land use for the other three types of power generation all showed upward trends, with wind and solar power reaching $8 . 6 6 \times 1 0 ^ { 7 }$ hectares/yr and $4 . 5 3 \times 1 0 ^ { 7 }$ hectares/yr, respectively, by 2020. This divergence reflects asymmetrical policy commitments to renewable industrialization under the respective decarbonization roadmaps.

# 3.2. Electricity-Driven Land Embodied in Imports and Exports

Figure 3 presents the trend of electricity-related land occupation embodied in trade from 2000 to 2020. Embodied land flows associated with electricity grew at a compound annual rate, driven by increasing global grid integration, and the land-use share of traditional thermal power contracted persistently. Meanwhile, renewable energy systems showed yearly steady growth in embodied land use, indicating that renewable power generation has matured within standardized sustainability protocols.

![](images/766a3772d1f12e16b57b06314c23c332bab06e17f1d933b7f067310f5c93b03d.jpg)

![](images/f09e3a46643c3ce1839d91d15ec299eb4c70e9e77626a423a50b1c772c3f3836.jpg)

![](images/2a701e3a178fb5526d7037f34b0b92e9bf63207cd17938ab17d470c5a6a74f18.jpg)

![](images/124a13963dfc595a8362b4275c36299a70cd1a3daf71bd4f1a2d463007732871.jpg)  
Figure 3. Embodied import and export land areas of the top eight countries in total embodied land trade (2000–2020). (a,c) show the changes in embodied land imports for four electricity generation types, while (b,d) show the changes in embodied land exports.

From Figure 3a, an annual increase in embodied land imports was observed in several countries. Japan was the exception, with its embodied land use declining from $1 . 9 2 \times 1 0 ^ { 4 }$ hectares in 2015 to $1 . 6 0 \times 1 0 ^ { 4 }$ hectares in 2020. Between 2000 and 2010, China’s electricity-related embodied land imports grew from $1 . 6 7 \times 1 0 ^ { 4 }$ hectares in 2000 to $2 . 1 7 \times 1 0 ^ { 4 }$ hectares in 2010. Over the same period, India’s area more than doubled, rising from $1 . 8 1 \times 1 0 ^ { 3 }$ to $5 . 1 8 \times 1 0 ^ { 3 }$ hectares. From 2015 to 2020, the United States and France nearly doubled their import values, reaching $7 . 9 4 \times 1 0 ^ { 4 }$ and $2 . 3 2 \times 1 0 ^ { 4 }$ hectares, respectively. These trends indicate a general increase in the demand for land embodied in imports, with notable fluctuations in between. Among exporting countries, Germany experienced a slight decrease in the total embodied land area, from $3 . 1 1 \times 1 0 ^ { 4 }$ hectares in 2015 to $3 . 0 6 \times 1 0 ^ { 4 }$ hectares in 2020, while the other seven countries recorded annual increases. India’s embodied land exports more than doubled between 2000 and 2010, rising from $4 . 3 7 \times 1 0 ^ { 3 }$ to $9 . 3 8 \times 1 0 ^ { 3 }$ hectares. From 2015 to 2020, both China and the United States significantly increased their embodied land exports, reaching $1 . 3 2 \times 1 0 ^ { 5 }$ hectares (an increase of $8 5 . 3 5 \%$ ) and $4 . 2 1 \times 1 0 ^ { 4 }$ hectares (an increase of $6 6 . 2 7 \%$ ), respectively.

The share of embodied land use associated with coal and natural gas power declined in most countries’ trade except the United States and Japan. In the United States, the embodied land exports for natural gas rose from $2 6 . 9 9 \%$ in 2000 to $3 6 . 6 0 \%$ in 2020. In Japan, the share increased slightly from $3 6 . 2 6 \%$ to $3 6 . 7 7 \%$ . Embodied land use for wind and solar power generally increased across most regions except for Japan as an exception. Between 2000 and 2020, Japan’s embodied land use for wind power fell from $2 0 . 2 1 \%$ to $1 4 . 3 4 \%$ , and for solar from $1 2 . 9 2 \%$ to $1 1 . 6 9 \%$ . China’s embodied land use of coal power was $3 9 . 7 2 \%$ while the United States had a larger share of $4 5 . 2 4 \%$ . Globally, coal accounted for about $3 2 \%$ of embodied land exports. In 2020, coal made up $6 2 . 2 0 \%$ of China’s and $6 3 . 2 9 \%$ of India’s embodied land use, down from $9 2 . 1 2 \%$ and $8 2 . 6 1 \%$ in 2000, respectively.

The growth rates of embodied land areas for different electricity generation types across countries over time were analyzed, as shown in Figure 3c,d. For imports, the growth rates of embodied land areas slowed over time in most countries, with slight rebounds in 2020, except for the United States and Japan. China and India experienced the most significant slowdowns in the growth rates of embodied land use from traditional energy sources. In China, the share of land use embodied in coal-fired power relative to total domestic electricity generation decreased from 2.03 times the 2010 level to just 0.13 times by 2020. Over the same period, India’s ratio declined from 1.42 to 0.52 times. Solar power related embodied land use growth rates declined more significantly than wind power. In France and India, the growth rate of wind-related embodied land rebounded in 2020, rising from 1.08 times and 1.66 times to 1.35 times and 2.30 times, respectively. The growth rate of wind power’s embodied land use in the United States increased steadily from 1.52 times in 2010 to 1.72 times in 2020, while that of solar power plummeted from 11.46 to 3.87 times. In Japan, the growth rates for wind and solar power related embodied land increased from $- 7 5 . 6 5 \%$ and $9 5 . 7 5 \%$ in 2010 to 1.67 and 8.67 times in 2015, fell again to $4 4 . 0 6 \%$ and 1.91 times in 2020.

Except for China and India, the growth rates of electricity-driven embodied land exports declined over time, though a slight rebound occurred in 2020 (Figure 3d). Germany’s solar-related embodied land exports exhibited the most significant change, declining from 130.89 times in 2010 to 0.52 times in 2020. In both China and India, the growth rates of solar-related embodied land use initially increased, followed by a subsequent decline. In China, the growth rate of electricity-driven embodied land increased from 1.83 times in 2010 to 20.14 times in 2015, before falling to 6.35 times in 2020. In India, the growth rate of embodied land increased from 30.98 times to 36.09 times, then dropped to 5.40 times. India saw the sharpest decline in the growth rate of wind related embodied land exports,

falling from 10.38 times in 2010 to 1.38 times in 2020. These shifts in the growth rates of embodied land imports and exports reflect a broader transition toward a more stable phase of development in both conventional and renewable energy generation.

# 3.3. Electricity-Driven Land Embodied in Trade Flows

Land areas of the top countries embodied in total trade during 2000 and 2020. Figure 4 reveals a structural asymmetry in global embodied land flows during this period. China accounted for $2 2 . 5 0 \%$ of total electricity-driven embodied land exports, with $2 2 . 5 8 \%$ from traditional energy and $2 2 . 3 1 \%$ from renewables. Meanwhile, the United States absorbed $1 5 . 8 3 \%$ of global embodied land imports, comprising $1 5 . 9 0 \%$ from traditional sources and $1 5 . 6 5 \%$ from renewables. From 2000 to 2020, the top two coal-related embodied land exporters shifted from China and the United States to China and India (Figure 4a,e). China’s share of coal power related embodied land exports dropped from $3 7 . 4 0 \%$ in 2000 to $3 1 . 7 3 \%$ in 2020. In 2020, China exported $5 . 2 6 \times 1 0 ^ { 3 }$ hectares of coal-related embodied land to the United States and $1 . 1 8 \times 1 0 ^ { 3 }$ hectares to Japan. India exported $7 . 4 8 \times 1 0 ^ { 2 }$ hectares to the United States and $1 . 9 3 \times 1 0 ^ { 2 }$ hectares to China. Compared to 2000, the embodied land flowing from China to the United States fell by $1 . 3 3 \times 1 0 ^ { 3 }$ hectares, and to Japan by $1 . 2 5 \times 1 0 ^ { 3 }$ hectares. In 2020, the largest embodied land importers shifted: Japan and the United States were replaced by China and the United States. During 2000 and 2020, the United States’ share of global coal-related embodied land imports decreased from $3 2 . 9 6 \%$ to $2 3 . 7 5 \%$ , while China’s share reached $1 0 . 1 8 \%$ in 2020. In 2020, China was the primary source of the United States’ embodied land imports, followed by Mexico with $9 . 2 5 \times 1 0 ^ { 2 }$ hectares. China’s primary sources were Japan with $5 . 0 1 \times 1 0 ^ { 2 }$ hectares and the United States with $4 . 8 5 \times 1 0 ^ { 2 }$ hectares.

![](images/078ff49a6a5dd198862221f45ee7760a6e0db3e1e866d8c7f7e7e12f5039f4d5.jpg)  
a

![](images/54bc66592765c7b5ca0e0ec343f2256161bdd1844acd824eb40fb435b0a45212.jpg)  
b

![](images/0daa427b1e7e3606625ce6df9b81d293d0a6ce4cea313091ea4798ef50593f12.jpg)  
c   
d

![](images/ccf42e263fc24b2128cdd399147837002450226d540c54359b64f4748ba9cc18.jpg)

![](images/6a1730d049df9a8a700c4b37ddcc98f72f24888d1d34e15d4d239da703fe04b8.jpg)  
e

![](images/0d1453c93eb23372934bead66b42c01c52b6b2778216d1d714b46ae5834c505a.jpg)  
f

![](images/d37749a4cdd8b1c4e7b5d7ed8c39d9b6b95d0dc52c05bf0c9e73dc3c3d391074.jpg)  
g   
h

![](images/78d734e25768ef55222eba2e47648b1e016ea06946e970ef72418decdddc8758.jpg)  
Figure 4. Flow of embodied land for different types of electricity across countries in 2000 and 2020. (a–d) show the embodied land trade for coal power (a), natural gas power (b), wind power (c), and PV power (d) in 2000, while (e–h) depict the embodied land trade for the four electricity generation types in 2020.

For natural gas, the United States and China consistently ranked as the largest exporters of embodied land from 2000 to 2020 (see Figure 4b,f). The United States’ share of global embodied land exports increased from $9 . 0 9 \%$ in 2000 to $1 0 . 4 2 \%$ in 2020, while

China’s share changed from $8 . 5 3 \%$ to $8 . 7 1 \%$ . Notably, in both 2000 and 2020, the United States and Japan were the primary destinations for China’s natural gas-related embodied land. Specifically, in 2000, China exported $5 . 2 3 \times 1 0 ^ { 2 }$ hectares of embodied land to the United States and $1 . 9 2 \times 1 0 ^ { 2 }$ hectares to Japan. By 2020, the embodied land flowing to the United States increased to $8 . 9 4 \times 1 0 ^ { 2 }$ hectares, while the flow to Japan decreased to $1 . 8 5 \times 1 0 ^ { 2 }$ hectares. In contrast, the leading destinations for the United States’ embodied land exports shifted from Japan and Mexico in 2000 to China and Canada in 2020. In that year, the United States exported $4 . 9 0 \times 1 0 ^ { 2 }$ hectares to Canada and $4 . 0 9 \times 1 0 ^ { 2 }$ hectares to China. Furthermore, the largest importers of embodied land shifted from the United States and Japan in 2000 to the United States and China in 2020. Throughout the period, China and Japan have consistently been the main sources of embodied land for the United States. In addition to the United States, China also imported $3 . 7 4 \times 1 0 ^ { 2 }$ hectares of embodied land from Japan in 2020.

In 2020, China and Germany were the largest exporters of embodied land for both wind and solar power (see Figure $^ { 4 \mathrm { g } , \mathrm { h } } ,$ , with exports of $4 . 1 8 \times 1 0 ^ { 3 }$ hectares and $2 . 6 2 \times 1 0 ^ { 3 }$ hectares of wind power, and $3 . 2 2 \times 1 0 ^ { 3 }$ hectares and $1 . 5 1 \times 1 0 ^ { 3 }$ hectares of solar power, respectively. The United States and China were the primary importers. The United States imported $4 . 3 2 \ \times \ 1 0 ^ { 3 }$ hectares from wind power and $3 . 2 7 \times 1 0 ^ { 3 }$ hectares from solar power. China imported $1 . 6 2 \times 1 0 ^ { 3 }$ hectares of wind-related embodied land and $1 . 3 3 \times 1 0 ^ { 3 }$ hectares of solar-related embodied land, which was less than half of the United States imports. China exported $1 . 4 5 \times 1 0 ^ { 3 }$ hectares from wind power and $1 . 1 1 \times 1 0 ^ { 3 }$ hectares from solar power to the United States, along with $3 . 2 4 \times 1 0 ^ { 2 }$ hectares from wind and $2 . 4 7 \times 1 0 ^ { 2 }$ hectares from solar to Japan. Germany sent $3 . 1 5 \times 1 0 ^ { 2 }$ hectares from wind power and $1 . 8 1 \times 1 0 ^ { 2 }$ hectares from solar power to the United States. Germany also sent $2 . 8 8 \times 1 0 ^ { 2 }$ hectares of wind- and $1 . 6 7 \times 1 0 ^ { 2 }$ hectares solar-related land exports to China. The United States imported $5 . 3 6 \times 1 0 ^ { 2 }$ hectares of wind power and $3 . 5 4 \times 1 0 ^ { 2 }$ hectares of solar power related land from Mexico. Meanwhile, China received $3 . 2 4 \times 1 0 ^ { 2 }$ hectares of wind power and $2 . 4 7 \times 1 0 ^ { 2 }$ hectares of solar power related land from Japan.

From Figure 4, China remained the leading exporter of renewable energy driven land use since 2000. By 2020, Germany had also emerged as a major exporter. Conversely, the United States and Japan have primarily acted as importers. Specifically, Japan emerged as the second-largest exporter of embodied land for solar power, exporting 2.92 hectares in 2000, following China. In that same year, China led with exports of 11.60 hectares of embodied land related to solar power and $5 . 2 2 \times 1 0 ^ { 2 }$ hectares of embodied land related to wind power. Additionally, Japan, rather than China, was the largest importer of embodied land for both wind and solar energy, alongside the United States. Japan imported $1 . 2 0 \times 1 0 ^ { 2 }$ hectares of wind related embodied land and 2.81 hectares of solar related embodied land, while the United States imported $3 . 9 9 \times 1 0 ^ { 2 }$ hectares of wind-related and 10.51 hectares of solar-related embodied land.

As shown in Figure 5, China’s imports and exports of coal related embodied land declined substantially between 2000 and 2020. During the same period, the share of wind and solar power in embodied land trade increased markedly (Figure 5a,b). In both 2000 and 2020, the primary destinations for China’s embodied land use in the electricity sector were the United States, Japan, Germany, and South Korea. The proportion to the United States remained relatively stable, decreasing slightly from $2 5 . 7 7 \%$ to $2 1 . 2 1 \%$ , Japan’s share falling from $1 4 . 8 6 \%$ to $6 . 4 7 \%$ , Germany’s share decreasing from $6 . 4 2 \%$ to $5 . 4 0 \%$ , and South Korea’s share increasing from $4 . 2 2 \%$ to $5 . 2 1 \%$ . Except for South Korea, the proportions of flow to India, Singapore, and Thailand all increased. India showed the largest gain, rising by $3 . 2 4 \%$ , not including the share attributed to the Rest of the World.

![](images/9049a8b033c60756bc40b0560976678163622115ad90871c476aa0df4ddb9527.jpg)  
a

![](images/b8284873ea83b3d6637aaba04c347a71a2c22e0bb0ae2953e937a81967832f42.jpg)

![](images/4a3eb7b86d3d1d2b791b8c80882100724ff444f623d11a33488a75da74780f3d.jpg)  
b

![](images/fadc9cc0fa6abdd53fe6cb163916e041c75c05f5f14367ef1845024a2e24ebad.jpg)

![](images/eeeb380a370d25be0881ba7a1df091f22fb980d4191eb2f839a80405f49eea36.jpg)  
C

![](images/d036aa0322757c309a297f15542502acb1956327d42f0f4c167d3909790eb88d.jpg)

![](images/db8f53105214684d4744d5c59d426d4f095121c2ca813a27696cd70ab1b913c4.jpg)  
d

![](images/a4225d16daab37ab2a2ecf458055a22b64cc40653a4bb45cd228d2996d1f6506.jpg)  
Figure 5. Sources and sinks of embodied land use in China and the United States. (a,b) represent the sources and sinks of embodied land use in China for the years 2000 and 2020, respectively; (c,d) show the sources and sinks of embodied land use in the United States for the years 2000 and 2020, respectively.

Between 2000 and 2020, China’s electricity-driven embodied land flows underwent a significant restructuring, with import dependencies increasingly shifting toward emerging economies in Asia. Trade linkages to India, Singapore, and Thailand are intensified, coinciding with Belt and Road energy infrastructure investments. Conversely, the proportion of land occupation embodied in trade between China and the United States, Japan, and the United Kingdom has declined. This reflects China’s weakening dependence on Western imports after 2010, as well as its strategic decoupling in key mineral supply chains. The main sources of embodied land use related to electricity for China were Japan, South Korea, the United States, and Germany. Japan’s share decreased by $3 . 9 6 \%$ , from $1 3 . 4 2 \%$ to $9 . 4 6 \%$ ; South Korea’s share slightly declined from $1 2 . 8 4 \%$ to $1 2 . 2 6 \%$ ; the United States’ share dropped from $1 1 . 2 7 \%$ to $9 . 5 9 \%$ , and Germany’s share increased by $0 . 4 8 \%$ , from $6 . 3 8 \%$ to $6 . 8 6 \%$ . The proportion of embodied land use related to electricity imported from Singapore saw the largest increase, rising by $1 . 9 3 \%$ .

In 2000, the primary destinations for the United States’ embodied land use were Canada $( 2 2 . 3 0 \% )$ , Mexico $( 1 3 . 7 7 \% )$ , Japan $( 1 1 . 2 9 \% )$ , and the United Kingdom $( 6 . 2 1 \% )$ ). By 2020, the major destinations had shifted to Canada $( 1 4 . 0 9 \% )$ , Mexico $( 1 3 . 5 3 \% )$ , China $( 1 1 . 6 4 \% )$ , and Japan $( 4 . 6 6 \% )$ . Aside from China, exports of embodied land to India and Thailand also increased, by $1 . 5 6 \%$ and $0 . 1 2 \%$ , respectively. In terms of imports, the main sources of the United States’ embodied land use in 2000 were China $( 2 9 . 3 0 \% )$ ), Canada $( 1 4 . 6 7 \% )$ ), Mexico $( 5 . 9 8 \% )$ , and Japan $( 5 . 8 0 \% )$ ). By 2020, India $( 5 . 2 5 \% )$ ) had surpassed Japan $( 4 . 2 9 \% )$ to become the fourth-largest source of embodied land use for the United States. Over these two decades, the share of embodied land use imported from India, Mexico, and Thailand to the United States increased, with Mexico showing the largest increase, rising by $5 . 8 1 \%$ .

# 3.4. Sectoral Structures of Electricity-Driven Land Use Changes

This study further investigates the sectoral structures of electricity-driven embodied land use from production and consumption perspectives. The results, as shown in Figure 6, reveal that, regardless of the country, the primary sources are household final consumption, government final consumption, and gross fixed capital formation. From Figure 6a, for coal-fired power, the household final consumption is the leading contributor to embodied

land use in coal power across all countries, accounting for more than $4 3 . 3 7 \%$ . South Korea stands out with the highest impact, where household final consumption reached $6 6 . 9 1 \%$ . In France and Italy, government final consumption was the second-largest source, accounting for $2 4 . 8 2 \%$ and $1 8 . 9 8 \%$ , respectively. This indicates that the public sector plays a key role in electricity-driven embodied land use, likely due to government-led demand for public projects and services. In other countries, gross fixed capital formation was the second major source, with contributions exceeding $1 5 . 2 9 \%$ . The influence of other factors in these countries generally remained below $1 1 . 0 3 \%$ .

![](images/6e7e07bef87297b60282dc586f3c8e8477dd4d94ecf3010d07accc12ba0152ed.jpg)

![](images/1f3094f06ee021a8c196d431e3352a6564e44ad629059abc759259f983e1bc4c.jpg)

![](images/4f9cb7a4c2ce107a15af63a4a1d6e50460c164627e889c77282befbd5a931ecb.jpg)

![](images/8c48bcf82ef0f7758126621d783aade3f4441064ebd09e5de505401e42749320.jpg)

![](images/ce6e7c24a023157caa82a584b311207a8cfa7d6b73e753d5d2cf89885efe4ee8.jpg)

![](images/ba3793d4cdf757c8ba7dfd8f5e23790c3439d113298f10d5a22f70e8bb61a9fe.jpg)

![](images/932fe134cf4de0f448e6e62e87312ca971d21efb6a4f0eeb792096d2c518f99e.jpg)

![](images/9cb009c594d799245f5e45bc6d6a52599f6520792956b9b5fa41b24dd47998e5.jpg)  
Figure 6. Sectoral structures of electricity-driven embodied land use. (a) presents embodied land use from the consumption perspective; (b) shows the relative differences across consumption-based sectors between 2000 and 2020. Abbreviations P.3h to P.53 sequentially represent Household final consumption, Non-profit institutions serving households, Government final consumption, Gross fixed capital formation, Changes in inventories, and Acquisitions less disposals of valuables.

For natural gas related embodied land, the situation is similar to that of coal power. However, in China, gross fixed capital formation emerges as the primary source, accounting for $4 4 . 8 8 \%$ , followed by household final consumption at $3 7 . 7 6 \%$ . This indicates that, in China, capital investments in infrastructure and related sectors were significant contributors to embodied land use for gas-fired power generation. In the Netherlands, government final consumption was the second-largest source $( 1 8 . 0 6 \% )$ ), while in Italy, gross fixed capital formation takes this position $( 1 3 . 2 5 \% )$ .

For wind and solar related embodied land use, household final consumption remained the largest contributing factor in all countries, followed by gross fixed capital formation, except in France and the Netherlands. Notably, in the countries other than China, household final consumption exhibtated a significantly greater impact than other factors, accounting for more than $5 2 . 1 1 \%$ , which underscores its dominant role. In China, household final consumption and gross fixed capital formation contributed almost equally, each accounting for around $4 0 \%$ . This suggests that while household consumption was the primary source of embodied land use in electricity generation in most countries, in China, both household consumption and capital investment played equally significant roles. This distinction highlights the more balanced influence of infrastructure development and individual consumption patterns on the embodied land use associated with China’s energy production.

Figure 6b illustrates the changes in impact across final demand categories from 2000 to 2020. For coal power related embodied land use, China, India, and South Korea were the only countries to experience consistent positive growth across all sectors, while other countries showed negative growth in various sectors. In the United States and the United Kingdom, all sectors saw negative growth except for acquisitions less disposals of valuables, which grew by $1 1 . 6 8 \%$ and $1 8 . 4 8 \%$ , respectively. In France and the Netherlands, all sectors experienced positive growth except for non-profit households, which declined to $- 0 . 2 0$ and $- 0 . 9 4$ times, respectively. In Germany, the household final consumption $( - 5 1 . 1 6 \% )$ , nonprofit households $( - 5 2 . 1 1 \% )$ , and the gross fixed capital formation $\left( - 7 . 5 8 \% \right)$ ) all showed negative growth. In Japan, only non-profit households $( 4 . 2 8 \% )$ and changes in inventories (1.38 times) experienced growth. In Italy, gross fixed capital formation decreased by $1 6 . 8 0 \%$ and acquisitions less disposals of valuables fell by $4 7 . 3 7 \%$ , while the other sectors saw positive growth.

The situation for the traditional and renewable driven embodied land use differs significantly. For natural gas related embodied land use, only a few countries experience sector-specific negative growth. Notably, non-profit households in France, the United Kingdom, and the Netherlands declined by $4 6 . 0 8 \%$ , $6 3 . 0 8 \%$ , and $- 0 . 3 0$ times, respectively. Additionally, the changes in inventories in Germany $( - 8 6 . 6 2 \% )$ and acquisitions less disposals of valuables in Japan $( - 6 6 . 2 7 \% )$ also decreased. Meanwhile, China showed the largest growth across nearly all sectors, except for changes in inventories. For wind and solar power related embodied land, the outlook is more optimistic, with over $8 0 \%$ growth in all six sectors across the ten countries.

# 4. Discussion and Policy Implications

This study examines changes in both direct and embodied land use associated with traditional and renewable electricity generation from 2000 to 2020, incorporating cross-country comparisons of the electricity-driven embodied land use. Between 2010 and 2020, the embodied land flows associated with wind and solar power grew more rapidly than those associated with fossil fuel driven energy systems. The land footprint of renewable energy increased by approximately $9 0 \%$ , three times the rate of that of traditional energy systems. Regarding national contributions, China supplied $2 . 0 3 \times 1 0 ^ { 4 }$ hectares of coal power related embodied land and $1 . 1 5 \times 1 0 ^ { 2 }$ hectares of wind power related embodied land for the final consumption in other countries. India provided $3 . 0 5 \times 1 0 ^ { 3 }$ hectares of embodied land linked to coal power. Conversely, the United States relied on international supply chains for $2 . 1 4 \times 1 0 ^ { 4 }$ hectares of wind power and $1 . 7 2 \times 1 0 ^ { 4 }$ hectares of solar power related embodied land to satisfy its consumption demand. China and Germany dominated wind and solar power related land exports, accounting for $3 2 . 4 2 \%$ of the global share. Meanwhile, China and India together accounted for $2 8 . 5 0 \%$ of the coal power related land transfers. Simultaneously, Germany solidified its role as Europe’s renewable land-export hub, commanding $1 2 . 6 5 \%$ of wind and $1 0 . 1 6 \%$ of solar power related land transfers, a regional complement to China’s global ascendancy. Additionally, China’s South–South trade captured emerging markets through targeted exports to India, Singapore and Thailand.

Based on the findings above, it is conclusively established that a global phenomenon exists, whereby land resource consumption driven by domestic demand is transferred to other countries through trade channels. This externalization of resource pressures has significantly adverse effects on both source and recipient countries. For recipient countries, land resource demands driven by foreign final consumption may trigger a series of cascading crises in natural and socioeconomic systems. Specifically, to meet land demands embodied in export trade, these countries may face increased desertification,

biodiversity loss, soil erosion, and large-scale encroachment on farmland. Consequently, they are likely to experience environmental governance costs, increased food security risks, and potentially aggravated social conflicts and governance challenges. For source countries, although the short-term transfer of resource pressures reduces domestic ecological burdens, the long-term reliance on external resource supplies leads to dependence on the stability of land resource provision from other nations to meet their final demand, creating strategic vulnerabilities. Such dependency not only entails the risks of supply chain disruption but may also undermine national resource sovereignty, thereby affecting long-term ecological security and economic resilience.

The transfer of land resource consumption worldwide is driven by multidimensional and systemic factors. Generally, environmental costs arising from resource extraction and environmental pollution are not fully internalized in commodity prices, resulting in uncom pensated ecological losses in countries exporting embodied land resources. Many bilateral trade agreements and international investment frameworks prioritize market accesses and economic gains over binding cross-border environmental accountability, indirectly exacerbating the resource pressure spillover. Moreover, existing international regimes lack clear transboundary mechanisms for holding accountable the countries that consume resources, making it difficult to assign compensation or remediation responsibilities to these countries for ecological damage abroad. The narrow emphasis of the current international sustainability agenda on carbon reduction also drove a rapid shift toward renewable energy sources, without adequate consideration of the electricity-driven embodied land use implications. This oversight has intensified the environmental pressure on resource-supplying countries. At the national level, consuming countries obscure the full land footprint embodied in imported goods, making it difficult for consumers and businesses to recognize the impact of their consumption on ecosystems abroad. Additionally, technologies for enhancing resource efficiency remain either underdeveloped or cost prohibitive in some countries. Consequently, continued reliance on the embodied land in imported goods may appear economically rational in the short term.

Addressing the challenges of the energy–land nexus system requires integrated, multiscalar governance frameworks that explicitly rectify the externalization of land pressures embodied in the global supply chains. It is essential to establish transparent transboundary accounting of embodied land flows and compensatory mechanisms, whereby importing countries provide financial remediation to exporting nations for habitat degradation and agricultural displacement caused by renewable material extraction. International institutions need to harmonize the mandatory ecological redlines for renewable energy projects to prevent deforestation and farmland conversion, ensuring that energy transitions do not undermine global food security or biodiversity conservation. At the regional level, developed economies should promote technological justice through cooperative ventures, such as donor-financed high-efficiency photovoltaic installations and grid modernization in land-vulnerable countries. Such partnerships can overcome technological barriers and reduce asymmetrical burdens on resource-supplying areas. Governments need to accelerate the research, development, and deployment of land-sparing technologies, such as perovskite solar panels, agrivoltaics, and offshore wind clusters. These technologies can drastically decouple renewable energy generation from terrestrial land use. Policies could also incentivize circular design in solar and wind infrastructure to reduce the primary material demand and slow the rate of resource extraction. This integrated governance paradigm not only advances the sustainable management of telecoupled socio-ecological systems but also directly addresses the inequitable socio-environmental costs imposed on developing economies under current energy transition pathways.

# 5. Conclusions

This study integrated the telecoupling theory with multi-regional analysis to map global electricity-driven land appropriation. To our knowledge, this represents systematic comparisons of the growth rates and transnational flows of embodied land occupation driven by different energy sources, overcoming the limitations of LCA’s inconsistent metrics and MRIO’s lack of sector-specific embodied land flow analysis. Key findings reveal that embodied land use for renewable energy, $5 6 . 3 3 \%$ lower than that of conventional sources, grew 2.18 times faster, signaling impending land demand thresholds. China has emerged as the nexus of energy–land telecoupling, supplying $2 0 . 8 1 \%$ of global wind and solar land exports and $3 1 . 7 5 \%$ of coal-related flows, with its South–South trade share tripling since 2000. Final consumption and capital formation accounted for $8 2 . 9 2 \%$ of the transnational land transfers, highlighting the embedded ecological liabilities of economic growth models. While wind and solar resource heterogeneity introduce spatial variability in land coefficients, the framework identifies critical pressure points, and land-exporting regions face compounded stresses. This study had two primary limitations. First, the analysis focused on representative conventional and renewable energy sources, omitting other critical sources such as hydropower and nuclear generation, which exhibit distinct land use patterns. Second, spatial variations in geographical contexts, natural resource endowments, and technological capacities across countries are largely disregarded. Future research could leverage the land use impacts of the energy transition by utilizing more granular electricity–land intensity coefficients at both the national and municipal levels. By integrating renewable power infrastructures and land use occupation, the analytical framework developed in this study aims to advance the understanding of energy–land nexus dynamics, providing a theoretical foundation for cross-system governance in the pursuit of carbon neutrality.

Author Contributions: Conceptualization, X.L. and M.H.; methodology, X.L., M.Y.G. and C.L.; formal analysis, X.L.; visualization, X.L.; writing—original draft preparation, X.L., Y.L., and Y.F.; writing— review and editing, M.H.; supervision, M.H., Z.L. and G.C. All authors have read and agreed to the published version of the manuscript.

Funding: This research was funded by the National Social Science Fund of China (grant no. 22CJY020).

Data Availability Statement: The electricity generation data from 2000 to 2020 for 189 countries/economies worldwide were sourced from the International Energy Agency (IEA) database https://www.iea.org/ (accessed on 19 August 2025), and the trade data for countries around the world from 2000 to 2020 were obtained from the Eora database https://worldmrio.com/eora26/ (accessed on 1 September 2025).

Conflicts of Interest: The authors declare that they have no conflicts of interest related to this study.

