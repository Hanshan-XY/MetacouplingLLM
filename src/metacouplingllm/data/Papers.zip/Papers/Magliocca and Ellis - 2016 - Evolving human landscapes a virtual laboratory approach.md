# Evolving human landscapes a virtual laboratory approach

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:57:44.323273+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Magliocca and Ellis - 2016 - Evolving human landscapes a virtual laboratory approach.pdf
- Year: unknown
- DOI: 10.1080/1747423X.2016.1241314
- OA status: closed
- License: none recorded
- Category: Journal Articles\Conceptual\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This conceptual article proposes an agent-based virtual laboratory (ABVL) for studying how human societies and landscapes coevolve over millennia. The work is global and long-term in scope, not focused on a single region. It is situated within land system science, social-ecological systems, and coupled human-natural systems research, and explicitly links to telecoupling by treating human societies as a global, evolving system that redistributes flows of energy, materials, biota, and information across space and time.

The authors build on anthroecology and sociocultural niche construction theory, which view human groups as modifying environments while inheriting cultural practices, ecological conditions, and material infrastructure. These inheritances affect adaptive success and are shaped by natural, cultural, and artificial selection. The paper distinguishes slowly changing, structural dynamics of a global human climate from short-term local human weather.

Methodologically, the ABVL is a generalized agent-based modeling framework. Agents represent households embedded in landscapes composed of patches with biophysical constraints and resources. Agents possess traits related to livelihood strategies, cooperation, aspirations, risk preferences, and social networks. They make annual decisions about land use and non-land-based activities, learn from experience and peers, form or join social groups, compete for land, reproduce, and transmit traits. Ecological processes such as degradation and regeneration are simplified but spatially explicit.

A key innovation is the building-block approach: sociocultural processes (aspiration formation, risk perception, land allocation, social norm formation, network influence) are modular, each with multiple complexity levels. Different combinations of these blocks are hypothesized to generate distinct cultural-landscape configurations, such as cooperative mosaic agriculture or market-driven extensification. Model evaluation relies on pattern-oriented modeling and hierarchical genetic algorithms to search across process combinations and parameter values.

The paper is not an empirical telecoupling case study but provides a theory-driven framework that can represent multi-scalar interactions among societies and environments, thereby supporting metacoupling analyses (within-system, adjacent, and distant couplings) when appropriately configured and calibrated.

## Structured Metacoupling Extraction

### Coupling Classification
- Conceptual and modeling paper on intra- and telecoupled human-environment systems via anthroecology and ABMs.

### Intracoupling
#### Systems
- Anthroecosystems linking a single society with its local landscapes and ecosystems.
- Agent-based representations of households managing land within one regional landscape.
- Household social groups shaping local resource use and land tenure institutions.
#### Flows
- Local flows of food, biomass, and livestock between land patches and households.
- Circulation of cultural, material, and ecological inheritances within one society.
- Intra-landscape movements of labor, information, and cooperative support.
#### Agents
- Household agents representing small kin-based units or farming households.
- Social groups and networks regulating norms, cooperation, and sanctions.
- Local authorities or elites mediating land allocation and conflict.
#### Causes
- Sociocultural niche construction processes shaping local land-use strategies.
- Household aspirations, risk preferences, and livelihood choices.
- Biophysical constraints such as soils, slope, water, and climate suitability.
#### Effects
- Formation of anthromes and fine-scale land-use mosaics within biomes.
- Local soil degradation or regeneration from extensive versus intensive practices.
- Changes in household welfare, inequality, and livelihood diversification.

### Pericoupling
#### Systems
- Neighboring villages or groups interacting over land and resources.
- Regional market centers connected to surrounding rural landscapes.
- Conflict-affected refugia landscapes adjacent to war zones.
#### Flows
- Short-distance migration of households escaping conflict or seeking land.
- Regional trade in crops, livestock, and inputs such as fertilizer and tools.
- Diffusion of land-use innovations and social norms through nearby networks.
#### Agents
- Neighboring social groups engaging in competition or cooperation.
- Regional traders and market intermediaries.
- Local government or customary institutions arbitrating land disputes.
#### Causes
- Proximity-based market access and travel time costs.
- Regional conflicts altering settlement and cooperation patterns.
- Competition for fertile or accessible land among adjacent groups.
#### Effects
- Patchy forest-agriculture mosaics across regional landscapes.
- Emergence of land conflicts and negotiated tenure boundaries.
- Spatial clustering of cooperative versus market-oriented communities.

### Telecoupling
#### Systems
- Global human climate system linking diverse societies and biomes.
- Remote policy centers influencing distant agrarian communities.
- Distant markets connected to local producers via trade networks.
#### Flows
- Long-distance flows of materials, energy, species, and information among societies.
- Transmission of cultural traits, technologies, and institutions across regions.
- Policy and economic signals such as subsidy removal or liberalization reforms.
#### Agents
- States and international actors shaping agricultural and economic policy.
- Global corporations and commodity chains influencing land-use incentives.
- Transregional knowledge networks spreading farming and livelihood innovations.
#### Causes
- Macroeconomic reforms and globalization reshaping rural incentives.
- Long-term expansion and scaling of human societies and infrastructure.
- Cross-biome diffusion of sociocultural niche construction strategies.
#### Effects
- Global spread and intensification of anthropogenic biomes across Earths land.
- Synchronization of land-use transitions across distant regions.
- Teleconnected vulnerabilities and feedbacks in coupled human-natural systems.

### Cross-Coupling Interactions
- Local anthroecosystem changes accumulate into global human climate dynamics.
- Telecoupled policies reshape regional markets, altering village-level land-use decisions.
- Social networks bridge local groups and distant opportunities, redirecting migration and livelihoods.

### Research Gaps or Limitations
- Full 50,000-year global ABVL implementation remains conceptual and not yet realized.
- Balancing generality, realism, and complexity in building-block processes is unresolved.
- Equifinality risks persist despite pattern-oriented modeling and genetic algorithms.

### Search Keywords
- anthroecology sociocultural niche construction agent-based virtual laboratory
- coupled human natural systems telecoupling land system science
- social norms cooperation land allocation building-block processes

### Extraction Confidence
high
