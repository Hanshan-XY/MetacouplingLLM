ARTICLE

https://doi.org/10.1038/s41467-020-19520-3

OPEN

![](images/f26e71b4b90fe2ae54424eabe1c05951d3f9909c48ce7f59b38a2d4f6c34d83a.jpg)

Check for updates

# Impacts of irrigated agriculture on food–energy–water–CO2 nexus across metacoupled systems

Zhenci $\mathsf { X } \mathsf { u } ^ { 1 , 2 , 5 }$ , Xiuzhi Chen 3,5, Jianguo Liu 1 ✉, Yu Zhang 3,4, Sophia Chau 1 , Nishan Bhattarai 2, Ye Wang3, Yingjie Li1 , Thomas Connor1 & Yunkai Li 3✉

Irrigated agriculture has important implications for achieving the United Nations Sustainable Development Goals. However, there is a lack of systematic and quantitative analyses of its impacts on food–energy–water– $C 0 _ { 2 }$ nexus. Here we studied impacts of irrigated agriculture on food–energy–water– $\cdot { \mathsf { C O } } _ { 2 }$ nexus across food sending systems (the North China Plain (NCP)), food receiving systems (the rest of China) and spillover systems (Hubei Province, affected by interactions between sending and receiving systems), using life cycle assessment, model scenarios, and the framework of metacoupling (socioeconomic-environmental interactions within and across borders). Results indicated that food supply from the NCP promoted food sustainability in the rest of China, but the NCP consumed over four times more water than its total annual renewable water, with large variations in food–energy–water– $\cdot { \mathsf { C O } } _ { 2 }$ nexus across counties. Although Hubei Province was seldom directly involved in the food trade, it experienced substantial losses in water and land due to the construction of the South-to-North Water Transfer Project which aims to alleviate water shortages in the NCP. This study suggests the need to understand impacts of agriculture on food–energy–water– $\cdot { \mathsf { C O } } _ { 2 }$ nexus in other parts of the world to achieve global sustainability.

nsuring food security for a growing global population under resource constraints is one of the biggest global challenges1. Food production can also contribute to other global challenges, such as water scarcity, global warming, and pollution since food production consumes large amounts of water, energy and fertilizers and causes environmental burdens. Food, water, and energy provide a foundation for environmental and socioeconomic development. Global challenges, such as food insecurity, energy crises, water insecurity and global warming threatens sustainability in many regions worldwide2–4. The United Nations, therefore, recommended the 17 Sustainable Development Goals, such as achieving zero hunger, clean water, sustainable energy, and combatting climate change to transform our world5,6.

Food, energy, water, and $\mathrm { C O } _ { 2 }$ emissions are highly interconnected, which is called a nexus relationship7–13. For example, water is used to produce food and energy (e.g., irrigation, hydropower, and bioenergy crop)14, and in turn, energy is required to pump and distribute water and produce food (e.g., water diversion projects, desalination, and irrigating)15,16. All of these processes generate $\mathrm { C O } _ { 2 }$ emissions.

A growing body of research has explored the environmental impacts of food production and trade16–21. The environmental impacts of irrigated agriculture are particularly profound22,23 and the area of irrigated agriculture for domestic consumption and international trade is increasing globally24,25. However, there is a lack of systematic and quantitative analyses of irrigated agriculture’s impacts on food–energy–water– $\mathbf { \cdot } \mathbf { C } \mathbf { O } _ { 2 }$ nexus across the agriculture and other areas simultaneously in the context of complex environmental and socioeconomic factors.

To address this important knowledge gap, we performed such analyses associated with food sustainability in China across food sending systems [the North China Plain (NCP), China’s major food production region with irrigated agriculture), food receiving systems (the rest of China) and spillover systems (Hubei Province, areas that are affected by interactions between sending and receiving systems) in the context of complex environmental and socioeconomic factors (e.g., climate change, diet change, irrigation technologies, crop planting strategies, and water diversion). The analyses were guided by the framework of metacoupling [environmental and socioeconomic interactions within and across borders17]. The metacoupling framework helps understand interrelationships among sending, receiving, and spillover systems that are connected by various flows (e.g., food trade and water transfer)26–29. It also suggests that the effects on spillover systems are largely ignored30,31, leaving an incomplete understanding of the environmental consequences of food production2,21,30,32. Assessing spillover effects can reveal the hidden environmental costs of food production and trade that can escalate local problems to national or even global catastrophes33.

China is the largest developing country in the world in terms of human population and faces many environmental challenges, including water scarcity, energy crisis, and intensive $\mathrm { C O } _ { 2 }$ emissions under rapid population growth and economic development34–37. Ensuring food security while safeguarding the environment is, therefore, one of the greatest challenges for China and the rest of the world today. The NCP is China’s agricultural base and main producer of crops38, which provides approximate half of the national wheat and maize supply while consuming substantial water and energy and emitting $\mathrm { C O } _ { 2 }$ . Much of the food produced in the NCP is transferred to other regions throughout China. The NCP and other regions thus interact through the food trade between northern and southern China and food trade between central and western China39,40. Wheat and maize produced in the NCP take up to $9 5 \%$ of the agricultural land area in the region and comprise approximately $5 0 \%$ of China’s total

wheat and maize production38,41. The government plans to apply water-conserving irrigation technologies in the NCP to alleviate water shortages and maintain crop yields42. To further reduce water pressure and support local industry and agriculture development in the NCP, the Chinese government implemented the South-to-North Water Transfer Project (SNWTP) to transport water from southern to northern China. The Middle Route has already been constructed. In this study, we focused on the Middle Route connecting Hubei Province and the $\mathrm { N C P } ^ { 4 3 }$ . The SNWTP diverts water from Hubei Province (which receives little wheat and maize from the $\mathrm { N C P ^ { 1 9 } }$ ) to the $\mathrm { N C P ^ { 4 4 , 4 5 } }$ . Assessing the relationships between environmental impacts related to food, water, energy, and $\mathrm { C O } _ { 2 }$ emissions in different areas involved in food production, trade, and consumption can provide valuable information for managing sustainable food trade and environmental conservation across many regions of the world.

In this study, we addressed the following questions: (1) What crop production, energy footprint, water footprint, $\mathrm { C O } _ { 2 }$ emissions, water and food sustainability are attributed to irrigated agriculture across the NCP? (2) What are the impacts of various environmental and socioeconomic factors (e.g., climate change, diet change, irrigation technologies, crop planting strategies, and water diversion) on the food–energy–water– $\mathbf { \cdot } \mathbf { C } \mathbf { O } _ { 2 }$ (FEWC) nexus in the NCP? (3) What are the impacts of irrigated agriculture in the NCP on spillover systems (e.g., Hubei Province, Middle Route of the SNWTP). To answer these questions, we collected various kinds of data and employed life-cycle assessment. We also constructed 15 scenarios (Table 1) to simulate impacts of various factors on FEWC outcomes (Supplementary Table 1). We used the ratio of the total available water for agricultural use to the total water consumption of irrigated agriculture as an indicator for water sustainability (see details in “Methods”). The sustainable food supply indicator is set as the ratio of the actual amount of crop production to the sustainable amount of crop production for ensuring national food security in the rest of China (see details in “Methods”). Based on results from the analyses and simulations, we discuss the implications for solving potential environmental woes of resource consumption in the NCP (Supplementary Table 2). Results showed that food supply from the NCP enhanced food sustainability in the rest of China, but the NCP consumed over four times more water than its total annual renewable water. Under different scenarios with a combination of environmental and socioeconomic factors, the food–energywater– $\mathrm { . C O } _ { 2 }$ nexus varied widely across counties in the NCP. Furthermore, the spillover systems also suffered large environmental impacts, such as land and water losses.

# Results

Environmental impacts in North China Plain. Surprisingly, all evaluated counties in the food sending system of the NCP had unsustainable water use due to irrigated agriculture (Figs. 1–3). However, crop production in the NCP fulfilled its share of responsibility for food sustainability in the rest of China. Total water consumption for irrigated agriculture in the NCP in 2010 was over four times the amount of renewable water available to the region for agriculture (inverse of water sustainability index, calculated as 1/0.23) (Supplementary Table 1). Irrigated agriculture in the NCP itself also consumed a large amount of energy and produced significant $\mathrm { C O } _ { 2 }$ emissions (Figs. 1–3 and Supplementary Fig. 1; Supplementary Table 1).

Environmental impacts under model scenarios. The water footprint, energy footprint, carbon footprint, crop yield, and water and sustainability indicators for the NCP varied widely under different scenarios (Fig. 2). The top three scenarios with the

Table 1 Scenario settings for irrigated agriculture in the North China Plain.   

<table><tr><td>Name</td><td>Scenarios</td><td>Settings</td></tr><tr><td>Baseline</td><td>Actual situation in 2010</td><td>Average temperature 13.1 °C, precipitation 454 mm, concentrations of CO2 421.5 umol/mol, Double cropping system (winter wheat - summer maize rotation), Border irrigation, irrigated 4 times during growth period in normal flow years, 164.7 kg/y for grain intake, 9.5 billion m3/year water delivered through the Middle Route of the SNWTP</td></tr><tr><td>S1</td><td>Climate change for 2030</td><td>Based on Baseline, the average temperature changed to 14.3 °C, concentrations of CO2 changed to 491.5 umol/mol</td></tr><tr><td>S2</td><td>Reduced irrigation frequency in normal flow years</td><td>Based on S1, irrigated 2 times during growth period in normal flow years</td></tr><tr><td>S3</td><td>Rain-fed crops in high flow years</td><td>Based on S1, no irrigation occurred in high flow years</td></tr><tr><td>S4</td><td>Reduced irrigation frequency in low flow years</td><td>Based on S1, irrigated 3 times during growth period in low flow years</td></tr><tr><td>S5</td><td>Upgraded to drip irrigation</td><td>Based on S1, irrigation methods changed to drip irrigation</td></tr><tr><td>S6</td><td>Upgraded to sprinkler irrigation</td><td>Based on S1, irrigation methods changed to sprinkler irrigation</td></tr><tr><td>S7</td><td>Reduced irrigation and changed cropping system</td><td>Based on S2, cropping system changed to winter wheat - summer maize - spring maize</td></tr><tr><td>S8</td><td>Upgraded to drip irrigation and change cropping system</td><td>Based on S7, Irrigation methods changed to drip irrigation</td></tr><tr><td>S9</td><td>Upgraded to sprinkler irrigation and changed cropping system</td><td>Based on S7, Irrigation methods changed to sprinkler irrigation</td></tr><tr><td>S10</td><td>Diet change recommended by FAO A</td><td>Based on S1, 164.7 kg/y changed to 127.8 kg/y for grain intake</td></tr><tr><td>S11</td><td>Diet change recommended by FAO B</td><td>Based on S1, 164.7 kg/y changed to 94.0 kg/y for grain intake</td></tr><tr><td>S12</td><td>Diet change recommended by FAO C</td><td>Based on S1, 164.7 kg/y changed to 75.0 kg/y for grain intake</td></tr><tr><td>S13</td><td>Increased SNWTP water delivered</td><td>Based on S1, increased water delivered to 11.8 billion m3</td></tr><tr><td>S14</td><td>Increased SNWTP water delivered to maximum</td><td>Based on S1, increased water delivered to 14.1 billion m3</td></tr><tr><td>S15</td><td>Increased SNWTP water delivered to the maximum with diet changed and irrigation upgraded</td><td>Based on S8 + S12 + S14</td></tr></table>

![](images/cb6b37284327851d19df1a449ca4ee7e7cdc80ece8c943cdee61cbdbc29c00e2.jpg)  
Fig. 1 Metacoupling processes and associated environmental impacts. This Figure shows environmental impacts across the associated food sending system [North China Plain (NCP)], spillover system (Hubei Province), and receiving system (the rest of China). Note: An index value greater than 1 indicates sustainable food supply from the NCP or water use in the NCP. Only irrigation water use is considered in the NCP. The 9.5 billion $\mathsf { m } ^ { 3 } .$ /year water is the total water diverted by the South-to-North Water Transfer Project and $2 2 \%$ of the water went toward agricultural use in the ${ \mathsf { N C P } } ^ { 8 9 }$ . In other words, Hubei Province lost 9.5 billion $m ^ { 3 }$ of water annually. The data for the base map was derived from the Resource and Environment Science and Data Center (http://www.resdc.cn/) which is publicly available. The boundary of the North China Plain and the route of the South-to-North Water Diversion Project were created by the authors (via ArcGIS version 10.1, ESRI).

![](images/b21a17d6426fe6512b2e99687c4aedfa67f2597e7508bd11bed60c1f54fb6e49.jpg)

![](images/fc874ed4bb5a8b596ad6f28741eca841f36363590c179f2f3e7f998701c52717.jpg)

![](images/ba19b85704ba0131d4e327120668d3a9f11dbb7e95e57a28332b05d5731518b8.jpg)

![](images/23b043793305f0098998ce301e397a8a45a1ff99d48df10c2798033d9e6c858c.jpg)

![](images/318026569ebd1ea8f8b7c2d3db8acf16d88ef14f9eb8c6a9e15a05ae0d3a2a91.jpg)

![](images/349bd91fd05bc5610c3e4f8cdde1d17b134b7ebc311d57d6c10ac79e1598729f.jpg)  
Fig. 2 Environmental impacts in North China Plain under model scenarios. a Water footprint, b energy footprint, c carbon footprint, d crop yield, e water sustainability, and f food sustainability for irrigated agriculture in the North China Plain under scenarios S1–S15. Data are provided in the Source data file.

least water footprint (in descending order) include S11 (diet change B: $1 6 4 . 7 \mathrm { k g / y }$ changed to $9 4 . 0 \mathrm { k g / y }$ for grain intake), S15 (maximum water transfer plus diet change C), and S12 (diet change C: $1 6 4 . 7 \mathrm { k g / y }$ changed to $7 5 . 0 \mathrm { k g / y }$ for grain intake), while the bottom three (or the largest water footprint) include S1 (climate change), S2 (climate change plus reduced irrigation frequency in normal flow years), and S4 (climate change plus reduced irrigation frequency in low flow years), respectively (see details about the scenarios in Table 1). The top three scenarios for the least water footprints (i.e., S11, S15, and S12) were also ranked among the top three in terms of the lowest energy, and carbon footprints. S11 and S12, however, were among those with the lowest water and food sustainability. This is largely due to the lower crop yield associated with these scenarios (i.e., two of the bottom three lowest yield scenarios). The highest yield (and highest food sustainability) came from scenarios S5 (upgraded to drip irrigation), S6 (upgraded to sprinkler irrigation), and S8 (upgraded to drip irrigation and changed the cropping system).

However, two of these three (i.e., S5 and S6) were among the ones with the highest energy and carbon footprints. These rankings of scenarios show that crop yield was driven by greater consumption of energy and water and not necessarily in a sustainable way. Overall, results indicate that water sustainability may not be guaranteed under 11 out of 15 scenarios [i.e., S1–10 and S13 (increased water delivered)]. Similarly, food sustainability may not be ensured under seven out of 15 scenarios [i.e., S2–4, S7 (reduced irrigation and changed cropping system), S10–12)]. Among the 15 scenarios, only two could achieve both water and food sustainability while at least water or food sustainability could not be achieved in the remaining scenarios.

There were large spatial variations in environmental consequences in the NCP (Fig. 3). Water sustainability appeared to have a decreasing pattern toward the south with the exception of few counties in the northwest. On the other hand, the water footprint, carbon footprint, and energy footprint show widespread heterogeneity across the counties. The variations in FEWC

![](images/92ec56f21699642ca369fb52c29e6d4fa3b7087c5f6545769a2a948cc03393fe.jpg)

![](images/b86c4a9f09df7d20a9f606e3ed18d11bb32d9540af8813404bd85c350e65c599.jpg)

![](images/6ec1dcb72bf41357ce8d8069912a1c69db508d436fee9108f6d18ae1777e2b2f.jpg)

![](images/85d77411cff88db7cc2993b5c3b0539b34212836e4e38d7b931c24f2ae0b19f4.jpg)  
Fig. 3 Spatial dynamics of environmental impacts in the North China Plain. a Water footprint, b energy footprint, c carbon footprint and d water sustainability in irrigated agriculture of the North China Plain. The data for the base map was derived from the Resource and Environment Science and Data Center (http://www.resdc.cn/) which is public available. The boundary of the North China Plain was created by the authors (via ArcGIS version 10.1, ESRI). Data are provided in the Source data file.

outcomes across counties seemed to be consistent with the heterogeneity in agricultural production, industrialization, farming practices, water utilization, among others. Across the 15 scenarios, there were also strong spatial differences in environmental impacts among counties of the NCP (Supplementary Figs. 2–5).

Spillover effects. Spillover systems influenced by food trade absorbed substantial environmental burdens. For instance, Hubei Province, which is not directly involved in food trade with the NCP, lost significant amounts of land and water due to the construction and operation of the SNWTP (Fig. 1), which was installed partially to alleviate water scarcity in the NCP. Annually, the SNWTP diverts 9.5 billion $\mathrm { m } ^ { 3 }$ of water from Hubei Province

to northern China, of which 2.1 billion $\mathrm { m } ^ { 3 }$ goes to agricultural use in the NCP. The SNWTP also occupies $3 1 \mathrm { 0 } \mathrm { k m } ^ { 2 }$ of land in Hubei Province. There were $1 4 9 . 3 \mathrm { k m } ^ { 2 }$ of cropland, $2 2 . 5 \mathrm { k m } ^ { 2 }$ of shrub land, $4 4 . 2 \mathrm { k m } ^ { 2 }$ of forest land, and $9 6 . 1 \mathrm { \bar { k m } } ^ { 2 }$ of other land types such as grassland and barren land in Hubei Province being occupied by the construction of the SNWTP. $\mathrm { C O } _ { 2 }$ emissions associated with the SNWTP were approximately 3.1 million tons (Fig. 4). Furthermore, there was substantial energy footprint throughout the life cycle of the SNWTP due to water transfer for food production in the NCP (Fig. 4).

# Discussion

This study provided the first assessment about how nexus trade-offs happened between different places under complex

![](images/d7c1999db4ef79de6bcd622fe97c4685eb648d92b613a48ed92610cc11f5327a.jpg)

![](images/da03c47703d5b508a8e6fbac599f9b9588189fc3c4c7147ddc4de62975a9849d.jpg)

![](images/83521e6b60954f97a32d7b8f2dad31b1d193ada438e485250e59e7744ca411c2.jpg)  
Fig. 4 Water footprint, carbon footprint, and energy footprint at each stage of the South-to-North Water Transfer Project’s life cycle. a Water footprint; b carbon footprint; c energy footprint. Data are provided in the Source data file.

environmental and socioeconomic factors (e.g., climate change, diet change, irrigation technologies, crop planting strategies, and water diversion project.). Irrigated agriculture in the NCP largely influences China’s food security and related resource consumption and environment. We found although the spillover system (Hubei Province) did not participate in the interactions as a sending or receiving system, it was still affected and even suffered losses (e.g., water and land losses). Cross-sector woes also happened between different places, like how ensuring food security in the rest of China brought unsustainable water use, energy and carbon footprint in the NCP. In other words, the environmental impacts not only were interconnected between different sectors, but also interacted between different places across boundaries. Our findings revealed environmental stress across sending, receiving, and spillover systems due to irrigated agriculture in the NCP. The reasons may include China’s soaring crop consumption driven by its rapid economic development, rapidly growing population, and considerable declines in cultivated land area in southern China, as well as increases in crop production in northern China due to the development of agriculture and water conservation facilities in the region46. Water scarcity, energy consumption, $\mathrm { C O } _ { 2 }$ emissions, and rapidly growing populations could interact to create complex socio-ecological challenges that, if left unaddressed, may threaten China’s sustainability.

The environmental impacts on the spillover system should be highlighted. Spillover systems are often overlooked in conventional studies and policymaking31. However, spillover systems can be affected by metacoupling, which can lead to severe environmental consequences47. Our study reveals how the food trade between the NCP and the rest of China places environmental burdens, including water loss and land occupation in Hubei Province, the spillover system.

Policies are needed to help address multiple aspects of environmental impacts in different areas simultaneously affected by the transfer of water. Deficit irrigation could be applied in areas that have yet to reach maximum water efficiency to minimize the trade-off between water sustainability in the NCP and food sustainability in the rest of China48. Since water sustainability is seriously threatened in the NCP and cannot support more food production in the long term, the crop production could be limited and be relocated.

More consumption-based policies (policies addressing consumption-related issues) could be combined with supplyoriented management to reduce pressures on food production and its associated environmental burdens and resource consumption. Applying supply-oriented management (management aiming at addressing supply-related issues) alone tends to increase water use, energy consumption, and $\mathrm { C O } _ { 2 }$ emissions because it gives the false perception that natural resources and the

ability of the oceans and atmosphere to absorb more $\mathrm { C O } _ { 2 }$ emis-2 sions is limitless49,50. This false perception can encourage more intensive resource consumption and exacerbate environmental burdens associated with food production. Thus consumptionbased policies such as those that encourage a diet shift to less resource-intensive crops and combat food waste in consumption side can help achieve sustainable development51. We suggest the Chinese government could consider both supply-side and consumption-side management simultaneously.

This study’s systematic assessment of environmental impacts across different systems associated with food trade and water transfers under various scenarios can be applicable to many other countries facing similar sustainability challenges. Such assessments are critical to achieving sustainable development since global food trade has proliferated in response to global challenges (e.g., water scarcity, food insecurity, $\bar { \mathrm { C O } } _ { 2 }$ emission, and energy crisis)2,21,32,52,53. In this study, the integrated framework of metacoupling helped fill important knowledge gaps through a comprehensive assessment of environmental impacts associated with food trade and water transfers across multiple systems. Due to data limitations, however, we cannot conduct analyses at the household level. Also, although current scenarios have considered various conditions, they still may not completely represent complex environmental and socioeconomic interactions in irrigated agriculture. Thus, future research could investigate the solution space more broadly and comprehensively to understand adaptation strategies by considering factors such as population growth, household dynamics, government investment and technology improvement, and natural disasters. For example, impacts of other technologies like gravity-based irrigation systems can be assessed to see if they perform better than other technologies for irrigated agriculture. Also, other socioeconomic factors about irrigated agriculture, such as robust water accounting and measurements, and the incentives and behavior of irrigators to subsidies could be included and assessed to avoid unexpected consequences54. Further research is also needed to go beyond the focus on environmental impacts by including socioeconomic impacts, such as poverty, social equality, health, and well-being. Such research can present a more comprehensive assessment of the socio-ecological effects associated with food trade and water transfers to help achieve global sustainable development.

# Methods

Data sources. We obtained agrometeorological data from 1986 to 2010 from the Meteorological Data Sharing Service System of National Meteorological Information Center of China, and basic agricultural data (e.g., cultivated area, nitrogen use, winter wheat and summer maize production, and areal extent of other crops) in the NCP at the county level from the Agricultural Information Institute of Chinese Academy of Agricultural Sciences. We obtained crop evapotranspiration measurements for summer maize and winter wheat from Luancheng Agro-Eco-

Experimental Station of the Chinese Academy of Sciences. We compiled data about SNWTP’s construction materials, work items and quantity of work from the Feasibility Study Report of South-to-North Water Transfer Project—Middle Route. This study focused on the Middle Route because it transfers water from Hubei Province to the NCP. The $\mathrm { C O } _ { 2 }$ emission factors and energy intensity factors of each material used for construction were derived from ELCD (European Life Cycle Database), IPCC (Intergovernmental Panel on Climate Change) and Ecoinvent databases55. According to the general report of the SNWTP, all construction processes would follow the Hydraulic Construction Mechanical Quota 2002, selecting machines and determining machines’ work hours. The hydraulic quota 2002 was used to define the energy consumption of each unit of the work process.

Metacoupled systems. We applied the metacoupling framework17 to define the systems in the scope of this study and identify the ways in which the systems were interconnected through food trade and water transfer. The NCP and regions throughout the rest of China are coupled human and natural systems, with humannature interactions within each (e.g., crop production, energy and water consumption and $\mathrm { C O } _ { 2 }$ emissions in the NCP; food consumption in the rest of China; water loss, land use, energy consumption and $\mathrm { C O } _ { 2 }$ emissions in spillover systems), connected through the flows of food and water. The NCP is the sending system of food, and the regions throughout China that are supported by food from the NCP constitute the receiving system. Hubei Province is the spillover system because although it is not directly involved in food trade with the $\mathrm { N C P ^ { 1 9 } }$ , it is the source site of the SNWTP, which diverts water from Hubei Province to the NCP for crop production there.

Life cycle assessment (LCA) of the chains of irrigated agricultural production. The use of LCA, performed according to ISO14040 & ISO1406756, is an established technique used for years to assess environmental impacts associated with a product throughout its life cycle57. Within the LCA model all impacts (e.g., water use, energy footprint and $\mathrm { C O } _ { 2 }$ emissions, etc.) are measured by functional unit and are thus connected at the time of consumption to that unit58. LCA can be a viable technique for determining environmental thresholds. In this study, LCA and footprint methods were coupled to take advantage of their strengths and complementarities. Water, energy and carbon footprints were calculated through the LCA method (Supplementary Fig. 6). As for water footprint, the green, blue and grey water footprint was considered.

For both LCA and footprints, the analyses focused on five stages of agricultural operations during the life cycle: tillage, sow, irrigation, fertilization, and harvest (Supplementary Fig. 7). For both footprints and LCA the quantitative description of the inputs and outputs to/from the studied system is required. Irrigation stage includes irrigation energy consumption, irrigation equipment input, etc. The fertilization stage includes fertilizer inputs and fertilization equipment. The labors input and machinery depreciation occur at all five stages. WF accounting requires the inventory of the inputs and outputs in terms of water flows (blue, green, and grey as stated above). LCA requires the inventory of all the types of material inputs (mainly natural biotic and abiotic resources, including water) and outputs (mainly emissions in gaseous, solid and liquid forms, the latter related to water pollution and, hence to grey water) and the entering and exiting energy flows.

# Water footprint from crop production

$W F _ { \mathrm { c o n s } }$ . $W F _ { \mathrm { c o n s } }$ of crop production is the total actual consumption of water within its whole production chain. Often, it is difficult to directly measure $W F _ { \mathrm { c o n s } }$ and thus the indirect water requirement method is used. The crop water requirement is assumed as the water via crop evapotranspiration under optimal conditions, which is calculated by multiplying the reference crop evapotranspiration with a crop coefficient. Because actual crop growth is not always in optimal conditions, actual evapotranspiration should be less than optimal crop evapotranspiration and a water stress coefficient is introduced. The main factors that affected crop evapotranspiration include precipitation, air temperature, pressure, sunshine hours, wind speed, crop type, soil condition, and planted time. The calculation functions are given below59,60.

$$
W F _ {\text {c o n s}} = \frac {E T _ {\mathrm {a}} \times A \times B}{Y} \tag {1}
$$

$$
E T _ {\mathrm {a}} = K _ {\mathrm {s}} \times K _ {\mathrm {c}} \times E T _ {0} \tag {2}
$$

$$
E T _ {0} = \frac {0 . 4 0 8 \delta \left(R _ {\mathrm {n}} - G\right) + \gamma \frac {9 0 0}{T + 2 7 3} U _ {2} \left(e _ {\mathrm {s}} - e _ {\mathrm {a}}\right)}{\delta + \gamma \left(1 + 0 . 3 4 U _ {2}\right)} \tag {3}
$$

Where $E T _ { \mathrm { a } }$ (mm) is the actual crop evapotranspiration; A $( \mathrm { k m } ^ { 2 } )$ is the total plantation area; $Y \left( \mathrm { k g } \right)$ is the total crop yield; $B$ is the unit conversion constant, equaling to 1000 here; $K _ { s }$ is water stress coefficient and is often assumed to be 1 for water requirement method; $K _ { \mathrm { c } }$ is crop coefficient comparing to reference crop evapotranspiration; $E T _ { 0 }$ (mm) is reference crop evapotranspiration; $R _ { \mathrm { n } }$ $( \mathrm { M J } \bar { \mathrm { m } } ^ { - 2 } \dot { \mathrm { d } ^ { - 1 } } )$ is net radiation on crop surface; $G \ : ( \mathrm { M J \ : m ^ { - 2 } d ^ { - 1 } } )$ is soil heat flux; T $( ^ { \circ } \mathrm { C } )$ is average air temperature; $U _ { 2 }$ $\mathbf { ( m \thinspace s ^ { - 1 } ) }$ is wind speed at 2 meters aboveground; $e _ { s }$ (kPa) is saturation vapor pressure; $e _ { \mathrm { a } }$ (kPa) is measured vapor pressure; δ $( \mathrm { k P a } ^ { \circ } \mathrm { C } ^ { - 1 } )$ is the

slope of the curve between saturation vapor pressure and temperature; γ $( \mathrm { k P a } ^ { \circ } \mathrm { C } ^ { - 1 } )$ ) is hygrometer constant.

For our proposed water consumption method, the actual crop evapotranspiration in Eq. (1) is calculated from the crop water production function (CWPF) shown below.

$$
y = a E T _ {\mathrm {a}} ^ {2} + b E T _ {\mathrm {a}} + c \tag {4}
$$

$$
E T _ {\mathrm {a}} = \min  \left(- \frac {b}{2 a} \pm \sqrt {\frac {y}{a} + \frac {b ^ {2}}{4 a ^ {2}} - \frac {c}{a}}\right) \tag {5}
$$

Where, a, b, c are regression coefficients; y (kg/ha) is unit area crop yield.

WFblue and WFgreen. $W F _ { \mathrm { b l u e } }$ $W F _ { \mathrm { g r e e n } }$ $W F _ { \mathrm { b l u e } }$ is the volume of consumed surface water and groundwater for producing goods or delivering services. $W F _ { \mathrm { g r e e n } }$ is the volume of consumed rainwater during the production process. This is particularly relevant for agricultural and forestry products, including the total rainwater evapotranspiration (from fields and plantations) plus the water incorporated into the harvested products61. The blue and green WF can be calculated by the following equations:

$$
W F _ {\text {c o n s}} = W F _ {\text {b l u e}} + W F _ {\text {g r e e n}} \tag {6}
$$

$$
W F _ {\text {b l u e}} = \frac {E T _ {\text {b l u e}} \times A \times B}{Y} \tag {7}
$$

$$
E T _ {\text {b l u e}} = \max  \left(0, E T _ {\mathrm {a}} - P _ {\text {e f f}}\right) \tag {8}
$$

$$
W F _ {\text {g r e e n}} = \frac {E T _ {\text {g r e e n}} \times A \times B}{Y} \tag {9}
$$

$$
E T _ {\text {g r e e n}} = \min  \left(E T _ {\mathrm {a}}, P _ {\text {e f f}}\right) \tag {10}
$$

$$
P _ {\text {e f f}} = \sigma P \tag {11}
$$

Where $E T _ { \mathrm { b l u e } }$ (mm) and $E T _ { \mathrm { g r e e n } }$ (mm) are evapotranspiration of blue and green water, respectively; $P _ { \mathrm { e f f } }$ (mm) and $P$ (mm) are effective rainfall and total rainfall within crop growth period, respectively; $\sigma$ is the effective utilization coefficient of rainfall.

Crop water production function. Crop water production function (CWPF) is the mathematical expression that describes the relationship between water use and crop production for a certain kind of crop. The function is mainly influenced by sunshine and heat factors such as photosynthetically active radiation and effective accumulated temperature, and agricultural production factors such as soil organic matter, crop types and varieties62. In the North China Plain (NCP), annual average photosynthetically active radiation ranges from 2290 to $2 5 2 4 \mathrm { M J } \mathrm { m } ^ { - 2 }$ . The effective accumulated temperature (EAT) of winter wheat and summer maize during their whole growth periods are $1 2 9 8 - 2 6 0 5 ^ { \circ } \mathrm { C }$ and $2 0 7 7 - 2 4 1 3 ^ { \circ } \mathrm { C } .$ , respectively. Soil organic matter in $8 2 . 9 \%$ of the area is between $0 . 5 \%$ and $1 \%$ . These numbers suggest that for winter wheat there is only large spatial variation in its EAT while little variation in other production factors. Thus, we divided the total plantation area of winter wheat into three zones based on the EAT and used different CWPFs to improve the estimation accuracy. Because the spatial distribution of EAT did not exactly match the administrative boundaries of counties, the EAT for the majority of counties’ land area was used. For summer maize, given there is little variation for all production factors affecting the CWPF, the same CWPF was used for all counties for a certain year.

Meanwhile, the CWPF may vary in a long period due to changes in crop variety (e.g., drought resistance, unit area yield). In addition, data of CWPF may not be available every year. For this study, for winter wheat, we obtained CWPF data in years $1 9 8 6 ^ { 6 3 }$ and $2 0 0 7 ^ { 6 4 }$ for zone 1, in years $1 9 9 0 ^ { 6 5 }$ and $2 0 0 3 ^ { 6 1 }$ for zone 2, and in years $1 9 8 6 ^ { 6 3 }$ and $2 0 0 8 ^ { 6 6 }$ for zone 3, respectively. For summer maize, we acquired CWPF data in years $1 9 8 4 ^ { 6 3 }$ , $2 0 0 0 ^ { 6 7 }$ , and $2 0 0 8 ^ { 6 6 }$ . Based on the obtained CWPF data in each two-consecutive time point, we then estimated the corresponding CWPF for each year with the assumption that the increment of crop yield per unit volume water consumption is equal across years.

In order to test the accuracy of the two methods, we took the measured data61 of ETc (from Luancheng Agro-Eco-Experimental Station of the Chinese Academy of Sciences, which is located in the northern part of the NCP.) to compare with data of ETc calculated from CWPF method and water requirement method. We mapped a scatter diagram with a $y .$ -axis of CWPF method and water requirement method, an $x$ -axis of the measured data of ETc. The measured data are from 1986 to 2009 for summer maize and 1986 to 2007 for winter wheat. For both methods, the more discrete degree of the points, the less accuracy of the method.

$W F _ { \mathrm { g r e y } }$ . The $W F _ { \mathrm { g r e y } }$ is an indicator of freshwater pollution that is associated with a product over its full production chain. It is calculated as the volume of water required to dilute pollutants to meet water quality standards. The $W F _ { \mathrm { g r e y } }$ can also be divided into surface and ground sources.

We focused on the $W F _ { \mathrm { g r e y } }$ of nitrogen because it was intensively used in the NCP and potentially had the most severe pollution since it can easily be

transported in soil, surface water, and groundwater. Soil phosphorus often easily generates chemical reactions with other soil minerals and produces chemical compounds that are not readily soluble, resulting in less pollution. Potassium ions can be easily attracted by soil colloids and are not easily filtered. Therefore, the pollution from phosphorus and potassium fertilizers can be ignored when assessing $W F _ { \mathrm { g r e y } }$ . For chemical pesticides, given there were various types of used chemical pesticides with distinct maximum allowable concentrations, it was very difficult to collect the data. Thus, we did not take them into account.

The nitrogen application amount in the NCP had an average amount of 433.38 $\mathrm { k g h a ^ { - 1 } }$ and a range from $1 7 9 . 7 6 \ \mathrm { ( m i n ) k g h a ^ { - 1 } }$ to 879.11 (max) $\mathrm { \ k g h a ^ { - 1 } }$ . The spatial distributions of winter wheat and summer maize are similar; however, on average the nitrogen application amount of winter wheat (223.56_average ${ \bf k g h a } ^ { - 1 } ,$ ) is higher than that of summer maize (212.43_average $\mathrm { { k g h a ^ { - 1 } } }$ ). The calculation functions for grey WF are shown below.

$$
W F _ {\text {g r e y}} = \frac {\left(\alpha_ {\text {t o t a l}} \times A R\right) / \left(C _ {\max } - C _ {\text {n a t}}\right)}{y} \tag {12}
$$

Where $\alpha _ { \mathrm { t o t a l } }$ is total leaching fraction, measured to be $2 5 . 0 \% ^ { 6 8 }$ ; AR $( \mathrm { k g h a ^ { - 1 } } )$ is per hectare application amount of chemical fertilizer; $C _ { \mathrm { m a x } } \left( \mathbf { g } \mathrm { L } ^ { - 1 } \right)$ and $C _ { \mathrm { n a t } } \left( \mathbf { g } \mathbf { L } ^ { - 1 } \right)$ are the maximum acceptable concentration and natural concentration of the chemical fertilizer, respectively.

Sustainability of water use. The sustainability of grain production from a WF perspective can be reflected through the use intensity of total available water for agricultural use $\left( I _ { \mathrm { t o t a l } } \right)$ . The higher the use intensity, the less sustainable for grain production. The water sustainability indicators can be calculated as follows.

$$
I _ {\text {t o t a l}} = W R _ {\text {a g r i , t o t a l}} / W F _ {\text {t o t a l}} \tag {13}
$$

Where $I _ { \mathrm { t o t a l } }$ is the sustainability indicator of total available water for agricultural use; $W F _ { \mathrm { t o t a l } }$ is total WF for winter wheat and summer maize here; $W \bar { R } _ { \mathrm { a g r i , t o t a l } }$ is total water resources for agricultural use69. For $W F _ { \mathrm { t o t a l } } ,$ the average values from 1986 to 2010 were calculated.

Water sustainability. To assess the sustainability of water use involved in crop production in all NCP counties from the perspective of water quantity, we used the ratio of the total available water for agricultural use to the total water consumption of irrigated agriculture production (total direct and indirect consumption of water in the whole production chain) as an indicator for water sustainability (see Supplementary information for further descriptions and details on calculation method)70,71. An indicator value greater than 1 represents sustainable water consumption. The greater the value of the indicator, the greater the sustainability of water consumption associated with crop production. We then mapped the spatial distribution of water sustainability across all NCP counties using ArcGIS software (Esri Inc., Redlands, CA).

Because the actual amount of water consumed by crop production might differ from the amount calculated from conventional methods that estimate the required amount, we developed and used an alternative method of calculating water consumption based on the crop water production function and compared our results with those of conventional methods. We found the estimate from the conventional water requirement methods was significantly higher than actual measurements at the Luancheng monitoring station and our method showed higher accuracy. After confirming the greater accuracy of our methods compared to conventional methods, we applied our method to calculate the water consumption of crop production. All statistical analyses were performed using Stata 13.

$\mathbf { c o } _ { 2 }$ emissions and energy footprint from crop production. The process of agricultural production has large amounts of $\mathrm { C O } _ { 2 }$ emissions. We calculated the $\mathrm { C O } _ { 2 }$ emissions from irrigated agriculture (CF) using Eq. (14):

$$
C F = C F _ {\mathrm {F}} + C F _ {\mathrm {I}} + C F _ {\mathrm {M}} + C F _ {\mathrm {H}} + C F _ {\mathrm {S}} + C F _ {\mathrm {P}} \tag {14}
$$

Where $C F _ { \mathrm { F } } { } _ { : }$ , $C F _ { \mathrm { { I } } } ,$ $C F _ { \mathrm { M } } ,$ $C F _ { \mathrm { H } } { \mathrm { : } }$ , $C F _ { \mathrm { { S } } }$ and $C F _ { \mathrm { { P } } }$ represent $\mathrm { C O } _ { 2 }$ emissions from fertilizer application, irrigation, mechanical work, labor input, seed input, and pesticide and herbicide use, respectively.

We calculated the energy consumed through the whole crop production chain $E _ { 1 }$ through the following Eq. (15):

$$
E _ {1} = E _ {\mathrm {W}} + E _ {\mathrm {M}} + E _ {\mathrm {L}} + E _ {\mathrm {F}} + E _ {\mathrm {P}} + E _ {\mathrm {I}} \tag {15}
$$

Where $E _ { \mathrm { W } } , E _ { \mathrm { M } } , E _ { \mathrm { L } } , E _ { \mathrm { F } } , E _ { \mathrm { P } }$ and $E _ { \mathrm { I } }$ represent energy input for seeds, machine use, labor, fertilizer, pesticides, and irrigation, respectively.

Simulation scenarios. We set the scenarios in Table 1 to simulate impacts of various factors on FEWC outcomes.

Scenarios and crop production patterns. The assessment of water, energy and nitrogen footprint of irrigated agricultural production and production processes in the North China Plain under different scenarios considered climate change, irrigation systems and methods, dietary structure adjustment, water transfer through

the South to North Water Transfer Project. The results in this section reflect spatial differences at the county-level calculations to analyze geospatial features72. The specific settings are as follows:

Climate changes. We considered scenarios with different levels of climate change73,74. This paper simulated different climate scenarios and considerd three factors: precipitation (average water year), temperature, and carbon dioxide concentration. The reference crop transpiration ET0 was calculated by the Penman-Montieth formula. According to the research conclusion of ref. 75, the climatic factors were all calculated according to the trend from 2010 to 2030. This paper used the AquaCrop model to predict crop yield. The input modules mainly included crops, weather, soil types, groundwater, field management, and initial conditions. Technical model was based on the current technical model (mechanical tiller planting machine harvesting, ground furrow irrigation, irrigation 4 times under normal water years, surface water of irrigation water source: groundwater $=$ 1:9, planting density $2 0 \mathrm { k g / m u }$ , fertilization converted to pure N, P, $\mathrm { K } = 3 0$ , 10, $5 \mathrm { k g / m u }$ “Guiding Opinions on Scientific Fertilization Technology for Winter Wheat in North China $\operatorname { P l a i n } ^ { \prime \prime } ) ^ { 7 6 , 7 7 }$ 7.

Agricultural production patterns. The agricultural production model mainly considers three categories: reducing irrigation volume, changing the rotation system, and upgrading irrigation methods. In order to be close to the actual production situation, this paper estimated the output under different irrigation and precipitation conditions through the Aqua-Crop model. Specifically, this paper included the reduction of irrigation to 2 times in normal water years, to 0 times (rain-fed) in high water years, and to 3 times in low water years. According to the Comprehensive Action Plan for Groundwater Overdraft in North China, the plan for water-saving irrigation area in the North China Plain is 58.62 million $\mathrm { h m } ^ { 2 }$ in $2 0 2 0 ^ { 6 0 }$ . This paper evaluated the output and water, energy and carbon footprint when sprinkler irrigation and drip irrigation were extended to 58.62 million $\mathrm { h m } ^ { 2 }$ (Supplementary Table 3). The extension area was allocated to the counties according to the proportion of the existing cultivated land area.

Water transfer engineering and diet changes. From the perspective of consumption, this paper looked at the output demand under dietary changes, calculated the required output backwards, combined the production technology model of the first part of the scenario analysis, calculated the corresponding water energy carbon footprint, and explored the sustainable production model under dietary adjustment78,79.

Sustainable food supply. We set an indicator of sustainable food supply to assess the impacts of crop production in the NCP on food security for the rest of China80, 81. According to the Major Consulting Project of Chinese Academy of Engineering “China’s Agricultural Water Demand and High Efficient Farming Construction of Water Saving”82,83, in 2010, a wheat yield of $5 , 8 9 5 \mathrm { k g } / \mathrm { h m } ^ { 2 }$ and maize yield of $5 , 8 3 5 \mathrm { k g } / \mathrm { h m } ^ { 2 }$ in the NCP were required to fulfill its share of responsibility for the national food security. This project assigned part of the food production task to the NCP, which is partially responsible for ensuring national food security. We, therefore, calculated the sustainable food supply indicator as the ratio of the actual amount of crop production to the sustainable amount of crop production which is derived from multiplying the crop yield requirements with their cropland area. An indicator value greater than 1 indicates that sustainable food supply is achieved. A higher value in the sustainable food supply indicator indicates greater sustainable food supply for the rest of China.

Food–energy–water– $\mathbf { \hat { \rho } } _ { \mathbf { \tilde { C } } \mathbf { 0 } _ { 2 } }$ nexus in the NCP. We developed and followed the framework (Fig. 5) to figure out environmental impacts of crop production in the NCP (see details in “Methods”).

Impacts on the spillover system. To evaluate the environmental spillover effects of crop production in the NCP on the spillover system, we analyzed data about water loss and land use change in Hubei Province due to the construction of the SNWTP from the general report on the feasibility study of the first phase project of the Middle Route of the SNWTP. We also assessed $\mathrm { C O } _ { 2 }$ emissions and energy footprint from the SNWTP’s life cycle (see details in SI). Because ${ \sim } 2 2 . 1 1 \%$ of the total water diverted by the SNWTP goes toward agriculture in the NCP, we multiplied the total $\mathrm { C O } _ { 2 }$ emissions and energy footprint of the SNWTP by $2 2 . 1 1 \%$ to calculate the environmental impacts of the SNWTP due to crop production in the NCP.

Water footprint, $\mathbf { c o } _ { 2 }$ emissions, and energy footprint from the SNWTP Water footprint. The water footprint of the South-to-North Water Transfer Project mainly includes two parts. One is the water footprint in the process of water transfer $( W F _ { \mathrm { e } } )$ , which mainly indicates the footprint of the evaporating water surface in the channel water period $( W F _ { \mathrm { m } } )$ , mainly including material water footprint and construction water footprint. The sum of these two water footprints constitutes the total water footprint of the South-to-North Water Transfer Project

![](images/97d82cd4e3e1c532060d6717b19bede06d248ba8b01225fa8d6d46d8c8c3f836.jpg)  
Fig. 5 Framework for footprint evaluation model based on LCA. Framework of crop production simulation and water, energy, and carbon footprint assessment in the North China Plain.

during its entire life cycle. The calculation formula is as follows:

$$
W F = W F _ {\mathrm {e}} + W F _ {\mathrm {m}} \tag {16}
$$

The water footprint generated during the water delivery process is the evaporative water footprint:

$$
W F _ {\mathrm {e}} = 1 0 \cdot E \cdot A \cdot T \tag {17}
$$

Where, E is the amount of surface water evaporation in open channels (mm); A is the surface area of open channels $( \mathrm { h } \mathrm { m } ^ { 2 } )$ ; T is the running time of water, 365 days in this study; 10 is the unit conversion. In this study, the channel water surface evaporation model was adopted for the open channel liquid surface evaporation water footprint. It refers to the Penman formula and Dalton model and was perfected on this basis, so as to propose a multi-factor combined water surface evaporation calculation model. Water surface evaporation calculation model:

$$
E = \Delta e \times f (\Delta T, r, W)
$$

$$
f (\Delta T, r, W) = g (T) \cdot \varphi (r) \cdot \varphi (W)
$$

$$
\varphi (W) = \left\{ \begin{array}{c c} 0. 1 9 2 + 0. 0 8 W, & W \leq 1. 5 \mathrm {m / s} \\ 0. 3 1 2 + 0. 0 7 8 (W - 1. 5) ^ {1 - 0. 0 9 8 (W - 1. 5) ^ {0. 5}}, & W > 1. 5 \mathrm {m / s} \end{array} \right.
$$

$$
\varphi (r) = 0. 1 5 3 + 0. 6 5 1 \left(1 - r ^ {2}\right) ^ {1 / 2} \tag {18}
$$

$$
g (\Delta T) = 0. 9 2 + 0. 0 3 6 3 \Delta T ^ {1. 0 8}
$$

$$
\Delta e = E _ {\mathrm {a}} - E _ {\mathrm {w}}
$$

$$
E _ {\mathrm {a}} = 0. 6 1 1 \times e ^ {\frac {1 7 . 2 7 \times T _ {3}}{T _ {4} + 2 3 7 . 2}} \times \left(1 - \frac {r}{1 0 0}\right)
$$

$$
E _ {\mathrm {w}} = 0. 6 0 1 8 \times e ^ {\frac {1 7 . 2 5 \times T _ {4}}{7 5 + 2 3 7 . 3}}
$$

where $E$ is the evaporation of the reservoir water surface $( \mathbf { m } ^ { 3 } )$ ; $\Delta e$ is the difference in saturation vapor pressure; $g$ (ΔT) is the water temperature difference function; $\varphi ( r )$ is the relative humidity function; $\varphi ( W )$ is the wind speed function; $T$ is the difference between water temperature and air temperature ${ } ^ { ( \circ } \mathrm { C } )$ ; r is relative humidity $( \% )$ ; $W$ is wind speed $\mathrm { ( m / s ) }$ ); $E _ { \mathrm { a } }$ is the saturated vapor pressure under air (kPa); $E _ { \mathrm { w } }$ is the saturated vapor pressure of water $\mathrm { ( k P a ) }$ ); $T _ { \mathrm { a } }$ is the temperature $( ^ { \circ } \mathrm { C } )$ ; $T _ { s }$ is the wet bulb temperature $( ^ { \circ } \mathrm { C } )$ .

For a water delivery channel, its cross-section (including channel bottom width and slope angle) and specific drop have been fixed after completion, while the width of the surface varies with the diversion flow and flow rate. Since the water transfer volume of the South-to-North Water Transfer Project is gradually increasing, the liquid surface area of the water transfer will change.

$$
F = \sqrt {d ^ {2} + 4 \frac {Q}{\nu} c t g \alpha} \cdot L \tag {19}
$$

where, $F$ is the open channel water surface area $( \mathbf { m } ^ { 2 } )$ ; $d$ is the bottom width (m); Q

is the open channel flow $( \mathrm { m } ^ { 3 } / \mathrm { s } )$ ; $\nu$ is the flow rate $\mathrm { ( m / s ) }$ ; $\alpha$ is the open channel slope coefficient; and $L$ is the open channel length (M).

The water footprint of energy consumption materials in the life cycle, the production and processing of raw materials in the construction of water transmission channels must be accompanied by the transfer and consumption of water resources, such as steel and concrete. The construction stage of the water conveyance channel includes various construction techniques such as earth and stone excavation and concrete mixing and pouring. Each single project is completed by cooperation of multiple machines. During this process, the power consumption of the construction machinery also produces a certain amount of water footprint. At the same time, concrete curing and mortar mixing are accompanied by a lot of water consumption.

$\mathbf { c o } _ { 2 }$ emissions and energy footprint from the SNWTP. We applied a hybrid EIO-LCA method to understand the $\mathrm { C O } _ { 2 }$ emissions of the South-to-North Water Transfer Project (SNWTP)84. The system being studied consists of material manufacturing, transportation of material, project construction, and project operation. The disposal of the SNWTP is not included in this study because it is very hard to imagine how such a large project would be disposed. One ton of water transferred per second is considered as the functional unit since the function of the SNWTP is transferring water.

In the material manufacturing process, some materials like cement, steel, wood, and diesel are made. The $\mathrm { C O } _ { 2 }$ emissions/energy footprint from material manufacturing is calculated by Eq. (20):

$$
C F _ {m} = \sum_ {i} \beta_ {i} \times C _ {i} \tag {20}
$$

where $C F _ { m }$ is the carbon/energy footprint of material manufacturing; $\beta _ { i }$ represents the $\mathrm { C O } _ { 2 }$ emissions/energy consumption intensity factor of material i; $C _ { i }$ is the amount of i material consumption.

Since the manufacturing sites are distributed widely throughout China, we derived the average distance of different kinds of materials transported from the manufacturing sites to the construction site from China Statistical Yearbook 2002, and then calculated diesel or gasoline consumed during the transportation stage. By hydraulic quota 2002, we chose 45 t freight truck as the distant transportation tool to transport different kinds of materials. Carbon/energy footprint from transportation stage $C F _ { \mathrm { t } }$ can be calculated as follows:

$$
C F _ {\mathrm {t}} = \sum_ {i} \beta_ {\mathrm {d}} \alpha_ {\mathrm {d}} \times \frac {Q _ {i}}{L} \times \frac {s _ {i}}{\nu} \tag {21}
$$

where $\beta _ { \mathrm { d } }$ represents $\mathrm { C O } _ { 2 }$ emissions/energy consumption intensity factor for diesel fuel; $\alpha _ { \mathrm { d } }$ represents the amount of diesel consumption by truck per hour; $Q _ { i }$ is the quantities of material transported; $L$ represents the load of truck. $s _ { i }$ represents the distance of transportation; $\nu$ is the speed of the truck.

Within the construction process, various work activities are involved, such as concrete mixing, concrete lining, soil-rock excavation, and soil-rock filling. The $\mathrm { C O } _ { 2 }$ emissions are produced by diesel and electricity consumed during construction, which can be calculated by using Eqs. (22)–(24):

$$
C _ {\mathrm {d} i} = \frac {w _ {i}}{h _ {i}} \times k _ {i} \tag {22}
$$

$$
C _ {e i} = \frac {w _ {i}}{h _ {i}} \times g _ {i} \tag {23}
$$

$$
C F _ {\mathrm {c}} = \sum_ {i} \left(\beta_ {\mathrm {d}} C _ {\mathrm {d i}} + \beta_ {\mathrm {e}} C _ {\mathrm {e i}}\right). \tag {24}
$$

where $C F _ { \mathrm { c } }$ represents the total carbon/energy footprint from construction; $C _ { \mathrm { d } i }$ means the diesel consumption of work i; $C _ { e i }$ is the electricity consumption in work i; $\beta _ { e }$ represents the $\mathrm { C O } _ { 2 }$ emissions/energy coumption intensity factor of electricity, $\beta _ { \mathrm { d } }$ is the $\mathrm { C O } _ { 2 }$ emissions/energy consumption intensity factor of diesel; $w _ { i }$ is the total amount of work $i ,$ and $h _ { i }$ represents the amount of work finished per unit time; $k _ { i }$ is the diesel consumed per unit time, and $g _ { i }$ represents the electricity consumed per unit time.

We applied economic input-output (EIO) life cycle assessment to quantify carbon/energy footprint from operation stage. According to a survey85, for concrete construction, each year the maintenance stage would cost $2 \%$ of total expense of one project, thus we also set this ratio for the SNWTP. Based on the standard for the “Economic Evaluation of Water Conservancy Construction Project $( S L 7 2 - 2 0 1 3 ) ^ { \mathfrak { v } 4 2 }$ , the SNWTP’s life of maintenance and operation spans 50 years86. After obtaining the total cost of the maintenance and operation stage, we used the EIO method to derive the $\mathrm { C O } _ { 2 }$ emissions from maintenance and operation stage by choosing construction, nonresidential maintenance and repair sector in the US 2002 Benchmark EIO model and running it.

Data quality assessment methods and models. Life cycle assessment (LCA) is an evaluation method based on the calculation and analysis of the data list in the entire life cycle. The uncertainty of the original data and the calculation process method affect the accuracy of the life cycle assessment results to some extent. Therefore, it is often necessary to analyze the uncertainty of the results from LCA. In this study, an evaluation method combining data quality index method (DQI) and uncertainty was used to establish a data quality evaluation model, and the final results were simulated through Monte Carlo Simulation to obtain the uncertainty of outcomes.

Step 1: scoring data quality. This study used a data quality scoring system based on five perspectives: credibility, completeness, technology-related, time-related, and geographic-related. The data quality was divided into five levels according to the data quality index matrix and assignment criteria. The larger the score, the better the quality of the data. By analyzing the data list, a data quality vector was formed, and the weighted average was calculated as:

$$
\bar {q} = \sum_ {i = 1} ^ {n} q _ {i} \tag {25}
$$

where $\bar { q }$ is the data quality of the original data; n (1–5) is the index of the vector with 5 elements (i.e., five data perspectives); $q _ { i }$ is the data quality vector element value.

# Step 2: the range of the indicator R is calculated as.

$$
R = \frac {\bar {q} - \operatorname* {m i n} q _ {i}}{\operatorname* {m a x} q _ {i} - \operatorname* {m i n} q _ {i}} \times 100 \% \tag{26}
$$

where R is the percentage of $\bar { q }$ within the total quality range of the data quality vector; minq is the minimum vector element value, and maxq is the maximum vector element value. According to $R ,$ the data quality vector was converted into the data quality indicators (DQI), and the data are shown in Supplementary Table 4.

Step 3: input data probability distribution. After determining DQI, it is necessary to determine the probability distribution of the original data and fit the data to it. This study used a wide range of $\beta$ distribution density functions, the formula was as follows:

$$
\begin{array}{l} f (x; \alpha ; \beta ; a; b) = \left[ \frac {1}{b - a} \right] \times \left\{\Gamma (\alpha + \beta) / [ \Gamma (\alpha) \times \Gamma (\beta) ] \right\} \times \left[ (x - a) / (x - b) \right] ^ {\alpha - 1} \tag {27} \\ \times \left[ \begin{array}{c} b - x \\ \hline b - a \end{array} \right] ^ {\beta - 1} \\ \end{array}
$$

where $\alpha$ and $\beta$ are distribution shape parameters, a and $^ { b }$ are selected range breakpoints.

Step 4: uncertainty calculation. The original data distribution type is determined by comparing the $\beta$ random distribution parameter table of the data quality index DQI (Supplementary Table 4). The uncertainty $U _ { 0 }$ of the original data can be

expressed by the relative standard deviation (RSD) of the distribution type. In this study, original data with $U _ { 0 } < 1 0 \%$ (i.e., the uncertainty of the original data is less than $1 0 \%$ ) was considered to be of good quality87.

Step 5: Monte Carlo simulation. Monte Carlo simulations with 50,000 times and a $9 5 \%$ confidence interval were carried out to obtain the probability distribution of data from each stage and obtain the uncertainty of the final LCA product (Supplementary Fig. 8)87.

Because the calculation of the footprint using LCA includes different stages with the use of data from different sources at different stages, there are several uncertainties associated with data collection at each stage, it is hard to account for all possible data uncertainties in LCA. Hence, the accuracies of LCA results are highly prone to errors arose from these uncertainties. This study used the data quality evaluation standard to evaluate the quality of data for agricultural production and the parameters during each stage of the South-to-North Water Transfer Project based on each element. Scoring was performed based on a DQIbased scoring system. Based on the original data quality matrix, the footprint results of each stage were simulated to determine the distribution type, and the uncertainty $U _ { 0 }$ of the original data under this distribution type was obtained. The data uncertainty from each stage was found to be between 3 and $6 \%$ , well below the $1 0 \%$ threshold. Hence, the data used in this study were reliable88.

Reporting summary. Further information on research design is available in the Nature Research Reporting Summary linked to this article.

