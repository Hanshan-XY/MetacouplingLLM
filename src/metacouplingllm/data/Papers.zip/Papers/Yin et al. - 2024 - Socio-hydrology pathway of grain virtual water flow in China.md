# Socio-hydrology pathway of grain virtual water flow in China

![](images/e076afcd0834c0737fc60192406e65e463d8fb4313087ecfb72d1cb6ad8c16d2.jpg)

Yali Yin a,b,c, Jiajun Tong a,b,c, Jiali Gu a,b,c, Shikun Sun a,b,c,\*, Jingxin Sun a,b,c, Jinfeng Zhao a,b,c, Yihe Tang a,b,c, Pute Wu a,b,c, Yubao Wang a,b,c, Zhaodan Wu d

<sup>a</sup> Key Laboratory for Agricultural Soil and Water Engineering in Arid Area of Ministry of Education, Northwest A&F University, Yangling 712100, Shaanxi, China   
<sup>b</sup> College of Water Resources and Architectural Engineering, Northwest A&F University, Yangling 712100, Shaanxi, China   
c Institute of Water Saving Agriculture in Arid regions of China, Northwest A&F University, Yangling 712100, Shaanxi, China   
$^{\mathrm{d}}$ Business School, Hohai University, Nanjing 211100, China

# ARTICLEINFO

Handling Editor - Dr Z Xiying

Keywords:

Grain virtual water flows

Socio-hydrology

Metacoupling framework

Driving mechanism

China

# ABSTRACT

As the world's largest grain producer, China's activities in virtual water trade for grain are particularly noteworthy. The imbalance of grain production and consumption among regions poses challenges to agricultural development and the sustainable use of water resources. Most of the previous research focused on the driving analysis of factors affecting agricultural water use at the production end. It is necessary to further explore the driving factors of virtual water flow (VWF) caused by grain trade on the consumption side, and consider the impact of production and consumption on the entire process of agricultural water use. This study combines the Logarithmic Mean Divisia Index (LMDI) index decomposition method and multiple regression model to analyze the main natural and social driving factors of VWF. The study also initiates the construction of an analytical framework for the dynamic interaction of coupled social hydrology and Metacoupling systems. The results indicate that economic growth is the primary driver behind the increase in VWF. The water intensity effect and industrial structure effect act as constraints on VWF. Notably, water intensity has the most significant negative effect, with contributions of $-118.9\mathrm{Gm}^3$ and $-192.4\mathrm{Gm}^3$ to the virtual water output and input areas, respectively. Conversely, the economic, demographic, and dependence effect play a promoting role. Among these, the positive economic effect far exceeds population and dependence effects, contributing $189.7\mathrm{Gm}^3$ and $231.3\mathrm{Gm}^3$ to the virtual water output and input areas, respectively. The analytical framework of coupled social hydrology and the dynamic interaction of Metacoupling systems reveals that VWF couples water resources with multiple systems through the production-consumption-pollution chain. Simultaneously, it achieves long-distance interactions across spaces through cross-space VWF, exhibiting socio-hydrological interactions. The input area displays a forward cycle, while the output area exhibits the opposite. These findings can serve as a theoretical reference for controlling grain VWF.

# 1. Introduction

Along with the rapid urbanization and industrialization, continuous population and economic growth, and the acceleration of global warming, the problems of water scarcity are becoming more and more prominent (Hogeboom, 2020). The escalating global demand for grain, coupled with the intensifying water shortages, poses significant challenges to agricultural production as regions strive for grain self-sufficiency (Cheng et al., 2023). The introduction of the concept of virtual water and water footprint and subsequent related studies provide a new perspective to ensure water security and its sustainable use (Qian et al., 2018). As a

strategy to address grain shortages, the international community has increasingly turned its focus to grain virtual water trade (D'Odorico et al., 2019). Nevertheless, the long-distance linkages associated with regional grain trade may exacerbate and disseminate the environmental and resource impacts of grain production (Sun et al., 2019). Hence, the paramount challenge lies in comprehending the pattern of inter-regional virtual water flow and its driving mechanisms. It is crucial to investigate how to judiciously allocate agricultural water resources to support a sustainable socio-economic-ecological-environmental cycle, grounded in the principles of the virtual water strategy.

Virtual water (VW) is used to describe the amount of water

consumed in the production of products or services (Allan, 1993), and water footprint (WF) refers to the total amount of direct or indirect water contained in the products and services consumed in a region (Hoekstra et al., 2011). Since then, researchers gradually realized the importance of virtual water and water footprint for balancing regional and global water security and started to find solutions to water problems from social and economic perspectives (Sun et al., 2019; Sun et al., 2022). Virtual water trade plays a key role in filling regional water supply and demand gaps, and as a water-intensive commodity, food trade leads to regional virtual water flow (VWF). According to virtual water theory, when virtual water is transferred from areas with higher water productivity to areas with lower water productivity, it could contribute to water savings at regional and even global scales (Chapagain et al., 2006). In accounting for virtual water trade in agricultural products, a water footprint approach is often used, such as using CROPWAT, GEPIC, H08, and other crop models to calculate WF and VWF. The WF and VWF data used in this study were calculated by these methods, as described in Sun et al. (2019). Other studies have combined input-output models to assess VWF for different industries (Fu et al., 2021).

In recent years, researches on VW trade have gradually shifted from quantifying VW trade flows and water saving benefits to VWF mechanisms, including economic and environmental impact assessment and multi-disciplinary analysis of driving mechanisms, with multidisciplinary integration to expand the scope of VW research. In terms of analyzing the driving mechanisms of VWF, the more widely applied methods are trade gravity model (Tamea et al., 2014; Fracasso, 2014), index decomposition analysis (Cai et al., 2019), multiple linear regression (Chouchane et al., 2018), and comparative advantage theory (Zhao et al., 2019). Since agriculture is the most water-intensive sector, with direct agricultural water use accounting for nearly $70\%$ of total global water use. When indirect water use in production and supply chains is taken into accounted, agriculture accounts for $92\%$ of global freshwater consumption (Hoekstra and Mekonnen, 2012). Cao et al. (2020) combined the water footprint and agricultural water use paradigms and constructed a hybrid framework for agricultural water utilization and efficiency evaluation. Therefore, a large number of studies have attempted to assess international VW transfers due to agricultural trade, including bilateral VW trade in agricultural products between multiple countries (Duarte et al., 2019) or the dynamics of VW imports and exports in a region (Fracasso et al., 2016). Other studies have attempted to reveal VWF mechanisms at the national or intra-regional level, such as the inter-provincial virtual water flow patterns in China (Huang et al., 2021). The results of studies on the mechanisms driving show that VWF are driven by multiple factors, such as soil and water resource endowments, population, GDP, geographic characteristics (Duarte et al., 2019), consumption patterns (Souissi et al., 2019; Qian et al., 2020), trade policies (Konar et al., 2016), industrial structure (Sun et al., 2022) and climate change (Song et al., 2020).

As a large population country, it is crucial to ensure food security in China. Agricultural water consumption accounts $65\%$ of the country's total water consumption, which is a significant proportion of China's water consumption structure, so water shortage is one of the bottlenecks limiting China's agricultural production and food security (Kang et al., 2016). Many scholars have evaluated the VWF phenomenon in the process of regional transfer of grain through VW theory, and found that the flowed from the water-poor northern region to the water-rich southern region, and this pattern increased the water stress, and affected the economic and environmental level of the export region, leading to unreasonable or contradictory water resources consequences (Sun et al., 2019). Based on the multidimensional investigation on the impact of VWF, Cao et al. (2023) established a framework for impact analysis of virtual water flow in consideration of blue, green and grey water differentiation. In a long-term perspective, the current VWF pattern is unsustainable to some extent. Therefore, it is necessary to analyze the main driving factors of inter-regional grain VWF to

understand the unreasonable VWF pattern, reduce the impact of VWF on regional water shortage, and provide a basis for agricultural water resources management (Qian et al., 2020).

Previous studies on the driving mechanism of grain VWF mostly revealed from the perspective of pure import and export, which may ignore potential problems. While the study from system interactions based on a socio-hydrology perspective will bring new insights. Sociohydrology regards human-water interaction as a complex process of mutual feedback that requires the integration of multiple systems to achieve interdisciplinary research (Savenije et al., 2014). Small changes in one system will bring about dynamic changes in other systems, with unpredictable consequences. In addition, human-water interaction can occur not only within a socio-hydrological system, but also between distant systems or adjacent systems. The grain VW trade expands and complicates the interaction scale and scope of the human-water system, covering multiple fields, and comprehensive management must be carried out on a global scale to avoid unintended consequences.

The purpose of this paper is to approach the socio-hydrological perspective by viewing the import and export regions as two independently yet coupled intertwined socio-hydrological systems, which interact with each other through the grain VWF, and water and other resources are transferred through agricultural products trade. The dynamics of inter-provincial VWF in Chinese mainland and their driving mechanisms are explored from the viewpoint of system coupling, so as to reveal the system interaction processes and potential developmental changes that exist in the VWF framework, and to clarify the trade-offs of water resource allocation in different industries and regions. The main contents include: Section 2 introduces the data sources and methods, Section 3 describes and analyzes the research results, Section 4 provides some discussions, and Section 5 gives the main conclusions of the paper.

# 2. Data and methods

# 2.1.Data

The study area of this paper included 31 provinces, autonomous regions and municipalities directly under the central government in Chinese mainland, excluding Taiwan, Hong Kong and Macao for lack of data, and the time series was from 1997 to 2014 (Fig S1). Water resources data were obtained from China Water Resources Bulletin (1997-2014), agricultural data, economic data and population data were obtained from China Statistical Yearbook (1998-2015), meteorological data were obtained from China Meteorological Data Service Center (http://data.cma.cn/), and data on grain VWF were obtained from Sun et al. (2019).

# 2.2. Methods

# 2.2.1. LMDI decomposition method

The Logarithmic Mean Divisia Index (LMDI) decomposition model is an effective tool for analyzing the mechanism of changes in resource or energy use (or consumption). The fundamental concept revolves around quantifying the extent of the impact that alterations in each independent variable have on changes in the dependent variable. This is achieved by breaking down the changes in the dependent variable into the cumulative effect of changes in each associated independent variable (Ang, 2015). In this study, a quantitative analysis (LMDI) was conducted to examine the primary factors influencing changes in VWF associated with grain (Ang, 2004). This model considers Water Use Intensity Effect (IE), Industrial Structure Effect (ISE), Economic Effect (EE), Population Effect (PE), and Dependency Effect (DE)—as factors to assess their respective impacts on variations in inter-provincial grain VWF. The decomposition of inter-provincial VWF is detailed as follows.

$$
V W F _ {i j} = \frac {W F _ {i}}{A P V _ {i}} \times \frac {A P V _ {i}}{G D P _ {i}} \times \frac {G D P _ {i}}{P _ {i}} \times P _ {i} \times \frac {G _ {i j}}{G P _ {i}} \tag {1}
$$

Where $VWF_{ij}$ is grain virtual flow from regionitoj, $(Gm^3)$ ; $\frac{W F_i}{APV_i}$ is water footprint to agricultural output ratio $(m^3 /Yuan)$ , representing water intensity (IE); $\frac{APV_i}{GDP_i}$ is the proportion of regional agricultural output value, representing the industrial structure effect (ISE); $\frac{GDP_i}{P_i}$ is regional GDP per capita $(10^{4}\text{Yuan/capita})$ , representing the economic effect (EE); $P_i$ is total population in regioni, $(10^{4}\text{capita})$ , representing the population effect (PE); $\frac{G_{ij}}{GP_i}$ is the proportion of grain output to grain production, representing the dependence effect (DE). From stage T-1 to stage T, the influencing factors of the virtual water flow variation can be decomposed into five parts:

$$
\Delta V W F _ {i j} = V W F _ {i j} ^ {T} - V W F _ {i j} ^ {T - 1} \tag {2}
$$

$$
\Delta V W F _ {i j} = \Delta V W F _ {I E, i j} + \Delta V W F _ {I S E, i j} + \Delta V W F _ {E E, i j} + \Delta V W F _ {P E, i j} + \Delta V W F _ {D E, i j} \tag {3}
$$

The contribution of the five drivers is calculated as follows:

$$
\Delta V W F _ {I E, i j} = L \left(V W F _ {i j} ^ {T}, V W F _ {i j} ^ {T - 1}\right) \times \frac {W F _ {i} ^ {T} / A P V _ {i} ^ {T}}{W F _ {i} ^ {T - 1} / A P V _ {i} ^ {T - 1}} \tag {4}
$$

$$
\Delta V W F _ {I S E, i j} = L \left(V W F _ {i j} ^ {T}, V W F _ {i j} ^ {T - 1}\right) \times \frac {A P V _ {i} ^ {T} / G D P _ {i} ^ {T}}{A P V _ {i} ^ {T - 1} / G D P _ {i} ^ {T - 1}} \tag {5}
$$

$$
\Delta V W F _ {E E, i j} = L \left(V W F _ {i j} ^ {T}, V W F _ {i j} ^ {T - 1}\right) \times \frac {G D P _ {i} ^ {T} / P _ {i} ^ {T}}{G D P _ {i} ^ {T - 1} / P _ {i} ^ {T - 1}} \tag {6}
$$

$$
\Delta V W F _ {P E, i j} = L \left(V W F _ {i j} ^ {T}, V W F _ {i j} ^ {T - 1}\right) \times \frac {\boldsymbol {P} _ {i} ^ {T}}{\boldsymbol {P} _ {i} ^ {T - 1}} \tag {7}
$$

$$
\Delta V W F _ {D E, i j} = L \left(V W F _ {i j} ^ {T}, V W F _ {i j} ^ {T - 1}\right) \times \frac {G _ {i j} ^ {T} / P _ {i} ^ {T}}{G _ {i j} ^ {T - 1} / P _ {i} ^ {T - 1}} \tag {8}
$$

$$
L \left(V W F _ {i j} ^ {T}, V W F _ {i j} ^ {T - 1}\right) = \frac {V W F _ {i j} ^ {T} - V W F _ {i j} ^ {T - 1}}{\ln V W F _ {i j} ^ {T} - \ln V W F _ {i j} ^ {T - 1}} \tag {9}
$$

$\Delta VWF_{IE,ij}$ 、 $\Delta VWF_{ISE,ij}$ 、 $\Delta VWF_{EE,ij}$ 、 $\Delta VWF_{PE,ij}$ 、 $\Delta VWF_{DE,ij}$ 值 denotes the contribution values of water use intensity effect IE, industrial structure effect ISE, economic effect EE, population effect PE, and dependence effect DE on the influence of inter-provincial grain VWF change volume, respectively. If the contribution value of the influencing factor is positive, it means that the factor shows an incremental effect on the virtual water flow change, and vice versa, it shows a decremental effect.

Since the LMDI decomposition formula contains logarithmic terms, the variables cannot be negative. In order to eliminate the problem of negative and zero values, all negative and zero values were replaced by a positive number $(10^{-20})$ tending to 0 in this study (Ang, 2005).

# 2.2.2. Multiple regression model

In order to comprehensively identify the macro factors influencing grain virtual water flow, this study, based on the Logarithmic Mean Divisia Index (LMDI) decomposition, expanded the variables considering socio-hydrology theory to elucidate each driving effect. It employed a multiple regression model to investigate the impact of each variable on changes in grain virtual water flow. Therefore, this study selected cultivated land area per capita (PCA, ha/capita) and water resources per capita (PCW, $\mathrm{m}^3/\mathrm{capita}$ ) to explain the water intensity effect (IE). For the industrial structure effect (IES), the study employed chemical fertilizer application intensity (FI, $10^{4}$ tons), agricultural machinery efficiency (ME, $10^{4}$ KW) and the agricultural expenditures ratio (AFE, %). The economic effect (EE) was explained by variables such as the unemployment rate (UR, %) and urban disposable income per capita (PCDI, $10^{3}$ CNY). The population effect (PE) was explored using agricultural population (AGP, $10^{4}$ capita), burden coefficient (DC, the ratio

of the non-working population to the working population in the overall population, $\%$ ), and floating population $(10^{4}$ capita). Finally, the dependence effect (DE) was explicated using the grain sown area $(10^{3}$ ha) (Fig. 1).

To analyze the VWF patterns, this study interpreted the relationship between net virtual water outflow (NVWE) and net virtual water inflow (NVWM) and selected independent variables by building a multiple regression model. The multiple regression equation for each variable is as follows:

$$
\begin{array}{r l} N V W E & = \alpha + \beta_ {1} A G P + \beta_ {2} D C + \beta_ {3} F P + \beta_ {4} F I + \beta_ {5} M E + \beta_ {6} U R \\ & + \beta_ {7} P C D I + \beta_ {8} S A + \beta_ {9} P C A + \beta_ {1 0} P C W + \beta_ {1 1} A F E + \varepsilon \end{array} \tag {10}
$$

$$
\begin{array}{r} N V W M = \alpha + \beta_ {1} A G P + \beta_ {2} D C + \beta_ {3} F P + \beta_ {4} F I + \beta_ {5} M E + \beta_ {6} U R \\ + \beta_ {7} P C D I + \beta_ {8} S A + \beta_ {9} P C A + \beta_ {1 0} P C W + \beta_ {1 1} A F E + \varepsilon \end{array} \tag {11}
$$

where $\alpha$ is a constant term, $\beta_{1}\beta_{2}\cdot \beta_{11}$ is the regression coefficient, $\varepsilon$ is the random error term.

To prevent the problem of high collinearity between individual independent variables, this study developed different regression models to incorporate different subsets of independent variables into the model and minimize the collinearity of the model.

modelI :

$$
N V W E = \alpha + \beta_ {1} A G P + \beta_ {2} D C + \beta_ {3} M E + \beta_ {4} U R + \beta_ {5} S A + \beta_ {6} P C W + \varepsilon
$$

modelII:

$$
N V W E = \alpha + \beta_ {1} F P + \beta_ {2} F I + \beta_ {3} P C D I + \beta_ {4} P C A + \beta_ {s} A F E + \varepsilon
$$

model III :

$$
N V W M = \alpha + \beta_ {1} A G P + \beta_ {2} D C + \beta_ {3} M E + \beta_ {4} U R + \beta_ {5} S A + \beta_ {6} P C W + \varepsilon
$$

model IV:

$$
N V W M = \alpha + \beta_ {1} F P + \beta_ {2} F I + \beta_ {3} P C D I + \beta_ {4} P C A + \beta_ {5} A F E + \varepsilon
$$

Using the ordinary least squares (OLS) regression analysis model, the net VWF in inflow and outflow area and the panel data of each explanatory variable were analyzed to reveal the driving mechanism of each explanatory variable to the VWF.

# 3. Results

# 3.1. Regional grain virtual water flow and economic population distribution

This study conducted a comprehensive and systematic analysis of agricultural production patterns, the spatiotemporal evolution characteristics of the economic population, and the features of inter-regional grain virtual water flow. The findings indicate a distinct trend of opposing distribution between water and land resources. Cultivated land resources are predominantly concentrated in the north, while water resources are primarily distributed in the south. The northern region plays a pivotal role in national grain production, contributing significantly with $55.9\%$ of grain production concentrated in the Northeast and the Huang-Huai-Hai region. Over time, there was a discernible shift in the focus of agricultural production towards the northern region. From 1997 to 2014, the GDP and urban disposable income per capita of all provinces in mainland China showed a year-by-year growth trend. Notably, the economic growth rate in the eastern coastal areas surpassed that in the western regions. Economic growth has resulted in a substantial influx of population, with inter-provincial population movements gravitating towards the eastern coastal areas, particularly the southeastern coast. The scale of population flow has exhibited a notable increasing trend over time. Changes in the economic and population exerted a notable influence on the evolution of grain production and consumption patterns. $57.9\%$ of the population's grain consumption is

![](images/5054a50dda38063c18b731131357eb3adef2252bab4e7eace07358e4d2ad05be.jpg)  
Fig. 1. The macro-influencing factors of virtual water flow.

concentrated in the southern regions. The imbalance between grain production and consumption become increasingly pronounced (Supplementary Results, Fig S2-S6). Driven by the combined forces of economic growth and population dynamics, the inter-provincial grain VWF in China showed an increasing trend year by year, from $72.89\mathrm{Gm}^3$ in 1997 to $121.46\mathrm{Gm}^3$ in 2014. Heilongjiang was the largest VW outflow area, with net VW outflow increasing from $24.36\mathrm{Gm}^3$ in 1997 to 56.62 $\mathrm{Gm}^3$ in 2014, followed by Jilin, Inner Mongolia, Henan and Anhui. Guangdong was the largest VW inflow area, with net VW inflow increasing from $18.85\mathrm{Gm}^3$ in 1997 to $75.74\mathrm{Gm}^3$ in 2014, followed by Zhejiang, Fujian, Shanghai and Guangxi. Jiangsu and Sichuan gradually changed from VW outflow areas to VW inflow areas, and Liaoning and Hubei continued to switch between VW outflow areas and VW inflow areas (Fig. 2a). In terms of the grain VWF direction, the VW of Heilongjiang, the largest outflow area, mainly flowed to Guangdong, Zhejiang, Fujian, Shanghai and Beijing. The virtual water outflow to each province in 2010 was $14.86\mathrm{Gm}^3$ , $7.33\mathrm{Gm}^3$ , $4.27\mathrm{Gm}^3$ , $4.14\mathrm{Gm}^3$ and $3.59\mathrm{Gm}^3$ , respectively. The main sources of grain VW in Guangdong, the largest inflow area, were from Heilongjiang, Jilin, Inner Mongolia, Anhui and Henan. The VW inflow from each province in 2010 was $14.86\mathrm{Gm}^3$ , $5.99\mathrm{Gm}^3$ , $4.39\mathrm{Gm}^3$ , $3.06\mathrm{Gm}^3$ and $4.04\mathrm{Gm}^3$ (Fig. 2b). From the perspective of interannual variation, the net virtual water outflow from the major virtual water outflow areas and the net VW inflow from the

major virtual water inflow areas generally showed an increasing trend year by year (Fig. 2c).

# 3.2. Decomposition analysis of virtual water flow variation between regions

In order to analyze the driving factors of regional VWF changes, this paper used LMDI decomposition method and OLS regression analysis to explore the driving effects of changes in water intensity, industrial structure, economy, population, and grain import and export dependence on inter-provincial grain VWF in Chinese mainland from 1997 to 2014. The decomposition results of the total effects of the inflow and outflow areas are shown in Fig. 3: On the whole, the intensity of each effect in the VW inflow area was significantly greater than that in the outflow area. Water use intensity and industrial structure had strong negative effects on the grain VWF. Their contribution to the VW outflow of the export area was $-118.9\mathrm{Gm}^3$ and $-40.0\mathrm{Gm}^3$ and the contribution of VW inflow in the import area was $-192.4\mathrm{Gm}^3$ and $-99.4\mathrm{Gm}^3$ , respectively. Economy, population and grain dependence had obvious positive effects on VWF, among which the positive driving effect of economic growth was the most prominent, and the population driving effect was relatively weak. The three effects contributed $189.7\mathrm{Gm}^3$ , $4.4\mathrm{Gm}^3$ and $20.1\mathrm{Gm}^3$ to the VW outflow in the export area and $231.3\mathrm{Gm}^3$ ,

![](images/3a92ba9090d92f88406acb20d6bab4dff84dff5628a0fbfaf766d7478e89b65c.jpg)  
(a)

![](images/2ec5de014201e83883c754cef25fa230f55b72724c7ce76df33bd24562e5f5fe.jpg)

![](images/54dbc2834ae0e54aec4a50236b480a4def656029f285aaa4436891ce5c6d31fd.jpg)

0.04-7.11   
7.11-14.18   
14.18-21.25   
21.25-28.33   
28.33-35.40   
35.40-42.47   
13474954   
42.47-49.54   
49.54-56.62

![](images/65622f6941fda3104bcd444cac22e28adee9a5e15ef15f54bec38babd0d8b66b.jpg)

0.05-9.51   
9.51-18.97   
18.97-28.43   
28.43-37.89   
37.89-47.36   
47.36-56.82   
56826628   
30.82-06.28   
66.28-75.74

![](images/bb2c1881e7551ae258ebe12a7d8aa33f54a4e083679137915d4c9c306e3f5023.jpg)  
(b)

![](images/265ccdbef933012f94cd412019852cfe6cbec7f3b281b7668b3d5ecc089fb55e.jpg)  
(c)   
Fig. 2. The virtual grain water (a) net flow (b) main flow direction (c) interannual variation in provinces in mainland China from 1997 to 2014.

![](images/e92a3c76ca8e043e4b921a4b917eccebf092e7d9fb6c43ae6aa5f014eab9d6c1.jpg)  
Fig. 3. Decomposition results of the total effect of inflow and outflow areas.

31.9 $\mathrm{Gm}^3$ and 137.1 $\mathrm{Gm}^3$ to the VW inflow in the import area, respectively.

Broadly, the water intensity effect and industrial structure effect inhibit the inter-provincial grain virtual water flow, while the economic effect, population effect, and dependence effect play a facilitating role. Examining the time series, it becomes apparent that the contribution intensity of each driving effect to the inflow area significantly surpasses that of the outflow area. Notably, the population effect and dependence effect emerge as the primary contributors to the inflow area, accounting for $88\%$ and $87\%$ , respectively. Conversely, the economic effect exhibits

the lowest contribution intensity at $55\%$ (Fig. 4). Except for 1998, 1999, and 2006, water use intensity consistently demonstrated a pronounced negative driving force. Despite enhancements in water productivity leading to increased grain production, a noteworthy grain VWF among regions occurred. This shift can be attributed to the complex interplay of factors such as variations in consumption demand resulting from population movements and changes in agricultural production due to industrial restructuring. The industrial structure effect consistently exhibited a robust negative driving influence in most years. Despite similar levels of industrial development and demand for non-

![](images/d12feb199ab05e9437623ffcce27be511eec84ad9fad552fad2974606c0989c7.jpg)  
Fig. 4. Time series analysis and regional contribution of total effect decomposition.

agricultural grain consumption in the outflow areas, economic and demographic disparities arising from differences in industrial structure led to the VW export. The economic effect consistently exhibits a strong positive driving force throughout the time series, demonstrating a discernible upward trend from year to year. This implies that the grain virtual water flow expands concomitantly with economic growth. The population effect similarly shows a positive driving force and sustains at a consistent level over time. The scale of the grain VWF expands in response to population growth. In general, grain dependence plays a consistently positive driving role in most time. In specific years, such as 1998, 2003, 2009, and 2011, slightly weaker negative effects are observed.

Using OLS regression analysis, the panel data of VW outflow and inflow area were tested by F test and Hausman test, respectively. The results showed Prob $> \mathrm{F} = 0.0000$ and Prob $< 0.01$ , rejecting the original hypothesis and using a fixed effects model. The individual fixed effects regression was performed on the panel data, and the results of the regression analysis are shown in Table 1.

The regression results showed that each model had a relatively significant explanatory strength for assessing the drivers of VWF. Model I and II estimated the contribution of each explanatory variable related to the net VW outflow. In Model I, APG, ME, UR, SA, and PCW all had a significant positive driving effect on the grain VW outflow in export areas, and all explanatory variables except PCW have a $99\%$ confidence interval. In Model II, all the explanatory variables exhibited extremely strong significance with $99\%$ confidence intervals. FP, FI and PCA all had a significant positive driving effect on grain VW outflow. PCDI and AFE showed a significant negative driving effect on grain VW outflow in export areas.

Model III and Model IV estimated the contribution of each explanatory variable related to the net VW inflow. In Model III, PCW showed a weak positive driving effect, that was, the increase of water resources per capita did not inhibit the VW inflow. In addition, the other variables showed a relatively obvious negative driving effect, among which SA showed a strong significance with a confidence interval of $99\%$ . In Model IV, FP, FI and PCDI had positive driving effects on the grain VW inflow, and the confidence intervals are all $99\%$ .

# 3.3. Grain virtual water flow analysis based on coupled socio-hydrology and Metacoupling framework

Based on the inter-provincial grain VWF pattern and its driving factors in China, combined with the results of LMDI decomposition analysis and multiple regression analysis, this paper preliminarily constructed a regional grain VWF analysis perspective based on sociohydrology and Metacoupling framework. From the perspective of system coupling, this study revealed and analyzed the socio-hydrological interaction of inflow and outflow areas in the process of grain VWF. Fig. 5 shows how each driving element interacted and affected the dynamics of VWF within the framework, and how the systems interacted across regions through element flow.

Resource costs and technology inputs were key factors in improving agricultural production efficiency. By investing in water-saving irrigation, optimizing land and labor resources, and employing chemical fertilizers, pesticides, and agricultural machinery on a large scale, agricultural water consumption has been effectively managed. This has resulted in a significant increase in grain output and improved water production efficiency. The green dotted box in the figure symbolizes the water intensity effect, exerting a negative driving influence on both the VW outflow area and inflow area. For outflow areas, the expansion of production factors was realized by improving production efficiency. While for inflow areas, the improvement of agricultural production efficiency resulted in the transfer of additional production factors to non-agricultural industries, further expanding the proportion of non-agricultural industries. The purple dotted box in the figure denotes the economic effect, exhibiting a positive driving force in both the grain outflow area and inflow area. Economic development has led to an industrial division of labor, promoting agricultural technological progress and increased financial subsidies for agriculture-related fields. However, the contribution and growth rate of non-agricultural industries in wealth accumulation and economic growth surpass those of agriculture. The orange dotted box in the figure represents the industrial structure effect, playing a negative driving role in both the grain outflow area and inflow area. When the difference in production efficiency between agriculture and non-agricultural industries increased, the proportion of agricultural

Table 1 Results of OLS regression analysis.   

<table><tr><td rowspan="2">Variables</td><td colspan="2">Exporters</td><td colspan="2">Importers</td></tr><tr><td>I</td><td>II</td><td>III</td><td>IV</td></tr><tr><td rowspan="2">AGP</td><td>0.006048 ***</td><td></td><td>-0.005283 *</td><td></td></tr><tr><td>(5.012220)</td><td></td><td>(-1.806489)</td><td></td></tr><tr><td rowspan="2">DC</td><td>-0.155753 ***</td><td></td><td>-0.366833 ***</td><td></td></tr><tr><td>(-3.152302)</td><td></td><td>(-6.303619)</td><td></td></tr><tr><td rowspan="2">ME</td><td>0.000591 ***</td><td></td><td>-0.000795</td><td></td></tr><tr><td>(3.138201)</td><td></td><td>(-1.209884)</td><td></td></tr><tr><td rowspan="2">UR</td><td>0.160581 ***</td><td></td><td>-0.074874 **</td><td></td></tr><tr><td>(5.251098)</td><td></td><td>(-1.999212)</td><td></td></tr><tr><td rowspan="2">SA</td><td>0.005733 ***</td><td></td><td>-0.007316 ***</td><td></td></tr><tr><td>(18.81669)</td><td></td><td>(-5.690137)</td><td></td></tr><tr><td rowspan="2">PCW</td><td>0.000618 **</td><td></td><td>0.000134 **</td><td></td></tr><tr><td>(2.056664)</td><td></td><td>(2.272055)</td><td></td></tr><tr><td rowspan="2">FP</td><td></td><td>0.002642 ***</td><td></td><td>0.007478 ***</td></tr><tr><td></td><td>(5.463817)</td><td></td><td>(7.610066)</td></tr><tr><td rowspan="2">FI</td><td></td><td>0.041574 ***</td><td></td><td>0.044638 ***</td></tr><tr><td></td><td>(7.311107)</td><td></td><td>(3.087629)</td></tr><tr><td rowspan="2">PCDI</td><td></td><td>-0.167637 ***</td><td></td><td>0.185516 ***</td></tr><tr><td></td><td>(-5.051935)</td><td></td><td>(4.595101)</td></tr><tr><td rowspan="2">PCA</td><td></td><td>1.037278 ***</td><td></td><td>0.035338</td></tr><tr><td></td><td>(14.34709)</td><td></td><td>(0.135849)</td></tr><tr><td rowspan="2">AFE</td><td></td><td>-0.234310 ***</td><td></td><td>-0.027850</td></tr><tr><td></td><td>(-4.214960)</td><td></td><td>(-0.256874)</td></tr><tr><td rowspan="2">C</td><td>-34.84259 ***</td><td>-12.57912 ***</td><td>42.35502 ***</td><td>-0.986471</td></tr><tr><td>(-10.31125)</td><td>(-8.811531)</td><td>(12.25306)</td><td>(-0.484952)</td></tr><tr><td>R²</td><td>0.94</td><td>0.94</td><td>0.87</td><td>0.87</td></tr></table>

Note: (1) $t$ statistics in parentheses   
(2) $^* p <   0.1$ $^{**}p <   0.05$ $^{**}p <   0.01$

Fig. 5. Virtual water flow framework: socio-hydrological interactions in inflow and outflow areas.   
![](images/9784ee2f3fc7a7831cecc4782ac772a9b32a3d64cfed156598ad3cc90d1dde87.jpg)  
Note: The dashed boxes in each color in the figure represent different driving effects, the orange, blue, green, purple and red in this figure represent the industrial structure effect, dependency effect, water intensity effect, economic effect and population effect, respectively.

production in GDP decreased and agricultural labor shifted to nonagricultural industries. The red dotted box in the figure represents the population effect, which plays a positive driving role in both grain outflow area and inflow area. The economic development level in most outflow areas is relatively low, whereas is relatively high in inflow areas. Local labor force outflow is limited, and the social wealth generated by abundant labor resources further encourages the influx of external labor force. The blue dotted box in the figure represents the dependence effect, which plays a positive driving role in both the outflow area and inflow area. Economic development and population mobility have further accelerated the widening gap between grain supply and demand, gradually exacerbating the separation of grain production and marketing in China. For the virtual water output area, along with the grain output, a large amount of water resources flow out of the area along with the grain trade. From the perspective of social hydrology, water resources are not only influenced in the natural system, but are also impacted by the feedback from the consumption link in the social and economic system.

# 4. Discussion

Many studies explored grain virtual water flow and its driving factors at regional or global scales through diverse methodologies (Fracasso et al., 2016; Duarte et al., 2019; Zhao et al., 2019; Cai et al., 2019; Song et al., 2020). While many have yielded insightful and consistent findings regarding the interpretation of grain VWF, there exist disagreements that warrant further exploration. It's essential to note that in prior investigations on the driving mechanisms of grain VW, the inflow and outflow areas were typically treated as unified entities. Alternatively, some studies discussed either the inflow or outflow areas in isolation, quantifying the impact of selected driving variables through quantitative research. Building upon the quantification of the driving mechanisms of grain VW, this study investigated the inflow and outflow areas of grain VW between provinces in mainland China from socio-hydrology and the Metacoupling framework. By treating the VW outflow and inflow areas as two interconnected social and hydrological systems, this research interpreted the driving mechanism of cross-regional grain VWF and elucidated potential system changes within the flow process from a

system interaction perspective.

# 4.1. Analysis of influencing factors of grain virtual water in inflow area and outflow area

According to the research results, the influence factors of VW outflow area and inflow area were obviously different. Fig. 6 and Fig. 7 showed the decomposition results of the inter-provincial variation of VWF in the outflow and inflow areas. For outflow areas, changes in water use intensity play an inhibitory effect on VW outflow, which is because the decrease in water use intensity implies an increase in water production efficiency, thus promoting the increase in grain production and grain VW outflow. The negative effect was most pronounced in Heilongjiang, Jilin and Henan, with contributions of $-47.3\mathrm{Gm}^3$ , $-16.1\mathrm{Gm}^3$ and $-11.7\mathrm{Gm}^3$ to the VWF change, respectively. Except for Heilongjiang, the industrial structure of other outflow regions has negative effects on VW outflow, among which Jilin, Liaoning and Henan have the most significant negative effects, by $-12.6\mathrm{Gm}^3$ , $-10.4\mathrm{Gm}^3$ , and $-7.1\mathrm{Gm}^3$ , respectively. The change in regional grain supply and demand pattern leads to an increase in grain VW inflow in import regions, mainly due to the decrease in the share of agricultural output value resulting in the transfer of a large amount of rural labor to developed coastal cities. The economic effect plays an important positive driving role on grain VW outflow in export areas. Heilongjiang, Jilin and Liaoning have the most significant economic effects, contributing $58.1\mathrm{Gm}^3$ , $34.5\mathrm{Gm}^3$ and $26.6\mathrm{Gm}^3$ to the change of VWF, respectively. On the one hand, economic growth is conducive to improving the level of agriculture, thereby increasing grain production; on the other hand, economic development increases the intensity of fiscal support to agriculture and drives grain production and VW outflow from grain export regions through subsidizing agricultural production and trade circulation. The population effect plays a very weak positive driving role, because grain export of outflow regions is mainly influenced by the consumption demand of inflow regions. The export dependence of most of the major grain producing regions showed a positive driving effect, and the larger the share of grain export in grain production, the larger VW outflow. Heilongjiang, Henan, Jilin and Liaoning have the most significant positive driving effect, contributing $12.6\mathrm{Gm}^3$ , $8.4\mathrm{Gm}^3$ , $5.3\mathrm{Gm}^3$ and $5.2\mathrm{Gm}^3$ to

![](images/0176ebb8c41513d95504246eef9950c1aaf202ec15991b090738f7b46385900a.jpg)  
Fig. 6. Decomposition results of the driving effect of outflow regions.

![](images/8a39bdedaf1ac015ca7b16ca5747109df1e607c51aa4907702c58eea7835a216.jpg)  
Fig. 7. Decomposition results of the driving effect of inflow regions.

the effect of VWF change, respectively.

The results of OLS regression analysis showed that the increase of agricultural population, the improvement of agricultural machinery efficiency, the expansion of grain sown area and the increase of water resources per capita in export areas could drive the grain VW outflow. In the context of the decreasing proportion of output value of agriculture, a large number of rural labor were liberated from agricultural production and transferred to non-agricultural industries. The relatively high unemployment rate in export areas prompted mass migration in search of employment opportunities and move to developed coastal cities, thus promoting changes in the pattern of grain supply and demand. The

increase in fertilizer application intensity and arable land per capita could both promote the grain VW outflow. The increase in population inflow did not curb the VW outflow. This may because the increase of population inflow in the import region also drove the increase in VW inflow, and the driving effect was stronger in the import region than export region, which drove the outflow of the export areas (Model IV). The increase in urban disposable income per capita inhibited the outflow of population from export areas, thereby reducing the grain VW outflow. The share of fiscal support for agriculture was on a slow decline during most of the study period, but it did not curb the grain VW outflow.

For the inflow areas, water intensity also showed a negative driving effect, among which Guangdong, Zhejiang and Fujian had the most significant negative effects, and their contributions to the VWF change were $-74.2\mathrm{Gm}^3$ $-27.1\mathrm{Gm}^3$ and $-17.6\mathrm{Gm}^3$ respectively. Although the improvement of water production efficiency saved water resources, this part of the additional available water resources was not used to expand agricultural production, but was used in other sectors or saved. The expansion of grain demand caused by industrial development and population agglomeration needed to be made up by increasing grain imports. The industrial structure had a negative effect on the VW inflow, among which Guangdong, Zhejiang and Shanghai have the most significant negative effects, and their contributions to the VWF change were $-28.0\mathrm{Gm}^3$ $-15.2\mathrm{Gm}^3$ and $-11.3\mathrm{Gm}^3$ , respectively. The economic effect showed a significant positive driving effect, among which the economic effects of Guangdong, Zhejiang and Fujian were the most significant, contributing $81.6\mathrm{Gm}^3$ $30.2\mathrm{Gm}^3$ and $20.3\mathrm{Gm}^3$ to the change of VWF, respectively.

The population effect also showed a positive driving effect, especially in Guangdong, where the population immigration was the highest, and the contribution to the change of VWF was $14.7\mathrm{Gm}^3$ . The import dependence of most of the grain sales areas showed a positive driving effect. The greater the proportion of grain inflow in grain production, that is, the greater the dependence on the outside, the greater the VW inflow. Guangdong, Zhejiang and Fujian had the most significant positive driving effects, contributing $62.8\mathrm{Gm}^3$ , $28.1\mathrm{Gm}^3$ and $12.8\mathrm{Gm}^3$ to the VWF change, respectively. The VW pattern of the main inflow areas could be explained as follows: With the change of regional industrial structure, the decrease of output value of agriculture, the rapid economic development brought about by industrial division, a large number of foreign labor was attracted. The expansion of grain demand and the imbalance between demand and supply increase the dependence on imports and stimulate the increase of VW inflow.

The results of OLS regression analysis showed that the increase of agricultural population, urban unemployment rate, and grain sown area could restrain the grain VW inflow. The increase in urban disposable income per capita attracted a large number of migrants for employment, and the increase in population inflow promoted grain VW inflow. The increase in the intensity of fertilizer application did not reduce the external VW inflow, which can be explained by the fact that the increase in consumption demand brought about by population inflow was much greater than the agricultural production in the inflow areas, and still required a large amount of grain VW import to fill the supply-demand gap. In both model III and I, DC showed a significant negative driving effect, with a confidence interval of $99\%$ , that is, the increase of the burden coefficient would simultaneously curb the VWF in the inflow and outflow areas.

# 4.2. Analysis of virtual water driving mechanisms in a coupled sociohydrology and Metacoupling framework

Metacoupling encompasses human-nature interactions within a particular system (intracoupling), between adjacent systems (pericoupling), and between distant systems (telecoupling) (Liu, 2023). A system means a coupled human and natural system (Liu et al., 2007), such as a social-ecological system and a human-environmental system. The integration of socio-hydrology into hydrology research, as introduced by Sivapalan et al. (2012), aims to unveil the highly dynamic changes in water systems resulting from human interventions. Socio-hydrology is defined as an interdisciplinary study that delves into the reciprocal feedback mechanisms and co-evolution dynamics inherent in human-water coupled systems. Gu et al. (2021) identified virtual water research as one of the four major thematic areas for disciplinary exploration. This study proposed a Metacoupling framework to elucidate the interconnections between physical water and virtual water based on Liu (2017) (Fig. 8).

From a socio-hydrology perspective, VW expands the properties of

water resources, shifting the research perspective from the traditional hydrology of direct extraction, transfer and consumption of water to the flow of water as an embedded resource in the economy and society, enabling the interaction of multiple systems connected by water consumption and pollution. Conditions that occur within a particular system can affect not only that system, but other systems that are adjacent or distant (Liu, 2017). In the Metacoupling framework of coupled physical-virtual water flow, such system interaction can occur not only at the watershed scale, but also realize the coupling interaction across watersheds and even the global scale through the trade of water-intensive commodities. In other words, in the context of VWF, the interaction between human and water is no longer formed through direct water consumption. At any node in the production supply chain, even between distant consumers and producers, whether planned human activities or unpredictable external disturbances can affect the coupling state of the entire system. This study incorporated the current status and drivers of VWF into this framework to understand the systemic coupling processes and potential developmental changes that exist in China.

There were many studies that have beneficially explored VWF and their drivers at regional or global scales through a variety of different approaches. Many constructive and consistent results have been obtained on the interpretation of VWF, and there are also disagreements that deserve further investigation. However, it should be noted that the interpretation of VWF in previous studies tends to consider the inflow and outflow regions as a unified whole or discuss the inflow or outflow regions separately, rather than taking a systematic view. Based on the socio-hydrological perspective and the Metacoupling framework, this paper regards the VW outflow area and the inflow area as two coupled socio-hydrological systems, and explains the driving mechanism of the VWF across regions from the perspective of system interaction.

Within separate inflow and outflow areas, production resources were allocated to varying degrees through competition between agricultural and non-agricultural industries. A large amount of water resources were embedded into grain products through agricultural production activities and coupled with the socio-economic system through the production-consumption chain. At the same time, the water pollution and water environment damage caused by the application of chemical fertilizers and pesticides in agricultural production activities, and the ecological damage caused by the disorderly occupation of cultivated land strengthened the coupling between the agricultural system and the ecological environment system (Fig. 8). Between inflow and outflow areas, inter-provincial grain VW trade realizes long-distance and cross-regional allocation of water resources, resulting in secondary allocation of water resources (Xu et al., 2020). Through the import and consumption of grain, the coupling of agricultural production and long-distance consumers was realized, thus completing the socio-hydrological interaction between the systems. Not only that, the inflow area saves the production resources of the region by importing grain VW, and the introduction of a large number of labors improves the capability of regional development. These additional available production factors can be used for further economic development, ecological restoration, public service construction, and other non-agricultural activities. Changes in capability have a profound impact on population flow patterns and social consumption levels in the field of ideas and concepts, thus promoting the cross-regional transfer of grain VW. It's an ever-accumulating positive cycle. The VW outflow area is just the opposite. Problems such as freshwater resource consumption, production resource occupation, ecological environment pressure, and economic development obstacles caused by agricultural production reduced the capability of regional development, further caused labor loss, and formed the dilemma of a negative cycle. The imbalance of economic benefits and environmental damage among regions greatly affects the equitable allocation of resources and overall development of regions (Xin et al., 2022).

From the perspective of system coupling, this study captured the

![](images/b1f836f0a58ee82e73149dc6c0baa0d5a0277f01ac91e308278bde0a940456ac.jpg)  
Fig. 8. Metacoupling framework of grain virtual water flow.

Matthew effect of the inflow and outflow areas on the competition of production resources. However, this vicious circle would inevitably lead to unbalanced and unsustainable social development. Studies found that there are many links between the situation in one area and the freshwater demand and supply in other areas (Weiss, 2012). When the water stress in the outflow region reaches a critical point or is disturbed by external factors such as climate change, will it cause the whole coupled system to turn to another trajectory, eventually leading to irreversible consequences? This is still unknown and requires further research. At the current stage, the primary objective is to ensure grain security in China and to control and adjust the negative cycle of the VW outflow area. The government should improve the agricultural production efficiency in grain export regions through technical support and financial subsidies for agriculture, increasing the grain yield per unit of land. Agricultural production in virtual water inflow areas should be encouraged. For the major grain import areas in the southeast coast, food production should be stabilized. At the same time, more agricultural skilled personnel and labor should also be encouraged to move from inflow areas to outflow areas to promote agriculture to be more technology and capital intensive.

# 4.3. Limitation and directions for future research

Compared with previous studies, this research marks a significant expansion in the dimension of variable selection when investigating the driving mechanism of grain VWF. While incorporating fundamental variables, this study also expands other variables related to science and technology, agricultural policy, and social and cultural levels. Furthermore, in the selection of economic or social factors, some factors of potential significance are considered. By broadening the scope of multidimensional variables, this study unveils a comprehensive understanding of the diverse driving factors that influence grain VWF. Secondly, adopting the perspectives of socio-hydrology and the Metacoupling framework, this study conceptualizes the grain virtual water outflow area and the inflow area as two interlinked socio-hydrological systems. These systems engage in interaction through the circulation of grain VW, wherein water resources and other essential resources are transferred by being embedded in agricultural products. Through the lens of system interaction, the research elucidates the

driving mechanism behind the cross-regional grain VWF, delving into potential system changes during the flow process (Blair and Buytaert, 2016).

However, owing to challenges in data acquisition, the time series in this study is relatively short. This limitation hinders the feasibility of conducting a systematic exploration of long-term VWF mechanisms. Additionally, it is essential to note that this study primarily focuses on revealing the system interaction within the process of grain VWF. This is achieved by identifying the driving factors of grain VWF between regions, assessing their significance, and constructing a comprehensive system framework pertaining to grain VWF.

Based on the limitations of the research, the subsequent research should update and expand the dataset with a focus on long-term series data to ensure the temporal coherence and timeliness of the research. It is necessary to comprehensively analyze the mechanism of grain VWF, formulate reasonable grain virtual water control measures, thereby enhancing the overall patterns of VWF. In addition, future studies should consider incorporating relevant variables and system interaction processes into the model. This will help to deeply and systematically reveal the system interaction mechanism of grain VWF, and to clarify how to address resource allocation imbalances between systems and ensure the reliability of continuous grain virtual water flow (Graham et al., 2020).

# 5. Conclusion

This study integrates the Logarithmic Mean Divisia Index (LMDI) index decomposition method with a multiple regression model to analyze the principal natural and social driving factors of grain VWF. It initiates the construction of an analytical framework for the dynamic interaction of coupled social hydrology and Metacoupling systems. The results indicate that economic growth is the primary driver behind the increase in VWF. The water intensity effect and industrial structure effect act as constraints on VWF. The variations in grain production and consumption across regions drive the grain VWF, consequently resulting in imbalances in resource distribution among regions. The driving factors of the input area and the output area are significantly different. The coupling framework of social hydrology and the Metacoupling system reveals that grain VWF is propelled by multi-dimensional variables. The interplay among these variables gives rise to system interactions,

consequently driving dynamic changes within the coupled system. These findings offer valuable insights for guiding the regulation of grain virtual water to ensure the sustainable development of both grain security and water security. Therefore, the mechanism of grain VWF and reasonable grain VW control measures are also influenced by many other factors, which need further investigations.

# Appendix A. Supporting information

Supplementary data associated with this article can be found in the online version at doi:10.1016/j.agwat.2023.108658.

