# Spatial coupling and decoupling between ecosystem services provisioning and benefiting areas Implic

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:09:35.484851+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Vergara et al. - 2021 - Spatial coupling and decoupling between ecosystem services provisioning and benefiting areas Implic.pdf
- Year: unknown
- DOI: 10.1016/j.ocecoaman.2020.105455
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines how marine ecosystem services (ES) supplied in Chilean Patagonia are spatially connected - or disconnected - from the people who benefit from them, and what this implies for marine spatial planning (MSP). The geographic focus is the Magallanes region in southern Chile, including 10 coastal municipalities. The work is explicitly framed within the metacoupling concept, distinguishing interactions within municipalities (intracoupling), among municipalities and neighboring regions (pericoupling), and between the region and distant countries (telecoupling).

The authors develop spatial indicators for five ES: sense of place, food from aquaculture, recreation opportunities, food from artisanal fisheries, and opportunities for education and knowledge. Using diverse spatial datasets (biological, cultural, economic, tourism and research records), they map ES hotspots across roughly 115,000 km2 of marine and coastal space. They then identify direct beneficiaries (local users, consumers, visitors, students, researchers) and indirect beneficiaries (workers in fisheries, aquaculture, tourism, and education) from secondary statistics at the municipal scale. Coupling or decoupling is defined by the co-occurrence or separation of ES hotspots and beneficiaries within and across municipalities; distant ES flows are classified as telecouplings.

Results show strong contrasts among ES. Cultural services (sense of place, education, recreation) are generally spatially aligned with local and visiting beneficiaries, but many recreation and knowledge benefits are captured by outsiders rather than regional residents. Provisioning services from fisheries and salmon farming show pronounced decoupling: most catches and aquaculture production are exported, while local access to fish is limited and some municipalities with high ES supply have almost no local beneficiaries. The Magallanes region thus functions as a large sending system in global seafood, tourism, and science networks, with largely one-way ES flows.

The paper is directly about metacoupling/telecoupling, demonstrating how spatial ES flow analysis can reveal scale mismatches, distributive inequities, and forms of enclosure, and arguing that MSP should explicitly incorporate ES flows to address justice and sustainability concerns.

## Structured Metacoupling Extraction

### Coupling Classification
- Paper explicitly applies metacoupling, analyzing intra, peri, and telecoupled ES flows in Chilean Patagonia

### Intracoupling
#### Systems
- Individual coastal municipalities in Magallanes marine social ecological system
- Municipal marine areas including fjords channels territorial sea
#### Flows
- Ecosystem service flows from local marine provisioning hotspots to local residents
- Flows of employment income within municipal ES value chains
#### Agents
- Municipal governments responsible for coastal microzoning
- Local residents indigenous communities tourists workers
- Aquaculture firms artisanal fishers tourism operators educators
#### Causes
- Spatial distribution of ES hotspots relative to settlements and infrastructure
- Local access institutions property rights and planning instruments
- Connectivity constraints like limited roads ferries expensive flights
#### Effects
- Local coupling for sense of place recreation education in some municipalities
- Local decoupling for aquaculture and artisanal fisheries food provision
- Unequal local access to ES benefits and potential food insecurity

### Pericoupling
#### Systems
- Neighboring municipalities within Magallanes region
- Magallanes region and adjacent Chilean regions
- Magallanes and nearby Argentine territories via land corridors
#### Flows
- Intermunicipal tourism flows to iconic parks and coastal destinations
- Fish and seafood movements between landing ports and processing centers
- Research activities moving among municipalities and nearby regions
#### Agents
- Regional and municipal planners coordinating marine spatial decisions
- Fishers processors transport companies tour operators
- Universities research centers schools NGOs
#### Causes
- Fjords channels straits acting as natural corridors between municipalities
- Regional economic clustering of salmon farms fisheries tourism
- Fragmented governance with many overlapping sectoral agencies
#### Effects
- Some municipalities host ES supply while neighbors capture benefits
- Territorial disputes over aquaculture concessions protected areas indigenous claims
- Intermunicipal inequalities in employment tourism and knowledge opportunities

### Telecoupling
#### Systems
- Magallanes marine ecosystems as sending system
- National Chilean consumer markets outside Magallanes
- International destinations in Asia Europe Americas for fish and tourism
#### Flows
- Large export flows of salmon and wild fish to distant consumers
- Inbound international tourists and cruise passengers for nature tourism
- Outbound knowledge through scientific publications and academic networks
#### Agents
- Export oriented aquaculture and fishing companies
- International tourists tour companies cruise lines
- National and foreign universities research funders NGOs
#### Causes
- Blue growth policies and neoliberal export oriented reforms
- Global demand for seafood and high end nature tourism
- Strategic location as gateway to Antarctic and global shipping routes
#### Effects
- Unidirectional telecoupling where outsiders capture most ES benefits
- Local shortages of fish despite high regional production
- Reinforced dependence on volatile global markets and external capital

### Cross-Coupling Interactions
- Strong telecoupled exports reduce locally available fish exacerbating intracoupled food insecurity
- Pericoupled tourism and telecoupled cruises intensify pressure on local ES hotspots
- Access and enclosure institutions simultaneously shape intra peri and telecoupled ES flows

### Research Gaps or Limitations
- Beneficiaries undercounted due to missing data on informal fisheries and temporary aquaculture jobs
- Difficulty tracing exports from specific landing sites to foreign consumers
- Cultural ES indicators rely on physical proxies and may miss experiential dimensions

### Search Keywords
- Magallanes Chilean Patagonia ecosystem services flows metacoupling
- marine spatial planning spatial coupling decoupling telecoupling salmon aquaculture
- artisanal fisheries tourism sense of place education inequality

### Extraction Confidence
high
