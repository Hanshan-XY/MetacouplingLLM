# LETTER

# The Emerging Soybean Production Frontier in Southern Africa: Conservation Challenges and the Role of South-South Telecouplings

Nestor Ignacio Gasparri<sup>1</sup>, Tobias Kuemmerle<sup>2</sup>, Patrick Meyfroidt<sup>3</sup>, Yann le Polain de Waroux<sup>4</sup>, & Holger Kreft<sup>5</sup>

1 CONICET, Instituto de Ecología Regional, Universidad Nacional de Tucumán, Tucumán, Argentina   
$^{2}$ Geography Department, Humboldt-University Berlin. Integrative Research Institute on Transformations in Human-Environment Systems (IRI THESys) Humboldt-University, Berlin   
<sup>3</sup>F.R.S.-FNRS, Brussels, Belgium & Université Catholique de Louvain, Earth and Life Institute, Georges Lemaitre Centre for Earth and Climate Research, Louvain-La-Neuve, Belgium   
4 Environmental Earth System Science & Woods Institute for the Environment, Stanford University, 385 Serra Mall, Stanford, CA 94107, USA   
5 Biodiversity, Macroecology & Conservation Biogeography Group, University of Gottingen, Gottingen, Germany

# Keywords

Agribusiness; cattle; dry forest; land-use change; savannas; soybeans; telecoupling.

# Correspondence

Nestor Gasparri, CONICET, Instituto de Ecología Regional, Universidad Nacional de Tucumán, CC34 CP4107. Yerba Buena, Tucumán, Argentina.

Tel: +54-381-4255174; fax: +54-381-4255174.

E-mail: ignacio.gasparri@conicet.gov.ar

# Received

26 August 2014

# Accepted

30 March 2015

# Editor

Loyola Rafael

doi:10.1111/conl.12173

# Abstract

Soybean expansion has been a strong driver of deforestation and biodiversity loss in South America (SAM). Here, we highlight strong similarities in environmental, institutional, and other contextual conditions among SAM and Southern African (SAFR) dry forest and savanna regions, and compile evidence for an emerging soybean production frontier in SAFR. Knowledge transfer, cooperation, and direct investment between SAM and SAFR countries constitute crucial elements of soybean expansion in Africa. Comparing maps of soybean suitability, biodiversity, and carbon revealed substantial and spatially diverse trade-offs, suggesting that the emerging soybean frontier in SAFR may pose major challenges for conservation. An increased focus of conservation science on agricultural expansion and intensification in SAFR, as well as strong environmental policies for balancing agricultural production and conservation goals, are needed to mitigate potentially large trade-offs. The coupling of production frontiers should be a vehicle for the transfer not only of agricultural technology and production models, but also of experiences in environmental governance on emerging agricultural frontiers.

# Introduction

Land-use change is the main driver of the global biodiversity crisis due to habitat loss and fragmentation, and the many detrimental off-site effects of industrialized agriculture (Foley et al. 2005). Unless major changes in consumption materialize, agricultural production will have to continue to increase (Kastner et al. 2012), either via agricultural expansion or intensification. Both will further amplify land-use-related pressures on biodiversity (Leadley et al. 2010), particularly in the Global South that harbors the majority of biodiversity, and most undeveloped fertile lands (Lambin et al. 2013).

Land-use change is increasingly driven by economic globalization (Lambin & Meyfroidt 2011), linking,

social-ecological systems across large distances via trade, institutional cooperation, migrations, and other forms of "telecouplings" (Liu et al. 2013). Conservation and land management policies implemented in one region may thus lead to a displacement of land-use pressure (Lenzen et al. 2012; Meyfroidt et al. 2013) and understanding these mechanisms is important for identifying effective conservation strategies (Grau et al. 2013). Telecouplings have predominantly been conceptualized as linking developed "consumer" and less-developed "producer" regions, through biomass flows (e.g., Kastner et al. 2014). The role of linkages among producer regions in developing countries in driving land conversion remains largely unexplored. These linkages may rely on material and capital flows, but can also be established through institutions

(e.g., bilateral agreements) and knowledge (e.g., technology transfer).

Soybean is an archetypal telecouplings crop (Reenberg & Fenger 2011), mainly linked to globally rising meat consumption (Kastner et al. 2012). South America (SAM) has been a hotspot of soybean expansion, causing large-scale deforestation and biodiversity loss (Hecht 2005; Aide et al. 2013). Soybean production frontiers in SAM are also increasingly linked, as actors increasingly act across borders (Gasparri & le Polain de Waroux 2014). The expansion of soybean agribusiness has occurred mostly in (sub)tropical dry forests and savannas in the Amazon "arc of deforestation," the Cerrado, the Chaco, and Chiquitania (Grau & Aide 2008). These regions are rich in biodiversity and carbon, but are also characterized by a sparse protected area network (Leadley et al. 2010; Lehmann 2010). As a response to rising conservation concerns, policies limiting deforestation have recently been implemented in Brazil, Argentina, and Paraguay (Gasparri & le Polain de Waroux 2014), with mixed success (Nepstad et al. 2014). Meanwhile, global demand and soybean prices continue to surge, and firms engaging in soybean production are increasingly transnational. New soybean frontiers are thus likely to develop.

One candidate region for such an expansion is Southern Africa<sup>1</sup> (SAFR) (Figure S1): with large areas environmentally similar to SAM soybean frontiers. Extensive areas of the Zambezi-Kalahari region were identified as equivalent to the dry Chaco (Baldi & Jobbágy 2013), one of the most dynamic soybean expansion frontiers (Gasparri et al. 2013). SAFR's soybean production potential is increasingly highlighted (World Bank 2009; Sinclair et al. 2014), and soybean area, although still small, has increased four-fold between 2000 and 2013 (see below). Better understanding where and how soybean frontiers may emerge in Africa is therefore essential to balance soybean production and biodiversity conservation.

Here, we assess the potential for an emerging soybean frontier in dry forests and savannas in SAFR, and provide evidence that this frontier is currently being enabled. We also assess the role of SAM countries in fostering this frontier via an emerging type of telecouplings – those between countries in the Global South. Specifically, we demonstrate two key messages.

(1) There is an emerging soybean production frontier in SAFR and it constitutes an environmental, but also socioeconomic and geopolitical concern.   
(2) To more sustainably govern these dynamics, SAFR soybean expansion has to be understood as being influenced by a south-south telecoupling with SAM.

# An emerging soybean frontier in SAFR Trends in soybean expansion and production

Soybean cultivation area in SAFR increased exponentially, from 20,000 ha (early 1970s) to 150,000 ha (early 1990s), and 750,000 ha in 2013 (Figure 1A). The corresponding production rose from about 13,000 t (early 1970s) to 260,000 t in 1990 and 1,248,000 t in 2013 (FAO 2014). Although both soybean area and production are still small compared to SAM, soybean expansion in SAFR after 2000 occurred at markedly higher rates than SAM and global trends (Figure 1B).

Demand for soybean products in SAFR is also increasing (Technoserve 2011). The Republic of South Africa has the largest market, with soybean imports (mainly from Argentina) approaching $700 million in 2011 (FAO 2014). Projections of future demand suggest a reinforcement of this trend (Technoserve 2011). This unsatisfied demand creates a favorable context for increasing soybean production, and the recent exponential growth in Africa has mainly taken place in the Republic of South Africa (Figures 1D and F). Other SAFR states, including Democratic Republic of Congo, Zambia, Zimbabwe, Malawi, Rwanda, and Burundi have also experienced sizeable soybean expansions.

# Potential for soybean expansion and conservation concerns

The potential for soybean cultivation in SAFR remains largely uncertain. We used global data sets of agronomic suitability for soybeans, carbon storage, and biodiversity to explore the potential for soybean expansion in SAFR and its environmental trade-offs (detailed methods and results in Supplementary Material 1). Over 365 Mha are considered having good to very high suitability for soybean and 195 Mha have medium to moderate suitability (Figure 2). SAFR contains about 49 Mha of cropland/natural vegetation mosaics, 128 Mha of forests, and 70 Mha of forest-shrub mosaics, which are unprotected and highly suitable for soybean (respectively, 144, 29, and 83 Mha for SAM, Figure S3). This suggests that the soybean potential in SAFR's savannas and dry forest biomes is large and of the same magnitude as in SAM. Humid tropical forests in SAFR are a high conservation priority, but dry forests, savannas, and grasslands have received comparatively little attention (Lehmann 2010; Parr et al. 2014).

Dry biomes also provide crucial resources for rural livelihoods (Shackleton et al. 2007; Chidumayo and Gumbo, 2010). Among the land highly suitable for soybean, $14\%$ were covered by mosaics of cropland and

![](images/a8b9b9f7f5188d4dc1545f3eee32f3ebc52167f97f8fced342fa722a6507407f.jpg)  
A

![](images/a7f966d9eb1009ba894e8127d46382aae3e751b534466a65f5c2ea3e2f3bfd31.jpg)  
B

![](images/078d1037c969ea18fcb1b593eb92b18c74338f1f3d2b1954b83f0422b88ed09c.jpg)  
C

![](images/92f10bb163f8a6639d17faaec8e44bbe9e057fea578b4c1930dd39090dbc983b.jpg)  
D

![](images/94ef737782968b3b2beafab9084e6689b787d68f1e22fbd06cd4bb19dd17bc9e.jpg)  
E

![](images/f8dc983838142a30ad47d26809581fe4a6041de9dbd7bfe08319ac3ce91246a4.jpg)  
F   
Figure 1 Expansion and increase in soybean production in Southern Africa between 1961 and 2013. Changes in soybean cultivation in South American countries (SAM), Southern African countries (SAFR), and globally in terms of total area (A) and relative to the base year 2000 (B). Absolute (C, D) and relative (E, F) changes for countries in SAM and SAFR. Source: FAOSTAT. No data were available for Angola, Botswana, Lesotho, Mozambique, Namibia, and Swaziland.

natural vegetation in 2005 (Figure 2A). A large, but imprecisely known area is also used for grazing, with around 80 Mha (22% land highly suitability for soybean) having an estimated cattle density $>10$ heads/ha (Figure S2).

SAFR savannas and dry forests contain astonishing biodiversity, including some of the world's last wilderness complexes, many endemic and/or charismatic species (Bond & Parr 2010; Shumba et al. 2010). Only about $18.5\%$ of the land highly suitable for soybean are protected (Figure 2A), many of which are increasingly threatened by agricultural expansion (Mascia et al. 2014). Expansion of large-scale, fenced, industrial agriculture may thus lead to drastic habitat loss, and adversely affect

biodiversity by blocking critical migration and dispersal corridors (Beale et al. 2013).

To evaluate potential biodiversity trade-offs, we overlaid the soybean suitability maps with maps of endemism richness, a range size-weighted species richness indicator that ranks grid cells according to their relative overall conservation importance for mammals, birds, and amphibians (Supplementary Material 1). Given the high variability of biodiversity, spatially and among taxa, the spatial pattern of high trade-offs with soybean yields varies significantly (Figures 3A-C and Figure S5), with many hotspots of potential conflict between soybean production and conservation.

![](images/84cd9ad135f5bc0d8919de45fe5963b75294303df4340d4b077712ba72a3979b.jpg)  
Current land use / cover per class of suitability for soy (Mha)

![](images/79df21a247ad1f8575780fc8ebcc3c8dc12bb40f8958ef40cefe385793fd45e6.jpg)  
Figure 2 Suitability for soybean expansion in Southern Africa. (A) Land use/cover in 2005, per classes of suitability for soybean cultivation (B) Map of suitability for soybean cultivation, expressed in potential yield (t/ha) under high inputs rain-fed cultivation. See Supplementary Information for data sources and methods.

![](images/13cfad01996881a679a829e87b9487f731a18fa43ae2fb7a2ad9da5ce49863ac.jpg)

![](images/feb2b40728f8ee415aa5ea66b874c787aa473ece8ca2639e59288ee3717e88f4.jpg)

![](images/f9816317826f3a77d960696bfee7e8acded5101d41b08e747e68886a98512711.jpg)

![](images/a16ce125c3ccc2c41c3be1655252af5c75d57007c9b76a491ed794443ccf68ae.jpg)  
Figure 3 Trade-offs between soybean production and conservation concerns. Soybean suitability versus biodiversity, measured using endemism richness, a range size-weighted species richness indicator (see Supporting Information for details); (A) mammals, (B) birds, and (C) amphibians. Soybean suitability versus carbon stocks (D). All maps display suitability for soybean cultivation in magenta, and the environmental indicator in green, highlighting the spatial heterogeneity of the environmental impact/yield tradeoff, and hotspots of potential land-use competition between soybean production and environmental impacts (in black). See Supplementary Information for data sources and methods.

Carbon stocks vary greatly from $\sim 0$ in the southwestern drylands to $>100\mathrm{MgCha^{-1}}$ in the forest-savanna mosaics of the Southern Congo basin (Saatchi et al. 2011). Carbon versus yield trade-offs also showed strong spatial heterogeneity (Figure 3D). Measures of statistical associations between yields and environmental indicators show that carbon stocks are strongly associated with potential soybean yields, while endemism richness is less strongly associated with yields (Table S1). This suggests that trade-offs between carbon and soybean yields could be more difficult to solve than for biodiversity. With global soybean production reaching 242 Mt in 2012 and projected to rise to 390 Mt in 2050, a hypothetical scenario assuming all additional demand to be satisfied from SAFR would entail 158-923 Tg of carbon emissions, equivalent to $17.5\% -102.5\%$ of all land-use/cover emissions over 2003-2012 (Figure S4).

# Dynamics of frontier development: actors, structures, and South-South telecommunications

South-South telecouplings are a new phenomenon, in many ways distinct from traditional North-South development cooperation. Although connections with China are most visible (Zafar 2007), less evident telecouplings such as between SAM and SAFR may have important consequences for future agricultural development. SAM-SAFR telecouplings involve flows of knowledge and capital into infrastructure development, land acquisition (Hall 2011; Land Matrix 2014), agricultural research, and institutional reforms.

The SAM-SAFR telecoupling is at an early stage, but SAM investments in SAFR agriculture are increasing at several levels (see below). Considering the potential for adaptation of the technology, know-how and practices developed in SAM over the last decades, SAM-SAFR telecouplings could soon become a significant driver of soybean expansion in SAFR.

# Similarities and differences between soybean production frontiers in SAM and SAFR

The current emergence of a soybean frontier in SAFR resembles the SAM soybean boom of the 1990s. Beyond environmental similarities between the two regions (Baldi and Jobbágy 2012), many of the factors that conditioned soybean expansion in SAM then (Kaimowitz & Smith 2001) are present, to some degree, in SAFR today. In the macroeconomic and governance domains, these include the reduction of bureaucracy, economic liberalization, and market deregulation (Kaimowitz et al.

1999; Assane & Chiang 2014), as well as investments supporting agricultural modernization, technology diffusion, land tenure regularization, and infrastructure (road and harbors). For example, the World Bank financed agricultural development projects during the 1980s and the 1990s in SAM, and is doing so heavily now in SAFR (see Supplementary Material 2). Such projects include the First Agriculture Development Policy Operation and the Integrated Growth Pole Project in Mozambique and similar projects in Malawi, Tanzania, and Zambia (see Supplementary Material 2 for a list of World Bank projects).

Important differences remain, however, between the two regions. Agronomic conditions, including pests (e.g., rust) and soil quality (e.g., acidity) still place strong constraints on soybean expansion in SAFR. Currently, the average soybean yield there is around $1.5\mathrm{t / ha}$ , in contrast to around $3\mathrm{t / ha}$ in Brazil and Argentina (FAO 2014). Efforts to identify and improve suitable soybean varieties for SAFR conditions are recent. Yet, technology transfer has been one of the most active areas of cooperation with the SAM soybean production sector (Table 1). Following the success of soybean technology adaptation for tropical and subtropical areas in SAM, the use of SAM seeds is expected to boost yields (The Economist 2010, Vicentini et al. 2013).

Socioeconomic conditions and development priorities constitute another contrast between SAM and SAFR. Socioeconomic and political constraints strongly limit the potential profitability of cultivation (Chamberlin et al. 2014). Furthermore, in SAM, the main actors involved in soybean are agribusiness companies producing for the global market, with little involvement of smallholders, resulting in land property concentration and numerous social conflicts (Caceres 2014). In SAFR, soybean production is being promoted not only for the global market, but also to improve food security and livelihoods locally (World Bank 2009), although soybean production in SAFR is currently dominated by commercial farms (Technoserve 2011).

# Coupling of the SAM and SAFR soybean production frontiers

Environmental and institutional similarities between SAM and SAFR suggest that the SAM production model can be exported to Africa (Cabral & Shankland 2012). Argentina and Brazil have developed a body of knowledge and experience that is now being mobilized to establish a presence in SAFR (Dobrovolski & Rattis 2014). Argentine and Brazilian companies try to position themselves in an incipient African Green Revolution, while their governments consider agricultural development in

Table 1 Conditions and actors in the establishment of new agricultural frontiers (data from project documents and news reports)   

<table><tr><td>Conditions</td><td>Actors</td><td>Actions</td><td>Examples</td></tr><tr><td>Knowledge of local agronomical conditions</td><td>Agricultural extension services of the investor country, often in partnership with those in target country</td><td>Scientific missions; mapping; experimental plots</td><td>Embrapa&#x27;s (Brazil) “Paralelos” program in Mozambique for mapping agricultural potential (2010-2014)</td></tr><tr><td>Adapted technology</td><td>Agricultural extension services with support of agriculture ministries</td><td>Experimental plots; technology transfer projects</td><td>INTA and EEAOC&#x27;s (Argentina) experimental plots in South Africa for the development of local soy varieties and the adaptation of no-till techniques (since 2011)Memorandums Of understanding between Argentina (INTA and Agriculture Ministry) and South Africa (ARC and Agriculture Ministry) (2007, 2013)Brazil&#x27;s &quot;Mais alimentos Internacional&quot; project, which intends to position Brazil as a provider of technology to Zimbabwe and Mozambique (since 2010)Brazil-Angola cooperation agreement in agriculture, facilitated by the FAO, for the development of a national innovation system and the training of researchers (2014).</td></tr><tr><td>Fluid trade</td><td>Governments</td><td>Trade agreements</td><td>Argentina-Angola customs information exchange agreement (2013)SACU-MERCOSUR preferential trade agreement (2009)</td></tr><tr><td>Local know-how</td><td>Universities, development agencies</td><td>University exchange programs in country of origin; capacity-building workshops in target country</td><td>Adjustments to the 1980 technical and scientific cooperation agreements between Brazil and Angola, including technical assistance in agriculture and the setting up of local experimentation stations (2010)Brazil&#x27;s &quot;Plataforma&quot; project&#x27;s support to Mozambiquean agronomical research (since 2010)</td></tr><tr><td>Credit</td><td>Governments; development agencies</td><td>Loans to government agencies; loans to private companies</td><td>Buyer&#x27;s and seller&#x27;s loans for the export of Brazilian machinery in Zimbabwe under the &quot;Mais Alimentos Internacional&quot; program (2013)</td></tr><tr><td>Tenure and investment security</td><td>Governments; development agencies</td><td>Regularization of land tenure; investment protection mechanisms</td><td>Creation of the Brazil-Mozambique Chamber of Commerce (2008)</td></tr><tr><td>Access to agricultural land</td><td>Companies</td><td>Land purchase and leasing</td><td>Agreement between Odebrecht (Brazil), Embrapa (Brazil), and the Angolan State through Gesterra S.A. for agroindustrial production on 36,000 ha (including soy; 2006)</td></tr><tr><td>Functional infrastructure</td><td>Companies, development agencies, governments</td><td>Infrastructure projects, private-public partnerships</td><td>Development of roads and portuary infrastructure in the Nacana corridor of Mozambique as part of the Prosavana plan (triangular agreement by Brazil&#x27;s ABC, Japan&#x27;s JICA, and Mozambique&#x27;s MINAG, 2011-2016)</td></tr></table>

![](images/0b12f239611214402f92a7bdc589ec41a5c4ce42268eb5e82e2e0b06f0158eea.jpg)  
Figure 4 Actors in the development of a soybean frontier. Main actors involved in the development of a soybean frontier, differentiating between investor and target country. Arrows represent different types of relations: cooperation, negotiation and investment (see Tables 1 and 2 for examples).

Africa as a source of future taxable income and of new exports markets for agricultural technology (Goulet & Sabourin 2012). For example, the More Food Africa program, initiated by the Brazilian government, provides credit lines for African smallholders to import agricultural machinery from Brazil, representing an investment by Brazil of about $0.2 billion till 2030 for Mozambique and Zimbabwe alone (Patriota & Pierri 2012).

Brazil and Argentina are establishing a presence in SAFR in three ways (Tables 1 and S2, Figure 4). First, presence is established via land acquisitions. Despite some prominent land deals, however, such transactions remain uncommon (Land Matrix 2014). Second, presence is established via knowledge creation, technology adaptation, and capacity building (Dobrovolski & Rattis 2014). New knowledge is necessary to identify areas suitable for production and to optimize production. For example, Embrapa has developed a wide range of technical support and capacity building programs in Africa (Dusi 2012), and adaptation of SAM technology to SAFR is also carried out by the Argentine National Institute for Agricultural Technology (Vicentini et al. 2013). Third, Argentina and Brazil are establishing a presence in SAFR by the improvement of investment conditions through improving infrastructure and governance. The ProSavana project, for example, includes plans for road development and harbor infrastructure in Mozambique (ProSavana 2014).

Actions to change governance target tenure and investment security, access to credit, and the removal of trade barriers via various bilateral agreements between Argentina, Brazil, and SAFR countries.

Much of the rhetoric around South-South cooperation revolves around technology transfer and the modernization of family farms for food security and rural poverty alleviation (e.g., Goulet & Sabourin 2012, ProSavana 2014). However, it is unclear that SAM-style soybean boom in SAFR will achieve these goals. In SAM, the history of the soybean boom is one of agribusiness, not family production, and statements by Argentine and Brazilian officials at the 9th World Soybean Research Conference in Durban in 2013 suggested strong interest in the integration of SAFR into the world soybean market.[2]

# Conclusion: Meeting conservation challenges while realizing the potential for soybean production in SAFR

Much hope is currently being expressed about developing agriculture in the dry forest and savanna biomes in SAFR, similar to the situation in SAM in the 1980s and 1990s (World Bank 2009; The Economist, 2010). We show evidence for an emerging soybean frontier in SAFR. While the expansion of soybean cultivation may have economic

benefits, it also poses major challenges for conservation, as areas of high soybean potential partially overlap with areas of high carbon storage and unique biodiversity.

Telecouplings between SAM and SAFR, through knowledge transfer, cooperation, and direct investment, constitute a crucial element of the recent soybean expansion in SAFR. Favorable institutional conditions were created in the last decade to facilitate the coupling between soybean production frontiers in these two regions. Currently, agribusiness capital flows from SAM to SAFR are still limited, but dramatic increases are a plausible scenario if major constraints to agribusiness expansion are eliminated. In a world where South-South collaborations become increasingly common, with China and Brazil leading the way (Perch & Bradly 2012), the role of countries like Argentina and Brazil in exporting their production model to new frontiers points to a possible reconfiguration of global land-use dynamics from a classical core-periphery structure toward a multipolar one.

Some of the main agronomic constraints prevailing in SAFR could be overcome within the next few years. Probably, the strongest constraint for agribusinesses expansion in SAFR lies in the political context and governance (Chamberlin et al. 2014, Deininger et al. 2014). That, so far, soybean production has only been booming in South Africa, the country with the highest governance ranking in the region after Botswana,[3] can be taken as evidence of this. Many African countries are on their way to improving governance, especially in the financial and economic realms (United Nations 2009). Evidence from SAM shows that agricultural intensification in a context of improved economic and social regulations, yet without a robust environmental policy, can promote rapid deforestation (Ceddia et al. 2014). Furthermore, direct replication of the SAM agribusiness model would likely conflict with the smallholder-based, nutrition-oriented objectives for soybean development in Africa.

In the early 1990s, concerns about deforestation in SAM were centered on the moist Amazonian forest. Even as the soybean boom was provoking a shift of deforestation to deciduous dry forest and savannas (Grau & Aide 2008), the conservation agenda remained biased toward the Amazon, and conservation policies in dry forests and savannas thus remain weak (Hecht 2005). In SAFR, similar biases exist with the tropical moist forest of the Congo basin in the focus, whereas dry forest and savannas appear neglected (Parr et al. 2014).

Commodity crop expansion can be steered into multiple pathways, with very different environmental and social outcomes (Meyfroidt et al. 2014). Monitoring and understanding the emerging soybean frontier in SAFR, and the role of SAM actors, is central for the conserva

tion of SAFR's dry forest and savannas. SAFR could build on some promising SAM experiences in curbing deforestation, including policy tools such as credit access restrictions for owners not complying with environmental legislation, supply-side interventions, and an effective deforestation monitoring system (Nepstad et al. 2014). It is crucial to develop such tools in SAFR now, in parallel to the creation of favorable governance and technological conditions for soybean development, instead of doing so delayed as in SAM. Policymakers should also be aware that emerging South-South telecouplings increase the risk of deforestation policies implemented in SAM causing leakage to other frontiers (Dobrovolski & Rattis 2014). The telecoupling of production frontiers should be a vehicle for the transfer not only of agricultural technology and production models, but also of experiences in environmental governance.

# Supporting Information

Additional Supporting Information may be found in the online version of this article at the publisher's web site:

Figure S1 Maps of biomes and ecoregions in Southern Africa.

Figure S2 Classes of livestock density per classes of suitability for soy expansion in Southern Africa.

Figure S3 Suitability for soybean expansion in South and Central America (a) Land use/cover in 2005, per classes of suitability for soybean cultivation (b) Map of suitability for soybean cultivation, expressed in potential yield (t/ha) under high inputs rain-fed cultivation. Data sources and methods: See Supplementary Information above.

Figure S4 Carbon emissions per ton of soybean produced.

Figure S5 Local indicators of spatial association (bivariate local Moran's I).

Table S1 Spatial association between soybean yields and environmental indicators

Table S2 Projects and agreements between SAM and SAFR countries (data from project documents and news reports)

# Endnotes

1. We here equate Southern Africa to the member countries of the Southern African Development Community, i.e., Angola, Botswana, Democratic Republic of Congo (DRC), Lesotho, Madagascar, Malawi, Mozambique, Namibia, South Africa, Swaziland, Tanzania, Zambia, Zimbabwe, plus Burundi and Rwanda, and excluding small island states (see http://www.sadc.int/member-states/).   
2. For example, the Agriculture Minister of Argentina, Norberto Yauhar, expressed his desire that "the African Savannah be a world soybean producer" and said he trusted that Argentina could help realize this mission (http://www.telam.com.ar/notas/201302/8322-endurban-argentina-apoyo-el-desarrollo-agricola-de-frica.html).   
3. As measured by the Ibrahim Index of African Governance 2013 (http://www.moibrahimfoundation.org/iiag/).
