# Harvesting dilemmas

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:39:25.330043+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: da Silva et al. - 2024 - Harvesting dilemmas.pdf
- Year: unknown
- DOI: 10.1016/j.oneear.2024.06.018
- OA status: green
- License: none recorded
- Category: Journal Articles\Commentary\Telecoupling
- Closed-access reason: green OA without permissive license (none)

## Copyright-Safe Summary
This commentary-style paper brings together several perspectives on how global commodity production and trade create land use dilemmas when viewed through telecoupling and metacoupling lenses. It focuses on land-based commodities such as soy, cocoa, petroleum-linked exports, and various agrifood products sourced from the Global South, with case material from Brazil (Cerrado and Amazon), West Africa (cocoa in Cote dIvoire and Ghana), Ecuador, Cameroon, Colombia, Kenya, and broader EU-global supply chains.

The system context throughout is telecoupled supply chains where distant consumer demand shapes land use, livelihoods, and ecosystems in producer regions, often with strong power asymmetries and weak protections for people and nature. The contributions are largely conceptual and policy-oriented rather than based on new quantitative datasets; they synthesize existing evidence, regulatory developments, and ongoing research projects such as TC4BE.

Key findings include: (1) Soybean deforestation controls in the Brazilian Amazon have shifted expansion pressure into the Cerrado, illustrating telecoupled spillover between biomes and the need for incentive-based mechanisms that favor restoring degraded land over clearing native vegetation. (2) In cocoa, low farm-gate prices push smallholders towards environmentally and socially harmful practices, while niche specialty traders may offer fairer, more sustainable telecoupled relationships that require independent scrutiny as they scale. (3) Infrastructure that enables commodity exports, exemplified by oil development in the Ecuadorian Amazon, expands frontiers and triggers cumulative ecological and social impacts that current project-by-project assessments miss. (4) Telecoupled land governance is constrained by unequal power and exclusionary institutions; addressing these imbalances and co-producing knowledge across producer and consumer countries is essential. (5) New EU due diligence rules could improve governance of telecoupled chains, but better data and participation on human rights impacts are critical. (6) Telecoupled commodity systems can also be leverage points for transformative change if counter-hegemonic, plural, and justice-centered approaches to governance and finance are pursued.

Overall, the paper is explicitly about telecoupling and metacoupling, using them to frame both harms and opportunities in global commodity-driven land use.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong focus on telecoupled global commodity chains and spillovers across producer landscapes and biomes.

### Intracoupling
#### Systems
- Local land use systems within Brazilian Cerrado biome
- Farm household systems of cocoa smallholders
- Indigenous territories affected by national infrastructure
#### Flows
- Land conversion from native vegetation to soybean fields
- Household labor and inputs within cocoa farms
- Local transport of extracted petroleum and timber
#### Agents
- Brazilian soybean farmers and ranchers
- Cocoa smallholder households and cooperatives
- Indigenous communities and local residents
#### Causes
- National policies enabling legal vegetation clearing
- Persistently low cocoa farmgate prices
- Infrastructure expansion into sparsely populated frontiers
#### Effects
- Accelerated Cerrado deforestation and habitat loss
- Underinvestment and unsustainable cocoa farming practices
- Dispossession of Indigenous peoples and biodiversity decline

### Pericoupling
#### Systems
- Neighboring Brazilian biomes linked by soybean expansion
- Bordering producer regions in West Africa
- Adjacent conservation areas near infrastructure corridors
#### Flows
- Soybean production shift from Amazon to Cerrado
- Cross-border cocoa trade within West Africa
- Regional spillover effects of transport networks
#### Agents
- Regional agribusiness companies and land speculators
- West African cocoa marketing boards
- Provincial governments and infrastructure planners
#### Causes
- Amazon soybean deforestation restrictions displacing expansion
- Regional competition and coordination in cocoa pricing
- Cumulative effects of multiple infrastructure projects
#### Effects
- Spillover land clearing in biomes less connected to global chains
- Shared environmental degradation across producer regions
- Landscape fragmentation and regional inequality

### Telecoupling
#### Systems
- Global soybean supply chain linking Brazil and distant consumers
- Global cocoa and chocolate value chains
- Telecoupled land-based commodity exports supported by infrastructure
#### Flows
- Soybeans exported from Cerrado to international markets
- Cocoa beans traded from Cote dIvoire and Ghana to chocolate industry
- Agri-food and petroleum commodities shipped via global trade
#### Agents
- International commodity traders and multinational buyers
- Specialty cacao traders and large trading firms
- EU regulators and transnational agrifood corporations
#### Causes
- Rising international demand for soy and livestock feed
- Global chocolate market seeking cheap cocoa
- EU due diligence and deforestation regulations shaping supply chains
#### Effects
- Commodity-driven deforestation and biodiversity loss in producer countries
- Farmer poverty and exploitative labor tied to distant consumers
- Human rights violations and environmental injustices along supply chains

### Cross-Coupling Interactions
- Amazon conservation policies shift soybean expansion and deforestation pressure into the Cerrado biome
- EU sustainability regulations reconfigure global agri-food telecouplings and local rights conditions
- Telecoupled value chains interact with local power imbalances and governance institutions

### Research Gaps or Limitations
- Need rigorous independent evaluation of specialty cocoa initiatives impacts on people and ecosystems
- Insufficient data on complex human rights impacts like land and water rights violations
- Limited assessment of cumulative infrastructure impacts beyond project-by-project evaluations

### Search Keywords
- soybean telecoupling Cerrado spillover
- global cocoa trade human rights
- infrastructure land grabbing Indigenous rights

### Extraction Confidence
high
