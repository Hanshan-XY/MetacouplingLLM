# Stormwater Runoff Allocation and Basin-Wide Flood Mitigation Mechanism From the Perspectives of Effi

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:06:47.954166+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Su and Min - 2025 - Stormwater Runoff Allocation and Basin-Wide Flood Mitigation Mechanism From the Perspectives of Effi.pdf
- Year: unknown
- DOI: 10.15302/J-LAF-0-020043
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
The paper develops a basin-wide framework for allocating future stormwater runoff to enhance flood-mitigation resilience, focusing on both efficiency and equity. The empirical case is the Dajia River Basin in central-western Taiwan, China, a steep watershed with 13 management units grouped into upstream, midstream, and downstream sections.

System context is integrated land-water planning under climate change and urbanization. The authors first downscale climate projections (multiple RCP scenarios) and combine them with observed land use changes (2008-2018) to estimate incremental stormwater runoff over a 200-year horizon. Climate change is found to dominate runoff increases, especially in upstream units.

To design an efficiency-oriented allocation, they build a two-stage data envelopment analysis (DEA) model. Stage 1 measures economic efficiency (economic outputs vs. resource inputs); stage 2 measures runoff management efficiency (disaster losses vs. runoff and governance inputs). Incremental runoff links the two stages, and a bi-objective optimization (maximize desirable outputs, minimize inputs) generates a scheme for distributing required runoff reductions among units. Under this scheme, the upstream region is assigned about 88.8 percent of the basin’s runoff management burden, reflecting both high runoff generation and large improvement potential.

For equity, the study applies a near-far telecoupling perspective operationalized through a multi-regional input-output (MRIO) model of land-based resource flows. Near coupling captures local land consumption; far coupling captures inter-unit land-service exchanges; external spillovers represent land services exported outside the basin. Regions that are net importers of land services are expected to compensate net exporters by bearing more runoff responsibility. Under this equity-oriented allocation, the downstream section takes about 78.25 percent of intra-basin runoff management, while upstream responsibility is minimal; external systems should cover roughly 70 percent of incremental runoff via higher-level compensation.

Finally, the authors introduce a decision-maker preference parameter that weights efficiency and equity allocations. When the weight on efficiency is set to 0.2 (greater emphasis on equity), inter-regional disparities in assigned runoff are minimized.

The work is directly relevant to metacoupling/telecoupling: it quantifies near and far couplings of land and water services within and beyond the basin and embeds these telecoupled flows into a formal allocation and compensation mechanism for flood risk governance.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong intra and peri basin coupling; uses MRIO telecoupling for equity

### Intracoupling
#### Systems
- Upstream, midstream, downstream subcatchments within Dajia River Basin
- Urban, agricultural, ecological land use zones inside basin
#### Flows
- Stormwater runoff generation, routing, and local flood peaks
- Economic outputs and disaster losses within management units
#### Agents
- River basin management units and local governments
- Residents, enterprises, infrastructure operators in each reach
#### Causes
- Urbanization increasing impervious surfaces and runoff volumes
- Climate change intensifying rainfall magnitude and frequency
#### Effects
- Spatially uneven flood risk and disaster losses
- Differentiated runoff reduction responsibilities among units

### Pericoupling
#### Systems
- Upstream forested regions and downstream urbanized regions
- Adjacent management units exchanging land services
#### Flows
- Land service flows via near far coupling within basin
- Runoff management compensation between upstream and downstream
#### Agents
- Subbasin planners coordinating across jurisdictional boundaries
- Provincial or central agencies brokering intra basin compensation
#### Causes
- Development imbalances between upper and lower reaches
- Dependence of cities on upstream ecosystem services
#### Effects
- Runoff burden shifted upstream under efficiency allocation
- Downstream承担更多治理责任 under equity allocation

### Telecoupling
#### Systems
- Dajia River Basin and external economic systems
- External regions receiving basin land service outflows
#### Flows
- Virtual land consumption via multi regional trade
- External runoff management compensation obligations
#### Agents
- National government coordinating cross regional compensation
- Producers and consumers linked by MRIO supply chains
#### Causes
- Embedded land use in traded goods and services
- Basin functioning as net land service exporter
#### Effects
- External systems expected to fund majority runoff management
- Telecoupled responsibilities reduce downstream flood pressure

### Cross-Coupling Interactions
- MRIO telecoupling used to adjust intra basin runoff quotas
- Decision preference model balances efficiency and equity allocations

### Research Gaps or Limitations
- Operational design of financial or credit based compensation unresolved
- Need dynamic models coupling future climate and land use change

### Search Keywords
- stormwater runoff allocation efficiency equity MRIO DEA
- Dajia River Basin near far coupling flood mitigation resilience

### Extraction Confidence
high
