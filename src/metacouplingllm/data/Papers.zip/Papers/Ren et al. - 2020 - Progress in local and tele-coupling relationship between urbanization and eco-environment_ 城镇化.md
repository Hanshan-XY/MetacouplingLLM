# Progress in local and tele-coupling relationship between urbanization and eco-environment_ åŸŽé•‡åŒ–

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:03:29.702157+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Ren et al. - 2020 - Progress in local and tele-coupling relationship between urbanization and eco-environment_ åŸŽé•‡åŒ–.pdf
- Year: unknown
- DOI: 10.11821/dlxb202003011
- OA status: unknown
- License: none recorded
- Category: Journal Articles\Review\Metacoupling
- Closed-access reason: no license info, oa_status=unknown

## Copyright-Safe Summary
This review article examines how urbanization and eco-environment interact through both local and distant (tele-) linkages, and how related theories and methods have evolved internationally. The focus is conceptual and methodological rather than on a single empirical case, but the discussion is framed by China’s rapid urbanization and the need to coordinate development and environmental protection, especially in urban agglomerations.

The authors synthesize three main strands of theory: teleconnection (originating in climate science and later applied to land use, vulnerability, and globalization), telecoupling and its extension to metacoupling (intra-, peri-, and tele-couplings among human-environment systems), and nexus approaches that analyze multi-element linkages among water, energy, food, and other resources. They argue that telecoupling and metacoupling provide a more integrated framework than earlier teleconnection work by explicitly structuring analysis around systems, flows, agents, causes, and effects across distances.

The paper reviews qualitative and quantitative methods used to study local-tele relationships between urbanization and the environment: place-based qualitative research and political ecology; multi-regional input-output models for tracing embodied water, energy, land, and emissions; spatial econometric models for detecting spatial spillovers; urban (or socio-ecological) metabolism analysis using material flow and emergy approaches; ecological network analysis for resource-flow networks; and case applications of the telecoupling framework. These methods are illustrated mainly with international examples in land-use change, water (especially virtual water and inter-basin transfers), and energy trade.

The authors conclude that while telecoupling/metacoupling thinking is central to contemporary human-environment research, explicit application to Chinese urbanization-environment relations remains limited. They identify three priority directions: multi-scale analysis with emphasis on urban agglomerations; tracing dominant coupling pathways and their temporal evolution; and building a stronger, interdisciplinary theoretical foundation for local and tele-coupling in China.

This paper is directly about telecoupling and metacoupling, positioning urbanization-eco-environment interactions within that systems framework and highlighting its value for sustainability governance.

## Structured Metacoupling Extraction

### Coupling Classification
- Reviews meta-coupling framework for urbanization and eco-environment at intra, peri, and tele scales.

### Intracoupling
#### Systems
- Local urbanization-eco-environment system within a city or region
- Internal components of urban agglomeration socio-ecological system
#### Flows
- Local material and energy flows within urban production and consumption
- Internal land use change, pollution, and resource use flows
#### Agents
- Local governments and planning departments
- Urban residents, firms, and utilities
#### Causes
- Urban expansion, industrialization, and population growth
- Local policies, technology change, infrastructure investment
#### Effects
- Local air and water pollution, ecological degradation
- Changes in urban livability, costs, and health

### Pericoupling
#### Systems
- Neighboring cities within an urban agglomeration
- Upstream and downstream regions within same basin
#### Flows
- Intercity commuting, goods and service trade
- Regional water diversion, energy grids, pollution spillovers
#### Agents
- Provincial and regional authorities
- Interregional enterprises and logistics actors
#### Causes
- Regional integration and infrastructure connectivity
- Comparative advantages of nearby regions
#### Effects
- Spatial spillover of land expansion and air pollution
- Redistribution of water, energy, and ecological pressure

### Telecoupling
#### Systems
- Chinese urban regions and distant resource-supplying regions
- Global sending, receiving, and spillover systems
#### Flows
- Trade in food, energy, land-based products and virtual water
- Capital, information, technology, migration, and pollutants
#### Agents
- National governments and international organizations
- Multinational companies, traders, financial institutions
#### Causes
- Economic globalization and global supply chains
- Remote demand for food, energy, materials, and ecosystem services
#### Effects
- Deforestation, biodiversity loss, and carbon emissions in sending regions
- Urban environmental pressure outsourcing and social inequities

### Cross-Coupling Interactions
- Meta-coupling integrates intra-, peri-, and telecoupling within one analytical framework
- Remote flows reshape internal urban metabolism and regional eco-environment
- Virtual resources and trade link local sustainability to distant ecological impacts

### Research Gaps or Limitations
- Telecoupling and meta-coupling theories remain conceptually incomplete and fragmented
- Few empirical applications directly target urbanization-eco-environment meta-coupling in China
- Limited fine-scale data constrain multi-scalar input-output and network analyses

### Search Keywords
- urbanization eco-environment telecoupling meta-coupling China
- multi-regional input-output virtual water energy trade
- urban agglomeration spatial spillover nexus analysis

### Extraction Confidence
high
