SYNTHESIS AND REVIEW • OPEN ACCESS

# Focus on cross-scale feedbacks in global sustainable land management

To cite this article: Ralf Seppelt et al 2018 Environ. Res. Lett. 13 090402

View the article online for updates and enhancements.

# You may also like

Preface : Proceedings of the Third-International Conference on Environmental, Socio-Economic, and Health Impacts of Sustainable Land Management (ICESHISLM)   
Climate change impact assessment on thepotential rubber cultivating area in the Greater Mekong Subregion Reza Golbon, Marc Cotter and Joachim Sauerborn   
Combined effects of climate and land-usechange on the provision of ecosystem services in rice agro-ecosystems Fanny Langerwisch, Tomáš Václavík, Werner von Bloh et al.

![](images/87ca01b3fd16a75c1a33df8fb5a4ef3c686c3965591344104ecbcb7e74a36ea4.jpg)

![](images/00e607bdd4389ac722805901be6f970a0d153f8262907a81b2d54a5a966a52f2.jpg)

# Environmental Research Letters

![](images/9776de38d4b264e06c8badc138ded352740bc88ea4504de54faa52f2637b526c.jpg)

CrossMark

# OPEN ACCESS

# SYNTHESIS AND REVIEW

# Focus on cross-scale feedbacks in global sustainable land management

# RECEIVED

1 August 2018

# ACCEPTED FOR PUBLICATION

22 August 2018

# PUBLISHED

20 September 2018

Original content from this work may be used under the terms of the Creative Commons Attribution 3.0 licence.

Any further distribution of this work must maintain attribution to the author(s) and the title of the work, journal citation and DOI.

![](images/e94bbd3720275cd291ed509329eb03642cbb863942cec8ccaf19ad19a0678af4.jpg)

# Ralf Seppelt $\mathbb { 1 , 2 , 3 } \oplus \mathbb { p }$ , Peter H Verburg4,5 , Albert Norström6 , Wolfgang Cramer7 and Tomáš Václavík1,8

1 UFZ—Helmholtz Centre for Environmental Research, Department Computational Landscape Ecology, D-04318 Leipzig, Germany   
2 Institute of Geoscience & Geography, Martin-Luther-University Halle-Wittenberg, D-06099 Halle (Saale), Germany   
3 iDiv—German Centre for Integrative Biodiversity Research, D-04103 Leipzig, Germany   
4 Institute for Environmental Studies, VU University Amsterdam, de Boelelaan 1087, 1081 HV Amsterdam, The Netherlands   
5 Swiss Federal Research Institute for Forest, Snow and Landscape, Birmensdorf, Switzerland   
6 Stockholm Resilience Centre, Stockholm University, Sweden   
7 Mediterranean Institute for Biodiversity and Ecology (IMBE), Aix Marseille University, CNRS, IRD, Avignon University, Aix-en-Provence, France   
8 Palacký University Olomouc, Department of Ecology and Environmental Sciences, Faculty of Science, 78371 Olomouc, Czech Republic

# E-mail: ralf.seppelt@ufz.de

Keywords: place-based research, transferability, land use, tele-coupling, scenario analysis

# 1. Introduction

Human land-use activities have transformed most of the Earth’s land surface (Foley et al 2005, Ellis 2011, Gauthier et al 2015). While land-use activities differ in many ways across the world, their combined impact is becoming a force of global importance. Consequently, sustainable land management has been identified as a key lever for achieving global sustainability. For example, six out of 17 sustainable development goals (SDGs), adopted in the United Nations 2030 Agenda for Sustainable Development, relate directly to land management: (i) land management is key for providing goods and services for humankind relating to ‘zero hunger’ (SDG 2); (ii) land management is responsible for $2 0 \% { - } 4 0 \%$ of greenhouse gas (GHG) emissions relating to ‘climate action’ (SDG 13), and (iii) land management is a major driver of biodiversity loss relating to ‘life of land’ (SDG 15). Indirectly, land management affects ‘affordable clean energy’ (SDG 7) and ‘sustainable cities and communities’ (SDG 11).

A growing human population, associated with increasing consumption rates and demands on commodities, requires a true paradigm shift regarding the management of the land for long-term sustainability. At the same time, we are witnessing a progressive scarcity of available productive land, and the production peak of many renewable resources has already been passed (Lambin and Meyfroidt 2011, Seppelt et al 2014). These demands and the limits to supply underlie the many linkages between the different social, economic and ecological goals and targets that are being charted out by Agenda 2030 (Geijzendorffer

et al 2017). Pathways to some goals are synergistic, while others present trade-offs for their mutual achievement. For example, an increase of provisioning goods and services from ecosystems, such as food and fibre, could be achieved through further intensification of land use (Mauser et al 2015), which might lead to an increased loss of biodiversity (Gerstner et al 2014, Stein et al 2014, Newbold et al 2015) but also result in higher GHG emission through higher energy use and fertilizer application. At the same time, biodiversity has to be maintained for many societal objectives including its potential to support ecosystem functions such as pollination (Cardinale et al 2012, Seppelt et al 2016). A significant reduction of GHG emissions through large-scale deployment of new biofuels is in conflict with the production of food or conservation of natural habitats for biodiversity or carbon storage. The specific nature of the conflicts and synergies between these different objectives strongly depends on the local land system and the environmental, socio-economic and cultural context in which this land system is operating. Thus, achieving one SDG might compromise others (Pradhan et al 2017) and trade-offs on various scales need to be expected, which can be moderated by appropriate land management.

Whilst place-based research provides essential knowledge on the biophysical and socio-economic boundaries of land use, its findings are naturally contingent upon the specific geographical context and rarely account for offsite effects. The conversion of a conventional agricultural system at one location to organic farming may have positive impacts on local sustainability, but it may, due to lower production,

displace some impacts to other locations that need to compensate for the loss of production. On the other hand, many land use drivers such as climate change, population growth or consumption patterns are well captured at the global scale, but there are significant uncertainties about how they interact with local conditions. Both regional and global studies on food production rarely account for these tight links and interactions between socio-economic and biophysical processes. These uncertainties and incongruences in spatial scales prevent effective integration, synthesis and transferability of findings from research to sustainable land management.

Against this background, here we review and synthesize the contributions of the focus collection on ‘Cross-scale Feedbacks in Global Sustainable Land Management’, which collates papers that investigate the links between global change processes and local realities through, e.g., integration of local and global drivers impacting economic and biophysical processes or assessing the transferability or up-scaling of findings from place-based research.

# 2. Synthesis: emerging topics in sustainable land management and land systems research

The articles in this focus issue illustrate new approaches to investigate global and regional land systems, and identify key research frontiers important for sustainable land management across scales to achieve the SDGs. Three major clusters of research frontiers have been identified: (1) new frameworks to understand cross-scale dynamics of land-use systems, (2) synthesis of place-based research, and (3) addressing future perspectives of land use by development of consistent scenarios.

# 2.1. New frameworks to understand cross-scale dynamics of land-use systems

Land management dynamics are seldom just local or place-specific anymore, but are influenced by multiple global drivers with complex connections to other places. Improving our understanding of these different cross-scale dynamics in diverse land-use systems is critical. Dorninger et al (2017) conceptualize ‘humannature connectedness’ as a new methodological framework that can be applied in any region of the world to assess how closely connected people are to their regional ecosystems. The authors identify two key mechanisms that disconnect humans from nature on a regional scale: (1) the flow of external non-renewable inputs into the land-use system and (2) teleconnections with distant systems. While these mechanisms allow for greater regional resource use, they pose challenges for sustainability through waste generation, depletion of non-renewable resources and environmental burdens shifted to distant regions.

The topic of environmental burdens is elaborated by Pascual et al (2017), who argue for a better recognition of the distant, diffuse and delayed impacts that land management often has on biodiversity and ecosystem services. They define these impacts as ‘off-stage ecosystem service burdens’ and identify four typical pathways based on biodiversity conservation policies, and the management of provisioning, regulating and cultural services. The authors advocate for their incorporation in land management decisions and ecosystem service assessments such as those conducted by the Intergovernmental Science-Policy Platform on Biodiversity and Ecosystem Services.

Finally, Sietz et al (2017) apply the emerging approach of ‘archetype analysis’ and assess vulnerability in African drylands to environmental change. A cluster analysis reveals archetypical patterns of how vulnerable farming systems are to land degradation and support understanding the heterogeneity of vulnerability determinants (e.g. water availability, agroecological potential or population pressure) across sub-Saharan Africa. Importantly, their spatially explicit framework offers the opportunity to evaluate a specific region’s potentials and challenges in its wider context across nested scales.

# 2.2. Synthesis of place-based research results

While new conceptual and analytical frameworks such as the above provide guidance in designing specific analysis and provide suggestions for similarities between case studies, a general methodology on the transferability of place-based research is unresolved and defines the second emerging topic. Three studies focus on the synthesis of data and local case studies on sustainable land management, highlighting the need for generalization and transferability of findings. Hermans-Neumann et al (2016) analyse the drivers of changes in tropical forest products using a standardized, pan-tropical dataset of more than 200 villages with forest access. Their analysis shows that forest resources (e.g. timber, fuel wood and food) declined over the last five years, though with marked differences across continents. The strongest degradation of forest resources occurred in places with both growing resource use and immigration.

Similarly, Carter et al (2017) synthesize comprehensive data on large-scale land acquisition (LSLA) to reveal that land available for agriculture, accessibility and political stability are the main factors that explain whether a country will be targeted for LSLA. The synthesis of such comprehensive datasets allows for globally comparative analyses that go beyond case studies in terms of generalizable conclusions and transferability of findings.

The issue of transferability is specifically addressed by Václavík et al (2016) who build on a previously developed concept of land system archetypes (Václavík et al 2013, Levers et al 2018) to investigate

potential transferability of regional case studies that focus on land management and ecosystem services across four continents. The proposed method is offered as a blueprint for large research frameworks that need to assess the relevance and representativeness of place-based research for other geographical areas and to identify possible gaps in research efforts.

# 2.3. Future perspectives and new integrated scenarios

Finally, the third emerging topic deals with potential future developments of land management based on scenarios which capture the diversity of land systems. Scenarios of land management need to consider that land is a limited resource which can be used to produce food and fibre or to maintain non-provisioning ecosystem services but that trade-offs exist in the decisions on how to manage land (Titeux et al 2017). Modelling approaches that integrate the interplay of biophysical and socio-economic factors in scenarios of global or regional change are promising tools to study future land-use impacts and trade-offs. Delzeit et al (2018) provide a set of scenarios of global drivers until 2030 that can be used consistently in a range of regional and local case studies of land use. The impacts of biofuel policies, dietary patterns, cropland expansion and productivity changes on agricultural markets are investigated in a modelling framework that couples an economic model with a crop growth model.

One of these global scenarios, together with regionally-tailored land-use and climate change scenarios, is applied by Langerwisch et al (2018) who quantify the combined effects of land-use and climate change on four ecosystem services in rice production regions in Southeast Asia. Here, the vegetation and hydrology model LPJmL shows clear trade-offs in the future provision of ecosystem services, but also the potential of land management to partially offset the negative impacts of climate change on rice production, carbon storage and sequestration. Following a similar framework, Gutsch et al (2018) quantify the effects of alternative land management scenarios and climate impacts on forest variables indicating ecosystem services related to timber, habitat, water and carbon. Again, the combination of modelling tools applied under scenarios of future change allows one to better balance the trade-offs between ecosystem services and provides the base for future forest management optimization at the regional and national scale.

# 3. Outlook: guiding questions of the emerging topics

Obviously, a focus collection of publications such as this cannot fully cover the complex topic of sustainable land management in a comprehensive or exhaustive manner. Global land management is characterized by a diverse set of key challenges. These range from

sustainable resource appropriation, the preservation of biodiversity and ecosystem functioning, human well-being, equity and so forth, as comprehensively covered by the SDGs, or as illustrated by figure 1. Based on the emerging topics identified by and discussed in the contributions of this focus collection we can collate key questions, which serve for stimulation as well as for guidance of future research directions; cf Box 1.

There is a predominant paradigm that an improved understanding of the system of interest, here land systems, is key to improve decision making. However, despite a significant increase in our understanding of land system dynamics over the past two decades, the uptake and integration of scientific knowledge into decision-making processes remains limited (Kirchhoff et al 2013). This is because decision-making only partly relies on well-established scientific knowledge. Of equal importance are the underlying value systems of the involved decisionmakers, beneficiary and stakeholders as well as the governance system and power structures in which decision can be taken, namely rules, values and knowledge, cf Gorddard et al (2016). Consequently, a simplistic focus on generating more understanding of land system dynamics will likely in itself be insufficient to foster sustainable land management.

Moving towards alternative approaches to sciencepolicy interactions, such as co-production (Mauser et al 2013), could increase the relevance and usability of land-use science for society and decision-making. With respect to global land governance, new emerging processes such as large-scale land acquisition or spilloff and offsite effects (Seppelt et al 2011, Carter et al 2017, Pascual et al 2017) pose challenges to land management which is mostly implemented through law, rule or incentives at the local to regional scale. Surprisingly, large-scale land acquisitions are not an issue in global-scale agro-economic models (Debonne et al 2018). A proper representation of changes in farming structure, including their underlying social, economic and political drivers, is important to be able to analyse the environmental, economic and social impacts of such changes and the ways in which these new modes of land governance impact on the relations between global and local processes. The limitation of the available land surface and the limitation of its goods and services produced simply suggests that novel ideas to govern land as global commons are required (Seppelt et al 2014, Creutzig 2017).

This focus collection also contrasts two different conceptual approaches to the synthesis of place-based research results: (a) global-scale analysis and modelling, that builds on the basic assumption to fully capture global processes related to land use and (b) linkage of a variety of locations studied as different case studies. While global trade models are limited with respect to spatial scale but also with respect to the commodities captured, a similar limitation holds for the synthesis of place-based results. For the latter, concepts like

![](images/5bb47a4a2f08d79c8b83b9e9045a297544236ea8f30e5219652b12b3efafdbf4.jpg)  
Figure 1. The diverse facets of global sustainable management of land systems (artist: M. Volk). The main task of balancing different trade-offs, such as between various SDGs, by the artistic guy in the center of the picture, mostly model-based (cf sign), has to cope with various challenges (smaller cartoons in different world regions): deforestation, invasive species (e.g. South America), water scarcity, high-tech agriculture, global trade (e.g. North America); renewable energies and bio-based economies, global trade (e.g. Europe), large-scale land acquisitions, mining and resources extraction (e.g. Africa), urbanization (e.g. East Asia), mining and resources extraction, invasive species (e.g. Australia).

tele-coupling, offsite effects or spill-over emerge quite logically (Seppelt et al 2011, Liu et al 2015, Pascual et al 2017). Although tele-coupling is well conceptualized, operationalization in research methods is still challenging. The literature is full of local case study evidence of potential impacts of emerging value chains and the role of market-based commodities and telecoupled land management (Lenzen et al 2012). However, these local insights are poorly coupled to larger scale assessments and life cycle analysis where impacts are only considered ‘on average’ ignoring the importance of local land systems as determinants of the impacts of these global relations.

For developing future perspectives on sustainable land management based on scenario approaches a better integration of feedbacks is needed, cf Delzeit et al (2018). Gaps still relate to understating land use intensity, landscape homogenization and the feedback between landscapes, agricultural production and biodiversity of managed landscapes (Seppelt et al 2016, Verburg et al 2016), specifically as humans shape emerging or novel ecosystems. Two understudied feedbacks pose major challenges for future global land systems research. First, the mutual dependence between biodiversity and agricultural production is

understudied in global studies and models: biodiversity is negatively affected through land-use intensification, which is mostly applied to boost yields. Maintaining yields on a high level, however, requires various facets of biodiversity for support of important ecosystem functions such as nutrient cycling, biocontrol or pollination (Seppelt et al 2016). Research for embedding these feedbacks quantitatively in globalscale models is advancing and could become crucial for global assessments in the near future (Rosa et al 2017).

Second, the feedback between commodity production and consumption are also understudied. Usually demand trajectories are predefined, such as by predefined scenarions, e.g. Delzeit et al (2018). Jevons paradox-like, rebound phenomena, which denote the increasing demand for a resource after establishing a more resource efficient production method (Alcott 2005), are mostly neglected in today’s scenarios analysis. This might hamper understanding of rebound effects and probably leads to overly positive estimates on certain scenarios.

Given the limited land resources available and multiple competing claims on these resources, sustainable land management should also include

Box 1. Outstanding questions of the emerging question in sustainable land management.

Enhancing understanding of the diversity of land systems

•Are the correct drivers addressed for investigating solutions on sustainable land management, considering the knowledge, values and rules define the decision context?   
•How to capture countries activities and characteristics properly to account for emerging issues such as large-scale land acquisition, or long-distance externalization of effects within global agro-economic models?   
•What are the options to govern land as global commons? Synthesis of place-based research results   
•Which are the next steps to enable global agro-economic models to address a larger set of commodities, different land-holding systems, capture nutrient cycling and provide sufficient information on food security question on a finger spatial resolution?   
•How can the tele-coupling concept be operationalized in research to better underpin and embed life cycle analysis in global relations?   
•Which data gaps should be closed to better account for local variations in the socio-economic context of sustainable land management?

Future perspectives and new scenarios

•How to implement the mutual feedback of biodiversity and agricultural production in today’s global model system estimation global agricultural yields and estimate optimum intensification levels?   
•To what extent do concepts like sustainable intensification that claim to have synergies between SDGs really have potential, what are the trade-offs hidden in these systems and in what local context are such concepts applicable?   
•How can integrated scenarios capture the links between production and consumption, rebound effects and Jevons paradox?

sustainable consumption (Scherer and Verburg 2017). While sustainable consumption is also one of the SDGs it is hardly related to land management. Recent work of Alexander et al (2016) shows the strong impacts of consumption and value-chain losses on agricultural production, indicating the potential reduction on land resources that can be achieved through improved consumption and value-chain management.

This focus collection provides several contributions in the fields of land system science to the development of concepts, models and tools for sustainable land management. To advance beyond the current state of the art, future research directions need to address a diversity of topical challenges such as poverty reduction, large-scale land acquisition, global feedbacks of agricultural production and biodiversity. While research questions can be developed easily, we acknowledge that further research needs shall not hamper action with respect to lowering pressure on the environment by all possible means. Research needs are no excuse for inaction (Voinov et al 2014).

# ORCIDiDs

Ralf Seppelt $\textcircled{1}$ https://orcid.org/0000-0002- 2723-7150

