# Environmental Impacts of Telecoupling of the Urban Consumption System of Organic Foods

Anelise Schmitz I Elaine Jordan II Tatiana Maria Cecy Gadda III

Abstract: The environmental impacts of the food system, especially the distances covered, are not clear to the final consumer. The aim was to evaluate and calculate the urban telecoupling and the environmental impacts and calculate the energy consumption and the environmental emissions of the organic foods. Through the calculation of quantities, distances, losses and the analysis of telecouplings, we measured Greenhouse Gas (GG) emissions, as well as the energy and carbon footprints of organic foods traded at the CEASA/PR, Curitiba. Emissions had a low environmental impact because the largest quantities of transported organics originate from production sites located within the greater Curitiba region. The study showed a consumption pattern supporting food produced in regions adjacent to the trading center in safe and healthy and safe way, which may be associated with a greater awareness of the environmental impacts resulting from the distances covered.

Keywords: Telecoupling; Energy Footprint; Carbon Footprint; Greenhouse Gases; Organics.

I Universidade Tecnológica Federal do Paraná e Universidade Federal do Paraná, Curitiba, PR, Brasil.

II Universidade Tecnológica Federal do Paraná, Curitiba, PR, Brasil.

III Universidade Tecnológica Federal do Paraná, Curitiba, PR, Brasil.

São Paulo. Vol. 26, 2023

Original Article

DOI: http://dx.doi.org/10.1590/1809-4422asoc20220018r2vu2023L2OA

# Introduction

Organic food products have positive attributes in regard to the environment insofar as they do not involve the use of pesticides, genetically modified inputs or synthetic additives. Nevertheless, society is often unaware of their source or of the environmental impacts associated to their transportation.

It is understood that distances and connections between the sending and receiving points of food products are necessary to face the challenge of supplying a growing population. Furthermore, there is a need to improve their traceability, reduce the associated Greenhouse Gas Emissions (GGE) and the distances involved in the transferals within telecoupled systems (MCCORD; TONINI; LIU, 2018; JORDAN; GADDA, 2020).

Telecoupling can be defined as a set of interactions among production, consumption and natural flows that makes it possible to observe the social, economic and environmental impacts of actors situated far distant (tele) from one another but who are connected (coupled) in some way (HULL; LIU, 2018; MCCORD; TONINI; LIU, 2018). Five interrelated components make up the telecoupling structure: systems, agents, flows, causes and effects (SUN; YU-XIN; LIU, 2017). Outstanding among the global consequences of the integrations present in telecoupling are the enhanced food security associated to the products the population consumes and the protection of the environment (FANG et al., 2016; HULL; LIU, 2018; MCCORD; TONINI; LIU, 2018). Thus consumption more appropriate to the planet’s biocapacity require systemic–type management of flows and resources. After all, the effects of telecoupling are not restricted to specific locations; they can occur anywhere on Earth. That means there is a need to rethink what is currently being consumed in an inadequate manner and to diminish environmental impacts globally (DÍAZ et al., 2018).

Studying the interactions stemming from telecouplings enables a reassessment of individuals’ relations with the environment. It could contribute, for example, to advancing aspects of the Sustainable Development Goals (SDG) agenda, especially goals: 2 – Zero Hunger and Sustainable Agriculture, 11 – Sustainable Cities and Communities, 12 – Responsible Consumption and Production, and 13 – Climate Action (UN, 2013).

Although organic food products are widely viewed as being free from environmental impacts, that is not actually true. There are environmental impacts stemming from the different stages of their production, transportation and consumption chains. In that context and motivated by the studies of Jordan and Gadda (2020), this research set itself the task of analyzing the impacts of the telecouplings involved in organic food trading.

The study sheds light on the origins of the organics and their respective distances and environmental impacts and it can be replicated based on the indicators of other localities thereby offering public policies an approach that considers land use patterns and distances covered by organics to get to the consumer market. In the literature, the presence of telecoupling research reports that include calculations of transportationassociated emissions is merely incipient. Thus the present study proposes to contribute to the state of the art in regard to telecoupling by proposing evaluation methodologies that enable estimations of transportation emissions.

This article set out to evaluate the telecouplings between sending and receiving systems based on the calculation of the environmental emissions and energy consumption of the transportation involved and the energy and carbon footprints of organic food traded in the Paraná State Supply Center (Central de Abastecimento do Paraná S/A – CEASA) in the city of Curitiba, Paraná.

# Theoretical Reference Framework

# Telecouplings

International trade connects distant regions by means of product, capital and information flows. The concept of telecouplings has emerged to address the sustainability challenges and socioeconomic aspects of those interconnections, seeking to track their respective flows. It is elaborated on the basis of a coupled human-natural system approach in a bid to understand connections between different systems and it classifies the connected systems as ‘sending’, and ‘receiving’ systems (SILVA et al., 2019). Many of the extant telecoupling studies concentrate on mapping the flows, the areas of production and associated vegetation cover losses, as, for example, those of Mccord; Tonini; Liu (2018); Yao; Hertel; Taheripour (2018); e Yao et al. (2020).

However, some of the research in this area has been incorporating quantitative analyses of the impacts. There are studies of the global biomass metabolism that investigate flows within systems to gain an understanding of the relations between changes occurring in one place and the impacts in others. An example is the evaluation, based on environmental footprints, of the telecouplings incorporated to trade flows (BRUCKNER et al., 2015). Such studies are few, however, are restricted to footprint calculation per territory and still lack a more detailed vision of the impacts.

Telecouplings are multi-scale and multidimensional, involving biophysical, social, economic, political or environmental aspects which may be at the global, national, regional or local level. They embrace coupled human and natural systems, fostering the possibility of formulating scenarios and distant connections interaction (HULL; LIU, 2018). They are structured to clarify the extant challenges to global sustainability (MCCORD; TO-NINI; LIU, 2018). Telecouplings are human-nature interactions over distances, such as occur, for example, in the vegetable trade and tourism industry chains (YAO et al., 2020).

Some studies have used addressed telecoupling analyses using multiregional input-output (MRIO) methods (YAO; HERTEL; TAHERIPOUR, 2018). Energy systems, including energy production, conversion, transportation, distribution and use, are essential in modern society. The telecoupling framework with its comprehensive and cross-disciplinary nature presents opportunities for a more profound and comprehensive understanding of energy sustainability (FANG et al., 2016).

Bruckner et al. (2015) present a structured general review and a comparative evaluation of extant land footprint accounting methods. They compare methods for measuring impacts in telecouplings on the global terrestrial system. Their study concludes that the available accounting methods have deficiencies mainly attributable to their coverage of

the product and supply chain and their lack of supply chain details. They suggest that footprint accounting needs to be improved, especially in regard to the transparency of the evaluation structures.

Jordan e Gadda (2020) analyzed the telecoupling distances of certified organic fruits traded in the Municipal Market of the city of Curitiba, Parana, and stated that the certified organic fruits often travelled long distances to get from their point of origin to their point of destination thereby constituting an environmental impact.

Telecoupling analysis enables the systematic evaluation of sustainability on different scales. However there are still very few studies that present quantitative analyses in a sub-national scale. In their telecouplings study, authors Deines, Liu and Liu (2016) investigated the future sustainability of urban water supply and found it to be determined by social and climatic factors such as population, economics, politics and technological development. Yao et al. (2020) conducted research into water shortage and poverty in China’s arid regions, measuring the water footprint and the effects of the vegetable trade on water shortage and income. Their model could be used to develop arid regions, manage natural resources and reduce poverty and it demonstrates how quantitative methodologies could contribute to public policies.

# Environmental impacts in multiple scales

The global and local impacts scenario affects biodiversity and the ecosystems. There are currently various factors with a negative effect on the environment among which are, burning off vegetation, excessive water consumption, and massive production of monocrops with poor rotation of crops in the food crop production of agribusiness (RAJÃO et al., 2020). Other points to underscore are the GG emissions of transportation and the ‘heat islands’ of the cities. On the other hand, there are notable positive impacts whenever there is more equitable food transferal and supply, better distribution of value and nearby interactions between the places of production and those of consumption (MCCORD; TONINI; LIU, 2018).

In that vein, the SDGs stand out as a “global appeal for action to end poverty, in all its forms, protect the environment and the climate and ensure that people can enjoy peace and prosperity” (UN, 2013). From that perspective, and with the intention of taking the SDGs into consideration, it is necessary to analyze consumption patterns. Consumption can be measured by methods used to calculate environmental footprints which are tools for calculating the impacts that consumption habits generate. They calculate the material and energy flows into and out of an economic system, converting them into areas of the planet’s surface that would be necessary to sustain the system in question.

One of the environmental footprints, the carbon footprint, is defined as the total amount of GG emissions associated to a given organization, activity or product. Another, the energy footprint, quantifies the energy incorporated in the products from the moment of their extraction, and including their transformation from raw material into finished components, their consumption and their loss or disposal (COSTA, 2008; BECKER et

al., 2012; ALVES, 2013; FERREIRA, 2018). The impacts stemming from GG emissions include increased frequency of extreme weather events. One way to evaluate the possible impacts on the environment requires the identification of consumption aspects, such as the energy necessary to produce vegetables (BRONDANI, 2014).

In Peking, local food suppliers have adopted an alternative form of supply. There is a friendly environment that fosters food security by means of a personal relationship between the supplier and the local consumer; as the connections are closer and the interactions more frequent so there is a fostering of a community to the benefit of sustainable development (LIU, 2018).

Telecoupling studies related to commodity flows show that, while those flows contribute towards rapid economic development, they are also associated to significant environmental damage and serious impacts on food security (MCCORD; TONINI; LIU, 2018; OZTURK, 2015).

Transformations towards equitable sustainability demand an alignment of food consumption. Scarcity of water and energy resources jeopardizes food security and the GG emissions harm the environment and people’s health (LUCENA; MASSUIA, 2021). In the precursory work of Houghton, Callander and Varney (1992) on the harmful impacts of GG emissions of automotive vehicles in transportation, the following aspects are underscored:

a) Nitrogen oxides (NOx) are gases that harm the respiratory system;   
b) Methane (CH4) is a gas almost insoluble in water that forms explosive mixtures with the air;   
c) Non-methane volatile organic compounds (NMVOC) are carcinogens and prolonged exposure to them may cause Leukemia.   
d) Carbon monoxide (CO) is a pollutant gas and contributes towards greater urban heat retention;   
e) Nitrous oxide (N2O) is one of the main gases contributing to the greenhouse effect and global warming;   
f) Carbon dioxide (CO2) is the main gas responsible for raising the temperature of the planet (global warming).

These GGs are listed in the State of Paraná’s Inventory of Atmospheric Pollutant Emissions (Inventário Estadual de Emissões Atmosféricas de Poluentes do Paraná). The document presents estimates of vehicle emissions per annum for various regions of the state. The city of Curitiba computed the following GG emissions: CO (62,457tons/year); NOx (5,525tons/year); RCHO - Aldehydes (336 tons/year); NMVOC (24,146 tons/year); CH4 (397 tons/year); PM – Particulate Matter (793 tons/year); SOx– Sulphur oxides (553 tons/year) (IAP, 2013). Recently, the Municipal Plan for the Mitigation of and Adaptation to Climate Change (Plano Municipal de Mitigação e Adaptação às Mudanças Climáticas) (2020), that commits the city of Curitiba to reduce its GGEs, calculated the emission of 3,505,046 tons of Carbon Dioxide Equivalent $\mathrm { ( C O } _ { 2 } \mathrm { e ) }$ ) and the emissions profile indicates that the transportation sector is the greatest contributor $( 6 6 . 6 \% )$ , followed by

the stationary energy sector $( 2 2 . 6 \% )$ and the waste sector $( 1 0 . 8 \% )$

# Organic food

Consumers associate their consumption of organics with their health and sustainable environment appeal, mainly due to the reduced use of agricultural pesticides in their production (GUIVANT, 2003). Organics’ prices, however, are an important obstacle to their accessibility. Companies that produce and trade in them report that difficulties are linked to factors such as: production outlet and (short) shelf life of the products, the mismatch between supply and demand; the (greater) demand for processed food; and the question of confidence in the veracity of the ‘organic’ nature of the product (DAVID; GUIVANT, 2020).

In spite of the difficulties, in the period 2010 to 2018, increased demand led to an annual average growth of $1 9 \%$ in the number of units of organic production, the number of registered organic producers grew by $1 7 \%$ and the number of certified organic producers increased from 5 to 22 thousand. In Brazil, the area occupied by organic production in 2017 went beyond 1.13 million hectares $0 . 4 \%$ of the area of arable land in Brazil) with more than 15 thousand producers (LIMA et al., 2020). Brazil’s Southern macro-region is the one that most consumes organic products $( 2 3 \% )$ , followed by the Northeast $( 2 0 \% )$ , Southeast $( 1 9 \% )$ , Center-west $( 1 7 \% )$ and North $( 1 4 \% )$ . The purchasing of organics is closely associated to fresh food products (ORGANIS, 2019).

The outstanding figure in this scenario is that of the subsistence farming companies working with organics and endeavoring to improve the Brazilian production chain of organics in the small and medium-sized farmers’ markets (ORGANICSNET, 2020). Organics are gaining space in the Paraná CEASA in Curitiba. where the Metropolitan Region’s organics producers market takes place (CEASA/PR, 2020). All over Brazil, The CEASAs seek to improve the trading and distribution of greens and vegetable products. It can be understood as a place that concentrates producers, traders and purchasers of those products (DOSSA; DENCK, 2018).

Draft Bill $\mathrm { n } ^ { \circ } 4 3 8 / 2 0 1 9$ , being processed by the legislative branch of the State of Parana, proposes that the metropolitan region of Curitiba (Greater Curitiba) should be entirely free of agricultural pesticides (BRASIL, 2019). That being so, the tendency will be for products to have greater trackability, in the future, from their origins through to the final consumer and in that way better control over organics will be obtained.

Marsden, Banks, Bristow (2000) stress the importance of public policies promoting new arrangements, alternative to the industrial agro-food model and based on the relations between producers and consumers, and of a new meaning for ‘quality’ in relation to food, based on preference for local, regional and natural foods.

# Methodological Procedures

This research investigated organic food products traded in the Curitiba CEASA.

It sought to make a methodological contribution to the evaluation of telecoupling processes and their environmental impacts based on the calculation of their GGEs, and their energy and carbon footprints. That is because, in the telecoupling literature there is a visible shortage of reports on research using quantitative approaches to environmental emissions associated to transportation.

Curitiba, the capital of the State of Parana, is situated in the Alto Iguaçu (upper Iguaçu) river basin and has a population of more than 1,948,600 in habitants (IBGE, 2020).

The sequence of research activities (see Figure 1) was as follows: (a) definition of the study area ; (b) inventorying the quantities of organics traded as registered in the database of the Brazilian Program for the Modernization of the Fruit, Greens and Vegetables Market (Programa Brasileiro de Modernização do Mercado Hortigranjeiro -PROHORT) (c) registration of the quantities of product waste associated to the trading process; (d) registration of the distances between origins and destinations obtained from the Google Mapps App; (e) research into GGEs and definition of the energy coefficients in MJ/kg, and of CO2 emissions in $K _ { \mathrm { g } } \mathrm { C O } 2 / \mathrm { k g }$ ; (f) calculation of the energy and carbon footprints; (g) mapping the telecouplings using QGIS software and (h) tabulating and analyzing the results.

Data were acquired from the database of the Brazilian National Supply Company (Companhia Nacional de Abastecimento -CONAB) which contains data on the trading activities of the CEASAs in its PROHORT portal available at https://www.conab.gov. br/info-agro/hortigranjeiros-prohort. A classificatory research activity was conducted to identify the quantities of organic food products (in kg) shipped to the Curitiba CEASA, from January to October, 2020, and classify them by origins.

The data gathered from the PROHORT consultation was compiled with a view to identifying: the organics and their respective quantities $( \mathrm { k g } )$ ), losses associated to transportation $( \% )$ , distances between origin and destination (km) obtained using Google Maps, energy consumption (MJ) of the transportation from sending to receiving, CO2 emissions of the transportation (g), and the calculations of the energy footprint (MJ) and the carbon footprint (kgCO2).

Figure 1 – Flow diagram of the proposed methodology   
![](images/e403740a9c052e57fbd818b51cf0c5d504de4fb70cba042c442db535164e816a.jpg)  
Source: the authors, 2021.

The losses of organics in the retail market were estimated according to references found in the works of Tofanelli et al. (2009); Cristofoli et al. (2014) and ABRAS (2019). Based on the identification of the municipalities of the origin of organics that are received by the Curitiba CEASA and with the use of the Google Maps app, it was possible to obtain the distances in kilometers associated to the transportation of the organics.

In the case of the energy consumption of transportation (Equation 1) the study considered the average fuel consumption indicator for road cargo transportation as estimated by Reis (1999) apud Kuhn (2006) and also cited by Schmitz, Libraga and Sattler (2020), for semi-heavy diesel-powered vehicles (mean consumption of a three-axle truck $= 0 . 7 8 \mathrm { x } 1 0 ^ { - 3 } \mathrm { M J } / \mathrm { k g . } \mathrm { k m } )$ , with the intention of presenting the worst energy consumption scenario.

$$
\text {E n e r g y c o n s t u p t i o n (M J)} = \left(\text {t h e o r e t i c a l c o n s t u p t i o n (k g) + l o s s} (\%)\right) x \text {d i s t a n c e (k m) x c o e f f i c i e n t o f c o n s t u p t i o n (0 . 7 8 x 1 0 - 3 M J / k g . k m)} \tag{1}
$$

The subsequent calculation of the environmental loads of the GGEs (Equation 2) took into account the fact that energy consumption associated to transportation is directly related to the mass being transported and to the distance covered. The estimated

pollutant emission factors were in accordance with the Intergovernmental Panel on Climate Change (1996b) apud Kuhn (2006), based on heavy vehicles and considering the following GG emission factors: NOx (1.0g/MJ); CH4 (0.006g/MJ); NMVOC (0.2g/MJ); CO (0.9g/MJ); N2O (0.003g/MJ); and CO2 (74g/MJ).

GG environmental load $( \mathrm { g } ) \ : = \ :$ energy consumption (MJ) x emission factor (g/ MJ) (2)

No up-to-date references for $\mathrm { g / M } ]$ of pollutants that take into account quantity, milage and the impact of transportation were found. Thus the estimates considered in this work are relatively high compared with actual emissions today as modern vehicles have more advanced technology and have lower pollutant emission levels.

To enable the calculation of the environmental footprints, the study needed coefficients for energy consumption expressed in Megajoules per kilogram $( \mathrm { M J / k g } )$ and for Carbon Dioxide emission expressed in kilograms of CO2 per kilogram of product $( \mathrm { k g } \mathrm { C O } 2 /$ kg). Through a survey of the international reference literature, the study obtained coefficients for each category of organic food from the works of González et al. (2011); Flores et al. (2016); Eriksson and Spångberg (2017); and Song (2017).

In regard to the energy footprint, the coefficients obtained from the different reference works were all converted into Megajoules per kilogram $( \mathrm { M J / k g } )$ ). Afterwards, the energy quantity totals were obtained in MJ for each category of organics. The energy footprint is represented in equation 3.

Energy footprint $( \mathrm { M J } ) \ =$ energy coefficient for the category (MJ/kg) x theoretical consumption $\mathrm { ( k g ) + l o s s \ ( \% }$ $( \% )$ (3)

For the carbon footprint (Equation 4), the coefficients obtained from the literature were converted into kilograms of carbon dioxide per kilogram $( \mathrm { k g C O } 2 / \mathrm { k g } )$ ) for each category of organic food. As mentioned above, due to the unavailability of data and information on carbon emissions in Brazilian reference works, that data was obtained from studies conducted in other countries.

Carbon footprint $( \mathrm { k g } { \mathsf { C O } } 2 ) \ = \mathrm { ~ C ~ }$ arbon coefficient for the category (kgCO2/kg) x (theoretical consumption $\mathrm { ( k g ) + l o s s \ : ( \% ) }$ $( \% )$ ) (4)

It is important to note that transportation energy consumption and its emissions complement one another (Equations 1 and 2) but they are independent of the values of the energy and carbon footprints of the food crop cultivation process (Equations 3 and 4).

Total analysis of the footprints, referencing them with the land area and the numbers of inhabitants made it possible to evaluate the environmental impacts of the telecoupling

of organic foods of the Curitiba Ceasa.

Telecouplings mapping used the QGIS georeferencing software applied to the distances and volumes between the sending and receiving systems of the telecouplings. The critical distances of municipalities that only shipped very small amounts of organic foods to Curitiba were disregarded.

# Results

The study identified eighteen organic products traded in the Curitiba CEASA, namely: pumpkin, courgette, lettuce, eggplant, beetroot, broccoli, onion, carrot, chayote, cauliflower, escarole endive, spinach, strawberry, sweet pepper, cabbage, rocket, tomato, and green bean. Quantities in kilograms per origin-destination and total quantities between cities and the unit of the Brazilian Federation (state or Federal District) the products were coming from were also classified (Figure 2).

The study also identified forty-six cities of origin and five states, namely Paraná, São Paulo, Rio Grande do Sul, Minas Gerais e Espírito Santo and the most representative cities/municipalities in terms of amounts shipped to the receiving city per type of organic product were Colombo, Piraquara, Mandirituba, Morretes and São José dos Pinhais.

Figure 2 – Telecouplings of the Curitiba, Paraná CEASA organics   
![](images/c6bd26361fd23320e214fa117caf5b70e21dbf7458fc52dc5547c63fffc83228.jpg)  
Source: the authors, 2021.

According to the PROHORT data, the five most consumed organic food items were lettuce, tomato, green bean, courgette and rocket. The quantities of all the others are displayed in Table 1. It can be seen that when the losses stemming from the sendingreceiving process are added to the theoretical consumption there is an increase in the quantity figures.

In regard to the energy consumption of transportation expressed in MJ, the same five organic foods stood out. The least expressive energy consumption was associated to the trading of escarole endive (0.11MJ), spinach (0.11MJ) and strawberry (0.90MJ).

Table 1 – Quantities and sending to receiving point distances   

<table><tr><td>Type1</td><td>Quantity (Kg)1</td><td>Loss (%)2</td><td>Loss (kg)</td><td>Theoretical Consump- tion + loss (kg)</td><td>Dis- tance (km)3</td><td>Place of origin (critical distan- ce)1</td><td>Total energy con- sumption (MJ)4</td></tr><tr><td>Pumpkin</td><td>777</td><td>0.7</td><td>5.44</td><td>782.44</td><td>20</td><td>Colombo. PR</td><td>12.21</td></tr><tr><td>Courgette</td><td>17589</td><td>10.0</td><td>1758.90</td><td>19347.90</td><td>20</td><td>Colombo. PR</td><td>301.83</td></tr><tr><td>Lettuce</td><td>98061</td><td>15.8</td><td>15493.64</td><td>113554.64</td><td>20</td><td>Colombo. PR</td><td>1771.45</td></tr><tr><td>Eggplant</td><td>2185</td><td>25.5</td><td>557.18</td><td>2742.18</td><td>20</td><td>Colombo. PR</td><td>42.78</td></tr><tr><td>Beetroot</td><td>3642</td><td>10.2</td><td>371.48</td><td>4013.48</td><td>20</td><td>Colombo. PR</td><td>62.61</td></tr><tr><td>Broccoli</td><td>26</td><td>25.5</td><td>6.63</td><td>32.63</td><td>20</td><td>Colombo. PR</td><td>0.51</td></tr><tr><td>Onion</td><td>3024</td><td>6.1</td><td>184.46</td><td>3208.46</td><td>20</td><td>Colombo. PR</td><td>50.05</td></tr><tr><td>Carrot</td><td>5172</td><td>10.9</td><td>563.75</td><td>5735.75</td><td>43</td><td>Mandirituba. PR</td><td>192.38</td></tr><tr><td>Chayote</td><td>65</td><td>8.3</td><td>5.40</td><td>70.40</td><td>69</td><td>Morretes. PR</td><td>3.79</td></tr><tr><td>Cauliflower</td><td>7496</td><td>28.6</td><td>2143.86</td><td>9639.86</td><td>20</td><td>Colombo. PR</td><td>150.38</td></tr><tr><td>Escarole endive</td><td>8</td><td>15.8</td><td>1.26</td><td>9.26</td><td>15</td><td>São José dos Pinhais. PR</td><td>0.11</td></tr><tr><td>Spinach</td><td>8</td><td>15.8</td><td>1.26</td><td>9.26</td><td>15</td><td>São José dos Pinhais. PR</td><td>0.11</td></tr><tr><td>Strawberry</td><td>51</td><td>13.7</td><td>6.99</td><td>57.99</td><td>20</td><td>Colombo. PR</td><td>0.90</td></tr><tr><td>Sweet pepper</td><td>33</td><td>13.5</td><td>4.46</td><td>37.46</td><td>43</td><td>Mandirituba. PR</td><td>1.26</td></tr><tr><td>Cabbage</td><td>5802</td><td>19.1</td><td>1108.18</td><td>6910.18</td><td>20</td><td>Colombo. PR</td><td>107.80</td></tr><tr><td>Rocket</td><td>10606</td><td>15.8</td><td>1675.75</td><td>12281.75</td><td>29</td><td>Piraquara. PR</td><td>277.81</td></tr><tr><td>Tomato</td><td>40940</td><td>14.6</td><td>5977.24</td><td>46917.24</td><td>20</td><td>Colombo. PR</td><td>731.91</td></tr><tr><td>Green bean</td><td>28108</td><td>25.5</td><td>7167.54</td><td>35275.54</td><td>20</td><td>Colombo. PR</td><td>550.30</td></tr></table>

Source: the authors, 2020. Based on   
1 PROHORT for the year 2020. http://dw.ceasa.gov.br/   
2 Tofanelli et al. (2009); Cristofoli et al. (2014) and ABRAS (2019)   
3 Google maps: https://www.google.com.br/maps   
4 Energy consumption of a semi-heavy, three axle truck (energy consumption $= 0 . 7 8 \mathrm { x } 1 0 . 3 \mathrm { M J / k g . k m ) }$

multiplied by the distance covered and the theoretical weight.

The combustion emissions in grams (g) can be seen in Table 2. The total NOx emission was $4 2 5 8 . 1 8 \mathrm { g }$ ; for CH4 it was $2 5 . 5 5 \mathrm { g }$ ; there were $8 5 1 . 6 4 \mathrm { g }$ of NMVOC emissions, the CO emission was 3,832.36g; N2O emission, 12.77g, and $3 1 5 , 1 0 5 . 2 7 \mathrm { g }$ of CO2 were emitted.

Table 2 – Emissions in grams (g) of the sending system to receiving system transportation   

<table><tr><td>Transported Product</td><td>NOx</td><td>CH4</td><td>NMVOC</td><td>CO</td><td>N2O</td><td>CO2</td></tr><tr><td>Pumpkin</td><td>12.21</td><td>0.07</td><td>2.44</td><td>10.99</td><td>0.04</td><td>903.25</td></tr><tr><td>Courgette</td><td>301.83</td><td>1.81</td><td>60.37</td><td>271.64</td><td>0.91</td><td>22,335.22</td></tr><tr><td>Lettuce</td><td>1771.45</td><td>10.63</td><td>354.29</td><td>1594.31</td><td>5.31</td><td>131,087.47</td></tr><tr><td>Eggplant</td><td>42.78</td><td>0.26</td><td>8.56</td><td>38.50</td><td>0.13</td><td>3,165.57</td></tr><tr><td>Beetroot</td><td>62.61</td><td>0.38</td><td>12.52</td><td>56.35</td><td>0.19</td><td>4,633.17</td></tr><tr><td>Broccoli</td><td>0.51</td><td>0.00</td><td>0.10</td><td>0.46</td><td>0.00</td><td>37.67</td></tr><tr><td>Onion</td><td>50.05</td><td>0.30</td><td>10.01</td><td>45.05</td><td>0.15</td><td>3,703.85</td></tr><tr><td>Carrot</td><td>192.38</td><td>1.15</td><td>38.48</td><td>173.14</td><td>0.58</td><td>14,235.90</td></tr><tr><td>Chayote</td><td>3.79</td><td>0.02</td><td>0.76</td><td>3.41</td><td>0.01</td><td>280.36</td></tr><tr><td>Cauliflower</td><td>150.38</td><td>0.90</td><td>30.08</td><td>135.34</td><td>0.45</td><td>11,128.25</td></tr><tr><td>Escarole endive</td><td>0.11</td><td>0.00</td><td>0.02</td><td>0.10</td><td>0.00</td><td>8.02</td></tr><tr><td>Spinach</td><td>0.11</td><td>0.00</td><td>0.02</td><td>0.10</td><td>0.00</td><td>8.02</td></tr><tr><td>Strawberry</td><td>0.90</td><td>0.01</td><td>0.18</td><td>0.81</td><td>0.00</td><td>66.94</td></tr><tr><td>Sweet pepper</td><td>1.26</td><td>0.01</td><td>0.25</td><td>1.13</td><td>0.00</td><td>92.96</td></tr><tr><td>Cabbage</td><td>107.80</td><td>0.65</td><td>21.56</td><td>97.02</td><td>0.32</td><td>7,977.11</td></tr><tr><td>Rocket</td><td>277.81</td><td>1.67</td><td>55.56</td><td>250.03</td><td>0.83</td><td>20,558.17</td></tr><tr><td>Tomato</td><td>731.91</td><td>4.39</td><td>146.38</td><td>658.72</td><td>2.20</td><td>54,161.26</td></tr><tr><td>Green bean</td><td>550.30</td><td>3.30</td><td>110.06</td><td>495.27</td><td>1.65</td><td>40,722.08</td></tr><tr><td>TOTAL</td><td>4,258.18</td><td>25.55</td><td>851.64</td><td>3,832.36</td><td>12.77</td><td>315,105.27</td></tr></table>

Source: Authors, 2020. Based on the pollutant emissions references of the Intergovernmental Panel on Climate Change (1996b) apud Kuhn (2006).

The total weight of organics shipped in the period was 260.63 tons. Based on the calculations, and the coefficients corresponding to the energy and carbon footprints it was possible to identify a total energy consumption of de 521,522.4 MJ and a total carbon dioxide emission of 65,291.86 kg. The respective results are displayed in Table 3 below.

Table 3 – Quantities and contributions of the energy and carbon footprints   

<table><tr><td>Trans- ported product</td><td>Weight (kg)</td><td>Category coefficient (MJ/kg)</td><td>Total ener-gyl (MJ)</td><td>Energy contribu-tion (%)</td><td>Category coefficient (kgCO2/ kg)</td><td>Total Carbon (kgCO2)</td><td>Car- bon con- tribu-tion (%)</td></tr><tr><td>Pumpkin</td><td>782.44</td><td>0.96</td><td>751.14</td><td>0.14</td><td>0.09</td><td>70.42</td><td>0.11</td></tr><tr><td>Courgette</td><td>19347.90</td><td>0.96</td><td>18573.98</td><td>3.56</td><td>0.21</td><td>4063.06</td><td>6.22</td></tr><tr><td>Lettuce</td><td>113554.64</td><td>1.40</td><td>158976.50</td><td>30.48</td><td>0.13</td><td>14762.10</td><td>22.61</td></tr><tr><td>Eggplant</td><td>2742.18</td><td>1.97</td><td>5402.08</td><td>1.04</td><td>1.35</td><td>3701.94</td><td>5.67</td></tr><tr><td>Beetroot</td><td>4013.48</td><td>1.10</td><td>4414.83</td><td>0.85</td><td>0.11</td><td>441.48</td><td>0.68</td></tr><tr><td>Broccoli</td><td>32.63</td><td>3.60</td><td>117.47</td><td>0.02</td><td>0.37</td><td>12.07</td><td>0.02</td></tr><tr><td>Onion</td><td>3208.46</td><td>1.00</td><td>3208.46</td><td>0.62</td><td>0.10</td><td>320.85</td><td>0.49</td></tr><tr><td>Carrot</td><td>5735.75</td><td>0.97</td><td>5563.68</td><td>1.07</td><td>0.09</td><td>516.22</td><td>0.79</td></tr><tr><td>Chayote</td><td>70.40</td><td>0.96</td><td>67.58</td><td>0.01</td><td>0.09</td><td>6.34</td><td>0.01</td></tr><tr><td>Cauliflower</td><td>9639.86</td><td>3.60</td><td>34703.48</td><td>6.65</td><td>0.37</td><td>3566.75</td><td>5.46</td></tr><tr><td>Escarole endive</td><td>9.26</td><td>1.40</td><td>12.97</td><td>0.00</td><td>0.47</td><td>4.35</td><td>0.01</td></tr><tr><td>Spinach</td><td>9.26</td><td>1.40</td><td>12.97</td><td>0.00</td><td>0.34</td><td>3.15</td><td>0.00</td></tr><tr><td>Strawberry</td><td>57.99</td><td>2.80</td><td>162.36</td><td>0.03</td><td>0.21</td><td>12.18</td><td>0.02</td></tr><tr><td>Sweet pepper</td><td>37.46</td><td>14.50</td><td>543.10</td><td>0.10</td><td>0.94</td><td>35.21</td><td>0.05</td></tr><tr><td>Cabbage</td><td>6910.18</td><td>1.10</td><td>7601.20</td><td>1.46</td><td>0.12</td><td>829.22</td><td>1.27</td></tr><tr><td>Rocket</td><td>12281.75</td><td>1.40</td><td>17194.45</td><td>3.30</td><td>0.13</td><td>1596.63</td><td>2.45</td></tr><tr><td>Tomato</td><td>46917.24</td><td>3.00</td><td>140751.70</td><td>26.99</td><td>0.37</td><td>17359.38</td><td>26.59</td></tr><tr><td>Green bean</td><td>35275.54</td><td>3.50</td><td>123464.40</td><td>23.67</td><td>0.51</td><td>17990.53</td><td>27.55</td></tr><tr><td>TOTAL</td><td>260,626.41</td><td></td><td>521,522.40</td><td>100.00</td><td></td><td>65,291.86</td><td></td></tr></table>

Source: The authors, 2020. Based on the category coefficients found in González et al. (2011); Flores et al. (2016); Eriksson and Spångberg (2017) and Song (2017).

Notably, as shown earlier, the greatest emissions correspond to the five most traded products in the products ranking. That is because, in general, the emissions were proportional to the quantities and losses of the traded products and to the respective sending point to receiving point distances.

Lettuce is the product whose sending and receiving has the biggest energy footprint, responding for $3 0 . 4 8 \%$ of all the energy consumed, while green bean is the greatest contributor to the carbon footprint with $2 7 . 5 5 \%$ of the carbon dioxide emissions.

Sweet pepper had an energy footprint higher than the other organics because different reference sources for the coefficients were used and there are discrepancies in the

literature in regard to the aspects of production period, place and technique.

The greater part of the energy footprint $( 9 4 . 6 5 \% )$ ) of the organic food products in this study was determined by the impacts associated to the shipping of Lettuce, Tomato, Green bean, Cauliflower, Courgette and Rocket. There is an observable variation in each product’s contribution and most of the organics with higher impacts are in the group with the greatest weights transported.

# Discussion

Lettuce is among the most intensely traded organics in this study and even though it is largely produced in places close to Curitiba, it is highly perishable and needs to be carefully preserved, with special conditions of accommodation and logistics, from the moment of harvesting and throughout the transportation process until it reaches the final consumer.

The energy footprint of organic food products was 521,522.40 MJ. Given that $1 \ \mathrm { M J }$ is equivalent to $0 . 2 8 \mathrm { \ k W h }$ then the footprint would correspond to an electricity consumption in the studied period of $1 4 6 , 0 2 6 . 2 7 \mathrm { k W h }$ . Considering the mean electricity consumption of an average Brazilian home to be $1 5 2 . 2 \mathrm { k W h } / $ /month (FEDRIGO et al., 2009), then the telecoupling of organics traded through the Curitiba CEASA would be equivalent to the electricity consumption of 96 families a month.

The energy footprint per municipal resident of the sending and receiving system alone was calculated as 0.27 MJ per capita. Taking into account the areas of the cities, the total value obtained was 1,199.20MJ/km² or $3 3 5 . 7 8 \mathrm { k W h / k m ^ { 2 } } .$ .That kind of data on a municipal scale provides an initial characterization for future comparison with other cities or other periods.

To compensate for each ton of CO2 emitted, it would be necessary to plant 7.14 trees (TJPR, 2022). That means about 466 trees should be planted to sequester the carbon and reduce the impact of the $6 5 , 2 9 1 . 8 6 \mathrm { k g }$ load of CO2 calculated in this research. The per capita carbon footprint is $0 . 0 3 \mathrm { k g } \mathrm { C O } 2$ and the Carbon Footprint expressed in terms of area is $1 5 0 . 1 3 \mathrm { k g } \mathrm { C O } 2 / \mathrm { k m } ^ { 2 }$ , for which the compensation to capture the carbon dioxide emissions would require the planting of an average of one tree per hectare.

It is important to bear in mind that there are other markets, such as the municipal market, trading in organics and the distances covered transporting products to them are often of intercontinental dimensions as shown by Jordan and Gadda (2020). If a simulation were to be made of such an increase in transportation distances to Curitiba of products coming from so very far away, then the environmental impact calculation could be far greater.

During the data gathering stage, it proved to be difficult to obtain some of the regional and national-level data on carbon emissions and energy consumption. That made it necessary to seek references of other countries and even to adapt them to the local reality as those countries do not necessarily have the same background in organic food production as Brazil.

It must be stressed that this study makes an important contribution insofar as telecoupling studies are still merely incipient in Brazil. Most of the international studies address the theme of commodity flows among countries and papers on the impacts of the telecouplings of organic food products are rare. Equally rare are studies focusing on urban telecouplings, especially those with a quantitative approach such as this study proposes. Insofar as it associates the studies of emissions and carbon and energy footprints with telecoupling, this study contributes towards achieving a far broader approach to the impacts of urban telecouplings.

It is important that future studies should address much broader time frames so that the changes in telecouplings’ environmental impacts in the course of time can be investigated. Another important aspect to underscore is the need to relate telecoupling studies to global environmental changes such as changes in land use patterns. This study did not compute the water footprint, but it is strongly recommended that future telecoupling research should devote specific attention to it considering the vast amounts of water needed to irrigate food crops. In the study area of the present research, the Upper Iguaçu basin where Curitiba is located, there is already evidence of water shortage and threats to sustainability.

# Final Considerations

This research aimed to evaluate the environmental impacts of urban telecouplings of the systems for sending and receiving organic foods. To that end it calculated the energy and carbon footprints of organic food production and the energy consumption and emissions of organic food transportation. The research focused on the organic food products traded in the Curitiba CEASA in the state of Paraná, identifying the telecoupling flows from the sending points of origin to the receiving point in the course of the year 2020. The study identified 18 different types of organic food coming in from 46 different cities/ municipalities and five Brazilian states. Data gathered from the PROHORT platform served as the reference for obtaining a view of the origins and consumption of those organic foods. Thus the study effectively conducted an analysis, at the sub-national level, of the environmental impacts associated to the distances covered by the food products in the trajectory from their places of production to the consumer market.

The study showed that there was a quantitative relation between the amounts of the food products being shipped and the dimensions of their energy and carbon footprints, for the greater the amount, the greater their contribution to the impacts. In regard to GGEs, NOx corresponded to an environmental load of 4,258.18 g; CH4 to one of 25.55 g; and the NMVOC emissions to $8 5 1 . 6 4 \mathrm { g } ,$ , while CO emissions were of 3,832.36 g, N2O was 12.77 g and the CO2 load was 315,105.27 g. These estimates of the emissions that the transportation generated represent less than $1 \%$ of the city of Curitiba’s annual emissions as measured by the IAP (2013).

In the period studied, the per capita energy footprint was found to be 0.27 MJ and per the square kilometer value was 1,199.20MJ/km². The values for the carbon footprint

were $0 . 0 3 \mathrm { k g } \mathrm { C O } 2$ per capita and an estimated $1 5 0 . 1 3 \mathrm { k g } \mathrm { C O } 2 / \mathrm { k m } ^ { 2 }$ by area. In the case of the study area, there are no reference parameters available for comparison of these values. Thus the presupposition here is that the calculated estimates based on the GGEs represent a low impact on the environment. That is because most of the organics come from municipalities near to Curitiba, so the location has a positive impact. Even though there is some impact, if the production were much farther away the impact would be negative.

As regards pollutant emissions, the greater the volume transported and the distances covered, the greater were the GG emissions. In this study, among the organics, lettuce was the product with the greatest representation in trading and in the aspect of emissions. However, it cannot be stated that there was any correlation with the impact of non-organic lettuce as that would require another study to enable the comparison. The municipality of Colombo, which borders on Curitiba, was the greatest supplier of organics to the Curitiba CEASA, accounting for $5 5 \%$ of all that was transported.

Compensating for the environmental impact on the area stemming from the telecoupling of organics would require the planting of around 466 trees to sequester the carbon emissions and the consumption transformed into electricity would be 14,602.63 kWh/month for the year studied.

Organic products will only have their impact reduced if the place of production is close to the place of consumption. Reducing the distances reduces the environmental footprints and GG emissions associated to transportation. This slant on energy outlay, food product trading, and emissions, associated to telecoupling shows that consumption needs to be more conscientious and that there is an increasing need for a trackability policy.

It is important that changes in consumer patterns should prevail in regard to healthy food and preference be given to locally produced foods thereby avoiding negative impacts stemming from the telecoupling system. Attention must also be paid to the losses incurred due to mishandling in the sending, transportation, and receiving of products.

Lastly, it is suggested that a regional and urban management of the food system embracing production and consumption and food consumption planning taking into consideration energy and water aspects, would collaborate towards achieving positive environmental changes and conscientious consumer patterns and would also address the Sustainable Development Goals and Targets that the UN has established.

# Anelise Schmitz

✉ anelise.schmitz@gmail.com

ORCiD: http://orcid.org/0000-0002-3028-1320

Submitted on: 02/03/2022

Accepted on: 22/11/2022

2023;26e:00182

# Elaine Jordan

✉ elainenjordan@gmail.com

ORCiD: https://orcid.org/0000-0001-6974-4110

# Tatiana Maria Cecy Gadda

✉ tatianagadda@utfpr.edu.br

ORCiD: https://orcid.org/0000-0002-7918-2104

# Impactos Ambientais dos Teleacoplamentos do Sistema de Consumo Urbano de Alimentos

Anelise Schmitz Elaine Jordan Tatiana Maria Cecy Gadda

Resumo: O sistema de alimentação produz impactos ambientais que não são evidentes para o consumidor final, especialmente em relação às distâncias percorridas. O objetivo da pesquisa foi avaliar os teleacoplamentos urbanos e os impactos ambientais a partir do cálculo do consumo energético e das emissões ambientais dos produtos alimentí- cios orgânicos. Por meio de quantitativos, distâncias, perdas e análise dos teleacoplamentos, mediram-se as emissões de Gases de Efeito Estufa - GEE, a pegada energética e a pegada de carbono dos alimentos orgânicos comercializados na CEASA/PR, Curitiba. As emissões representaram baixo impacto ao meio ambiente, pois a maior quantidade de orgânicos transportada origina-se de locais de produção que se situam na Região de Curitiba. O estudo evidencia um padrão de consumo privilegiando o alimento produzido nas regiões adjacentes ao comércio, de modo saudável e seguro, que deve estar associado a maior consciência dos impactos ambientais decorrentes das distâncias percorridas.

Palavras-chave: Teleacoplamentos; Pegada Energética; Pegada de Carbono; Gases de Efeito Estufa; Orgânicos.

São Paulo. Vol. 26, 2023

Artigo Original

# Impactos Ambientales de los Teleacoplamientos del Sistema de Consumo Urbano de Alimentos Orgánicos

Anelise Schmitz

Elaine Jordan

Tatiana Maria Cecy Gadda

Resumen: El sistema de alimentación produce impactos ambientales que no son evidentes para el consumidor final, especialmente en relación a las distancias recorridas. El objetivo de la investigación fue evaluar los teleacoplamientos urbanos y los impactos ambientales a partir del cálculo del consumo energético y de las emisiones ambientales de los productos alimenticios orgánicos. Mediante cuantitativos, distancias, perdidas y de las análisis de los teleacoplamientos, se midieron las emisiones de Gases de Efecto Invernadero – GEI, la huella energética y la huella de carbono de los alimentos orgánicos comercializados en el CEASA/PR, Curitiba. Las emisiones representaron un bajo impacto al medio ambiente, pues la mayor cantidad de orgánicos transportada se origina en locales de producción que están en la Región de Curitiba. El estudio deja en evidencia un modelo de consumo que privilegia el alimento producido en las regiones aledañas al comercio, de forma saludable y segura, que debe estar asociado a una mayor conciencia de los impactos ambientales derivados de las distancias recorridas.

Palabras-clave: Teleacoplamientos; Huella Energética; Huella de Carbono; Gases de Efecto Invernadero; Orgánicos.

São Paulo. Vol. 26, 2023

Artículo Original
