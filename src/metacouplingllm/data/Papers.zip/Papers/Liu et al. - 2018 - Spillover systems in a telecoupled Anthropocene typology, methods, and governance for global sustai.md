# Spillover systems in a telecoupled Anthropocene typology, methods, and governance for global sustai

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:54:50.787157+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Liu et al. - 2018 - Spillover systems in a telecoupled Anthropocene typology, methods, and governance for global sustai.pdf
- Year: unknown
- DOI: 10.1016/j.cosust.2018.04.009
- OA status: green
- License: none recorded
- Category: Journal Articles\Conceptual\Telecoupling
- Closed-access reason: green OA without permissive license (none)

## Copyright-Safe Summary
This conceptual paper develops the idea of spillover systems within the telecoupling framework and proposes ways to classify, study, and govern them for global sustainability. Its focus is global rather than on a single geographic region, and it is firmly centered on telecoupling and broader metacoupling debates.

Telecoupling describes socioeconomic and environmental interactions over distance, such as trade, migration, species invasions, and tourism. Within this framework, sending and receiving systems exchange flows, while spillover systems are other places and communities that are affected by, or help mediate, those exchanges. The authors argue that these spillover systems are pervasive but often invisible in research and policy.

They propose a typology of spillover systems based on six criteria: (1) how they are linked to sending and receiving systems through flows (including stopovers and systems linked only to senders or only to receivers); (2) whether they are spatially distant or adjacent; (3) whether effects are predominantly positive or negative; (4) the spatial or demographic size of the affected system; (5) whether agents in spillover systems play active or passive roles; and (6) how spillover systems originate, including transformations of previous sending or receiving systems and entirely new spillover systems. Examples span global commodity chains, species invasions, climate impacts from transport emissions, and local land-use changes around large infrastructure and development projects.

The paper reviews a broad portfolio of qualitative, quantitative, and mixed methods for detecting and analyzing spillover systems: ethnography, interviews, archival work, remote sensing, GIS, econometrics, footprint and input-output analysis, network analysis, and simulation modeling.

For governance, the authors call for integrating spillover systems into telecoupling governance using an overall goal of reducing harmful and enhancing beneficial spillovers, guided by three principles: fairness, responsibility, and capability. They highlight the need for both place-based and flow-based governance, tailored to different spillover types, and emphasize the role of mediating agents and extension programs in making spillovers visible and actionable.

## Structured Metacoupling Extraction

### Coupling Classification
- Conceptual telecoupling paper emphasizing spillover systems linking distant human nature systems

### Intracoupling
#### Systems
- Local farming communities affected by nearby irrigation or conservation projects
- Villages near economic corridors expanding cash crop cultivation
#### Flows
- Water redistribution within river basins
- Knowledge and technology diffusion among neighboring farmers
#### Agents
- Smallholder farmers coordinating irrigation and production
- Local irrigators associations and extension agents
#### Causes
- Domestic development or conservation policies
- Local adoption of new agricultural systems
#### Effects
- Changed local land use patterns and crop choices
- Altered biodiversity and agrodiversity within landscapes

### Pericoupling
#### Systems
- Adjacent farmers near newly irrigated fields
- Rural villages bordering the East West Economic Corridor
#### Flows
- Overflow water and shared irrigation infrastructure
- Market access and transport along regional corridors
#### Agents
- Local governments implementing infrastructure
- Nearby villagers adopting profitable crops
#### Causes
- Internationally funded irrigation and corridor projects
- Spillover from targeted development investments
#### Effects
- New market outlets and income opportunities nearby
- Indirect land use change in surrounding communities

### Telecoupling
#### Systems
- Global soybean trade among Brazil China USA and fertilizer suppliers
- International panda loans linking China zoos and bamboo producing regions
- Transcontinental species invasions and tourism related CO2 emissions
#### Flows
- Soybeans fertilizers capital and trade information
- Pandas bamboo tourism and conservation funding
- Ballast water organisms invasive ants and greenhouse gases
#### Agents
- Governments traders shipping companies agribusiness firms
- Zoos conservation agencies tourists and airlines
- Port authorities land investors mediating extension agents
#### Causes
- Rising global demand for food energy and tourism
- Trade agreements geopolitical conflicts and market shifts
- Infrastructure expansion and global transportation networks
#### Effects
- Deforestation biodiversity loss and pollution in distant regions
- Positive income for suppliers and education benefits for visitors
- Drinking water crises climate impacts and new invasions

### Cross-Coupling Interactions
- Systems may simultaneously act as sending receiving and spillover nodes in overlapping telecouplings
- Governance or conservation in one place can displace pressures to other distant regions
- Converted sending or receiving systems become spillover systems under changing global trade

### Research Gaps or Limitations
- Spillover systems often hidden and underrepresented in policy and empirical datasets
- Limited integrated models capturing multiple spillover types and cascading effects
- Governance instruments rarely designed to explicitly include spillover systems

### Search Keywords
- telecoupling spillover systems typology
- distant and adjacent spillover governance
- soybean trade panda loans invasive species

### Extraction Confidence
high
