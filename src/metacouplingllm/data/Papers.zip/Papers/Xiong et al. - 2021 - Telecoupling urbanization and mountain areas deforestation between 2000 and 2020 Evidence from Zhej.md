# Telecoupling urbanization and mountain areas deforestation between 2000 and 2020 Evidence from Zhej

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:12:35.906175+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Xiong et al. - 2021 - Telecoupling urbanization and mountain areas deforestation between 2000 and 2020 Evidence from Zhej.pdf
- Year: unknown
- DOI: 10.1002/ldr.4074
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper examines how rapid urbanization in Zhejiang Province, China, has been linked to deforestation in mountain areas between 2000 and 2020, using a telecoupling perspective. Zhejiang is a highly developed, mountainous coastal province where forest, farmland, and built-up land strongly compete.

The authors integrate several spatial datasets and official statistics: 30 m GlobeLand30 land cover maps for 2000, 2010, and 2020; Hansen global forest change data (annual forest loss, 2001-2019); ESA-CCI land cover (300 m, 2000-2018); and Zhejiang land-use statistics, supported by field checks. They assess provincial-scale changes and then focus on a telecoupled city pair: the highly urbanized Hangzhou and the less developed, mountainous Lishui.

Remote sensing shows substantial net forest loss in Zhejiang despite official reports of forest increase. Net forest area declined by several percent since 2000, concentrated in western and southern mountainous municipalities, with Lishui losing the most. At the same time, urban land grew dramatically (about 1.7 times its 2000 area), mainly by converting nearby cropland. To maintain a mandated provincial balance of cropland under China’s Balance of Arable Land System (BALS), new farmland was created largely by clearing forest, especially in less urbanized interior areas.

Hangzhou’s expansion thus displaced cropland, while Lishui, with slower growth and more reserved land, supplied replacement cropland through deforestation. Financial and land-use flows between municipalities, mediated by provincial policy, connect these distant outcomes. The paper interprets this as a clear telecoupling: urbanization in one municipality indirectly drives forest loss in another through the no-net-loss cropland policy.

The study is explicitly about telecoupling/metacoupling. It shows how a well-intended land protection policy, when evaluated only on cropland quantity, can shift environmental burdens from core cities to remote mountain regions, refine forest transition theory, and highlight the need to integrate ecological quality and distant impacts into land policy design.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling between urbanization and distant mountain deforestation within Zhejiang; limited explicit intracoupling, weak pericoupling.

### Intracoupling
#### Systems
- Provincial land system of Zhejiang as a whole
- Mountain forest landscapes inside Zhejiang
- Provincial cropland and urban land system
#### Flows
- Internal conversion among forest, cropland, and urban land
- Provincial financial transfers for land consolidation
- Internal policy directives on cropland balance
#### Agents
- Zhejiang provincial government and planning bureaus
- Municipal governments across Zhejiang
- Local farmers and rural collectives
#### Causes
- Rapid provincial economic growth and urbanization
- Implementation of cropland balance and protection policies
- Demand to secure food production with limited land
#### Effects
- Net provincial forest loss and cropland decline
- Expansion of artificial surfaces in cities
- Ecosystem degradation and forest fragmentation

### Pericoupling
#### Systems
- Not identified.
#### Flows
- Not identified.
#### Agents
- Not identified.
#### Causes
- Not identified.
#### Effects
- Not identified.

### Telecoupling
#### Systems
- Highly urbanized Hangzhou municipality as receiving system
- Less urbanized Lishui mountain municipality as sending system
- Provincial or national authorities as mediating governance system
#### Flows
- Cropland development quotas flowing from Lishui to Hangzhou
- Financial compensation and investment flowing from Hangzhou to Lishui
- Policy and administrative orders reallocating land responsibilities
#### Agents
- National ministries designing BALS and land policies
- Provincial land and natural resource bureaus
- Municipal leaders negotiating cross-region land arrangements
#### Causes
- No net loss cropland rule driving offsite compensation
- Urban land demand exceeding local cropland availability in Hangzhou
- Surplus land and outmigration in Lishui enabling cropland expansion
#### Effects
- Deforestation in Lishui to create cropland compensating Hangzhou losses
- Ecological degradation concentrated in less developed sending areas
- Spatial decoupling of urban benefits and environmental costs

### Cross-Coupling Interactions
- Intracoupled provincial land transitions are structured by telecoupled Hangzhou Lishui relations
- Cropland balance policy links local urban growth to distant forest loss
- Economic inequalities shape which municipalities bear ecological burdens

### Research Gaps or Limitations
- Uncertainty from differing forest definitions and remote sensing products
- Limited assessment of biodiversity and ecosystem service impacts
- Insufficient analysis of social outcomes for affected rural communities

### Search Keywords
- telecoupling urbanization deforestation Zhejiang Hangzhou Lishui
- Balance of Arable Land System cropland compensation
- forest transition China land use change 2000 2020

### Extraction Confidence
high
