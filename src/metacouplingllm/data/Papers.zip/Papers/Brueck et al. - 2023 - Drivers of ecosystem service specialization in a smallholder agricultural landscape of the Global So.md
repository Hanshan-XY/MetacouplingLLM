Research

# Drivers of ecosystem service specialization in a smallholder agricultural landscape of the Global South: a case study in Ethiopia

Maria Brück 1 , Joern Fischer 1 , Elizabeth A. Law 2 , Jannik Schultner 3 and David J. Abson 1

ABSTRACT. The global shift toward agricultural specialization in the 20th century led to unprecedented ecological and socioeconomic changes, both positive and negative, in rural landscapes. Economic theory describes comparative advantage and market participation as two important drivers of such changes. Landscapes in the Global South are still often characterized by subsistence agriculture and direct dependence on natural ecosystem processes. Agricultural specialization is part of the structural transformation process from subsistence to market-oriented agriculture. However, comparative advantage and market participation as major drivers for agricultural specialization remain understudied. In this paper, we assess the potential drivers of ecosystem service specialization in an Ethiopian smallholder landscape at the kebele level, the smallest administrative unit in Ethiopia. We measured specialization via the concentration of production for a range of locally important provisioning ecosystem services (beef, cattle, coffee, eucalyptus, honey, maize, sorghum, and teff). We measured comparative advantage based on productivity data, and assessed spatial flows of ecosystem services to local, regional, and global markets (i.e., telecoupling). To unpack the relationships between specialization, comparative advantage, and telecoupling, we used hierarchical clustering, principal component analysis, correlation analysis, and linear regression. More telecoupled kebeles (i.e., kebeles that produced more of ecosystem services that flow to broader spatial scales) were more specialized in their ecosystem service production, and the positive relationship between comparative advantage and specialization grew stronger with altitude. Wealthier kebeles and kebeles with higher population density were less specialized. Biophysical drivers, such as altitude and amount of forest cover, influenced the ecosystem services produced and the relationship between comparative advantage and specialization. Policy makers should therefore try to balance potential positive and negative consequences of specialization, and to account for fine-scale social and biophysical drivers underpinning diverse ecosystem service production profiles.

Key Words: agricultural specialization; comparative advantage; ecosystem service flows; Ethiopia; land management; smallholder agriculture; telecoupling

# INTRODUCTION

A key shift in agricultural practices during the 20th century in rural landscapes around the world has been the increase in agricultural specialization, leading to unprecedented changes in the ecological and socioeconomic characteristics of these landscapes (Abson 2019). Although agricultural specialization can increase agricultural yield and food productivity (Tilman 1999, Godfray et al. 2010), specialization also comes with potentially negative consequences, including declines in biodiversity and increased ecological externalities such as water pollution or greenhouse gas emissions (Stoate et al. 2009, Abson 2019). Moreover, agricultural specialization can increase vulnerability to ecological and economic shocks because of decreased multifunctionality and resilience (Foley et al. 2005, Fischer et al. 2017, Abson 2019, Frei et al. 2020), and often leads to landscape simplification, which can negatively impact biodiversity (Abson 2019), or human-nature connectedness and relational values (Riechers et al. 2022). Finally, specialization can also cause social problems, such as rising inequalities and the erosion of values, traditions, and local knowledge (Jiren et al. 2020a, Schultner et al. 2021, Riechers et al. 2022), with the danger of leaving behind groups that are already disadvantaged, for example because of their lack in capital assets or agency (Manlosa et al. 2019a, Schultner et al. 2021, Manlosa 2022).

Economic theory describes comparative advantage and market participation, often also termed “commercialization,” as two important drivers of agricultural specialization (Abson 2019). Comparative advantage is the ability of an economic agent to

carry out a particular economic activity more efficiently (at a lower relative opportunity cost) than another agent (Watson 2017). This provides a strong economic rationale for farmers and governments to favor large-scale, specialized agricultural production of tradable goods for which they have a comparative advantage (Abson 2019). Associated benefits for farmers and societies include higher profits and increased resource efficiency (Matsuyama 1992, Hunt and Morgan 1995). Comparative advantage therefore allows greater production with lower resource use and production costs, potentially freeing resources for other socially useful purposes (Green et al. 2005, Godfray and Garnett 2014). Market access and participation are preconditions for the exploitation of comparative advantages, because the process of specialization depends on global commodity markets for both inputs and outputs. Hence, a lack of transportation infrastructure or other forms of market access can limit or slow the agricultural specialization process (Li et al. 2017, Abson 2019). Moreover, the extent of the market drives specialization, because a larger market allows greater specialization by ensuring adequate demand for specialized products; this idea dates back to Adam Smith (Emran and Shilpi 2012, Li et al. 2017). In addition to comparative advantage and market participation, a range of social and biophysical variables, such as wealth or landscape diversity, might also explain agricultural specialization (Table 1).

Despite its obvious importance, agricultural specialization, and especially its relationship with market participation and comparative advantage, remains poorly understood in

Table 1. Variables used in analysis, including their definition and expected relationship with specialization. Kebele (smallest administrative units in Ethiopia) production data were adjusted for kebele area and scaled by a robust scaler (i.e., the median is subtracted from each datapoint, then divided by the interquartile range). Kebele productivity data were also robust scaled. For additional details see Appendix 1. ES $=$ ecosystem services, LULC $=$ land use land cover.   

<table><tr><td>Variable</td><td>Definition</td><td>Expected relationship with specialization</td></tr><tr><td>Specialization</td><td>Concentration of ES production; 
Simpson&#x27;s index (infinite version) based on kebele production data (area adjusted, robust scaled)</td><td>-</td></tr><tr><td>Telecoupling</td><td>Degree of market connection to broader spatial scales in terms of ES production; 
Telecoupling score for each ES (average number of beans weighted by degree of telecoupling of each spatial scale) multiplied by total annual ES production for each ES, summed across ES</td><td>POSITIVE: Markets ensure adequate demand for large-scale production and access to necessary inputs (Li et al. 2017, Abson 2019). Studies in Ethiopia have shown that an increase in walking distance from markets or roads increases the likelihood and extent of crop diversification (Mussema et al. 2015, Dessie et al. 2019).</td></tr><tr><td>Comparative advantage</td><td>Concentration of ES productivity; Simpson&#x27;s index (infinite version) based on kebele productivity data (robust scaled)</td><td>POSITIVE: Farmers and societies obtain benefits from specializing in goods for which they have a comparative advantage and trading them, such as higher profits and increased efficiency (Abson 2019).</td></tr><tr><td>Biophysical variables</td><td></td><td></td></tr><tr><td>Mean altitude</td><td>Calculated from a digital elevation model with 30m resolution</td><td>UNCLEAR: Coffee grows naturally in the region at altitudes between 1500 and 2100 m (Dorrestein et al. 2017, Duguma et al. 2022) and forest cover decreases with altitude (one reason is forest clearing in altitude ranges that are unsuitable for coffee; Hylander et al. 2013). Yet ultimate influence unclear: Lower forest cover and the absence of coffee might mean that kebeles at higher altitudes show more specialization because they cannot produce any coffee. On the other hand, kebeles in coffee growing altitudes might specialize in coffee production.</td></tr><tr><td>Forest cover</td><td>Forest area divided by total kebele area (in ha)</td><td>UNCLEAR: See mean altitude.</td></tr><tr><td>Landscape diversity</td><td>Simpson&#x27;s diversity index based on absolute area (in ha) of 12 LULC classes</td><td>UNCLEAR: The relationship between ES multifunctionality and land use diversity is complex, and depends on the location, choice of indicator, and scale of analysis (Stürk and Verburg 2017).</td></tr><tr><td>Remoteness</td><td>Sum of distance from the nearest town and distance from the nearest road (both robust scaled)</td><td>NEGATIVE: With greater distance from markets, farmers need to rely on a diverse set of ecosystem services for subsistence, because they cannot trade outputs or inputs in markets (Mussema et al. 2015, Dessie et al. 2019).</td></tr><tr><td>Social variables</td><td></td><td></td></tr><tr><td>Share of women in the population</td><td>Number of women divided by total population</td><td>UNCLEAR: Women are more risk averse and tend to promote a more diversified and food secure approach to ecosystem service production (Assefa et al. 2022, Sekyi et al. 2023). On the other hand, it has been shown that male-headed households tend to increase farm diversification because they have better access to required resources (Asante et al. 2018, Dessie et al. 2019, Manlosa et al. 2019c).</td></tr><tr><td>Population density</td><td>Total population divided by total kebele area</td><td>UNCLEAR: The higher population density, the smaller farm sizes (Josephson et al. 2014). Some studies have shown that in Ethiopia larger farm size is associated with higher diversification (Mussema et al. 2015, Kidane and Zegeye 2018, Mekuria and Mekonnen 2018, Dessie et al. 2019), whereas a recent global meta-analysis found that smaller farms have higher crop diversity (Ricciardi et al. 2021).</td></tr><tr><td>Wealth</td><td>Number of tin roofs divided by total number of households</td><td>UNCLEAR: Farmers who hold more (durable) assets are more likely to specialize (Li et al. 2017, Sekyi et al. 2023). Studies in Ethiopia found however that livestock ownership, which is a significant capital asset in Ethiopia (Manlosa et al. 2019b), is positively associated with diversification (Kidane and Zegeye 2018, Mekuria and Mekonnen 2018).</td></tr></table>

smallholder agricultural landscapes of the Global South (Li et al. 2017, Sekyi et al. 2023). These landscapes are often characterized by subsistence agriculture and direct dependence on local ecological resources, such as fuelwood or crops for personal consumption (Tallis et al. 2008, Egoh et al. 2012). Agricultural specialization is part of the structural transformation process from subsistence to market-oriented agriculture (Emran and Shilpi 2012, Li et al. 2017). In this context, pursuing a comparative advantage approach seeks to optimize profits via efficient resource allocation, but it does not necessarily address issues related to risk and diversification in agroecological systems. For example, some studies have investigated the consequences of

agricultural specialization, or of its opposite, diversification, suggesting that crop diversification is positively associated with higher household income (Pellegrini and Tasciotti 2014, Bellon et al. 2020), higher food security (e.g. in terms of higher selfconsumption of food crops) and dietary diversity (Pellegrini and Tasciotti 2014, Waha et al. 2018, Manlosa et al. 2019a, Bellon et al. 2020), and lower risk of poverty (Michler and Josephson 2017).

Others have explored drivers of specialization or diversification in countries of the Global South in relation to household, farm, or regional characteristics, such as gender of household head, farm size, or distance to markets (Li et al. 2017, Asante et al. 2018,

Mekuria and Mekonnen 2018, Dessie et al. 2019). Only a few studies have explicitly analyzed the relationship between specialization, market participation and comparative advantage. Most studies that analyzed the relationship between crop or croplivestock specialization and market participation found a positive relationship between them (Mussema et al. 2015, Li et al. 2017, Dessie et al. 2019, Sekyi et al. 2023). In contrast, some found a negative relationship (Mekuria and Mekonnen 2018, Rampersad 2021), or a U-shaped relationship (Emran and Shilpi 2012). Studies that focused on comparative advantage or productivity found a positive relationship between crop specialization and productivity (Kurosaki 2003, Kidane and Zegeye 2018, Sekyi et al. 2023). Most of the studies focused on the household or farm level and on crops or livestock, but Emran and Shilpi (2012) analyzed specialization at the village level, and Torres et al. (2018) considered a range of different ecosystem services, including some from agroforestry systems and coffee.

In this paper, we analyze potential drivers of agricultural specialization in a smallholder landscape in southwestern Ethiopia, with a particular focus on market participation and comparative advantage. In the study area, livelihood strategies have traditionally been diversified and subsistence-oriented (Manlosa et al. 2019a). Specialization and market integration are, however, strongly encouraged by the government, and many stakeholders, such as farmers and representatives of governmental, non-governmental, and civil society organizations, expect or even favor such developments (Federal Democratic Republic of Ethiopia, National Planning Commission 2016, Jiren et al. 2020a, 2020b). Over the past decades, production has already begun to shift from subsistence to marketed crops, and access to cash crops with indirect benefits (e.g., economic returns from trade) increased (Schultner et al. 2021). In this way, the economy in the landscape and the local farmers’ livelihoods are increasingly shaped by the flow of global commodities such as coffee (Petit 2007).

We frame our analysis of potential drivers of agricultural specialization in terms of the ecosystem services concept and focus on provisioning ecosystem services. These are defined as the products obtained from ecosystems, including, for example, food, fuel, and water (Millennium Ecosystem Assessment 2005). We use the ecosystem services concept here to highlight that instead of merely being agricultural products, the “ecosystem services” in our case study fulfill multiple roles, such as providing cultural meaning and determining other non-provisioning services. Kebeles, the smallest administrative units in Ethiopia, in our study area differ in their social and biophysical characteristics as well as in the ecosystem services they produce (Dorresteijn et al. 2017, Duguma et al. 2022), and local people’s livelihoods strongly depend on ecosystem services (Dorresteijn et al. 2017, Manlosa et al. 2019a). From previous research, we know that a number of provisioning services, such as maize and coffee, are important to local people (Dorresteijn et al. 2017, Manlosa et al. 2019a, Shumi et al. 2019). Because trade-offs often occur between provisioning services and regulating or cultural services (Raudsepp-Hearne et al. 2010, Martín-López et al. 2012), provisioning services are likely to determine (via trade-offs or synergies) other ecosystem services that are generated in the landscape, as well as socioeconomic and equity outcomes (Brück et al. 2022). For example, increasing commercialization of provisioning ecosystem services in the

landscape will change land use patterns overall, which could cause deforestation and thus the loss of regulating and cultural services for the landscape as a whole (Kassa et al. 2017, Schultner et al. 2021). Moreover, benefits and values associated with provisioning services are likely to change if production becomes more specialized and market-oriented, that is, changing from direct use toward exchange values, with important implications for livelihoods and well-being (Daw et al. 2011, Brück et al. 2022). Whereas increased economic capacity may enable some households to purchase goods and make livelihood investments, lack of economic capital may prevent other households to make initial investments for participation in market-oriented cropping (Schultner et al. 2021).

The degree of market participation of farmers has been defined as the degree of production for markets as opposed to production for subsistence (Emran and Shilpi 2012, Li et al. 2017). To define and describe the degree of market participation, we use the concept of telecoupling, which describes “both socioeconomic and environmental interactions among coupled human and natural systems over distances” (Liu et al. 2013), and has been broadly implemented by researchers from diverse disciplines (Hull and Liu 2018, Kapsar et al. 2019). In the context of ecosystem services, the telecoupling concept has for example been used to analyze water governance (Liu et al. 2016), spatial subsidies of migratory species (López-Hoffman et al. 2017), or power asymmetries and social relations related to ecosystem services (Martín-López et al. 2019). Based on the telecoupling concept, Schröter et al. (2018) and Koellner et al. (2019) provided guidance on how to analyze interregional ecosystem services flows, leading us to focus here on the “biophysical flows of traded goods” (Schröter et al. 2018).

The overarching goal of this paper is to explore potential drivers of ecosystem service specialization in an Ethiopian smallholder landscape, including telecoupling, comparative advantage, and other potentially important social and biophysical factors. This paper addresses two key gaps in the literature, we (1) focus our analysis on telecoupling and comparative advantage in relation to specialization, which are theoretically important drivers for specialization during the process of agricultural structural change, but have not received much attention in case studies of the Global South, and (2) choose the kebele level as unit of analysis instead of the household level.

Analyzing the relationships between specialization, telecoupling, and comparative advantage provides a better understanding of a key, but context-specific driver of land use change, which is in turn a major driver of biodiversity loss and multiple social and economic outcomes (for example, the access to, and distribution of, key ecosystem services). Focusing on the municipal or kebele level, rather than individual households’ responses to telecoupling and comparative advantage, provides important insights at the landscape level, and thereby can help inform policy interventions to mitigate against land use homogenization and the associated risks of ecological and market shocks (Abson and Termansen 2011, Abson et al. 2013). We analyze ecosystem services that are relevant in the landscape, rather than only focusing on crops and/ or livestock production (beef and cattle as well as maize, sorghum, and teff, but also coffee, eucalyptus, and honey). We draw on two strands of literature where we see the possibility for mutual

learning, one that is centered around notions such as “agricultural diversification/specialization,” “market participation,” and “commercialization” (Emran and Shilpi 2012, Li et al. 2017, Kidane and Zegeye 2018), and the other around “ecosystem service multifunctionality” and “telecoupling” (Hölting et al. 2019, Frei et al. 2020, Llopis et al. 2020).

To achieve our goal, we (1) define indices to quantify specialization, telecoupling, and comparative advantage in each kebele, (2) examine correlations between specialization, telecoupling, and comparative advantage across all kebeles in the study area, (3) analyze how these relationships differ between kebeles in three farming type clusters, and (4) build a regression model to statistically test the role of telecoupling and comparative advantage, and other social and biophysical variables, as possible drivers of specialization. With this paper we thereby makes the following contributions: we operationalize the telecoupling concept in an ecosystem services context by measuring ecosystem service flows to spatial scales from the household to the global level in a data-scarce environment; in a case study region in Ethiopia, we empirically assess potential drivers of agricultural specialization, based on ecosystem service production and flow data; and we produce results that may help policy makers better understand possible future landscape change and therefore make more informed decisions about ecosystem service management. In this way, we contribute to a broader understanding of how telecoupling and comparative advantage may act as drivers of specialization during the process of agricultural structural change in the Global South.

# METHODS

# Study area

The study area consisted of three woredas (districts), in Jimma Zone, Oromia Region, Ethiopia, namely Gera, Gumay, and Setema woreda (Fig. 1). The landscape is a recognized biodiversity hotspot (Mittermeier et al. 2011) and characterized by a mosaic of farmland and moist evergreen Afromontane forest (Hylander et al. 2013). Smallholders are mainly involved in subsistence farming, which provides diverse ecosystem service benefits to the local community (Shumi et al. 2019, Schultner et al. 2021), but also ecosystem services of global importance, such as carbon storage (De Beenhouwer et al. 2016). Kebeles in the study area measure on average $3 0 ~ \mathrm { k m } ^ { 2 }$ and have an average population of approximately 4000 inhabitants.

# Data collection and validation

We collected and analyzed data for 61 rural kebeles with multifunctional land uses in our study area. Seventeen kebeles in our study area were excluded from analysis because they were dominated by forests or large towns (see Appendix 1 for details). Important ecosystem services in the landscape include those stemming from the use of woody plants, inter alia eucalyptus (Eucalyptus spp.) and honey (Shumi et al. 2019); coffee (Coffea arabica) as one of the main cash crops; and maize (Zea mays), sorghum (Sorghum bicolor), and teff (Eragrostis tef) as key food crops (Manlosa et al. 2019a). Households usually own a small number of livestock, and the most valuable of these are cattle, which are used as draft animals and also considered a valuable capital asset (Manlosa et al. 2019b). We distinguished between

cattle used for general purposes versus cattle used specifically for beef fattening (i.e., for meat production). We thus collected data for the following eight ecosystem services: eucalyptus, honey, coffee, maize, sorghum, teff, cattle, and beef.

In October and November 2020, we conducted interviews on ecosystem service production and flows with experts in woreda offices in Gera, Gumay, and Setema. Experts were chosen based on their respective expertise. For example, experts working at the Bureau of Agriculture were asked about cereal crop production and flows. For ecosystem service production, we collected mainly official data from the experts for all ecosystem services, and where unavailable relied on experts’ estimates (for details see Appendix 1). For each kebele, we collected total annual production (cattle/ beef: number owned, coffee/honey/maize/sorghum/teff: ton, eucalyptus: $\mathbf { m } ^ { 3 }$ ) and area dedicated to the production (in ha; honey: number of producers) for each ecosystem service. Missing values for some kebeles for beef, coffee, eucalyptus, and sorghum production and area were imputed based on the data from other kebeles (for details see Appendix 1). The collected data were crosschecked for plausibility and consistency with remote sensing data, secondary productivity data, and data from previous research (for details see Appendix 1).

Official data on ecosystem service flows, that is, information on how much of a given ecosystem service stays within households or flows to broader geographical scales, was difficult to obtain, especially at relatively fine scales like the household and kebele level. For this reason, we used a “coffee bean exercise” to elicit this knowledge (for details see Appendix 1). For this, experts were asked to allocate 20 coffee beans (representing a household’s yearly yield of the ecosystem service) to different spatial scales, in order to spatially disaggregate proportionate flows for each ecosystem service studied (Fig. 2). We defined five spatial scales based on local understandings of the supply chain: household, local market (kebele), district market (woreda), central market (regional/national), and global market. We collected this information for all ecosystem services for a selection of 12 kebeles representing social-ecological gradients in the study area. Kebeles in our study area were clustered into four social-ecological groups, based on a range of ecological and social variables. We then chose a sub-set of kebeles, three from each of the four social-ecological kebele groups.

# Definition of variables

All data analysis was conducted using R version 4.1.2 (R Core Team 2021; main R packages used are indicated in the text, information on additional packages can be found in Appendix 1). We adjusted ecosystem service production data by kebele area to account for kebele size differences, and applied a robust scaler (a scaling method that is relatively insensitive to outliers, where the median is subtracted from each datapoint, then divided by the interquartile range) to facilitate direct comparison among diverse ecosystem services. For each ecosystem service, we divided total annual production by the area dedicated to the production (in ha; honey: number of producers) to obtain ecosystem service productivity. Kebele productivity data were then also robust scaled. Our analysis included three main variables (specialization, telecoupling, comparative advantage; Fig. 3) plus a range of social and biophysical variables that we expected might explain

![](images/dac945f5053e557bad4f9a3e3a7562f3672d7adf1e64fe29b511ebf7f0b04486.jpg)  
Fig. 1. Map of (A) the location of the study area in Jimma Zone, Oromia, Ethiopia; and (B) a detailed view of the three woredas, including kebeles (smallest administrative units in Ethiopia) boundaries and altitude (from ASTER digital elevation model with $3 0 \mathrm { m }$ resolution, obtained from https://asterweb.jpl.nasa.gov/gdem.asp; NASA/METI/AIST/Japan Spacesystems and U.S./Japan ASTER Science Team 2009, Duguma et al. 2022).

![](images/2b9536fb3b09f92f565e7a08ec4a76238d8d4cb1df3dca155255a2cc748bde19.jpg)

![](images/2c29e914b6928dda7ecd2eaab3c23041897208b71faf9536fdfa08433c5bbfb8.jpg)  
Fig. 2. Coffee bean exercise to elicit ecosystem service flow data. Experts allocated 20 coffee beans (representing a household’s yearly yield of the ecosystem service) to five spatial scales: household, local market (kebele), district market (woreda), central market (regional/national), global market. Each row represents a different kebele within the woreda (district).   
specialization (Table 1). Other variables may also play a role in driving specialization, such as farmers’ agency or cultural norms. However, such variables are difficult to measure, and their examination would require more extensive research.

In our definition, a kebele was more specialized if its ecosystem service production was more concentrated and less evenly distributed across services. That is, a kebele that produced a lot of some ecosystem services and only comparatively little of other ecosystem services had a higher specialization score than a kebele that produced the same amount of all ecosystem services. We measured the degree of specialization for each kebele through Simpson’s index (for infinite samples) based on ecosystem service production data for each kebele (gini.simpson.C in R package diverse, v0.1.5, Guevara et al. 2016). We chose this index, which takes into account both richness and evenness, instead of other diversity indices, because it is a very meaningful and robust diversity measure and provides good estimates at relatively small sample sizes (Magurran 2011), it reflects best the nature of our data, and it has been widely used in the literature on ecosystem service multifunctionality (Raudsepp-Hearne et al. 2010, Brandt et al. 2014, Stürck and Verburg 2017, Hölting et al. 2019, 2020).

Similarly, we defined that a kebele was more telecoupled if it produced more of relatively highly telecoupled ecosystem services than other kebeles. Our telecoupling score thus indicated how connected a kebele was to broader spatial scales in terms of its ecosystem service production. We measured the degree of telecoupling for each kebele by a combination of data on average ecosystem service flows to different spatial scales, and ecosystem service production data for each kebele. Based on the “coffee bean exercise,” we calculated the average number of coffee beans attributed to each spatial scale for each ecosystem service (across the 12 kebeles), and weighted the different spatial scales by their degree of telecoupling (household scale $= 0$ , local $= 1$ , district $=$ 2, central $= 3$ , global $= 4$ ; see Fig. 2) to obtain a telecoupling score

Fig. 3. Definition and calculation of the three main variables: specialization, telecoupling, and comparative advantage. Kebele (smallest administrative units in Ethiopia) production data were adjusted for kebele area and scaled by a robust scaler, i.e., the median is subtracted from each datapoint, then divided by the interquartile range (IQR). Kebele productivity data were also robust scaled. ES = ecosystem services; Dss $=$ Simpson’s index based on ES production, measures specialization; $\mathbf { N } =$ total number of ecosystem services considered; $\mathrm { \ p i = }$ share of total annual production of ES i in the total annual production of all ES in the kebele; Dscp $=$ Simpson’s index based on ES productivity, measures comparative advantage; qi = share of productivity of ES i in the sum of productivities of all ES in the kebele. For example, the value for kebele Bore Dedo for cattle was 13,680, which was then divided by the total kebele area (2688.1318 ha), which gives 5.09 cattle/ha. The median of all kebeles for the kebele area adjusted cattle was 4.17, and the IQR was 4.81. The resulting value (adjusted for kebele area, robust scaled) for Bore Dedo for cattle was thus $( 5 . 0 9 { - } 4 . 1 7 ) / 4 . 8 1 = 0 . 1 9$ .

# Degree of specialization:

Howconcentrated is ES production in a kebele?

Simpson's index (infinite version) based on kebele production data (area adjusted,robust scaled)

$$
D _ {s s} = \sum_ {i = 1} ^ {N} p _ {i} ^ {2}
$$

# Degree of comparative advantage:

Howconcentrated is ESproductivity_ina kebele?

Simpson's index (infinite version) based on kebele productivity data (robust scaled)

$$
D _ {s c p} = \sum_ {i = 1} ^ {N} q _ {i} ^ {2}
$$

![](images/a7f509ddacc0cc199d8cd6e860abddf6ef4307b46ad10fb63a94d6d557cd8dda.jpg)  
Degree of telecoupling: How telecoupled isa kebele in terms of ES flows?   
Ecosystem service

![](images/0edc139660513a94d857acf079d6a89d4024732eec88d8f0058bf6b3304ed453.jpg)  
Scale

![](images/6f64ad70d3e88ff817898f356c1a7502a708548dfd60e9c1ac846b7ac7094205.jpg)  
Household = 0   
Local $= 1$   
Central = 3   
Global= 4

Telecoupling score for each ES

Kebele ES production (areaadjusted,robust scaled)

![](images/05303848524a6e26ffeb961fe618ab5ac59284e4ba07a3c63b4af1a837f79f1d.jpg)

Telecoupling score for each ES

![](images/b4ff0cb50a0407dcf4e5ee2b36e3ea83c1486dd6c45ab581afbe4ca4158d002e.jpg)  
Summed   
across ES   
Telecoupling score for   
each kebele

for each ecosystem service. We then multiplied this score by total annual production for each ecosystem service and summed across ecosystem services to obtain a telecoupling score for each kebele.

A kebele had a higher comparative advantage if its ecosystem service productivities were more concentrated and less evenly distributed. That is, a kebele that was very productive in producing one or more particular ecosystem service(s) and less productive in producing others had a higher comparative advantage score than a kebele that produced all ecosystem services with similar (high or low) efficiency. A higher score thus meant a local comparative advantage for one (or few) ecosystem services within the kebele compared to the other ecosystem services, and hence theoretically more incentive for farmers to specialize. We

measured the degree of comparative advantage for each kebele through Simpson’s index based on ecosystem service productivity data.

# Data analysis

To assess associations between specialization, telecoupling, and comparative advantage, we performed a correlation analysis. Because the variables were not normally distributed (Shapiro-Wilk test: $\mathsf { p } < 0 . 0 0 1$ for all three variables), we chose to analyze correlation by the Kendall rank correlation coefficient τ (Kendall 1938, 1949, Kruskal 1958, Newson 2002).

To understand how the relationships between our main variables differed between kebeles, we explored if kebeles could be meaningfully grouped based on their ecosystem service

production. We performed a hierarchical clustering analysis based on (robust scaled) production data for all eight ecosystem services (Euclidean dissimilarity matrix, Ward‘s clustering method). The resulting dendrogram was then classified into clusters (representing farming types) based on visual inspection, considering group interpretability (for dendrogram see Fig. A1.1).

To assess if telecoupling and comparative advantage were significant predictors of specialization, and to explore the role of other potential social and biophysical drivers for specialization, we built a linear regression model with specialization as the dependent variable (for details see Appendix 1). As explanatory variables, we included telecoupling and comparative advantage, additional biophysical and social explanatory variables, as well as two-way interactions between comparative advantage, landscape diversity, and mean altitude, based on the results of the kebele clustering as well as prior knowledge on the study area (see Equation 1, Table 1, and for further details on the two-way interactions, Appendix 1). We first conducted thorough data exploration (following the protocol by Zuur et al. 2010), and centered and scaled all independent variables. We applied a Box-Cox transformation to the dependent variable, and Yeo-Johnson transformations to telecoupling, comparative advantage, female population, landscape diversity, and remoteness to account for non-linearity, non-normality, and heterogeneity in the data, using the bestNormalize package (v1.8.2, Peterson 2021). We then fit a “full” model, defined as:

Specialization ${ \bf \beta } _ { \mathrm { i } } = \beta _ { 0 } + \beta _ { 1 }$ Telecouplingi $+ \beta _ { 2 } \ell$ Comparative advantagei + β3Mean altitudei + (1) β Forest cover $+ \beta _ { 5 } |$ Landscape diversity + β Remoteness + β Share of female population + β8Population densityi + β9Wealthi + β10Comparative advantagei ∗ Mean Altitudei $^ +$ β11Comparative advantagei ∗ Landscape diversity $+ \beta _ { 1 2 } \mathrm { M e a n }$ altitudei ∗ Landscape diversityi $+ \varepsilon _ { \mathrm { i } }$

For kebele i, where $\beta _ { 0 }$ is the intercept, $\beta _ { 1 }$ to $\beta _ { 1 2 }$ are the parameters to be estimated, and $\varepsilon _ { \mathrm { i } }$ is the error term with $\varepsilon \sim \Nu ( 0 , \sigma ^ { 2 } )$ . To find the most parsimonious explanatory model, we then applied stepwise backward model selection based on the Akaike information criterion (AIC) and validated the final model (checking for linearity, normality of residuals, homogeneity of variance, outliers and leverage points, autocorrelation, and multicollinearity), using ggfortify (v0.4.13, Tang et al. 2016) and gvlma packages (v1.0.0.3, Pena and Slate 2021). To check if our main variables of interest, telecoupling, and comparative advantage were significant predictors to the model, we compared models with and without these variables using ANOVA at a significance level of $\alpha = 0 . 0 5$ .

To check the robustness of our correlation analyses and the linear model to alternative definitions of our focal indices, we computed different versions of our main variables (for details see Appendix 1). For telecoupling, we varied the weights applied to the spatial scales. For specialization and comparative advantage, we calculated a range of alternative diversity indices. We checked if imputed data had a significant influence in the linear model, by checking if dummy variables for imputed value had a significant influence on the model results.

Our study has some limitations. First, data were partly based on experts’ best estimates and thus may be biased. To minimize the risk of bias, we cross-checked ecosystem service production data against remote sensing, secondary, and household-based data of previous project research, and averaged ecosystem service flow data across 12 kebeles. Second, we only focused on provisioning

services here, because they are of key importance to local people; future studies should examine if and how our findings translate to other types of ecosystem services. Last, other studies have shown a two-way causality between specialization and market participation, which we refer to as telecoupling in this paper (Emran and Shilpi 2012, Li et al. 2017, Sekyi et al. 2023). However, we chose specialization as our main and dependent variable of interest because of its important implications for the livelihoods of smallholder farmers.

# RESULTS

# The spatial distribution of flows differs between ecosystem services

Based on experts’ assessments, on average, more than half of a household’s yearly yield of almost all ecosystem services (except beef) stayed in the household or at the kebele level (Fig. 4). Beef was the ecosystem service with the highest telecoupling score, followed by coffee and honey.

# Ecosystem service specialization is positively correlated with both telecoupling and comparative advantage, but kebele farming types influence these relationships

Hierarchal clustering of ecosystem service production data resulted in three clusters of kebeles, denoting three different farming types (Fig. 5). Kebeles in the first cluster (“beef ”) produced significantly more beef, and kebeles in the second cluster (“coffee/honey”) significantly more coffee and honey than kebeles in the other clusters (Fig. A2.2). Kebeles in the third cluster (“mixed”) produced significantly more cattle, eucalyptus, maize, sorghum, and teff than kebeles in the other clusters. Beef cluster kebeles had significantly higher altitudes and lower forest cover than the other two clusters (Fig. A2.3).

We found a strong positive and significant correlation between telecoupling and ecosystem service specialization across kebeles $( \tau = 0 . 3 3 , p < 0 . 0 0 1$ ; Fig. 6), and a positive significant relationship between comparative advantage and ecosystem service specialization across kebeles $( \tau \ = \ 0 . 1 9$ , $p ~ = ~ 0 . 0 3 )$ . These correlations were robust to outliers and different versions of our variables (Fig. A2.1, A2.4, A2.5).

Robust to different versions of our variables (Fig. A2.4), the beef and the mixed cluster both showed positive significant relationships between telecoupling and ecosystem service specialization (beef: $\tau = 0 . 2 8 , p = 0 . 0 1 6$ ; mixed: $\tau = 0 . 3 5 , p = 0 . 0 5 2$ ; Fig. 6), though the relationship was not significant in the coffee/ honey cluster. In contrast to the significantly positive general correlation between comparative advantage and ecosystem service specialization, none of the individual clusters showed a significant correlation between these variables (Fig. A2.5).

# Telecoupling, comparative advantage and altitude significantly contribute to predictions of specialization

Robust to different versions of our variables (Table A2.1, A2.2, A2.3, A2.4), the final model with specialization as the dependent variable (Table 2; adjusted $R ^ { 2 } = 0 . 3 3 1$ , $F ( 6 , 5 4 ) = 5 . 9 4 5 )$ showed positive significant relationships for telecoupling $( \beta = 0 . 6 6 ; p <$ 0.001), and the interaction between altitude and comparative advantage $( \beta = 0 . 3 3 ; p = 0 . 0 6 5$ ; Fig. 7). The mean main effect of altitude was positively significant $( \beta = 0 . 2 1 ; p = 0 . 0 8 3 )$ , whereas comparative advantage on its own was not significant, but had a

![](images/4bd961f9cb514ed98c7709deb59eea4169aacc4e185fbca0aef5a5565f613059.jpg)  
Fig. 4. Bar chart indicating average number of coffee beans (across 12 kebeles, smallest administrative units in Ethiopia) attributed by experts to each spatial scale for each ecosystem service. Twenty coffee beans represented a household’s yearly yield of the ecosystem service. Telecoupling score for each ecosystem service in brackets (average number of coffee beans weighted by degree of telecoupling of each spatial scale, and summed across spatial scales). $\mathrm { H H } =$ household.

positive coefficient. Population density and wealth showed negative significant relationships (β = -0.35, $p = 0 . 0 1 8$ ; $\beta = - 0 . 2 5$ , $p = 0 . 0 2 6 )$ . Telecoupling and comparative advantage, our main variables of interest, significantly contributed to predictions of specialization (ANOVA; $\operatorname { F } ( 3 , 4 9 ) = 7 . 1 2 5 7 , p < 0 . 0 0 1$ $p < 0 . 0 0 1$ ; for details and additional checks showing that they were significant predictors see Appendix 2).

# DISCUSSION

# Methodological contribution

In a data-scarce environment, we operationalized the telecoupling concept in the context of ecosystem services through spatial disaggregation of ecosystem service flows (see Liu et al. 2016, López-Hoffman et al. 2017, Boillat et al. 2018 for other examples). Because ecosystem services are often appropriated at different places and by different people than where they are generated, it is crucial to consider spatial scales when analyzing ecosystem services (Hein et al. 2006). Spatial disaggregation of ecosystem service flows helps to understand where ecosystem services are generated versus where they are appropriated, and can hence serve as a proxy for understanding who benefits from the ecosystem services generated in a given landscape (Brück et al. 2022). We used a “coffee bean exercise” as an alternative data collection method, in order to assess ecosystem service flows in a data-scarce environment, and measured the degree of telecoupling for each kebele by a combination of data on average ecosystem service flows to different spatial scales, and ecosystem service production data. Using coffee beans or other types of tokens is an established data collection method, for example for the assessment of ecosystem service importance (Hicks et al. 2015, Lau et al. 2018),

or as a triangulation method for measurements of sensitive, socially undesirable behavior (Lau et al. 2011, Jones et al. 2021). Our results concerning the degree of telecoupling of kebeles were only made possible through this participatory data collection method, because official data on ecosystem service flows at fine spatial scales were not available.

# Telecoupling is a positive significant predictor of ecosystem service specialization

Telecoupling was correlated with specialization across all kebeles, and in two of three kebele farming type clusters (Fig. 6), we found a significant positive relationship for telecoupling in our linear model (Table 2), and showed that a model with telecoupling and comparative advantage as explanatory variables was significantly better than a model without them: hence, more telecoupled kebeles were more specialized in their ecosystem service production. The exception in the coffee/honey cluster (no significant correlation) can either be attributed to the fact that this cluster contained only few datapoints, or to social and cultural factors connected to coffee production. Our study thus confirmed a pattern that has already been observed in agricultural landscapes of the Global North and in some studies for the Global South: agricultural specialization and market participation are closely related (Emran and Shilpi 2012, Li et al. 2017, Abson 2019). Some Ethiopia-specific studies are in line with our findings, showing that crop diversity at the household level increased with distance to markets or roads (Mussema et al. 2015, Dessie et al. 2019). In contrast, other studies in Ethiopia found that crop-livestock or crop diversity at the household level increased with market access (Mekuria and Mekonnen 2018, Rampersad 2021). These results show that the effects of more telecoupling (higher market

![](images/1923acaedec4e179ef47ee57148ef26243cdd7196fad4a2d431d850255631d73.jpg)  
Fig. 5. Ordination plot of kebele (smallest administrative units in Ethiopia) farming types. Clusters based on hierarchical clustering analysis of ecosystem service production data of eight ecosystem services for 61 kebeles, and visualized by principal component analysis (PCA). Each datapoint represents one kebele. The x-axis represents the first principal component (explains $3 3 \%$ of the variation). The y-axis represents the second principal component (explains $24 \%$ of the variation). Arrows show ecosystem service production. Longer arrows mean stronger correlation with PCA axes. Clusters were determined from visual inspection of dendrogram after hierarchical clustering of ecosystem service production data and named according to the ecosystem services they are mainly defined by.

participation or access) very much depend on the case study specific context, for example, with regard to the types of crops or livestock investigated, the definition of market participation, or the stage of specialization. Emran and Shilpi (2012) found, for example, a U-shaped causal relationship between the extent of the market and the pattern of crop specialization, suggesting that the portfolio of crops in a village economy becomes more diversified initially, however, after the market size reaches a threshold, the production structure becomes more specialized.

The agricultural landscape in our study area might thus be on a trajectory to face similar opportunities and challenges of increased specialization and market integration as other highly specialized landscapes, such as rising incomes but also increased vulnerability to ecological and economic shocks through loss of redundancy, adaptive capacity, and response diversity (Abson 2019, Walker et al. 2023). However, despite marked differences in specialization between kebeles, we should also note that the overall degree of specialization in the study area is (until now) relatively low.

# Comparative advantage, altitude, and their interaction influence ecosystem service specialization

Comparative advantage was positively correlated with specialization across all kebeles (but not within specific farming types; Fig. A2.1); it was a significant positive predictor for specialization in its interaction with altitude (but not on its own; Table 2), and a model with telecoupling and comparative

advantage as explanatory variables was significantly better than a model without them; hence, there was a relationship between comparative advantage and specialization, but it was weaker than for telecoupling. Only a few studies examined the relationship between specialization and comparative advantage or productivity in the Global South. Among these, Sekyi et al. (2023) found that crop specialization positively related to agricultural productivity (measured in crop produced per hectare) in a case study in Ghana, whereas Kidane and Zegeye (2018) found that crop diversification had a negative but non-significant influence on productivity in Ethiopia. In our analysis, kebeles in higher altitudes were typically more specialized, on average, but this positive relationship was most pronounced in kebeles with high comparative advantage, and relatively minor in kebeles with low comparative advantage (Table 2, Fig. 7).

From our cluster analysis and the linear model, we observed an interplay of altitude with forest cover and ecosystem service production in the kebeles of our study area (Fig. 5, A2.2, A2.3). Kebeles at higher altitudes had lower forest cover and produced more beef, and tended to specialize more (mostly in beef production). Kebeles of lower altitudes, in contrast, had higher forest cover and produced either forest ecosystem services or a mixture. Although lower altitudes are suitable for coffee, which is a global commodity of considerable value, it was interesting that these kebeles did not specialize in coffee production, but rather included coffee in a diverse portfolio of ecosystem services production. Other studies in our study area have already

![](images/496b29ee5ece2c12b61536fb2a5d6fe8b1a6aa0cb1a2f5eece5aa329f3237da3.jpg)  
Fig. 6. Scatterplot for 61 kebeles (smallest administrative units in Ethiopia) of the relationship between telecoupling and ecosystem service specialization, with density plots by clusters “beef,” “coffee/honey,” and “mixed.” The density plots (around the edges of the plot) represent the distribution of specialization and telecoupling, and help to visualize the distribution of the two variables for each cluster. Specialization was measured by Simpson’s index based on ecosystem service production data, and telecoupling by a combination of ecosystem service production data and weighted average ecosystem service flow data.

Table 2. Results of the linear model testing the influence of social and biophysical kebele (smallest administrative units in Ethiopia) characteristics on ecosystem service specialization. All predictor terms were continuous. Specialization was measured by Simpson’s index based on ecosystem service production data, telecoupling by a combination of ecosystem service production data and weighted average ecosystem service flow data, and comparative advantage by Simpson’s index based on ecosystem service productivity data.   

<table><tr><td rowspan="2">Term</td><td colspan="3">Specialization</td></tr><tr><td>Coefficient</td><td>Standard error</td><td>P-value</td></tr><tr><td>Intercept</td><td>-0.01</td><td>0.10</td><td>0.931</td></tr><tr><td>Comparative advantage</td><td>0.19</td><td>0.13</td><td>0.159</td></tr><tr><td>Telecoupling</td><td>0.66 ***</td><td>0.15</td><td>&lt;0.001</td></tr><tr><td>Mean altitude</td><td>0.21 *</td><td>0.12</td><td>0.083</td></tr><tr><td>Population density</td><td>-0.35 **</td><td>0.14</td><td>0.018</td></tr><tr><td>Wealth</td><td>-0.25 **</td><td>0.11</td><td>0.026</td></tr><tr><td>Comparative advantage*Mean altitude</td><td>0.33 *</td><td>0.18</td><td>0.065</td></tr><tr><td>Observations</td><td>61</td><td></td><td></td></tr><tr><td>R2/R2adjusted</td><td>0.398 / 0.331</td><td></td><td></td></tr></table>

$^ { * } p < 0 . 1 , ^ { * * } p < 0 . 0 5 , ^ { * * * } p < 0 . 0 1 .$

demonstrated that location (altitude and proximity to forest) is an important driver of ecosystem services distribution (Dorresteijn et al. 2017), and that people depend on forest ecosystem services, but that access to them is decreasing (Shumi et al. 2019, Schultner et al. 2021).

Biophysical conditions (such as altitude and forest cover) and limited tenure security and use rights in the study area may restrict smallholders’ agency to change their ecosystem service production, especially if they belong to poor or already vulnerable groups (Shumi et al. 2019, Manlosa 2022). Kebeles at lower, coffee-suitable altitudes did not exploit comparative advantages as much as kebeles at higher altitudes. Social or cultural factors may explain why coffee productivity plays a minor role in farmers’ decision to produce or specialize in coffee. In contrast to most other ecosystem services that we analyzed, coffee showed no positive correlation between its production and productivity (Fig. A2.6), and it could be associated with numerous socio-cultural benefits (Bulitta and Duguma 2021).

# Population density and wealth are negative significant predictors of ecosystem service specialization

Population density had a significant negative relationship in our model (Table 2), meaning kebeles with higher population density tended to specialize less. Farm sizes usually decrease with higher population density (Josephson et al. 2014), and many studies at the household level in the Global South found that larger farm sizes can lead to higher diversification, thus smaller farm sizes should lead to specialization (Benin et al. 2004, Mussema et al. 2015, Li et al. 2017, Kidane and Zegeye 2018, Mekuria and Mekonnen 2018, Torres et al. 2018, Dessie et al. 2019), which seems to contradict our results. In contrast, a recent meta-analysis across 55 countries and 154 crops found that smaller farms had higher crop diversity (Ricciardi et al. 2021), which would support our finding. However, these previous studies focused on the household level in the context of crop or crop-livestock

![](images/84f47a5534e946bf8e837d1f17f554ac0305d3651cf3d136d51f0538e078e8ae.jpg)  
Fig. 7. The relationship between mean altitude and specialization, and its interaction with comparative advantage. Predicted values of specialization based on mean altitude, with $9 5 \%$ confidence interval. For $2 5 \%$ , $50 \%$ , and $7 5 \%$ quantiles of comparative advantage and all other variables set to their mean value.

diversification; only Torres et al. (2018) considered a range of different ecosystem services, including some from agroforestry systems and coffee. Our analysis, in contrast, examined patterns at the kebele level, and we are not aware of any prior investigations for Ethiopian landscapes at this level for forest and woody vegetation-based ecosystem services (in our case: coffee, eucalyptus, and honey).

In our case, higher population density might mean more opportunities to exchange or trade with other people in the kebele (our data showed that for all ecosystem services, except beef, more than half of household production stayed in the kebele or the household; Fig. 4). Therefore, each household might specialize in different ecosystem services, but with a maintenance of an overall diverse production in the kebele that allows households to trade and exchange.

Wealth was a significant negative predictor in our model (Table 2), meaning that wealthier kebeles tended to be less specialized in their ecosystem service production. There is no obvious way to define wealth (for example, some studies looked at durable assets, others at livestock ownership as a proxy), and here we used the proportion of tin roofs as a proxy for wealth (Duguma et al. 2022; Table 1). Again, as for patterns of vegetation-based ecosystem services diversity at the kebele level, no prior data exist, to the best of our knowledge, at the village or kebele level for the relationship between wealth and specialization or diversification, and evidence at the household level is mixed. Some studies showed that farmers who held more (durable) assets were more likely to specialize (Li et al. 2017, Sekyi et al. 2023). Studies in Ethiopia found, however, that livestock ownership, which is a significant capital asset in Ethiopia (Manlosa et al. 2019b), and larger land

holdings were positively associated with diversification (Kidane and Zegeye 2018, Mekuria and Mekonnen 2018), which is further supported by our results. Wealthier kebeles may thus be able to “afford” diversity and not only focus on few subsistence crops that are needed for more immediate survival.

# Implications for policy making

Knowledge on the dynamics between ecosystem service specialization, comparative advantage, and telecoupling is useful to plan for a rapidly changing future landscape. Even though ecosystem service specialization in the study area remains relatively low, we found a strong relationship between telecoupling and specialization, and some evidence for a relationship between comparative advantage and specialization. The government and many other stakeholders favor development toward specialization, intensification, and market integration (Jiren et al. 2020b). In this study, we showed that telecoupling and (to some extent) comparative advantage drive specialization in the landscape, and we know that increased specialization is a likely future development in the study area (Jiren et al. 2020a). However, agricultural specialization comes with economic and ecological trade-offs at different spatial scales (Klasen et al. 2016). Potential negative consequences of specialization include increased vulnerability to ecological and economic shocks due to decreased multifunctionality and resilience (Foley et al. 2005, Fischer et al. 2017, Abson 2019, Frei et al. 2020); decreased food security and higher poverty risk (Pellegrini and Tasciotti 2014, Michler and Josephson 2017, Waha et al. 2018, Manlosa et al. 2019a, Bellon et al. 2020); decline in biodiversity and rise in ecological externalities (Stoate et al. 2009, Abson 2019); and increased social problems such as rising inequalities and the loss of local traditions and knowledge (Jiren et al. 2020a, Schultner et al. 2021, Riechers

et al. 2022). A diversification strategy, on the other hand, could mean to forego the benefits associated with specialization and market integration, such as higher efficiency, yield, and profits (Pellegrini and Tasciotti 2014, Abson 2019).

These considerable potential positive and negative consequences of specialization require informed decisions regarding land use and ecosystem services. The role of farmers in land governance in our study area is limited, and is for example restricted by limited tenure security and land use rights (Shumi et al. 2019, Manlosa 2022). Governance related to ecosystem service management is often strongly hierarchical, and dominated by government administrative organizations, which can lead to power capture, where the interests of few powerful stakeholders override those of smallholder farmers (Jiren et al. 2018, 2022). However, participatory and collaborative governance can be a means to tackle environmental problems in a sustainable way (Newig and Fritsch 2009, Jager et al. 2020). Despite the currently limited role of smallholder farmers in governance in the case study landscape, we hope to strengthen the sustainable future development of the landscape by bringing back results of our research to local communities, and by helping to engage policy processes that involve actors from all levels, including smallholder farmers (Fischer et al. 2018, Jiren et al. 2020a, Jiren et al. 2023).

One example of specific policies in the context of ecosystem service management concerns the future of coffee in the study area, and the decision whether to prioritize southwestern Ethiopia for export coffee production (hence increased specialization and telecoupling), or to establish a biosphere reserve that combines sustainable agriculture, eco-coffee production, and tourism opportunities (Jiren et al. 2020a). Policy makers should consider smallholders’ heterogeneity (in livelihood strategies, capital assets, access to ecosystem services, and agency), and ensure that especially already disadvantaged groups are able to benefit from structural changes to their livelihoods (Manlosa et al. 2019a, Jiren et al. 2020b, Schultner et al. 2021, Manlosa 2022). An example are poor, landless men, who have, in their position as laborcontributing share-croppers, less decision-making power regarding the crops to plant (marketable vs. subsistence crops), with direct implications for their food security (Manlosa 2022). We also found that biophysical factors such as altitude and forest cover influenced specialization directly and played a role in the relationship between comparative advantage and specialization. Kebeles should thus not be managed uniformly or based on administrative groups, but rather based on their unique social and biophysical characteristics (Hanspach et al. 2016, Oberlack et al. 2019).

# CONCLUSION

The goal of this paper was to explore drivers of ecosystem service specialization in an Ethiopian smallholder landscape. Based on data on ecosystem service production, productivity, and flows for each kebele, we found that both telecoupling and comparative advantage were positively significantly correlated with specialization. More telecoupled kebeles were more specialized in their ecosystem service production, and the positive relationship between comparative advantage and specialization grew stronger with altitude. Different factors thus drive specialization in the study area, and at the same time, developments toward specialization, intensification and market integration are

encouraged by the government and expected or supported by many stakeholders. Policy makers should try to balance potential positive and negative consequences of specialization, especially for already disadvantaged groups, such as landless people. Kebeles should not be managed uniformly, but policy making should consider biophysical differences such as altitude and forest cover, because such factors determine to a large extent which ecosystem services are produced and how comparative advantage and specialization develop and interact. We encourage other researchers to employ novel data collection methods if official data cannot be obtained. Through our “coffee bean exercise” we were able to disaggregate ecosystem services flows from the household to the global level and, ultimately, to gain important insights for the smallholder landscape under study. Our analysis of an Ethiopian case study contributed to a broader understanding of how telecoupling and comparative advantage act as drivers of specialization during the process of agricultural structural change in the Global South.

# Appendix 1

Methods

Manuscript title: Drivers of ecosystem service specialization in a smallholder agricultural landscape of the Global South: a case study in Ethiopia

METHODS: DATA COLLECTION AND VALIDATION. 2

Kebele selection . 2

Challenges of the data collection process ..... .. 2

Data imputation and cross-check... ... 2

Coffee bean exercise . 3

METHODS: DEFINITION OF VARIABLES 4

R packages ..... 4

Main variables ... 4

Additional variables . 5

METHODS: DATA ANALYSIS. 6

Hierarchical clustering: dendrogram ...... .... 6

Linear model: data exploration and transformation ......... .... 6

Linear model: two-way interactions ... 6

Robustness checks: different versions of main variables. 7

LITERATURE CITED.. 8

# METHODS: DATA COLLECTION AND VALIDATION

# Kebele selection

Of the overall 78 kebeles in the study area we excluded state forest kebeles (12 kebeles), two kebeles with a forest share larger than $9 0 \%$ , and three towns. The state forest kebeles and the two kebeles with a very high forest share (larger than $9 0 \%$ ; Gemina Dacho and Gere Ifalo) were excluded, because in this research we are interested in multifunctional, mixed-use agricultural landscapes. The three kebeles that have more than $3 0 \%$ of their total area dedicated to towns were excluded (Chira town, Gatira town and Toba town – one located in each woreda), because they function differently than the rural kebeles that our analysis is focused on.

# Challenges of the data collection process

Obtaining the required data on ecosystem service production at the woreda and kebele level was challenging and time-consuming. Such sub-national data needs to be obtained from experts in person, because no online data is available. For some ecosystem services, there was only little official data available, which meant that we had to rely on experts’ estimates (roughly $4 0 \%$ of all datapoints). We even dropped some ecosystem services from the analysis, because too little datapoints could be obtained.

# Data imputation and cross-check

For beef, we did not collect area data, but instead asked for the main source of fodder, because we had no previous data on how beef fattening cattle in the landscape was fed. Experts indicated that beef fattening cattle were mostly grazing. We thus inferred the area for beef for each kebele by rule of three based on cattle data. Rule of three is a mathematical rule that allows you to solve problems based on proportions, such as $\mathrm { a } / \mathrm { b } = \mathrm { c } / \mathrm { x }$ . To calculate x, we can use: $\mathbf { x } = ( \mathbf { b } ^ { * } \mathbf { c } / \mathbf { a } )$ . For six kebeles for which no data on coffee were provided, we assumed that no coffee is grown in these kebeles, because they are all outside of optimal or potential coffee growing zone. For six kebeles for which no data on eucalyptus were provided, we imputed area values based on the relationship between eucalyptus area to share of woody vegetation in each woreda, and based on this, production values from average woreda productivity for eucalyptus. For two kebeles for which no data on sorghum were provided, we imputed sorghum area based on the ratio of maize and teff area to sorghum area in each woreda, and based on this, production values from average woreda productivity for sorghum.

Data was cross-checked for plausibility and potential outliers. For this, we compared the sums across kebeles with woreda data, compared area data with remote sensing data, and crosschecked productivity of all ecosystem services with secondary data and household-based data of previous project research (Dorresteijn et al. 2017, Manlosa et al. 2019, Shumi et al. 2019). We decided to not exclude any data points.

# Coffee bean exercise

In this exercise, experts were asked to allocate 20 coffee beans (which represent a household’s yearly yield of the ecosystem service) to different spatial scales to spatially disaggregate ecosystem service flows. Note that for beef and cattle we used two differing interpretations. For beef, the 20 beans represented the share of the herd that is sold in each year, because they are only of value to local people when they are sold. For cattle, the 20 beans represented the entire herd owned by a household, because cattle provide a continuous use value to the household (as draft animals). We defined five spatial scales based on local understandings of the supply chain: Household, Local market (kebele), District market (woreda), Central market (regional/national), Global market. We collected this information for all ecosystem services for a selection of 12 kebeles representing social-ecological gradients in the study area, four from each woreda.

Detailed description of instructions.

Please introduce the exercise like this: “In this exercise, I would like to get your expert opinion on where agricultural products from the woreda flow. We will talk about the following agricultural products: cattle, cattle for beef fattening, coffee, eucalyptus (in three sizes), firewood, honey, khat, maize, sorghum, and teff. Please have a look at this picture [show the printed-out figure]. The different squares represent different scales. First, you can see the household level. The other squares represent the local market (kebele), district market (woreda), central market (region and national) and global market.”

[For each agricultural product:]

• “Here we have 20 coffee beans [place 20 coffee beans in household square]. They represent an average household’s yearly harvest/yield of [insert agricultural product]. Let’s now assume we are in an average household in your woreda. By moving the coffee beans, can you please show me how much of the harvest stays in the household and how much is sold on the local (kebele) market or is exchanged between households (what percentage)? How much of the proportion sold at the local market then goes on to the district market? Which share then goes to the central market? How much is sold to the global market?” [allocate coffee beans to different scales, guide by follow-up questions if needed]   
“Now think about the following four kebeles: [see last pages in this document]. Would any of the flows be different in these kebeles than for the average household? “[If so, ask expert to repeat exercise for kebeles where flows are different, with a new set of coffee beans.]   
[When the exercise is complete, take a photo and write down results (…). If a person does not answer to some parts, leave blank. If the flows are the same for a specific kebele as for the woreda indicate with a “ –“.]

[Repeat exercise for all other agricultural products that the expert knows about.]

# METHODS: DEFINITION OF VARIABLES

# R packages

The following R packages were used, in addition to those already indicted in the main text:

o tidyverse (v1.3.1; Wickham et al. 2019)   
o readxl (v1.3.1; Wickham and Bryan 2019)   
o factoextra (v1.0.7; Kassambara and Mundt 2020)   
o ggpubr (v0.4.0; Kassambara 2020)   
o FactoMineR (v2.4; Lê et al. 2008)   
o rstatix (v0.7.0; Kassambara 2021)   
o PerformanceAnalytics (v2.0.4; Peterson and Carl 2020)   
o sjPlot (v2.8.10; Lüdecke 2021)

# Main variables

We measured the degree of specialization/comparative advantage for each kebele through Simpson’s index based on kebele production/productivity data (gini.simpson.C in R package diverse, v0.1.5, Guevara et al. 2016). Using an index - compared to other approaches to quantifying multifunctionality or diversity such as the threshold approach, averaging approach, or calculating the sum of all ecosystem services (for more information see Hölting et al. 2019a) - allows to evaluate whether ecosystem services are supplied equally of if few are dominant, without making normative choices about thresholds or assuming substitutability of ecosystem services (Hölting et al. 2019b, Hölting et al. 2019a). We chose Simpson’s index for infinite samples instead of other diversity indices to measure concentration of both ecosystem service production and productivity, because it is a very meaningful and robust diversity measure and provides good estimates at relatively small sample sizes (Magurran 2011), it reflects best the nature of our data, and it has been widely used in the literature on ecosystem service multifunctionality (Raudsepp-Hearne et al. 2010, Brandt et al. 2014, Stürck and Verburg 2017, Hölting et al. 2019b, Hölting et al. 2020).

We measured the degree of telecoupling for each kebele by a combination of data on average ecosystem service flows to different spatial scales, and ecosystem service production data for each kebele. We calculated the average number of coffee beans attributed by the experts to each spatial scale for each ecosystem service (see bar chart), and weighted the different spatial scales by their degree of telecoupling (from 0 for the household level up to 4 for the global level) to obtain a telecoupling score for each ecosystem service. We then multiplied this score by total annual production for each ecosystem service and summed across ecosystem services to obtain a telecoupling score for each kebele.

# Additional variables

Altitude: Mean altitude was calculated from ASTER digital elevation model with 30m resolution (obtained from https://reverb.echo.nasa.gov/; NASA/METI/AIST/Japan Spacesystems and U.S./Japan ASTER Science Team 2009, Duguma et al. 2022).

Forest share: The extent of 12 biophysically distinct land use and land cover (LULC) classes in each kebele was developed from supervised image classification based on imagery and ground control points (for forest, woody vegetation, arable land, pasture, cultivated wetland, grazed wetland, settlement, towns) as well as informed assumptions (for coffee plantations, eucalyptus plantations, khat, and fruits and vegetables; Duguma et al. 2022). Forest area was then divided by total kebele area (in ha) to obtain forest share.

Landscape diversity: Based on absolute area (in ha) of the 12 LULC classes, we calculated Simpson’s diversity index (gini.simpson in R package diverse; see Guevara et al. 2016).

Remoteness: We summed the distance from the nearest town and the distance from the nearest road (both robust scaled, see Duguma et al. 2022).

Share of women in the population: Population data were obtained from Central Statistical Agency (CSA) 2007. We divided the number of women by the total population in each kebele.

Population density: We divided total population divided by total kebele area.

Wealth: Number of tin roofs (identified from satellite imagery) divided by number of households (see Duguma et al. 2022).

# METHODS: DATA ANALYSIS

# Hierarchical clustering: dendrogram

![](images/e061d30389a94d0bde842e5e86f9f021fe9e047134c30ef210592f2f681e7d52.jpg)  
Figure A1.1. Dendrogram of hierarchical clustering analysis of ecosystem service production data for eight ecosystem services in 61 kebeles (smallest administrative units in Ethiopia). The three groups were derived from visual inspection, considering group interpretability.

# Linear model: data exploration and transformation

We checked for outliers in and relationships between the dependent and independent variables, normality and zero trouble in the dependent variable, and collinearity between the independent variables (Zuur et al. 2010). We centered and scaled all independent variables. We applied a Box-Cox transformation to the dependent variable, and Yeo-Johnson transformations to telecoupling, comparative advantage, female population, landscape diversity and remoteness to account for non-linearity, non-normality, and heterogeneity in the data. We excluded forest share due to collinearity issues with altitude and landscape diversity.

# Linear model: two-way interactions

Based on theoretical considerations, we include two-way interactions between altitude, landscape diversity and comparative advantage. The hierarchical clustering analysis has shown that clusters differ in altitude and in the relationship between specialization and comparative advantage. Kebeles in higher altitudes have lower forest share (one reason is forest clearing in altitude ranges that are unsuitable for coffee; Hylander et al. 2013). Forest share in turn might directly influence comparative advantage (the higher the forest share, the higher the incentive

to intensify production of non-forest ecosystem services), but also is also connected to landscape (land use and land cover) diversity, which in turn probably provides more or less incentives for people to specialize in specific ecosystem services or intensify their production (increase productivity) for certain ecosystem services.

# Robustness checks: different versions of main variables

To check the robustness of our correlation analyses and the linear model, we computed different versions of our main variables. For telecoupling, we wanted to make sure that our results were not dependent on our weighting of the spatial scales (0 for the household level up to 4 for global), which was chosen somewhat arbitrarily. We calculated one version where we weighted the household level with 1 up to the global level with 5, and another version where we weighted the household and local level with 0 and all the three remaining levels with 1.

For specialization and comparative advantage, which we have calculated by Simpson`s index (infinite version), we additionally calculated the finite version of the Simpson’s index (simpson.D in R package diverse), the Shannon index (entropy in R package diverse), and the Gini index (R package ineq, v0.2-13, Zeileis 2014). Note that Shannon index has a reverse interpretation from our other indices: higher values mean more diversity, whereas for Simpson and Gini higher values mean less diversity and more concentration.

# Appendix 2

Results and discussion

Manuscript title: Drivers of ecosystem service specialization in a smallholder agricultural landscape of the Global South: a case study in Ethiopia

RESULTS.. 2

Correlation between comparative advantage and specialization (with and without outlier)..... 2

Altitude, forest share and ecosystem services in kebele faming clusters ......... .... 3

Robustness checks: correlations.. 4

Robustness checks: linear model.. 6

Telecoupling and comparative advantage as significant predictors ... . 11

DISCUSSION . 12

Correlations between ecosystem services production and productivity.......... ... 12

# RESULTS

Correlation between comparative advantage and specialization (with and without outlier) The relationship between comparative advantage and specialization remains positive and significant even when excluding the outlier (kebele Genida Chala).

![](images/3bbcf4356ee4f23651fd65ed110d5efea2aabfe8d9cffe7d06c1648d07eec284.jpg)

Figure A2.1. Scatterplot of the relationship between comparative advantage and ecosystem service specialization, colored by clusters “beef”, “coffee/honey” and “mixed”, across all 61 kebeles (A) and excluding the outlier Genida Chala (B). Specialization was measured by Simpson’s index based on ecosystem service production data, and telecoupling by a combination of ecosystem service production data and weighted average ecosystem service flow data.   
![](images/3bc7a944723273e4ec53eff614a2c665a6925e75c7adec8a9eb5195e61254a40.jpg)  
Clustera Beef a Coffe/Honey a Mixed

![](images/d462520825d6d504203c7ff540354000d983bb44ddbffb79c2db5b8ccf3563e1.jpg)  
Altitude, forest share and ecosystem services in kebele faming clusters

![](images/48ac8b01e0e93299a32a0f33d2885aef433db67d83e94e0771bc5cd7b69148a5.jpg)

![](images/ef89ae2b496fc576c303fe2d3b64f5bf30796f6b9e41e1ead26c391e6d7b578c.jpg)  
Figure A2.2. Boxplots for beef, coffee and honey production, comparing the three kebele farming type clusters. Kruskal-Wallis test for comparing more than two groups for nonparametric data, Dunn’s test for multiple pairwise comparison between groups with Bonferroni correction.

![](images/1079a493b92f22c75207d7a01eedd4e15921e0409ac988e2fb4d366dfd1924e6.jpg)

![](images/1d22d8d0fc335ac094cde4dcd11cccd1b851efc74e8b79bccd09badd337f6807.jpg)  
Figure A2.3. Boxplots for forest share and altitude, comparing the three kebele farming type clusters. Kruskal-Wallis test for comparing more than two groups for non-parametric data, Dunn’s test for multiple pairwise comparison between groups with Bonferroni correction.

# Robustness checks: correlations

The relationship between telecoupling and specialization across all kebeles is robust against the different versions of our main variables. The relationship is also robust in the kebele farming type clusters: for the “beef” and the “mixed” cluster, the relationship remains positive and significant at least at the $10 \%$ level, and the evidence for the “coffee/honey” cluster remains inconclusive, except for the finite Simpson’s index.

![](images/d980919b0197ef8325b4513b5e2e2018012d962028ed98542260e6bce17b68c2.jpg)

![](images/01eaeb630ee6a44f6cf642343af21de009d90fc0ea2066527483e29ddcdd2ab8.jpg)

![](images/3f4ebb7a2cbd93bcffe0f2121b8401d08f6dba5e34fcc2586543c7b933901e53.jpg)

![](images/dc246f4182da1b177cf3b06ee9672ee238202f5cedeb9fa43e5ca42e0d175bd6.jpg)

![](images/7f9696fb23d312259bb6b6833c147d95b6436114f1cd44367921ad0196753e6e.jpg)

![](images/2221e9dad184afe1ef8f722572a87bb4e0e4f75de72409328a5e3d9193a5bcc1.jpg)

![](images/dedbd8a134925415857630c4d749dd559b8568c5a97ebb0fc133001be1178ecc.jpg)

![](images/447f074c4e5d3dfd28b55b699365732a5a1c15602008cd08879fbb17418ec88b.jpg)

![](images/bf0925a4bd05a21c4949a0b86c7d0bda828cc3769a4db56cebdb1409a8876858.jpg)  
Figure A2.4. Scatterplot of relationship between telecoupling and ecosystem service specialization across 61 kebeles, colored by clusters “beef”, “coffee/honey” and “mixed”. For telecoupling: weighting was 0 for the household level up to 4 for the global level (A); 1 for the household level, up to 5 for the global level (B); 0 for the household and local level and 1 for the three remaining levels (C). Specialization measured by Simpson’s index (finite, 1), Gini index (2), and Shannon index (3).

The relationship between comparative advantage and specialization across all kebeles is robust against the different versions of the variables. For the relationship between comparative advantage and specialization in the clusters, the evidence remains similarly inconclusive for all different versions of the variables.

![](images/ac37723be8173841ea1dd4b70af6bf24373084ca80e4961f6e1b81f12f57a297.jpg)

![](images/749304b4e58eae1d4c32349d22990a68bf8c4d8399c8a3842b430662ef4ddba3.jpg)

![](images/258701ed3c41f9c5eb3d809d002d6b0231d1f1ccd1cf518d77c24918bf97430e.jpg)  
Cluster a Beef a Coffee/Honey a Mixed   
Figure A2.5. Scatterplot of relationship between comparative advantage and ecosystem service specialization across 61 kebeles, colored by clusters “beef”, “coffee/honey” and “mixed”. Specialization and comparative advantage measured by Simpson’s index (finite, A), Gini index (B), and Shannon index (C).

# Robustness checks: linear model

The main results of the linear model (positive significant coefficients for telecoupling and the interaction between comparative advantage and altitude) are robust against different versions of our main variables (Table A2.1, A2.3 and A2.4), except for the finite version of the Simpson’s index (Table A2.2), which results in a model where the influence of telecoupling on specialization compared to the other variables is extremely high.

Table A2.1. Results of the linear model testing the influence of social and ecological kebele characteristics on the degree of ecosystem service specialization in a kebele. All predictor terms are continuous. Specialization measured by Simpson’s index (infinite version) based on ecosystem service production data. Telecoupling measured by a combination of ecosystem service production data and weighted average ecosystem service flow data. For Telecoupling, the weighting was 0 for the household level, up to 4 for the global level. For Telecoupling_2, the weighting was 1 for the household level, up to 5 for the global level. For Telecoupling_3, the weighting was 0 for the household and local level and 1 for the three remaining levels. Models selected by stepwise backward model selection based on the Akaike information criterion (AIC).

<table><tr><td rowspan="2">Term</td><td colspan="9">Specialization</td></tr><tr><td>Coeff.</td><td>Std. error</td><td>P-value</td><td>Coeff.</td><td>Std. error</td><td>P-value</td><td>Coeff.</td><td>Std. error</td><td>P-value</td></tr><tr><td>Intercept</td><td>-0.01</td><td>0.10</td><td>0.931</td><td>-0.01</td><td>0.11</td><td>0.927</td><td>-0.01</td><td>0.10</td><td>0.938</td></tr><tr><td>Comparative advantage</td><td>0.19</td><td>0.13</td><td>0.159</td><td>0.25*</td><td>0.13</td><td>0.070</td><td>0.15</td><td>0.13</td><td>0.263</td></tr><tr><td>Telecoupling</td><td>0.66***</td><td>0.15</td><td>&lt;0.001</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>Mean altitude</td><td>0.21*</td><td>0.12</td><td>0.083</td><td>0.27**</td><td>0.13</td><td>0.046</td><td>0.17</td><td>0.11</td><td>0.134</td></tr><tr><td>Population density</td><td>-0.35**</td><td>0.14</td><td>0.018</td><td>-0.24</td><td>0.15</td><td>0.126</td><td>-0.36***</td><td>0.14</td><td>0.010</td></tr><tr><td>Wealth</td><td>-0.25**</td><td>0.11</td><td>0.026</td><td>-0.25**</td><td>0.11</td><td>0.030</td><td>-0.23**</td><td>0.10</td><td>0.031</td></tr><tr><td>Comparative advantage*Mean altitude</td><td>0.33*</td><td>0.18</td><td>0.065</td><td>0.36*</td><td>0.18</td><td>0.051</td><td>0.29*</td><td>0.17</td><td>0.099</td></tr><tr><td>Telecoupling_2</td><td></td><td></td><td></td><td>0.52***</td><td>0.16</td><td>0.002</td><td></td><td></td><td></td></tr><tr><td>Female population</td><td></td><td></td><td></td><td>-0.20</td><td>0.12</td><td>0.109</td><td></td><td></td><td></td></tr><tr><td>Telecoupling_3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>0.71***</td><td>0.14</td><td>&lt;0.001</td></tr><tr><td>Observations</td><td>61</td><td></td><td></td><td>61</td><td></td><td></td><td>61</td><td></td><td></td></tr><tr><td>R2/R2 adjusted</td><td>0.398/0.331</td><td></td><td></td><td>0.370/0.286</td><td></td><td></td><td>0.437/0.375</td><td></td><td></td></tr></table>

* p<0.1 ** p<0.05 *** p<0.01

Table A2.2. Results of the linear model testing the influence of social and ecological kebele characteristics on the degree of ecosystem service specialization in a kebele. All predictor terms are continuous. Specialization measured by Simpson’s index (finite version) based on ecosystem service production data. Telecoupling measured by a combination of ecosystem service production data and weighted average ecosystem service flow data. For Telecoupling, the weighting was 0 for the household level, up to 4 for the global level. For Telecoupling_2, the weighting was 1 for the household level, up to 5 for the global level. For Telecoupling_3, the weighting was 0 for the household and local level and 1 for the three remaining levels. Models selected by stepwise backward model selection based on the Akaike information criterion (AIC).

<table><tr><td rowspan="2">Term</td><td colspan="9">Specialization</td></tr><tr><td>Coeff.</td><td>Std. error</td><td>P-value</td><td>Coeff.</td><td>Std. error</td><td>P-value</td><td>Coeff.</td><td>Std. error</td><td>P-value</td></tr><tr><td>Intercept</td><td>0.00</td><td>0.04</td><td>1.000</td><td>0.00</td><td>0.04</td><td>1.000</td><td>-0.00</td><td>0.04</td><td>1.000</td></tr><tr><td>Telecoupling</td><td>1.00 ***</td><td>0.05</td><td>&lt;0.001</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>Population density</td><td>-0.10 **</td><td>0.05</td><td>0.035</td><td>-0.13 **</td><td>0.05</td><td>0.015</td><td></td><td></td><td></td></tr><tr><td>Telecoupling_2</td><td></td><td></td><td></td><td>1.06 ***</td><td>0.06</td><td>&lt;0.001</td><td></td><td></td><td></td></tr><tr><td>Mean altitude</td><td></td><td></td><td></td><td>0.07</td><td>0.05</td><td>0.172</td><td>-0.13 ***</td><td>0.04</td><td>0.004</td></tr><tr><td>Wealth</td><td></td><td></td><td></td><td>-0.09 **</td><td>0.04</td><td>0.035</td><td></td><td></td><td></td></tr><tr><td>Landscape diversity</td><td></td><td></td><td></td><td>-0.06</td><td>0.04</td><td>0.163</td><td></td><td></td><td></td></tr><tr><td>Telecoupling_3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>0.92 ***</td><td>0.04</td><td>&lt;0.001</td></tr><tr><td>Observations</td><td>61</td><td></td><td></td><td>61</td><td></td><td></td><td>61</td><td></td><td></td></tr><tr><td>R2/R2 adjusted</td><td>0.909 / 0.906</td><td></td><td></td><td>0.913 / 0.905</td><td></td><td></td><td>0.887 / 0.883</td><td></td><td></td></tr></table>

* p<0.1 ** p<0.05 *** p<0.01

Table A2.3. Results of the linear model testing the influence of social and ecological kebele characteristics on the degree of ecosystem service specialization in a kebele. All predictor terms are continuous. Specialization measured by Gini index based on ecosystem service production data. Telecoupling measured by a combination of ecosystem service production data and weighted average ecosystem service flow data. For Telecoupling, the weighting was 0 for the household level, up to 4 for the global level. For Telecoupling_2, the weighting was 1 for the household level, up to 5 for the global level. For Telecoupling_3, the weighting was 0 for the household and local level and 1 for the three remaining levels. Models selected by stepwise backward model selection based on the Akaike information criterion (AIC).

<table><tr><td rowspan="2">Term</td><td colspan="9">Specialization</td></tr><tr><td>Coeff.</td><td>Std. error</td><td>P-value</td><td>Coeff.</td><td>Std. error</td><td>P-value</td><td>Coeff.</td><td>Std. error</td><td>P-value</td></tr><tr><td>Intercept</td><td>-0.07</td><td>0.10</td><td>0.478</td><td>-0.08</td><td>0.10</td><td>0.453</td><td>-0.06</td><td>0.10</td><td>0.531</td></tr><tr><td>Comparative advantage</td><td>0.13</td><td>0.10</td><td>0.219</td><td>0.15</td><td>0.11</td><td>0.162</td><td>0.09</td><td>0.10</td><td>0.382</td></tr><tr><td>Telecoupling</td><td>0.64 ***</td><td>0.14</td><td>&lt;0.001</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>Mean altitude</td><td>0.24 *</td><td>0.12</td><td>0.059</td><td>0.28 **</td><td>0.13</td><td>0.040</td><td>0.15</td><td>0.11</td><td>0.201</td></tr><tr><td>Landscape diversity</td><td>-0.04</td><td>0.11</td><td>0.709</td><td>-0.02</td><td>0.12</td><td>0.852</td><td>-0.09</td><td>0.11</td><td>0.392</td></tr><tr><td>Female population</td><td>-0.17</td><td>0.12</td><td>0.142</td><td>-0.22 *</td><td>0.12</td><td>0.069</td><td></td><td></td><td></td></tr><tr><td>Population density</td><td>-0.34 **</td><td>0.13</td><td>0.015</td><td>-0.31 **</td><td>0.14</td><td>0.035</td><td>-0.40 ***</td><td>0.12</td><td>0.002</td></tr><tr><td>Wealth</td><td>-0.17 *</td><td>0.10</td><td>0.100</td><td>-0.18</td><td>0.11</td><td>0.103</td><td>-0.15</td><td>0.10</td><td>0.121</td></tr><tr><td>Comparative advantage*Mean altitude</td><td>0.30 ***</td><td>0.11</td><td>0.010</td><td>0.32 ***</td><td>0.11</td><td>0.007</td><td>0.26 **</td><td>0.11</td><td>0.021</td></tr><tr><td>Comparative advantage*Landscape diversity</td><td>0.22 **</td><td>0.10</td><td>0.039</td><td>0.25 **</td><td>0.11</td><td>0.024</td><td>0.19 *</td><td>0.10</td><td>0.069</td></tr><tr><td>Telecoupling_2</td><td></td><td></td><td></td><td>0.57 ***</td><td>0.15</td><td>&lt;0.001</td><td></td><td></td><td></td></tr><tr><td>Telecoupling_3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>0.75 ***</td><td>0.13</td><td>&lt;0.001</td></tr><tr><td>Observations</td><td>61</td><td></td><td></td><td>61</td><td></td><td></td><td>61</td><td></td><td></td></tr><tr><td>R2/R2 adjusted</td><td>0.527 / 0.444</td><td></td><td></td><td>0.483 / 0.392</td><td></td><td></td><td>0.544 / 0.474</td><td></td><td></td></tr></table>

* p<0.1 ** p<0.05 *** p<0.01

Table A2.4. Results of the linear model testing the influence of social and ecological kebele characteristics on the degree of ecosystem service specialization in a kebele. All predictor terms are continuous. Specialization measured by Shannon index based on ecosystem service production data. Telecoupling measured by a combination of ecosystem service production data and weighted average ecosystem service flow data. For Telecoupling, the weighting was 0 for the household level, up to 4 for the global level. For Telecoupling_2, the weighting was 1 for the household level, up to 5 for the global level. For Telecoupling_3, the weighting was 0 for the household and local level and 1 for the three remaining levels. Models selected by stepwise backward model selection based on the Akaike information criterion (AIC).

<table><tr><td rowspan="2">Term</td><td colspan="9">Specialization</td></tr><tr><td>Coeff.</td><td>Std. error</td><td>P-value</td><td>Coeff.</td><td>Std. error</td><td>P-value</td><td>Coeff.</td><td>Std. error</td><td>P-value</td></tr><tr><td>Intercept</td><td>0.03</td><td>0.10</td><td>0.779</td><td>0.03</td><td>0.11</td><td>0.773</td><td>0.02</td><td>0.10</td><td>0.828</td></tr><tr><td>Comparative advantage</td><td>0.22*</td><td>0.12</td><td>0.067</td><td>0.26**</td><td>0.12</td><td>0.035</td><td>0.16</td><td>0.11</td><td>0.160</td></tr><tr><td>Telecoupling</td><td>-0.52***</td><td>0.15</td><td>0.001</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>Mean altitude</td><td>-0.33**</td><td>0.12</td><td>0.012</td><td>-0.35**</td><td>0.13</td><td>0.012</td><td>-0.24**</td><td>0.11</td><td>0.038</td></tr><tr><td>Remoteness</td><td>0.17</td><td>0.13</td><td>0.179</td><td>0.19</td><td>0.13</td><td>0.151</td><td></td><td></td><td></td></tr><tr><td>Female population</td><td>0.21*</td><td>0.12</td><td>0.084</td><td>0.26**</td><td>0.12</td><td>0.039</td><td>0.16</td><td>0.12</td><td>0.173</td></tr><tr><td>Population density</td><td>0.37**</td><td>0.15</td><td>0.017</td><td>0.32**</td><td>0.16</td><td>0.046</td><td>0.34**</td><td>0.14</td><td>0.017</td></tr><tr><td>Wealth</td><td>0.29***</td><td>0.11</td><td>0.010</td><td>0.29**</td><td>0.11</td><td>0.012</td><td>0.26**</td><td>0.10</td><td>0.015</td></tr><tr><td>Comparative advantage*Mean altitude</td><td>0.35**</td><td>0.16</td><td>0.030</td><td>0.37**</td><td>0.16</td><td>0.026</td><td>0.26*</td><td>0.15</td><td>0.080</td></tr><tr><td>Telecoupling_2</td><td></td><td></td><td></td><td>-0.43**</td><td>0.16</td><td>0.011</td><td></td><td></td><td></td></tr><tr><td>Telecoupling_3</td><td></td><td></td><td></td><td></td><td></td><td></td><td>-0.62***</td><td>0.14</td><td>&lt;0.001</td></tr><tr><td>Observations</td><td>61</td><td></td><td></td><td>61</td><td></td><td></td><td>61</td><td></td><td></td></tr><tr><td>R2/R2 adjusted</td><td>0.447 / 0.362</td><td></td><td></td><td>0.405 / 0.313</td><td></td><td></td><td>0.463 / 0.392</td><td></td><td></td></tr></table>

* p<0.1 ** p<0.05 *** p<0.01

Including dummy variables for imputed values in the model showed that imputed coffee values had a significant influence on the model results. However, we are relatively confident in our assumption that these kebeles do not produce any coffee, since they lie outside the coffee growing zone. A high influence on the model results by these values was expected, because none of the other ecosystem services were reported as “zero”. This means that zero coffee production has a high influence on telecoupling, specialization and comparative advantage for these kebeles. The remaining imputed values (for eucalyptus and sorghum) did not show a significant influence on the model results.

Table A2.5. Results of the full linear model testing the influence of social and ecological kebele characteristics on the degree of ecosystem service specialization in a kebele. “coffee_impute” is a dummy variable for all kebeles where coffee data were imputed, “other_impute” for any other imputed ecosystem services.   

<table><tr><td rowspan="2">Term</td><td colspan="3">Specialization</td></tr><tr><td>Coefficient</td><td>Standard error</td><td>P-value</td></tr><tr><td>Intercept</td><td>-0.20*</td><td>0.12</td><td>0.095</td></tr><tr><td>Comparative advantage</td><td>-0.04</td><td>0.14</td><td>0.809</td></tr><tr><td>Telecoupling</td><td>0.72***</td><td>0.17</td><td>&lt;0.001</td></tr><tr><td>Mean altitude</td><td>0.05</td><td>0.15</td><td>0.717</td></tr><tr><td>Landscape diversity</td><td>-0.04</td><td>0.12</td><td>0.772</td></tr><tr><td>Remoteness</td><td>-0.05</td><td>0.12</td><td>0.677</td></tr><tr><td>Female population</td><td>-0.06</td><td>0.12</td><td>0.589</td></tr><tr><td>Population density</td><td>-0.44***</td><td>0.15</td><td>0.004</td></tr><tr><td>Wealth</td><td>-0.11</td><td>0.11</td><td>0.319</td></tr><tr><td>Coffee_impute</td><td>1.77***</td><td>0.46</td><td>&lt;0.001</td></tr><tr><td>Other_impute</td><td>-0.01</td><td>0.36</td><td>0.980</td></tr><tr><td>Comparative advantage*Mean altitude</td><td>0.13</td><td>0.21</td><td>0.552</td></tr><tr><td>Mean altitude*Landscape diversity</td><td>0.07</td><td>0.15</td><td>0.619</td></tr><tr><td>Comparative advantage*Landscape diversity</td><td>0.26</td><td>0.24</td><td>0.281</td></tr><tr><td>Observations</td><td>61</td><td></td><td></td></tr><tr><td>R2/R2adjusted</td><td>0.584 / 0.469</td><td></td><td></td></tr></table>

* p<0.1 ** p<0.05 *** p<0.01

# Telecoupling and comparative advantage as significant predictors

By comparing our model with a model without comparative advantage and telecoupling, we can be confident that telecoupling and comparative advantage both significantly contribute to predictions of specialization (ANOVA; $\operatorname { F } ( 4 , 4 9 ) = 6 . 7 2 3 2$ , $\mathsf { p } < 0 . 0 0 1$ ).

We are confident that telecoupling and comparative advantage both contribute to predictions of specialization (comparative advantage in its interaction with altitude): they have significant coefficients in the full model; their removal from the full model reduces model fit (see ANOVA results); and they are significant when fit by themselves. We additionally used the dredge function starting from the full model (R package MuMIn, v1.43.17; Barton 2020) to check if telecoupling and comparative advantage are part of the best models (according to AIC). All of the best ranked models included telecoupling, it was the most important predictor, it had the strongest effect, and was the most significant of all the predictors. Some of the best models included comparative advantage and its interaction with altitude, it was fifth important predictor, and the interaction with altitude had a significant positive effect on average.

# DISCUSSION

# Correlations between ecosystem services production and productivity

For all ecosystem services, production and productivity are positively significantly correlated, except for beef, coffee and teff. The productivity data for beef were derived from cattle data and not directly collected, which might explain the divergent finding here. Cultural reasons might explain the missing relationship for coffee and teff (see manuscript).

![](images/d395bf17df855ccfb8138720330c7badd059bc909a7c3c18523d2e7638d2799c.jpg)

![](images/98c40c456458fced54895b932ca21a871b7b4b4dd017352fd8be10ba3732b09f.jpg)

![](images/e75a97b5cdf3c2157c8452039e7acc95433d724f4fb7dba8ad0acc5d03bc8a9b.jpg)

![](images/e6995692529a7d515b91d4dc5fbb6b22f09506c4e890e6c6536d1cde74912701.jpg)

![](images/bea008e3afc2835964fb1dfac1468c1a3daefa31201e741822941a0076d6d5c2.jpg)

![](images/cbeebaed0b026e7be69a3ee26a6d704d3746779c8da3df182a1b9407b2efcd54.jpg)

![](images/c41fc0e91fca83011670baf770332ec8d9412d27bafa9b168ef56133814d59fc.jpg)

![](images/d8a5be8770570a160007b4f1468453f089a34baad9f6f78d1f0fee86865a248e.jpg)  
Figure A2.6. Correlations (Kendall’s Tau coefficient) between ecosystem service production (adjusted for kebele area) and productivity for 61 kebeles.
