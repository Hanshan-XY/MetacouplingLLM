LETTER • OPEN ACCESS

# Boat to bowl: resilience through network rewiring of a community-supported fishery amid the COVID-19 pandemic

To cite this article: Andrew K Carlson et al 2021 Environ. Res. Lett. 16 034054

View the article online for updates and enhancements.

# You may also like

Air quality-related human health damagesof wild capture seafood production in the United States

Madisen L Gittlin, Sumil K Thakrar, Madeline G Faubion et al.

Structure and evolution of the globalseafood trade network

Jessica A Gephart and Michael L Pace

Broadening the sustainable seafood movement—systemic and enabling approaches to transform blue food

Malin Jonell, Abigayil Blandon, Julia Maria

Charlotte Feine et al.

![](images/9bb6f6d2c1af18ebd0bcb1440116a0fff06986b5896c20bbdb6c5171d992461e.jpg)

250th ECS Meeting

Otober 25-29, 2026

Calgary, Canada

BMO Center

![](images/f8283ca2737d6c161890eac2a931afad4cb5485bc3e57996f50ff5efac1926e2.jpg)

The Electrochemical Society

Advancing solid state&electrochemical science & technology

Stepinto the

Spotlight

SUBMIT YOUR

ABSTRACT

Submission deadline:

March 27,2026

# ENVIRONMENTAL RESEARCH

LETTERS

![](images/964fd2cab7f5bb8b0446b6a628255c90243c93ef982b21f9b0d5e689cfb5cd5b.jpg)

CrossMark

# OPEN ACCESS

# LETTER

# Boat to bowl: resilience through network rewiring of a community-supported fishery amid the COVID-19 pandemic

RECEIVED

30 October 2020

REVISED

5 February 2021

ACCEPTED FOR PUBLICATION

10 February 2021

PUBLISHED

2 March 2021

Original content from this work may be used under the terms of the Creative Commons Attribution 4.0 licence.

Any further distribution of this work must maintain attribution to the author(s) and the title of the work, journal citation and DOI.

![](images/28e501099b50546d52e5a2edcf924f136e0702438439c80100817e95d90623b6.jpg)

Andrew K Carlson $^ { 1 , 2 } \oplus$ , Talia Young $\cdot ^ { 1 , 3 , 4 } ( \mathbb { D } )$ , Miguel A Centeno5, Simon A Levin1,2

and Daniel I Rubenstein1,2

1 Department of Ecology and Evolutionary Biology, Princeton University, Princeton, NJ, United States of America   
2 High Meadows Environmental Institute, Princeton University, Princeton, NJ, United States of America   
3 Department of Environmental Studies, Haverford College, Haverford, PA, United States of America   
4 Fishadelphia Community Seafood Program, Philadelphia, PA, United States of America   
5 Department of Sociology, Princeton University, Princeton, NJ, United States of America

E-mail: andrewkc@princeton.edu and andrew.carlson@ufl.edu

Keywords: community-supported fishery programs, coupled human and natural systems, CSF, coronavirus, COVID-19, metacoupling, SARS-CoV-2

Supplementary material for this article is available online

# Abstract

Fisheries are coupled human–natural systems locally, regionally, and globally. However, human–nature interactions within and between adjacent and distant systems (metacouplings) are rarely studied in fisheries despite their prevalence and policy relevance. We filled this knowledge gap by using network models to identify how the severe acute respiratory syndrome coronavirus 2 (SARS-CoV-2) pandemic has rewired couplings and reshaped resilience of Fishadelphia, a community-supported fishery program (CSF) in New Jersey and Pennsylvania, USA. As abstractions illustrating interactions among supply-chain actors, networks are helpful for characterizing flows and assessing resilience to disturbances such as those induced by the SARS-CoV-2 pandemic. Since Fall 2018, 18 seafood (finfish and shellfish) species totaling 6273 lbs have flowed from harvesters $( n = 4 )$ ), to processors $( n = 2 )$ ), to a distributor, to retailers $( n = 2 )$ ), and finally to customers $\overset { \prime } { n } = 1 8 3$ ). The pandemic reduced the number of seafood harvesters and processors $( - 5 0 \% )$ , seafood flow quantity $( - 2 5 \% )$ , species diversity in the marketplace $( - 6 7 \% )$ , and species per supplier $( - 5 0 \% )$ before stopping flows in mid-March 2020, when Fishadelphia closed for 3 months. Models of network optimality indicated that the pandemic fragmented metacouplings that previously allowed multiple seafood suppliers to provide diverse products to customers. However, demand-side resilience increased through dispersed, socially distanced, efficient seafood delivery that expanded the customer base and generally increased customer satisfaction. This resilience dichotomy—wherein the post-closure network was less resilient than the pre-closure network in supply-side species diversity, but more resilient in demand-side social distancing, delivery efficiency, and customer satisfaction—has implications for rewiring networks to sustain CSFs and other local food systems amid ecological and social disturbances.

# 1. Introduction

From food web control and nutrient cycling to economic growth and food provisioning, fisheries contribute to ecosystems and human systems locally to globally [1, 2]. Fisheries also contribute to food security (table 1) and livelihoods, providing income and employment for 60 million people globally [3–5]. Humans derive health benefits from fisheries through biomedical research (e.g. Zebrafish

(Danio rerio) in cancer genetics and regenerative medicine), fish predation on disease-carrying mosquitoes, and connections with the outdoors [5–8]. In developed and developing countries, fisheries support human cultures through ethnic, spiritual, aesthetic, and inspirational (e.g. art, folklore) contributions while unifying communities around common purposes such as environmental stewardship and local food [4, 9]. Although most livelihood contributions of fisheries employment occur in

developing countries [3], developed countries derive considerable human health, cultural, and recreational (e.g. fishing, boating) benefits from fisheries [10]. For instance, recreational fishing in the U.S. generates $\$ 125$ billion $\mathrm { y r } ^ { - 1 }$ in total economic impact and $\$ 49.8$ billion in retail sales, supporting more than 800 000 jobs [11].

Despite the ecological and societal importance of fisheries, human–nature interactions (e.g. fish catch, harvest, retail) within fisheries systems and between adjacent and distant systems have scarcely been examined within individual studies [18, 28, 29]. Such multiscalar human–nature interactions are important to investigate because they impact fish stocks and stakeholders in many fisheries. For instance, fisheries management decisions by commercial fishers and governments at large scales (e.g. national, international) can affect fish abundance, distribution, and catch at local and regional scales [30, 31]. These multiscalar human–nature interactions can reduce catches of subsistence and artisanal fishers while modifying supply chains of fish and other foodstuffs (e.g. soybeans, wheat) through shifts in resilience—a system’s capacity to withstand socioeconomic and environmental disturbance without fundamentally changing to an alternate, less desirable state (table 1) [19, 26, 31]. It is also important to study multiscalar human–nature interactions in fisheries because they are complicated and germane to fisheries management [19, 20, 32, 33]. Causes and effects of multiscalar human–nature interactions vary widely among fisheries systems (e.g. Peruvian anchoveta Engraulis ringens, mahi mahi Coryphaena hippurus, Atlantic bluefin tuna Thunnus thynnus, brook charr Salvelinus fontinalis) [19, 31, 34], demanding management approaches that incorporate the contextual uniqueness of individual fisheries while acknowledging their multiscalar connections with other fisheries and human systems [20, 33]. Given the prevalence, complexity, and policy relevance of multiscalar human–nature interactions in fisheries, it is important to develop tools to quantify, predict, and manage these linkages. Ideal fisheries for developing such tools would involve human–nature interactions distributed across distinct, definable spatial boundaries.

North American community-supported fishery programs (CSFs, table 1) are a case in point. CSFs are seafood distribution programs that market finfish and shellfish from suppliers (e.g. harvesters, processors) to consumers through shortened supply chains, often involving recurring, pre-arranged product deliveries [12, 13]. Originating in Maine in 2007 [35], CSFs decrease the distance (physical and/or social) from ‘boat to bowl,’ much like Community Supported Agriculture programs reduce the distance from ‘farm to fork’ [12]. CSF missions vary [36] but typically involve providing fresh, local seafood and corresponding education to consumers and generating alternative markets and

fair prices for suppliers. CSFs often seek to make seafood environmentally friendly by minimizing overexploitation, habitat impairment, and carbon emissions from international trade [12, 13, 37]. We illustrate how CSFs can increase resilience through network rewiring in response to disturbances, such as those created by a pandemic. Rewiring consists of adding or deleting nodes (network actors, e.g. harvesters, processors) or edges (connections between nodes) to continue providing food to consumers, generating markets for suppliers, and fulfilling other CSF objectives amid disturbances (table 1). Rewiring represents a possible model for sustaining CSFs and building resilience during supply-chain disruptions [23, 24, 38], as exemplified by adaptation of seafood supply chains amid climate change [39, 40].

Founded in 2017, Fishadelphia is a CSF based in Philadelphia, Pennsylvania, USA [14]. Throughout the spring and fall, Fishadelphia buys seafood (defined herein as finfish and shellfish) from harvesters and processors along the New Jersey Atlantic Coast. Fishadelphia then transports seafood to two Philadelphia high schools, which serve as retail locations where students sell seafood to customers. Students are fully engaged as retailers and managers of Fishadelphia’s day-to-day operations (e.g. communications, planning, budgeting) [14]. Fishadelphia is unique among CSFs in recruiting and connecting socioculturally diverse retailers and customers, including Asian, Black/African-American, and Hispanic/Latinx individuals and people from educationally and socioeconomically diverse backgrounds. Indeed, $7 3 \%$ of student retailers speak at least one non-English language (e.g. Spanish, Vietnamese, Khmer), as do $2 8 \%$ of customers [14]. Combined with its goal of expanding markets for seafood suppliers, the sociocultural vibrancy of Fishadelphia could make it a model system for developing tools to understand how human–nature interactions affect diverse stakeholders. However, Fishadelphia’s supply-chain structure and resilience must first be evaluated relative to the program’s mission to provide fresh, local seafood at fair prices and cultivate relationships among culturally and economically diverse harvesters, processors, retailers, and customers.

Assessing Fishadelphia’s progress toward its mission is particularly significant amid global spread of severe acute respiratory syndrome coronavirus 2 (SARS-CoV-2, hereafter COVID-19), which is having far-reaching effects on food systems locally to globally (e.g. restaurant closures, transportation disruptions, mismatches between supplies and consumer demand) [27, 41]. Perturbations like COVID-19 have the potential to initiate new seafood distribution pathways in Fishadelphia that differ from traditional conduits, which may be amplified or inhibited as perturbations continue and eventually subside. Moreover, a return to normal seafood distribution pathways, if it occurs, may exhibit hysteresis,

Table 1. Definitions of key terms used in this paper.   

<table><tr><td>Term</td><td>Definition</td><td>References</td></tr><tr><td>Community-supported fishery program (CSF)</td><td>Seafood distribution programs that market fresh, local finfish and shellfish from suppliers (e.g. harvesters, processors) to consumers through shortened supply chains.</td><td>[12-14]</td></tr><tr><td>Degree</td><td>The number of direct connections a node has.</td><td>[15]</td></tr><tr><td>Edge</td><td>A connection between two nodes representing a flow (e.g. seafood, money, information).</td><td>[15-17]</td></tr><tr><td>Food security</td><td>The condition when all people, at all times, have physical, social, and economic access to sufficient, safe, and nutritious food that meets their dietary needs and food preferences for an active and healthy life.</td><td>[3]</td></tr><tr><td>Multiscalar human-nature interactions (metacouplings)</td><td>Linkages between people and ecosystems within individual human-natural systems (Type 1 interactions) as well as between adjacent systems (Type 2) and between distant systems (Type 3).</td><td>[18-20]</td></tr><tr><td>Network analysis</td><td>A suite of integrated methods for illustrating relations among network actors and analyzing the social and ecological structures that drive, and result from, these relations.</td><td>[15-17]</td></tr><tr><td>Network redundancy</td><td>The existence of independent paths connecting particular nodes, providing alternative options for fulfilling network objectives (e.g. distributing seafood) when primary paths are disrupted or removed.</td><td>[21, 22]</td></tr><tr><td>Network rewiring</td><td>Changing network structure by adding or deleting nodes or edges to continue fulfilling network objectives (e.g. providing food for consumers, generating markets for suppliers) amid disturbances.</td><td>[23, 24]</td></tr><tr><td>Node</td><td>A network actor (e.g. harvester, processor).</td><td>[15-17]</td></tr><tr><td>Power centrality</td><td>A measure of a node&#x27;s influence over other nodes reflecting its degree and the number of edges it shares with low-degree nodes. A node has high power centrality if has both high degree and many connections to low-degree nodes.</td><td>[25]</td></tr><tr><td>Resilience</td><td>A system&#x27;s capacity to withstand socioeconomic and environmental disturbance without fundamentally shifting to an alternate, less desirable state.</td><td>[26]</td></tr><tr><td>Supply chain</td><td>A network that moves products from production to consumption.</td><td>[14, 27]</td></tr></table>

involving a ‘new normal’ with ‘rewirings’ that change network structure [42]. It is important to determine which seafood distribution pathways—ranging from the traditional, to the pandemic-induced, to the ‘new normal’—are most resilient to COVID-19 and future disturbances (e.g. fishery collapses, natural disasters) to develop Fishadelphia management strategies going forward.

Such questions can be addressed using network analysis (table 1). We used this approach because it is a well-established method for understanding interactions among actors in social and ecological systems [43, 44], including fisheries [16, 17, 45, 46]. In addition, Fishadelphia is a model system for network analysis because it is data-rich, cataloging information on network actors (e.g. harvesters, processors, customers) and quantities (e.g. seafood flowing among actors) across spatial regions over time while exemplifying network characteristics of larger food supply chains [14]. Moreover, Fishadelphia

administrators need, and will benefit from, network information to quantify and predict seafood flows and manage supply-chain operations and customer engagement initiatives, among other activities. Finally, analyzing the Fishadelphia network is critical because the program’s financial viability and longevity depend on flows of seafood, money, information, and people at multiple spatial levels [14]. These multiscalar interactions have been termed ‘metacouplings’ [15, 18–20, 31, 34, 47]: human–nature interactions within individual human–natural systems (Type 1 interactions) as well as between adjacent systems (Type 2) and between distant systems (Type 3; table 1). Of particular interest for metacoupling-based network analysis of Fishadelphia are effects of COVID-19 on harvesters, processors, retailers, and customers and impacts of a pandemic adaptation strategy: development of a porch-based seafood delivery program. In this program, volunteers host coolers at their homes to provide seafood

![](images/13b83bd5b13c5a298fab34b1646892f7ba59f8c1f7c6e5aec7b4d9c14424163a.jpg)  
Figure 1. The Fishadelphia network depicting seafood flows (arrows) from the Atlantic Ocean to harvesters, processors, a distributor, retailers, and customers. Flows encompass four seasons before Fishadelphia’s closure (Fall 2018, Spring 2019, Fall 2019, Spring 2020), and arrow width is proportional to seafood weight (lbs). Nodes are labeled by type and location (northern (n), southern (s), and inland (i) subregions). The retailer node (star) encompasses two schools serving 183 customers, which are not included for clarity. Species are as follows: bigeye tuna (Thunnus obesus), black sea bass (Centropristis striata), bluefish (Pomotomus saltatrix), cherrystone clam (Mercenaria mercenaria), dogfish (smooth, Mustelis canis), eel (Conger oceanicus), fluke (summer flounder, Paralichthys dentatus), ling (red hake, Urophycis chuss), littleneck clam (Mercenaria mercenaria), monkfish (Lophius americanus), oyster (Crassostrea virginica), porgy (scup, Stenotomus chrysops), scallop (Placoplecten magellicus), squid (Doryteuthis pealeii), tilefish (Lopholatilus chamaeleonticeps), whiting (silver hake, Merluccius bilinearis), winter skate (Leucoraja ocellata), yellowfin tuna (Thunnus albacares).

to customers in distributed locations that enable socially distanced, time-separated arrivals, thereby avoiding large gatherings of people while making seafood delivery more efficient and convenient for customers.

Our first objective was to use network analysis to visualize flows of seafood among Fishadelphia stakeholders before a 3 month pandemic-induced closure. Our second objective was to identify, on a seasonal and biweekly basis, how the Fishadelphia network changed before and after closing. Our final objective was to use what-if scenario analysis to assess pre-closure and post-closure network optimality in terms of five Fishadelphia objectives (species diversity, delivery efficiency, customer safety, customer satisfaction, flow consistency) and develop strategies for managing Fishadelphia amid future disturbances.

# 2. Methods

# 2.1. Fishadelphia network description

Fishadelphia encompasses seafood harvesters $( n = 4 )$ ), processors $( n = 2 )$ ), a distributor, retailers $( n = 2 )$ ), and

customers $n = 1 8 3$ ; figure 1). Finfish harvesters in the study area’s northern subregion (counties along the Atlantic Coast north of Philadelphia, denoted ‘n’) are denoted anonymously as Harvester_1n and Harvester_2n. Other nodes are located in the southern subregion (counties along the Atlantic Coast south of Philadelphia, denoted ‘s’) and the inland subregion (non-coastal counties surrounding Philadelphia, denoted ‘i’). These nodes include shellfish harvesters (Harvester_3s, Harvester_4i), Processor_1s (which processes finfish and sells shellfish), Processor_2i, Distributor_1i, Retailer_Si (schools), and Retailer_Pi (porches).

Seafood supply from Fishadelphia harvesters and processors is known to be seasonally stable, with fishing occurring year-round [14]. Before the pandemic, the Fishadelphia distributor transported seafood from harvesters and processors to school-based retailers (figure 1) every 2 weeks across four seasons: Fall 2018 (17 September 2018–20 December 2018), Spring 2019 (19 February 2019–30 May 2019), Fall 2019 (26 September 2019–20 December 2019), and Spring 2020 (21 January 2020–16 March 2020). Data analyzed herein encompass school-based

seafood delivery in the above seasons and porchbased delivery in Summer 2020 (12 June 2020–9 July 2020). Biweekly data were available in 2020 and used to measure COVID-induced network changes across late January (21 January 2020–3 February 2020), early February (4 February 2020–17 February 2020), late February (18 February 2020–2 March 2020), early March (3 March 2020–16 March 2020), closure (17 March 2020–11 June 2020), mid-June (12 June 2020–25 June 2020), and early July (26 June 2020–9 July 2020).

# 2.2. Network analysis

Network analysis was used to quantify and model seafood flows (edges) among stakeholders (nodes). Metacouplings were defined as flows of seafood (lbs) among stakeholders within subregions in a particular state (Type 1 interactions), between subregions in a state (Type 2), and between states (Type 3). Network analysis was performed in R Studio [48] using the network, igraph, sna, and visNetwork packages [49–52] to visualize Fishadelphia in three ways: (a) single network encompassing four pre-closure seasons (Fall 2018, Spring 2019, Fall 2019, Spring 2020), (b) changes in five season-specific networks before and after closure, and (c) changes in biweekly networks before and after closure. For each analysis, network attributes (e.g. number of nodes, edges) and node-level metrics including degree (number of direct connections) and power centrality (table 1) were evaluated. A node’s power centrality is proportional to its degree (a measure of centrality) and the number of edges it shares with low-degree nodes (a measure of power) [25].

Changes in season-specific networks before and after the closure were evaluated using packages networkDynamic and tsna [53, 54]. Exponential random graph models were developed with the ergm package [55] to assess predictors of edge formation, measure metacouplings among nodes, and evaluate the optimality of post-closure (Summer 2020) as compared to pre-closure (Fall 2018) networks. Fishadelphia administrators consider Fall 2018 an appropriate reference period because seafood flows were large (largest of any season) and originated from multiple harvesters and processors. As such, seafood was readily available and accessible for customers in Fall 2018, and multiple suppliers were engaged in Fishadelphia, helping fulfill two important components of Fishadelphia’s mission. Models of network structure, namely the probability of network configurations as a function of parameters describing network properties, were generated using Markov Chain Monte Carlo maximum likelihood estimation. Parameters relevant for Fishadelphia, and used herein, included number of unidirectional edges and number of transitive ties, edges $I  j$ that also exhibit a two-step path from i to $j$ (e.g. harvester–distributor and harvester–processor–distributor).

Models also included ‘nodefactor’ parameters: node type (harvester or processor), subregion, and state. Metacouplings were modeled by distinguishing seafood flows within/between subregions and states using the ‘nodematch’ function. Parameters included nodematch.subregion and nodematch.state. Positive coefficients indicated that edge formation probability increased when nodes were from the same subregion (Type 1 interaction) or state (Type 2). Negative coefficients indicated that edges tended to form between nodes from different subregions in a state (Type 2 interaction) or different states (Type 3). Models were developed using information-theoretic model selection and Akaike’s information criterion (AIC). For individual seasons and the four-season pre-closure network, eight models representing multiple working hypotheses of network structure were compared via AIC [56, 57]. Full-model averaging was performed for models with $\Delta { \mathrm { A I C } } < 2$ [57].

Optimality has diverse dimensions that reflect Fishadelphia’s five objectives. For instance, optimality can be defined relative to seafood species diversity in the marketplace (maximizing purchasing options for customers), delivery efficiency (minimizing customers’ average distance traveled), and customer safety (social distancing during the pandemic). Optimality also pertains to customer satisfaction (maximizing customers’ ability to obtain desired seafood items from the Fishadelphia ‘club’ of their choice—fillet, whole fish, finfish-only) and flow consistency (minimizing variance in customers’ seafood purchases to increase stability of seafood flows and income). Using ‘what-if ’ scenario analysis, we evaluated these five dimensions of network optimality by comparing networks before and after the closure to determine if the post-closure network was more or less satisfactory relative to each dimension and all dimensions collectively. Customer satisfaction was quantified by developing an index of satisfaction reflecting customer purchasing profiles, with customers either receiving (1) or not receiving (0) their clubspecific seafood items in biweekly periods in Spring and Summer 2020. We assessed changes in satisfaction over time by creating violin plots and performing Cochran’s Q test to determine if there were significant differences in mean satisfaction among biweekly periods (pairwise comparisons using Wilcoxon’s sign test). An analogous procedure using one-way analysis of variance and Tukey’s HSD test was performed for seafood quantity purchased and dollars spent by customers.

# 3. Results

# 3.1. Pre-closure network

Seafood flows among Fishadelphia stakeholders encompassed 18 species (14 finfish, 4 shellfish) before the closure (figure 1). Across four pre-closure seasons, Harvester_1n sent 1929 lbs of seafood to Processor_1s

Table 2. Trends in degree and power centrality for nodes in the Fishadelphia network. Time periods include the entire four-season network before the pandemic (pre-closure) and individual seasons in 2018–2020. Seasons include fall (F), spring (S), and summer (Su); Summer 2020 is equivalent to post-closure. In node labels, lower-case letters denote subregion: northern (n), southern (s), inland (i). ‘Retailer $\_ s ^ { \ / }$ and ‘Retailer_P’ indicate school-based and porch-based retailer, respectively.   

<table><tr><td>Metric</td><td>Node</td><td>Pre-closure</td><td>F2018</td><td>S2019</td><td>F2019</td><td>S2020</td><td>Su2020</td></tr><tr><td rowspan="9">Degree</td><td>Harvester_1n</td><td>20</td><td>15</td><td>2</td><td>3</td><td>0</td><td>0</td></tr><tr><td>Harvester_2n</td><td>16</td><td>0</td><td>6</td><td>7</td><td>3</td><td>0</td></tr><tr><td>Harvester_3s</td><td>2</td><td>1</td><td>0</td><td>1</td><td>0</td><td>0</td></tr><tr><td>Harvester_4i</td><td>1</td><td>0</td><td>1</td><td>0</td><td>0</td><td>1</td></tr><tr><td>Processor_1s</td><td>34</td><td>9</td><td>8</td><td>11</td><td>6</td><td>1</td></tr><tr><td>Processor_2i</td><td>6</td><td>6</td><td>0</td><td>0</td><td>0</td><td>0</td></tr><tr><td>Distributor_1i</td><td>90</td><td>34</td><td>22</td><td>24</td><td>10</td><td>4</td></tr><tr><td>Retailer_Si</td><td>45</td><td>17</td><td>11</td><td>12</td><td>5</td><td>0</td></tr><tr><td>Retailer_Pi</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>2</td></tr><tr><td rowspan="9">Power centrality</td><td>Harvester_1n</td><td>2.06</td><td>2.42</td><td>0.92</td><td>1.21</td><td>0.00</td><td>0.00</td></tr><tr><td>Harvester_2n</td><td>1.93</td><td>0.00</td><td>2.13</td><td>2.05</td><td>1.83</td><td>0.00</td></tr><tr><td>Harvester_3s</td><td>0.03</td><td>0.06</td><td>0.00</td><td>0.09</td><td>0.00</td><td>0.00</td></tr><tr><td>Harvester_4i</td><td>0.01</td><td>0.00</td><td>0.15</td><td>0.00</td><td>0.00</td><td>1.28</td></tr><tr><td>Processor_1s</td><td>0.26</td><td>0.32</td><td>0.75</td><td>0.55</td><td>0.79</td><td>1.28</td></tr><tr><td>Processor_2i</td><td>0.04</td><td>0.19</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td></tr><tr><td>Distributor_1i</td><td>0.01</td><td>0.06</td><td>0.14</td><td>0.09</td><td>0.16</td><td>0.85</td></tr><tr><td>Retailer_Si</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td></tr><tr><td>Retailer_Pi</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td></tr></table>

(904 lbs), Processor_2i (523 lbs), and the distributor (502 lbs). Similarly, Harvester_2n sent 1533 lbs to Processor_1s (926 lbs) and the distributor (607 lbs; figure 1). Shellfish harvesters sent 957 lbs of oysters (Crassostrea virginica) to the distributor (541 lbs from Harvester_3s, 416 lbs from Harvester_4i). Degree was largest for the distributor because it both received and delivered seafood (table 2, figure 1). Power centrality was largest for Harvester_1n and Harvester_2n because these nodes frequently supplied seafood to non-supplier nodes (table 2), making them important components of Fishadelphia.

Pre-closure edges were most likely to form for unidirectional seafood flows involving fish processors or northern-subregion harvesters because these were the primary suppliers (table 3). The pre-closure network was driven by interstate seafood exchanges (Type 3 interactions), so edge formation probability declined when nodes in a pair were from the same subregion (Type 1) or the same state but different subregions (Type 2), or a node was from the inland subregion (table 3).

# 3.2. Post-closure network

Seafood flows among Fishadelphia stakeholders encompassed only two species (0 finfish, 2 shellfish) after the closure. Shellfish received by the distributor (1196 lbs) included oysters from Harvester_4i (666 lbs) and littleneck clams (Mercenaria mercenaria) from Processor_1s (530 lbs). Degree was largest for the distributor, and power centrality was largest for Harvester_4i and Processor_1s because they were the only suppliers in the network (table 2).

The post-closure network was more localized than the pre-closure network, so edges were most likely to form within subregions (Type 1 interactions)

rather than between subregions or states (table 3). Edge formation probability declined when a node was from the inland subregion, southern subregion, or the state of New Jersey (table 3).

# 3.3. Seasonal network changes before and after closure

Across seasons between Fall 2018 and Summer 2020, the number of nodes and edges decreased (table 4, figures 2(a)–(e)). This resulted from Fishadelphia’s administrative decision to close and then reopen on a trial basis with a small, local network, reflecting challenges imposed by COVID-19 (e.g. protecting customer and staff safety). Declines in harvesters and processors reduced species diversity, mean number of species per supplier, and mean degree (table 4). Total seafood flows from suppliers to customers decreased between Fall 2018 and Summer 2020, but mean lbs/supplier and associated flow variability increased as suppliers became less numerous (figure 3). Degree declined for most nodes over time, although the emergence of dispersed, socially distanced, porch-based retailers and the return of Harvester_4i as a shellfish supplier in Summer 2020 increased degree for these nodes (table 2). Power centrality decreased over time for most nodes as they became less connected (fewer edges) or left the network due to COVID-19 challenges (see above). However, power centrality increased for Harvester_4i, Processor_1s, and the distributor because these nodes persisted in Spring and Summer 2020 and accounted for relatively large proportions of total edges (table 2, figures 2(a)–(e)).

Network models varied across seasons, but edge formation probability was positively associated with unidirectional seafood flows in all seasons except

,  ( directional (U (wi), harvester (Harv), inland subregion (In), northern subregion (N), nodematch.state (NMst), nodematch.subregion (NMsub), processor (Proc), southern subregion (S), state of New Jersey (sjNJ), transitive ties (TTie), Table 3. Exponential random graph models and model-averaged estimators explaining Fishadelphia network structure in the pre-closure period (encompassing Fall 2018, Spring 2019, Fall 2019, and Spring 2020) and five seasons individually. Summer 2020 is equivalent to post-closure. Model averaging was performed for every season except Fall 2018, when no models were within two AIC units of the top model. Abbreviations are as follows: Akaike weight   

<table><tr><td>Model</td><td>wi</td><td>Harv</td><td>In</td><td>N</td><td>NMst</td><td>NMsub</td><td>Proc</td><td>S</td><td>stNJ</td><td>TTie</td><td>Uni</td></tr><tr><td colspan="12">Pre-closure (four seasons)</td></tr><tr><td>In + N + NMst + NMsub + Proc + Uni</td><td>0.36</td><td>—</td><td>-2.82</td><td>3.03</td><td>-5.97</td><td>-3.53</td><td>3.33</td><td>—</td><td>—</td><td>—</td><td>3.54</td></tr><tr><td>In + N + NMst + Proc + Uni</td><td>0.22</td><td>—</td><td>-2.36</td><td>2.22</td><td>-4.39</td><td>—</td><td>1.92</td><td>—</td><td>—</td><td>—</td><td>1.85</td></tr><tr><td>Model-averaged</td><td>—</td><td>—</td><td>-1.53</td><td>1.57</td><td>-3.10</td><td>-1.26</td><td>1.61</td><td>—</td><td>—</td><td>—</td><td>1.67</td></tr><tr><td colspan="12">Fall 2018</td></tr><tr><td>NMsub + S + Uni</td><td>N/A</td><td>—</td><td>—</td><td>—</td><td>—</td><td>-1.31</td><td>—</td><td>-2.37</td><td>—</td><td>—</td><td>1.12</td></tr><tr><td colspan="12">Spring 2019</td></tr><tr><td>Harv + Nmsub + Uni</td><td>0.39</td><td>-2.16</td><td>—</td><td>—</td><td>—</td><td>-0.14</td><td>—</td><td>—</td><td>—</td><td>—</td><td>1.42</td></tr><tr><td>Harv + N + NMst + Uni</td><td>0.23</td><td>-3.21</td><td>—</td><td>1.22</td><td>0.31</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>1.50</td></tr><tr><td>Model-averaged</td><td>—</td><td>-1.59</td><td>—</td><td>0.28</td><td>0.07</td><td>-0.06</td><td>—</td><td>—</td><td>—</td><td>—</td><td>0.90</td></tr><tr><td colspan="12">Fall 2019</td></tr><tr><td>Harv + Nmsub + Uni</td><td>0.40</td><td>-2.16</td><td>—</td><td>—</td><td>—</td><td>-1.35</td><td>—</td><td>—</td><td>—</td><td>—</td><td>1.57</td></tr><tr><td>Harv + NMst + Uni</td><td>0.29</td><td>-2.37</td><td>—</td><td>—</td><td>0.36</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>1.47</td></tr><tr><td>Model-averaged</td><td>—</td><td>-1.56</td><td>—</td><td>—</td><td>0.10</td><td>-0.54</td><td>—</td><td>—</td><td>—</td><td>—</td><td>1.06</td></tr><tr><td colspan="12">Spring 2020</td></tr><tr><td>In</td><td>0.20</td><td>—</td><td>-0.53</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>TTie</td><td>0.17</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>-0.49</td><td>—</td></tr><tr><td>Uni</td><td>0.16</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>0.71</td></tr><tr><td>Model-averaged</td><td>—</td><td>—</td><td>-0.10</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>-0.08</td><td>0.12</td></tr><tr><td colspan="12">Summer 2020 (post-closure)</td></tr><tr><td>S</td><td>0.22</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td><td>-1.61</td><td>—</td><td>—</td><td>—</td></tr><tr><td>NMsub + stNJ</td><td>0.18</td><td>—</td><td>—</td><td>—</td><td>—</td><td>0.15</td><td>—</td><td>—</td><td>-1.35</td><td>—</td><td>—</td></tr><tr><td>In + Nmsub</td><td>0.11</td><td>—</td><td>-1.60</td><td>—</td><td>—</td><td>2.53</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr><tr><td>Model-averaged</td><td>—</td><td>—</td><td>-0.18</td><td>—</td><td>—</td><td>0.31</td><td>—</td><td>-0.35</td><td>-0.24</td><td>—</td><td>—</td></tr></table>

Table 4. Comparison of Fishadelphia network attributes between the pre-closure reference season used for optimality assessment (Fall 2018) and the post-closure comparison season (Summer 2020). ‘Supplier’ refers to seafood harvesters and processors. Mean degree is the mean number of direct connections per node.   

<table><tr><td>Attribute</td><td>Fall 2018</td><td>Summer 2020</td></tr><tr><td>Nodes</td><td>6</td><td>4</td></tr><tr><td>Harvesters</td><td>2</td><td>1</td></tr><tr><td>Processors</td><td>2</td><td>1</td></tr><tr><td>Edges</td><td>41</td><td>4</td></tr><tr><td>Species</td><td>12</td><td>2</td></tr><tr><td>Mean species/supplier</td><td>4</td><td>1</td></tr><tr><td>Mean degree</td><td>13.67</td><td>2.00</td></tr></table>

![](images/a676430a2a0a1ecd9d7543dfa4034eec930edf69e4c3f051e181625881358bb1.jpg)

![](images/5392e3f7dc1b3cbf13f04c8931754ac16a6383e4f38a66d970de9a82d16ab55b.jpg)

![](images/dcb8e7c541f1c443f831c381dbc9f750c9a1a23ef4b304f1d832303afa555a1b.jpg)

![](images/39c42c18ff246010f793bdb79a5f09511721fa297e9e5cfa56f71513e7ed659a.jpg)

![](images/271fbaade5f550d6075be86f37f5bf24019634bdf2b80a35c51e8130d46e8307.jpg)  
Figure 2. (a)–(e) Changes in the Fishadelphia network from Fall 2018 to Summer 2020. Arrows are seafood flows; width is proportional to seafood weight (lbs) and color indicates species (scientific names in figure 1 caption). Nodes labels denote type and location (northern (n), southern (s), and inland (i) subregions).

Summer 2020 (table 3). Pre-closure networks were driven by interstate seafood distribution, so edges were most likely to form between nodes from different subregions (Type 2/3 interactions). The postclosure network was more localized; edges were most likely to form within rather than between subregions (Type 1 interactions; table 3).

# 3.4. Biweekly network changes before and after closure

COVID-19 had abrupt effects on Fishadelphia across biweekly periods. Before the closure, there were declines in the number of nodes (4–0), edges (5–0), and seafood species (1–0; figures 4(a)–(e), supplemental figures 1 and 2 (available online at

![](images/cc9ac61c5cb783c972045d9c4f7162fd29472407a93f3646d9f2446b95491395.jpg)  
Figure 3. Total seafood flows (lbs, solid line) and mean seafood flows (lbs per supplier, dotted line) in the Fishadelphia network across seasons. Error bars represent $\pm 1$ standard error of the mean.

stacks.iop.org/ERL/16/034054/mmedia)). However, seafood flows grew as Fishadelphia administrators increased seafood purchasing between late January (120 lbs) and early March (544 lbs), with each pre-closure period featuring a different species (figures 4(a)–(d)) to meet growing customer demand. With increasing pre-closure seafood availability and potential uncertainty that it would remain available amid the pandemic, the number of school-based customers more than doubled between late January (55) and early February (114) and increased from late February (97) to early March (128; figures 5(a)–(e)).

After the closure, there were increases in the number of nodes (0–3) and edges (0–2) (figures 4(e)–(g), supplemental figures 1 and 2). Seafood flows decreased from mid-June (666 lbs) to early July (530 lbs), with each period featuring a different species (figures 4(f) and (g)). The number of porchbased, socially distanced customers increased from 130 in mid-June (13 porches) to 141 in early July (14 porches; figures 6(a) and (b)).

# 3.5. Network optimality assessment

Across Fishadelphia clubs and in the fillet and wholefish clubs individually, customer satisfaction with seafood distribution stayed constant or increased after the closure relative to before (supplemental figures 3(a)–(c)); network rewiring via porch-based delivery thus increased resilience from the perspective of most consumers. In contrast, finfish-only customer satisfaction was greater before the closure (supplemental figure 3(d)) and rewiring did not maintain resilience, as finfish were unavailable post-closure due to a Fishadelphia administrative decision to

reopen with shellfish (i.e. locally available, minimal COVID-19 risk, low packaging costs). After the closure, customers acquired more seafood (supplemental figures 4(a)–(d)) and spent more money on seafood (supplemental figures 5(a)–(d)) across all clubs and in each club individually, although average customer expenditures were largest in early February when fluke, a relatively expensive fish, was the only species offered. Purchase quantities and expenditures tended to be more variable after the closure (supplemental figures 4(a)–(d) and 5(a)–(d)), reducing the consistency of Fishadelphia’s seafood flows and associated income. In summary, network rewiring via porch-based seafood distribution strengthened network resilience by increasing delivery efficiency, customer safety, and customer satisfaction. Hence, compared to the pre-closure network, the post-closure network was closer to optimal overall despite being farther from optimal in two dimensions (species diversity, flow consistency).

# 4. Discussion

Our research illustrates the utility of metacouplingbased network analysis for understanding and modeling seafood flows, evaluating pandemic-induced network changes, and developing strategies to rewire and manage CSFs amid disturbances. Before the closure, Fishadelphia had a seafood supply chain with tightly, frequently connected nodes, reflecting the program’s emphasis on cultivating human relationships among network actors [14]. Degree and power centrality were substantially larger for finfish harvesters than shellfish harvesters due to the predominance of

![](images/01cdf7e0eab19a63fcb0fde7ce8655430910f32b7344dc4de62ab184696a00bb.jpg)  
Figure 4. (a)–(g) Biweekly changes in the Fishadelphia network from late January to early July 2020. Arrows are seafood flows; width is proportional to seafood weight (lbs) and color indicates species (scientific names in figure 1 caption). Nodes labels denote type and location (northern (n), southern (s), and inland (i) subregions).

finfish-buying customers. However, a local shellfish harvester (4i) was the primary seafood supplier after Fishadelphia reopened in mid-June 2020, reflecting administrators’ decision to maintain a small, localized network amid uncertainties of the pandemic. Interestingly, some finfish-only customers $n = 2 1$ , $1 2 \%$ of total customers) were flexible in purchasing shellfish post-closure, indicating the importance of rewiring Fishadelphia to include at least one shellfish harvester to accommodate customers’ elastic seafood tastes and safeguard against future perturbations that reduce finfish availability (e.g. pandemics, fishery collapses, natural disasters).

Likewise, Processor_1s, a highly connected finfish processor and shellfish aggregator/seller that promoted functional diversity and resilience in Fishadelphia, is important to include in the future network, even alongside other processors. Indeed, network redundancy (table 1) can build resilience by providing independent pathways for delivering seafood via alternative nodes and edges if primary options fail [21]. Resilience depends on the capacity of redundant nodes, whether created after a disturbance or present before it, to both sustain preexisting edges and support flows equivalent to those pre-disturbance. If they cannot, redundancy

![](images/d38a6b4bca3b590381af0035c2e2948157a89c1249b461e517ea7b7e5bd3054f.jpg)  
A Late January 2020

![](images/0987d337d892bc1a10c19bcc8e4da81545b0868031487383017725e205dab260.jpg)  
B Early February 2020

![](images/0ca3c7b605c94d36e58e2077636167d0b7bd426f8b1a8ca06c15a2284eb2ad9b.jpg)  
C Late February 2020

![](images/8cc013acfd57305f8885afb7759d2f9e6270aedef0b45d9a8305dcf28cc8de4b.jpg)  
D Early March 2020   
E Closure

![](images/87af68fc2ecffac24e9980aa2d5a56557b634554d0fc6612d8536770f03a3726.jpg)  
Figure 5. (a)–(e) Pre-closure customer networks at schools across biweekly periods from late January to mid-March 2020. Nodes are colored by customer ‘club’ (fillets, whole fish, finfish only (no shellfish)), and arrow width is proportional to seafood weight (lbs).

![](images/86b9abb7d3d47d2820c8b5a92af2e2f6d9eb8d0d3f5b00b42fef52057c5ab36d.jpg)  
A Mid-June 2020   
Figure 6. (a), (b) Post-closure customer networks across porches in mid-June and early July 2020. Nodes are colored by customer ‘club’—orange (fillets), blue (whole fish), purple (finfish only, no shellfish)—and arrow width is proportional to seafood weight (lbs). Abbreviations are locations of coolers in the porch pick-up program: Bella Vista (BEV), Central South Philadelphia (CSP), East Passyunk (EPA), Elkins Park (ELK), Francisville (FVL), Gayborhood (GBH), Mount Airy (MTA), Northeast (NEA), North Kensington (NKE), North Philadelphia (NPH), Overbrook (OBR), Southeast Asian Mutual Assistance Associations Coalition (SAM), West Kensington (WKE), West Philadelphia—Baltimore Avenue (WPB).

will not increase resilience [22]. Fishadelphia nodes and edges that were present, but infrequently used, before the closure (Harvester_3s, Harvester_4i, Processor_2i) are capable of accommodating seafood flows characteristic of primary nodes and edges

(Harvester_1n, Harvester_2n, Processor_1s). Hence, incorporating Harvester_3s, Harvester_4i, and Processor_2i into the future post-pandemic Fishadelphia network will increase supply-side resilience, much like porch-based seafood delivery accommodated

larger flows than the school-based system and increased demand-side resilience. Moreover, network resilience could be enhanced by enlarging existing seafood flows and contracting with new harvesters and processors—particularly those that supply diverse finfish species (generalists) and fewer shellfish species (specialists)—to increase network redundancy, total flows, and seafood options for customers. Diversifying networks by adding generalists and specialists increases resilience [58], setting the stage for further study to determine the best numerical balance and spatial (i.e. metacoupling) arrangement of finfish and shellfish suppliers for achieving Fishadelphia’s five objectives. Currently, Fishadelphia administrators are increasing the number of seafood harvesters and processors and thereby amplifying redundancy and resilience while recognizing that logistical and financial realities place limits on network rewiring, and differences in company operating schedules and uncertainties like poor weather (which favors shellfish harvest) are inevitable [14].

Comparing networks across seasons and biweekly periods revealed COVID-induced network changes, including declines in supply-side nodes, edges, seafood species diversity, and associated network redundancy and resilience. This pattern reflects broader regional and national declines in seafood purchases by large-scale buyers (e.g. restaurants, wholesalers) as a result of pandemic-induced closures and supply-chain alterations [59–61]. Some harvesters responded by selling seafood directly to customers via ‘pop-up’ markets, much like Fishadelphia increased sales diversity through dispersed, porchbased seafood delivery. Although Fishadelphia has continued to generate income for harvesters and processors, larger-scale effects of the pandemic on the fishing industry remain to be seen. It should be noted that Fishadelphia’s supply-side nodes receive income from other buyers (e.g. scallopers, gillnetters, otter trawlers, longliners), which partially insulated them from pandemic-induced edge removal in their own networks. Indeed, Fishadelphia’s 3 month closure did not stem from supply-side resource limitations; it was intended to protect staff and customers from potential COVID-19 transmission via congregated, school-based seafood distribution.

Although it was intended to protect human health, porch-based seafood delivery also enlarged Fishadelphia’s customer base and made it easier for customers to obtain seafood by decreasing average distance traveled. Most customers $( 9 1 \% )$ visited a porch near their residence that was closest to the school where they received their seafood preclosure. Because customers favor traveling shorter distances, a porch-based distribution system was more satisfactory than a school-based system from a customer perspective, an important insight for designing city-based food programs in an urbanizing world. While continuing porch-based seafood

delivery, Fishadelphia administrators should also rewire the post-closure network to increase species diversity and flow consistency, which is important for ensuring a stable, reliable income stream. For instance, Fishadelphia administrators could contract with more finfish and shellfish suppliers to increase network redundancy, enlarge seafood flows, provide more seafood options, and thereby increase customer satisfaction and purchasing consistency. In addition, Fishadelphia administrators could train program staff to perform multiple tasks (e.g. customer engagement, seafood distribution)—a form of internal, within-node redundancy—to ensure that customers are satisfied, seafood purchasing is reliable, distribution is efficient and convenient, and Fishadelphia’s community-oriented leadership and human relationships are sustained [14, 62].

COVID-induced network changes have potential implications for food supply, food security, and human relationships in Fishadelphia. For instance, after mid-March 2020, customers did not receive seafood during the 3 month closure. At some level, this break may have affected food supply or food security, particularly for customers that were unable to obtain seafood elsewhere. Although Fishadelphia lost a few customers and associated income due to the pandemic, it experienced a net increase in buyers and income post-closure, perhaps because of interest in low-contact, socially distanced seafood distribution and local, readily available shellfish. However, COVID-19 has decreased income for harvesters and processors due to reduced purchasing by large-scale restaurants and wholesalers while affecting human relationships in Fishadelphia. For instance, Fishadelphia’s student retailers have lost valuable opportunities to learn leadership and business management skills through in-person interactions with seafood customers at schools. In addition, network resilience stemming from human relationships declined when Fishadelphia’s annual fishing dock trip—whereby customers, students, and employees meet with harvesters to learn about their operations and develop an appreciation for the fisheries supply chain—was cancelled due to the pandemic.

Across-season declines in the number and geographic range of supply-side nodes (particularly finfish harvesters), edges, and seafood species were reflected in network models, which were valuable tools for understanding metacouplings. Whereas models for Fall 2018 and Spring and Fall 2019—seasons with comparatively complex networks—included node-function, subregion, and metacoupling parameters, the Spring 2020 model only incorporated unidirectional and transitive (i.e. harvester–distributor and harvester–processor– distributor) flows. The Summer 2020 model was unique because it included a positive, rather than negative, coefficient for the nodematch.subregion parameter, indicating the importance of local, Type 1

shellfish flows in the post-closure network as opposed to Type 2/3 finfish flows in the pre-closure network. After the closure, the predominance of Type 1 shellfish flows reflected administrators’ decision to reopen Fishadelphia using a small, localized network to minimize employee travel, COVID-19 risk, and seafood packaging costs (all higher for finfish) while fulfilling customers’ desire for local seafood.

# 5. Conclusions

Despite the localized, linear, species-limited nature of supply-side seafood flows after the closure, demandside seafood distribution was more diversified and dispersed through the porch delivery program, which increased the number of customers and augmented network redundancy and resilience while minimizing COVID-19 transmission. These findings reinforce the notion that network optimality is multifaceted in Fishadelphia. Overall, our observations and models suggest that an effective strategy for restarting CSFs, and perhaps other alternative food distribution systems, after disturbance-induced closures is to stay local and small while maintaining connections with key suppliers—local and non-local—and diversifying and dispersing food delivery. Although staying local and small may be necessary, it could also be risky (e.g. suppliers could drop out, customer demands could be inelastic). If Type 2/3 seafood flows and the species diversity and resilience they provide are not engaged at the outset, the aforementioned risks could be reduced by increasing the number of local finfish and shellfish suppliers. Importantly, our findings provide an alternative view to recent calls for food localism amid supply-chain disruptions caused by COVID-19 [63]. Although laudable in its intent, localism is unlikely to sustain food networks when local suppliers drop out, buyers demand products that are unavailable locally, or buyers cannot afford to pay premium prices for local food. Moreover, inelastic demand by dissatisfied customers could potentially destabilize food networks lacking redundancy. Rather than localism, our results suggest that resilient food systems stem from spatially mixed networks that are rooted in local suppliers and buttressed by local redundancy and non-local connectivity to provide resilience amid disturbances [64].

Fishadelphia’s network resilience is regulated by metacouplings that change seasonally, offering insights for post-closure and post-pandemic network rewiring. Whereas Types 2 and 3 seafood flows fostered species diversity and flow consistency before the closure, Type 1 flows promoted customer safety, delivery efficiency, and customer satisfaction afterwards. Collectively, these results indicate the importance of rewiring Fishadelphia to include multiple finfish and shellfish suppliers across Types 1–3 scales. Building redundancy into the supply-side network

would allow Fishadelphia administrators to maximize demand-side customer satisfaction by ensuring consistent flows of seafood distributed through safe, efficient porch-based delivery. In addition, expanding Type 1 finfish and shellfish flows would increase local product diversity and customer satisfaction while engaging socioculturally diverse customers in their communities, thereby supporting Fishadelphia’s mission. Overall, it is informative to conceptualize and critical to manage Fishadelphia’s supply-chain operations and customer engagement activities through a metacoupling lens to effectively serve multiple stakeholders in different places. Due to a stark difference in the level of control that Fishadelphia administrators have over seafood distribution (high) versus supply (low), it is important to sustain relationships with harvesters and processors, and build supply-side redundancy and resilience into the network, to protect against future disturbances (e.g. pandemics, fishery collapses, natural disasters).

How can a Fishadelphia case study advance understanding of broader resilience practices around the world, within and beyond fisheries? As with any case study, there are important contextual issues which help define the example at hand. CSFs are primarily located in the United States and Canada [13, 36], so our research naturally occurred in a North American context, and our data were specific to the mid-coastal United States. Although our goal to evaluate how COVID-19 affected the Fishadelphia network could only be addressed at this spatial scale, our methods and findings are applicable to CSFs in other parts of North America and fisheries throughout the world [30]. For instance, metacoupling-based network analysis is a systematic, organized method for assessing the systems, flows, agents, causes, and effects underlying multiscalar human–nature interactions in fisheries, a crucial step in filling knowledge gaps created by historical consideration of either human or natural dynamics within individual fisheries [31]. Moreover, metacoupling-based network analysis has notable flexibility (i.e. understanding human–nature interactions in different fisheries) and applicability (i.e. translating research into policy and management approaches), rendering it a useful tool for fisheries science and practice. Ultimately, fisheries managers can use metacoupling-based network analysis to design adaptive, resilient approaches for rewiring fisheries networks in a socioeconomically, environmentally sustainable manner.

Our research illustrates lessons for developed countries and those lacking the infrastructural resources of the United States. The first lesson is that networks, by definition, are dynamic systems. That is, individuals and organizations need not accept a specific network structure as a given because network analysis accommodates wide-ranging topologies. Moreover, networks bridge the boundary

between structural and actor-based explanations; actors can modify edges and add or delete nodes and thereby alter network structure. This interplay between network structure and actors—and the ability of network analysis to capture it—is broadly applicable within and beyond CSFs in the mid-coastal United States.

Second, all efforts to create more resilient networks must identify central players in the old and new configurations. The willingness of network actors to adapt will play a major role in determining network resilience. Third, redundancy is broadly relevant. Although redundancy may be expensive in actual or opportunity costs, it is a critical resource for adaptation. Building redundancy is not simply generating alternative ways to distribute products, but also ensuring that network actors become more ‘generalized’ in their products and open to new approaches for increasing resilience, which may involve expanding or contracting local, adjacent, or distant human– nature interactions.

Finally, change is constant in the twenty-first century; all efforts to create more resilient networks must prepare for it. COVID-19 represented an existential threat to Fishadelphia, but administrators rearranged the demand-side network to cope with dramatic pandemic-induced changes. The importance of adaptability applies not only to Fishadelphia but to all networks, wherein producers, distributors, retailers, and customers must be flexible amid unpredictable changes and challenges of the modern era (e.g. health crises, fishery collapses, natural disasters, political unrest).

Our research adds to a growing metacoupling literature establishing the prevalence of multiscalar human–nature interactions in marine and freshwater fisheries across sectors (e.g. commercial, artisanal, subsistence, recreational) [19, 20, 31, 33, 34]. Although causes and effects of metacouplings vary widely among fisheries systems, flows, actors, and multiscalarity (i.e. occurrence of local– regional–global interactions) are often similar [33]. As CSFs grow in number, structural uniqueness, and stakeholder diversity [12, 36], we show how metacoupling-based network analysis is a useful, systematic approach for understanding these emerging food supply chains and promoting robust CSF management amid ordinary logistical and financial challenges [37] and extraordinary circumstances created by public health emergencies and other crises. Network analysis also has broader relevance for addressing metacouplings in terrestrial agriculture, fisheries and wildlife management, disease ecology, international trade, and other fields [16, 43, 44, 65, 66]. Although network analysis has not been widely employed through a metacoupling lens, our research demonstrates the utility of this technique for understanding network complexity and operationalizing the metacoupling framework.

These insights are critical in a world where multiscalar human–nature interactions in fisheries are undeniable but underappreciated for their prevalence, complexity, and policy relevance from boat to bowl.

