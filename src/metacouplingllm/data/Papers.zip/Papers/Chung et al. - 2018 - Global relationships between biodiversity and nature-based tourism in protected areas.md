# Global relationships between biodiversity and nature-based tourism in protected areas

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:37:29.489221+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Chung et al. - 2018 - Global relationships between biodiversity and nature-based tourism in protected areas.pdf
- Year: unknown
- DOI: 10.1016/j.ecoser.2018.09.004
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This article investigates how biodiversity and nature-based tourism are related in terrestrial protected areas worldwide, and how management strategies and surrounding social-ecological conditions shape this relationship. The study is explicitly framed within coupled human and natural systems and telecoupling, emphasizing that visitors and other pressures often originate far from the protected areas themselves.

Using a global dataset of 929 nationally designated terrestrial protected areas in 50 countries, the authors compile average annual visitor numbers (2000-2014) and combine these with spatial data on species richness (birds, mammals, amphibians), IUCN management category, biophysical attributes (area, elevation, climate, remoteness, age), and characteristics of 10-km buffer zones (population density, agricultural yield and area, and water-related ecosystem services). They apply log-log multiple regression in a STIRPAT-type framework, use information-theoretic model selection and averaging, and test robustness of coefficients.

Biodiversity is strongly and positively associated with visitation: richer species assemblages correspond to higher visitor numbers, net of other factors. Protected areas managed primarily for biodiversity (IUCN II-IV) both contain more species and receive substantially more visitors than those managed for mixed use (V-VI). Larger, older, more elevated, cooler, and less rainy parks attract more tourists, while remoteness from cities reduces visitation. High national income and dense surrounding populations also correlate with greater visitor numbers. In contrast, agricultural intensity and agricultural land share in buffer zones, as well as upstream water-supply contributions from protected lands, do not show clear direct or indirect effects on visitation through biodiversity.

The paper is directly relevant to telecoupling and metacoupling. It highlights that nature-based tourism in protected areas is largely driven by distant demand, with cross-scale socioeconomic and ecological linkages connecting urban and international visitor origins, protected area biodiversity, and surrounding land uses. The authors argue that conservation strategies that prioritize biodiversity can simultaneously support tourism-based economic opportunities, but outcomes depend on broader telecoupled flows of tourists, capital, and environmental impacts.

## Structured Metacoupling Extraction

### Coupling Classification
- Telecoupling between distant tourists and protected areas worldwide

### Intracoupling
#### Systems
- Individual protected areas as coupled human and natural systems
#### Flows
- Onsite tourism experiences and recreation inside protected areas
#### Agents
- Park agencies managing biodiversity and visitor use
#### Causes
- Biodiversity conservation strategies within protected areas
#### Effects
- Local economic benefits from tourism businesses near parks

### Pericoupling
#### Systems
- Protected areas and their 10 km buffer zones
#### Flows
- Spillover of tourism demand into nearby communities
#### Agents
- Local residents and farmers surrounding protected areas
#### Causes
- Population density and agriculture growth around protected areas
#### Effects
- Agricultural pressure and land use change near park boundaries

### Telecoupling
#### Systems
- Protected areas as sending systems providing tourism services
- Domestic and international tourist origins as receiving systems
#### Flows
- Visitor travel from distant cities and countries to parks
- Financial flows from tourist spending into destination economies
#### Agents
- Tourists choosing destinations based on biodiversity
- National governments setting park management categories
#### Causes
- Rising incomes increasing global nature-based tourism demand
- International conservation networks promoting protected areas
#### Effects
- Greater visitation where biodiversity and strict protection are higher
- Infrastructure development potentially impacting biodiversity and ecosystems

### Cross-Coupling Interactions
- Telecoupled tourism demand interacts with buffer-zone population growth
- Park management simultaneously alters local biodiversity and global tourism appeal

### Research Gaps or Limitations
- Cross-sectional data limits causal inference about tourism biodiversity feedbacks
- Coarse global biodiversity and visitation data hinder fine-scale analysis

### Search Keywords
- telecoupling protected areas tourism biodiversity
- nature-based tourism buffer zones global analysis

### Extraction Confidence
high
