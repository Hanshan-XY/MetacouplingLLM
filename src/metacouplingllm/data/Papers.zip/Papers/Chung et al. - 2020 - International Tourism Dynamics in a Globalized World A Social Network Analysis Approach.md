# International Tourism Dynamics in a Globalized World A Social Network Analysis Approach

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:37:43.717111+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Chung et al. - 2020 - International Tourism Dynamics in a Globalized World A Social Network Analysis Approach.pdf
- Year: unknown
- DOI: 10.1177/0047287519844834
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This article examines how international tourism flows have evolved as a global network and what forces shape those dynamics, using the metacoupling lens of interactions among distant sending and receiving systems.

The study covers bilateral tourist arrivals among 124 countries worldwide from 2000 to 2013, based on UNWTO statistics (tourists only, not same-day visitors). The authors treat countries as nodes and tourist flows as directed links. They combine two main methods: (1) cluster analysis of the global tourism network (Kliquefinder, k-core decomposition) to detect groups of countries that exchange tourists more intensely with each other, and (2) a longitudinal mixed-effects social network model framed as a gravity model. Explanatory variables include visa policy, shared language, geographic distance or direct flights, relative price levels, GDP per capita, population, political stability, protected area extent, and cultural World Heritage area.

Network clustering shows that the initially fragmented global tourism system, with multiple geographically oriented clusters, became progressively more consolidated. By 2011-2013 almost all countries formed a single large cluster dominated by high-income states, with growing participation by emerging economies such as China and Russia.

The mixed-effects model indicates that transaction cost proxies - visa-free access, common language, shorter distance or more direct flights - systematically enhance tourist flows. Higher GDP per capita and larger populations in both origin and destination countries also increase flows and become more influential over time. Relative cost-of-living differences matter in the early 2000s but their importance diminishes after about 2010. Political instability and terrorism risks show limited and inconsistent effects, suggesting a degree of resilience in international tourism, especially in high-income destinations. In contrast, the total or proportional areas of protected lands and cultural World Heritage sites do not significantly predict cross-border arrivals at the global scale.

The paper explicitly engages metacoupling/telecoupling by interpreting tourism as a service flow linking distant human-environment systems and by emphasizing how economic growth, policy choices, and network structure jointly shape these cross-border interactions.

## Structured Metacoupling Extraction

### Coupling Classification
- Study analyzes global telecoupling via international tourist flows among 124 countries, 2000-2013.

### Intracoupling
#### Systems
- Individual countries as coupled human-environment systems with tourism sectors and destinations.
#### Flows
- Domestic tourism and internal redistribution of tourism revenues and infrastructure investment.
#### Agents
- National governments managing tourism, conservation agencies, domestic tourism businesses.
#### Causes
- National income growth, population growth, internal conservation and tourism development policies.
#### Effects
- National employment and GDP from tourism, pressures on local resources and protected areas.

### Pericoupling
#### Systems
- Geographically neighboring countries within same regional tourism cluster.
#### Flows
- Cross-border tourist trips between nearby countries, including visa-free regional travel.
#### Agents
- Regional organizations, immigration authorities, airlines and transport operators.
#### Causes
- Low travel distance, shared language, regional visa arrangements and cultural similarity.
#### Effects
- Regional economic interdependence, shared exposure to crises, spatially clustered tourism impacts.

### Telecoupling
#### Systems
- Distant sending countries supplying outbound tourists.
- Distant receiving countries hosting international arrivals.
- Global tourism network as higher-level metacoupled system.
#### Flows
- International tourist movements quantified as bilateral arrival numbers.
- Associated monetary expenditures and trade in tourism services.
- Information flows via marketing, image, and risk perception.
#### Agents
- International tourists as mobile consumers of cultural ecosystem services.
- National tourism boards, visa and border control agencies.
- Airlines and global travel industry intermediaries.
#### Causes
- Income and population growth in origin countries increasing outbound demand.
- Transaction cost factors: distance, shared language, visa policies, flight connections, prices.
- Political stability and perceived security in destinations.
#### Effects
- Consolidation of global tourism into few highly connected country clusters.
- Large energy, water, land use, food consumption and CO2 emissions from tourism.
- Shifting influence of prices versus income on global tourism patterns over time.

### Cross-Coupling Interactions
- Regional crises or disasters fragment previously consolidated global tourism networks geographically.
- Economic growth in emerging economies amplifies both regional and long-distance tourist flows.
- Destination conservation policies interact with global demand but show weak aggregate arrival effects.

### Research Gaps or Limitations
- Lack of global time-series data for visa and flight variables forced them to be treated as constant.
- Model cannot rigorously attribute structural network changes to specific global crisis events.
- Some countries poorly fitted, suggesting omitted local or regional tourism determinants.

### Search Keywords
- international tourism network metacoupling telecoupling
- social network analysis gravity model tourist flows
- visa policy distance language GDP population political stability

### Extraction Confidence
high
