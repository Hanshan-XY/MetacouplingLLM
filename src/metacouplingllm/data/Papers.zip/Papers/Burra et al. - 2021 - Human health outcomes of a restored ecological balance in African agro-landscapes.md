# Human health outcomes of a restored ecological balance in African agro-landscapes

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:30:05.099604+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Burra et al. - 2021 - Human health outcomes of a restored ecological balance in African agro-landscapes.pdf
- Year: unknown
- DOI: 10.1016/j.scitotenv.2021.145872
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines how restoring ecological balance in smallholder farming systems affected human health and demographics across cassava-growing regions of sub-Saharan Africa. The focus is on the invasion of cassava mealybug (Phenacoccus manihoti) in the 1970s and its subsequent biological control by the parasitoid wasp Anagyrus lopezi, released from 1981 onward.

Geographically, the analysis covers 18 early-invaded countries in West, Central, and parts of Southern Africa that depended heavily on cassava as a staple food. The system context is rainfed agro-landscapes where many rural and urban people relied on cassava for a substantial share of daily calories.

The authors combine historical invasion and control records, FAO country statistics on cassava yield and production, and World Bank demographic data. They define three phases for each country: pre-invasion baseline, post-invasion period prior to parasitoid establishment, and a post-introduction recovery phase. Time-series and breakpoint analyses assess regional trends, while generalized additive models (GAMLSS) evaluate how changes in cassava yield and the presence of biotic stressors relate to shifts in birth rate and rate of natural increase.

Following mealybug invasion, cassava yields and total production dropped markedly on average, with some countries suffering extreme losses. During this phase, birth rates, fertility, and population growth slowed, while adult mortality rose. The authors estimate several million fewer births cumulatively in the affected countries over roughly a decade. After A. lopezi became established and biological control suppressed the pest, cassava yields and production rebounded substantially, coinciding with reduced infant and adult mortality, increased life expectancy, and partial recovery of birth rates.

The paper is not framed explicitly as telecoupling or metacoupling, but it is relevant: a globally transported invasive species and an internationally sourced natural enemy link distant regions ecologically and socioeconomically. The work illustrates how cross-border species movements and ecological interventions propagate through food systems to shape human health outcomes at continental scale.

## Structured Metacoupling Extraction

### Coupling Classification
- Telecoupling of Neotropical pest and South American parasitoid with African cassava systems and health
- Intracoupling within African cassava landscapes linking biodiversity, yield, and human demography

### Intracoupling
#### Systems
- Cassava-based smallholder agro-landscapes in 18 sub-Saharan African countries
- Rural and urban food and health systems dependent on cassava
- National demographic and public health systems in invaded countries
#### Flows
- Local spread of cassava mealybug among fields and villages
- Biocontrol parasitoid dispersal across national cassava areas
- Information and agronomic practices about biological control implementation
#### Agents
- Smallholder farmers and farm families relying on cassava
- National agricultural and plant protection services
- Biological control and agricultural researchers
#### Causes
- Biodiversity loss and weakened natural pest control in agroecosystems
- Invasion and proliferation of cassava mealybug in African cassava belt
- Deliberate release of specialist parasitoid to restore ecological balance
#### Effects
- Large cassava yield reductions and aggregate production losses
- Declines in birth rate, fertility, natural population increase
- Increased adult mortality, then improved survival after yield recovery

### Pericoupling
#### Systems
- Neighboring African countries within contiguous cassava growing regions
- Savanna and non-savanna cassava production zones
- Border regions where pest and parasitoid spread between states
#### Flows
- Regional dispersal of mealybug across adjacent countries
- Cross-border movement of cassava planting material carrying pests
- Regional coordination of parasitoid releases and monitoring
#### Agents
- Regional plant protection organizations in Africa
- Cross-border traders of cassava cuttings and roots
- International research centers working with regional partners
#### Causes
- Connected cassava landscapes facilitating pest spread among neighbors
- Shared climatic conditions enabling regional invasion fronts
- Coordinated biological control campaigns across multiple states
#### Effects
- Synchronized regional yield shocks and recoveries
- Parallel shifts in demographic indicators across neighboring countries
- Heterogeneous impacts depending on cassava share in savannas

### Telecoupling
#### Systems
- Neotropical region harboring native cassava mealybug and parasitoid
- Sub-Saharan African cassava-dependent food systems
- Global trade and policy systems influencing species movement
#### Flows
- Unintentional transcontinental introduction of cassava mealybug to Africa
- Intentional transfer of parasitoid Anagyrus lopezi from South America
- Knowledge, funding, and technology for biological control programs
#### Agents
- International biological control experts and research institutes
- Global trade actors facilitating initial pest movement
- Donor agencies supporting cross-continental control efforts
#### Causes
- Global trade in agricultural commodities enabling invasive species
- Recognition of severe economic and food security damage from mealybug
- Adoption of nature-based solutions aligned with sustainability goals
#### Effects
- Continental-scale cassava yield collapse affecting millions of consumers
- Economic benefits and health improvements from restored yields
- Contribution to Sustainable Development Goals via ecosystem-based control

### Cross-Coupling Interactions
- Telecoupled biocontrol introduction reshapes intracoupled farmer livelihoods and health outcomes
- Regional pest spread mediates how global invasions manifest in local demography
- Ecosystem service restoration links ecological telecoupling to social welfare gains

### Research Gaps or Limitations
- Coarse national statistics likely underestimate yield and health impacts
- Conflict, data gaps, and omitted countries cause conservative continental estimates
- Other stressors like drought, conflict, and co-invading pests confound attribution

### Search Keywords
- cassava mealybug biological control Africa demographics
- telecoupling invasive species human health cassava
- Anagyrus lopezi ecosystem services food security

### Extraction Confidence
high
