# Australia-Japan telecoupling of wind power-based green ammonia for passenger transportation Efficie

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:56:39.147382+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Lu et al. - 2022 - Australia-Japan telecoupling of wind power-based green ammonia for passenger transportation Efficie.pdf
- Year: unknown
- DOI: 10.1016/j.rser.2022.112884
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper analyzes a prospective Australia-Japan supply chain in which wind power in Australia is used to produce green ammonia that is exported to Japan for passenger transport, and evaluates it as a telecoupled energy system.

The geographic focus is the Australia-Japan corridor. The system context contrasts four well-to-wheel scenarios for 1 km of passenger transport by electric vehicles (EVs) or hydrogen fuel cell vehicles (FCVs) in Japan: coal-based electricity to EVs, natural-gas-based electricity to EVs, wind-based green ammonia converted to electricity (via SOFC) for EVs, and wind-based green ammonia cracked to hydrogen (via PEMFC) for FCVs. The authors explicitly structure each option into three telecoupling subsystems: Australia as the sending system (energy production), international shipping as the spillover system, and Japan as the receiving system (conversion and vehicle use).

Methodologically, the study develops an integrated life cycle assessment-emergy evaluation (LCA-EME) framework. Life cycle inventories are built in SimaPro and converted into emergy units using published unit emergy values. Midpoint impact categories (global warming, terrestrial acidification, freshwater and marine eutrophication) and endpoint human health and ecosystem quality impacts (DALY and PDF) are translated into emergy-based indicators. New indices for emergy waste and biotic impact are proposed. Uncertainties are propagated via Taylor expansion and Monte Carlo analysis.

At the system level, green-ammonia-based options substantially reduce nonrenewable energy use and greenhouse gas emissions relative to fossil-based EVs, and show higher overall sustainability indices. However, they require much more emergy overall, especially in minerals, water, and land, and raise total biotic endpoint impacts. Most added resource burdens and ecological damages occur in the sending subsystem (Australia), while Japan and the shipping subsystem gain lower emissions and improved emergy performance.

The paper is explicitly about telecoupling and metacoupling: it applies the telecoupling framework to quantify cross-border resource flows, emissions, and impacts, and to reveal uneven distribution of benefits and burdens across sending, receiving, and spillover systems. It highlights the need to internalize externalized resource stress in exporting regions and shows that the LCA-EME approach can support telecoupling-informed energy transition planning.

## Structured Metacoupling Extraction

### Coupling Classification
- Study explicitly applies telecoupling framework to Australia Japan green ammonia energy trade
- Analyzes sending, receiving, spillover subsystems for wind based ammonia passenger transport
- Quantifies cross border resource, emission, sustainability impacts of energy transition

### Intracoupling
#### Systems
- Australia domestic wind based ammonia production system
- Japan domestic power hydrogen production and NEV operation
- National resource and emergy accounting within each country
#### Flows
- Domestic use of minerals, land, and freshwater in production chains
- Local renewable and nonrenewable energy inputs to facilities
- Domestic pollutant emissions affecting national health and ecosystems
#### Agents
- Energy producers and utilities in Australia
- Vehicle manufacturers and transport operators in Japan
- National governments setting energy and climate policies
#### Causes
- National goals for fossil fuel reduction and energy security
- Domestic availability or scarcity of renewables, water, and minerals
- Implementation of green ammonia technologies and infrastructure
#### Effects
- Increased resource demand and environmental load in production regions
- Reduced greenhouse gases but higher acidification and eutrophication locally
- Changes in human health and biodiversity indicators within each country

### Pericoupling
#### Systems
- Maritime transport corridor between Australia and Japan
- Port regions handling coal, gas, and ammonia shipments
- Adjacent marine ecosystems along the shipping route
#### Flows
- International shipping of coal, natural gas, and green ammonia
- Marine emissions and spill risks from bulk carriers
- Virtual flows of water and land embedded in traded fuels
#### Agents
- Shipping companies and port authorities
- Maritime regulators and safety agencies
- Local coastal communities near ports
#### Causes
- Long distance fuel trade required by resource mismatches
- Choice of high energy density ammonia for seaborne transport
- Existing global infrastructure for liquid ammonia shipping
#### Effects
- Intermediate environmental burdens in spillover marine regions
- Biotic health impacts from shipping emissions and risks
- Moderate emergy demand and improved sustainability for ammonia FCV route

### Telecoupling
#### Systems
- Australia as sending subsystem supplying wind based green ammonia
- Japan as receiving subsystem using imported fuels for NEVs
- Global spillover subsystem along Australia Japan shipping route
#### Flows
- Telecoupled trade of coal, natural gas, and wind based green ammonia
- Embodied emergy, minerals, water, and land from Australia to Japan
- Cross border flows of emissions, human health, biodiversity impacts
#### Agents
- Australian and Japanese national governments and energy planners
- Mining, wind power, ammonia, and fuel cell industries
- International organizations concerned with climate and sustainability
#### Causes
- Japanese transport decarbonization targets and NEV deployment goals
- Abundant Australian wind, land, and export orientation for green ammonia
- Global pressure to reduce fossil fuel use and greenhouse gases
#### Effects
- Lower fossil energy use and greenhouse gases at system and Japanese levels
- Strongly increased emergy use, water stress, mineral demand in Australia
- Uneven distribution of biotic endpoint impacts among subsystems

### Cross-Coupling Interactions
- Telecoupled ammonia trade shifts resource depletion and biotic impacts from Japan to Australia
- Water energy mineral emission impact nexus links all three subsystems nonlinearly
- Improved sustainability indices can coexist with higher total emergy and endpoint damages

### Research Gaps or Limitations
- Scenario omits detailed inland transport and labor economic costs
- High uncertainty for coal and gas mining and eutrophication emissions
- Lacks explicit mechanisms to share or internalize sending region externalities

### Search Keywords
- Australia Japan green ammonia telecoupling
- emergy LCA water energy material nexus
- wind based ammonia hydrogen NEV trade

### Extraction Confidence
high
