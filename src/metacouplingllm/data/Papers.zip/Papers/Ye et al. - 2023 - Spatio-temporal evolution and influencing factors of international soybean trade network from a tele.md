# Spatio-temporal evolution and influencing factors of international soybean trade network from a tele

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:15:56.278341+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Ye et al. - 2023 - Spatio-temporal evolution and influencing factors of international soybean trade network from a tele.pdf
- Year: unknown
- DOI: 10.31497/zrzyxb.20230616
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This study examines how the global soybean trade network has changed over space and time from 1995 to 2020, explicitly using the telecoupling framework. It focuses on 177 trading countries worldwide and treats soybean trade as flows linking distant human-environment systems. The authors construct six trade matrices (1995-2020) using FAOSTAT export volumes, and apply social network analysis (UCINET) to characterize overall network structure, node roles, cohesive subgroups, and to identify sending, receiving, and spillover systems. They then use QAP regression with matrices for distance, economic and demographic variables, soybean area, manufacturing value added, WTO membership, and globalization indices to explain network evolution.

The global soybean trade network becomes denser, more clustered, and more efficiently connected, yet remains weakly linked overall and exhibits small-world properties. Trade volume grows sharply but is highly concentrated. A polarized pattern emerges around three dominant systems: China as the main receiving system, and Brazil and the United States as core sending systems, with Argentina and Paraguay as secondary exporters. Many smaller importers are in Europe, Asia, and Africa. Several emerging economies, notably India and South Africa, act as important intermediaries with strong spillover influence, while some European hubs lose relative brokerage roles.

Cohesive subgroups evolve from fragmented clusters to larger, geopolitically structured blocs, with clear Americas-Europe groupings and differentiated North-South patterns in Africa. Recent trade frictions between China and the US shift Chinese imports further toward Brazil, tightening their telecoupled link.

QAP results show soybean harvested area and manufacturing development (supply-side factors) and geographic distance are key drivers. Soybean area strongly boosts trade volumes, highlighting underlying land-use telecoupling. Distance discourages forming trade links, but among existing links larger distances are associated with higher volumes, indicating strong, complementary long-distance couplings that override distance decay. WTO membership and globalization modestly facilitate connections.

The paper is explicitly about telecoupling: it interprets global soybean trade as a multi-system telecoupled network that redistributes environmental pressure. Expansion of soybean area correlates with forest loss in several South American exporters, implying that demand from distant Asian and European importers shifts land-use and ecological burdens across continents.

## Structured Metacoupling Extraction

### Coupling Classification
- Explicit telecoupling study of global soybean trade networks 1995-2020
- Focus on multiple sending, receiving, spillover systems across continents

### Intracoupling
#### Systems
- Domestic soybean production and land use systems within major exporter countries
- Domestic consumption, feed, and processing systems in major importers
- National forest and ecosystem management systems in exporter regions
#### Flows
- Internal land allocation from other crops or forest to soy within a country
- Domestic soybean use for food, feed, and processing industries
- National-level nitrogen emissions and environmental pressures
#### Agents
- National governments designing agricultural and environmental policies
- Domestic farmers and producer cooperatives
- Domestic processors, feed mills, and livestock producers
#### Causes
- Economic growth and dietary shifts raising domestic soy demand
- National comparative advantages in land and mechanization
- Domestic environmental regulations on deforestation and farming
#### Effects
- National land use change and forest loss or protection outcomes
- Shifts in domestic crop structure and farm livelihoods
- Changes in national agricultural emissions and resource use

### Pericoupling
#### Systems
- Neighboring South American soy exporting countries
- European Union member states trading soy among themselves
- Regional African soy producers and nearby importers
#### Flows
- Regional soy trade among geographically close countries
- Spillover of soy expansion from core exporters to nearby nations
- Intra-regional redistribution of environmental and market pressures
#### Agents
- Regional trading blocs and customs unions
- Transnational grain companies active within regions
- Regional logistics and port authorities
#### Causes
- Geographical proximity reducing trade costs for nearby partners
- Regional demand for feed and food products
- Emerging soy production potential in neighboring countries
#### Effects
- Formation of cohesive regional trade subgroups
- Regional differentiation in forest loss and soy expansion
- Shift of intermediary roles from some European hubs to developing regions

### Telecoupling
#### Systems
- South American soybean sending systems like Brazil, Argentina, Paraguay, Bolivia
- Asian and European soybean receiving systems including China and EU states
- Spillover systems such as India, South Africa, Canada, Ukraine
#### Flows
- Large-scale international soybean trade flows 1995-2020
- Embodied land, forest loss, and environmental assets in exported soy
- Information, capital, and technology supporting global soy supply chains
#### Agents
- National governments shaping trade and environmental policies
- International traders and agribusiness corporations
- International organizations such as WTO influencing trade rules
#### Causes
- Global economic growth and rising protein consumption increasing soy demand
- Comparative advantages in land, climate, and mechanization in exporters
- Trade liberalization, globalization, and transport improvements
#### Effects
- Polarized network centered on China, Brazil, United States
- Transfer of environmental pressures from Asian and European importers to South American exporters
- Creation of small-world, increasingly cohesive global soy trade network

### Cross-Coupling Interactions
- Import demand in China and Europe drives soy expansion and forest loss in South America
- Export-driven soy expansion alters exporter ecosystems and feeds back into global markets
- Trade network structure and policy shifts reshape roles of sending, receiving, spillover systems

### Research Gaps or Limitations
- Limited integration of diet transitions, corporate strategies, and GMO market dynamics as drivers
- Coarse analysis of ecological impacts beyond simple soy area and forest loss relations
- Data constraints reduce factor coverage and temporal detail, especially after 2019

### Search Keywords
- telecoupling soybean trade network social network analysis
- global soy sending receiving spillover systems deforestation
- QAP regression distance complementarity land use change

### Extraction Confidence
high
