# Uncovering the spatially distant feedback loops of global trade A network and input-output approach

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:02:24.400666+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Prell et al. - 2017 - Uncovering the spatially distant feedback loops of global trade A network and input-output approach.pdf
- Year: unknown
- DOI: 10.1016/j.scitotenv.2016.11.202
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper investigates how international trade creates long-distance feedbacks between countries economic relations and land use. It explicitly uses the telecoupling lens, focusing on how consumption in one country drives land-use change elsewhere, and how these distant interactions reinforce themselves over time.

The authors analyze the global trading system from 2000 to 2010 for 172 countries. They work at the whole-world scale, without focusing on specific regions, and consider all traded sectors aggregated to country-by-country flows. They combine a multi-regional input-output (MRIO) model based on the EORA database with dynamic network analysis using stochastic actor-oriented models (SAOMs).

MRIO calculations are used to estimate land embodied in trade, covering cropland, forests, grazing land, built-up land, and fisheries. For each country, they derive a Land Trade Imbalance (LTI) index that compares embodied land exports with embodied land imports. Positive values indicate net land exporters; negative values indicate net land importers. Trade networks are defined using only the strongest 5 percent of trade flows to highlight structurally important ties. The SAOM framework then jointly models how these trade ties evolve and how LTI changes, while controlling for GDP per capita (wealth), geographic distance, and land endowment.

The core finding is a reinforcing feedback loop. Poorer countries that are already net exporters of embodied land tend to form or maintain strong export ties to wealthier countries. In turn, exporting to richer partners increases these exporters land trade imbalances, further deepening their net-exporter status. Wealthy countries are more likely to be net land importers, while countries with large land endowments tend to become net exporters without necessarily gaining more strong trade connections.

This work is directly about telecoupling/metacoupling: it operationalizes a telecoupled land-trade system, quantifies distant feedbacks between trade structure and land displacement, and shows how these processes reinforce global environmental inequality between rich consumer regions and poorer producer regions.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong focus on telecoupling via globally traded embodied land and distant feedback loops.

### Intracoupling
#### Systems
- Domestic land systems within exporting countries
- Domestic production structures behind land intensive sectors
#### Flows
- Local land use changes for export production
- Domestic environmental stress from intensified land exploitation
#### Agents
- Producers and firms using national land resources
- National governments shaping export oriented policies
#### Causes
- Pursuit of comparative advantage in land intensive commodities
- Large domestic land endowments encouraging export specialization
#### Effects
- Increased local land pressure and potential deforestation
- Shift of domestic economies toward land intensive activities

### Pericoupling
#### Systems
- Neighboring or regionally close trading partners
- Regional trade clusters among countries of similar wealth
#### Flows
- Regional trade of land intensive goods within contiguous areas
- Knowledge and capital flows reinforcing regional trade ties
#### Agents
- Regional trade blocs and alliances
- Export import firms operating within regional markets
#### Causes
- Geographical proximity lowering trade costs
- Similarity in GDP per capita fostering preferential regional ties
#### Effects
- Regionalization of trade networks and blocks
- Clustered patterns of similar environmental footprints

### Telecoupling
#### Systems
- Poorer land exporting countries as sending systems
- Wealthier land importing countries as receiving systems
- Global trade network as connecting system over 172 countries
#### Flows
- Embodied land in traded commodities from exporters to importers
- Financial flows and demand from wealthy consumers to producers abroad
- Information and market signals guiding formation of strong trade ties
#### Agents
- Export oriented firms and multinational corporations
- National governments managing trade and land policies
- Consumers in developed economies driving distant land demand
#### Causes
- Global trade liberalization and WTO integration of emerging economies
- Wealth disparities shaping trade network positions
- Comparative advantage and historical power asymmetries in resource extraction
#### Effects
- Positive feedback reinforcing land export dependence of poorer countries
- Unequal distribution of land related environmental burdens
- Increasing telecoupled stress on ecosystems in exporting regions

### Cross-Coupling Interactions
- Feedback loop where land export status drives formation of strong ties to richer countries and vice versa
- Co evolution of trade network topology and Land Trade Imbalance over 2000 2010
- Telecoupled trade patterns reinforcing global economic and environmental inequality

### Research Gaps or Limitations
- Analysis restricted to 2000 2010 timeframe and three MRIO waves
- Focus on aggregate embodied land, limited treatment of specific ecosystem outcomes
- Closed access data and modeling complexity constrain policy replication

### Search Keywords
- telecoupling embodied land trade networks feedback loops
- Land Trade Imbalance MRIO stochastic actor oriented models
- global trade inequality rich poor land exporters importers

### Extraction Confidence
high
