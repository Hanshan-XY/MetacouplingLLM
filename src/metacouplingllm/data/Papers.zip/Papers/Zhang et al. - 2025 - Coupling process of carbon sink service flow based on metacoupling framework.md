# OPEN

# Coupling process of carbon sink service flow based on metacoupling framework

Yan Zhang1, Dongjie Guan1,2, Lilei Zhou1,2, Qin $\mathbf { \times } \mathbf { \ i ^ { 1 } }$ , Xinyu Liu3, Jiameng Cao4, Xiujuan He5 & Kangwen Zhu1

Carbon sink service (CSS) is crucial in addressing global warming and provides theoretical support for research on human‒system coupling. CSS generation, flow, and utilization in the composite ecosystem of mountains, rivers, forests, farmlands, lakes, and grasslands (CEMRFFLG) provides theoretical support for sustainable development. Quantifying the coupled supply‒flow‒demand processes and mechanisms of the CSS in CEMRFFLG remains a pressing issue for the study of carbon sink service flows (CSSFs). First, quantify the CSS supply and demand situation of CEMRFFLG Chongqing. Second, the coupling process of the CSSF among the water, forest, farmland, and grassland subsystems is explored via the breakpoint model combined with the metacoupling framework. Finally, a multiscenario simulation of CSSF was performed to reveal its flow mechanism. The results show that: (1) Net primary productivity (NPP) mainly comes from forests, and carbon emissions (CEs) mainly come from farmland. (2) During telecoupling, the forest subsystem has the highest total value in the outflow and inflow plots, accounting for $3 5 . 5 1 \%$ and $6 1 . 2 4 \%$ of the total, respectively. (3) The CSSF mainly moves from areas with forest areas to areas with human activities. This paper proposes optimization suggestions for the CSSF in Chongqing. This is essential for achieving the complex ecosystem’s sustainable development.

Keywords Composite ecosystem of mountains, Rivers, Forests, Farmlands, Lakes, And grasslands; Carbon sink service flow; metacoupling framework; breakpoint model; SPANs‒BBNs model

Metacoupling, first proposed by Liu in 2017, encompasses human-nature interactions within a particular system (intracoupling), between adjacent systems (pericoupling), and between distant systems (telecoupling), providing a new approach to analyze socio-economic and environmental interactions within human-nature coupled systems across spatial scales1 . Traditional approaches (e.g., intracoupling2 , telecoupling3 , etc.) usually focus on a single dimension and are limited to the impacts of human-nature interactions within a system or across a region, which the metacoupling framework compensates for by simultaneously considering interactions and relationships within a region and with neighboring and distant regions4 . The framework has been widely applied in environmental-economic studies and provides a solid basis for analyzing physical, non-physical, and virtual flows across different distances5 . For example, Du et al.6 revealed the impact of global virtual water trade on local water stress through a metacoupling; Carlson et al.7 revealed the interrelationships of marine fishing at local, regional, and global scales through metacoupling. Introducing a metacoupling framework for research has become an important direction for promoting synergistic development of the environment and economy and optimizing ecosystem service assessment globally. The study of carbon sink service flows (CSSFs) based on the metacoupling framework can provide new theoretical perspectives for the cross-regional assessment of ecosystem services.

CSSFs, driven by anthropogenic and natural factors, are transferred from supply regions to demand regions via specific pathways and media8 . In recent years, rapid population growth, the expansion of construction land, and an increase in consumer demand9,10have exacerbated an imbalance between the supply and demand of the carbon sink service (CSS)11,12. CSSF can effectively connect the supply and demand relationship of spatial changes, quantify and draw the spatial flow of CSS, and become the focus of future research13. Luo et al.14

1School of Smart City, Chongqing Jiaotong University, Chongqing 400074, China. 2Research Center for Ecological Security and Green Development, Chongqing Academy of Social Sciences, Chongqing 400020, China. 3Department of Chemistry and Pharmaceutical Science, The University of Siena, Siena 53100, Italy. 4School of River and Ocean Engineering, Chongqing Jiaotong University, Chongqing 400074, China. 5Department of Geography, The University of Hong Kong, Hong Kong 999077, China. email: guandongjie_2000@163.com

analyzed how land use affects the flow of carbon sinks(CSs); Wu et al.15 identified the transfer path between supply and demand areas. We study the whole process of CSS from generation to flow and use, which helps to identify how CSS moves and provides theoretical support for regional ecological protection and sustainable development.

Research on CSSF is actively evolving, with incomplete quantitative assessment methods16. Current CSSF assessment methods are divided into physical quantity-based (e.g., ARIES17and EcoMetrix models18, etc.) and value-based (e.g., ecological footprint method19, MRIO model20, breakpoint model21, and field strength model22, etc.) approaches. The breakpoint model begins with economic impacts between cities and can be used for various ecosystem service flow measurements because of its similarity to ecosystem service flow theory. Now have been a large number of studies based on the fracture point model for ecosystem service measurements, such as Yu et al.23, Ji et al.24, Guan et al.25, Zhai et al.26, and others. The physical quantity-based method is limited by multi-source data and scale applicability issues27. In contrast, the value quantity-based method has broader applicability. Most current studies focus on a single perspective and scale, overlooking the spatial coupling relationship between nonneighboring areas and the subsystems of composite ecosystems. The reach of CSS can extend to regional, national, and global levels. Zhang et al.28 used the equivalent factor method and the breakpoint model to analyze the ecosystem service flow inside and outside the Huangshui Basin under the framework of metacoupling. Vergara et al.29 investigated the spatial connections among cities, regions, and neighboring regions in southern Chile’s marine space via a metacoupling framework. Da Silva et al.30 evaluated the impacts of intracoupling and intercoupling on the environmental and socioeconomic factors of soybean production in Mato Grosso, Brazil, via a metacoupling framework. Most of these studies focus on the water resource supply and grain economic trade. However, there is little research on CSSF at home and abroad, and there is a lack of in-depth studies on the coupling mechanism of supply, flow, and demand of CSSs under the metacoupling framework.

The shortage of CSS supply and demand is increasingly critical, and conducting an assessment and pathway modeling of CSSF based on “supply‒flow‒demand” has become a vital method to solve this issue. Most current pathway modeling methods for ecosystem service flows focus on water provisioning services31–33, and methods based on CSSF include ARIES8 , Service Path Attribute Networks (SPANs)17, and $\mathrm { \dot { R } I } ^ { 3 4 }$ , etc. SPANs model can simulate the supply, use, and flow processes of a CSS under ideal and difficult-to-access conditions, becoming an essential focus in spatial CSSF research35. However, this model is currently concentrated in North America and Europe due to the large number of required parameters and complex data36,37. By simplifying the SPAN model and adopting its conceptual framework of “source‒sink‒use”, many researchers have quantified the transfer process of CSSF by combining it with Bayesian belief networks (BBNs) and ecological models. There are limited studies on uncertainty and sensitivity analysis of SPANs‒BBNs models38,39, and it is possible to combine SPANs with BBNs models and utilize the sensitivity analysis of BBNs to assess the performance of SPANs models in different uncertainties and stability in ecosystem service assessment40.Liu et al.41 simulated water resources in Inner Mongolia via the SPANs model, classified variables affecting water supply services via the BBNs model, and calculated the state probability. Yang et al.42 drew the direction and trend of regional CSS spatial flow by using the SPANs model and GIS tools through wind direction elements. The “source‒sink‒use” process of the CSSF can be effectively simulated by the SPANs‒BBNs model.

The composite ecosystem of mountains, rivers, forests, farmlands, lakes, and grasslands (CEMRFFLG) shoulders the task of establishing an ecological protection compensation mechanism that reflects the value of the CS. Establishing a robust ecological compensation system for the CSS is crucial for achieving the “dual carbon” goal. The CEMRFFLG is a crucial CS, and protecting and restoring it enhances the CSS. Current research on CSS focuses mainly on forest $\mathrm { C S ^ { 4 3 } }$ , grassland $\bar { \mathrm { C S ^ { 4 4 } } }$ , urban $\mathrm { C S ^ { 4 5 } }$ , and ocean $\mathrm { C S ^ { 4 6 } }$ , which cover a wide range of fields. Xu et al.47 assessed the CS capacity of China’s forest, grassland, farmland, wetland, and shrub ecosystems. Lou et al.48 assessed the carbon emission (CE) and sink capacities of China’s forests, grasslands, and farmlands. Existing studies have ignored the differentiation and spatial and temporal change characteristics of CSSs among different ecosystem subsystems of the CEMRFFLG, and there are fewer studies on the flow of CSSs in the CEMRFFLG. The research perspective is informative for the study of the metacoupling process of supply-flow-demand of global composite ecosystem services.

Researchers are increasingly focusing on CSSF. The study of the CSSF in the CEMRFFLG raises two key questions: (1) How can we identify the spatial dislocation of the CSS supply and demand in the composite ecosystem and analyze the coupling relationships among the CSS supply, flow, and demand in the CEMRFFLG? (2) How can we create a comprehensive multiscenario evolutionary model of a CEMRFFLG and analyze the mechanisms governing the spatial flow of the CSS in different scenarios?

Based on the quantitative assessment of the supply and demand of CSSs in the CEMRFFLG, we will reveal the metacoupling mechanism of “supply-flow-demand” in the composite ecosystem, and explores the distribution law of CSSF among different subsystems; and based on the spatial mismatch between the supply and demand of CSSs in CEMRFFLG, multi-scenario simulations were conducted to reveal the flow mechanism of CSSs, and provide a scientific basis for optimizing the management of CSSs. Based on the above research objectives, this paper takes Chongqing as the study case area, and quantitatively assesses the supply and demand of CSSs in the CEMRFFLG through the Carnegie‒Arms‒Stanford approach (CASA) model and the IPCC inventory method; explores the coupling process between different subsystems through the breakpoint model combined with the metacoupling framework; and simulates the flow process of the CSSs based on the SPANs-BBNs model, to reveal the flow mechanism is revealed. The study results can improve the understanding of the objective law regarding the spatial flow of the CSS in Chongqing and facilitate the green development of the ecosystem composite pattern.

# Materials and methods

# Research framework

In this paper, we select four subsystems, namely, water, forest, farmland, and grassland, to measure the total supply and demand of the CSS and analyze the CSSF between the systems by establishing a focal‒adjacent‒distant coupling framework. This paper’s focal system is “one district‒two groups”; the adjacent system is Chongqing, and the distant system is the Yangtze River Basin (YRB). Zhang et al.28 used the abundance of water resources in the Yellow River as a criterion for judging the supply and demand zones; Liang et al.13 took into account the area of different regions as well as their locations in the watershed when determining the supply and demand zones of carbon sequestration services; Yan et al.49 determined the spatial distribution of ecosystem service supply and demand by examining different area differences in land use types to determine the spatial distribution of ecosystem service supply and demand. Depending on the subsystem’s size, the supply area for the adjacent and distant systems is selected in “one district‒two groups”. The Chongqing metropolitan area (CM) is the focal system of the farmland and water subsystem, the southeast Chongqing urban agglomeration (SC) is the focal system of the forest subsystem, and the northeast Chongqing urban agglomeration (NC) is the focal system of the grassland subsystem.

The research framework of this paper is shown in Fig. 1. In the first part, the CASA model and the IPCC inventory method are used to obtain the total CSS supply and demand of Chongqing and the YRB, respectively. The second part uses the breakpoint model to quantify the CSSF between the four subsystems in focal‒adjacent‒ distant systems. The third part uses the SPANs‒BBNs model to simulate the space flow path of the CSS. By dividing the four subsystems of the CSSF into service clusters, some suggestions are proposed to optimize the spatial pattern of the CSSF in Chongqing.

![](images/8ed8401c6033239f070a245e1a6dd374238142531bd62a200aa945ec36ac87b5.jpg)  
Fig. 1. Research framework.

# Research area

Chongqing is located in Southwest China, at the heart of the Three Gorges Reservoir area (Fig. 2a). According to the Third National Land Survey, Chongqing spans approximately 8.24 million hectares, with farmland and forest comprising $2 2 . 7 0 \%$ and $5 6 . 9 1 \%$ of the total area, respectively. The region has 38 districts and counties, forming a development pattern known as “one district–two groups”. This pattern includes the CM, NC, and SC. The terrain is complex, with hills and mountain ranges covering approximately $9 0 \%$ of the area. To achieve the “dual carbon” goal, Chongqing reduced its carbon energy intensity by $1 9 . 4 \%$ during the “13th Five‒Year Plan period”. Owing to its rapidly developing economy, the CE remains high, and the imbalance between the supply and demand for the CSS needs to be addressed.

This paper divides the CEMRFFLG into four subsystems (Fig. 2b): water, forest, farmland, and grassland. These four subsystems are not individual elements but are interconnected, influencing each other to create a complex ecosystem. The water subsystem consists of river, lake, and beach elements. The forest subsystem includes mountain and forest elements. Chongqing is a typical mountain city, with mountains and hills covering approximately $7 6 \%$ and $1 8 \%$ of the area, respectively. Most forests grow on mountains, so mountains and forests are placed in the same system. The farmland subsystem consists of paddy fields and dryland elements. The grassland subsystem includes grassland elements.

# Data source

This paper uses three main data types for 2000, 2010, and 2020. The first type of data is vector data, including administrative boundary data; the second type of data is raster data, including DEM, NDVI, LUCC, POP, and GDP data. When the resolution of the original data is $1 \mathrm { k m }$ , it is necessary to resample the data to $3 0 ~ \mathrm { m }$ by the resampling tool in ArcMap software when evaluating Chongqing; and the third type of data is statistical data, including energy consumption data (from the Chongqing Statistical Yearbook (https://tjj.cq.gov.cn/), and China

a.   
![](images/c934706802869dddf97d15aa714c15eb859eff059cd4cbbc68340a3b2be2290a.jpg)  
DEM(m) High : 8405 Low:-268

![](images/6e30aa43f146cfe4548b17956c658b739a7ec5720ac58c8c0bceef7c814be1b8.jpg)

![](images/c9e27416428c1cdb7b8fc9c8303276a1aa1f1941f3f4854bea0cbe6394547cc0.jpg)  
One district-two groups Chongqing YangtzeRiverBasin

![](images/2790e5b790dd7302d00855c77de9c67b194ff08b20621bb76f773985715c722a.jpg)  
City boundary County bounda

![](images/edc32dc79fb49459a850d109a45e97302356193c6848d7a0fc8daf4daee45548.jpg)  
  
Fig. 2. Map of the study area. (a) Study area (This map depicted in the figure was generated by the authors using ArcGIS 10.4 (Esri, URL: https://www.esri.com/en-us/arcgis/products/arcgis-desktop/overview) and does not require any license). (b) The four subsystems of this paper.

Energy Statistical Yearbook (https://data.cnki.net/)), and meteorological data (solar radiation, precipitation, temperature, evapotranspiration) (from the National Meteorological Information Center‒China Meteorological Data Network (https://data.cma.cn/)). The first and second data types are from the Resource and Environmental Science Platform (https://www.resdc.cn/). In this paper, the research accuracies of Chongqing and the YRB are not consistent, so they are calculated separately. The resolution of the data in Chongqing is unified as $3 0 \mathrm { m }$ , and the data in the YRB are unified as 1 km.

# CSS supply model

Net primary productivity (NPP) represents the chemical energy converted from the energy of the sun by photosynthesis. The CASA model uses light use efficiency to estimate NPP at large or small scales. This paper expresses the supply of the CSS through the NPP value. NPP is represented by establishing a relationship between absorbed photosynthetically active radiation (APAR) and light use efficiency (Ɛ). The basic principle of the model is as follows50:

$$
N P P (x, t) = A P A R (x, t) \times \epsilon (x, t) \tag {1}
$$

where $N P P ( x , t )$ denotes the NPP $( \mathrm { g } \mathrm { C } { \cdot } \mathrm { m } ^ { - 2 } { \cdot } \mathrm { a } ^ { - 1 } )$ of image element $x$ at time t; $A P A R ( x , t )$ denotes the APAR $\mathrm { ( g C \cdot m ^ { - 2 } / }$ month) absorbed by image element $x$ at time t; and $\boldsymbol { \varepsilon } ( x , t )$ denotes the actual light energy utilization of image element $x$ at time t. The algorithm of APAR(x, t) is51:

$$
A P A R (x, t) = S O L (x, t) \times F P A R (x, t) \times 0. 5 \tag {2}
$$

where $F P A R ( x , t )$ denotes the proportion of photosynthetically active radiation absorbed by the plant at time $t$ by image $x ,$ which can be determined from the NDVI; $S O L ( x , t )$ denotes the total solar radiation at time t by image $x ;$ and 0.5 is the proportion of total solar radiation available to the vegetation. The algorithm for $\mathcal { E } ( x , t )$ is as follows:

$$
\epsilon (x, t) = T _ {\epsilon 1} (x, t) \times T _ {\epsilon 2} (x, t) \times W _ {\epsilon} (x, t) \times \epsilon_ {m a x} \tag {3}
$$

where $T _ { \varepsilon _ { I } } ( x , t )$ and $T _ { \varepsilon 2 } ( x , t )$ are temperature stress factors reflecting the effect of temperature on light energy use Ɛ1efficiency; $W _ { \boldsymbol { \varepsilon } } ( x , t )$ Ɛ2 is a moisture stress factor indicating the impact of moisture on light energy use efficiency; and $\mathfrak { E } _ { m a x }$ Ɛis the maximum light energy use efficiency under ideal conditions. Based on existing studies52,53, this maxpaper assigns different $\varepsilon _ { \mathrm { { m a x } } }$ values to different site types, as shown in Table 1. Zhu et al.54 describe the model in more detail.

# CSS demand model

This paper’s CE includes direct and indirect $\mathrm { C E } s ^ { 5 5 }$ , representing the need for a CSS. Direct CE comes from farmland, forest, grassland, water, and unused land56. Farmland has a positive CE factor and is a net CE source, whereas other land use types play a role in $\mathrm { C S ^ { 5 7 } }$ . Indirect CEs are emissions from urban energy production and living on self‒built land58. This paper selects coke, raw coal, gasoline, kerosene, diesel oil, natural gas, and power for calculation. The formula for calculating the CE is as follows:

$$
E = E _ {D} + E _ {I} \tag {4}
$$

where $E _ { D }$ is direct CE and $E _ { I }$ is indirect CE. $E _ { D }$ is calculated as follows:

$$
E _ {D} = \sum_ {i = 1} ^ {n} A _ {i} \times \epsilon_ {i} \tag {5}
$$

where $A _ { i }$ denotes the area of land use type $i$ and $\boldsymbol { \mathfrak { E } } _ { i }$ denotes the CE coefficient $( \mathbf { g } { \cdot } \mathbf { m } ^ { - 2 } { \cdot } \mathbf { a } ^ { - 1 } ) ^ { 5 9 - 6 1 }$ of land use type i, as shown in Table 2. The $E _ { I }$ is calculated as follows:

$$
E _ {I} = C _ {e} \times \alpha_ {e} \times \beta_ {e} \tag {6}
$$

Table 1. $\varepsilon _ { \mathrm { { m a x } } }$ for different site types.   

<table><tr><td>Land use type</td><td>\( {\mathbf{\varepsilon }}_{\max }\left( {\mathrm{g}\mathrm{C} \cdot  {\mathrm{{MJ}}}^{-1}}\right) \)</td></tr><tr><td>Farmland</td><td>0.542</td></tr><tr><td>Forestland</td><td>0.985</td></tr><tr><td>Shrubbery</td><td>0.429</td></tr><tr><td>Open forestland</td><td>0.985</td></tr><tr><td>Other forestland</td><td>0.985</td></tr><tr><td>Grassland</td><td>0.542</td></tr><tr><td>Water</td><td>0.389</td></tr><tr><td>Urban</td><td>0.389</td></tr><tr><td>Unused land</td><td>0.389</td></tr></table>

Table 2. CE factors for land use types.   

<table><tr><td></td><td></td><td>Farmland</td><td>Forest</td><td>Grassland</td><td>Water</td><td>Unused land</td></tr><tr><td rowspan="2">εi</td><td>Chongqing</td><td>46.89</td><td>-60.46</td><td>-2.05</td><td>-13.9</td><td>-0.165</td></tr><tr><td>YRB</td><td>42.2</td><td>-57.8</td><td>-2.1</td><td>-25.2</td><td>-0.5</td></tr></table>

Table 3. Energy standard coal conversion factor and CE factor.   

<table><tr><td>Type of energy</td><td>Standard coal conversion factor</td><td>CE factor \( \left( {\mathrm{t} \cdot  {\mathrm{t}}^{-1}}\right) \)</td></tr><tr><td>Coke</td><td>\( {0.9714}\mathrm{\;{kg}} \) ce \( \cdot  {\mathrm{{kg}}}^{-1} \)</td><td>0.8550</td></tr><tr><td>Raw coal</td><td>\( {0.7143}\mathrm{\;{kg}} \) ce \( \cdot  {\mathrm{{kg}}}^{-1} \)</td><td>0.7559</td></tr><tr><td>Gasoline</td><td>\( {1.4714}\mathrm{\;{kg}} \) ce \( \cdot  {\mathrm{{kg}}}^{-1} \)</td><td>0.5538</td></tr><tr><td>Kerosene</td><td>\( {1.4714}\mathrm{\;{kg}} \) ce \( \cdot  {\mathrm{{kg}}}^{-1} \)</td><td>0.5714</td></tr><tr><td>Diesel oil</td><td>\( {1.4571}\mathrm{\;{kg}} \) ce \( \cdot  {\mathrm{{kg}}}^{-1} \)</td><td>0.5921</td></tr><tr><td>Natural gas</td><td>\( {1.2143}\mathrm{\;{kg}} \) ce \( \cdot  {\mathrm{m}}^{3} \)</td><td>0.4483</td></tr><tr><td>Power</td><td>\( {0.1229}\mathrm{\;{kg}} \) ce \( \cdot  \mathrm{{kW}} \cdot  \mathrm{h} \)</td><td>0.7559</td></tr></table>

where $C _ { e }$ denotes the total energy consumption of the lower e energy sources; $\alpha _ { e }$ denotes the conversion coefficient between the $e$ energy source and standard coal, and $\beta _ { \epsilon }$ denotes the energy CE coefficient. Referring to existing studies62,63 and the IPCC guidelines for calculating CEs (2006), the details are shown in Table 3.

# CSSF coupling process model

The flow of the CSS from the supply area to the demand area generally follows the principle of distance attenuation, which is affected by various natural and social factors, such as water flow, wind direction, land use type, population, and economy64. This paper uses the breaking point model and the metacoupling framework to measure the CSSF.

The model is divided into three steps. First, the radial distance from the supply area to the demand area is calculated via the following equation:

$$
d _ {i j} = D _ {i j} / \left(1 + \sqrt {m _ {j} / m _ {i}}\right) \tag {7}
$$

where $d _ { i j }$ denotes the radial distance from supply zone i to demand zone j; $D _ { i j }$ denotes the distance from supply zone i to demand zone $j ;$ and $m _ { i }$ and m denote the flow difference in the supply zone and the flow difference in i jthe demand zone, respectively21. The formulas for $m _ { i }$ and $m _ { j }$ are the same in this paper:

$$
m _ {i} = N P P (x, t) - E \tag {8}
$$

Then, the field model is used to calculate the average radiation value between regions, and the formula is as follows65:

$$
F _ {i j} = m _ {i} / D _ {i j} ^ {2} \tag {9}
$$

where $\mathrm { F _ { i j } }$ denotes the average radiation value between regions.

ijFinally, the CSSF is calculated according to the average radiation value and radiation range, and the formula is as follows:

$$
E _ {i j} = F _ {i j} \times A _ {i} \times \alpha \tag {10}
$$

where $E _ { i j }$ denotes the flow from supply area i to demand area j; $A _ { i }$ denotes the radial area of supply area i, which is a circular area geometrically centered on i; and $\alpha$ denotes the spatial conversion coefficient. α is generally thought to be 0.6, Ma et al.66, Wang et al.67 (2021) and Wang et al.68 (2024) set it as 0.6 when studying ecosystem service flow in Loess Plateau, Yangtze River Delta region and Guangdong region respectively. Therefore, $\alpha$ of CSSF in Chongqing is set as 0.6 in this paper.

To assess the CSSF from the districts and counties in the “one district‒two groups”, the area ratio method was employed to determine the supply area of each district and county. In the breakpoint model, we calculate the movement of the CSS from the supply area to other regions. Then, we use the supply area as the demand area to calculate the flow of services from other regions into this area.

To quantify the flow of the CSS between the “one district‒two groups” and the adjacent and distant systems, the “one district‒two groups” is considered the supply area. The breakpoint model calculates the CSSF for adjacent and distant systems. The natural breakpoint method was used to divide districts and counties into three levels: low outflow, medium outflow, and high outflow. The remaining CSS outflows are the main CSS outflows, with the exception of the low outflow districts and counties.

Then, considering the “one district‒two groups” as the demand area, the breakpoint model was used to calculate the CSSF from the districts and counties of the adjacent and distant system to the demand area. We divided these districts and counties into three levels: low inflow, medium inflow, and high inflow. The rest are the main CSS inflows, with the exception of the low‒inflow districts and counties. The major CSS outflow and inflow areas of the focal system were divided according to the same principle.

# CSSF multiscenario model

CSSF is characterized by three attributes: flow direction, flow rate, and flow volume. Based on the characteristics of the spatial distribution of the CSS supply and demand in the study area, the flow path of the CSS in the study area was determined via the SPANs model. The logical relationships among the supply, flow, and demand of the CSS were established via the BBNs, and the results were spatialized via integration with ArcGIS software. We analyzed the area and evolution trend of different regions under the carbon peak (CP) and carbon neutrality (CN) scenarios.

# SPANs model

The SPANs model is a spatial framework for quantifying ecosystem service flows on the basis of the “source‒ sink‒use” idea69. This paper’s service flow parameters are screened according to the model framework and localized on the basis of the research content, as shown in Table 4.

# BBNs model

The BBNs model is a method for representing and reasoning about uncertain data and consists of two components: the directed acyclic graph and the conditional probability table (CPT)71. The nodes of the model represent the probability distributions of the variables, and the directed edges between the nodes represent the CPT‒based causal relationships. We combine the prior data with the actual data to find the conditional probability distribution for each node72. For a detailed description of the BBNs model, please refer to Pham73. This paper uses Netica32 (https://norsys.com/netica.html) and GeNIe 4.0 (https://www.bayesfusion.com/) software to model Chongqing’s CSSF. This includes identifying the areas where CS supply services originate (“source” areas), where CS supply services are utilized (“use” areas), and where the CSS is depleted (“sink” areas).

# SPANs‒BBNs model parameterization

Based on the model objectives and the CSSF’s supply and demand results, the model contains both discrete and continuous data. To simplify the calculation, we used ArcGIS to discretize the data and selected a sample of 36,143 data points. Of these, $8 0 \%$ were used for model learning, and $2 0 \%$ were used for model testing. The model comprises 21 nodes (see Table B.1) and is illustrated in Fig. A.1 (Fig. A.1 in Supplementary Information).

# SPANs‒BBNs model evaluation

In this paper, we assess the performance of SPANs‒BBNs from two perspectives. First, we conducted a sensitivity analysis using mutual information (MI) and variance of belief (VB) to gauge how well the target nodes align with the input nodes. The larger the MI and VB are, the stronger the node relationship becomes. Afterward, the accuracy of the model is evaluated based on the overall accuracy of the confusion matrix72. The sensitivity results for the main nodes of the model are presented in Table B.2. The model’s overall accuracy exceeds $8 5 \%$ , demonstrating its strong applicability and the high scientific validity and accuracy of CSSF prediction under various scenarios. The detailed confusion matrices can be found in Tables 5, 6 and 7.

# SPANs‒BBNs model multiscenario simulation

The paper uses the CSS of Chongqing in 2020 as a base scenario and then modifies key data points while keeping others constant to simulate different scenarios. Based on the sensitivity analysis, this paper focuses on changes in parameters such as key nodes A, APAR, POP, GDP, Coke, and Rawcoal to predict the CSS trends in Chongqing for 2030 under the CP and CN scenarios. According to the Chinese policy and existing research results, the specific setting parameters are shown in Table 8. According to the parameter settings of the key nodes under the

Table 4. SPANs model conceptual framework localization.   

<table><tr><td>SPANs concept</td><td>SPANs concept interpretation</td><td>SPANs model</td><td>Localization concept</td><td>Localization model</td></tr><tr><td>Ecosystem service flows</td><td>The spatial flow path of ecosystem services from supply to use.</td><td>Quantization and spatial mapping through SPANs model flow module.</td><td>CSSF from generation to consumption.</td><td>CSSF is the spatial and temporal connections of service flows from the supply area to the demand area, which are process descriptions of service flow paths.</td></tr><tr><td>“Source” area</td><td>Position of the supply service.</td><td>“Source” generates carrier agents for subsequent flow simulations.</td><td>CSS supply area location.</td><td>The supply level and location of CSS are calculated based on the empirical model.</td></tr><tr><td>“Use” area</td><td>Position of beneficiary.</td><td>Passing through the carrier results in a traffic loss and affects the supply services the user receives.</td><td>CSS demand area location.</td><td>Identify the demand and location of carbon sequestration services in conjunction with population distribution and energy consumption needs.</td></tr><tr><td>“Sink” area</td><td>Carrier region of the service delivery process.</td><td>Including beneficial and harmful vectors.</td><td>Potential demand area and potential supply area of CSSF.</td><td>Application and land use change and land use respiratory CE70 represent the loss of the CSSF process.</td></tr><tr><td>Mapping of flows</td><td>Overlap of source and use regions.</td><td>Calculated directly from the SPANs model.</td><td>In situ service flow.</td><td>Coupled SPANs-BBNs model simulates the probability distribution of supply and demand conditions for CSS.</td></tr></table>

Table 5. Confusion matrix of the CSS “sink” area.   

<table><tr><td rowspan="2" colspan="2">“Sink”</td><td colspan="3">Predicted</td></tr><tr><td>Low</td><td>Medium</td><td>High</td></tr><tr><td rowspan="3">Actual</td><td>Low</td><td>3,922</td><td>165</td><td>1</td></tr><tr><td>Medium</td><td>246</td><td>1,978</td><td>121</td></tr><tr><td>High</td><td>1</td><td>361</td><td>435</td></tr><tr><td>Overall accuracy (%)</td><td colspan="4">87.64</td></tr></table>

Table 6. Confusion matrix of the CSS “use” area.   

<table><tr><td rowspan="2" colspan="2">“Use”</td><td colspan="3">Predicted</td></tr><tr><td>Low</td><td>Medium</td><td>High</td></tr><tr><td rowspan="3">Actual</td><td>Low</td><td>4,642</td><td>309</td><td>1</td></tr><tr><td>Medium</td><td>393</td><td>1,374</td><td>10</td></tr><tr><td>High</td><td>1</td><td>26</td><td>473</td></tr><tr><td>Overall accuracy (%)</td><td colspan="4">89.76</td></tr></table>

Table 7. Confusion matrix of the CSS “source” area.   

<table><tr><td rowspan="2" colspan="2">“Source”</td><td colspan="3">Predicted</td></tr><tr><td>Low</td><td>Medium</td><td>Low</td></tr><tr><td rowspan="3">Actual</td><td>Low</td><td>3,901</td><td>253</td><td>6</td></tr><tr><td>Medium</td><td>171</td><td>2,283</td><td>60</td></tr><tr><td>High</td><td>1</td><td>236</td><td>318</td></tr><tr><td>Overall accuracy (%)</td><td colspan="4">89.96</td></tr></table>

Table 8. Scenario parameter setting (unit: $\%$ ).   

<table><tr><td>Scene/ Rate of change</td><td>APAR</td><td>A</td><td>POP</td><td>GDP</td><td>Coke</td><td>Rawcoal</td></tr><tr><td>CP</td><td>0.368</td><td>0.368</td><td>0.021</td><td>0.050</td><td>-0.23</td><td>-0.23</td></tr><tr><td>CN</td><td>0.102</td><td>0.102</td><td>0.038</td><td>0.066</td><td>-0.168</td><td>-0.168</td></tr></table>

two scenarios, the simulation results of the key nodes of the CSSF in Chongqing under different scenarios were obtained by substituting different conditional probabilities into the SPANs-BBNs model. According to the node data of the simulation results, the table data were converted into spatial distribution data by ArcMap software.

CP scenario assumes that carbon emissions peak just before 2030. During this period, economic growth decreases, the share of coal consumption in energy consumption decreases, population growth decreases, and the capacity of ecosystems to sequester carbon increases. Specific indicators are set as follows: The China Peak Carbon by 2030 Study predicts that China’s GDP will grow at an average annual rate of more than $5 \%$ during the Fourteenth and Fifteenth Five-Year Plan periods. According to the National Population Development Plan (2016–2030), the country’s total population will reach its peak in 2030, with a growth rate of $2 . 1 \%$ . According to the data description of CMIP6 by the Center for Resource and Environmental Science and Data of the Chinese Academy of Sciences, through the data description of SSP1-2.6 and SSP2-4.5, the temperature in these two scenarios increases by $3 6 . 8 \%$ compared with the 2020 data of this paper. The key nodes of this paper do not have temperatures, so we are realized through “APAR” and “A” (the principle of CN scenario is the same). The World and China Energy Outlook 2060 suggests that China’s share of coal consumption in 2025 will be $8 \%$ lower than in 2020, with the addition of a $1 5 \%$ reduction in coal consumption in 2030 compared to 2025. There is no coal in the key node of this paper, so it is realized by $^ { \mathrm { e } } C \mathrm { o k e } ^ { \mathrm { p } }$ and “Rawcoal” (the principle of CN scenario is the same).

CN scenario assumes that carbon neutrality will be achieved by 2060, in order to project 2030 data. During this period, the economy continues to develop at a high rate, energy consumption continues to decrease, the population grows moderately, and the CSS supply service is deployed more slowly, so the carbon sequestration capacity still shows an upward trend. The specific indicators are set as follows: According to Deng et al.74, CN can be achieved around 2060 under the SSP1-2.6 scenario, under which precipitation rises by $1 0 . 2 \%$ in the mean value of temperature and precipitation compared to the 2020 data of this paper. According to the setup in the Study on China’s Long-Term Low-Carbon Development Strategies and Transition Paths, China’s achievement of CN in 2060 can be equivalent to the situation studied in the $1 . 5 ^ { \circ } \mathrm { C }$ temperature control target scenario of the

study, with a $4 0 \%$ coal share in 2030, which is a $1 6 . 8 \%$ reduction compared to 2020. Based on the historical data from the statistical yearbook, the population data will grow by $3 . 8 \%$ and GDP by $6 . 6 \%$ in 2030.

# Results

# Supply and demand of the CSS in CEMRFFLG assessment

CSS supply

From 2000 to 2020 (Fig. A.2‒A.5; Fig. A.2‒A.5 in Supplementary Information), there was little change in the spatial class distribution of NPP in the water, forest, and grassland subsystems, with significant differences in the farmland subsystem. The contribution rate of NPP value of water, forest, farmland, and grassland subsystems to the total NPP value was $0 . 5 4 \%$ , $4 4 . 8 3 \%$ , $3 6 . 7 8 \%$ , and $7 . 0 3 \%$ , respectively. The primary sources of NPP are forest and farmland.

From 2000 to 2020 (Fig. A.2), the water subsystem recorded relatively high NPP levels, which were located mainly along the YRB. Wanzhou, Fuling, Changshou, Hechuan, Jiangjin, and Yunyang had relatively high NPP values, averaging $1 . 8 8 \times 1 0 ^ { 1 0 } { \bf g } { \bf C } / \mathrm { m } ^ { 2 }$ . Yuzhong, Dadukou, Shapingba, Qijiang, Nanchuan, and Chengkou had lower NPP values, averaging $\mathbf { \bar { 5 } . 0 5 \times 1 0 ^ { 9 } g C } / \mathbf { m } ^ { \bar { 2 } }$ .

From 2000 to 2020 (Fig. A.3), the forest subsystem recorded relatively high NPP levels, mainly in SC and NC. Chengkou, Wuxi, Fengjie, Youyang, Pengshui, and Fengjie presented relatively high NPP values, with a mean value of $8 . 2 4 \times 1 0 ^ { 1 2 } { \bf g } \bar { \mathrm { C } } / \mathrm { m } ^ { 2 }$ . Moreover, Yuzhong, Dadukou, Jiangbei, Nan’an, and Tongnan had lower NPP values, with a mean value of $6 . 8 4 \times 1 0 ^ { 1 0 } { \bf g } \mathrm { C } / \mathrm { m } ^ { 2 }$ . Among them, Yuzhong had the lowest NPP value, at less than $6 . 4 0 \times 1 0 ^ { 7 } { \mathrm { g C } } / { \mathrm { m } } ^ { 2 }$ .

From 2000 to 2020 (Fig. A.4), the farmland subsystem recorded higher NPP levels, mainly in the NC; the NPP value decreased by $3 7 . 5 3 \%$ . The areas with decreasing NPP values are mainly in CM and SC, possibly because urban expansion has led to reduced farmland. Hechuan, Kaizhou, and Wanzhou consistently had high NPP values, with levels above $5 \times 1 0 ^ { 1 1 } \mathrm { g C } / \mathrm { m } ^ { 2 }$ , whereas Yuzhong had the lowest value, averaging $3 . 2 9 \times \mathrm { \dot { 1 } 0 ^ { 7 } g C } / \mathrm { \dot { m } ^ { 2 } }$

From 2000 to 2020 (Fig. A.5), the grassland subsystem recorded relatively high NPP levels, mainly in the NC. Fengjie, Yunyang, Chengkou, Kaizhou, Wuxi, and Wanzhou presented relatively high NPP values, with a mean value of $2 . 8 2 \times 1 0 ^ { 1 1 } \mathrm { g C } / \mathrm { m } ^ { 2 }$ . Notably, Yuzhong, Dadukou, Jiangbei, and Nan’an had no grasslands, so they were not analyzed. Tongliang, Rongchang, Jiulongpo, Bishan, Shapingba, Beibei, and Yongchuan had lower NPP values, with a mean value of $4 . 6 9 \times 1 0 ^ { 8 } \mathrm { g C } / \mathrm { m } ^ { 2 }$ .

# CSS demand

From 2000 to 2020 (Fig. A.6‒A.9; Fig. A.6‒A.9 in Supplementary Information), the spatial distributions of the CEs of the four subsystems were the same, and the values changed little. The average CE values for the water, forest, farmland, and grassland subsystems are $- 1 . 5 1 \times 1 0 ^ { 1 0 } { \bf g } \mathrm { C } / \mathrm { m } ^ { 2 }$ , $- 2 . 0 3 \times 1 0 ^ { 1 2 } { \bf g } \mathrm { C } / \mathrm { m } ^ { 2 }$ , $1 . 7 9 \times 1 0 ^ { 1 2 } { \bf g } { \bf C } / \mathrm { m } ^ { 2 }$ , and $- 1 . 6 6 \times 1 0 ^ { 1 0 } { \bf g } \mathrm { C } / \mathrm { m } ^ { 2 }$ , respectively. Farmland is the primary source of CEs.

In the water subsystem (Fig. A.6), areas with greater carbon sequestration were concentrated in the SC. The lowest level of carbon sequestration was in Chengkou, with an average value of $2 . 2 5 \times 1 0 ^ { 7 } \mathrm { g C } / \mathrm { m } ^ { 2 }$ , whereas the highest level of carbon sequestration was in Jiangjin, with an average value of $1 . 2 4 \times 1 0 ^ { 9 } \mathrm { g C } / \mathrm { m } ^ { 2 }$ . From 2000 to 2020, Wanzhou, Fuling, Yunyang, Fengjie, Wushan, and Wanzhou significantly increased, with an increasing trend of approximately $1 1 2 \%$ in carbon sequestration.

In the forest subsystem (Fig. A.7), areas with greater carbon sequestration were concentrated in CM. From 2000 to 2020, the values fluctuated and were relatively small. The lowest level of carbon sequestration was in Yuzhong, with a mean value of $1 . 1 8 \times 1 0 ^ { 7 } \mathrm { g C } / \mathrm { m } ^ { 2 }$ , whereas the highest level of carbon sequestration was in Youyang, with a mean value of $1 . 9 6 \times 1 0 ^ { 1 1 } { \bf g } { \bf C } / \mathrm { m } ^ { 2 }$ .

In the farmland subsystem (Fig. A.8), the distribution of CEs was relatively uniform, and the values showed a general downward trend. The lowest CE is in Yuzhong, with an average value of $1 . 4 1 \times 1 0 ^ { 7 } \mathrm { g C } / \mathrm { m } ^ { 2 }$ . Nanchuan and Kaizhou show clear increasing trends, with increases of $6 \%$ and $1 8 \%$ , respectively.

In the grassland subsystem (Fig. A.9), areas with greater carbon sequestration were concentrated in CM, and the values fluctuated. The Yuzhong, Dadukou, Jiangbei, and Nan’an regions do not have grasslands, so they were not included in the analysis. The amount of carbon sequestered in Kaizhou decreased significantly from $1 . 8 7 \times 1 0 ^ { 9 } \mathrm { g C } / \mathrm { m } ^ { 2 }$ in 2000 to $1 . { \dot { 0 } } 8 \times 1 0 ^ { 9 } \mathrm { g C } / \mathrm { m } ^ { 2 }$ in 2020, a decrease of approximately $4 2 \%$ . Carbon sequestration in Pengshui generally increased from $6 . 6 0 \times 1 0 ^ { 8 } { \mathrm { g C } } / { \mathrm { m } } ^ { 2 }$ in 2000 to $1 . 0 5 \times 1 0 ^ { 9 } \mathrm { g C } / \mathrm { m } ^ { 2 }$ in 2020, a rise of approximately $6 0 \%$ .

# Metacoupling of the CSSF in CEMRFFLG

Intracoupling of the CSSF in CEMRFFLG

The rank distribution for intracoupling is determined by adding up the outflows and inflows.

From 2000 to 2020 (Figs.  3 and 4, Fig. A.10‒A.15; Fig. A.10‒A.15 in Supplementary Information), the total flow first increased but then decreased. In the outflow plot, the total flow in the supply area changes as $4 . 9 4 \times 1 0 ^ { 1 3 } \mathrm { g } {  } 6 . 7 3 \times 1 0 ^ { 1 3 } \mathrm { g } {  } 4 . 9 6 \times 1 0 ^ { 1 3 } \mathrm { g }$ . In the inflow plot, the total flow in the demand area changes as $1 . 5 4 \times 1 0 ^ { 1 3 } \mathrm { { g } }  2 . 1 0 \times 1 0 ^ { 1 3 } \mathrm { { g } }  1 . 5 3 \times 1 0 ^ { 1 3 } \mathrm { { g } }$ . The difference in the outflow plot is obvious in the spatial rank distribution. The rank distribution of the inflow plot is generally consistent.

In the water subsystem, the outflow plot (Fig. 3) shows that the total flow from the supply area has a mean value of $8 . 3 4 \times 1 0 ^ { 1 1 } \mathrm { g }$ . The maximum flow value in the supply area is in Hechuan, with a mean value of $3 . 8 2 \times 1 0 ^ { 1 1 } \mathrm { g } ,$ accounting for $4 5 . 8 7 \%$ of the total supply area. From 2000 to 2020, the high‒level phases accounted for $2 9 . 4 1 \%$ $4 7 . 0 6 \%$ , and $5 . 8 8 \%$ , respectively. In the inflow plot (Fig. 4), the total flow in the demand area has an average value of $3 . 3 6 \times 1 0 ^ { 1 0 } \mathrm { g }$ . The largest flow in the supply area is in Tongnan, with an average value of $1 . 0 4 \times 1 0 ^ { 1 0 } \mathrm { g } ,$ representing $3 0 . 8 2 \%$ of the entire supply area. The high levels all accounted for approximately $3 0 \%$ .

![](images/c69b26f96f30a2bba1783d89d9b4852e66e9d4ec2916ea2f2aeb93bf269c045b.jpg)

![](images/21e3b0acdd6a0f09b877a7b55118e35f1b4c6a61e52c6d609c59a9f2266ac5d6.jpg)

![](images/22f3c08581a64ef7634aa55ea18ec49b3406b4f7a6e856531b7ba1d9d5872d8f.jpg)

![](images/d71656c9a9693cede172557b994cc9ad0896586841666a8afad010aa41f3270f.jpg)  
Fig. 3. Outflow plot of intracoupling of water subsystem. (a) Hierarchical distribution of CSSFs in 2000. (b) Hierarchical distribution of CSSFs in 2010. (c) Hierarchical distribution of CSSFs in 2020. (d) CSSF outflow values in 2000. (e) CSSF outflow values in 2010. (f) CSSF outflow values in 2020.

In the forest subsystem, in the outflow plot (Fig. A.10), the total mean flow value provided by the supply area is $7 . 8 3 \times 1 0 ^ { 1 2 } \mathrm { g }$ . Among them, the maximum flow value in the supply area is Youyang, with a mean value of $4 . 7 8 \times 1 0 ^ { 1 2 } \mathrm { g } ,$ which accounts for $6 1 . 0 6 \%$ of the total flow in the supply area. All high‒level outflows occurred in 2010, and no high‒level outflows occurred in 2020. In the inflow plot (Fig. A.11), the total flow in the demand area has an average value of $2 . 7 5 \times 1 0 ^ { 1 2 } \mathrm { g }$ . The smallest flow in the supply area is Qianjiang, with an average value of $5 . 7 4 \times 1 0 ^ { 1 1 } \mathrm { g } ,$ , accounting for $2 0 . 8 4 \%$ of the total flow in the supply area. All were high levels of inflows in 2010.

In the farmland subsystem, the outflow plot (Fig. A.12) shows that the total flow provided by the supply area has a mean value of $3 . 2 2 \times 1 0 ^ { 1 3 } \mathrm { g }$ . There were no low‒level outflows in 2010. In the inflow plot (Fig. A.13), the demand area has a total flow mean of $4 . 7 8 \times 1 0 ^ { 1 2 } \mathrm { g } ;$ the smallest flow in the supply area is Yuzhong, with a mean of $2 . 9 7 \times 1 0 ^ { 4 } \mathrm { g } ,$ , which is less than $1 \%$ of the total flow in the supply area. The high levels all accounted for approximately $2 4 \%$ .

In the grassland subsystem, in the outflow plot (Fig. A.14), the mean value of the total flow provided by the supply area was $5 . 9 2 \times 1 0 ^ { 1 2 } \mathrm { g }$ . Among the supply areas, Kaizhou has the smallest flow, with a mean value of $1 . 6 \bar { 1 } \times \bar { 1 } 0 ^ { 1 2 } \mathrm { g } ,$ accounting for $2 7 . 1 7 \%$ of the total flow. From 2000 to 2020, the high‒level periods accounted for $2 5 \%$ , $5 0 \%$ , and $1 2 . 5 \%$ , respectively. In the inflow plot (Fig. A.15), the demand area has an average flow of $1 . 3 3 \times 1 0 ^ { 1 2 } \mathrm { g }$ . The highest flow in the supply area is Chengkou, with an average of $4 . 3 9 \times 1 0 ^ { 1 1 } \mathrm { g } ,$ accounting for $3 3 . 0 6 \%$ of the total flow. The proportion of high levels is consistently approximately $5 0 \%$ .

# Pericoupling of the CSSF in CEMRFFLG

The spatial distribution and total flow characteristics (Figs.  5 and 6, Fig. A.16‒A.21; Fig. A.16‒A.21 in Supplementary Information) during the coupling of the focal and adjacent systems are generally consistent with the intracoupling. The total flow in the outflow area varies from $4 . 3 \dot { 5 } \times 1 0 ^ { 1 4 } \dot { \bf g } \dot { > } 5 . 8 1 \times 1 0 ^ { 1 \ddot { 4 } } \bf g {  } 4 . 0 \dot { 7 } \times 1 0 ^ { 1 4 } \dot { \bf g } ;$ the total flow in the inflow area varies from $2 . 1 3 \times 1 0 ^ { 1 2 } { \bf g }  3 . 1 6 \times 1 0 ^ { 1 2 } { \bf g }  2 . 4 5 \times 1 0 ^ { 1 2 } { \bf g } .$

In the water subsystem (Fig. 5), the largest outflow area is Chengkou, with an average flow of $2 . 0 8 \times 1 0 ^ { 1 1 } \mathrm { g } ,$ accounting for $7 . 3 4 \%$ of the total flow. The smallest outflow area is Yunyang, accounting for $4 . 4 2 \%$ of the total area. From 2000 to 2020, high‒level outflows accounted for $3 5 . 2 9 \%$ , $5 8 . 8 2 \%$ , and $5 . 8 9 \%$ , respectively. As shown in Fig. 6, the largest inflow area is Yunyang, with a flow increasing from $3 . 6 7 \times 1 0 ^ { 8 } \mathrm { g }$ in 2000 to ${ 3 . 9 0 \times \mathrm { i } 0 ^ { 9 } \mathrm { g } }$ in 2020, an increase of $4 0 8 . 6 6 \%$ , accounting for $2 6 . 7 5 \%$ of the total flow. Qianjiang, Liangping, Chengkou, and Youyang

![](images/ee88d893c6983387eb685f46bab63e9443ab6372c87cf643a7ac8b4cff4599c1.jpg)

![](images/5e033527d85922a50d71ecc5778ce85c7974f45818ed3c7dc31bde5f5fa38a09.jpg)

![](images/305fc0708146d5666669448a6a2c4cb5f746a8eadf1a620164706ec1e3dc92cb.jpg)

![](images/b581c99b276d8c42dc45160645c76c67bc8d64900f70614c9d6a151d3d22dcfc.jpg)  
Fig. 4. Inflow plot of intracoupling of water subsystem. (a) Hierarchical distribution of CSSFs in 2000. (b) Hierarchical distribution of CSSFs in 2010. (c) Hierarchical distribution of CSSFs in 2020. (d) CSSF inflow values in 2000. (e) CSSF inflow values in 2010. (f) CSSF inflow values in 2020.

all have smaller flows, each accounting for no more than $1 \%$ of all flows. The high‒level distribution increased by 1.5 times.

In the forest subsystem (Fig. A.16), Yuzhong had the largest outflow, with an average value of $1 . 3 2 \times 1 0 ^ { 1 3 } \mathrm { g } ,$ accounting for $4 . 4 1 \%$ of the total outflow. Wuxi had the smallest outflow, representing only $1 . 9 1 \%$ of the total. Only Wuxi had a low grade in 2010. As shown in Fig. A.17, the inflow into Wuxi was significantly greater than that into other areas, increasing from $3 . 3 1 \times 1 0 ^ { 1 1 } \mathrm { g }$ in 2000 to $4 . 2 1 \times 1 0 ^ { 1 1 } \mathrm { g }$ in 2020, a $3 3 . 5 6 \%$ increase. The flows in Yuzhong, Dadukou, Jiangbei, and Shapingba are relatively small, each accounting for less than $1 \%$ of the total.

In the farmland subsystem (Fig. A.18), the outflow in all areas showed a significant upward trend in 2010, with a high‒level distribution and an overall increase of approximately $3 0 \%$ . The differences in the flow between different districts and counties were relatively small. In the inflow area (Fig. A.19), Kaizhou had significantly higher flow than did the other areas, increasing from $5 . 4 3 \times 1 0 ^ { 1 0 } \mathrm { g }$ in 2000 to $1 . 0 3 \times 1 0 ^ { 1 1 } \mathrm { g }$ in 2020, an $8 9 . 9 6 \%$ increase. Xiushan had the smallest flow, with an average value of $6 . { \overset { \textstyle - } { 4 } } 9 \times 1 0 ^ { 9 } \mathrm { g } .$ , representing only $1 . 1 1 \%$ of the total inflow.

In the grassland subsystem, the absence of grassland was removed. In the outflow area (Fig. A.20), the lowest flow was in Qijiang, with an average value of ${ \bf \bar { 2 } } . 3 9 \times 1 0 ^ { 1 2 } { \bf g } ,$ accounting for $3 . 0 3 \%$ of the total flow. No low level was recorded in 2010. Among the inflow areas (Fig. A.21), the largest flow was Shizhu, which decreased from $2 . 2 5 \times 1 0 ^ { 1 0 } \mathrm { g }$ in 2000 to $1 . 3 0 \times \overline { { 1 0 } } ^ { 1 0 } \mathrm { g }$ in 2010, a decrease of $4 2 . 3 9 \%$ , accounting for $2 4 . 8 1 \%$ of the total flow. The flows in Jiulongpo, Shapingba, Tongliang, and Bishan were relatively small, each accounting for less than $1 \%$ of the total flow.

# Telecoupling of the CSSF in CEMRFFLG

From 2000 to 2020 (Figs. 7 and 8, Fig. A.22‒A.27; Fig. A.22‒A.27 in Supplementary Information), during the coupling process between the focal and distant systems, the flow in the outflow area first increased but then decreased. The total flow rate in the outflow area changes to $1 . 6 7 \times 1 0 ^ { 1 5 } { \bf g }  2 . 4 0 \times 1 0 ^ { 1 5 } { \bf g }  1 . 5 1 \times 1 0 ^ { 1 5 } { \bf g }$ . In the inflow area, the flow rate decreases and then increases, with the total flow rate in the inflow area changing to $2 . 4 3 \times 1 0 ^ { 1 4 } { \bf g } {  } 2 . 0 9 \times 1 0 ^ { 1 4 } { \bf g } {  } 3 . 3 7 \times 1 0 ^ { 1 4 } { \bf g }$ . The differences in spatial class distributions are more noticeable in the

![](images/2910ce5f8adbceb2d9e1145f9b74a756ef845a6c6d4f96182da2abb07ec7a7a3.jpg)  
Fig. 5. Outflow plot of pericoupling of water subsystem. (a) Hierarchical distribution of CSSFs in 2000. (b) Hierarchical distribution of CSSFs in 2010. (c) Hierarchical distribution of CSSFs in 2020. (d) CSSF outflow values from 2000 to 2020.

outflow plot, with a significant increase in class distribution in 2010, and in the inflow plot, with a significant increase in class distribution in 2020.

In the water subsystem, the spatial class distribution is more uniform and less varied. In the outflow area (Fig. 7), most low‒level areas are distributed in the middle reaches of the YRB. Naqu and Hezhou have relatively high flows, both exceeding $2 \times 1 0 ^ { 1 1 } \mathrm { g }$ . Among the inflow areas (Fig. 8), Haixi, Jingzhou, and Yushu have relatively high flows, and the largest flow is in Jingzhou, with an average value of $2 . 9 2 \times 1 0 ^ { 1 1 } \mathrm { g } ,$ , accounting for $8 . 9 0 \%$ of the total flow. The main inflow areas are located in the middle reaches of the YRB, with high grades accounting for approximately $8 \%$ of the total area.

In the forest subsystem (Fig. A.22), the outflow area had a large proportion of low levels, averaging $3 1 . 0 8 \%$ with a clear distribution of high levels in the lower reaches of the YRB. In 2010, the outflow area experienced a significant increase in flow, from $8 . 1 6 \times 1 0 ^ { 1 4 } \mathrm { g }$ in 2000 to $1 . 1 8 \times 1 0 ^ { 1 5 } \mathrm { g }$ in 2010, indicating a $4 4 . 8 4 \%$ increase. In the inflow area (Fig. A.23), the flow in 2020 also increased significantly, from $1 . 5 9 \times 1 0 ^ { 1 4 } \mathrm { g }$ in 2000 to $2 . 1 7 \times 1 0 ^ { 1 4 } \mathrm { g }$ in 2020, an increase of $3 6 . 7 3 \%$ . Among them, the regions of Ganzi, Liangshan, Aba, and Ganzhou experienced relatively high flows. Ganzi has the highest flow, with a change in flow of $\mathbf { \bar { 1 . 3 8 \times 1 0 ^ { 1 3 } g } } \mathbf { \times } \mathbf { 1 . 2 9 } \mathbf { \times } 1 0 ^ { 1 3 } \mathbf { g } \mathbf {  } 2 . \mathbf { \bar { 1 } } 7 \times 1 0 ^ { 1 3 } \mathbf { g } ,$ reflecting an increase of approximately $5 7 . 6 0 \%$ compared with 2000 and accounting for $9 . 5 0 \%$ of the total flow.

In the farmland subsystem (Fig. A.24), in the outflow area, the total flow increased from $2 . 1 9 \times 1 0 ^ { 1 3 } \mathrm { g }$ in 2000 to $3 . 3 8 \times 1 0 ^ { 1 3 } \mathrm { g }$ in 2020, a $5 4 . 0 1 \%$ increase. There is no high‒level distribution in the lower reaches of the YRB. The flows in Nanyang, Liangshan, and Hanzhong are significantly greater than those in other areas, with the highest flow occurring in Nanyang, averaging $1 . { \bar { 1 6 } } \times 1 0 ^ { { \bar { 1 2 } } } \mathrm { g } .$ , accounting for $4 . 8 5 \%$ of the total flow. As shown in Fig. A.25, the inflow area mainly consists of low‒level flows, averaging $3 3 . 0 8 \%$ . In 2010, only Nanyang and Liangshan had low‒level flows below $4 \times 1 0 ^ { 1 2 } \mathrm { g }$ .

In the grassland subsystem (Fig. A.26), the main outflow areas are located mainly in the middle and lower reaches of the YRB. In 2010, there was a significant increase in the outflow area, from $2 . 7 7 \times 1 0 ^ { 1 4 } \mathrm { g }$ in 2000 to $3 . 7 3 \times 1 0 ^ { 1 4 } \mathrm { g }$ in 2010, representing a $3 4 . 6 0 \%$ increase. As shown in Fig. A.27, the main inflow areas were located primarily in the upper YRB, with Ganzi, Aba, and Yushu having significantly higher inflows than other areas. Ganzi had the largest inflow, with an average value of $2 . 2 0 \times 1 0 ^ { 1 3 } \mathrm { \overline { { g } } } ,$ , accounting for $3 3 . 3 0 \%$ of the total inflow.

# Multiscenario results of CSSF in CEMRFFLG

Figure 9 shows that changes in the “sink” area are insignificant; the “source” area shows an increasing trend, with changes mainly concentrated in NC and SC; the “use” area shows a decreasing trend, with changes mainly

![](images/1d16c6c068d2d48ceea644600d120be50c8bb88c95dedb0b8cf7671172f87801.jpg)  
Fig. 6. Inflow plot of pericoupling of water subsystem. (a) Hierarchical distribution of CSSFs in 2000. (b) Hierarchical distribution of CSSFs in 2010. (c) Hierarchical distribution of CSSFs in 2020. (d) CSSF inflow values from 2000 to 2020.

![](images/5448332dd37ff29be2c6003b5176539c327cd767187b5a293421b11bae46907e.jpg)  
Fig. 7. Outflow plot of telecoupling of water subsystem. (a) Hierarchical distribution of CSSFs in 2000. (b) Hierarchical distribution of CSSFs in 2010. (c) Hierarchical distribution of CSSFs in 2020. (d) CSSF outflow values from 2000 to 2020.

![](images/2d46a430fe1901bfeaaa3108baa010b875cf3b34451e24aa6ddd501fd9af3899.jpg)  
Fig. 8. Inflow plot of telecoupling of water subsystem. (a) Hierarchical distribution of CSSFs in 2000. (b) Hierarchical distribution of CSSFs in 2010. (c) Hierarchical distribution of CSSFs in 2020. (d) CSSF inflow values from 2000 to 2020.

concentrated in the CM. In the CP scenario, the “source” area of high‒level CSS increases by $1 8 8 . 7 2 \%$ , and the “use” area of high‒level CSS decreases by $6 3 . 8 3 \%$ . The supply and demand for the CSS are most moderate under the CP scenario.

In the three scenarios (Fig.  9a, b, and 9c), the higher “source” areas for CSS are mainly along the Daba Mountains, the Dalou Mountains, and the Wuling Mountains. The CSS “sink” areas are primarily determined by the soil respiration rate, with high “sink” areas mainly concentrated in forests and grasslands, resulting in minimal differences among the three scenarios. High “use” areas for the CSS are predominantly concentrated in urban districts and counties, indicating that regions with greater human activity and faster economic development are the main demand areas for the CSS. Overall, the flow of CSS primarily moves from areas with significant forest cover, such as Wuxi, Chengkou, and Fengjie, etc., to areas with more human activity, such as Dadukou, Jiulongpo, and Yuchong, etc.

Among the “source” areas (Fig.  9a, b, and 9c), under the base scenario, only Wuxi, Chengkou, Fengjie, Nanchuan, and Kaizhou have a high‒level CSS “source” area share of more than $1 0 \%$ . The “source” areas of low CSS account for more, with 32 areas, including Tongliang, Tongnan, and Dadukou, having more than $5 0 \%$ of the low level. Compared with the base scenario, under the CP and CN scenarios, the districts and counties with a high CSS “source” area account for more than $1 0 \%$ of the total area increase from 5 to 12 and 7, respectively. The regions with a greater reduction in the share of “source” areas served by low CSS include the Chengkou, Yunyang, and Wushan districts and counties, all of which have declined by more than $5 0 \%$ .

Among the “sink” areas (Fig. 9a, b, and 9c), in the base scenario, CP scenario, and CN scenario, the low CSS sink area is the main area, accounting for $8 6 . 8 4 \%$ , $7 6 . 3 2 \%$ , and $7 1 . 0 5 \%$ , respectively. The average proportion of regions with high‒level status is approximately $2 9 \%$ , and the proportion of high CSS “sink” is the largest in Wuxi, which is approximately $5 0 \%$ in all the scenarios.

Among the “use” areas (Fig.  9a, b, and 9c), in the base scenario, more than $5 0 \%$ of the high‒CSS areas are Dadukou, Jiulongpo, Jiangbei, etc. The percentage of areas with more than $5 0 \%$ low‒CSS areas is $4 4 . 7 4 \%$ . Compared with the base scenario, the percentages of areas with more than a $5 0 \%$ reduction in high‒CSS “use” areas under the CP and CN scenarios are $8 3 . 8 7 \%$ and $4 5 . 1 6 \%$ , respectively. The percentages of regions with more than a $5 0 \%$ increase in the “use” area for low CSS are $4 8 . 6 5 \%$ and $2 7 . 0 3 \%$ , respectively.

# Discussion

# Global implications of the metacoupling framework

The metacoupling framework contains multiple systems of focal, adjacent, and distant systems, which not only increases the complexity between systems also allows to deal with complex features (e.g., problems such as nonlinearities75, time lags76, and legacy effects77), and has become one of the world’s most complex frameworks one of the most complex1 . With the application of the metacoupling framework, scholars have conducted a large number of studies from the provincial scale78, national scale79to the global scale1 , which involve a wide range of areas such as ecosystem services, goods, environmental footprints, virtual water, virtual carbon, and other fields80,81, enriching the existing theoretical system of environmental economy. Due to the omnidirectionality of $\boldsymbol { \mathrm { C S S F s } ^ { 8 2 } }$ , the CSSFs of the CEMRFFLG in Chongqing can affect the neighboring provinces and municipalities of Chongqing, China, and even have a certain impact on CSSFs on a global scale. Based on the differences in

![](images/cdcc8d3458accf5549883f26f9638b16fa6f424d52b82a906045650aab5192f8.jpg)

![](images/0e57ff3f5463a0cdcb772a3bf8ceb8f098aeeba714f06b6cde4bbf7d962d81c6.jpg)

![](images/b6ac4c7ac3eb5613f6f578db6038c5de07f053bf32b82fca293ce291b10b9575.jpg)

![](images/42b9cea4fed595c34108c9bb3e425a42e0515cc4e9ca69dc4df6f22b59f736da.jpg)

![](images/d1d65a58e71b1d21ed406ca6dad794daf7fbc1161adc4aa83add1816ca640fed.jpg)

![](images/26bd2df9fa8b2db79911d366b034321f74e49bb089e5d12fa31279cab1ed21ed.jpg)

![](images/d79028db92eab1f692817d1709d2b5ba0fde90c28425c5cdedebea4d385c697c.jpg)

![](images/66b7cf001195369310d1f7eb0a4e3cd4cc885c03ac542c4765614adff8f7a042.jpg)

Fig. 9. CSSF paths in Chongqing under different scenarios. (a) Base scenario. (b) CP scenario. (c) CN scenario. This map depicted in the figure was generated by the authors using ArcGIS 10.4 (Esri, URL: https://w ww.esri.com/en-us/arcgis/products/arcgis-desktop/overview) and does not require any license.   
![](images/7d6107c6ad35e8be929bde5aeb4ba2c1f96149eeffa43aee9a28eb1152e63498.jpg)  
Low Medium High   
Low Medium High   
Low Medium High

supply and demand of CSSs, the metacoupling framework allows for the balance of CSSFs within systems as well as across spatial distances, allowing for a more complete inter-system study, with significant potential in the integrated assessment of CSSFs. With rapid population and economic growth, it will increase the imbalance between the supply and demand of CSSs in the CEMRFFLG across space and time, which will change the strength of the metacoupling. In order to fully realize the potential of the framework, more time and resources are needed to conduct more systematic and integrated research on the CEMRFFLG to accelerate the further application of the framework worldwide and to achieve global sustainable development.

# Differences in the focal‒adjacent‒distant coupling of the CSS in different subsystems

Based on the results of the focal–adjacent–distant coupling from 2000 to 2020, it is evident that the CSS outflow generally exhibits an inverse relationship with the CSS inflow. To further analyze this relationship, we discuss the CSS outflow in the outflow plot and the CSS inflow in the inflow plot for the four subsystems in 2020 (Fig. 10).

In intracoupling (Fig. 10a), an inverse linear relationship between CSS outflow and inflow is observed in the water and farmland subsystems. This relationship is weaker in the forest and grassland subsystems, being

![](images/c1d0bf5dc8f097655f4a7ef03f68d93e9378fce678c074aed9833969d6ff0ae7.jpg)  
Inflow(g)

![](images/9655e91ee93ee8ac970acd4e3d514b58eb7e95c874e2e25a5f1dc0cd9d457100.jpg)  
Inflow(g)

![](images/765f0140b682b6904877be6ea3b8b1e218a7a38bfb03ebe7ae1b233bf3124aa4.jpg)  
Inflow(g)

![](images/e044be3df92cb207e5dc5574ba1e3d7fd1247e6272e1897fea2351969467abd7.jpg)  
Inflow(g)

![](images/113b3553684bdcb6b59ead10a1500346c75c88c9f7a82edd630be8b716d4a719.jpg)  
Inflow(g)

![](images/b356246ec7a024d42c8aaec61d24880afacc3eec83ffd92f4593cd298b97b394.jpg)  
Inflow(g)

![](images/c4d20542b4a54bfd2d384b97d36b198fad6a5e40a2b8032998486913c9d1a5da.jpg)  
Inflow(g)

![](images/5a97cc73759c12d586931658f9427dd7ebdd3db82d94d07288a39add21fee471.jpg)  
Inflow(g)

![](images/247d0800ad9d01bf73ad87554a8198191e177568def6f454b997df787518645f.jpg)  
Inflow(g)

![](images/ca490d588027188471ba5e82eadc82f03a37157beb4d83055d9f70e37573fe62.jpg)  
Inflow(g)

![](images/2708e583d612bb54c5b824a45502f90a324d07a601e681cf405b75bda4300beb.jpg)  
Inflow(g)

Fig. 10. Correlation between the outflows and inflows of CSSs. (a) The situation of four subsystems in intracoupling. (b) The situation of four subsystems in pericoupling. (c) The situation of four subsystems in telecoupling.   
![](images/8b0e11238578b4954582e0656cd9dd51c3fab40e1c7f820bf03aa1a829ec0246.jpg)  
Outflow(g）-——Linear fit of outflow 95%confidence band 95% prediction band

Inflow(g)

most notable in the forest subsystem. The main factors contributing to this are the distance between supply and demand areas and the level of CSS demand in the demand areas. When the distance difference is insignificant, areas with lower CSS demand experience greater inflows; when the difference in demand for CSSs is insignificant, more distant areas have larger inflows. Pengshui, Youyang, Kaizhou, Fengjie, and Yunyang in the outflow plot are supply areas. Given the lower CSS demand in the supply area, the outflow from it is less than that from the demand area, leading to a significant supply‒demand gap. Compared to the water and farmland subsystems, the supply‒demand distance in the grassland and forest subsystem is shorter, and the more conspicuous decrease in inflow causes a departure from the linear relationship.

In pericoupling (Fig. 10b), an inverse linear relationship exists between the outflows and inflows of CSSs in the four subsystems, with a weaker linear relationship in the forest subsystem. This is mainly due to the geomorphology of Chongqing. The eastern, southern, and southeastern parts of Chongqing are mostly mountain and hilly areas, such as the Wushan, Wuling, and Daloushan mountain ranges. The special geomorphology makes the mountainous areas of SC and NC rich in forest resources. Forest areas are more evenly distributed in SC and NC, narrowing the difference between supply and demand areas. The MC has a smaller distribution of forest areas, high demand, and low supply. As a result, the linear relationship between supply and demand areas is weakened. The distribution trend of resources in the supply and demand areas of other subsystems is the same, the resources in the supply area are more abundant, and the resources in the demand area are more scarce. Ample resources confer a higher supply capacity; when resources are relatively scarce, the demand for resources is high, which is more evident in the CSS inflows.

In telecoupling (Fig.  10c), the outflows and inflows of CSSs in the four subsystems exhibit a negative correlation, yet the linear relationship is attenuated, and in some regions, the outflows of CSSs are less than the inflows. Telecoupling encompasses larger ecosystems, and its flow mechanism is influenced by multiple factors. On one hand, it may result from internal transformation within the distant system, which diminishes the coupling effect between the focal and distant systems via the interaction of CSSs in the neighboring region. On the other hand, various factors such as climate, topography, land use, policies, and human activities in different regions need to be taken into account. Consequently, the linear relationship fails to precisely depict the relationship between inflows and outflows. Under metacoupling, overall CSS outflows exceed inflows, but in telecoupling, certain regions have CSS outflows smaller than inflows. These regions are mainly located in Yunnan, Sichuan,

Shaanxi, Qinghai, Jiangxi, Hunan, and Hubei, primarily because these regions possess relatively more abundant resources compared to the “one district‒two groups”.

Differences between the CSSFs are analyzed based on their share of the four subsystems in each region from 2000 to 2020. Due to the regional inconsistency of the focal system in this paper and the small amount of data for intracoupling and pericoupling, only the regions in the distant system are analyzed here. According to Fig. 11, the region’s most significant change from 2000 to 2020 was a decrease in CSSFs of grassland, farmland, and water subsystems to compensate for the increase in CSSFs of the forest subsystem. The forest subsystem and the farmland, grassland and water subsystems present trade-offs (when an increase in the CSSFs from the forest subsystem leads to a decrease in the CSSFs from the rest of the subsystems83), and the farmland, grassland and water subsystems present synergy (simultaneous decreases in the CSSFs from the subsystems). Land use change and urbanization may lead to a decrease in CSSFs in the farmland and grassland subsystems; the decrease in CSSFs in the water subsystem is related to changes in hydrological conditions due to water management policies and climate change. According to the Guiding Opinions on Strengthening Afforestation and Greening of the Yangtze River Economic Belt issued in 2016, the YRB has vigorously carried out the return of farmland to forests and grasslands to improve forest quality; during the 13th Five-Year Plan period, it is clear that it will be necessary to increase the carbon sink of forests and to reduce the intensity of carbon dioxide emissions. Based on the above reasons, it is possible that the CSSF of the grassland, water, and farmland subsystems may be sacrificed in order to enhance the CSSF of the forest subsystem.

# Optimal design of the CSSF in CEMRFFLG

This paper uses the self‒organizing mapping method84 to identify the carbon sink service clusters (CSSCs) in the districts and counties of Chongqing on the basis of the similarity of the CSSFs of the four subsystems in each district and county. These clusters are then mapped in space and assigned to the CSSC. As shown in Figs. 12 and 13, in terms of spatial distribution, the supply side of the SC is B1, and the demand side is Bi. SC is the ecological barrier area of the Wuling Mountains. This area has a high percentage of forest cover and favorable conditions for afforestation. The area of farmland, water, and grassland areas are all small, and the ecological environment quality is high85. The supply side of NC is dominated by the CSS in the grassland subsystem, with Chengkou, Wuxi, and Yunyang designated B5; Wanzhou, Kaizhou, Fengjie, and Wushan designated B4; the remaining areas designated B6; and the demand side is all Biv. The NC contains the ecological barrier area of the Dabashan Mountains, with limited forested areas and the largest proportion of grassland. Farmland accounts for approximately $3 8 \%$ of the city area and is an essential main production area for agricultural products in Chongqing. Water resources come from the main stream and many tributaries of the YRB, but the region still faces a shortage of water resources due to karstic landforms86. The land use structure of the CM is quite complex, with the farmland subsystem being the dominant feature. Hechuan is classified as B2 and requires forest services. Tongnan, Changshou, Fuling, Ba’nan, and Jiangjin are classified as B3 and require forest services, whereas the remaining areas are classified as B6 and need more green services. The farmland area of the CM accounts for about $4 7 \%$ of the city, and the area of grassland and forest land is relatively scarce87. It contains runoff from many rivers such as the main stream of the YRB, Jialing River, and Wuriver, and is rich in water resources.

![](images/783cfd98f7b9d436a32c1debf7d181ba8789dda64d38a7f3e1caeb575afd537b.jpg)  
Fig. 11. Transformation rates of the share of subsystem CSSFs in the distant system by region from 2000 to 2020.

![](images/4b34bf474ea0cab33827a459976bbd8b9d1b9514b730219fd81b2ed625fbc13b.jpg)

![](images/8d50ca39add3ee631c3bae8103c9f929f988b70cac680aae9da6e7272a5b1fd5.jpg)  
Fig. 12. Supply‒side CSSC in the CSSF of the EC in Chongqing. (a) Spatial-temporal patterns of CSSC. (b) Composition and relative magnitude of CSSFs in CSSC. (B1: forest service cluster; B2: high food‒water service cluster; B3: low food‒water service cluster; B4: low green service cluster; B5: high green service cluster; B6: low food service cluster).

![](images/f6f53eba5ce363c0f5ba2099e668f03eb0c5fcfb1f9222cf657be230c7fcf088.jpg)

![](images/b384f833bc3659519be08f26a21c8ea5e267679a14524814088e911905e6164e.jpg)  
Fig. 13. Demand‒side CSSC in the CSSF of the EC in Chongqing. (a) Spatial-temporal patterns of CSSC. (b) Composition and relative magnitude of CSSFs in CSSC. (Bi: high food‒water‒grass synergistic services demand cluster (SDC); Bii: high ecological SDC; Biii: low ecological SDC; Biv: food‒water‒forest synergistic SDC; Bv: low green SDC; Bvi: forest‒field‒water synergistic SDC).

This paper proposes optimization suggestions on the basis of the spatial distribution pattern of supply and demand service clusters related to the CSSF within the CEMRFFLG in Chongqing. These suggestions consider natural ecological features and relevant policies.

(1) SC should increase the forest area and expand farmland and water bodies appropriately. SC’s forest ecosystem provides ample space, making it a key area for building the “Green Mountains on Both Sides of the Taiwan Strait–Thousand Miles of Forest Belt” and the National Reserve Forest. This expansion aligns with national policy goals and helps address rocky desertification issues in SC, thereby increasing the CSS of the forest ecosystem and compensating for the CSSF in CM. SC water and farmland ecosystems have relatively low CSSs, so measures should be taken to build lakes and wetlands in suitable areas to increase their CSS while protecting the original ecological environment.   
(2) NC should protect blue and green spaces and reasonably increase the area of farmland. Protecting the blue–green space also helps maintain the CSS of the forest, grassland, and water subsystems and compensates for the CSS flows in the CM. Interregional water transfer, including the Sichuan‒Chongqing‒Northeast Integrated Water Resources Allocation Project and the Changzheng Canal Diversion Project, has also increased water resources. The Daba Mountain ecological barrier area and the Wushan‒Qiyao Mountain ecological barrier area in NC contain critical CSSs in the forest and grassland subsystems of Chengkou, Wuxi, and Yunyang, followed by Wanzhou, Kaizhou, Fengjie, and Wushan. The Liangping, Dianjiang, Zhongxian, and Fengdu areas have the

largest farmlands, but their CSSs are insufficient. Therefore, expanding the amount of arable land is necessary to enhance its CSS.

(3) CM should respect the red line for farmland and establish compensation mechanisms for the CSSF. The CM is dominated by farmland, which is an essential ecological conservation area. It is appropriate to “return farmland to forests and grasslands” to protect the farmland red line and increase the CSS of the forest and grassland subsystems. Hechuan is a major grain‒producing county with three river confluences; Tongnan, Changshou, Fuling, Banan, and Jiangjin are the next most important areas. The remaining regions provide fewer CSSs in the farmland subsystem, the land is tight, and the area available for afforestation is relatively small. Relying on the ecological pattern of “three belts, four screens, multiple corridors, and multiple points”, a compensation mechanism for the CSSF can be constructed.

# Deficiencies and prospects

This paper offers a reference for Chongqing to enhance understanding of the relationships among CSS supply, flow, and demand within the CEMRFFLG. It lays a foundation for ecosystem management and restoration, yet has certain limitations. Firstly, the application of different land use data in various models was overlooked. Here, CSS supply was measured with a single model for expediency, with the CASA model used for forest CS assessment and all land use data based thereon, potentially increasing data error. Secondly, the interaction between adjacent and distant systems was not explored. In the focal‒adjacent‒distant coupling process, only the interactions between the focal system and adjacent/distant systems were considered, while the CSSF and mutual influence between adjacent and distant systems were neglected. Thirdly, insufficient multiscenario modeling was conducted. Three scenarios were explored based on national policies, with multiscenario parameters set subjectively, necessitating further exploration to combine subjective and objective data for simulation.

Given these shortcomings, future research is warranted. Firstly, different LUCC data and more suitable models should be considered. The CASA model may not be able to accurately assess the characteristics of the ecosystems of the water, farmland and grassland subsystems, but it has become the norm for most studies to calculate the CSs of each land use type through this model. As different models are different from each other due to different principles and calculation methods, they also bring errors between models. Which specific way brings less error needs to be further explored in the future. Secondly, the connection between adjacent and distant systems should be incorporated. Future work could improve this connection within the metacoupling framework. Thirdly, a combination of shared socioeconomic pathways (SSPs) and representative concentration paths (RCPs) should be employed for multiscenario setup. The SSP focuses on global social, demographic, and economic futures without considering climate change impacts, while the RCP accounts for greenhouse gas and radiative forcing effects. Future research could involve further discussions in the context of SSPs‒RCPs.

# Conclusions

(1) From 2000 to 2020, the average NPP values for the water, forest, farmland, and grassland subsystems were $0 . 5 4 \%$ , $4 4 . 8 3 \%$ , $3 6 . 7 8 \%$ , and $7 . 0 3 \%$ , respectively. From 2000 to 2020, the distribution of CEs across the four subsystems remained consistent, with only minor changes in values.   
(2) The focal system of this paper is “one district‒two groups”, with Chongqing as the adjacent system and the YRB as the distant system. During intracoupling, the farmland subsystem has the highest total value in the outflow and inflow plots, accounting for $1 . 7 7 \%$ and $2 . 6 4 \%$ of the total, respectively. For pericoupling, the forest subsystem has the highest total value in the outflow and inflow plots, accounting for $1 2 . 5 0 \%$ and $0 . 5 2 \%$ of the total, respectively. Finally, in telecoupling, the forest subsystem again has the highest total value in the outflow and inflow plots, accounting for $3 5 . 5 1 \%$ and $6 1 . 2 4 \%$ of the total, respectively.   
(3) In this paper, the “source” area refers to the location of the supply of the CSS, the “sink” area refers to the potential demand area and potential supply area of the CSSF, and the “use” area is where the demand for the CSS is located. The base scenario used in the paper is the CSS in Chongqing in 2020, with only the data of key nodes being changed to create the CP and CN scenarios. Under the CP scenario, the “source” area for high CSS increases by $1 8 8 . 7 2 \%$ , the changes in the “sink” area are not very noticeable, whereas the “use” area for high CSS decreases by $6 3 . 8 3 \%$ . The overall trend observed was that the CSSF mainly originated from areas with large forested areas, such as Wuxi, Chengkou, and Fengjie, to areas with more human activities, such as Dadukou, Jiulongpo, and Yuchong.   
(4) In focal–adjacent–distant coupling, the amount of outflow flow from the supply area of the outflow plot is related to the supply of resources in the area itself, and the more resources there are the higher the outflow. The amount of inflow flow in the demand area of the outflow plot is related to the proximity of the supply area and the difference in the flow of the demand area of its CSS. Generally, the inflow plot’s flow is inversely proportional to the outflow plot’s flow. The forest subsystem and the farmland, grassland and water subsystems present tradeoffs, and the farmland, grassland and water subsystems present synergy.   
(5) To optimize the spatial distribution of the CSS in Chongqing’s CEMRFFLG, we put forward corresponding suggestions based on the ecological pattern of “one district‒two groups”.

