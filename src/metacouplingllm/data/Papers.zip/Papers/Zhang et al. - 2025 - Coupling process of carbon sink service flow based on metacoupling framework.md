# Coupling process of carbon sink service flow based on metacoupling framework

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:19:41.797975+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Zhang et al. - 2025 - Coupling process of carbon sink service flow based on metacoupling framework.pdf
- Year: unknown
- DOI: 10.1038/s41598-025-90606-y
- OA status: gold
- License: cc-by-nc-nd
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This study examines how carbon sink services (CSS) are generated, transferred, and used within a complex regional ecosystem, using Chongqing, Southwest China, as a case. The authors focus on a composite system of mountains, rivers, forests, farmlands, lakes, and grasslands, divided into four functional subsystems: water, forest, farmland, and grassland. They embed this system in a metacoupling structure, with Chongqing’s internal subregions as the focal system, Chongqing as the adjacent system, and the Yangtze River Basin as the distant system.

CSS supply is measured by net primary productivity using the CASA model; CSS demand is represented by direct and indirect carbon emissions estimated with IPCC inventory methods and energy statistics. A breakpoint-field model quantifies CSS flows between supply and demand zones under intracoupling, pericoupling, and telecoupling. The spatial pathways and scenario evolution of CSS flows are then simulated with a combined Service Path Attribute Network (SPANs) and Bayesian belief network (BBNs) model.

Forests contribute the largest share of CSS supply, while farmland is the main emission source. Under intracoupling, farmland dominates internal CSS flows, whereas forest-based flows become most important for coupling with adjacent and distant systems. In telecoupling, forest flows account for over one-third of outflows from Chongqing and most inflows to it, indicating strong long-distance carbon regulation. Overall, CSS tends to move from mountainous, forest-rich counties toward urban, high-emission districts.

Scenario simulations to 2030 under carbon-peak and carbon-neutrality assumptions suggest that enhancing vegetation productivity and cutting coal use substantially increase high-level source areas and reduce high-demand use areas, with only modest change in sink (loss) zones. The paper directly applies and extends the metacoupling framework to carbon sink service flows, clarifying how intracoupling, pericoupling, and telecoupling jointly shape regional carbon regulation. If used in telecoupling or metacoupling research, this work is highly relevant; it is explicitly about metacoupled CSS flows, not merely about local carbon balances.

## Structured Metacoupling Extraction

### Coupling Classification
- Explicitly applies metacoupling to carbon sink flows for intra, peri, and telecoupling.
- Analyzes focal Chongqing, adjacent municipality, and distant Yangtze River Basin linkages.
- Quantifies supply-flow-demand coupling for multiple ecosystem subsystems.

### Intracoupling
#### Systems
- Within Chongqing composite ecosystem of water, forest, farmland, grassland.
- Urban agglomerations CM, NC, SC as internal focal subsystems.
- Source, sink, use areas for carbon sink inside Chongqing.
#### Flows
- Carbon sink service flows between districts inside Chongqing.
- NPP minus emissions moving from high supply to high demand zones.
- CSS flows mainly from forest rich mountains to human activity centers.
#### Agents
- District and county governments managing land and energy.
- Local residents and industries emitting carbon.
- Ecological planners implementing afforestation and land use control.
#### Causes
- Spatial mismatch between carbon sink supply and energy driven demand.
- Urban expansion reducing farmland and altering NPP.
- Local policies on ecological protection and agricultural production.
#### Effects
- Intraregional CSS imbalances across CM, NC, SC.
- Supply gaps where low demand areas export CSS to high demand cores.
- Need for intra Chongqing ecological compensation and land use optimization.

### Pericoupling
#### Systems
- Focal one district two groups versus adjacent Chongqing municipality.
- Chongqing core vs surrounding districts in same municipality.
- Subsystem coupling between focal clusters and nearby counties.
#### Flows
- CSS exchange between focal clusters and adjacent Chongqing areas.
- Forest subsystem dominates peri scale outflows and inflows.
- Water, farmland, grassland CSS redistributed around municipal boundaries.
#### Agents
- Municipal government coordinating regional ecological policy.
- Interdistrict water and land managers.
- Regional energy and agricultural sectors.
#### Causes
- Topographic contrasts between mountainous NC, SC and central CM.
- Periurban development increasing demand near focal boundaries.
- Regional afforestation and returning farmland to forest programs.
#### Effects
- Pericoupling strengthens forest CSS export from mountain barriers.
- Adjacent low resource CM depends on surrounding CSS inflows.
- Peri exchanges alter spatial equity of ecosystem services.

### Telecoupling
#### Systems
- Focal Chongqing versus distant Yangtze River Basin.
- Upper, middle, lower Yangtze regions linked by CSS flows.
- Distant provinces such as Sichuan, Yunnan, Shaanxi, Qinghai, Jiangxi, Hunan, Hubei.
#### Flows
- Large scale CSS transfers between Chongqing and basin regions.
- Forest subsystem provides majority of telecoupled CSS flows.
- Flows follow distance attenuation but modified by ecological capacity.
#### Agents
- National and basin level policymakers targeting dual carbon goals.
- Interprovincial energy and land use sectors affecting emissions and sinks.
- Watershed management agencies influencing hydrological related CSS.
#### Causes
- Basin wide climate targets and afforestation policies.
- Virtual and physical carbon sink exchanges across provinces.
- Land conversion, water projects, and climate driven productivity shifts.
#### Effects
- Some distant regions import more CSS than they export to Chongqing.
- Forest CSS increases while farmland, grassland, water CSS shares decline.
- Telecoupling reshapes tradeoffs among subsystems across the basin.

### Cross-Coupling Interactions
- Intracoupling, pericoupling, telecoupling show generally inverse outflow inflow relationships.
- Forest CSS tradeoffs with farmland, grassland, water CSS across distant systems.
- Neighboring system transformations weaken distant telecoupling linearity.

### Research Gaps or Limitations
- Single CASA model applied to all land types may misrepresent non forest subsystems.
- Interactions between adjacent and distant systems not explicitly modeled.
- Scenario parameters partly subjective; SSP RCP based designs suggested.

### Search Keywords
- carbon sink service flow metacoupling Chongqing Yangtze Basin
- CASA breakpoint SPANs BBNs carbon supply demand coupling
- intracoupling pericoupling telecoupling composite ecosystem mountains rivers forests farmlands grasslands

### Extraction Confidence
high
