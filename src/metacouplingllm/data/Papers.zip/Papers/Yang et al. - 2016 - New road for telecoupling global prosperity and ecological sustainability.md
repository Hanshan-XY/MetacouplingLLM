# New road for telecoupling global prosperity and ecological sustainability

Dewei Yang, $^{1,2}$ Jingjing Cai, $^{3}$ Vanessa Hull, $^{4}$ Kaiyong Wang, $^{5}$ Yin-Phan Tsang, $^{6}$ and Jianguo Liu $^{4,7}$

$^{1}$ Key Lab of Urban Environment and Health, Institute of Urban Environment, Chinese Academy of Sciences, Xiamen, 361021 China

$^{2}$ Xiamen Key Lab of Urban Metabolism, Xiamen, 361021 China

$^{3}$ School of Economics, Xiamen University, Xiamen, 361005 China

$^{4}$ Department of Fisheries and Wildlife, Center for Systems Integration and Sustainability, Michigan State University, East Lansing, Michigan 48823 USA

$^{5}$ Institute of Geographic Sciences and Natural Resources Research, Chinese Academy of Sciences, Beijing, 100101 China

$^{6}$ Department of Natural Resources and Environmental Management, University of Hawaii, Manoa, Honolulu, Hawaii 96822 USA

Abstract. China's ambitious Belt and Road Initiative, which seeks to expand the ancient land routes that connect China to the Mediterranean Sea and corresponding ocean-based routes, is expanding global cooperation with profound socioeconomic and ecological implications. As China and associated countries are developing specific policies to implement the initiative, it is important to analyze and integrate major relevant issues. In this article, we discuss several major challenges facing the Belt and Road region: complex natural features, mismatched resources, shared ecological issues, and diverse socioeconomic conditions. To meet the challenges, we apply the integrated framework of telecoupling (socioeconomic and environmental interactions over distances) and propose to enhance infrastructure connection, transboundary actions, scientific and cultural exchanges, and institutional innovations within the Belt and Road region; and collaborate with more international organizations and countries beyond the Belt and Road region for a prosperous and sustainable world.

Key words: ecological sustainability; global prosperity; telecoupling; the Belt and Road Initiative.

Citation: Yang, D., J. Cai, V. Hull, K. Wang, Y.-P. Tsang, and J. Liu. 2016. New road for telecoupling global prosperity and ecological sustainability. Ecosystem Health and Sustainability 2(10):e01242. 10.1002/ehs2.1242

# Introduction

China is seeking to enhance international cooperation by proposing the "Belt and Road Initiative" (B&R Initiative). The initiative was proposed by President Xi Jinping in 2013 to revive and expand the 2000-year-old Silk Road. The ancient Silk Road, connecting China with Asia, Europe, and Africa, carved Sino-foreign history as a key network of trade and cultural transmission routes in the world. The ambitious B&R Initiative calls for building infrastructure networks around the "Silk Road Economic Belt," such as roads, railways, fuel pipelines, and airports (Fig. 1). The land-based belt is coupled with the ocean-based "21st-century Maritime Silk Road," which extends through ports from the Pacific Ocean to the Indian Ocean and the Mediterranean Sea. Currently, the initiative involves 65 countries that are home to two-thirds of the global population and cover nearly

one-third of the global economy (China Daily 2015a). Investment in the B&R Initiative is expected to reach a peak of \(4 trillion (Djankov and Miner 2016). Recent examples include investment in a gas pipeline between Myanmar and China and completion of three train lines between China and Europe.

The B&R Initiative could not only transform China's economy, but also shape the world's economy and ecosystems and help achieve the Sustainable Development Goals (Sustainable Development Knowledge Forum 2015). However, many challenges remain. The initiative is ambitious with regard to global economic cooperation (Liu 2015), but does not sufficiently address ecological sustainability. Incorporating more environmental actions into the initiative would help achieve long-term global economic prosperity and ecological sustainability. In addition, the misunderstanding of the B&R Initiative, such as taking it as the disparate geopolitical strategy of the Marshall plan (Overholt 2015, People's Daily 2016), would create disputes and deter cooperation.

Here, we address some of the key challenges and provide suggestions for meeting these challenges. Sustainable solutions require a system approach such

![](images/4944613bd7eda46db0c69375bea735309feeec3526e2f62bb9dd6f7af1d3df47.jpg)  
Fig. 1. The Silk Road Economic Belt and the 21st-century Maritime Silk Road (edited using basic information from NDRC et al. (2015)).

as the integrated framework of telecoupling (socioeconomic and environmental interactions over distances) (Liu et al. 2013a, b, 2015a, Yang et al. 2013, 2014). The telecoupling framework examines flows (e.g., movement of energy, matter, goods, products, information, people, and money) between distant systems that cause both environmental and socioeconomic effects. It has been applied to address many issues, including international trade (Liu 2014, Wicke 2014, Fang et al. 2016), species invasions (Liu et al. 2014), conservation (Gasparri and Waroux 2015), investment (Liu et al. 2015b), and ecosystem services (Liu and Yang 2012, Deines et al. 2015). The successful applications of the framework so far demonstrate its potential for use in understanding and governing the interconnections of socioeconomic and environmental issues (including ecological issues) within and among B&R countries across much of the world.

# Challenges

# Complex natural features

Nowhere in the world are there more complex natural features than the B&R region. The land-based region includes all of the highest mountains (over $8,000\mathrm{m}$ in

elevation) in the world and more than 60 rivers over $1,000\mathrm{km}$ long each. The rapid changes in elevation result in varied climatic and extreme environmental conditions. For example, the tectonic uplift of the Qinghai-Tibet Plateau produces extremely arid conditions and seasonal monsoons across most of central Asia (An et al. 2001). Desertification now affects at least one-third of the total population along the Silk Road in China. These obstacles make remote regions difficult to access and challenging to pass through the Eurasia inlands. There is no railway system that spans across the Himalayas to link China with southern Asia. Frequent natural hazards such as sandstorms and earthquakes lead to disastrous environmental and economic consequences. For instance, an earthquake in 2008 along the ancient Silk Road segment in Sichuan, China, caused an estimated $150 billion in direct economic losses and resulted in profound ecosystem degradation in areas that have among the highest biodiversity in the world (Cui et al. 2011).

# Mismatched resources

The B&R region has resources available for economic growth. However, the spatial distribution of these

resources does not match the needs for economic development. China has about $20\%$ of the global human population, but only $5 - 7\%$ of the world's freshwater (Qiu 2010). About two-thirds of Chinese cities are short of water (Liu and Yang 2012), even as the Himalayas is known as the "water tower of Asia." To address the spatial mismatches in water demand and supply, China has implemented the $\$77$ billion South-North Water Transfer Project, the world's largest water diversion project and a good example of a man-made telecoupling, which transfers nearly 45 billion cubic meters of fresh water annually over thousands of kilometers (Liu et al. 2016). Further, the mismatched energy supply and demand leads to dependency on high-carbon energy resources such as oil and coal. About $60\%$ of the imported crude oil in China since 2001 came from energy-rich countries in the Middle East, Russia, northern Africa, and central Asia (Gong et al. 2015). The fluctuating supply of energy resources may undermine the stability of the global economy. High-carbon energy contributes to global climate change and causes ongoing environmental deterioration in the Eurasian continent.

# Shared environmental issues

The B&R countries are facing shared environmental issues such as climate change; biodiversity loss; desertification; air, water, soil, and ocean pollution; and natural disasters. These challenges trigger negative socioeconomic and ecological effects across telecoupled systems. For example, years of severe haze generated by polluting industries in eastern Asia have caused public panic and the spread of respiratory disease over great distances. The World Health Organization estimates that more than one million premature deaths per year in Asia are caused by outdoor air pollution (Silva et al. 2013). The B&R region encompasses 14 of the world's 36 biodiversity hotspots, including the Caucasus, the coastal forests of eastern Africa, and the mountains of central Asia (Critical Ecosystem Partnership Fund 2016). These diverse hotspots already face threats such as deforestation, global warming, and species invasion, which would likely be further exacerbated by the B&R Initiative (Bellard et al. 2014). Marine species and habitats are seriously threatened by overfishing, biological invasion, water pollution, and ocean acidification due to rapid urbanization and intensive industrialization along the maritime Silk Road (Vikas and Dwarakish 2015). However, the shared environmental issues among the B&R countries have not received enough attention.

# Diverse socioeconomic conditions

The B&R region is the cradle of four great ancient civilizations, the source of three major religions, and

the home to diverse ethnicities. However, lack of adequate transportation limits social, cultural, and economic exchanges. For example, due to the inadequate railway network, less than $20\%$ of China's cargo is transferred via land transportation (Du and Ma 2015). The transportation links of nodes and hubs, for example, major cities, depend more on the airline network to facilitate flows among the telecoupled systems than on land transportation. To build a powerful global economic network, the B&R countries need a more connected and reliable transportation network.

Conflicts within and among countries (e.g., frequent wars over energy, disputed borders, ethnic conflicts, terrorist acts) cause tension in the Eurasia region, especially in the Middle East and western Asia. Differences in cultural and religious backgrounds across space create communication barriers that stall cooperation efforts. Current institutions or geopolitical trade rules may undermine the flow of goods and information due to lack of vitality and inclusion both regionally and globally. Despite financial aid from some institutions, for example, the Asia Infrastructure Investment Bank (AIIB) and the Silk Road Fund (SRF) (with a total registered capital of $110 billion), the shortage of funds has restricted regional cooperation in the wake of an ailing global economy.

There are also large regional discrepancies in economic development, social welfare, science, and technology. For example, one billion people live in the poorest and most isolated nations, mostly in sub-Saharan Africa and south and central Asia. These people survive on less than $2\%$ of the world's wealth (World Bank 2008). In 2013, about $11\%$ of China's total investment was focused on energy resources and minerals in the B&R countries (Zheng and Liu 2015).

# Recommendations

# Infrastructure connectivity

It is imperative to build more infrastructural networks for enhancing spatial connectivity and reducing economic gaps across telecoupled systems involved in the B&R Initiative. Building such platforms creates economic and ecological linkages among telecoupled B&R countries, for example, the global environmental change research platform in the Qinghai-Tibet Plateau, the desertification mitigation platform between western China and central Asia, and the trans-South China Sea development platform. Transport nodes and hubs must be connected with protection agreements to accelerate flows of capital, labor, materials, energy, and other resources (e.g., by linking land-based central economic capitals, metropolitan areas, and key maritime harbors, Fig. 1). Following the example of the Sino-Mongolia-Russia, Sino-Pakistan, and Eurasia Land Bridge economic corridors, China should construct more

economic corridors that radiate from China to other countries (e.g., Sino-Myanmar-Bangladesh-India, Sinocentral Asia-west Asia-Africa, and Sino-Indochina Peninsula-Oceania) (NDRC et al. 2015).

# Transboundary actions

Cross-border resource exploitation and shared environmental issues require long-term overall planning and transboundary actions. These involve better management of socioeconomic and environmental effects of telecoupling among B&R countries, including transboundary haze control, upstream-downstream regulation in cross-border rivers, desertification mitigation, and joint exploitation of tourist resources along corridors (UNESCO World Heritage Centre 2015). Sensitive issues could be addressed through establishing "environmental reserves of common interests," for instance, no-take fishing zones (Xinhua News Agency 2012) in marine systems or peace parks in disputed areas among neighboring countries. To tackle ecosystem degradation and related problems arising from mismatched resources, B&R countries should do more to share their successful experiences with ecosystem conservation (e.g., China's afforestation, Israel's water savings, and European biodiversity protection). We suggest a multinational joint research program for international communities to focus on wide-ranging impacts of the B&R across the diverse biodiversity hotspots it traverses. Environmental impact assessments should be conducted on all projects and overseen by transboundary governing bodies to weigh costs and benefits of alternatives for sustainability at multiple scales. To maintain the balance and security of energy supply and demand, reliable energy trade and resource exchange agreements could be established among the B&R countries (Len 2015). A transboundary, transdisciplinary, and cross-sectional telecoupling platform needs to be established for dynamic monitoring, reliable data sharing, early warning, and rapid responses.

# Scientific, technological, and cultural exchanges

More technology transfer is needed among the B&R countries. Successful technologies associated with sewage purification, air pollution control, soil remediation, and seawater desalination could be exchanged among the B&R countries. The transfer of innovative energy-use technologies would promote a strengthened telecoupling of information flow among B&R countries that would in turn allow for a shift in energy dependency from traditional energy (e.g., coal, oil) to renewable energy (e.g., geothermal, solar, wind). The advanced technologies in China (e.g., bullet trains, nanotechnology, and nuclear power for civic use) could be introduced to many more B&R countries.

As environmental problems largely stem from overuse of resources coupled with outdated technologies, fostering scientific and technological exchanges is urgent. Joint scientific exchanges should focus on addressing shared challenges in smart cities, industrial transformation, pollution control, and oceanic resources exploitation. Technology priorities should switch from high-carbon resources (e.g., coal) to clean energy (e.g., hydrogen power, solar energy) (Liu et al. 2013a, b). In addition, joint collaborations could enhance earth system observation of natural resources in the region using advanced remote sensing and related monitoring technologies.

Efforts are needed to overcome differences across cultures and religions among countries. Formulating diverse cultural exchanges (e.g., forums, exhibitions) will help bridge the gaps and reduce cultural unfamiliarity among the B&R countries. These may include Silk Road exhibitions, annual cultural festivals, and regular economic trade and technology fairs (NDRC et al. 2015).

# Institutional innovations

Institutional innovations are needed to create a more fair, equitable, economically efficient, and environmentally friendly world. New flexible governance rules, such as Silk Road trade agreements, should be developed to foster more effective cooperation bilaterally and multilaterally. Institutions need to incorporate agents across telecoupled systems that are connected via enhanced trade and information exchange. Besides existing platforms, such as the Shanghai Cooperation Organization and the BRICS summit among Brazil, Russia, India, China, and south Africa, a free trade zone of the Silk Road could be set up to uphold cooperation, such as via information exchanges, financial support, and infrastructure construction along transportation networks. The linkages between the environment and trade could be tightened via a treaty that enforces emission limits for environmentally sensitive sectors (e.g., a climate-friendly framework with supporting payments and green finance (China Daily 2015b)).

To facilitate the cross-border movement of information, capital, and technology, it is important to develop adaptive policies that promote agglomeration economies, infrastructure construction, advanced technology transfers, and circular economies. These policies require not only high-speed transportation networks (e.g., the Thai Canal (China Daily 2015c) and the route from Qinghai-Tibet Plateau to south Asia), but also more financial support. Besides the AIIB and the SRF, more specialty investment banks or special funds need to be established.

More policy-oriented initiatives should be established to overcome the wealth gap and technological hurdles (e.g., accessible trade rules, technological transfers, scientific exchanges). Furthermore, satisfying diverse demands is indispensable for closing gaps among the

B&R countries. Academies and universities could be more active in tracking natural, social, and technological causes of regional differences and could make policy-oriented initiatives a priority.

# Go beyond the B&R region

The B&R Initiative should collaborate with more international organizations and countries beyond the B&R region to achieve its potential, to minimize its negative spillover effects, and to enhance its positive spillover effects. For example, the United Nations, G7 countries, and BRICS countries could play crucial roles along the Silk Road in, for example, climate adaptation and mitigation, technological transfer, resource savings, pollution control, reducing geopolitical concerns, and poverty alleviation. The South-South Cooperation (UNSSC 2014) and North-South Cooperation (Gaillard 1994, Chandiwana and Ornbjerg 2003) should share their environmental and economic experiences to inform development in the B&R region. The South-South Cooperation (among developing countries) and North-South Cooperation (between developed countries and developing counties) are two collaborative mechanisms that promote the exchange of economy, technology, resources, and environment. International collaborative research on global environmental change under the Belmont Forum (an international consortium of major funding agencies) should be extended to more B&R countries. Together, the world would be in a better position to address global challenges for a prosperous and sustainable future.

