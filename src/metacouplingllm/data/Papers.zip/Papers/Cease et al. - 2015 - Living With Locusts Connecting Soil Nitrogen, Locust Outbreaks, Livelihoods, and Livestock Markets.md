# Living With Locusts Connecting Soil Nitrogen, Locust Outbreaks, Livelihoods, and Livestock Markets

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:32:04.015492+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Cease et al. - 2015 - Living With Locusts Connecting Soil Nitrogen, Locust Outbreaks, Livelihoods, and Livestock Markets.pdf
- Year: unknown
- DOI: 10.1093/biosci/biv048
- OA status: unknown
- License: none recorded
- Category: Journal Articles\Conceptual\Telecoupling
- Closed-access reason: no license info, oa_status=unknown

## Copyright-Safe Summary
This paper develops a coupled human-natural systems perspective on locust outbreaks, using grassland-livestock systems in Inner Mongolia, China, as a focal case and then generalizing globally. The authors link land degradation, soil nutrients, insect physiology, institutions, and markets to explain why some grasshopper species become devastating locust pests and how these processes connect distant human communities.

Empirically, prior work in northeastern China showed that heavy livestock grazing depletes soil nitrogen through erosion and nutrient export. This lowers plant nitrogen content and produces protein-poor forage. Mongolian locusts, unlike many herbivores, grow and reproduce best on such low-protein plants. Thus, overgrazing simultaneously undermines livestock forage quality and enhances conditions for locust population explosions. The paper also notes similar patterns for related locust species in Africa and Australia, though detailed nutrient mechanisms are best documented for the Mongolian locust.

The geographic scope is global: the article surveys major locust species across Africa, the Middle East, Asia, Australia, and Madagascar, and discusses historical experience in North America. It integrates ecological literature on locust biology and precipitation effects, economic analyses of property rights and externalities, and institutional case studies of locust control programs and grazing regimes. Methods are conceptual and synthetic rather than statistical or experimental; the study builds a theoretical framework grounded in existing empirical and modeling work.

The authors frame grassland-locust-livestock interactions as a telecoupled social-ecological system. There are two main telecoupling pathways. First, markets transmit information and materials (for example, livestock and feed prices) across regions, influencing stocking decisions and land use. Second, locust swarms themselves serve as mobile telecouplers: local grazing decisions alter nutrient cycles, promoting locust migration, which then damages crops and rangelands far from the degradation source, with cascading livelihood and price impacts.

The paper is explicitly about telecoupling and metacoupling, emphasizing ecosystem externalities transmitted over long distances and the institutional challenges of managing grazing and locust risk at appropriate spatial and temporal scales.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via locust migration and markets, with local intracoupling and regional pericoupling of grasslands.

### Intracoupling
#### Systems
- Inner Mongolia grassland locust livestock soil system
- Local pastoral households and communal grazing institutions
- National grassland management and pesticide control system
#### Flows
- Soil nitrogen cycling into plant nutrient content
- Livestock grazing pressure altering vegetation quality
- Pesticide and biocontrol applications within outbreak regions
#### Agents
- Local herders and livestock managers
- National agricultural and pest control agencies
- Village or communal grazing institutions
#### Causes
- Heavy grazing depleting soil nitrogen and degrading grasslands
- Stocking decisions driven by meat wool and milk prices
- Institutional failures to manage commons sustainably
#### Effects
- Protein poor forage benefiting Mongolian locust performance
- Increased frequency and scale of local locust outbreaks
- Reduced long term livestock productivity and land value

### Pericoupling
#### Systems
- Neighboring grassland regions sharing migratory locust sources
- Adjacent farming areas exposed to invading swarms
- Regional livestock markets connecting nearby communities
#### Flows
- Locust swarms moving between nearby rangelands and croplands
- Short distance trade of livestock and feed
- Pesticide spraying efforts coordinated across bordering districts
#### Agents
- Neighboring farmers and ranchers
- Regional pest management organizations
- Subnational governments coordinating locust responses
#### Causes
- Spatial externalities from unmanaged overgrazing spreading degradation risk
- Local locust outbreaks spilling into adjacent production zones
- Price signals from regional crop and livestock shortages
#### Effects
- Crop and pasture damage in surrounding communities
- Strategic free riding or complementing in pesticide control
- Changes in local feed availability and herd management

### Telecoupling
#### Systems
- Remote desert or steppe locust breeding areas and distant agricultural regions
- Global and regional livestock and grain markets
- International organizations coordinating cross border locust control
#### Flows
- Long distance migratory locust swarms across countries
- Trade of livestock meat grain and inputs across regions
- Price and information signals transmitted through global markets
#### Agents
- United Nations Food and Agriculture Organization Locust Watch
- Australian Plague Locust Commission and similar agencies
- National governments donors and international aid organizations
#### Causes
- Overgrazing driven by global meat demand and poverty pressures
- Ecosystem externalities transmitted by mobile locust populations
- Market failures omitting locust risk from prices
#### Effects
- Multicountry food insecurity and livelihood losses
- Large public expenditures on pesticides and monitoring
- Long term human capital impacts such as reduced schooling

### Cross-Coupling Interactions
- Local grazing decisions alter locust ecology which then drives regional market and policy responses
- Market price shifts feed back to grazing intensity reinforcing or relieving degradation
- Institutional arrangements mediate how ecological telecouplings translate into social welfare outcomes

### Research Gaps or Limitations
- Limited empirical work on nitrogen locust mechanisms beyond Mongolian locust case
- Poor quantification of health and environmental costs from pesticide based control
- Uncertain price and behavior responses to locust induced feed and livestock shocks

### Search Keywords
- telecoupling locust livestock grassland nitrogen
- ecosystem externalities grazing institutions markets
- Mongolian locust Inner Mongolia soil nitrogen

### Extraction Confidence
high
