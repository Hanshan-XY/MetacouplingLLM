# Interregional ecosystem services benefits transfer from wind erosion control measures in Inner Mongo

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:13:25.023949+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Xu et al. - 2020 - Interregional ecosystem services benefits transfer from wind erosion control measures in Inner Mongo.pdf
- Year: unknown
- DOI: 10.1016/j.envdev.2020.100496
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study analyzes how wind erosion control measures in Inner Mongolia generate ecosystem services that benefit distant downwind regions, using a metacoupling / telecoupling perspective on ecosystem service (ES) flows.

The geographic focus is Inner Mongolia, China, a major dust source area affecting northern China and Northeast Asia. The authors examine the wind-break and sand-fixing service (WSS) provided by vegetation and ecological restoration projects, and how the avoided sand and dust export is transmitted to other regions.

Methodologically, they first quantify the amount of soil that would be eroded without vegetation versus with current cover using the Revised Wind Erosion Equation. The difference is interpreted as the physical WSS. They then assign an economic value using a restoration-cost approach based on desertification control investments. Next, they use the HYSPLIT Lagrangian atmospheric transport model to simulate 5-day dust trajectories from five representative stations across Inner Mongolia for 2010 and 2015, under wind speeds exceeding local erosion thresholds. By interpolating these trajectories, they delineate service providing regions (SPRs) and service benefiting regions (SBRs), and allocate material and monetary flows across a 1-degree grid and to countries and Chinese provinces.

Results show that Inner Mongolia’s WSS reached roughly 7.8 x 10^12 kg of avoided erosion in 2010 and 7.4 x 10^12 kg in 2015, with monetary values on the order of 10^10 CNY. Around 80 percent of this benefit flowed outside Inner Mongolia to downwind areas. SBRs span much of northern China and extend to Mongolia, the Russian Far East, the Korean Peninsula, Japan, and parts of the North Pacific. Within China, in both years about two-thirds of national territory, nearly 90 percent of the population, and over 90 percent of GDP lay within SBRs, though benefit intensity declines with distance from key dust corridors.

The work explicitly addresses telecoupled ES flows and interregional environmental equity, arguing for horizontal ecological compensation from downwind beneficiaries to upwind service providers, and offers a transferable framework for mapping ES flows under the metacoupling framework.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling of ecosystem service flows from Inner Mongolia to East Asia and beyond
- Pericoupling among Inner Mongolia and nearby Chinese provinces via wind erosion control services
- Intracoupling within Inner Mongolia between vegetation restoration and local wind erosion reduction

### Intracoupling
#### Systems
- Grassland desert mosaic within Inner Mongolia
- Local settlements and herder communities in Inner Mongolia
- Ecological project zones inside Inner Mongolia
#### Flows
- Local reduction of wind erosion and dust emission
- Internal material and value flow of windbreak sand fixing service
- Financial investments into local wind erosion control projects
#### Agents
- Inner Mongolia regional governments and agencies
- Local farmers and herders participating in restoration
- Chinese central government funding ecological projects
#### Causes
- Severe local wind erosion and desertification risk
- Implementation of shelterbelt and sand source control projects
- Policy focus on Inner Mongolia as ecological security barrier
#### Effects
- Reduced dust storms and soil loss within Inner Mongolia
- Opportunity costs for local economic development
- Improved local environmental quality and land productivity

### Pericoupling
#### Systems
- Inner Mongolia and adjacent Chinese provinces like Hebei Gansu Ningxia
- Beijing Tianjin urban agglomeration downwind
- Agropastoral transition belt around Inner Mongolia
#### Flows
- Avoided dust deposition onto nearby provinces
- Transfer of windbreak service value across provincial borders
- Interprovincial ecological compensation needs and investment flows
#### Agents
- Provincial governments in northern China
- Designers of Beijing Tianjin Hebei sand source control project
- Residents farmers and industries in downwind provinces
#### Causes
- Downwind dependence on Inner Mongolia vegetation for dust mitigation
- National ecological function zoning and compensation schemes
- Regional development and urbanization increasing exposure to dust
#### Effects
- Protection of cropland and infrastructure in northern China
- Large share of Chinas population and GDP benefiting
- Emerging demands for horizontal interprovincial eco compensation

### Telecoupling
#### Systems
- Inner Mongolia wind erosion source region
- East Asian downwind regions Korea Japan Russian Far East
- Long range receptors including North Pacific Alaska Kazakhstan
#### Flows
- Atmospheric transport of dust as proxy for service flow
- Telecoupled benefits of avoided dust storms abroad
- Information and modeling outputs on transboundary ecosystem service flows
#### Agents
- Chinese national agencies operating HYSPLIT based assessments
- International communities exposed to Asian dust events
- Potential foreign stakeholders in regional environmental cooperation
#### Causes
- Climatic wind patterns transporting dust thousands of kilometers
- Vegetation restoration decreasing emission from major Asian dust source
- Growing recognition of metacoupled environmental interdependence
#### Effects
- Reduced health and environmental impacts in foreign downwind regions
- Unequal distribution of benefits relative to Inner Mongolia costs
- Need for crossborder coordination on wind erosion control

### Cross-Coupling Interactions
- Local vegetation restoration in Inner Mongolia creates regional and international dust mitigation benefits
- National eco projects internalize some costs while external beneficiaries largely free ride
- Spatial proximity shapes gradient from strong peri benefits to weaker tele benefits

### Research Gaps or Limitations
- Difficult to isolate windbreak service benefits from other socioeconomic drivers in beneficiary regions
- Limited quantification of health agricultural and industrial damage avoided in SBRs
- Telecoupled beneficiaries do not yet feature in concrete international compensation mechanisms

### Search Keywords
- Inner Mongolia windbreak sand fixing service flow
- metacoupling dust telecoupling East Asia
- ecosystem service benefit transfer wind erosion control

### Extraction Confidence
high
