# Zoning for the sustainable development mode of global social-ecological systems From the supply-pro

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:42:38.295517+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Du et al. - 2024 - Zoning for the sustainable development mode of global social-ecological systems From the supply-pro.pdf
- Year: unknown
- DOI: 10.1016/j.resconrec.2024.107447
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper develops a global framework to assess and classify national social-ecological systems using a telecoupling lens, emphasizing how international trade decouples where ecological resources are produced and where they are consumed.

The study is global in scope and treats each country as an open system linked through trade in biomass-based products. Ecological resources are represented by net primary productivity (NPP), used as a common metric for ecosystem capacity and material flows. Three core dimensions are quantified: (1) ecosystem supply capacity (sustainable NPP available to humans), (2) production intensity (human appropriation of NPP for agriculture, forestry, and livestock, based on a HANPP-style accounting), and (3) demand level (NPP embodied in domestic consumption, including imports and exports). The authors combine Earth observation data, global land-cover products, FAO production and trade statistics, and World Bank socioeconomic indicators for 185 countries around 2000-2020.

By comparing supply, production, and demand, they derive indicators of self-sufficiency, trade dependence, and ecological carrying pressure, and then classify countries into six sustainable development modes. Key modes include: ecologically strict protection, ecology-economic equilibrium, ecology-economic inequilibrium, ecology-wellbeing equilibrium, ecology-wellbeing inequilibrium, and a theoretically possible but currently absent economy-oriented mode.

Results show that most countries remain in the same mode over two decades. Many resource-rich exporters (e.g., Americas, Russia, Australia) operate in an ecology-economic equilibrium mode, using exports to convert ecological abundance into income without exceeding ecological thresholds. Many high-income, resource-poor importers achieve an ecology-wellbeing equilibrium mode, protecting domestic ecosystems by importing biomass. Sub-Saharan Africa and Central America host many ecologically strict protection systems: ecosystems are not overloaded, but low agricultural technology and import dependence constrain economic development and wellbeing, effectively creating ecological over-protection. A small number of countries (e.g., Germany, Czech Republic) fall into ecology-economic inequilibrium, where export-driven production slightly exceeds sustainable supply.

The paper is explicitly grounded in telecoupling/metacoupling theory, interpreting international trade as long-distance ecological resource flows that redistribute both benefits and environmental pressures. It proposes mode-specific governance and trade strategies to better align global trade, resource security, and the SDGs under ongoing globalization and potential deglobalization.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via international trade in ecological resources among national social ecological systems.

### Intracoupling
#### Systems
- National social ecological systems defined by country boundaries.
- Domestic ecosystems providing NPP based ecological resources.
#### Flows
- Internal appropriation of NPP for agriculture forestry livestock.
- Domestic consumption of ecological products by residents and industries.
#### Agents
- National governments managing land use and trade policies.
- Domestic farmers foresters and agribusiness firms.
- National consumers demanding food fiber and materials.
#### Causes
- Economic development and food security objectives.
- Local agricultural technology levels and land use patterns.
#### Effects
- Ecological surplus or overload within national ecosystems.
- Changes in human wellbeing and poverty within countries.

### Pericoupling
#### Systems
- Neighboring or regional country clusters in Africa Asia Latin America.
- Regional trade blocs exchanging ecological resources.
#### Flows
- Regional food and biomass trade among adjacent countries.
- Cross border land acquisitions within same macro region.
#### Agents
- Regional trade organizations and customs unions.
- Transnational agribusiness investing in nearby countries.
#### Causes
- Geographical proximity reducing transport costs.
- Regional trade agreements and tariffs.
#### Effects
- Shared biodiversity conservation or loss in hotspot regions.
- Regional clustering of protection or exploitation modes.

### Telecoupling
#### Systems
- Resource exporting countries with high ecological endowment.
- Resource importing countries with scarce local ecological resources.
- Global social ecological system under Anthropocene context.
#### Flows
- International trade of primary ecological products and derived goods.
- Virtual flows of NPP based ecological resources embedded in exports and imports.
- Transnational land acquisitions reallocating production overseas.
#### Agents
- High income importing countries in Europe North America East Asia.
- Export oriented countries in Latin America Northern Europe Oceania.
- International organizations providing trade data and development assistance.
#### Causes
- Globalized demand separating production and consumption locations.
- Scarcity of ecological resources and population growth.
- Trade liberalization and evolving deglobalization pressures including COVID 19.
#### Effects
- Synergies and trade offs for SDGs across exporting and importing countries.
- Ecology economic equilibrium or inequilibrium in exporter systems.
- Ecology wellbeing equilibrium or inequilibrium in importer systems.

### Cross-Coupling Interactions
- International trade converts simple supply demand relations into three way supply production demand interactions.
- Import dependence in one country often relies on export dependence and ecological pressure elsewhere.
- Deglobalization risks propagate through trade networks threatening import dependent sustainability modes.

### Research Gaps or Limitations
- Industrial product related ecological resource flows are not yet incorporated into the assessment.
- Spillover or stopover countries in multi step trade chains are not explicitly analyzed.
- Future integration with MRIO and HANPP based extensions is proposed but not implemented.

### Search Keywords
- telecoupling international ecological resource trade NPP HANPP
- social ecological system sustainability modes self sufficiency import dependence
- ecology economic equilibrium ecology wellbeing equilibrium deglobalization adaptive governance

### Extraction Confidence
high
