# Urban land teleconnections in the United States A graphical network approach

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:58:56.139014+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: McManamay et al. - 2022 - Urban land teleconnections in the United States A graphical network approach.pdf
- Year: unknown
- DOI: 10.1016/j.compenvurbsys.2022.101822
- OA status: green
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: green OA without permissive license (none)

## Copyright-Safe Summary
This study analyzes how urban growth in the United States is linked to land-use change in both nearby and distant areas, using a telecoupling / urban land teleconnection perspective. The geographic scope is the conterminous US, with 484 census-defined urban areas and 1,564 rural units (non-urban parts of counties).

The authors treat cities and rural areas as nodes in directed networks and measure links (edges) as statistical dependencies between long-term time series (1950-2016) of land and population variables. For urban nodes they track developed land and population intensity (population per developed area). For rural nodes they track developed land, agricultural land, and agricultural production intensity, including crop-level data. Proximate urban-rural networks are limited by a distance function based on city population and income; distal networks are constrained by empirically derived county-to-county food-supply chains. Teleconnection strength is calculated using transfer entropy (causal information transfer) and Bayesian regression posteriors (correlation).

Urban-urban teleconnection networks are very large and dense: almost all cities are interconnected, with each city linked to dozens of others via shared dynamics in development and especially in population intensity. By contrast, proximate urban-rural networks are small: most rural areas link primarily to a single neighboring city, forming many small local neighborhoods. Distal agricultural counties typically serve several cities via food trade, but only a subset of these commodity links show detectable land teleconnections.

Across network types, changes in urban population intensity generate more and stronger teleconnections than changes in developed land alone. However, models predicting teleconnection strength reveal that attributes of rural destination nodes (rural population, agricultural area, production intensity, and rural development) are at least as influential as city characteristics, suggesting strong local inertia and multi-driver influences in rural land systems.

The paper is explicitly about telecoupling and metacoupling: it operationalizes urban land teleconnections, distinguishes proximate and distal linkages, and proposes a scalable, information-theoretic method that can be integrated into land-use and land-cover change models and extended to emissions, supply-chain, and planning analyses.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling among US cities and between cities and distant agricultural regions
- Pericoupling between cities and nearby rural or peri-rural counties via land and population change

### Intracoupling
#### Systems
- Individual US cities and their internal developed land and population intensity dynamics
#### Flows
- Urban land expansion within fixed census urban boundaries
- Population concentration changes per unit developed land
#### Agents
- Municipal governments and planners
- Urban residents and developers
#### Causes
- Urbanization, economic growth, and demographic change
- Local planning for intensive versus extensive development
#### Effects
- Shifts between compact and sprawling urban growth
- Internal changes in land demand and housing density

### Pericoupling
#### Systems
- Cities and bordering or nearby rural county fragments in the US
- Urban cores and surrounding proximate agricultural landscapes
#### Flows
- Conversion of nearby cropland and pasture to developed land
- Socioeconomic influence of cities on nearby agricultural land values
#### Agents
- City governments and regional planners
- Farmers and rural landowners near cities
#### Causes
- Proximity-driven land value increases from urban economic activity
- Urban population and developed land change affecting adjacent parcels
#### Effects
- Loss of nearby agriculture and pasture to urban uses
- Small urban centered networks where one city shapes a few rural neighbors

### Telecoupling
#### Systems
- Network of 484 US cities linked through land and population co-evolution
- Cities and distant agricultural production counties connected by food supply chains
- Interlinked rural producer regions serving multiple cities
#### Flows
- Food commodity movements from producing counties to consuming urban areas
- Information and causal signals in land and population time series between distant nodes
- Teleconnected changes in agricultural production intensity and urban development intensity
#### Agents
- Agribusiness firms and food processors
- Commodity traders and logistics companies
- Federal and state policy institutions affecting agriculture and urbanization
#### Causes
- Globalization of urban economies and commodity markets
- Urban demand for food and other agricultural products
- Macro socioeconomic trends and sectoral policies influencing land decisions
#### Effects
- Distant cropland contraction with rising production intensity and land stress
- Complex inter-urban dependency networks averaging dozens of telelinked cities
- Rural land change partly driven by multiple distant cities rather than only local forces

### Cross-Coupling Interactions
- Inter-urban telecoupling cascades into pericoupled urban rural land changes
- Distant commodity driven telecoupling overlaps with nearby development driven pericoupling in same rural counties
- Local rural dynamics sometimes outweigh telecoupled city influences on land change

### Research Gaps or Limitations
- Teleconnections inferred statistically without explicit material or energy flow accounting
- Distal food telecouplings underrepresent complex multi stage supply chains and intermediary rural nodes
- Urban peri urban distinctions blurred by static census boundaries and limited variable set

### Search Keywords
- urban land teleconnections United States information theory network
- transfer entropy urban rural land use agricultural production intensity
- telecoupling LULCC modeling city networks food supply chains

### Extraction Confidence
high
