# Have there been forest transitions Forest transition theory revisited in the context of the Modifia

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:50:25.571270+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Kozak and Szwagrzyk - 2016 - Have there been forest transitions Forest transition theory revisited in the context of the Modifia.pdf
- Year: unknown
- DOI: 10.1111/area.12267
- OA status: green
- License: cc-by-nc-nd
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This paper revisits forest transition theory using the lens of the Modifiable Areal Unit Problem (MAUP) and growing telecoupling in the global land system. The study is conceptual and methodological rather than region-specific, but uses a simulation experiment plus a case from the Polish Carpathian Mountains (Central Europe).

The authors examine how shifts from locally bounded land use decisions to long-distance interactions, mediated by markets and trade, can produce apparent forest transitions inside arbitrary spatial units such as countries. They extend an earlier raster-based model in which farmers gradually relocate agriculture to more suitable land, freeing marginal areas for forest regrowth. Their key innovation is to vary the spatial search radius for better land: first restricted within intermediate units (states), then allowed across the entire simulated world. They track forest cover trajectories inside smaller units (regions) grouped by relative land suitability.

Under local search, forest trends depend mainly on a region’s suitability relative to its surrounding state. Under global search, higher-level context dominates: regions in generally less suitable states tend to gain forest, while those in more suitable states lose it, even though total global forest area is constant. In a mixed local-to-global simulation, many regions experience reversals in forest-cover trends when the search radius expands, mimicking transitions seen in empirical data.

A 150-year analysis of forest cover in the Polish Carpathians, using elevation as a proxy for agricultural suitability, shows patterns similar to the mixed simulation: initial divergence between low- and high-elevation communes, followed by generalized forest increase once the mountain region becomes disadvantaged relative to external lowlands.

The paper is explicitly about telecoupling and metacoupling. It argues that in a telecoupled global land-use system, national boundaries rarely align with the true coupling structure of land use drivers. As a result, many reported country-level forest transitions may be MAUP artifacts or expressions of displaced land use rather than genuine endogenous transitions. The authors contend that only a global-scale forest transition would be robust to MAUP in a fully telecoupled world.

## Structured Metacoupling Extraction

### Coupling Classification
- Paper centers on telecoupling in global land use and its effect on forest transitions.

### Intracoupling
#### Systems
- National forest and agricultural land systems treated as closed units
- Mountain communes within the Polish Carpathians
#### Flows
- Local land use adjustments between forest and agriculture
- Internal migration and demographic change affecting land abandonment
#### Agents
- Farmers managing land for subsistence
- National policymakers shaping forest and agricultural policies
#### Causes
- Endogenous demographic and economic changes within countries
- Agricultural productivity shifts reducing local land demand
#### Effects
- Apparent national forest transitions under closed-system assumptions
- Spatially uneven forest cover change within mountain regions

### Pericoupling
#### Systems
- Neighboring regions with contrasting agricultural suitability
- Subnational states and regions within a country
#### Flows
- Regional displacement of cropland to more suitable nearby areas
- Short-distance trade of food and timber between regions
#### Agents
- Regional land markets reallocating production
- Inter-regional traders and processors
#### Causes
- Differences in land suitability among adjacent regions
- Improved regional transport and market integration
#### Effects
- Forest gain in less suitable regions, loss in more suitable neighbors
- Scale-dependent reversals in regional forest trends

### Telecoupling
#### Systems
- Global land use system linking distant countries
- Polish Carpathians connected to external lowland and international markets
- Countries experiencing forest recovery coupled with foreign deforestation regions
#### Flows
- Long-distance trade in agricultural commodities and timber
- Export and import of land demand across borders
- Capital and policy influences transmitted over large distances
#### Agents
- International traders and agribusiness firms
- National governments participating in global markets
- Global consumers driving remote land demand shifts
#### Causes
- Expansion of global markets and trade liberalization
- Growing interaction distance for sourcing agricultural land
- Telecoupled demand causing land use displacement abroad
#### Effects
- Forest recovery in importing countries and deforestation in exporters
- Spurious national forest transitions driven by external land displacement
- Only global-scale forest transition remains robust to spatial aggregation

### Cross-Coupling Interactions
- Shift from local to global drivers alters regional forest trajectories without changing global forest area
- Telecoupled trade turns endogenous-looking transitions into exogenously driven outcomes
- MAUP shows that coupling scale choice changes observed forest transition patterns

### Research Gaps or Limitations
- Simulation omits plantations, agroforestry, and complex driver combinations
- Abrupt interaction-distance switch simplifies gradual globalization processes
- Need better quantification of distant drivers behind observed national transitions

### Search Keywords
- forest transition telecoupling MAUP land use displacement
- global land system agricultural suitability simulation
- Polish Carpathians forest cover change globalization

### Extraction Confidence
high
