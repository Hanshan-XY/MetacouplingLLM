# Modelling drivers of Brazilian agricultural change in a telecoupled world

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:59:38.426115+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Millington et al. - 2021 - Modelling drivers of Brazilian agricultural change in a telecoupled world.pdf
- Year: unknown
- DOI: 10.1016/j.envsoft.2021.105024
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper develops and applies a large-scale land-use and agriculture model for Brazil to explore how global demand for food commodities drives local land-use change in a telecoupled world. The study focuses on 10 major soybean- and maize-producing states, covering about 3.85 million square kilometers, and embeds Brazil within global supply chains for soybean, maize, and beef.

The authors adapt the CRAFTY (Competition for Resources between Agent Functional Types) modeling framework into CRAFTY-Brazil. The model is spatially explicit (5 km grid, annual time step) and represents several land-use agents (e.g., soybean farmers, maize farmers, double-cropping soy-maize producers, beef ranchers, other crop farmers, and nature) and their provision of multiple services (soy, maize, beef, other crops, nature, and other uses). It explicitly incorporates telecoupled drivers through exogenous demand for agricultural commodities linked to domestic and international markets, with the intent to later couple this model to a system-dynamics model of global trade.

Empirical data for 2001-2018 from MapBiomas, IBGE, land price data, climate datasets, transport networks, and protected area maps are used to calibrate capital layers (climate moisture indices, transport costs, technology-driven yields, land value frontiers, and protection constraints). The model also introduces endogenous processes for spatial contagion of land conversion, access to natural land and existing cropland, regeneration of natural vegetation, and producer indebtedness that delays land-use switching.

Calibration indicates that CRAFTY-Brazil reproduces aggregate trajectories of cropland expansion, pasture contraction, and rising soybean and maize output reasonably well, but spatial allocation at municipality level is less accurate. Sensitivity tests and scenarios (varying demand, yields, climate, and protection) show that changes in demand and yields strongly affect total production and the balance between agriculture and nature, while climate mainly alters production levels with limited immediate land-cover response. Yield growth can lead to land sparing via agricultural intensification, while removal of protection expands agriculture but not exclusively inside current protected areas.

The work is squarely about telecoupling/metacoupling: it operationalizes distant market demand, infrastructure, technology, climate, and conservation policies as interacting drivers of Brazilian land-use change, and is designed for future coupling to a global trade model.

## Structured Metacoupling Extraction

### Coupling Classification
- Explicit telecoupling focus; intra regional dynamics in Brazil; future coupling to global trade model

### Intracoupling
#### Systems
- Brazilian agricultural socio ecological system in ten major producing states
- Local land use and cover mosaics of cropland pasture and nature
#### Flows
- Domestic flows of soybean maize beef and other crops
- Capital technology and infrastructure improvements within Brazil
#### Agents
- Soybean maize double crop and other crop farmers
- Beef ranchers and frontier land developers
- Government agencies managing protected areas and land prices
#### Causes
- National agricultural policies and protection rules
- Infrastructure expansion and land price gradients
- Climate variability and technological change in farming
#### Effects
- Conversion between cropland pasture and natural vegetation
- Spatial reallocation of double cropping and pasture systems
- Changes in aggregate commodity production and land abandonment

### Pericoupling
#### Systems
- Brazilian frontier regions versus more established southern agricultural regions
- Municipal scale production zones connected by transport networks
#### Flows
- Regional movement of inputs machinery seeds and knowledge
- Intra national transport of grains and beef to ports and cities
#### Agents
- Regional logistics and transport infrastructure planners
- State level environmental and agricultural authorities
#### Causes
- Uneven transport costs and road paving across regions
- Regional differences in climate suitability and land values
#### Effects
- Emergence of agricultural frontiers and shifting production hotspots
- Localized deforestation and nature regeneration patterns near existing farms

### Telecoupling
#### Systems
- Brazilian soybean maize and beef production system
- International consumer markets such as China and global food system
- Prospective global trade System Dynamics model
#### Flows
- Export flows of soybean maize and beef from Brazil to global markets
- Telecoupled demand signals affecting Brazilian land use
- Potential feedbacks between global prices and local production
#### Agents
- International commodity traders and importers
- Brazilian federal agricultural and trade ministries
- Global climate forcing affecting Brazilian growing conditions
#### Causes
- Rising international demand for feed and meat commodities
- Trade policies and moratoria influencing export viability
- Global climate change altering moisture regimes used in scenarios
#### Effects
- Expansion and intensification of Brazilian cropland and pasture
- Shifts from single maize to soybean maize double cropping
- Telecoupled land sparing or expansion under yield and demand changes

### Cross-Coupling Interactions
- Telecoupled export demand interacts with local capitals like transport moisture and technology
- Protection policies and moratoria mediate how global demand translates into deforestation
- Planned coupling of CRAFTY Brazil with global trade dynamics for feedback analysis

### Research Gaps or Limitations
- Model better reproduces aggregate time series than spatial land allocation patterns
- Uncertainty and misclassification in land cover datasets especially grassland mosaics
- Demand treated exogenously and ecosystem service demand for nature poorly quantified

### Search Keywords
- telecoupling Brazil soybean maize beef
- CRAFTY Brazil land use cover change model
- global commodity trade climate scenarios protected areas

### Extraction Confidence
high
