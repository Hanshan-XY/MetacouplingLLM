# Analysis of emergy-based metabolic efficiency and environmental pressure on the local coupling and telecoupling between urbanization and the eco-environment in the Beijing-Tianjin-Hebei urban agglomeration

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:36:41.790726+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: ChuangLin and Yufei - 2017 - Analysis of emergy-based metabolic efficiency and environmental pressure on the local coupling and t.pdf
- Year: 2017
- DOI: 10.1007/s11430-016-9038-6
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This article examines how urbanization and the eco-environment are linked through both local coupling (within-region interactions) and telecoupling (inter-regional resource and economic exchanges) in the Beijing-Tianjin-Hebei urban agglomeration over 1980-2014. The authors treat the agglomeration as an open socio-ecological system and use emergy-based urban metabolism analysis to evaluate resource flows, economic efficiency, and environmental pressure associated with internal and external elements.

The study area is the core northern China city-region comprising Beijing, Tianjin, and Hebei Province. Internal elements include local renewable and non-renewable natural resources and locally produced goods. External elements include imported energy, water transferred from other basins, trade, foreign capital, labor inflows, and tourism-related earnings. Using official statistics, the authors compute emergy for these flows, emergy-to-GDP and emergy-to-population ratios, an emergy extroversion ratio capturing dependence on external inputs, and internal and external environmental loading ratios as pressure indicators.

Results show a rapid increase in total metabolic emergy, with a marked transition from internal-resource-dominated metabolism to one dominated by external inputs. By 2014, more than two-thirds of total emergy came from external elements, especially in Beijing and Tianjin, which evolved into highly extroverted, import-dependent urban economies. Hebei remained more reliant on its own resource base and heavy-chemical industries. Emergy intensity per unit GDP fell sharply while emergy per capita rose, indicating improved economic efficiency and higher material welfare, but environmental loading from both internal and especially external elements increased continuously, signaling growing ecological stress and pollution risks.

Conceptually, this paper is explicitly framed within the telecoupling and broader metacoupling perspective. It operationalizes telecouplings as external emergy flows and quantifies how these distant interactions reshape local coupling between urbanization and the eco-environment. The findings highlight that managing urban sustainability in mega-urban regions requires not only local environmental governance but also regulation of cross-regional resource, capital, and labor flows that drive environmental pressure.

## Structured Metacoupling Extraction

### Coupling Classification
- Analyzes both local coupling and telecoupling between urbanization and eco-environment in one mega-region.

### Intracoupling
#### Systems
- Urbanization and internal eco-environment within Beijing-Tianjin-Hebei agglomeration
- Internal human system of cities and local ecosystems
#### Flows
- Internal renewable and nonrenewable resource use within cities
- Local agricultural products, water, energy and materials
- Internal pollution and waste emissions
#### Agents
- Local governments of Beijing, Tianjin and Hebei
- Urban residents and local industries
- Regional planners and environmental managers
#### Causes
- Urbanization-driven growth in local resource demand
- Industrialization and heavy industry in Hebei
- Policy-guided regional economic development plans
#### Effects
- Rising internal environmental loading ratios
- Structural shift toward service sectors in core cities
- Improved economic efficiency but persistent local pollution

### Pericoupling
#### Systems
- Neighboring cities within the Beijing-Tianjin-Hebei cluster
- Adjacent resource supply areas around the agglomeration
#### Flows
- Short-distance transfers of energy, water and materials
- Intercity labor and capital movements
#### Agents
- Provincial governments coordinating regional integration
- Intercity transport and utility companies
#### Causes
- Functional division between capital, port city and resource hinterland
- Regional integration and coordinated development strategies
#### Effects
- Increased dependence of Beijing and Tianjin on Hebei resources
- Spatial disparities in pollution and resource burdens

### Telecoupling
#### Systems
- Beijing-Tianjin-Hebei urban agglomeration and distant domestic regions
- Agglomeration and international trade and investment partners
#### Flows
- Imported fuel, water transfer project inputs and traded goods
- Foreign investment, trade inputs and tourism revenues
- Exported manufactured products and embodied environmental impacts
#### Agents
- Central government and national planners
- Foreign investors, trading firms and tourists
- Migrant workers entering the agglomeration
#### Causes
- Globalization and national opening-up policies
- Insufficient local resources for continued urban expansion
- Search for external capital, energy and labor
#### Effects
- External elements dominate urban metabolic structure over time
- Sharp rise in external environmental loading and extroverted city metabolism
- Heightened environmental risks transferred across regions

### Cross-Coupling Interactions
- Scale coupling links intra-urban processes with interregional telecoupled flows
- External inputs reshape internal metabolism, efficiency and pollution patterns
- Many-to-many relations among cities, internal elements and distant sources

### Research Gaps or Limitations
- Telecoupling mechanisms and multi-city one-to-many relations not fully quantified
- Data limits prevent finer spatial analysis at prefectural or county scales
- Need for stronger interdisciplinary integration across geography, economics and management

### Search Keywords
- urban emergy metabolism Beijing Tianjin Hebei
- local coupling telecoupling urbanization eco-environment
- environmental loading external dependency China megaregion

### Extraction Confidence
high
