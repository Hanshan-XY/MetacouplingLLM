# Research progress on ecosystem service trade-offs From cognition to decision-making

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:01:56.187708+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Peng et al. - 2017 - Research progress on ecosystem service trade-offs From cognition to decision-making.pdf
- Year: unknown
- DOI: 10.11821/dlxb201706002
- OA status: unknown
- License: none recorded
- Category: Journal Articles\Review\Telecoupling
- Closed-access reason: no license info, oa_status=unknown

## Copyright-Safe Summary
This review synthesizes developments in research on trade-offs among ecosystem services and links scientific understanding to decision-making. The geographic scope is global, with many examples from China, and the system context spans landscapes, river basins, and regional social-ecological systems.

The authors clarify what ecosystem service trade-offs are: situations where increasing one service (often provisioning) reduces others (typically regulating or cultural). They distinguish negative trade-offs, positive synergies, and neutral relationships, and emphasize three core attributes: spatial trade-offs between regions, temporal trade-offs between short- and long-term benefits, and reversibility of ecosystem change. Maslow-type hierarchies of human needs are used to interpret why stakeholders prioritize certain services.

Methodologically, the paper reviews two main evaluation approaches: indicator-based quantification and process or statistical models (e.g., InVEST and related tools), with cultural services as a persistent challenge for measurement. It discusses mapping of service supply and demand, overlay analysis, clustering of service bundles, correlation analysis, local spatial statistics, and newer tools such as production possibility frontiers for revealing trade-offs and synergies across scales.

For decision-making, the review outlines a conceptual framework that treats multi-level human wellbeing as the ultimate objective and ecological compensation or payments as a key implementation tool. Scenario analysis (often via land-use change models) and multi-objective optimization are highlighted as practical methods to explore alternative futures and negotiate among competing stakeholder preferences.

The paper explicitly connects ecosystem service trade-offs to telecoupling and metacoupling by stressing service flows between distant supply and beneficiary regions, the mismatch between locations of provision and consumption, and the need to analyze networks of ecosystem service flows. It calls for future work on multi-scale coupling of services, dynamic modeling of service flows within telecoupled systems, and integration of trade-off analysis into ecological compensation schemes.

The article is directly about telecoupling/metacoupling, treating ecosystem service flows and distant linkages as central themes.

## Structured Metacoupling Extraction

### Coupling Classification
- Conceptual review emphasizing intra and telecoupling in ecosystem service trade-offs.

### Intracoupling
#### Systems
- Local coupled social-ecological systems managing multiple ecosystem services
- Landscape ecosystems providing provisioning, regulating, cultural, supporting services
#### Flows
- On-site provision and consumption of regulating and cultural services
- Local trade-offs between provisioning increase and regulating decline
#### Agents
- Local residents and farmers choosing land use and service priorities
- Local governments designing ecosystem service and land policies
#### Causes
- Preference for short-term economic gains and provisioning services
- Land use change and management intensification within landscapes
#### Effects
- Reduced regulating and cultural services and biodiversity
- Changes in local human wellbeing across multiple dimensions

### Pericoupling
#### Systems
- Upstream and downstream regions of shared river basins
- Neighboring administrative regions linked by ecosystem service flows
#### Flows
- Water regulation and soil retention services moving along catchments
- Pollution and sediment transport affecting adjacent areas
#### Agents
- Upstream land managers influencing downstream beneficiaries
- Regional planners coordinating cross-boundary ecosystem management
#### Causes
- Watershed engineering projects altering upstream land cover
- Regional development strategies reallocating land between sectors
#### Effects
- Shifted trade-offs between water supply, soil conservation, waste treatment
- Need for cross-regional ecological compensation mechanisms

### Telecoupling
#### Systems
- Distant ecosystem service supply areas and remote beneficiary regions
- National-scale ecological projects and faraway urban demand centers
- Global-scale climate and nutrient regulation systems
#### Flows
- Telecoupled ecosystem service flows of water, food, energy, materials
- Long-distance benefits from carbon sequestration and climate regulation
- Monetary and policy flows in ecological compensation schemes
#### Agents
- Central governments designing large ecological compensation programs
- Distant consumers of agricultural and forest products
- Researchers using telecoupling to analyze service networks
#### Causes
- Spatial mismatch between ecosystem service supply and demand
- Infrastructure projects like large water transfer systems
- Market demand and national development strategies
#### Effects
- Redistribution of ecosystem service benefits and burdens across distant regions
- Complex cross-scale trade-offs requiring telecoupling assessment
- Need to trace service flow paths, volumes, and temporal changes

### Cross-Coupling Interactions
- Multi-scale trade-offs where local land decisions affect regional and distant beneficiaries
- Ecosystem service flow networks linking intra-, peri-, and telecoupled systems
- Ecological compensation designed using results from cross-scale trade-off analyses

### Research Gaps or Limitations
- Limited methods for dynamic quantification and mapping of ecosystem service flows
- Weak integration of multi-scale trade-off knowledge into actual policy decisions
- Lack of unified, comparable frameworks linking trade-offs with ecological compensation

### Search Keywords
- ecosystem service trade-offs decision-making telecoupling
- ecosystem service flow multi-scale coupling ecological compensation
- scenario analysis multiobjective optimization ecosystem services

### Extraction Confidence
high
