# Environment-deterministic pedestrian behavior New insights from surveillance video evidence

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:10:45.256568+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Wei et al. - 2022 - Environment-deterministic pedestrian behavior New insights from surveillance video evidence.pdf
- Year: unknown
- DOI: 10.1016/j.cities.2022.103638
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study investigates how micro-scale physical features of urban public space shape pedestrian walking trajectories, using a waterfront site in Ningbo, China (the Old Bund) as a case. The geographic scope is strictly local, focused on one camera scene within a riverside promenade and adjacent square; there is no multi-region or cross-system telecoupling in the usual land-system sense.

The authors develop a standardized workflow to turn 24 hours of surveillance camera footage into accurate plan-view trajectories. They harmonize video formats, apply convolutional-neural-network-based detection and tracking, denoise tracks, and transform pixel coordinates into a common ground coordinate system using projective methods. Trajectory density is then calculated on a fine grid (about 0.9 m cells, close to adult stride length).

Four types of environmental elements are digitized: obstacles (pillars, streetlights), spatial boundaries (curbs, edges), attractors (river, entrances), and road midlines. These are converted into continuous distance-decay fields using kernel methods. The dependent variables are several forms of trajectory density, including kernel density and its logarithm. The authors estimate both global Ordinary Least Squares and local Geographically Weighted Regression models.

Results indicate that spatial variation in walking density can be explained to a striking degree by environment: in the best GWR model, up to about 71 percent of variation in log-transformed trajectory density is accounted for primarily by obstacles and road midlines. Midlines consistently increase trajectory density, while obstacles have location-dependent effects. In contrast, attractors do not significantly improve model performance at this micro-scale, suggesting that many visual or experiential attractors may influence behavior from outside the observed scene, or through preferred viewing positions rather than proximity.

The authors explicitly frame this as a possible telecoupling-like effect within pedestrian-environment interactions: distant or off-site features may exert nonlocal influences across scales, complicating simple local-force models. However, the work itself remains single-site and does not implement formal metacoupling analysis. Its main contribution to telecoupling discussions is conceptual, highlighting cross-scale and nonlocal perception effects in urban micro-behavior.

## Structured Metacoupling Extraction

### Coupling Classification
- Mainly intracoupling of pedestrians and micro-scale built environment; telecoupling hinted via distant visual attractors.

### Intracoupling
#### Systems
- Waterfront public space in Old Bund Ningbo with paths, riverside platform, and small square.
- Micro-scale pedestrian movement system within a single surveillance scene.
- Local built environment elements like road midlines, obstacles, boundaries, and near-field attractors.
#### Flows
- Pedestrian walking trajectories and density patterns across 0.9m grid cells.
- Information and perceptual cues from surrounding physical elements to pedestrians.
- Video-derived trajectory data transformed into orthophotographic coordinates.
#### Agents
- Individual pedestrians using the waterfront paths and square.
- Urban planners and designers interpreting trajectory-environment relations.
- Municipal management agency providing surveillance video data.
#### Causes
- Spatial configuration of obstacles, road midlines, boundaries, and attractors.
- Repulsive and attractive social forces predicted by the Social Force Model.
- Micro-scale built form of linear waterfront, pillars, streetlights, curbs, and river edge.
#### Effects
- Up to seventy percent of local trajectory density explained by obstacles and road midlines.
- Pedestrians tend to walk near midlines; obstacles show mixed local effects.
- Attractors show weak local influence, suggesting scale-dependent behavior mechanisms.

### Pericoupling
#### Systems
- Not identified.
#### Flows
- Not identified.
#### Agents
- Not identified.
#### Causes
- Not identified.
#### Effects
- Not identified.

### Telecoupling
#### Systems
- Local pedestrian scene and visually distant environmental attractors.
- Small study area and broader urban context influencing destination choices.
#### Flows
- Perceptual influence from distant scenery or signage beyond the modeled grid.
- Behavioral responses to attractors located outside the surveillance frame.
#### Agents
- Pedestrians reacting to off-site visual stimuli like billboards or distant river views.
- Designers considering nonlocal attractors when planning micro-scale spaces.
#### Causes
- Attractors affecting pedestrians from distances larger than the study scene.
- Impulse stops and viewing behaviors not requiring proximity to attractors.
- Concept transfer of telecoupling from human–land research to pedestrian behavior.
#### Effects
- Local models underestimate attractor influence because effects extend beyond scene boundaries.
- Possible over- and underpredictions near edges where off-site influences matter.
- Need to consider larger perceptual fields when modeling micro-scale walking patterns.

### Cross-Coupling Interactions
- Scale-dependent interaction where local obstacle effects dominate, but distant attractors telecouple behavior.
- Micro-scale deterministic patterns coexist with broader cognitive maps shaped by citywide elements.

### Research Gaps or Limitations
- Single-site micro-scale case; generalizability to other spaces and densities remains unclear.
- Camera occlusion, edge distortion, and truncated trajectories reduce data completeness near boundaries.
- Telecoupled attractor ranges and appropriate spatial scales are not empirically delineated.

### Search Keywords
- micro-scale pedestrian trajectories and physical environment
- social force model obstacles road midlines GWR
- telecoupling visual attractors waterfront public space

### Extraction Confidence
high
