# The geography of international conservation interest in South American deforestation frontiers

Siyu Qin $^{1}$ Tobias Kuemmerle $^{1,2}$ Patrick Meyfroidt $^{3,4}$ Mariana Napolitano

Ferreira<sup>5</sup> | Gregorio I. Gavier Pizarro<sup>6</sup> | Maria Eugenia Periago<sup>7</sup>

Tiago N.P. dos Reis<sup>3,8</sup> | Alfredo Romero-Muñoz<sup>1</sup> | Alberto Yanosky<sup>9</sup>

<sup>1</sup>Geography Department, Humboldt-University Berlin, Berlin, Germany   
$^{2}$ Integrative Research Institute on Transformations of Human-Environment Systems (IRI THESys), Berlin, Germany   
<sup>3</sup> Earth and Life Institute, UC Louvain-la-Neuve, Belgium   
Fonds de la Recherche Scientifique F.R.S.-FNRS, Brussels, Belgium   
$^{5}$ Science Program, WWF-Brasil, São Paulo, SP, Brazil   
$^{6}$ Biological Resources Institute, National Agricultural Technology Institute, Argentina   
Fundación Vida Silvestre Argentina, Buenos Aires, Argentina   
8 Trase, Global Canopy, Oxford, UK   
<sup>9</sup> Guyra Paraguay—CONACYT, Asunción, Paraguay

# Correspondence

Siyu Qin, Geography Department, Humboldt-University Berlin, Unter den Linden 6, 10099 Berlin, Germany. Email: siyu.qin@geo.hu-berlin.de

# Abstract

International funding is increasingly important in supporting conservation in mega-biodiverse countries. However, it remains unclear which donors invest in which conservation objectives and where, making it difficult to identify gaps and key actors to influence. Here we identified 1947 foreign-aided conservation projects in South America's major deforestation frontiers and summarized their objectives and interventions over time and space. We found that conserving nature for its own sake and for ecosystem services remained key objectives, but the types of interventions varied considerably over time. Geographically, international conservation prioritized moist forests over drier biomes, despite equally high deforestation risk. Different donor groups emphasized specific objectives and interventions that reflected socioecological links (e.g., bird migration, colonial history) between donating and receiving regions, as well as the donors' values (e.g., iconic/endangered species, human rights). These telecoupled patterns provide both opportunities and barriers for conservation and have implications for conservation prioritization strategies.

# KEYWORDS

Amazon, Atlantic forest, biodiversity conservation, Caatinga, Cerrado, foreign aid, funding, Gran Chaco, Pantanal, telecoupling

# 1 | INTRODUCTION

Despite being essential to achieving the UN Sustainable Development Goals, biodiversity and its multiple contributions to people have recently declined drastically (IPBES, 2019). This decline has triggered widespread and varied conservation responses (Adams, 2019; Mace, 2014). While conservation has initially been local and within individual countries, international initiatives spanning across nations have become increasingly important (Boillat et al., 2018; Kuemmerle et al., 2019; Miller, 2014). International conservation funding spent from developed to developing countries now roughly matches domestic conservation spending of developing countries (Waldron et al., 2013), with more funding to be mobilized for post-2020 conservation plans (Deutz et al., 2020). It is therefore important to understand where such international conservation interests and funding has focused on, what the rationales behind funding decisions are (i.e., areas to invest, conservation objectives, and envisioned interventions), and how conservation funding could be better channeled to regions in need.

National-level analyses found that international conservation investments were linked to biodiversity value, environmental and development needs, and governance and political factors of the receiving countries (Miller, 2014; Miller et al., 2013; Reed et al., 2020). However, our understanding of the spatial-temporal patterns of international conservation interests remains partial in at least three aspects. First, while existing studies often emphasized conservation funding's response to and impacts on biodiversity loss or deforestation (Bare et al., 2015; Miller et al., 2013; Reed et al., 2020), conservation efforts have diversified considerably over time to encompass a wide range of objectives, such as ecosystem services, sustainable livelihoods, or Indigenous rights (Pizarro Gariazzo, 2012; Mace, 2014). Second, previous analyses have focused on funding distribution at the national or ecoregion level (Castro & Locker, 2000; Miller et al., 2013; Strelneck & Vilela, 2017), or within certain types of interventions, such as Protected Areas or REDD+ (de Oliveira & Bernard, 2017; Skutsch & Turnhout, 2018). Existing work thus, falls short of understanding the distribution of international funding at scales that match conservation objectives. Finally, while often described and analyzed as "global responses," international conservation responses to biodiversity loss or environmental degradation in one place often originate from certain distant places with their own social-ecological characteristics, including values and interest of actors, or access to information (Kuemmerle et al., 2019). Such relations between the origin and target places of conservation funding are an example of "telecouplings"

(Hull & Liu, 2018; Kuemmerle et al., 2019). Understanding telecouplings can help contextualize donor motivation and preferences, and to identify the key actors to influence. Overall, a higher thematic and spatial resolution and consideration of donor-recipient relations would provide a better understanding of international conservation funding.

Specifically, we explore how multiple donors collectively shape the international conservation funding landscape in four South American countries that overlap major deforestation frontiers. We ask:

1. What are the trends in conservation donors, objectives, and interventions related to foreign conservation funding committed to South America's deforestation regions?   
2. What are the geographic patterns of this conservation funding by objectives, interventions, and donor origins?   
3. How does the emphasis on different objectives, interventions, and areas differ among donor origins?

# 2 MATERIALS AND METHODS

# 2.1 Study area

Our study focused on the South America biomes facing major commodity deforestation in the past decades (Curtis et al., 2018) (Figure S1). These tropical forests and savannas host high biodiversity (Jenkins et al., 2013) and large amounts of carbon (Avitabile et al., 2016). Indigenous and local communities also critically depend on these ecosystems (Schwartzman Gasparri, 2016; Stephan et al., 2013). The regions share a similar social-ecological and historical setting (e.g., long colonial history, state-supported agricultural expansion, land speculation, illegal deforestation [Mares, 1986; Hecht & Cockburn, 2010; Schwartzman et al., 2010; Gasparri, 2016; Oliveira & Hecht, 2016; Piquer-Rodriguez et al., 2018]). Likewise, the impacts of deforestation on biodiversity, carbon emissions, and local livelihoods are present across the region. Despite these similarities, different subregions have attracted varied levels of international conservation interests: the Amazon basin has received 2.57 billion USD in funding between 2003 and 2015 (de La Mata & Riega-Campos, 2014; Strelneck & Vilela, 2017), mainly from bilateral donors (Strelneck & Vilela, 2017), while the Gran Chaco has been comparatively neglected (Kuemmerle et al., 2017). Moreover, it remains unclear how conservation objectives related to funding flows have changed over time and how funding is distributed within regions (Hecht & Cockburn, 2010; Strelneck & Vilela, 2017).

# 2.2 Database of international conservation funding

We used data on bilateral and multilateral public funding for conservation-related projects to approximate international conservation interest. We extracted data from AidData's Core Research Release (v3.1), which compiles project-level development aid committed by 96 donors (sovereign countries and international institutions) between 1947 and 2013 (AidData, 2017; Tierney et al., 2011). We restricted the search to funding received by Argentina, Bolivia, Brazil, Paraguay, or recorded as sent to the South American Region, and queried the database with a list of conservation-relevant keywords (and translations) related to biodiversity and ecosystem services, as well as Indigenous land rights, considering the role of Indigenous stewardship in conservation (Garnett et al., 2018; Miller et al., 2013) (Table S1). This search yielded 6355 records. By reviewing the project titles and descriptions, we selected projects that supported one or more of the four countries and that suggested biodiversity conservation as either an objective, approach, or outcome (see Supporting Information). This yielded 1947 records from 33 bilateral and multilateral donors between 1975 and 2013, which composed the dataset for our analyses.

# 2.3 | Establishment of the geospatial and thematic database of conservation funding

Based on the project titles and descriptions, we inductively coded 42 objectives (e.g., general biodiversity, species, carbon/climate, freshwater, Indigenous rights, etc.), then grouped the objectives into six categories: conservation of nature itself (Conservation), conservation and sustainable use of ecosystem services (Ecosystem Services), improving production/productivity (Production), development (Development), land and human rights (Rights), and general conservation/environment/sustainability (General). Similarly, we identified 58 interventions in nine categories: area-based governance (AreaProtection), management of land and resources (Management), sustainable use and activities (Activities), incentives (Incentives), interventions focusing on environmental and Indigenous rights (Rights), enabling conditions and empowerment (Enabling), inclusiveness and transparency of decision-making process (Process), improving science, knowledge, and data (Data), and other general/unspecified interventions (General) (see Supporting Information for the full list of objectives and interventions and the categorization).

Based on the description of the projects' areas of interest, we categorized nine types of areas: Protected Areas (PA), administrative units (Admin), Habitat, hydrologi

cally defined regions (Hydro; e.g., basins, river deltas), ecologically defined regions (Eco, e.g., ecoregions, ecosystems), zoning units (Zoning), Indigenous people and Indigenous lands (ILs), other types of area-based governance (Other), and unknown/undefined areas (Unknown). When possible, we linked the projects with the geographic boundaries of these areas of interest, to further map the spatial distribution of international conservation interest by objectives, interventions, and donor origins. A full description of the mapping process is provided in the Supporting Information. We were able to map the area of interest of 1160 projects and focused the spatial analysis within the tropical forest, shrublands, and savanna biomes of the four countries (Figure S1).

# 2.4 | Analyzing patterns of international conservation funding

To assess trends over time, we calculated the percentage of projects that mentioned each category of objectives and interventions annually. For geographic patterns, we summed the total number of projects, the number of donors, and the amount of funding/km² potentially targeting a given area of interest. We then mapped the number and percentage of projects of some major themes of objectives (Biodiversity and Species under the Conservation category; Climate/Carbon and Water under Ecosystem Services) and interventions (Ecological Production and Restoration under Activities) as well as from different major donors (see Supplemental methods). We further linked the objective and intervention categories with the type of areas. To compare donor interests, we assessed the number of projects by donors (grouped by the origin of donors) within each objective category, intervention category, and major objective and intervention themes mentioned above. We then combined donor preferences with the trends and geographical distribution to discuss telecoupled patterns.

# 3 | RESULTS

# 3.1 National-level trends

The number and percentage of conservation-related projects increased from 10 projects (1% of all foreign aid projects) per year in 1990 to 130-245 projects (3.6-4.6%) per year in the early 2010s (Figure S2). Multilateral donors funded about $20\%$ of the projects in the 1990s, and $\sim 10\%$ in the 2000s, as bilateral donors became more active (Figure 1a). Recipient-wise, Brazil and Bolivia hosted most internationally funded projects, while the share of such projects in Argentina increased, especially after 2000 (Figure 1b).

![](images/3209e378fce80a23c835b76d89c5881ef9e72e83b991f926357ecf502d3e9e56.jpg)

![](images/bedea748d95bce689c668013b857c744ff2976bb09f9caa2056a31548983d2ef.jpg)

![](images/30eb893901ac5175d77dddb15327400bab1af572536d98d0531ce288b6a71d5f.jpg)

![](images/60290ff66b9ae53944aeb10575e43b1d450f2f4e84290226e76e9f80a0362b18.jpg)  
FIGURE 1 The proportion of projects per year categorized by (a) donors, (b) recipients, (c) objectives, and (d) interventions. Note: Percentages in (c) and (d) can be $>100\%$ as one project may mention multiple objectives or interventions

Conservation and Ecosystem Services were the most mentioned objective categories (40–50% projects annually) (Figure 1c). Objectives under the Development and Rights categories were mentioned by more projects after 2003 (+20–30% annually). In contrast, Production became less popular, dropping from about 30–5% per year. Among interventions (Figure 1d), Enabling, Activities, Data, and land/resources Management received the most support, while right-related interventions (Rights) were mostly neglected. Interest in area-based protection (AreaProtection) fluctuated, with a recent downward trend. Incentive-based approaches increased recently.

# 3.2 | Geographic patterns

The Amazon region in Brazil attracted the most donor attention, receiving funding from 16 or more donors out of 33 in total (Figure 2a). Other hotspots with high numbers of donors included the Bolivian Yungas and the Atlantic Forest in Brazil. Fewer donors funded conservation-related projects in dry forests and savannas across all countries. We observed no clear tendency toward targeting or avoiding commodity-driven deforestation. Many projects also

focused on the Bolivian Yungas and the Brazilian Amazon, particularly protected areas/Indigenous lands in the region (Figure 2b). The distribution of funding also showed a general focus on these hotspots, but considerable funding also went to the Pantanal ecoregion and some Brazilian states (Acre, Rondônia, Tocantins, Ceará, and Santa Catarina) through large multilateral development projects (Figure 2c).

The Andes and Amazon regions received more projects that considered Development and Rights as objectives, while funding in the Cerrado and Paraguay focused mainly on nature Conservation and Ecosystem Services, but rarely on Development objectives (Figures 3a and S4a). Interventions focused on Enabling were supported mainly in emerging deforestation frontiers, while interventions related to Activities tended to be in already heavily transformed areas. Interventions related to Rights occurred mainly in northern Bolivia (Figures 3b and S4b). Geographic patterns also differed between Conservation objectives emphasizing biodiversity versus species, between Ecosystem Services objectives emphasizing climate/carbon versus water, and between Activities promoting ecological production versus restoration approaches (Figures 3c and S4c). Finally, while most donors focused on the

![](images/9c3140c903586961e8b8a216f9247c434ab8690bb85ed32388aba64bf51c8487.jpg)

![](images/af03592ef00690e492fe6049cd1cfd15a8d5dc01f07eb4ab1bad9d0e061bdac5.jpg)

![](images/7d401a3df42fdd3b797427729e98b417e317b77796d899202ffaa59e6c727bee.jpg)  
FIGURE 2 International conservation interest in the study area indicated by (a) number of donors, (b) number of projects; (c) $\mathrm{USD / km^2}$ , from 1980 to 2013, with additional spatial references showing (a) tropical and subtropical moist broadleaf forest biome (light gray line shaded area) and regions experiencing mainly commodity-driven deforestation (black line shaded area); (b) terrestrial protected areas [including Indigenous lands meeting PA standards] (poygons with light-gray boundaries); and (c) administrative boundaries of states and provinces (thin white lines). Data sources: WWF (biomes), Curtis 2018 (drivers of deforestation), UNEP-WCMC (World Database of Protected Areas), and GADM (administrative boundaries)

![](images/9785335b826219006c95cd1bb624b5e5157e49ddd0ea42560e42d7c4a63e398e.jpg)  
FIGURE 3 The relative importance of different (a) objectives (by category), (b) intervention (by category), (c) themes, and from (d) different donors. The colors indicate the percentages of projects mentioning certain objectives/interventions/themes or from a given donor, comparing to the total number of projects expressing interest covering the map location

![](images/c08b3061e65c4fd20a625af4b97ad0e78fb2124bb50e0aa07a84b23baaa51a96.jpg)  
FIGURE 4 The connection between (a) the objectives and (b) interventions and the types of areas targeted by international funding. The width of the flow indicates the number of projects mentioning both the objectives/intervention and the type of area. Note: The total count of project shown in the graph is larger than the sample size (1947) as one project can mention multiple objectives/interventions/types of area

Brazilian Amazon, Spain primarily funded projects in Bolivia, Argentina, and Paraguay, and the United States funded over $50\%$ of the projects in Paraguay. Global Environmental Facility (GEF) funded projects were more evenly distributed, filling the gap of bilateral funding in drier biomes (Figures 3d and S4d).

International funding saw PAs mainly as places for reaching Conservation objectives, as well as Ecosystem Services and Development objectives (Figure 4a). Projects supporting Indigenous people and their lands were mostly for Rights and Development objectives. Zoning units were the least mentioned type of area. A variety of interventions were mentioned with each area type (Figure 4b). PAs were mostly mentioned when area-based protection were promoted. Indigenous lands were sometimes mentioned as the means of conservation (Area-based), but more often as project areas for enabling, land/resource management, sustainable use and activities, and rights interventions. Note that area categorizations can overlap spatially; hence, this categorization reflects the kinds of system boundaries that are seen relevant when focusing on certain objectives and interventions.

# 3.3 | Donor's interest in different objectives and interventions

Different donors lead on different thematic interests (Figure 5). North American donors focused primarily on Conservation objectives ( $n = 352$ projects; $76\%$ of projects from North American donors), especially for specific species groups (Species) (94; $20\%$ ), with migratory birds being the main target (51; $11\%$ ). Species conserva

tion was the sole objective of the only Western Asian donor (United Arab Emirates, 24, $100\%$ ). Western European countries' interest in Conservation (327; $50\%$ of Western Europe funded projects) emphasized general biodiversity (208; $33\%$ ) more than species (13; $2\%$ ). They also focused on Ecosystem Services (248; $38\%$ ), especially those provided by forests (101; $16\%$ ) or related to carbon/climate (59; $9\%$ ). Southern Europe focused more on Development objectives (156; $39\%$ of Southern Europe-funded projects), and Activities interventions (133; $33\%$ ). Northern Europe showed a strong commitment to Indigenous and local community rights (Rights) in both objectives (85; $45\%$ of Northern Europe-funded projects) and interventions (13; $7.3\%$ ). Multilateral institutions provided above-average support to protected areas and other area-based conservation approaches (AreaProtection) (46; $26.6\%$ of multilateral-funded project). Different group of donors also show distinct combinations between the objectives and interventions, and the types of areas they target (Figure S5).

# 4 | DISCUSSION

Our study focused on the initial steps of the funding flow—when funding is committed—to show where funding was intended to flow to and for which objectives and interventions. The results contribute insights to the geography of international funding in South America's deforestation frontiers, providing the first detailed map of where and what international conservation funding has been targeting. We also unraveled the interest of donors from different origins, which allowed us to identify the linkages and motivations connecting the donating and receiving

![](images/6cf4ec7e32f60a6f56e4bca226b272c8659a10264e4a7640abaf0ebacb2d8456.jpg)  
FIGURE 5 Count of projects from each donor region distributed across (a) objective categories, (b) intervention categories, and (c) themes

social-ecological systems, to identify opportunities and obstacles for financing conservation.

Intrinsic values and ecosystem services remain the primary motivation for international conservation donors. The growing emphasis of international funding on rights and development in our study area echoes the narrative shift in global conservation research and policy from "nature for itself" and "nature for people" toward "people and nature" (Mace, 2014), although rights-related projects remain in the minority, mirroring global patterns (RFN, 2021). Foreign donors' interest in different interventions varied more considerably over time, with investments in certain interventions waxing and waning, likely in relation to domestic political opportunities (Radeloff et al., 2013). In line with global trends (Wunder et al., 2018), our analysis also showed an emerging interest in using incentive and supply-chain approaches for conservation in the region. More generally, profiles of donor interests illustrated pluralistic views on what matters and what works (Pascual et al., 2021), even within the mainly western donors, which underscores the need for further analysis to identify and resolve the potential mismatches between international interests and domestic/local needs in places receiving funding. Combining with more accurate tracking and reporting of funding flows, network analyses of financing, implementing, and receiving agencies can further shed light on how actors interact to shape each other's preference and the funding distribution.

Assessments of international conservation funding to-date have focused on national-scale data (Miller, 2014; Reed et al., 2020), and here we provide the fine-scale anal

Analysis of the geographical pattern of international conservation interest. This revealed a major bias toward rainforests, while dry forests and savannas received much less funding from international donors across the world, despite high pressure from commodity-driven deforestation (Curtis et al., 2018). Importantly, the lack of interest in dry forests and savannas is primarily in conservation projects aimed at ecosystem services or development objectives (Figures 3a and S3a), possibly due to knowledge gaps on the importance of dry forests for livelihoods and other ecosystem services (Blackie et al., 2014). It was less the case for species-level conservation (Figures 3c and S3c), as many endangered species and migratory birds (also) depend on drier forests and savannas (Somveille et al., 2013). In contrast, the Amazon and Andes—where most recognized Indigenous lands are located (LandMark, 2020)—received funding for multiple converging objectives including conserving nature, sustainable use of resources, human development, and rights. This contrast indicates that Indigenous and community lands—especially those not recognized by government yet—in tropical dry forests and savannas might have been particularly lacking support.

Donors' preferences showed a combination of common global interest (e.g., in conserving biodiversity and forest) and conservation telecouplings (i.e., specific combinations of distant donors, objectives, and target areas) (Kuemmerle et al., 2019). Some telecouplings can be explained by biophysical connections. For instance, migratory birds were the objective of $10\%$ of projects funded by North American donors but were not mentioned as a conservation objective by donors from other regions

of the world. Social and cultural ties are also important, as Spain primarily supported projects in former Spanish colonies, while other donors focused on Brazil (Figure 3d). Similar pattern was also observed in sub-Saharan Africa, where conservation NGOs tended to work in countries speaking the same language (Brockington & Scholfield, 2010). Finally, some linkages reflect donors' value preferences, such as the US's and UAE's support for iconic and endangered species, hence for certain habitats, or Northern Europe's emphasis on Indigenous rights, hence on Indigenous people and their lands. These patterns suggest that bilateral donor preferences can potentially be explained by biophysical and socioeconomic linkages, beyond political, or economic motivations as previously mentioned in development aid (Biscaye et al., 2017). Telecouplings may also explain overlooked regions or conservation issues. For instance, the lack of media coverage, and hence interest, in Europe, for certain regions (Mempel & Corbera, 2021) might contribute to the lack of bilateral conservation support in the Cerrado and Gran Chaco, despite rapid forest loss and land conflicts in these regions.

Our findings may encourage donors to reflect on their revealed biases (e.g., the remaining low consideration of rights and the neglected tropical dry forests and savannas), and support recipients navigating and shaping the donor preferences and leveraging the telecouplings to meet local conservation needs. The improved thematic and spatial resolution of intentional conservation interests can facilitate analyzing funding coverage and impacts in perspective with their claimed goals, and at a scale more relevant to conservation prioritization and outcomes. By moving beyond generalized perspectives on international funding, we can address the challenges and leverage the potentials of conservation telecouplings for more effective conservation.

# SUPPORTING INFORMATION

Additional supporting information may be found in the online version of the article at the publisher's website.

How to cite this article: Qin, S., Kuemmerle, T., Meyfroidt, P., Ferreira, M. N., Pizarro, G. I. G., Periago, M. E., dos Reis, T. N. P., Romero-Muñoz, A., Yanosky, A.. The geography of international conservation interest in South American deforestation frontiers. Conservation Letters. 2022;15:e12859. https://doi.org/10.1111/conl.12859
