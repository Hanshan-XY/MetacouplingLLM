# The dynamics of beef trade between Brazil and Russia and their environmental implications

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:04:37.201388+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Schierhorn et al. - 2016 - The dynamics of beef trade between Brazil and Russia and their environmental implications.pdf
- Year: unknown
- DOI: 10.1016/j.gfs.2016.08.001
- OA status: green
- License: other-oa
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: green OA without permissive license (other-oa)

## Copyright-Safe Summary
This paper analyzes how changing beef trade between Brazil and Russia emerged after the collapse of the Soviet Union and what this implies for land use and greenhouse gas emissions. Its geographic focus is Russia (as a beef importer) and Brazil, especially the Amazon and Cerrado regions (as producers and exporters). The study is explicitly framed as a telecoupling case: distant but tightly linked food systems and their environmental consequences.

Using time series from FAO, USDA, IBGE, Russian and Brazilian trade statistics, and prior literature, the authors reconstruct: (1) Russian beef production, consumption, and imports from the Soviet period to the 2010s; (2) Brazilian beef production, export growth, and spatial expansion; and (3) associated deforestation and greenhouse gas emissions. The work is largely a synthesis and quantitative review, not a single new model.

After 1991, Russian subsidies collapsed, cattle herds shrank, and beef production and consumption fell sharply. Economic recovery after 1998 restored meat demand, including higher quality beef in urban markets, but production did not recover, despite new policy support. Russia therefore became one of the world’s leading beef importers.

At the same time, disease crises and policy changes reduced export capacity from the EU, US, Argentina, and Ukraine. Brazil, benefiting from currency devaluation, veterinary improvements, new export infrastructure, and strong industry coordination, expanded beef output and exports. Its cattle frontier moved into the Cerrado and Amazon, driving large-scale pasture expansion, deforestation, and high CO2 and non-CO2 emissions. By the mid-2000s, Russia was the main buyer of Brazilian beef and thus the largest external recipient of these embodied emissions.

Later, Brazilian policies and supply-chain agreements curtailed Amazon deforestation while production intensified. Still, because Brazilian beef is more emission-intensive than Russian beef, importing from Brazil raises the climate footprint of Russian consumption.

The paper is directly about telecoupling/metacoupling, showing how a political shock in one country and global market shifts rewire trade networks, shift environmental burdens abroad, and complicate climate- and land-use policy.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via Brazil Russia beef trade with embedded emissions and land use change

### Intracoupling
#### Systems
- Russian domestic beef production and consumption system
- Brazilian cattle ranching and land use system
- Brazilian Amazon and Cerrado deforestation frontier
#### Flows
- Beef from Russian farms to Russian consumers
- Cattle and pasture expansion within Brazilian biomes
- Domestic policy incentives and subsidies within each country
#### Agents
- Russian government and agricultural ministries
- Brazilian ranchers and meatpacking firms
- Brazilian and Russian retail chains
#### Causes
- Post Soviet economic transition and subsidy removal in Russia
- Brazilian policies supporting cattle expansion and FMD control
- Domestic demand shifts for higher quality beef
#### Effects
- Russian cattle herd collapse and land abandonment
- Pasture expansion and intensification in Brazil
- National level greenhouse gas emission changes

### Pericoupling
#### Systems
- Russia and neighboring ex Soviet states beef exchanges
- Brazilian Amazon and adjacent Cerrado production shifts
- Russia Belarus Ukraine regional livestock trade
#### Flows
- Beef imports from Belarus and Ukraine to Russia
- Cattle and pasture relocation between Cerrado and Amazon
- Soy expansion displacing pasture toward forest frontiers
#### Agents
- Belarus state trading companies
- Ukrainian livestock exporters
- Regional farmers shifting between crops and pasture
#### Causes
- Russian sanitary bans on Ukrainian and EU livestock products
- Regional free trade arrangements with Belarus
- Relative profitability of soy versus cattle locally
#### Effects
- Increased Russian dependence on specific neighbors
- Indirect deforestation via pasture displacement
- Regional concentration of export oriented ranching

### Telecoupling
#### Systems
- Russian beef consumption and food security system
- Brazilian beef production and export system
- Global beef market including EU US Argentina
#### Flows
- Frozen and chilled Brazilian beef exported to Russia
- Embodied CO2 and non CO2 emissions in traded beef
- Capital knowledge and sanitary regulations shaping trade
#### Agents
- Brazilian Beef Exporters Association and meatpackers
- Russian importers retailers and policymakers
- International buyers responding to disease related trade bans
#### Causes
- Russian production shortfalls after Soviet collapse
- BSE and FMD related import restrictions on competing exporters
- Currency devaluations and improved Brazilian export conditions
#### Effects
- Russia becomes top importer of Brazilian beef emissions
- Pasture driven deforestation in Amazon and Cerrado
- Global redistribution of beef related climate impacts

### Cross-Coupling Interactions
- Global disease outbreaks shifted Russian sourcing from EU US to Brazil
- Russian trade embargo on Western food further redirected demand to South America
- Brazilian anti deforestation policies moderated but did not remove export pressure

### Research Gaps or Limitations
- No quantitative attribution of Russian demand share in Brazilian deforestation
- Uncertainty linking export statistics to exact cattle origin regions
- Need scenario analysis comparing Russian domestic beef expansion versus imports

### Search Keywords
- Brazil Russia beef telecoupling emissions deforestation
- Brazilian Amazon pasture expansion global beef trade
- embodied greenhouse gases in traded beef Russia

### Extraction Confidence
high
