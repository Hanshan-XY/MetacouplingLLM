# Understanding ecosystem service flows through the metacoupling framework

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:19:00.306640+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Zhang et al. - 2023 - Understanding ecosystem service flows through the metacoupling framework.pdf
- Year: unknown
- DOI: 10.1016/j.ecolind.2023.110303
- OA status: gold
- License: cc-by-nc-nd
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This article applies the metacoupling framework to understand how ecosystem services move within and beyond a river basin, focusing on the Huangshui River Basin on the northeastern Tibetan Plateau in China. The basin is treated as the focal system, the nearby Lanzhou-Xining urban agglomeration as the adjacent system, and the upper Yellow River Basin as the distant system. The work directly engages with metacoupling and telecoupling by differentiating intracoupling (within-basin flows), pericoupling (flows to adjacent areas), and telecoupling (flows to distant areas).

The authors analyze seven ecosystem services that have strong regional implications and are important for ecological compensation: water provision, climate regulation, waste treatment, hydrological regulation, erosion control, soil fertility maintenance, and cultural services. Using land cover maps (30 m), statistical yearbooks, and farm cost-benefit data for 2000 and 2020, they estimate ecosystem service values with a China-specific equivalent factor approach and then apply a gravity-type breaking point model to infer service flows between counties and between systems.

Results show that total ecosystem service flows declined over the two decades inside the basin and from the basin to both adjacent and distant systems. The largest reduction occurs in telecoupled flows to the distant upper Yellow River Basin, where average annual losses in service value exceed those to adjacent systems and within-basin flows. Regulating services dominate these declines, especially hydrological regulation, whose flow to distant areas falls more than 2.4 times faster than other regulating services. Attribution analysis indicates that reduced hydrological regulation mainly stems from loss of grassland cover in the focal basin, responsible for over 70 percent of the decline, rather than from changes in the distant system.

The study argues that distant downstream beneficiaries rely heavily on upstream regulation services, so ecological compensation and shared grassland protection schemes across basins are needed. It also highlights the value of the metacoupling framework for comparing ecosystem service flows across spatial interaction types and designing regionally coordinated sustainability policies.

## Structured Metacoupling Extraction

### Coupling Classification
- Strongly metacoupled case; analyzes intra, adjacent, and distant ecosystem service flows with one focal basin

### Intracoupling
#### Systems
- Huangshui River Basin counties as one coupled human natural system
- Internal service providing and benefiting areas within basin
- Urbanizing plateau basin sensitive to climate and human change
#### Flows
- Monetary-valued ecosystem service flows among basin counties
- Internal flows of water provision, regulation, and cultural services
- Net sending and receiving areas based on ecosystem service value
#### Agents
- County governments within Huangshui Basin
- Local residents, farmers, herders, urban populations
- Regional planners and environmental managers
#### Causes
- Grassland loss and land cover conversion inside basin
- Rapid urbanization and socio-economic growth in plateau basin
- Climate variability affecting hydrology and regulating services
#### Effects
- Decreased internal ecosystem service flows 2000 2020
- Reduced regulating services, especially hydrological and climate regulation
- Spatial reconfiguration of net providers and beneficiaries within basin

### Pericoupling
#### Systems
- Huangshui River Basin as focal system
- Lanzhou Xining urban agglomeration as adjacent system
- Counties in urban agglomeration as external service beneficiaries and providers
#### Flows
- Ecosystem service value outflows from basin to adjacent urban counties
- Reciprocal regulating and provisioning flows from adjacent system into basin
- Hydrological regulation and climate regulation dominating interregional exchanges
#### Agents
- Local and provincial governments coordinating urban agglomeration
- Water resource and environmental agencies across provinces
- Urban residents and industries benefiting from upstream services
#### Causes
- National policy promoting Lanzhou Xining urban agglomeration development
- Hydrological connectivity between basin and nearby urban areas
- Increasing regional demand for water and regulating services
#### Effects
- Decline in basin to adjacent ecosystem service flows over two decades
- Reduced climate regulation inflows from adjacent counties to basin
- Need for regional ecological compensation among neighboring jurisdictions

### Telecoupling
#### Systems
- Huangshui River Basin as upstream focal system
- Upper Yellow River Basin as distant system
- Downstream economic zones along Yellow River as key beneficiaries
#### Flows
- Large scale hydrological regulation and water related services to distant regions
- Monetary-valued ecosystem service outflows to distant Yellow River counties
- Increasing hydrological regulation inflows from distant headwater areas to basin
#### Agents
- National and provincial authorities along Yellow River
- Distant urban economic circles such as Yinchuan area
- Stakeholders in Three River Sources and Asian Water Tower region
#### Causes
- Natural river network linking Huangshui to upper Yellow River
- Global warming weakening cryosphere hydrological regulation
- Grassland degradation in focal basin reducing water regulation capacity
#### Effects
- Largest decline in regulating service flows toward distant system
- Heightened downstream flood and water security risks
- Need for cross basin grassland protection and payment mechanisms

### Cross-Coupling Interactions
- Metacoupling comparison reveals distant flows decline faster than adjacent and internal flows
- Grassland loss in focal basin simultaneously weakens intra, peri, and telecoupled hydrological regulation
- Distant systems urged to co finance upstream grassland protection following who benefits compensates principle

### Research Gaps or Limitations
- Breaking point model cannot fully capture complex biophysical service transport processes
- Adjacency and distance delineation partly subjective and focused mainly on hydrology
- Future work should apply explicit ecosystem service flow models and multi nexus criteria

### Search Keywords
- metacoupling ecosystem service flows Huangshui River Basin
- hydrological regulation grassland loss Yellow River telecoupling
- ecological compensation adjacent distant systems plateau

### Extraction Confidence
high
