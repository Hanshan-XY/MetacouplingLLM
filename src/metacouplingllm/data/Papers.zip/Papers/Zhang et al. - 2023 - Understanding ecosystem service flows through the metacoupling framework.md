# Understanding ecosystem service flows through the metacoupling framework

![](images/6a63cab1d85d633e943427ee9ecb125862be9acaf737d2ef6779ce3aeb9b46e8.jpg)

Jinxi Zhang a,b,c,d, Chunyang He a,b,c,e,\*, Qingxu Huang b,d, Lei Li a,b,c,d

<sup>a</sup> Key Laboratory of Environmental Change and Natural Disasters of Chinese Ministry of Education, Beijing Normal University, Beijing 100875, China   
${}^{\mathrm{b}}$ State Key Laboratory of Earth Surface Processes and Resource Ecology (ESPRE),Beijing Normal University,Beijing 100875,China   
$^{\mathrm{c}}$ Academy of Disaster Reduction and Emergency Management, Ministry of Emergency Management and Ministry of Education, Beijing 100875, China   
$^{d}$ Faculty of Geographical Science, Beijing Normal University, Beijing 100875, China   
e Academy of Plateau Science and Sustainability, People's Government of Qinghai Province and Beijing Normal University, Xining, China

# ARTICLEINFO

Keywords:

Metacoupling

Ecosystem service flow across regions

Supply and demand

Ecological compensation

Sustainability

# ABSTRACT

Ecosystem service (ES) flow is an indispensable link between natural ecosystem and socioeconomic system. Research on ES flow is of great significance for regional ecosystem management and ecological compensation policies. However, previous studies have mainly focused on ES flow within a region or ES flow across regions, without distinguishing the relationship between ES flow within a region and ES flow from the region to its external regions. Therefore, taking the Huangshui River Basin in the Tibetan Plateau as an example, we combined the revised equivalent factor method and the breaking point model to analyze the ES flow within the basin and ES flow between the basin and its external regions (including adjacent and distant systems) under the metacoupling framework. The results showed that ES flow within the basin, ES flow to adjacent systems and ES flow to distant systems decreased from 2000 to 2020. ES flow to distant systems decreased the most, with an average decrease of 666 million yuan. Moreover, among different ESs, the decrease in hydrological regulation flow to the distant system was the most substantial, at least 2.4 times that of other ESs. Grassland loss in the basin was the main reason for the decrease in hydrological regulation flow to distant systems. Therefore, we suggest that future ecosystem conservation in the basin needs the participation of distant systems to ensure the ESs provided to them. Following the basic principle of "who benefits, who compensates", distant systems that benefit can establish the grassland ecological compensation mechanisms to maintain the hydrological regulation service flowing to them, thereby ensuring water security and promoting sustainable development.

# 1. Introduction

Ecosystem service (ES) flow refers to the spatiotemporal connection between service providing areas (SPAs) and service benefiting areas (SBAs), which is an indispensable link between natural ecosystem and socioeconomic system (Bagstad et al., 2013; Bagstad et al., 2014; Serna-Chavez et al., 2014). In general, ES flow is not limited to local areas and often exists as a transregional phenomenon (Xie et al., 2019; Semmens et al., 2018). In other words, there is a mismatch between SPAs and SBAs in time and space. This spatiotemporal mismatch leads to the spatial flow of ES (Pascual et al., 2017). Driven by intensive globalization, increasing human and natural interactions are occurring between geographically, culturally, and institutionally distant systems, and

across local, regional, national, and global scales (Sun, 2023; Xu et al., 2020). This means that the scope of ES flow is increasing, and the impact of ES flow is becoming increasingly evident (Ouyang et al., 2020; Xie et al., 2019; Zhu et al., 2022). Therefore, ES flow research is of great significance to promote regional sustainable development and has become one of the emerging directions of ES research.

Recently, some studies have quantified the ES flow within a region or ES flow across regions. In terms of the ES flow within the region, Li et al. (2017) quantified the freshwater ecosystem service flow within the Beijing-Tianjin-Hebei urban agglomeration in China. Wang et al. (2021) analyzed multiple regulating service flows within the Yangtze River Delta region in China. He et al. (2019) evaluated the cultural ecosystem service flows (aesthetic service and recreational service) of farmlands

E-mail address: hcy@bnu.edu.cn (C. He).

within Hangzhou, China. In terms of transregional ES flow, Kleemann et al. (2020) analyzed the flood regulation service flow between Germany and the surrounding areas. Xie et al. (2019) quantified the various ES flows from Inner Mongolia to the surrounding provinces of China. In summary, existing studies have made significant contributions to the spatial flow of different types of ESs (provisioning services, regulating services and cultural services) within or across regions. However, these studies did not distinguish the relationship between the ES flow within a region and ES flow from the region to its external regions. This is not conducive to targeted ecosystem management in different regions.

Metacoupling provides an effective theoretical framework for a comprehensive and systematic understanding of ES flows (Liu, 2017). The metacoupling framework is used to integrate human and natural interactions within a system (intracoupling), between adjacent systems (pericoupling), and between distant systems (telecoupling). The framework was developed on the basis of the telecoupling framework. In 2013, Liu et al. (2013) proposed a telecoupling framework to describe the socioeconomic and environmental interactions between distant human and natural coupling systems. For example, Zheng et al. (2013) analyzed the social, economic, and environmental impacts of the "Paddy Land to Dry Land" program on the upstream and downstream of the Miyun Reservoir in China through the telecoupling framework. In the telecoupling framework, there are a series of interrelated human and natural coupling systems that are connected by the flow between them (Liu et al., 2013). According to the direction of the flow, the coupling systems can be divided into sending system, receiving system, and spillover system. In the field of ES, the sending system can be regarded as a SPA and the receiving system as a SBA. The flow flows out of the SPA, while the SBA obtains the flow from the SPA. Currently, the telecoupling framework has been improved to the metacoupling framework, with the addition of the pericoupling and intracoupling. Herzberger et al. (2019) analyzed the global food trade flow through the metacoupling framework. This framework can more comprehensively analyze the ES flows at different spatial scales, including the ES flows within the region, as well as the ES flows between the region and adjacent and distant systems. Therefore, the metacoupling framework has great potential to comprehensively evaluate ES flows.

The innovation of this study is to analyze the ES flow using the metacoupling framework, taking the Huangshui River Basin in the Tibetan Plateau as an example. First, we delimited the adjacent and distant systems of the Huangshui River Basin. Then, we combined the revised equivalent factor method and the breaking point model to quantify the ES flows within the basin (intracoupling), the ES flows between the basin and its adjacent system (pericoupling), and the ES flows between the basin and its distant system (telecoupling) from 2000 to 2020. The findings can provide a scientific basis for regional ecosystem management and ecological compensation policy formulation.

# 2. Study area and data

# 2.1. Study area

The Huangshui River Basin is located in northwest China with a total area of $16100\mathrm{km}^2$ $(100^{\circ}42^{\prime}\mathrm{E} - 103^{\circ}01^{\prime}\mathrm{E}$ and $36^{\circ}02^{\prime}\mathrm{N} - 37^{\circ}28^{\prime}\mathrm{N})$ (Fig. 1). The elevation of the basin is between 1548 and $4863\mathrm{m}$ . The basin has a plateau semiarid continental climate. The annual average temperature is $3.4^{\circ}\mathrm{C}$ , and the annual average precipitation is approximately $430\mathrm{mm}$ , mainly from June to September (Zhang et al., 2013). In this basin, the land cover types are mainly grassland and cultivated land, accounting for $57.9\%$ and $32.2\%$ of the total area, respectively.

The basin includes 9 counties. Among them, there are 3 counties with a total population of less than 0.2 million, 5 counties with a total population of between 0.2 and 0.5 million, and 1 county with a total population of more than 0.5 million, Xining. According to statistics, the total population and GDP of the basin in 2019 were approximately 3.68 million and 172 billion yuan, respectively.

The adjacent system of the basin is the Lanzhou-Xining urban agglomeration, which includes 21 counties. In March 2018, the Chinese government planned to build the urban agglomeration. As Xining is located in the basin, the basin plays a vital role in the high-quality development of the urban agglomeration. The distant system of the basin is the upper Yellow River Basin, including 59 counties. The Huangshui River is the largest tributary of the upper Yellow River, supporting the sustainable development of the upper Yellow River Basin.

The basin is located on the Tibetan Plateau, providing important ecosystem services (such as water supply) for itself and its downstream areas. This makes the basin suitable for analyzing the ES flow under the metacoupling framework. Driven by the Belt and Road Initiative, the basin has become a typical rapid urbanization basin in the Tibetan Plateau. From 2000 to 2018, the urbanization rate of the basin increased from $30.9\%$ to $49.6\%$ , higher than the average level of the Tibetan Plateau $(44.0\%)$ . Moreover, the basin is highly sensitive to human activities and climate change. Under the pressure of human activities and climate change, the interaction between the natural ecosystem and socioeconomic system in the basin has intensified, leading to a series of problems such as the tension between water supply and demand, which seriously affects the sustainable development of the basin itself and its downstream areas. Previous studies have found an imbalance between supply and demand of water supply and water purification services in the basin (Zhan et al., 2021; Xia et al., 2022). However, there is still a lack of research on ES flow.

# 2.2.Data

We primarily used three types of data from 2000 and 2020 (Table 1). The first type of data was land cover data. The second type of data was basic geographic information data, including administrative boundary data, river data and digital elevation model (DEM). The third type of data was statistical data, including the Statistical Communique on National Economic and Social Development of Xining and Haidong, as well as the National Farm Product Cost-benefit Survey data.

# 3. Methods

# 3.1. Metacoupling framework

In this study, we used the metacoupling framework to understand ES flows (Fig. 2). Specifically, we regarded the Huangshui River Basin as the focal system and the Lanzhou-Xining urban agglomeration and the upper Yellow River Basin as the adjacent system and distant system of the basin, respectively. The main reason why the Lanzhou-Xining urban agglomeration can be regarded as the adjacent system of the basin is that the Chinese government has vigorously promoted the construction of the urban agglomeration. This positive promotion makes the basin closely linked with the urban agglomeration. There are two main reasons why the upper Yellow River Basin can be regarded as the distant system of the basin. First, there is a natural hydrological connection between the basin and the upper Yellow River Basin (Fig. 1). As the largest tributary, the Huangshui River delivers an average of 4.476 billion cubic meters of flowing water to the upper Yellow River annually and is one of the main sources. Second, the demand for water resources in a region can generally be met within $500\mathrm{km}$ (McDonald et al. 2014). The distance between the basin and the upper Yellow River Basin is approximately $500\mathrm{km}$ . Subsequently, we analyzed the ES flows within the basin, then analyzed the ES flows between the basin and its adjacent system, and finally analyzed the ES flows between the basin and its distant system.

Our method consisted of three parts. In the first part, we combined the revised equivalent factor method and the breaking point model to quantify the ES flows within the basin. On this basis, in the second and third parts, we used the breaking point model to quantify the ES flows

![](images/bf61957feeb86c7b4db195794f4125e3ffde1a6448cc3add293189d824b1f246.jpg)

![](images/b386eef8a009bd297eb52714dca1f96d2e5c250c0f6ac935768214734fece685.jpg)  
Fig. 1. The Huangshui River Basin. Note: County code: 1. Gonghe; 2. Guinan; 3. Guide; 4. Jianzha; 5. Tongren; 6. Hualong; 7. Xunhua; 8. Jishishan; 9. Yongjing; 10. Linxia; 11. Dongxiang; 12. Lintao; 13. Dingxi; 14. Yuzhong; 15. Lanzhou; 16. Yongdeng; 17. Gaolan; 18. Baiyin; 19. Jingyuan; 20. Pingchuan; 21. Jingtai; 22. Maduo; 23. Maqin; 24. Dari; 25. Gande; 26. Jiuzhi; 27. Maqu; 28. Ruoergai; 29. Luqu; 30. Henan; 31. Tongde; 32. Xinghai; 33. Zeku; 34. Xiahe; 35. Hezuo; 36. Zhuoni; 37. Minxian; 38. Lintan; 39. Kangle; 40. Guanghe; 41. Hezheng; 42. Linxia; 43. Tianjun; 44. Gangcha; 45. Menyuan; 46. Tianzhu; 47. Huining; 48. Guyuan; 49. Haiyuan; 50. Gulang; 51. Wuwei; 52. Yongchang; 53. Jinchang; 54. Minqin; 55. Alxa Youqi; 56. Alxa Zuoqi; 57. Zhongwei; 58. Zhongning; 59. Wuzhong; 60. Qingtongxia; 61. Yongning; 62. Yinchuan; 63. Helan; 64. Pingluo; 65. Shizuishan; 66. Huinong; 67. Wuhai; 68. Tongxin; 69. Lingwu; 70. Otog Qianqi; 71. Otog Qi; 72. Hanggin Qi; 73. Dalad Qi; 74. Urad Qianqi; 75. Wuyuan; 76. Bayan Nur; 77. Hanggin Houqi; 78. Dengkou; 79. Urad Houqi; 80. Urad Zhongqi.

Table 1 The data used in this study.   

<table><tr><td>Category</td><td>Data</td><td>Resolution</td><td>Source</td></tr><tr><td>Land cover data</td><td>Land cover data</td><td>30 m</td><td>National Geomatics Center of China https://www.globallandcover.com/</td></tr><tr><td rowspan="3">Basic geographic information data</td><td>Administrative boundary data</td><td>-</td><td>National Geomatics Center of China https://www.ngcc.cn/ngcc/</td></tr><tr><td>River data</td><td>-</td><td>National Geomatics Center of China https://www.ngcc.cn/ngcc/</td></tr><tr><td>DEM</td><td>30 m</td><td>Geospatial Data Cloud https://www.gscloud.cn/</td></tr><tr><td rowspan="2">Statistical data</td><td>Statistical Communique on National Economic and Social Development</td><td>-</td><td>China National Knowledge Infrastructure https://www.cnki.net/</td></tr><tr><td>National Farm Product Cost-benefit Survey</td><td>-</td><td>China National Knowledge Infrastructure https://www.cnki.net/</td></tr></table>

between the basin and its adjacent system and between the basin and its distant system, respectively (Fig. 3).

# 3.2. Quantifying the ES flow within the basin

# 3.2.1. Calculating the ESV

ESs are generally divided into provisioning services, regulating services, supporting services and cultural services. Constanza et al. combined ecology and economics to quantify the ESV and proposed the value equivalent coefficients table of ES per unit area (Sutton and Costanza, 2002). Xie et al. proposed the value equivalent coefficients table of ES per unit area in China according to a questionnaire survey of 200 Chinese ecologists (Xie et al., 2003). In 2017, Xie et al. revised the value equivalent coefficients table of ES per unit area in China based on the results of existing studies and the spatial-temporal distribution of the net primary productivity of ecosystems, so it has some reliability (Xie

et al., 2017). In addition, this method can readily and effectively quantify different types of ESs and is widely accepted by the researchers (Gao et al., 2021; Su et al., 2020; Zhang et al., 2017; Niu et al., 2022).

Referring to the study of Xie et al. (2017), we adopted the revised value equivalent factor to calculate the ESV in the basin in 2000 and 2020. According to the study of Gao et al. (2021), seven ESs show regional impacts and should be included in the scope of ecological compensation. They are water provision services, climate regulation, waste treatment, hydrological regulation, erosion prevention, maintenance of soil fertility, and cultural services. In this study, we selected these seven ESs for analysis. Calculation of the ESV comprised three steps. First, we calculated the value of the standard equivalent factor according to the production of the main grain crops in the study area. The formula is as follows:

$$
D = S _ {w} \times F _ {w} + S _ {p} \times F _ {p} + S _ {c} \times F _ {c} \tag {1}
$$

where $D$ is the value of the standard equivalent factor in 2020 (yuan/ $\mathrm{hm}^2$ ), $S_w, S_p$ , and $S_c$ are the percentage of sown area of wheat, potato and corn in total sown area of three crops, respectively (\%), and $F_w, F_p$ , and $F_c$ are the average net profit of unit area for wheat, potato and corn in China, respectively ( $\mathrm{yuan/hm}^2$ ). By calculation, $D$ is 3507.97 yuan/hm².

Second, based on the value equivalent factor of ES per unit area proposed by Xie et al. in 2017, we formulated the value equivalent factor of ES per unit area suitable for this study (Table 2).

Finally, we calculated the seven ESVs and summed them at the county scale. The formula is as follows:

$$
E S V = \sum_ {s = 1} ^ {7} \sum_ {k = 1} ^ {9} D \times B _ {s, k} \times A _ {k} \tag {2}
$$

where $ESV$ is the sum of the seven ESVs in a county (yuan), $B$ is the value equivalent factor of ES per unit area, $A$ is the area of different land cover $(\mathrm{hm}^2)$ , $s$ is the type of ES, and $k$ is the type of land cover.

# 3.2.2. Calculating the ESV flow

Ecosystem service generally declines with distance, and the influence degree varies with natural conditions such as wind direction, water flow, topography, and the amount of population movement. Taking into account the influence of distance and the relative magnitude of ESs, Wang et al. (2021) adopted the breaking point model to calculate the ESV flow. In this study, we also used the method to calculate the ESV flow within the basin in 2000 and 2020. The model was developed on the basis of Reilly's Law of Retail Gravitation. It considers the attractiveness of a city to its surrounding areas to be proportional to its size and inversely proportional to the square of its distance from it. At present, the model has been widely applied to the economic radiation effect between cities

![](images/aa93a411410327197d3cf165beb15360b7d6d9d22569ef757d868f18f3548767.jpg)  
Fig. 2. Metacoupling framework in this study (modified based on Liu (2017)).

![](images/53fd035826428ff729c2c33d270152df274b65be126e018407dabaa32c5e3f00.jpg)  
Fig. 3. Flow chart.

Table 2 The value equivalent factor of ES per unit area in this study.   

<table><tr><td rowspan="2">Ecosystem</td><td>Provisioning services</td><td colspan="5">Regulating services</td><td>Cultural services</td></tr><tr><td>Water</td><td>Climate regulation</td><td>Waste treatment</td><td>Hydrological regulation</td><td>Erosion prevention</td><td>Maintenance of soil fertility</td><td>Aesthetic landscape</td></tr><tr><td>Cultivated land</td><td>0.02</td><td>0.36</td><td>0.10</td><td>0.27</td><td>1.03</td><td>0.12</td><td>0.06</td></tr><tr><td>Forest</td><td>0.37</td><td>7.03</td><td>1.99</td><td>3.51</td><td>2.86</td><td>0.22</td><td>1.14</td></tr><tr><td>Grassland</td><td>0.31</td><td>5.21</td><td>1.72</td><td>3.82</td><td>2.40</td><td>0.18</td><td>0.96</td></tr><tr><td>Shrubland</td><td>0.22</td><td>4.23</td><td>1.28</td><td>3.35</td><td>1.72</td><td>0.13</td><td>0.69</td></tr><tr><td>Wetland</td><td>2.59</td><td>3.60</td><td>3.60</td><td>24.23</td><td>2.31</td><td>0.18</td><td>4.73</td></tr><tr><td>Water bodies</td><td>8.29</td><td>2.29</td><td>5.55</td><td>102.24</td><td>0.93</td><td>0.07</td><td>1.89</td></tr><tr><td>Bare Land</td><td>0.00</td><td>0.00</td><td>0.10</td><td>0.03</td><td>0.02</td><td>0.00</td><td>0.01</td></tr><tr><td>Permanent snow and ice</td><td>2.16</td><td>0.54</td><td>0.16</td><td>7.13</td><td>0.00</td><td>0.00</td><td>0.09</td></tr><tr><td>Artificial Surfaces</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td><td>0.00</td></tr></table>

(Levy and Goldenberg, 2014; Simini et al., 2012). Since ES flows are also affected by the relative magnitude of ES and the distance between regions, in recent years, the breaking point model has been used to analyze ES flows between regions (Zhai et al., 2021; Tan and Lu, 2019). The model is both simple and effective and is suitable for a variety of ESs.

Specifically, we calculated the ESV flow between regions in three steps. First, we calculated the radiation scope of the ES between regions. The formula is as follows:

$$
d _ {j} = \frac {D _ {i j}}{1 + \sqrt {m _ {j} / m _ {i}}} \tag {3}
$$

where $d_{j}$ is the radiation distance of the ES from region $i$ (SPA) to region $j$ (SBA), $D_{ij}$ is the shortest straight distance between region $i$ and region $j$ , and $m_{i}$ and $m_{j}$ are the ESVs of region $i$ and region $j$ , respectively.

Second, we calculated the average radiation value of the ES between regions based on the field model (Converse, 1949; Wu et al., 2020). The formula is as follows:

$$
F _ {i j} = \frac {m _ {i}}{D _ {i j} ^ {2}} \tag {4}
$$

where $F_{ij}$ is the average radiation value of the ES of region $i$ to region $j$ .

Third, we calculated the ESV flow based on the radiation scope and the average radiation value between regions. The formula is as follows:

$$
E _ {i j} = F _ {i j} \times A _ {t} \times a \tag {5}
$$

where $E_{ij}$ is the ESV flow from region $i$ to region $j$ , $A_{t}$ is the radiation area of region $i$ , which is a circular area centered on its geometrical center, and $a$ is the parameter of the spatial value transfer, set to 0.6 (Fan et al., 2007).

In this study, each county in the basin was regarded as both an SPA and SBA. If the outflow of ESV in a county was greater than the inflow, it was called a net SPA. Conversely, if the outflow of ESV in a county was less than the inflow, it was called a net SBA.

# 3.3. Quantifying the ES flow between the basin and adjacent and distant systems

To quantify the ES flow between the basin and adjacent and distant systems, we regarded the basin as a net SPA and used the breaking point model to calculate the ESV flowing to each county of the adjacent system and the distant system. Then, we divided these counties into three levels by the natural breakpoint method, namely, low outflow, medium outflow and high outflow. With the exception of the low-outflow counties, the other counties were considered to be the main areas of ES outflow from the basin.

Next, we regarded the basin as a net SBA and calculated the ESV flowing to the basin from each county of the adjacent system and the distant system using the breaking point model. Next, we divided these counties into three levels, namely, low inflow, medium inflow and high inflow. Except for the low-inflow counties, the other counties were the main areas of ESs flowing into the basin.

![](images/a5ff93ca17fb30f08515fbee92db9446583b71360e7461d49cd5e15f93543ee1.jpg)

![](images/5fc15583548162ac0203da07c063f371bbc904c922319d0fff45851d93286e70.jpg)

![](images/950249633fcbf8dd98e0662286df1abcc3e9162da8230db5ab1953aa1103fd22.jpg)

![](images/74d15c7dcf90a37d5b83e02ae7fc8e79deaa47f19711edb8c98bdc5053a7c5df.jpg)  
Fig. 4. Pattern and dynamics of ES flow within the basin. Note: (a) and (b) show the pattern of ESV flow within the basin in 2000. (c) shows the dynamics of ESV flow within the basin from 2000 to 2020. (d) shows the dynamics of different ESV flows within the basin from 2000 to 2020. In (d), the columns from left to right represent Xining, Minhe, Pingan, Huzhu and Huangyuan.

# 4. Results

# 4.1. ES flow within the basin

In the basin, there were four net SPAs in 2000, namely, Haiyan, Datong and Huangzhong in the northwest and Ledu in the southeast (Fig. 4a). The net SPA with the highest outflow was Haiyan, and the ESV outflow was 11.07 billion yuan, accounting for $32.3\%$ of the total outflow of ESV. The net SPA with the lowest outflow was Huangzhong, with an ESV outflow of 4.34 billion yuan, accounting for only $12.7\%$ of the total outflow of ESV (Fig. 4b).

The ESV outflow decreased in $75\%$ of the net SPAs of the basin from 2000 to 2020. Among them, the net SPA with the largest reduction in ESV outflow was Haiyan, which has decreased by 1.04 billion yuan, accounting for $59.4\%$ of the total reduction. Conversely, the net SPA with the least reduction in ESV outflow was Huangzhong, which decreased by 296 million yuan, accounting for only $16.9\%$ of the total reduction (Fig. 4c).

Among three types of ESs, the value outflow of regulating services decreased the most, especially in hydrological regulation and climate regulation. Specifically, in Haiyan, the value outflow of hydrological regulation decreased the most, ranging from 79 million yuan to 128 million yuan, accounting for $41.1\% - 75.1\%$ of the total reduction. In Datong and Huangzhong, the value outflow of climate regulation decreased the most, with reduction ranges of 32-72 million yuan and 23-60 million yuan, respectively, accounting for $32.5\% - 37.3\%$ and $33.7\% - 38.5\%$ of the total reduction, respectively (Fig. 4d).

# 4.2. ES flow between the basin and the adjacent system

In 2000, the ESV in the basin mainly flowed to nearly $60\%$ of the adjacent system (Fig. 5a). Among them, the ESV flowing to Linxia was the highest, reaching 15.25 billion yuan, accounting for $18.3\%$ of the total outflow. The ESV flowing to Gaolan was the lowest, at 4.73 billion yuan, accounting for only $5.7\%$ of the total outflow (Fig. 5b).

From 2000 to 2020, the ESV flow from the basin to the adjacent

![](images/b9f83e3e94405fd169c664fc6380afc36ccf3dea32ac25bb0f0c2455f7585d13.jpg)

![](images/c7de2710a90a6132a6723abc14c4c21057ea8ff9816673be208d01951868052b.jpg)

![](images/1b49a94c834d8a71ed81bc8026916230b1376d70a9ffcaea57f901bc98286677.jpg)

![](images/e68767ca95dea24bc4f698e08847eb95b216055efd7834a2cfd86469c9d3836e.jpg)  
Fig. 5. Pattern and dynamics of ES flow from the basin to the adjacent system. Note: (a) and (b) show the pattern of ESV flow from the basin to the adjacent system in 2000. (c) shows the dynamics of ESV flow from the basin to the adjacent system from 2000 to 2020. (d) shows the dynamics of different ESV flows from the basin to the adjacent system from 2000 to 2020.

system decreased. The ESV flowing to Linxia decreased the most, by 948 million yuan, accounting for $20.3\%$ of the total reduction. The ESV flowing to Lanzhou decreased the least, by 142 million yuan, only $3.0\%$ of the total reduction (Fig. 5c).

For different ESs, the decrease in hydrological regulation flow toward the adjacent system was the most obvious. In detail, the decrease in hydrological regulation flow from the basin to the adjacent system was between 57 million yuan and 690 million yuan, accounting for $40.0\% - 72.7\%$ of the total reduction (Fig. 5d).

In the adjacent system, nearly $30\%$ of ESV flowed into the basin in 2000 (Fig. 6a). Among them, the region with the highest inflow was

Gonghe, and the ESV flowing into the basin was 301.12 billion yuan, accounting for $67.7\%$ of the total inflow. The region with the lowest inflow was Jingtai, and its ESV flowing into the basin was 15.75 billion yuan, which was only $3.5\%$ of the total inflow (Fig. 6b).

Overall, the ESV flow from the adjacent system to the basin decreased from 2000 to 2020. Among them, the region with the largest reduction was Gonghe, for which the ESV flowing into the basin decreased by 4.43 billion yuan, accounting for $89.5\%$ of the total reduction. The region with the smallest reduction was Jingtai, which decreased by only 89 million yuan, or $1.8\%$ of the total reduction (Fig. 6c).

![](images/d9b9b84864f39d5cd1a389c508fe66aa07a6b85c6fc9d8a4ef5db46b3eb13d35.jpg)

![](images/4354a8ca734e664f87894e2cc6f49454f232e3041b8d5592ceaf2c53ffc614e0.jpg)

<table><tr><td>1</td><td>1.78</td><td>12.74</td><td>10.15</td><td>12.00</td><td>7.57</td></tr><tr><td>2</td><td>5.98</td><td>1.59</td><td>2.36</td><td>0.92</td><td>2.79</td></tr><tr><td>16</td><td>2.55</td><td>0.32</td><td>0.24</td><td>0.65</td><td>1.04</td></tr><tr><td>3</td><td>1.13</td><td>1.28</td><td>0.76</td><td>0.80</td><td>0.51</td></tr><tr><td>19</td><td>1.24</td><td>1.30</td><td>0.74</td><td>1.31</td><td>0.05</td></tr><tr><td>5</td><td>2.30</td><td>0.13</td><td>0.32</td><td>0.34</td><td>0.72</td></tr><tr><td>21</td><td>1.27</td><td>0.93</td><td>0.45</td><td>1.05</td><td>0.27</td></tr><tr><td colspan="6">Xining Minhe Pingan Iuizhu IIuangyuan</td></tr><tr><td colspan="6">Huangshui River Basin</td></tr></table>

![](images/3b4438c71c499371279e776fd799de6acff047d786d255469c7b15b84cc9693c.jpg)

![](images/88506c93f85cb3ddd5a29331a24b9239df6e359d5d4b73419492fcdb35947ebc.jpg)

![](images/2b1d2fdab6db6140bca736445c5646c795951b2d263c0e7c88059d08c96b5fb4.jpg)  
Fig. 6. Pattern and dynamics of ES flow from the adjacent system to the basin. Note: (a) and (b) show the pattern of ESV flow from the adjacent system to the basin in 2000. (c) shows the dynamics of ESV flow from the adjacent system to the basin from 2000 to 2020. (d) shows the dynamics of different ESV flows from the adjacent system to the basin from 2000 to 2020.

Climate regulation played a major role in the reduction of the ESV flow from the adjacent system to the basin. Specifically, the climate regulation flow from Gonghe, Guide and Jingyuan to the basin decreased by 3.12 billion yuan, 848 million yuan and 208 million yuan, accounting for $53.4\%$ , $55.2\%$ and $66.3\%$ of the total reduction, respectively (Fig. 6d).

# 4.3. ES flow between the basin and the distant system

In 2000, the ESV in the basin mainly flowed to nearly $30\%$ of the distant system (Fig. 7a). Among them, the ESV flowing to Guanghe was the largest, 10.78 billion yuan, accounting for $7.4\%$ of the total outflow. The ESV flowing to Qingtongxia was the lowest, 5.73 billion yuan, accounting for only $3.9\%$ of the total outflow (Fig. 7b).

From 2000 to 2020, the ESV flow from the basin to the distant system decreased. Among them, the ESV flowing to Urad Houqi decreased the most, by 6.21 billion yuan, accounting for $41.2\%$ of the total reduction. The ESV flowing to Yinchuan decreased the least, by only 67 million yuan, $0.4\%$ of the total reduction (Fig. 7c).

Among all ESs, hydrological regulation flow and climate regulation flow toward the distant system decreased significantly. The hydrological regulation flow from the basin to nearly $80\%$ of the distant system decreased the most, ranging from 51 million yuan to 1.67 billion yuan, accounting for $45.3\% -93.7\%$ of the total reduction. In addition, in the remaining nearly $20\%$ of the distant system, the climate regulation flow from the basin decreased the most, ranging from 191 million yuan to 2.17 billion yuan, accounting for $34.4\%$ to $39.7\%$ of the total reduction (Fig. 7d).

In 2000, nearly $20\%$ of the ESV in the distant system flowed into the basin (Fig. 8a). Among them, the region with the highest inflow was Maduo, and its ESV flowing into the basin was 291.39 billion yuan, accounting for $21.3\%$ of the total inflow. The region with the lowest inflow was Hanggin Qi, whose ESV into the basin was 85.19 billion yuan, $6.2\%$ of the total inflow (Fig. 8b).

In general, the ESV flow from the distant system to the basin increased from 2000 to 2020. Among them, the region with the largest increase was Mado, where the ESV flowing into the basin increased by 17.89 billion yuan, accounting for $34.5\%$ of the total increase. The region with the smallest increase was Dari, as its ESV flowing into the basin only increased by 278 million yuan, or $0.5\%$ of the total increase (Fig. 8c).

Among different types of ESs, the increase in hydrological regulation flow from the distant system to the basin was the most obvious. The hydrological regulation flow from Maduo, Maqu, Hanggin Qi and Dari to the basin increased by 16.77 billion yuan, 8.00 billion yuan, 3.52 billion yuan and 141 million yuan, accounting for $87.0\%$ , $77.2\%$ , $34.1\%$ and $46.7\%$ of the total increase, respectively.

In addition, we verified the reliability of the breaking point model from two aspects. On the one hand, we first used hotspot analysis to identify the main SPAs and SBAs, and then performed the consistency check with the SPAs and SBAs identified by the breaking point model. The results showed that Kappa was 0.627 (P less than 0.001), with strong consistency. This means that the breaking point model has certain reliability in analyzing the ES flow. On the other hand, many of the SPAs identified by the breaking point model belong to Three River Sources Region. The region is known as the China Water Tower, delivering more than 60 billion cubic meters of living water to the downstream every year, and is a very important ecological source. Moreover, many of the main SBAs (such as Lanzhou, Yinchuan and Shizuishan) identified by the breaking point model are located in the economic zones in the upper reaches of the Yellow River designated by the National Planning Commission. Obviously, these economic zones generally require the inflow of ESs from external areas.

# 5. Discussion

# 5.1. Advantages of the metacoupling framework

ES flows are not limited to local, but often show transregional characteristics. They involve a process of ESs generated by the SPA, relying on a carrier, driven by natural or human factors, along a certain direction and path to the SBA (Liu et al., 2016). In this process, ESs provide benefits to human beings through spatial flows of different scales (from local to global) (Bagstad et al., 2013; Balmford et al., 2011; Cimon-Morin et al., 2013).

In addition to the analysis of local ES flows, existing studies have also analyzed the transregional ES flows. For example, Zhang et al. (2021) analyzed the freshwater ecosystem service flow within the Weihe River Basin of China. Xie et al. (2019) quantified multiple ES flows from Inner Mongolia to surrounding provinces of China. Ouyang et al. (2020) analyzed the global carbon sequestration flow from Qinghai Province, China. However, these studies rarely compare the differences in the flow of ESs in different spatial scopes.

The metacoupling framework enables comparison of the flow of ESs in different spatial scopes. We found that the ES flow from the basin to the distant system decreased the most. From 2000 to 2020, the ESV flowing to the distant system decreased by an average of 666 million yuan, 1.9 times and 2.7 times thoes flowing to the adjacent system and within the internal region of the basin, respectively (Fig. 9a). Moreover, among three ESs, the flow of regulating services from the basin to the distant system decreased the most. From 2000 to 2020, the regulating services flowing to distant systems decreased by 599 million yuan on average, which was 1.9 times and 3.0 times that flowing to adjacent systems and within the internal region of the basin, respectively (Fig. 9b). This can provide a reference for targeted management in different regions. For example, for distant system, the government should give more consideration to how to formulate policies to maintain the flow of regulating services.

The metacoupling framework has the potential for wide applications. The framework develops relevant policies by revealing important interactions (ES flows) within a system, between adjacent systems, and between distant systems, such as ecological compensation policies (Zhai et al., 2021). The framework also enhances the governance of ESs. Future research in ES flows that embraces the metacoupling framework will add important insights toward sustaining provision, balancing tradeoffs, promoting regional and global cooperation, and advancing SDG goals (Sun, 2023).

# 5.2. Hydrological regulation flow to the distant system decreased the most

We also found that hydrological regulation service flow from the basin to the distant system decreased the most among five regulating services. Specifically, the hydrological regulation flowing to distant systems decreased by an average of 306 million yuan from 2000 to 2020, more than 2.4 times that of other regulating services flowing to distant systems (Table 3). Furthermore, the results of the independent sample T test showed that there was a significant difference between the decrease in hydrological regulation flow toward the distant system and that toward the adjacent system. This indicates that the decrease in hydrological regulation flow in the basin had a significantly greater impact on the distant system and was likely to threaten the water security of the distant system. For example, on June 21, 2020, the water inflow from the Ningxia section of the Yellow River in the distant system increased, with a peak flow reaching 2130 cubic meters per second, and a flood occurred (Xinhua News Agency, 2020). On July 22, 2020, the peak flow of the Ningxia section of the Yellow River reached 3090 cubic meters per second, and another flood occurred (Xinhuanet, 2020). As the largest tributary of the upper Yellow River, the Huangshui River may be closely related to the two floods.

Existing studies have reported similar findings. For example, the

![](images/7c6fa3e72d143b5942cbe17ebbfaa8dbff77cc21c71619e05c9055e9e9578626.jpg)

![](images/ebd840fe1f4b29c12722bb9c3025776095b3aa78c2e85b0c4c19f5b8d6492ad1.jpg)

<table><tr><td rowspan="5">Huangshui River Basin</td><td>2.84</td><td>19.33</td><td>3.13</td><td>1.81</td><td>3.18</td><td>2.85</td><td>1.53</td><td>2.92</td></tr><tr><td>1.32</td><td>18.20</td><td>1.82</td><td>0.64</td><td>1.89</td><td>1.62</td><td>0.39</td><td>1.70</td></tr><tr><td>0.96</td><td>14.33</td><td>0.36</td><td>1.31</td><td>0.08</td><td>0.34</td><td>1.41</td><td>0.15</td></tr><tr><td>0.93</td><td>10.20</td><td>1.20</td><td>0.48</td><td>1.19</td><td>1.04</td><td>0.33</td><td>1.06</td></tr><tr><td>40</td><td>79</td><td>77</td><td>61</td><td>39</td><td>53</td><td>59</td><td>41</td></tr><tr><td>Haiyan</td><td>1.25</td><td>4.11</td><td>4.67</td><td>1.90</td><td>1.98</td><td>0.27</td><td>2.08</td><td>1.47</td></tr><tr><td>Datong</td><td>0.18</td><td>2.97</td><td>3.81</td><td>0.93</td><td>0.95</td><td>0.70</td><td>1.03</td><td>0.44</td></tr><tr><td>Ledu</td><td>1.64</td><td>0.97</td><td>1.72</td><td>0.83</td><td>0.79</td><td>2.34</td><td>0.70</td><td>1.05</td></tr><tr><td rowspan="2">Huangzhong</td><td>0.18</td><td>1.77</td><td>2.24</td><td>0.63</td><td>0.63</td><td>0.32</td><td>0.66</td><td>0.33</td></tr><tr><td>76</td><td>42</td><td>78</td><td>63</td><td>66</td><td>75</td><td>65</td><td>51</td></tr><tr><td>Haiyan</td><td>1.21</td><td>2.03</td><td>1.65</td><td rowspan="5" colspan="5">Flow change</td></tr><tr><td>Datong</td><td>0.35</td><td>1.18</td><td>0.75</td></tr><tr><td>Ledu</td><td>1.18</td><td>0.43</td><td>0.71</td></tr><tr><td rowspan="3">Huangzhong</td><td>0.29</td><td>0.72</td><td>0.49</td></tr><tr><td>62</td><td>64</td><td>60</td></tr><tr><td colspan="8">The upper Yellow River Basin</td></tr></table>

![](images/c2b0967353164b5177558e0f132628556bbf2c7f185eb41a723784a0fda2eb03.jpg)  
Fig. 7. Pattern and dynamics of ES flow from the basin to the distant system. Note: (a) and (b) show the pattern of ESV flow from the basin to the distant system in 2000. (c) shows the dynamics of ESV flow from the basin to the distant system from 2000 to 2020. (d) shows the dynamics of different ESV flows from the basin to the distant system from 2000 to 2020.

![](images/a8db3f6c04f57110083b7a8d3994d407f00bf155461b40eeccd26f1b01ca6e8e.jpg)  
Fig. 8. Pattern and dynamics of ES flow from the distant system to the basin. Note: (a) and (b) show the pattern of ESV flow from the distant system to the basin in 2000. (c) shows the dynamics of ESV flow from the distant system to the basin from 2000 to 2020. (d) shows the dynamics of different ESV flows from the distant system to the basin from 2000 to 2020.

![](images/11f2b704c4f22f1a37198909069716e8a9b24baab3c6d3a345c766408779baa0.jpg)

![](images/16373e1d106d10e6e546b424bdfe8ee499fd3c5fb8824671b5638b0b9d0ea595.jpg)  
Fig. 9. Dynamics of ES flows under the metacoupling framework. Note: (a) shows the dynamics of ESV flow under the metacoupling framework. (b) shows the dynamics of different ESV flows under the metacoupling framework. In (b), the primary axis represents the value flow dynamics of regulating services, and the secondary axis represents the value flow dynamics of provisioning services and cultural services.

Table 3 Dynamics of regulating service flows under the metacoupling framework.   

<table><tr><td>Regulating service type</td><td>Dynamics of ES flows within the basin (100 million yuan)</td><td>Dynamics of ES flows from the basin to adjacent system (100 million yuan)</td><td>Dynamics of ES flows from the basin to distant system (100 million yuan)</td><td>Statistical significance</td></tr><tr><td>Climate regulation</td><td>-0.08</td><td>-0.49</td><td>-1.27</td><td>☆</td></tr><tr><td>Waste treatment</td><td>-0.18</td><td>-0.35</td><td>-0.59</td><td>☆</td></tr><tr><td>Hydrological regulation</td><td>-1.59</td><td>-1.93</td><td>-3.06</td><td>★</td></tr><tr><td>Erosion prevention</td><td>-0.16</td><td>-0.37</td><td>-0.98</td><td>☆</td></tr><tr><td>Maintenance of soil fertility</td><td>-0.01</td><td>-0.03</td><td>-0.09</td><td>☆</td></tr></table>

Note: The black star represents a statistically significant difference in the reduction of ES flows in different spatial ranges at 0.05 level, while the white stars represent results that were not statistically significant.

Asian Water Tower (Tibetan Plateau and its surrounding areas) contains many glaciers, frozen soil and lakes, which are natural reservoirs with very important hydrological regulation functions (Tang et al., 2019). With global warming, the melting of glaciers and thawing of frozen soil, the hydrological regulation function of the Asian Water Tower is significantly weakened. This directly results in uneven distribution of runoff in the downstream rivers within one year, which seriously threatens the flood control security, water supply security and ecological security of remote downstream regions (Kraaijenbrink et al., 2021; Yao et al., 2022).

# 5.3. Grassland loss is the main reason for the decrease in distant flow

The decrease in ES flow is affected by both supply and demand; that is, the decline in ES provision capacity in SPAs and the improvement in ES in SBAs can lead to a decrease in ES flow (Schröter et al., 2018; Xu et al., 2019). To this end, we compared the dual effects of supply and demand in response to the finding that the hydrological regulation flow from the basin to the distant system decreased. Specifically, we kept the hydrological regulation of the distant system unchanged and calculated the contribution of the hydrological regulation changes in the basin to flow reduction. In addition, we remained the hydrological regulation in the basin unchanged and calculated the contribution of the hydrological regulation changes in distant systems to flow reduction. The results

show that the decrease in hydrological regulation flow toward the distant system was mainly due to the decline in hydrological regulation capacity in the basin. In more than $60\%$ of the regions in the distant system, the decline in hydrological regulation capacity in the basin contributed more than $50\%$ to the flow reduction (Fig. 10a).

We analyzed the main reason for the decline in hydrological regulation capacity in the basin from the perspective of land use/cover. Previous studies have shown that forests, grasslands, shrublands, wetlands and water bodies play an important role in providing hydrological regulation services (Xie et al., 2017; Fu and Zhang, 2014). By analyzing the dynamics of these five land cover types and their contribution to hydrological regulation, we found that grassland loss was the main reason for the decline in hydrological regulation capacity in the basin. From 2000 to 2020, the grassland area in the basin decreased by 388.04 $\mathrm{km}^2$ , resulting in a decrease of 520 million yuan in hydrological regulation services, more than $70\%$ of the total reduction (Fig. 10b). Existing studies have also shown that grasslands in the plateau play an irreplaceable role in water resource conservation and soil and water conservation and may even be more influential than forests. For example, the capacity of forests growing for seven or eight years to impound surface runoff is $34\%$ , while that of grasslands growing for two years is $54\%$ (Li et al., 2005).

Therefore, maintaining hydrological regulation flow by protecting grassland in the basin is an effective means to support the sustainable

development of distant systems. We propose two specific suggestions. First, the distant system can establish a cost-sharing, benefit-sharing and cogovernance ecological compensation mechanism for grassland protection in the basin. For example, Yinchuan Urban Economic Circle in the distant system is the main SBA in the basin. Following the basic principle of "who benefits, who compensates", the Urban Economic Circle needs to actively cooperate with the basin to establish horizontal ecological compensation based on ES flows, especially for grassland. Second, the basin can establish a value realization mechanism for ecological products derived from hydrological regulation. In the basin, Haiyan, located in the northwest, plays a main role in the maintaining hydrological regulation service. We propose to establish a value realization mechanism for ecological products in this region to ensure sustainable supply of the ecosystems (such as grassland) in hydrological regulation.

# 5.4. Future perspectives

In this study, we innovatively applied the metacoupling to the study of ES flows. Compared with existing studies, this study can describe the ES flows more comprehensively and systematically. Under the metacoupling framework, we found that the regulating services flow from the basin to distant system decreased the most, especially the hydrological regulation. In other words, ecosystem degradation in the basin may have

![](images/495ce428857dc48f8cd692660ac7eb3042499bf6dbf6f682181a5ab6d8d73a8a.jpg)

![](images/1124af641ac3d9dd2e3a26fb5662d86b141b651de69f4dc2ec228ca31663fe4e.jpg)  
Fig. 10. Cause analysis of the decrease in hydrological regulation flow from the basin to the distant system. Note: (a) shows the contribution of the basin and distant system to the decrease in hydrological regulation flow. Among them, the contribution from the basin is the proportion of the decrease in hydrological regulation flow to the decrease in actual hydrological regulation flow when the hydrological regulation of the distant system is constant. The contribution from the distant system is the proportion of the decrease in hydrological regulation flow to the decrease in actual hydrological regulation flow when the hydrological regulation of the basin is constant. (b) shows the dynamics of land cover and its contribution to the decrease in hydrological regulation.

a negative impact on the water security of distant systems, and this remote connection cannot be ignored.

This study has some limitations. Generally, ecosystem service declines with distance, which is the basis for the breaking point model to analyze multiple ES flows. However, this method is difficult to consider the complex physical and chemical processes of multiple ES flows, resulting in certain uncertainty. In addition, there is some subjectivity in the delineation of the adjacent and distant systems. For example, the scope of the distant system is defined only by hydrological elements.

In future studies, we need to more objectively delineate the adjacent system and distant system of the basin. For example, we can define the scope of adjacent and distant systems based on the water-energy-food nexus. In addition, we should use the ES flow model to simulate the path and dissipation of the flow.

# 6. Conclusions

The metacoupling framework can be used to comprehensively and systematically evaluate ES flows. The framework can reveal the ES flows within the basin as well as the ES flows between the basin and its adjacent and distant systems.

Our case study in Huangshui River Basin showed that ES flow within the basin and ES flow to adjacent and distant systems decreased from 2000 to 2020. Among them, ES flow to distant systems decreased the most, with an average decrease of 666 million yuan, 1.9 times and 2.7 times that flowing to adjacent systems and within the internal region of the basin, respectively. Furthermore, among all ESs, the decrease in hydrological regulation flow toward distant systems was the most significant, at least 2.4 times that of other ESs. This indicates that the hydrological regulation flow in the basin can significantly affect the water security of the distant system and is not conducive to regional sustainable development.

Grassland loss in the basin was the main reason for the decrease in hydrological regulation flow toward distant systems. From 2000 to 2020, grassland loss in the basin contributed more than $70\%$ to the reduction in hydrological regulation services. Thus, in the future, distant systems can participate in the grassland protection of the basin through scientific ecological compensation mechanism. This can better maintain the hydrological regulation flow to the distant system, ensure regional water security, and promote regional sustainable development.

