# Spillover effect offsets the conservation effort in the Amazon

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:17:25.754845+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Yue et al. - 2018 - Spillover effect offsets the conservation effort in the Amazon.pdf
- Year: 2018
- DOI: 10.1007/s11442-018-1539-0
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study analyzes how voluntary zero-deforestation supply-chain agreements in the Brazilian Amazon alter deforestation patterns both inside and outside the targeted biome. The geographic focus is on Para State in the Amazon (sending system) and Tocantins State in the Cerrado (spillover system), with global soybean and beef importing regions treated as receiving systems.

The authors apply the telecoupling framework to link distant human-environment systems through commodity, monetary, and information flows. They compile panel data for 2003-2015 at municipality level, including satellite-based deforestation estimates, soybean and beef prices, land availability, and transport infrastructure. Using regression models and counterfactual projections, they estimate how the Soy Moratorium (2006) and the zero-deforestation beef agreement (2009) affected deforestation in both states under changing market conditions.

Within Para, deforestation fell sharply after the agreements. Model projections suggest that, without these measures, cumulative forest loss from 2007 to 2015 would have been more than double the observed level. Parcel sizes of cleared land also declined, indicating smaller-scale clearing under stronger regulation.

In Tocantins, however, deforestation rose after the agreements took effect in the Amazon. Estimated forest loss is several times higher than a no-agreement scenario. Deforested parcels became larger, and statistical results show that soybean and beef price signals, when combined with the agreements in the Amazon, are associated with increased clearing in this Cerrado frontier. The authors interpret this as a displacement of agricultural expansion and pasture development from the regulated Amazon into a less regulated savanna biome. They estimate that this spillover offsets roughly one-fifth of the Amazonian carbon emission savings.

The paper is explicitly about telecoupling and metacoupling. It demonstrates how conservation interventions in one biome can generate unintended environmental costs in another through linked markets and policies, and argues that evaluating such measures requires a systems perspective that includes spillover systems, not only sending and receiving regions.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling among Amazon, Cerrado, and global commodity importers with documented spillover effects.

### Intracoupling
#### Systems
- Amazon biome internal land-use and conservation dynamics in Para State.
- Cerrado internal land-use change and deforestation in Tocantins.
- Brazilian national policy context shaping domestic deforestation controls.
#### Flows
- Within-Para shifts among forest, pasture, and soybean fields.
- Within-Tocantins conversion of native Cerrado to soy and pasture.
- Domestic information and policy diffusion on deforestation control.
#### Agents
- Brazilian federal and state governments and environmental agencies.
- Local farmers, ranchers, and agribusinesses in Para and Tocantins.
- Brazilian research institutes and monitoring agencies such as INPE.
#### Causes
- National conservation policies and monitoring programs reducing Amazon deforestation.
- Rising domestic demand and profitability for beef and soy production.
- Road expansion, land availability, and biophysical suitability for agriculture.
#### Effects
- Large decline in deforestation rates and parcel sizes in Para.
- Expansion of soybean and pasture areas within both states.
- Changes in local economies through agricultural growth and infrastructure.

### Pericoupling
#### Systems
- Amazon and Cerrado as neighboring Brazilian biomes.
- Border region where Tocantins overlaps Amazon and Cerrado.
- Adjacent Brazilian states involved in agricultural frontiers.
#### Flows
- Movement of farmers, capital, and production practices from Amazon to Cerrado.
- Policy and market information diffusing between adjacent biomes.
- Potential cattle and commodity movements across state borders.
#### Agents
- Regional agribusiness companies operating in multiple Brazilian states.
- Farmers relocating or expanding from Para into Tocantins.
- State-level planners coordinating land-use and infrastructure.
#### Causes
- Stricter deforestation controls in Amazon relative to Cerrado.
- Lower land prices and weaker regulation in Cerrado frontier.
- Proximity and connectivity between Amazon and Cerrado frontiers.
#### Effects
- Displacement of pasture and soybean expansion into Cerrado.
- Higher deforestation growth rates and parcel sizes in Tocantins.
- Partial offset of Amazon conservation gains by nearby biome losses.

### Telecoupling
#### Systems
- Amazon biome in Para as sending system exporting soy and beef.
- Global importing countries and regions as receiving systems.
- Cerrado in Tocantins as spillover system affected by distant interactions.
#### Flows
- Soybean and beef exports from Para and Tocantins to international markets.
- Monetary flows from foreign buyers back to Brazilian producers.
- Market, policy, and agreement information shaping producer decisions.
#### Agents
- Global agribusiness traders implementing zero-deforestation commitments.
- International soybean and beef buyers influencing supply-chain standards.
- Multilevel NGOs, researchers, and certification coalitions promoting moratoria.
#### Causes
- Rising global demand for soy and beef driving frontier expansion.
- Voluntary zero-deforestation agreements regulating Amazon-based supply chains.
- Price fluctuations and exchange rates in international commodity markets.
#### Effects
- Substantial avoided deforestation in Para compared to no-agreement baseline.
- Sharp increase in Tocantins deforestation attributed to displaced pressure.
- Significant share of Amazon carbon savings offset by Cerrado emissions.

### Cross-Coupling Interactions
- Telecoupled market demand interacts with local Amazon policies, redirecting land clearing to Cerrado.
- Supply-chain agreements reshape flows to receiving systems while leaving spillover system less regulated.
- Global price signals combined with regional road networks amplify spillover deforestation.

### Research Gaps or Limitations
- Limited representation of complex global price dynamics and exchange rates in models.
- Difficulty disentangling supply-chain agreements from concurrent public policies.
- Incomplete coverage of agents and longer-term behavioral feedbacks in the telecoupled system.

### Search Keywords
- Amazon Cerrado telecoupling spillover deforestation soy beef
- Soy Moratorium zero-deforestation beef agreement Para Tocantins
- telecoupling framework displaced land use Brazil conservation

### Extraction Confidence
high
