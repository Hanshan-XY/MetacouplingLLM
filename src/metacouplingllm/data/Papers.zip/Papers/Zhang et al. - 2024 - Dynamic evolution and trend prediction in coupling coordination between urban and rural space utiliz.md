Research article

# Dynamic evolution and trend prediction in coupling coordination between urban and rural space utilization efficiency based local and tele-coupling model

![](images/dca70ade87112cbd65e7babf3e424f164883270e4771d38ff41ba33f39ac03ac.jpg)

Fengtai Zhang a,c, Aiyu Xie a,\*, Jiawei Zhang a, Jing Chen a, Peiran Yang a, Dalai Ma a, Youzhi An a, Guochuan Peng b,c

$^{a}$ School of Management, Chongqing University of Technology, Chongqing, 400054, China   
$^{b}$ Institute for Ecology and Environmental Resources, Chongqing Academy of Social Sciences, Chongqing, 400020, China   
$^{c}$ Research Center for Ecological Security and Green Development, Chongqing Academy of Social Sciences, Chongqing, 400020, China

# ARTICLEINFO

Keywords:

Local and tele-coupling coordination degree

Space utilization efficiency

Spatial-temporal analysis

The Chengdu-Chongqing economic circle

# ABSTRACT

Optimizing the pattern of territorial space utilization is one of the key tasks to achieve the sustainable development goals. With the accelerating rate of global urbanization, the understanding of territorial space utilization efficiency, role and potential is a prerequisite for alleviating contradictions in urban and rural space distribution. The city cluster is the main form of organization for urban development in future, so the study attempted to explore the urban and rural space utilization efficiency (URSUE) in Chengdu-Chongqing urban agglomeration (CCEC) from coupling coordination degree (CCD) perspective. Considering the gradual increase in the trend of remote interactions between URSUE, we further introduced the Local and Tele-coupling coordination (LTCCD) model that takes into account interactive development relationship between different systems. The results of the study show that: In CCEC, the more economically developed cities indicated that urban spatial utilization efficiency lags behind rural spatial utilization efficiency; The LTCCD in the geographic center region will indicate a higher level but the LTCCD in the economic core cities is higher compared with their CCD level, especially in Chengdu City. This suggests that the LTCCD model is better able to take into account regional development correlations and spatial spillovers effect. This study attempts to explore several key issues of urban-rural spatial allocation in the process of urbanization development and to provide guidance for the territorial space utilization planning in urban agglomerations.

# 1. Introduction

Territorial space is a material carrier formed by social elements and their interactions, and one of the keys to optimize territorial space is to realize the efficient and rational allocation of urban and rural space [1,2]. The China's 19th National Congress proposed to build a system for the development and protection of territorial space which means improve the quality and efficiency of territorial space has become a national strategic plan in China. For several years, China has made city clusters as the spatial subjects of promoting high-quality urbanization in its planning outlines [3]. Therefore, coordinating urban and rural space is important tools for the

synergistic development of urban and rural areas. With the impact of globalization, both urban and rural areas have strongly felt the influence of the open economy, and the existing urban-rural development gap has been widening, which has made the contradiction between urban and rural spatial utilization more and more prominent. Therefore, how to the efficient and synergistic allocation of territorial space is a serious challenge [4,5]. On the one hand, the rural population has decreased due to higher personal income or better living conditions providing in urban areas, resulting in the weakening of the vitality of rural development. At the same time, the high cost of agricultural production and the slow growth of farmers' incomes are constraining the further development of rural areas to a certain extent [6,7]. On the other hand, rapid urbanization has led to the continuous expansion of urban scale, increasing energy consumption and environmental pollution in urban areas. The heat island effect, greenhouse effect and other urban problems are becoming more and more serious [8]. Both rural and urban areas are indeed the key subjects of territorial space, and harmonizing the interaction between them is a necessary step towards improving the territorial space and achieving sustainable development [9]. The relevant researches are committed to solving these problems faced respectively and their goal is how to support sustainable economic and social development within their own spatial boundaries with minimal resource consumption. In this context, clarify the efficiency of urban and rural utilization space is a prerequisite for the scientific optimization of their spatial layout [1].

With regard to research on the territorial space utilization, one research perspective is to divide territorial space according to these different land-use types and examine the impact of a single land-use structure on regional economic development or ecological protection [10]. However, they ignore the competition within the territorial space system and the synergy between various types of space, and there is also little literature that focus on urban-rural space in the research framework of competition and trade-offs [1]. Furthermore, the traditional territorial space analysis is based on the territorial function and evaluate from the "production-life-ecological" space perspective, and scholars have basically formed a consensus on the connotations of them, and there are still cognitive differences in their indicator systems, assessment methods and other aspects [11,12]. With the accelerating level of global urbanization, an "urban-rural-ecological" research perspective which considers from the territorial space subject, has gradually emerged recently [9]. Some scholars have explored the relationship between urban space utilization and ecological space utilization from the perspective of "dual-subject" assessment [7,13]. But this research perspective is still controversial whether ecological space can be regarded as unified territorial spatial subjects comparing with the urban and rural space. Currently, the research on territorial utilization space mainly focuses on its spatial classification system, spatial-temporal evolution, functional zoning, and planning schemes, especially the lack of analysis of the efficiency assessment, the evaluation of future development potential, and the comprehensive consideration based the conflict between urban and rural space.

Society is a complex system, and there are multiple coupling relationships between different systems such as resources, ecology, economy and society [14,15]. Coupling coordination relationship is a positive association between different systems, and when the CCD between them is high, it means that there is a benign development relationship between systems [16,17]. However, with the deepening of the research, some defects of the classical CCD model are gradually revealed. For example, the results of the classical CCD model mainly rely on the coupling degree value but the coupling degree value generally tends to be close to the high-value, which will make the CCD results appear the phenomenon of "inflated" to a certain extent [18]. Secondly, when determining the coordination degree, the classical CCD model gives the same weight to different systems, which cannot accurately reflect the actual situation in reality. Fortunately, some scholars have given different solutions to this problem. The main method about CCD's weights can be divided into two categories: the subjective assignment method and the objective assignment method. The subjective assignment method is flexible but there is a certain arbitrariness during the determination of weights, while objective empowerment method is high-objectivity but weak in practicability. Therefore, there still exists some controversies about the determination of CCD weights in the academy [2,19,20]. Moreover, urbanization drives the frequent replacement of transportation, logistics, and population migration among different regions, and the social systems among different regions are becoming more and more closely connected, so should the classical CCD model also be improved in response to this trend of social development? For the result it can provide better guidance for the sustainable development of the region and its surrounding areas as a whole. The proposal of the LTCCD model provides a new perspective for considering socio-economic and ecological interactions. The model takes into account the remote correlation between regional development on the basis of the traditional CCD model, and is able to reflect the urban socio-economic and ecological problems caused by the exchange of information and material flows between regions, which is a more comprehensive research perspective [7,21].

Resource efficiency can quantitatively assess whether the current region should increase its economic output under the current conditions of social production, and it is an effective tool for measuring urban and rural space utilization. Also, more attention should be paid to the consideration of un-expected outputs in resource management in the context of sustainable development [22]. The research attempted to address several key topics in the process of constructing spatial efficiency and assessment systems for urban and rural territories. The first is to comprehensively identify the key role of urban and rural space utilization on the overall optimal territorial space utilization. The research on territorial space assessment from the perspective of efficiency is more in line with the development trend of regional comprehensive research in the context of sustainable development goals. Urban and rural areas are the key subjects of territorial space, and assessing the efficiency level of urban and rural space is the basis for carrying out territorial space layout; Secondly, the evaluation of territorial spatial development potential based on the efficiency to grasp the problems arising from the development and protection of urban and rural space is a central point in the rational development of the region's future territorial space; Thirdly, from the perspective of coupling coordination research, the LTCCD model was introduced in combination with the socio-economic system in order to explore the dynamic development status between urban and rural space utilization systems.

# 2. Materials and methods

# 2.1. Study area and data

# 2.1.1. Study area

Urban agglomerations are the main forces to support China's high-quality development. After the Chengdu-Chongqing City Cluster Development Plan was approved by the Chinese government in 2016, 29 districts (counties) in Chongqing Municipality and 15 prefectures in Sichuan Province were analyzed as the Chengdu-Chongqing City Cluster, but they are being pushed forward under the integration policy, and Chongqing Municipality will be analyzed as a city for the convenience of description (Fig. 1). The Chengdu-Chongqing Economic Circle (CCEC) is located at the intersection of the China's national strategic economic named "Belt and Road" and "Yangtze River Economic Belt", and is an important economic development area in western China. With the advancement of urbanization, the increasing demand for construction land has led to the irrational land use in CCEC, and the regional ecological environment has been subjected to great challenges with the frequent conversion of different land types. In addition, as the CCEC is located in the ecological function area of the upper reaches of the Yangtze River, it needs to strengthen the protection of ecological land. However, subject to the influence of natural conditions, there are frequent encroachment for arable land or forest land around the CCEC, and the conflict of land use is exceptionally intense. At the same time, the CCEC has witnessed a gradual increase in the urban-rural income gap within regions and a wide gap in the urban-rural development level between regions in recent years [23,24].

# 2.1.2. Study data

The data of 15 prefectural-level cities in Sichuan Province are mainly obtained from the Sichuan Provincial Statistical Yearbook and the China Urban Statistical Yearbook. Additionally, the statistics of Chongqing Municipality are from Chongqing Municipal Statistical Yearbook and China Urban Statistical Yearbook. Account for missing data, the interpolation approach was used to fill in the remaining gaps.

# 2.2. Methodology

# 2.2.1. Calculation of space utilization efficiency

Clarify the efficiency of urban-rural spatial utilization, which is a prerequisite for exploring the coupling and coordination relationship between them. Data Envelopment Analysis (DEA) is a quantitative analysis method for evaluating the relative effectiveness of objects based on input and output indicators by using linear programming methods. Tone et al. proposed the Network DEA [25], and

Fig. 1. Location of CCEC in China.   
![](images/801b106dd5990ed063be0511781dc163714084c8c23aa11e947dfe0f9413c91a.jpg)  
Note: The map review number used in this study is: GS (2020)4619.

the DEA model has been continuously improved and used by many scholars. The DEA model was mostly used in the energy field at the beginning, but with the international concern about environmental pollution the super-efficiency network SBM, which can consider non-desired outputs, is more capable of indicating the real level of social system development. In addition, the model can reasonably consider the influence of input and output indicators on the system when measuring, thus making the final measurement results more scientific [26,26,27]. Thus, the actual status of URSUE can be reflected more effectively among different regions.

$$
\rho^ {*} = \min  \rho = \min  \frac {1 - \left(\frac {1}{\mathrm {V}} \sum_ {\mathrm {v} = 1} ^ {V} \frac {s _ {u} ^ {*}}{x _ {u} ^ {*}}\right)}{1 + \left[ \frac {1}{1 + \mathrm {U}} \left(\sum_ {u = 1} ^ {U} \frac {s _ {u} ^ {*}}{y _ {u} ^ {*}} + \sum_ {i = 1} ^ {I} \frac {s _ {j} ^ {*}}{b _ {i} ^ {*}}\right) \right]} \tag {1}
$$

$$
\sum_ {k = 1} ^ {K} z _ {k} ^ {y} y _ {u} ^ {k} - s _ {u} ^ {y} = y _ {u} ^ {k}, u = 1 \dots , U; s _ {u} ^ {y} \geq 0 \tag {2}
$$

$$
\sum_ {k = 1} ^ {K} z _ {k} ^ {\gamma} x _ {v} ^ {k} - s _ {v} ^ {x} = x _ {v} ^ {k ^ {\prime}}, v = 1 \dots , V; s _ {v} ^ {x} \geq 0 \tag {3}
$$

$$
\sum_ {k = 1} ^ {K} z _ {k} ^ {Y} b _ {i} ^ {k} - s _ {i} ^ {b} = b _ {i} ^ {k}, i = 1, 2 \dots N, s _ {i} ^ {b} \geq 0 \tag {4}
$$

In the Equ.1-4, $\rho^{*}$ represents the score of the ULGUE levels, V, U, N stand for input, expected and Un-expected output variables, respectively.

$(S_u^y, S_i^b, S_\nu^x)$ , $(y_u^k, b_i^k, x_\nu^k)$ and $z_k^y$ represent input and output slack variables. The score of $\rho^*$ is greater, which means the higher level. Given that system efficiencies vary in different scale, the standardization way is introduced in order to be able to perform the next coupling coordination calculations [20].

# 2.2.2. Calculation of CCD and LTCCD

The coupling coordination model allows for the analysis of inter-systemic problems in different areas and has advantages in analyzing the interaction between variables. Urban and rural space, as subsystems within the territorial space system, also are the key subjects of territorial space utilization. Therefore, this study constructed the URSUE evaluation system from the perspective of coupling coordination. The LTCCD was proposed is based on CCD model and inverse distance weighting. The model considers the influence of spatial distance in line with the current trends of the times. The details are as follows:

$$
C = \sqrt {\frac {U \times R}{\left(\frac {U + R}{2}\right) ^ {2}}} \tag {5}
$$

$$
T = \alpha U + \beta R \tag {6}
$$

$$
C C D = \sqrt {C \times T} \tag {7}
$$

$$
W _ {i k} = \frac {d _ {i k} ^ {- p}}{\sum_ {k = 1} ^ {n} d _ {i k} ^ {- p}} \tag {8}
$$

$$
C _ {s i} = \alpha \cdot C _ {\left(U _ {i}, R _ {i}\right)} + \beta \cdot \left[ \frac {\sum_ {k = 1} ^ {n} w _ {i k} \times C _ {\left(U _ {i} , R _ {k}\right)} + \sum_ {k = 1} ^ {n} w _ {k i} \times C _ {\left(U _ {k} , R _ {i}\right)}}{2} \right] \tag {9}
$$

$$
T _ {s i} = \alpha \cdot T _ {\left(U _ {i}, R _ {i}\right)} + \beta \cdot \left[ \frac {\sum_ {k = 1} ^ {n} w _ {i k} \times T _ {\left(U _ {i} , R _ {k}\right)} + \sum_ {k = 1} ^ {n} w _ {k i} \times T _ {\left(U _ {k} , R _ {i}\right)}}{2} \right] \tag {10}
$$

$$
L T C C D _ {s i} = \sqrt {C _ {s i} \times T _ {s i}} \tag {11}
$$

where Equ.5-7 indicates the coupling degree, coordination degree and CCD in the traditional CCD model respectively; $U$ means urban space utilization efficiency and $R$ means rural space utilization efficiency; we assumed that urban space has the same importance as rural space so the $\alpha$ and $\beta$ are 0.5;

Equ.8-11 were used to measure the LTCCD. Where indicates $i$ is the $i$ th region, $n$ is the total number of regions, $k$ is an integer from 1 to $n$ . $w_{ik}$ is the weight based on the inverse distance weighting, $d_{ik}$ is the distance between different areas' administrative centers; $p$ is

the power of the distance, usually equal to 2; $C_{si}$ indicates the degree of coupling based LTCCD model. $T_{si}$ is the coordination index, and $LTCCD_{si}$ is the local and tele-coupling coordination degree. Based on the needs of the study, we categorized the CCD and LTCCD into five levels (Fig. 2).

# 2.2.3. GM (1,1) model

The GM (1,1) model can predict for incomplete information or small sample data, especially in which for the series with obvious monotonic trend. In addition, the model could simulate the trend with high accuracy and is now widely used in the prediction of environmental problems, traffic flow and energy economy, etc. By collecting the original series data, the GM (1, 1) model generally can predict the data trend by considering the randomness and fluctuation of the original data. For time series forecasting of localized samples and ambiguous information, it is suitable since the prediction results are more consistent and not limited by the original data [28]. GM (1, 1) modeling is as follows:

Step 1: Determine the original nonnegative variable data series (smooth series) and utilize first-order accumulation to produce data in succession (Equ.12-14).

$$
Z ^ {(0)} (\mathbf {k}) = \left[ Z ^ {(0)} (1), Z ^ {(0)} (2), \dots Z ^ {(0)} (n) \right] \tag {12}
$$

$$
Z ^ {(1)} (\mathbf {k}) = \left[ Z ^ {(1)} (1), Z ^ {(1)} (2), \dots Z ^ {(1)} (\boldsymbol {n}) \right] \tag {13}
$$

$$
\frac {d Z ^ {(1)}}{d t} + \alpha Z ^ {(1)} = \mu \tag {14}
$$

where $\alpha$ is the developmental grey number, $\mu$ means the endogenous control grey number; $Z^{(1)}$ is the cumulative data series and $Z^{(0)}$ is the original data. And if the sequence $Z^{(1)}(k)$ has a quasi-exponential law, then the sequence $Z^{(1)}(k)$ satisfies the first-order linear differential equation (16).

Step 2: Decide the data matrix $B$ and $Y_{n}$ (Equ.15-17).

$$
B = \left[ \begin{array}{l l} - X ^ {(1)} (2) & 1 \\ - X ^ {(1)} (3) & 1 \\ - X ^ {(1)} (4) & 1 \\ \dots \\ - X ^ {(1)} (n) & 1 \end{array} \right] \tag {15}
$$

$$
\mathbf {Y} _ {n} = \left[ \mathbf {Z} ^ {(0)} (2), \mathbf {Z} ^ {(0)} (3), \dots \mathbf {Z} ^ {(0)} (n) \right] ^ {T} \tag {16}
$$

$$
X ^ {(1)} (k) = \mu Z ^ {(1)} (k) + (1 - \mu) Z ^ {(1)} (k - 1), k = 2, 3 \dots n \tag {17}
$$

![](images/d27631f811f5808a27d51c8eee660e9ecbb9d5c82c9dd0a6ca0c99711ee11d2b.jpg)  
Fig. 2. The division of CCD level.

where $X^{(1)}(k)$ is the background value in the matrix $B$ ; $\mu$ is the weighting coefficient, its usual value is 5.

Step 3: Utilize ordinary least squares to estimate the parameters (Equ.18):

$$
U = \left(\boldsymbol {B} ^ {T} \boldsymbol {B}\right) ^ {- 1} \boldsymbol {B} ^ {T} Y _ {n} \tag {18}
$$

Step 4: Solve the time response sequence (Equ.19):

$$
Z ^ {(1)} (k) = \left[ Z ^ {(1)} (p) - \frac {u}{a} \right] e ^ {- a (k - p)} + \frac {u}{a} \tag {19}
$$

where the value of K and P is 1,2 ... n. In the GM (1,1) model, it is usually assumed that $p = n$ , the original condition of the time response function is assumed to be $Z^{(1)}(p) = Z^{(1)}(n)$ . $Z^{(1)}(p)$ is the temporal response function's initial condition.

Step 5: Find the fitted value (Equ.20).

$$
Z ^ {(0)} (k) = Z ^ {(1)} (k) - Z ^ {(1)} (k - 1) \tag {20}
$$

where $Z^{(0)}(k)$ ( $k > n$ ) is the predicted value of the original data. $Z^{(1)}(k)$ is the ifitted value of the original data series; Also, the value of K is 2,3 ... n.

# 2.2.4. Exploratory spatiotemporal data analysis (ESTDA)

ESTDA evolved on the basis of exploratory spatial data analysis, and by adding the temporal dimension, it can make up for the shortcomings of traditional exploratory spatial data analysis, and better explore the spatiotemporal differences and change trends among research objects [26,29]. In this study, we attempted to explore the spatial clustering and divergence characteristics by using ESDTA, so as to visualize the mutual clustering and interaction mechanisms of LTCCD in CCEC. ESTDA mainly consists of two parts: the time path of Local Indicators of Spatial Association (LISA) and the spatial-temporal leap of LISA, and this paper attempts to investigate the spatial-temporal dynamics evolution of the LTCCD of CCEC from 2005 to 2030 by using ESTDA.

(1) LISA time path: It is also a continuous expression of Local Moran's I in scatterplot transfer, and is able to reveal the direction and strength of the spatiotemporal interactions between spatial units. The moving path of LISA coordinates can be expressed as $(yi,t,yLi,t)$ , $yi,t$ denotes the LTCCD of the city $i$ in the year $t$ , and $yLi,t$ denotes the spatial lag of the city $i$ in the year $t$ [30]. This can be seen in the LISA scatterplot. This explains the spatiotemporal dynamics characteristics of the LTCCD at the regional level and offers a better measure of coordinate stability.

$$
\tau = \frac {N \sum_ {t = 1} ^ {T - 1} d \left(L _ {i , t} , L _ {i , t + 1}\right)}{\sum_ {i = 1} ^ {N} \sum_ {t = 1} ^ {T - 1} d \left(L _ {i , t} , L _ {i , t + 1}\right)} \tag {21}
$$

$$
\varepsilon_ {i} = \frac {\sum_ {t = 1} ^ {T - 1} d \left(L _ {i , t} , L _ {i , t + 1}\right)}{d \left(L _ {i , 1} , L _ {i , T}\right)} \tag {22}
$$

$$
\theta_ {i} = \arctan \frac {\sum_ {j} \sin \theta_ {i}}{\sum_ {j} \cos \theta_ {j}} \tag {23}
$$

In the Equ.21-23, $N$ is the objects' total number; $\tau_{i}$ is the relative length of region i, the curvature is $\varepsilon_{i}$ and the direction of movement is $\theta_{i};T$ is the annual time interval, $L_{i,t}$ is the LISA coordinates of the city $i$ in the year $t$ , $d(L_{i,t},L_{i,t + 1})$ is the distance that the city $i$ has moved from the year $t$ to the year $t + 1$ ; and $d(L_{i,1},L_{i,T})$ is the distance that the city $i$ has moved from the first to the last year.

Table 1   
Basic types of spatial-temporal transition.   

<table><tr><td>Type</td><td>Spatial-Temporal Transition Type</td><td>Symbolic Expressions</td></tr><tr><td>Type1 (I)</td><td>Self and neighboring stabilization</td><td>HHt→HHt+1, HLt→HLt+1, LLt→LLt+1, LHt→LHt+1</td></tr><tr><td>Type2 (II)</td><td>Self-transition, neighboring stabilization</td><td>HHt→LHt+1, HLt→LLt+1, LLt→HLt+1, LHt→HHt+1</td></tr><tr><td>Type3 (III)</td><td>Self-stabilization, neighboring transition</td><td>HHt→HLt+1, HLt→HHt+1, LLt→LHt+1, LHt→LLt+1</td></tr><tr><td>Type4 (IV)</td><td>Self and neighboring transition</td><td>Type4a = HHt→LLt+1, LLt→HHt+1 (concentric)Type4b = HLt→LHt+1, LHt→LHt+1 (reverse)</td></tr></table>

(2)LISA temporal leapfrogging: Rey proposed a Markov transfer matrix and temporal leapfrogging theory and classified space-time leaps into four types based on their form [31,32]. Rey defined space-time variation (SF) and space-time coalescence (SC) as the ratio of the number of certain types of leaps to the total number of leaps (m) in the study time period. The formulas are as follows:

$$
S F = \frac {\text {T y p e 2} + \text {T y p e 3}}{m} \tag {24}
$$

$$
S C = \frac {\text {T y p e 1} + \text {T y p e 4 a}}{m} \tag {25}
$$

In Equ.24-25, Type2, Type3, Type1, Type4a denote the number of respective leap types in Table 1, respectively.

# 2.2.5. Trend surface analysis

From the orientation standpoint, trend surfaces analysis may clearly show the spatial distribution patterns of geographic elements in space [33]. The trend surface analysis is an ideal tool for continuously revealing the spatial change characteristics, which can focus on reflecting the trend of spatial data in different range of areas. This study examined the spatial distribution pattern of LTCCD among URSUE by using trend surface analysis, especially analyzing the evolutionary trend of CCECs in the east-west and north-south directions in order to better regional URSUE planning in the future. The formula is expressed as follows:

$$
Z _ {i} \left(x _ {i}, y _ {i}\right) = T _ {i} \left(x _ {i}, y _ {i}\right) + \delta_ {i} \tag {26}
$$

In Eq.26, $Z_{i(x_i,y_i)}$ is the actual observation data; $T_{i(x_i,y_i)}$ is the trend function, $\delta_{i}$ is the random error.

# 2.3. Indicator selection and research mechanism

Based on previous researches and the current development of CCEC, we selected five indicators for URSUE respectively limiting on the number of indicators of DEA modeling (Table 2). The URSUE essentially evaluates the trade-offs between inputs, desired outputs and undesired outputs, and thus promotes the synergistic development of urban and rural spaces. Specifically, the urban space utilization is the process of continuous accumulation of factors such as labor and capital on the land, and its indicator system should fully reflect the characteristics of non-agricultural production activities. Consequently, we selected the number of employees in the secondary and tertiary industries and the investment in fixed assets to represent the inputs of labor and capital, respectively; and it selects the economic benefits (GDP per capita), the social benefits (urbanization rate) and urban population density as the output indicators. On the other hand, the selection of the rural space utilization system needs to reflect the development characteristics of agriculture. We selected the area sown in crops and fertilizer application rate as the land and capital inputs. The expected output indicators were selected as gross domestic product of the primary industry and so on.

In this study, we used the super-SBM model to measure the URSUE of 16 cities in the CCEC region. In addition, we evaluated the CCD between the them using the CCD model. On this basis, considering the migration, transportation, and logistics between different regions, the LTCCD model was further introduced to evaluate the regional evolution of CCD in the current CCEC Under China's strategic economic layout. In addition, considering that the territorial spatial potential will have a great impact on the overall planning of the region in the future, we have further recognized the cities that will play a key leading role in the future development of the CCEC by utilizing the GM (1,1) model. The ESTDA and trend surface analysis portray the spatio-temporal evolution features of CCEC in URSUE from different perspectives. Therefore, we are able to better identify and solve the problems of the urban and rural space utilization in the present, save the restoration cost and better plan a sustainable development models of the CCEC in the future (Fig. 3).

# 3. Results

# 3.1. The measuring of URSUE

Using the Super-SBM model, we obtained the efficiency values of URSUE for 16 prefecture-level cities in CCEC from 2005 to 2020.

Table 2 The evaluation index system.   

<table><tr><td>System</td><td>Date type</td><td>Indicator source</td></tr><tr><td rowspan="5">Urban space utilization efficiency</td><td>Urban population density</td><td>[2,34,35]</td></tr><tr><td>Urbanization rate</td><td></td></tr><tr><td>the number of employees in the secondary and tertiary industries</td><td></td></tr><tr><td>Total investment in fixed assets</td><td></td></tr><tr><td>GDP per capita</td><td></td></tr><tr><td rowspan="5">Rural space utilization efficiency</td><td>Rural population density</td><td>[36-38]</td></tr><tr><td>Total grain production</td><td></td></tr><tr><td>Area sown in crops</td><td></td></tr><tr><td>Fertilizer application rate</td><td></td></tr><tr><td>GDP of primary sector</td><td></td></tr></table>

![](images/46fa4f4f8720aaaa2ccf51ef581528f006c50bb555eaf5559d422a8f2c5a6af8.jpg)  
Fig. 3. Workflow chart to analyze the dynamic evolution and trend prediction of CCD in CCEC.

We compared the efficiency values between urban and rural space utilization additionally (Fig. 4). The left end of Fig. 4 shows the urban system space utilization efficiency and the right end of it represents the rural system space utilization efficiency values. In general, the lower the score, the greater the intensity of territorial space utilization.

The efficiency scores of the urban system space utilization system are mainly distributed in the interval of 0.25-1.78. As a whole, its values of the 16 prefectural-level cities in CCEC shows a decreasing trend, fluctuating from 0.927 in 2005 to 0.798 in 2020. But there existed a rebound trend around 2015. Among them, the urban system space utilization efficiency values of Chongqing and Chengdu were on the low side, especially Chongqing's urban system space utilization efficiency value in 2006 was the lowest among all the regions, which was only 0.254. This suggests that under the impetus of urbanization, the cities with higher developed economies will utilize the urban space more intensively.

The rural system space utilization system presents a completely different distribution trend comparing with the urban system space utilization system. On the one hand, the overall level of rural system space utilization presented is relatively stable and balanced. The values of rural system space utilization in the 16 prefecture-level cities were all higher than 0.438, and it as a whole shows a fluctuating upward trend. The average values of rural system space utilization efficiency in 2005, 2010, 2015, and 2020 were 0.633, 0.872, 1.017, and 2.166, respectively. More and more people gradually gather in big cities for convenient living services and personal development

Fig. 4. The URSUE changes from 2005 to 2020 in CCEC.   
![](images/0436be1e23f7212ae78b140c3982bccd168e2c7a3812bb783fa50fc55a64e722.jpg)  
Note: (a)-(p) denote the 16 prefecture-level cities of CCEC respectively.

opportunities, so the intensity of rural space utilization is obviously weakened. In some economically backward regions, the intensity of rural space utilization is significantly higher than that in economically developed regions, such as Suining City, Deyang City and Neijiang City.

# 3.2. The measuring and prediction results of CCD

# 3.2.1. Comparison of CCD in different regions with overall levels

We compared the CCD and LTCCD of URSUE in CCEC from 2005 to 2030 under different cities as shown in Fig. 5.

Under the classical CCD model, the CCD of URSUE of the 16 prefectures in CCEC reaches the moderately balanced level in the study years, and the CCD in 2005 and 2020 were 0.571 and 0.567, respectively, which are slightly decreasing but basically stable. Among the 16 prefectural cities, Chengdu City has the lowest average CCD among the 16 prefectural cities, basically concentrating in the range of 0.20–0.40, which was at the seriously unbalanced level or moderately balanced level. While the high CCD area was mainly Ya'an City, which has reached the highly balanced level in the year of study. We also compared the LTCCD results of 16 prefecture-level cities in different years. Under the LTCCD model considering the spatial distance, the LTCCD levels were lower than CCD levels in most cities, with the overall average LTCCD decreasing from 0.440 in 2005 to 0.412 in 2020, and the LTCCD level has only reached the basically balanced level. The high and low value areas of LTCCD have also changed significantly, such as the high value area is mainly Meishan City, whose LTCCD average value in the year reached 0.523.

It is worth noting the CCD and LTCCD value in Chongqing Municipality has a clear trend of growth in the future, and especially

![](images/9784cbfac0dcbfaa009e8971529aeeb84a0adff99b04e7b01f04f0aff519ed6a.jpg)

![](images/c095ddcc1e35cb77cea2b34e5d74cca89acf49ca059ed0d6ff3b490969d7c1b2.jpg)  
(i) Zigong city

![](images/ff71ae5ae22fdf7da2fb8a488610f37f0e674709d8c24778d2daedebdecb16a6.jpg)

![](images/b33ef107733e61313a9d406c5fdf59f760dbd5f18c1ebf482a6baadd82e6be55.jpg)

![](images/309b49862aeb65bc8e0d23a9c716ca96e77a56de44a817dedb33fa4a2e453413.jpg)

![](images/2197f5f1ecc2ea35817f53b37cf37c30c977a01c3dc5d0f6ca2056a8173fa2ff.jpg)

![](images/7308cab4d9b5cd62a61e8daaa60405b44a48f110f1d31da1e8aaaf443e41f7d7.jpg)

![](images/11f8d055f1117dac82db5093c4b281db077c7b72753000ffbbdae3f2775873e0.jpg)

![](images/ebc488dfc91effc57ff54c3685e92d20ab115ca35f6e420950fa300860496255.jpg)

![](images/bbe0bedcbb2d073373e9ff6524e528abe10dc75eec5ba9fbe8b83964dea06d52.jpg)

![](images/1104ab27cf8d26ade200c3c7566d6c8437871a65d062ac5a2823a01baaa20fb7.jpg)

![](images/f331389183ae46cfaf14c1c0b677112362590729de85349e44a4069084ee5651.jpg)

![](images/02aea55a4cb0bff7027c8346be88fa6cf203887259818577b503dc9f97574c91.jpg)

![](images/00e58062642c374698f3caf457bed3015458f7d96299b86e8099183cd02a12fb.jpg)

![](images/1f716d1bad324dbff306956428690d5df2887ea7c8261b7691acdc7695b6ed50.jpg)

![](images/d59b3010dd242a10cc8f7941ea67a748206c6f016f5fedc3683d8c7983f0bb4d.jpg)  
Fig. 5. The CCD changes and comparisons from 2005 to 2030 in CCEC. Note: (a)-(p) denote the 16 prefecture-level cities of CCEC respectively.

under the classical CCD model, its CCD value is already close to 1 in the year of 2029. Under the LTCCD model, the LTCCD in Chongqing Municipality in 2024 was expected to be more than the average level of the 16 cities, which realizes the transition from a follower to leader role. In the future, Chongqing Municipality will play a more prominent role in leading the CCEC's URSUE development process.

# 3.2.2. Comparison of LTCCD model with CCD model

In Fig. 5, it can also furtherly compare the results of the classical CCD model with the LTCCD model. On the whole, the values of the classical CCD model were generally higher than the LTCCD model. To a large extent, this can be attributed to the fact that the results of the classical CCD model are mainly dependent on the coupling value, and one of the drawbacks of the classical CCD model is that the coupling value is basically distributed in the high end, which leads to the phenomenon that the CCD value is prone to be "falsely high", and this drawback is very prominent in the prediction of the CCD in Chongqing. That is, after 2029, the CCD value of URSUE in Chongqing is close to 1, which is not in line with the current development status and trend of Chongqing. On the other hand, it can find in the analysis of LTCCD that after adding the consideration of spatial distance, the places with higher CCD levels do not mean that their LTCCD levels will also present higher levels, while the cities located in the middle of the urban agglomeration present higher LTCCD levels, and the high level of LTCCD levels is mainly composed of Meishan City (0.523), Ya'an City (0.519) and Zigong City (0.514). Under the LTTCD model, the CCDs of most prefecture-level cities were basically balanced level, which to some extent is more in line with the current actual status of CCEC.

# 3.3. The spatiotemporal analysis of LTCCD

# 3.3.1. The changes of LTCCD in different levels

According to the variation of LTCCD values, we selected 2005, 2010, 2015, 2020, 2025, and 2030 as the study years, and analyzed the changes of its LTCCD values at five different levels, as shown in Fig. 6. On the one hand, in these years, the LTCCD levels of CCEC were mainly concentrated in (0.31–0.40] and (0.41–0.50], especially in 2025, the number of LTCCD at the basically balanced level reaches 8, and half of the cities have reached higher level. On the other hand, among the five different CCD levels, the major number increase poles are mainly concentrated from (0.00–0.30] to (0.41–0.50]; while the major number decrease poles are mainly concentrated from (0.31–0.40] to (0.61–1.00] and (0.41–0.50] to (0.61–1.00]. This showed to some extent that although the overall LTCCD of CCEC has gradually realized the leap from low CCD to medium CCD level, more efforts are needed to realize the transition from medium CCD to high CCD in the future.

# 3.3.2. Exploratory spatiotemporal data analysis results

The geometric features of the LISA time paths of the LTCCDs of 16 cities in CCEC were visualized using ArcGIS10.8 software. Fig. 7 (a) shows that Chongqing has the highest relative length, indicating that the local spatial structure of the LTCCDs in Chongqing is more dynamic. Fig. 7(b) divided the relative lengths into two categories with 1 as the boundary, among which there were 9 regions with relative lengths less than 1, accounting for $56.25\%$ mainly located in the western part of the CCEC, indicating that the local spatial structure of these cities is relatively stable. Fig. 7 (c) shows that the curvature of most of the cities was greater than 1, with stronger spatial dependence, and the spatial distribution roughly shows the trend of decreasing from northeast to southwest, and the cities with larger curvature include Chengdu, Deyang, Suining, Mianyang and Ya'an, indicating that these cities spatial dependence fluctuation, and the obvious dynamic change and interaction process between the above cities and their neighbors. Fig. 7 (d) shows the moving direction of the LTCCD, and the study found that the moving direction of the LTCCD of the five cities exhibits synergistic growth, which only accounts for $31.25\%$ of the study area, indicating that the collaborative dynamics of the regional localized spatial structure is weaker than the competitive dynamics, and that the spatial integration is weaker. This implies that the synergistic development

![](images/234f8a63e7ffd39505f547f27611a745169801eb9bbbc01ad751e1e623f29945.jpg)

![](images/28baad365eafbcaba9a7f586de62cc9b9ab84e664beef99ffbc1660f028169cd.jpg)

![](images/7679c179e04fbbcd0f2cf0ad3adc9100d31d5c63761bd140d6b72d701125e2b7.jpg)

![](images/8d03589763ffbe436e923118ddbcb260164f7bb96931c63493fd77a864fb302b.jpg)

![](images/069bb1f11611b06f628d2da2cc69659273fd617d6fcb9ac4abe28e75dd13732a.jpg)

![](images/6d91be9d5fdc81a1fb5ae099aef6870f5daef08a7846895bb3553a96f86c5b0d.jpg)  
Legend   
Seriously unbalanced level

![](images/3f9d20b83219b3bb710697c9d10b851401f6b8c8a1ec56a5cd1717d288465859.jpg)  
Moderately unbalanced level

![](images/978bfd9ce309aac9cf5020c71bbf45dca3cc10370be7b945287f27f3131b9b39.jpg)  
Basically balanced level

![](images/7632714b9e655c323fdd7af8b497dece7369da4cc7edd59cc8bd8a235757831b.jpg)  
Moderately balanced level

Highly balanced level   
Fig. 6. Changes in the number of different CCD's levels in CCEC.   
![](images/ddddff31451d94a7ddbccfb2087ae260721c5cd955b4ddb014ee8f129bda7449.jpg)  
Note: (a)-(e) shows the changes in the number of LTCCD at the five class levels in CCEC cities respectively. Where (a) denotes the period from 2005 to 2010; (b) denotes the period from 2010 to 2015; (c) denotes the period from 2015 to 2020; (d) denotes the period from 2020 to 2025; (e) denotes the period from 2025 to 2030.

![](images/9547b0581c74ec492e4fadee63fe023589f4e510e4a44b2c6887fb7c6f04bc8e.jpg)

![](images/276eb62135f83fac544559ca7cabd0e1f8bf3ccbc77492b037b0985c84e44315.jpg)

![](images/2167caa20652df9434b9219061d7aeec59634dfc4dc0acce495ece401039ed2d.jpg)

![](images/069839d50075024282cb1303b6534d5d1a6c1662f94d09e468525b5b9e334d02.jpg)  
Fig. 7. Spatial distribution of LISA time trajectory characteristics for LTCCD from 2005 to 2030. Note: (a) and (b) denote the relative lengths; (c) is the curvature; (d) is the direction of movement.

# between cities needs to be strengthened.

According to the results of the LISA space-time jump matrix (Table 3), the most dominant form of transition is type1 with a probability of $88\%$ ; the second most dominant is type2 with a probability of $7.25\%$ ; Among them, the transfer types with higher probability are $LL_{t} - LH_{t+1}$ and $HL_{t} - HL_{t+1}$ , respectively. Overall, most of the cities have undergone spatiotemporal jumps during the study period, with weak path-dependence characteristics. In addition, the spatio-temporal cohesion probability of LTCCD is higher at $88.25\%$ , indicating that LTCCD is more spatially cohesive and the spatial correlation structure is relatively stable.

# 3.3.3. Trend surface analysis results

In Fig. 8, the Z-axis represents the attribute value of LTCCD, the X-axis and Y-axis represent the due east and due north directions, respectively. The blue curve represents the fitted line of spatial variation of LTCCD values in the north-south direction, and the red curve represents the fitted line of spatial variation in the east-west direction.

In the north-south direction, the LTCCD as a whole realized the transformation from a "U" shape to an inverted "U" shape. From 2005 to 2020, the distribution trend of high in the north and low in the south is basically maintained, which indicates that the LTCCD of CCEC maintains a better interaction in the north than in the south in this interval. In the forecast years, the benign interaction in the south keeps rising, and finally realizes the surpassing of the northern region. In the east-west direction, there was a significant change in the slope of the overall curve. From the basic balance in 2005, the curve gradually evolves to a "U" curve, and the height of the LTCCD at the western end gradually increases, which indicates that the benign interaction of the LTCCD in the western part of the

Table 3 Spatiotemporal jumps and probability matrices for LTCCD.   

<table><tr><td>t/t+1</td><td>HH</td><td>LH</td><td>LL</td><td>HL</td><td>Type</td><td>Percentage</td><td>SF</td><td>SC</td></tr><tr><td>HH</td><td>I (78,0.195)</td><td>II (3,0.0075)</td><td>IV (0,0)</td><td>III (7,0.0175)</td><td>I</td><td>0.88</td><td>0.1175</td><td>0.8825</td></tr><tr><td>LH</td><td>II (4,0.01)</td><td>I (79,0.1975)</td><td>III (2,0.005)</td><td>IV (0,0)</td><td>II</td><td>0.0725</td><td></td><td></td></tr><tr><td>LL</td><td>IV (1,0.0025)</td><td>III (4,0.01)</td><td>I (81,0.2025)</td><td>II (10,0.025)</td><td>III</td><td>0.045</td><td></td><td></td></tr><tr><td>HL</td><td>III (5,0.0125)</td><td>IV (0,0)</td><td>II (12,0.03)</td><td>I (114,0.285)</td><td>IV</td><td>0.0025</td><td></td><td></td></tr></table>

![](images/ef1175934a8f23eb010e687698542fc746a9af06e04ffcf506e8026c366b7057.jpg)  
(a) 2005

![](images/fcfd3a5e29721e10f535ce7bc9956ecfc38ae65fb0475d45a3c5e42bc76e870e.jpg)  
(b) 2010

![](images/750941ca8ae264dcc71182721f9529a84d0bff1889c0fe9bc4cc597ca93b8965.jpg)  
(c) 2015

![](images/cf1df7c9e3df5e9d1d1336b4322d5f6a263596f98673d9a719f9b0c0cf5e3f30.jpg)  
(d) 2020

![](images/5e75ce1937aee08495d1a19b2e9474c7670415a99277e0361f372837a41a25a3.jpg)  
(e) 2025

(f) 2030   
Fig. 8. The trend surface analysis results of LTCCD in CCEC.   
![](images/48b22992d58ac8b0f2c3c0e547decc5f087782583ecc33dc49319bf90f405350.jpg)  
Note: (a)-(f) denote the trend distribution of LTCCD in CCEC in different years respectively.

CCEC is better than that in the northern part. In addition, the slopes of the fitted curves in the east-west direction exceeded those in the north-south direction after 2020, suggesting that the east-west direction is the main reason for the spatial differentiation of LTCCD in the CCEC. Moreover, the slopes of the fitted curves in the north-south direction gradually weakened during the study period, whereas the gap between the slopes of the fitted curves in the east-west direction was gradually increasing, which suggests that the spatial disparity of the LTCCD in the east-west direction is key direction if the CCEC want to enhance the overall regional LTCCD in the future.

# 4. Discussion

# 4.1. Dynamic evolution of the LTCCD

The analysis of the results of the classical CCD model and the LTCCD model can be found that the CCD values under them showed a clear low value area in 2008-2009 together. By tracing the major social events that occurred in Chengdu and Chongqing in that year, we believe that the occurrence of the Wenchuan earthquake is the key reason that affects the low LTCCD values. Felbermayr has concluded in his research that the disasters in the top $1\%$ of the disaster index distribution caused a decrease in per capita GDP of at least $6.83\%$ , while the disasters in the top $5\%$ caused a decrease in per capita income of at least $0.33\%$ [39]. After this mega-earthquake, several regions of Sichuan Province were seriously broken, and the large scope of this aftershock even affected Chongqing Municipality and Shaanxi Province. The occurrence of natural disasters has a significant impact on areas' industrial structure and policy orientation, because it means it needs to invest a large amount of resources in reconstruction after the disaster. The epicenter of Wenchuan earthquake is located in Sichuan Province, so the impact on the 15 cities of Sichuan Province LTCCD is more obvious. On the other hand, the low values of LTCCD in Chongqing Municipality, which is in the aftershock range area, is relatively insignificant.

In addition, according to the first law of geography, that is: there are interactions and mutual influences among various geographic phenomena in various systems. With the concepts of economic globalization, the connections between biological systems on earth become more and more frequent and close under the influence of logistics, population migration, transportation, and so on, and the LTCCD model was proposed in this context. By improving the classical CCD model, the LTCCD model with the considering of spatial distance provides a new perspective for the development of CCD model. Our study finds that, the urban agglomeration center area plays a stronger connecting role between regions and its final LTCCD tends to be stronger without considering the topographical factors and the original accumulation of development levels. Such as the LTCCD of Chengdu City in the CCEC in the whole will higher than the classical CCD model and then could justify the findings of our study. In addition, when An et al. measured the carbon emission and ecological quality CCDs in the Yangtze River Economic Belt using the LTCCD model, they found that that CCD in the classical CCD model is smaller and CCD in LTCCD model is higher [40]. However, our study results revealed that the CCD under the LTCCD model would be lower, so it is inconsistent with the conclusions of our findings. Of course, different study areas and study subjects all will have important implications for LTCCD. Therefore, there is not a single simple linear correlation between the CCD results between classical CCD and LTCCD models. All in all, the LTCCD model is able to reflect to some extent the existence of spatial dynamic

interactions of URSUE among different cities, and with the further implementation of the Chengdu-Chongqing urban agglomeration development plan, the LTCCDs among the 16 cities will show a higher level in the future which is in line with the future development trend of CCEC.

# 4.2. Problem area recognition

After measuring and comparing the levels of CCD, we analyzed the problem areas of URSUE based on the results of the study, so that we can better propose more reasonable, practical and scientific policy recommendations for the future development of CCEC. Based on the previous studies and the actual development status of the CCEC, we divided the problem areas into four categories [41]. (1) Urban efficiency lagged areas: USUE values are lower than $75\%$ of the annual average of the whole region; (2) Rural efficiency lagged areas: RSUE values are lower than $75\%$ of the annual average of the whole region; (3) CCD lagged areas: CCD values are lower than $80\%$ of the annual average of the whole region; (4) LTCCD lagged areas: LTCCD values are lower than $80\%$ of the annual average of the whole region.

As shown in Fig. 9, it can be found that the number of problem areas is mainly urban efficiency lagged areas and CCD lagged areas. There are three Urban efficiency lagged areas, which are Chengdu, Chongqing and Yibin City. On the other hand, CCD lagged areas include Chengdu City, Zigong City and Suining City. It is worth noting that Chengdu and Chongqing, as the center cities of CCEC,

![](images/cd092116802c0a7824668c91e6802b1c572dc605c4ab043ee527917322da42f3.jpg)

![](images/28b51f706056f68e90867cf8aa1a4daaf095a30f8cbb24c64442b39096b0821d.jpg)

![](images/5afeb1b672df3fae4a59cf355e4f0a96876b82ee45c91e953a5bcc4bbaf48c92.jpg)

Fig. 9. Spatial distribution of problem area identification in CCEC.   
![](images/b49467e534b6c1793bcce622b2c7da620260d2e9a7b251b3162c9e0591b437b7.jpg)  
Note: (a) denote the urban efficiency problem areas; (b) is the rural efficiency problem areas; (c) is the CCD problem areas; (d) is LTCCD problem areas.

perform poorly in the evaluation system as a whole, appearing as problem areas several times.

# 4.3. Study limitations

(1) The analysis of the territorial space utilization only from the perspective of efficiency will lead to constrain the fairness of territorial space resources. How to carry out the research on the comprehensive correlation between equity and efficiency of territorial space resources is one of the directions for future research.   
(2) In this study, the LTCCD model improves the classical CCD model by considering from perspective of spatial distance. However, the model only considers the distance of administrative district centers between different regions, so these cities in the central region usually present a higher level of LTCCD level. In the future, scholars can consider add the influence on GDP, population agglomeration, transportation or other factors to improved LTCCD model, so as to explain more realistically the influence of regional spatial spillover and siphoning effect.   
(3) In this paper, only 16 prefectural-level cities of CCEC were selected as research objects, and the research results can only provide reference value for the optimization of territorial space utilization within the scale of urban agglomeration, and future research can select other richer research scales and regions, so as to provide new research perspectives and theoretical value for the optimization of territorial space utilization in another regions.

# 5. Conclusion and policy implications

# 5.1. Conclusion

The study attempts to address several key problems during the process of constructing urban and rural spatial layout. Firstly, it is necessary to identify the role of urban and rural space utilization in the optimal use of territorial space, and transform from a single space efficiency measurement to a comprehensive consideration of multiple space types, so as to analyze the effectiveness of the overall territorial space optimization. Secondly, we analyzed the CCD of urban and rural spatial utilization, and used the LTCCD model to emphasize that different regions should establish a sense of "community" in their development, so as to promote the effective enhancement of the overall territorial space utilization efficiency of the CCEC region. Thirdly, based on the GM (1,1) model, the evaluation of the territorial space development potential in CCEC region was carried out, and the problems were examined from the perspective of the time dimension, so as to improve the defects in the current development mode and reduce the risk of the problems in the territorial space development of inter-regional areas in the future. The results of the study show that: (1) The level of economic development will have a direct impact on the regional URSUE, and the current CCEC's URSUE has greater differences in economically developed cities. Additionally, relatively low volatility in the efficiency existed in rural space utilization system; (2) The LTCCD model will be close to the actual development state in CCEC, and the LTCCD in the center region will show a higher level such as Meishan City. (3) The changes in the LTCCD level of CCEC are mainly reflected in the transformation from low CCD to medium CCD, and the trend of changes from medium CCD to high CCD is not obvious. Furtherly, the spatial spillover effect of economically developed regions in the territorial space utilization will be more obvious in the future, especially in Chongqing. (4) The spatial distribution of LTCCD in CCEC shows a decreasing trend from northeast to southwest, and the synergistic development between cities needs to be strengthened in the future, and the east-west direction is the main direction of spatial differentiation of LTCCD in CCEC.

# 5.2. Policy implications

(1) The CCEC is an important growth pole for economic growth in China, as well as an important ecological reserve in the upper reaches of the Yangtze River. Among them, Chengdu and Chongqing, as the core cities, the unbalanced URSUE is more prominent for the reason of the higher urban population density and urbanization rate. Between 2005 and 2020, the urbanization rate of Chengdu increased from $50.27\%$ to $78.76\%$ while Chongqing increased from $25.79\%$ to $69.46\%$ , which is the fastest rate urbanization among all the cities. It leads to the population urbanization and the "rural hollowing" problems in these cities have become increasingly prominent, indicating that the CCEC is in a dynamic period of urban-rural transformation and development. Therefore, it is crucial to formulate multi-stage development plans according to the different stages of urbanization development. Furthermore, it is also important to balance the relationship between economic development and ecological protection which need these core cities rationally plan the carrying capacity of resources in the region, assess the territorial potential for long-term development and pay attention to the problem of fragile ecological background especially in mountainous areas.   
(2) In the spatio-temporal evolution analysis, the LTCCD of CCEC as a whole indicated strong spatial cohesion and stable spatial correlation structure. This is largely due to the planning of integrated development of CCEC in recent years such as Chengdu-Chongqing urban agglomeration development plan. Therefore, it is necessary to fully consider the impact regional interactions on the territorial space brought about by the migration and logistics, so as to build a coordinated and efficient territorial spatial linkage network in CCEC. On the other hand, the URSUE development gap in the east-west direction must also be emphasized which means the core region need to actively strengthen the regional cooperation, improve the adaptability of the living function and ecological function with the surrounding regions in order to promote the benign interaction of URSUE among different regions in CCEC.

