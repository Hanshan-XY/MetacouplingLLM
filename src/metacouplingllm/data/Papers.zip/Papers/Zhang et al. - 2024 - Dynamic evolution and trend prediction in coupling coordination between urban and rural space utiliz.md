# Dynamic evolution and trend prediction in coupling coordination between urban and rural space utiliz

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:19:10.806746+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Zhang et al. - 2024 - Dynamic evolution and trend prediction in coupling coordination between urban and rural space utiliz.pdf
- Year: unknown
- DOI: 10.1016/j.heliyon.2024.e31578
- OA status: gold
- License: cc-by-nc-nd
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This study examines how efficiently urban and rural land is used in the Chengdu-Chongqing Economic Circle (CCEC) in western China, and how well these two subsystems develop together over time and space. The system context is an urban agglomeration that is both a major economic hub and an ecologically sensitive region at the upper Yangtze River, experiencing rapid urbanization, land-use conflicts, and widening urban-rural disparities.

The authors build separate efficiency indices for urban and rural space utilization using a super-efficiency, non-radial network DEA model that incorporates both desired and undesired outputs. Urban efficiency indicators emphasize non-agricultural labor, capital investment, population density, income, and urbanization, while rural indicators focus on agricultural inputs, output, and rural population. They then use a traditional coupling coordination degree (CCD) model and an extended Local and Tele-coupling Coordination Degree (LTCCD) model, which adds inverse-distance weights to capture cross-city spatial spillovers. A GM(1,1) grey prediction model, exploratory spatiotemporal data analysis, and trend surface analysis are applied to 16 CCEC cities for 2005-2020, with projections to 2030.

Results show that urban spatial efficiency is relatively low and declining in many economically advanced cities, especially Chengdu and Chongqing, implying intensive and sometimes inefficient urban land use. Rural efficiency is more stable and often higher, with some less developed cities showing particularly efficient rural land use. Traditional CCD tends to overstate coordination levels; the LTCCD model yields lower, more realistic values and highlights higher coordination in the geographic center (e.g., Meishan, Ya-an, Zigong) rather than only in core economic cities.

Spatiotemporal analysis reveals strong spatial cohesion but limited progress from medium to high coordination, with east-west contrasts emerging as the main axis of differentiation. The framework explicitly addresses telecoupling and metacoupling by modeling how urban-rural spatial efficiency interactions are shaped not only by local conditions but also by cross-city linkages via migration, logistics, transportation, and economic flows.

## Structured Metacoupling Extraction

### Coupling Classification
- Focuses on intracoupling of urban and rural spaces and telecoupling among CCEC cities.

### Intracoupling
#### Systems
- Urban space utilization subsystem within each CCEC city
- Rural space utilization subsystem within each CCEC city
#### Flows
- Labor and capital between urban and rural sectors inside each city
- Land conversion between urban construction land and rural agricultural land
#### Agents
- Municipal governments of CCEC cities
- Local residents including farmers and urban workers
- Regional planning and ecology agencies
#### Causes
- Rapid urbanization increasing construction land demand
- National strategy for territorial spatial optimization
- Economic development widening urban rural gaps
#### Effects
- Urban space efficiency often lower than rural efficiency in rich cities
- Rural depopulation and weakened rural development vitality
- Urban environmental pressures such as pollution and heat islands

### Pericoupling
#### Systems
- Neighboring cities within Chengdu Chongqing Economic Circle
- Adjacent urban and rural areas across city borders
#### Flows
- Short distance commuting and population migration between nearby cities
- Regional logistics and transportation of goods
#### Agents
- Prefecture level city governments in CCEC
- Transport and logistics enterprises
#### Causes
- Integrated development policy for Chengdu Chongqing urban agglomeration
- Spatial spillover and siphoning between close cities
#### Effects
- Spatial clustering of similar LTCCD levels among neighbors
- Medium level coupling coordination dominating regional pattern

### Telecoupling
#### Systems
- Chengdu Chongqing Economic Circle cities as interacting systems
- Broader national strategies like Belt and Road and Yangtze River Belt
#### Flows
- Information, capital, and logistics flows across distant CCEC cities
- Population migration among cities driven by job opportunities
#### Agents
- Central government shaping national spatial policy
- Provincial and municipal planners coordinating city cluster
- Economic actors influencing investment flows
#### Causes
- Globalization and open economy intensifying remote interactions
- Urbanization driven transport and logistics connectivity
- National designation of CCEC as major growth pole
#### Effects
- Spatial spillover of urban rural efficiency across cities
- Central cities shifting from followers to regional leaders
- East west disparities in LTCCD becoming key differentiation axis

### Cross-Coupling Interactions
- Local urban rural coupling interacts with telecoupled spillovers modeled by LTCCD.
- Natural disasters like major earthquakes disrupt both local and remote coordination.
- Urban efficiency, rural efficiency, and CCD jointly shape regional telecoupling dynamics.

### Research Gaps or Limitations
- Efficiency focus neglects equity of territorial space resource allocation.
- LTCCD distance uses only administrative center geometry ignoring economic or demographic weights.
- Study limited to 16 CCEC cities; transferability to other regions untested.

### Search Keywords
- urban rural space utilization efficiency CCEC LTCCD
- local and tele coupling coordination model China
- Chengdu Chongqing urban agglomeration CCD DEA

### Extraction Confidence
high
