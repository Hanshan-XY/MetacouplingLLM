# Economic drivers of telecoupling and terrestrial carbon fluxes in the global soybean complex

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:14:44.442706+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Yao et al. - 2018 - Economic drivers of telecoupling and terrestrial carbon fluxes in the global soybean complex.pdf
- Year: unknown
- DOI: 10.1016/j.gloenvcha.2018.04.005
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper investigates how economic forces link distant human-environment systems through global soybean trade, with a focus on Brazil, China, and the United States. It explicitly applies and advances the telecoupling and metacoupling framework by examining how distant demand, domestic changes, and spillovers jointly shape production, land use, and terrestrial carbon emissions.

The authors use a modified computable general equilibrium model, GTAP-BIO, extended to distinguish genetically modified and non-GM soybeans, multiple crops, biofuels, and detailed land-cover types (cropland, pasture, forest) by agro-ecological zone. The global economy is treated as a fully coupled system, and the 2004 base year is projected to 2011 using observed changes in key socioeconomic drivers. These drivers are grouped into five categories: macroeconomic growth (GDP, population, capital, labor, investment), soybean sector productivity (including Chinese feed industry restructuring and GM adoption), productivity in other crops and land intensification, government and trade policies (agricultural supports, tariffs, biofuel mandates), and productivity and policy changes in pasture and forestry. A decomposition method attributes changes in trade, production, and emissions to each driver and region.

The model reproduces more than 80 percent of observed bilateral soybean trade changes over 2004-2011. China’s rapid economic expansion is the dominant driver of the global soybean boom, sharply increasing its soybean imports. Brazilian soybean total factor productivity growth, largely from widespread GM adoption, enables Brazil to capture Chinese demand, expand soybean area, and overtake the US as China’s main supplier. These gains displace US exports, illustrating strong negative spillovers within the telecoupled system.

In Brazil, productivity gains and external demand drive cropland expansion and associated carbon emissions, mainly through conversion of forests and pasture. China and the US see little net cropland expansion and modest carbon effects. The study thus provides a clear empirical telecoupling analysis, showing how distant economic growth and technology shifts propagate through trade to alter land use and carbon fluxes.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via Brazil China US soybean trade and land carbon linkages

### Intracoupling
#### Systems
- National agricultural land use and carbon dynamics within Brazil
- Domestic soybean production and policy system in China
- US crop and biofuel production system
#### Flows
- Internal shifts among cropland pasture and forest
- Domestic soybean flows to livestock and food sectors
- Capital and labor reallocations between farm and nonfarm sectors
#### Agents
- Farmers and livestock producers
- National governments setting agricultural and trade policies
- Biofuel industries and feed manufacturers
#### Causes
- Macroeconomic growth changing internal demand and factor allocation
- Adoption of GM soybeans and other productivity gains
- Domestic support and stockpiling policies influencing crop choices
#### Effects
- Cropland expansion or contraction within countries
- Terrestrial carbon emissions or savings from land cover change
- Shifts in national soybean output and sector competitiveness

### Pericoupling
#### Systems
- Brazil and neighboring South American agricultural exporters
- EU and US biofuel linked crop markets
- China and nearby Asian feed and livestock systems
#### Flows
- Regional spillover of crop and pasture productivity changes
- Biofuel driven trade in feedstocks and byproducts
- Price spillovers in regional soybean and maize markets
#### Agents
- Regional trading partners and blocs
- Biofuel policy makers in US EU Brazil
- Regional grain crushers and feed companies
#### Causes
- Biofuel mandates altering regional crop demand
- Trade border policies shifting regional sourcing
- Productivity changes in nonsoy crops affecting land competition
#### Effects
- Displacement of production among neighboring exporters
- Regional land use changes in pasture and forest
- Modified regional carbon fluxes from agriculture

### Telecoupling
#### Systems
- Brazilian soybean production and land system
- Chinese feed livestock and food demand system
- US soybean and competing crop system
#### Flows
- International soybean and soymeal trade Brazil China US
- Embodied land use change and carbon emissions in soybean exports
- Global capital investment and migration affecting agriculture
#### Agents
- International traders and crushing industries
- National governments setting tariffs and GMO regulations
- Global modelers using GTAP BIO for policy analysis
#### Causes
- Rapid Chinese GDP and population growth boosting soybean import demand
- Brazilian GM soybean productivity gains reducing production costs
- Chinese GMO ban and tariff structure favoring soybean imports
#### Effects
- Brazilian cropland expansion and associated deforestation emissions
- Decline in Chinese soybean production and forest conservation leakage
- US loss of soybean market share and altered land use

### Cross-Coupling Interactions
- Chinese demand growth and Brazilian productivity jointly reconfigure global soybean trade and land use
- Brazilian productivity growth displaces US exports while amplifying Brazilian cropland expansion
- Biofuel policies elsewhere alter crop competition and indirectly affect soybean land and carbon outcomes

### Research Gaps or Limitations
- Framework emphasizes market drivers while downplaying infrastructure regulations and speculative land clearing
- Does not resolve subnational supply chains or actor level heterogeneity
- Biodiversity food security poverty and water impacts remain largely unquantified

### Search Keywords
- telecoupling soybean trade Brazil China US
- GTAP BIO land use carbon emissions
- macroeconomic drivers GM soybean productivity

### Extraction Confidence
high
