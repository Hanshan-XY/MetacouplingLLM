# Agroecological transitions to sustainability and biosphere reserves

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:40:12.834966+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: de Lucio and Seijo - 2023 - Agroecological transitions to sustainability and biosphere reserves.pdf
- Year: unknown
- DOI: 10.1080/21683565.2023.2231370
- OA status: green
- License: cc-by-nc-nd
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This article investigates how local agroecological initiatives in Spain contribute to community resilience, and whether being inside a UNESCO Biosphere Reserve (BR) strengthens these contributions. The study focuses on two case areas: La Vera in Extremadura (a non-BR region) and the Mariñas Coruñesas e Terras do Mandeo BR in Galicia. Both areas host networks of small agroecological producers and consumers, often organized around short supply chains and community supported agriculture models.

The authors frame the cases as coupled human and natural systems (CHANS), explicitly linking them to telecoupling and metacoupling: urban consumers depend on rural production systems, and these links are shaped by distant institutions such as the European Union and national governments. The work combines participatory action research, semi-structured interviews, and a survey of 40 stakeholders (mainly highly educated rural residents, both producers and consumers). Responses were analyzed through principal components analysis and then aggregated into indicators for several community resilience attributes, including local knowledge, community networks, governance, financial resources, mental outlook, and perceptions of natural resource use.

Participants rated environmental benefits, nature conservation, product quality, and local knowledge very positively in both regions. However, they identified two major barriers to resilience: weak economic competitiveness due to higher prices of agroecological products relative to conventional goods, and governance problems linked to subsidy dependence and burdensome regulation. Direct producer-consumer relations, participatory decision making, and trust-based networks were seen as the most supportive governance mechanisms; state administrations at municipal and regional levels were viewed critically.

Comparisons between the BR and non-BR sites revealed no statistically significant differences in aggregate resilience scores, but some qualitative contrasts. Respondents in the BR perceived governance somewhat less negatively than those in La Vera, suggesting that BR status can modestly enhance institutional leverage and visibility for agroecological initiatives, for example through EU-funded food plans. Overall, the paper is explicitly grounded in CHANS, telecoupling, and metacoupling theory, using these concepts to understand how local agroecological niches interact with broader political-economic systems and distant consumer markets.

## Structured Metacoupling Extraction

### Coupling Classification
- Study applies CHANS and metacoupling to agroecology and Spanish biosphere reserves
- Analyzes intracoupling inside reserves and rural areas plus urban rural telecoupling
- Telecoupling concept used explicitly to frame distant consumer producer linkages

### Intracoupling
#### Systems
- La Vera agroecological CHANS in Extremadura
- Mariñas Coruñesas e Terras do Mandeo biosphere reserve CHANS
- Local community supported agriculture and food networks
#### Flows
- Agroecological food products within each territory
- Knowledge sharing and participatory learning among local stakeholders
- Financial flows from local markets and public subsidies
#### Agents
- Agroecological farmers and cooperatives
- Local consumers and consumer groups
- Municipalities and regional rural development associations
#### Causes
- Search for alternatives to unsustainable conventional agrifood systems
- Local initiatives using agroecology as transition niche
- Biosphere reserve designation enabling pilot sustainability projects
#### Effects
- Enhanced local community resilience attributes and networks
- Conservation of biodiversity, soil, water and cultural landscapes
- Persistent challenges of profitability, pricing and bureaucratic constraints

### Pericoupling
#### Systems
- Neighboring rural municipalities within each case region
- Regional governance structures and autonomous communities
- Nearby urban center A Coruna surrounding the biosphere reserve
#### Flows
- Short supply chains for regional agroecological products
- Regional policy, certification and development program support
- Tourism and ecotourism related to protected landscapes
#### Agents
- Autonomous community administrations and technical staff
- Regional rural development associations implementing food plans
- Regional certification and participatory guarantee organizations
#### Causes
- Regional rural development and LEADER funding opportunities
- Decline of traditional farming and rise of forestry monocultures
- Strategic choice to market reserve products to nearby cities
#### Effects
- Creation of regional food plans and branding for reserve products
- Improved access to land and markets for some producers
- Ongoing tensions over regulations, subsidies and local autonomy

### Telecoupling
#### Systems
- Spanish urban consumer CHANS dependent on rural production
- Globalized agrifood supply chains competing with local niches
- International governance frameworks like UNESCO MAB and EU CAP
#### Flows
- Demand and price signals from distant urban food markets
- EU and national subsidies, regulations and certification schemes
- Normative discourses on agroecology, food sovereignty and sustainability
#### Agents
- Urban consumers supporting agroecological networks
- European Union institutions funding and regulating agriculture
- UNESCO biosphere reserve program influencing governance
#### Causes
- Global food system crises and long supply chains
- Metacoupling driven feedbacks between distant CHANS
- Ethical consumption and willingness to pay among urban allies
#### Effects
- Erosion of short food chains through global competition
- New ethical codes, labels and sustainability standards
- Agroecological niches relying on non utilitarian motivations

### Cross-Coupling Interactions
- Metacoupling links local agroecology niches with distant urban consumers and global regimes
- Biosphere reserves act as institutional windows mediating local, regional and global drivers
- Telecoupled policies reshape intracoupled community resilience attributes and governance perceptions

### Research Gaps or Limitations
- Small non probabilistic sample and two case studies limit generalization
- Telecoupling analysis mostly conceptual, limited quantitative flow mapping
- Future work proposed on cultural political drivers of non utilitarian behavior

### Search Keywords
- agroecology coupled human and natural systems biosphere reserve Spain telecoupling
- community resilience short food supply chains La Vera Marinas Corunesas
- metacoupling urban rural linkages EU subsidies governance agroecological transitions

### Extraction Confidence
high
