# Disentangling the Local Coupling and Telecoupling of Urbanization and Ecosystem Services to Reveal A

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:11:59.384516+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Xia et al. - 2025 - Disentangling the Local Coupling and Telecoupling of Urbanization and Ecosystem Services to Reveal A.pdf
- Year: unknown
- DOI: 10.1002/ldr.5607
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This paper examines how urbanization interacts with ecosystem services (ESs) both locally and over distance in a large Chinese urban region, using telecoupling and metacoupling concepts explicitly.

The study focuses on the Beijing-Tianjin-Hebei (BTH) urban agglomeration in North China, which includes two large municipalities and 11 surrounding cities. The authors treat urbanization and ESs as two coupled subsystems of a broader social-ecological system.

They map urbanization (combining population density, built-up land share, and nighttime lights) and seven ESs for 199 counties in 2000, 2010, and 2020: grain production, water yield, carbon storage, air pollution removal, soil retention, habitat quality, and outdoor recreation. ESs are modeled with land use data, biophysical models such as InVEST and RUSLE, and ancillary environmental and socioeconomic layers.

Local coupling (within each county) between urbanization and each ES is measured with a standard coupling degree index. Telecoupling (between distant counties) is quantified with a gravity-style model that scales interaction strength by the product of urbanization and ES levels and decays with squared distance. Network analysis identifies strong telecoupled links. Hierarchical clustering groups counties into archetypes based on all local and telecoupling indicators, and social-ecological drivers are examined with nonparametric tests and random forest models.

Results show rapid urban growth, especially around Beijing, Tianjin, and major Hebei cities, and heterogeneous ES trends: some services increase (e.g., grain, recreation), others decline (e.g., carbon storage, habitat quality). Local coupling generally strengthens over time, with many counties where urbanization either lags or is roughly in balance with ESs. Telecoupling patterns differ by service, forming distinct spatial networks connecting core cities with grain-producing plains and mountainous ES source areas.

Four archetypical interaction types emerge, aligned with an urban-peri-urban-rural gradient and interpreted through a red-loop/green-loop lens: two ES-exporting, relatively green-loop clusters in mountain and agricultural zones; a largely locally coupled transition cluster in peri-urban areas; and a red-loop cluster of core cities heavily dependent on external ESs. The paper is firmly grounded in telecoupling/metacoupling and uses these concepts to propose differentiated land management and ecological compensation strategies for urban agglomerations.

## Structured Metacoupling Extraction

### Coupling Classification
- Addresses both intracoupling within counties and telecoupling among distant counties in an urban agglomeration

### Intracoupling
#### Systems
- Urbanization system versus local ecosystem services within each county in Beijing-Tianjin-Hebei
- Socioeconomic subsystem interacting with ecological subsystem at county scale
#### Flows
- Local feedbacks between built-up expansion and county-level ecosystem service provision
- Bidirectional interactions between urban growth indicators and aggregated ES indices
#### Agents
- County and municipal governments managing land and development
- Local residents and firms driving population, economy, and land conversion
- Regional planners implementing urbanization and land policies
#### Causes
- Rapid urban expansion increasing built-up land, GDP, and population density
- Land use change from cropland or natural land to urban uses
- Policies emphasizing coupled assessment of development and environment
#### Effects
- Increasing local coupling degree between urbanization and several ecosystem services
- Prevalent patterns of urbanization lagging or balancing ecosystem services locally
- Spatial gradients of local coupling stronger in peri-urban and some southern counties

### Pericoupling
#### Systems
- Not identified.
#### Flows
- Not identified.
#### Agents
- Not identified.
#### Causes
- Not identified.
#### Effects
- Not identified.

### Telecoupling
#### Systems
- Highly urbanized central cities coupled with remote grain-producing plains
- Urban cores linked to mountainous counties supplying regulating services
- Rural and semi-natural counties exporting ecosystem services to external urbanization
#### Flows
- Telecoupled flows of grain and other provisioning services from southern Hebei to core cities
- Flows of regulating and supporting services like carbon storage and soil retention from mountains to metropolises
- Outsourced ecosystem service dependence of central urban areas on distant ecosystems
#### Agents
- Urban consumers and industries demanding external ecosystem services
- Rural land managers and farmers in sending regions
- Higher-level authorities shaping requisition-compensation cropland policy and ecological compensation
#### Causes
- Local ecosystems insufficient to satisfy growing urban ecosystem service demand
- Cropland requisition-compensation policy displacing production to distant counties
- Economic globalization and regional integration strengthening distant urban-rural linkages
#### Effects
- Distinct telecoupling networks between urbanization and grain, air purification, soil retention, habitat quality
- Increased environmental pressure and resource exploitation in sending rural and mountainous areas
- Emergence of green-loop, red-loop, and transition archetypes along urban-peri-urban-rural gradients

### Cross-Coupling Interactions
- Four archetypes combine patterns of local coupling and telecoupling along the urban to rural gradient
- Green-loop clusters export surplus ecosystem services while maintaining relatively strong local human-nature ties
- Red-loop urban cores show strong telecoupling and weaker direct dependence on local ecosystems

### Research Gaps or Limitations
- Gravity-based telecoupling metric oversimplifies real flows and omits explicit trade and mobility data
- Telecoupling analysis restricted to within the Beijing-Tianjin-Hebei region; external linkages not quantified
- Future work suggested to use finer ES flow models, multi-regional input-output, and telecoupling toolboxes

### Search Keywords
- urbanization ecosystem services telecoupling Beijing Tianjin Hebei archetypes
- local coupling gravity model spatial networks green loop red loop
- urban agglomeration land management ecological compensation China

### Extraction Confidence
high
