# Prioritizing partners and products for the sustainability of the EU’s agri-food trade

![](images/1fa5ad6b88461f9f8f430f07f9b8d5009d4db7aac6f363843a86ccd4ba9cec27.jpg)  
Graphical abstract

# Highlights

d Relevance and leverage help prioritizing trade relations for sustainability action   
d Relevance identifies how to reduce the magnitude of the EU’s global impact   
d Leverage identifies producing countries with a strong EU influence   
d Sustainability of global agri-food systems requires complementary policy packages

# Authors

Yves Zinngrebe, Jurij Berger, Christian Bunn, ..., Guy Pe’er, Christian Schleyer, Sebastian Lakner

# Correspondence

yves.zinngrebe@ufz.de

# In brief

Assessing telecoupled effects of the EU’s trade relations in developing countries in terms of relevance and leverage helps to prioritize policy responses. High relevance values identify countries and products with strong contribution to the EU’s crop imports. High leverage values identify where large shares of domestic production is dedicated to exports into the EU. These values and product portfolios allow the identification of groups of key partner countries for improving the sustainability of global cropland production.

# Article

# Prioritizing partners and products for the sustainability of the EU’s agri-food trade

Yves Zinngrebe, $^ { 1 , 2 , 1 1 , ^ { \star } }$ Jurij Berger,2 Christian Bunn,2,3 Marı´a R. Felipe-Lucia,4,5,6 Nina Graßnick,2 Thomas Kastner,7 Guy Pe’er,4,5 Christian Schleyer,8,9 and Sebastian Lakner2,10

1Department for Conservation Biology and Social-Ecological Systems, Helmholtz Centre for Environmental Research (UFZ), Leipzig, Germany

2Department for Agricultural Economics and Rural Development, University of Go¨ ttingen, Go¨ ttingen, Germany

3Alliance of Bioversity International and CIAT, Cali, Colombia

4Department for Ecosystem Services, Helmholtz Centre for Environmental Research (UFZ), Leipzig, Germany

5German Centre for Integrative Biodiversity Research (iDiv) Halle-Jena-Leipzig, Leipzig, Germany

6Departamento de Conservacio´ n de la Biodiversidad y Restauracio´ n de Ecosistemas, Instituto Pirenaico de Ecologı´a, Jaca (Huesca), Spain

7Senckenberg Biodiversity and Climate Research Centre, Frankfurt, Germany

8Section of International Agricultural Policy and Environmental Governance, Faculty of Organic Agricultural Sciences, University Kassel, Witzenhausen, Germany

9Institute of Geography, University of Innsbruck, 6020 Innsbruck, Austria

10Faculty for Agricultural and Environmental Sciences, University Rostock, Rostock, Germany

11Lead contact

*Correspondence: yves.zinngrebe@ufz.de

https://doi.org/10.1016/j.oneear.2024.03.002

# SUMMARY

Global agri-food systems couple sustainability challenges in producing countries to consumption behavior and regulations in destination markets. We assume that trade relations can be prioritized according to (1) the relevance (share of imports) and (2) leverage (share of domestic production for destination market). This study analyzes the relevance and leverage of the EU’s crop imports in monetary values, footprints, and deforestation. Our results identify high relevance and leverage values in trade relations with specific partner countries, particularly palm oil and rubber specialists in East Asia and soy-producing MERCOSUR countries. High leverage values in imports from African-Caribbean-Pacific small sugar specialists and other small countries highlight the EU’s potential to establish sustainability criteria. We suggest that the EU revises incoherent foreign and domestic policies and proactively engages with trading partners to include sustainability safeguards in the whole value chain with particular focus on trade relations with high relevance and leverage values.

# INTRODUCTION

Meeting the global sustainability agenda requires a transformation of agri-food systems to provide food security, sustainable livelihoods, and sustain healthy ecosystems for future generations.1 Strategies for simultaneously generating economic development opportunities and mitigating environmental impacts need to take into account the ‘‘telecoupled’’ interdependence of production and consumption systems, linking causes and effects for sustainability in geographically distant regions.2 With the normative principle referred to as ‘‘Policy Coherence for Development’’ (PCD), the European Union (EU) has committed to review its policies and external relations to coherently support developing countries in their endeavor to meet United Nations’ Sustainable Development Goals (SDGs).3 PCD addresses the transfer of resources, and hence of wealth, from developing to developed countries (as defined by the United Nations $\lbrack \mathsf { U N } \rbrack ^ { 4 } )$ , and is therefore fundamentally linked to questions of equity and justice.5 The EU’s Green Deal and its Farm to Fork Strategy

intend to support a global transition toward sustainable agri-food systems,6 and their implementation will require an integration of different policy fields including trade policy7 and land-use policies.8 We argue that achieving these targets and supporting global sustainability in line with PCD needs to be guided by a better understanding of the telecoupled interdependencies between the EU’s consumption, and environmental and socio-economic impacts in developing countries.

So far, scientific literature attests only a low level of PCD implementation in the EU,9 highlighting the need for major institutional adjustments across several policy fields. Most prominently, the EU’s Common Agricultural Policy (CAP), with an annual budget of almost 60 billion Euros in 2019 $( 3 8 \%$ of the EU’s budget), has been criticized for decades for distorting markets and limiting the economic potentials of developing economies.10 Similarly, EU trade policies have been criticized for offshoring their environmental effects on developing countries.11,12 For example, tropical deforestation driven by agricultural expansion and intensification has been linked to consumption of

![](images/fe2401c62d4f7d3b933c01768572f56b9cff17e2703dd1f1efc211941e319c60.jpg)  
Figure 1. Conceptual figure to prioritize telecoupled agri-food systems for improving PCD implementation and the PCD potential of trade relations with specific countries or products according to their relevance (strength of contribution to the EU imports) and leverage (size of the share of domestic production dedicated to export to the EU)

Source: own presentation. A–H represent hypothetical products or developing countries trading with the European Union. Figure 2 shows the results with actual data for products, Figure 4 for trading partners.

agricultural commodities in the developed world in general, and the EU in particular,13 threatening the world’s biodiversity hotspots and carbon sinks.14 Similarly, policies supporting the use of biofuels are tightly connected to tropical deforestation either directly (e.g., clearance of primary forests for palm oil and timber plantations) or indirectly by driving land-use changes.15

The telecoupling lens provides an analytical framework to link land-use dynamics, such as those derived from international trade, with interdependent governance structures in telecoupled systems.16 These telecoupled effects show that coherent responses to sustainability require the EU to not only think about policies to support sustainability initiatives in developing countries, but also about the governance systems that have induced telecoupled impacts in the first place or that coordinate their persistence.17 Thus, effective governance requires coordinated and coherent responses across sector policies and value chains guided by information on external, telecoupled effects.

Here, we argue that the EU can identify and prioritize suitable policy options for implementing PCD by assessing [telecoupled] impacts in telecoupled agri-food systems based on two factors: relevance and leverage (Figure 1). Relevance is here assessed by identifying products and developing countries that supply a high share of the EU’s overall import values, thus having the strongest influence on the EU’s overall PCD performance in terms of economic and ecological impacts; leverage is the share of production in a country of origin or a specific product that is dedicated for export to the EU. The higher the leverage value, the higher is the potential of the EU to improve the sustainability of the particular telecoupled system. We used trade data from the Food and Agriculture Organization (FAO) to assess the monetary imports values of the EU’s imports and calculated the equivalent cropland area harvested18 and the resulting deforestation in the pro-

ducing countries induced by EU imports for average annual values for the period from 2009 to 2013.13 The definition of developing countries has been adopted from the UN. In the following, we identify the products (i.e., soybeans, palm oil, coffee, and cocoa) and corresponding groups of producing countries (e.g., the MERCOSUR countries and palm oil and rubber specialists in East Asia) with the highest relevance and high leverage values. Finally, we discuss the specific telecoupled nature of these trade relations and point to specific implications for current EU policies to mitigate negative EU environmental and social influences. We find that policy implications to effectively govern telecoupled effects go beyond trade regulations and standards and instead require policy packages for foreign and domestic policies targeted to the nature of trade relations.

# RESULTS

# Prioritizing countries and products for the EU’s PCD Relevance and leverage of products

The highest values for relevance, and significantly aboveaverage values for leverage in all dimensions, were found for soybeans, palm oil, coffee, and cocoa (Figures 2 and 3, see Table S1 for detailed results). A second product group with high relevance and above median leverage values were raw sugar, rubber, bananas, grapes, and tobacco. Lower relevance and leverage values for deforestation can be found for oranges, rice, maize, sunflower seed, rapeseed, and wheat.

A group of products with very low relevance but very high leverage values in monetary terms and cropland footprint are vanilla, blueberries, castor oil seed, linseed, and cranberries. For these products, the cropland footprint concentrates on a few individual countries, as apparent for vanilla $( 9 7 \%$ of cropland footprint in Madagascar), blueberries $7 1 \%$ Morocco), castor oil seed $( 9 8 \%$ India), or mustard seed $7 6 \%$ Ukraine), meaning that individual trade relations have a strong effect on land-use changes in the producing countries. Low relevance and high leverage values in monetary terms were found for hazelnut, mustard seed, Brazil nut, currant, and flax fiber. The above-median leverage values indicate a strong focus of the products on the EU market and a comparatively strong influence of EU consumption and trading conditions.

# Relevance and leverage of developing countries

The three countries with the highest relevance values for monetary imports, cropland footprint, and imported deforestation (Brazil, Argentina, Indonesia) also show above median leverage values (Figure 4, see Table S2 for detailed results). All other analyzed countries show diverging patterns. Thus, for each of the three analyzed dimensions, we selected countries with highest values for relevance and leverage and clustered them into eight groups according to their exported product portfolio (Figure 5) and mapped their geographical distribution (Figure 6).

The MERCOSUR countries, Brazil, Argentina, Paraguay, and Uruguay, show very high relevance values in all three dimensions, mainly driven by exports of soybean products. These countries also show significantly above-average leverage values, highlighting the strong connection of EU consumption with land-use changes and deforestation in Latin America.

The palm oil and rubber specialists include Indonesia, Malaysia, and Papua New Guinea, which account for $90 \%$ of cropland

![](images/e80aeebbb9830ea310d42c0e4610a33477268268ecd3037e24544251a3fa0bd1.jpg)

![](images/d783d97ce129c794d37ec59e9e40e9023e7dbaab910222d1638a654f22c0a74d.jpg)

![](images/7329de58f40999bae7085adc00dfcc827aaf38ff44a54bf167a0512315ff8d44.jpg)  
Figure 2. Relevance and Leverage Values for Products

Relevance and leverage of products from developing countries destined for the EU market in (A) economic import value (in USD), (B) cropland footprint (in ha), and (C) imported deforestation (in ha). Relevance (y axis) indicates the share of a product in relation to the overall EU imports. Leverage indicates the share of the product in the producing country destined for the EU market. Source: own calculations; See supplemental material for the detailed data and Figure 1 for conceptual background. Note that staple crops include cereals and legumes and spices include tea and mate.

A group of Mediterranean fruits and vegetable producers (Morocco, Tunisia, Egypt, Turkey) have a relevance in monetary imports of $6 . 5 \%$ , cropland footprint of $2 . 5 \%$ , and very low $( < 0 . 2 \% )$ ) imported deforestation. Turkey provides $84 \%$ of the cropland needed for the EU’s hazelnut imports. About $9 9 \%$ of the cropland footprint   
![](images/96cdef858208e09af6defb1c5864225d10e492b9c7b0528556dc1773b608c130.jpg)  
Source: own calculations. Imports from developed countries are not included. Relevance indicates the share of a specific product indicates the share of a product in relation to the overall EU imports. The figure highlights and accumulates relevance values for the four major product categories, soybeans, oil palm fruit, coffee, and cocoa, to emphasize their dominant effect, particularly for imported deforestation.

Figure 3. Relevance of different products from developing countries with regard to economic relevance (import share) and ecological relevance (cropland footprint and deforestation 2009–2013)

footprints, and $9 9 \%$ of imported deforestation linked to EU palm oil imports. They further provide $89 \%$ of EU imports of palm oil in monetary terms. These countries additionally export rubber, coffee, and cocoa and show above median leverage values.

The coffee and cocoa specialists are characterized by high relevance values and above-median leverage values in cropland and deforestation footprints, and tend to additionally export rubber and fruits. Countries with these characteristics include: Uganda, Coˆ te d’Ivoire, Ghana, Cameroon, Congo, Togo, and Nigeria in Africa; Colombia, Peru, Ecuador, Costa Rica, and Honduras in Latin-America; and Vietnam in Asia.

The group of ACP-small sugar exporters are part of the African-Caribbean-Pacific producers (ACP). These countries include Mauritius, Fiji, Barbados, Guyana, Esuatini (formerly Swaziland), and Bahamas, whose exports represent more than $80 \%$ of total EU sugar imports, both in monetary values and cropland footprint. The EU has low relevance, but very high leverage values in these countries, both for cropland footprint and monetary imports.

The group of East European and Central Asian grain exporters include Russia, Ukraine, Kazakhstan, Moldova, Belarus, and Serbia. About $69 \%$ of the cropland footprint imported into the EU from these countries are used for the production of cereals (wheat, maize, barley) or oil seeds (sunflower, rapeseed, linseed). The EU has a strong leverage in these countries. Sunflower is particularly relevant for the land-use associated with EU imports, representing $3 8 \%$ of the total cropland area harvested in Ukraine and Russia being dedicated to EU exports.

A group of large generalist countries have a monetary relevance value of at least $2 \%$ and provide a high variety of products with no single product category dominating. These countries are China, India, Thailand, Chile, and South Africa. Russia and Brazil could also fit into this group, but have been allocated to other groups based on their product portfolio. These large generalist countries have below-median leverage values in all dimensions, with the exception of Chile.

imported to the EU for olive consumption is located in Tunisia, Morocco, and Turkey.

Finally, a group of individual specialists are countries with a particularly high leverage value in either cropland footprint or monetary import value $( > 1 0 \% )$ and a strong specialization by dedicating at least $67 \%$ of the area for exports into the EU to one single product. Examples are the Seychelles $( 9 9 \%$ of exported cropland footprint is from cinnamon production), Saint Lucia $8 9 \%$ bananas), French Polynesia $9 6 \%$ coconuts), and Suriname $7 4 \%$ rice). Examples of specialist countries with high leverage values in monetary terms are Namibia $( 9 2 \%$ grapes) and Comoros $( 6 7 \%$ cloves). These countries are not included in Figure 4 because of low relevance values.

The remaining analyzed countries present neither high values for relevance nor leverage. These countries only have an accumulated relevance for EU imports of $1 3 \%$ in monetary terms, $1 3 \%$ for cropland footprint, and $9 \%$ for deforestation.

# DISCUSSION

# Putting PCD into practice

Our results identify different clusters of EU trade relations with producing countries of high relevance and leverage values with key sustainability implications as indicated by monetary imports, cropland footprint, and imported deforestation. The nature of these telecoupled links and feedbacks points to several EU policy implications and options for improving its PCD performance and contributing to global sustainability goals.

# Tackling trade relations with the highest ‘‘relevance’’ for PCD

# Our concept of relevance pinpoints key countries and products that dominate the EU’s global monetary imports, cropland footprint, and imported deforestation

Soybeans and palm oil alone contribute to $3 3 . 2 \%$ of the EU’s imported footprint and $6 6 . 1 \%$ of the EU’s contribution to

![](images/1e9ebd64514ce76771aa4a7f14e4e4346228ba9a8524b3fe65271a5d3c52f60e.jpg)  
Importvalue(Billion US$)  
C 5   
10   
15

Country group

Coffee/cocoa

Fruits/Vegetables

Grain

Large Generalists

MERCOSUR

。Other

Palm Oil-Rubber

Sugar

![](images/f42f0617281ba46d63cdecf095408169db8b66e9d6b0e1c95417291fef2a292d.jpg)  
Land footprint（Million ha)  
  
  
  
6

Figure 4. Relevance and leverage values for trading partner countries.   
![](images/78bb16e3d458fe44fceb700181a2e40648161f2bd7ea7d7c2acae9d6079b1b80.jpg)  
Deforestation   
(1000 ha/year)   
10   
20   
30   
40

Relevance and leverage of developing countries trading with the EU are assessed in (A) economic import value (in USD), (B) cropland footprint, and (C) imported deforestation. Source: own calculations. See supplemental material A for detailed results and Figure 1 for conceptual background. Relevance (y axis) indicates the share from a specific developing country in relation to the overall EU cropland product imports. Leverage indicates the share of cropland production from a respective developing country destined for the EU market. Note that: Coffee/Cocoa and Palm oil/Rubber refer to specialist countries; Fruit/Veg refers to Mediterranean Fruit and Vegetable Producers; Grain refers to Eastern European and Central Asian grain exporters; Sugar refers to ACP Small Sugar Exporters.

Figure 5. Relevance of specific country groups with regard to economic relevance (import share), ecological relevance 1 and 2 (cropland footprint, and deforestation 2009– 2013) between specific groups of selected countries   
![](images/d1652d94823e19be752f1a871f1c776c24de335224af09ca8967fbceb8510d50.jpg)  
Source: own calculation. The groups were selected based on similarity of production and on regional criteria. Relevance indicates the share from a specific developing country in relation to the overall EU cropland product imports.

border adjustments and value chain regulation reveal questions regarding its potential effectiveness and political feasibility.25,26 The EU can make significant improvements by setting up a coherent food policy as part of the Green Deal, such as the proposed Sustainable Food System framework, and align trade agreements and international tax regulations to

global deforestation. Projections predict that developing countries will not reduce their ecological footprint alongside growing economic development, but will instead be locked into their role of biocapacity providers for the growing consumption in the Global North, including the EU.19 The EU can reduce the magnitude of such impacts by reducing its demand for products with highest ecological (external) costs, for instance, by addressing this in a policy for Sustainable Food Systems or other food consumption policies.10 In the EU, imports of soybeans and their derivatives are particularly important for livestock production.20 Healthy diets that remain within our planetary boundaries2 entail a shift away from meat, dairy, and sugar, and toward vegetables, fruits, unrefined grains, legumes, and nuts, producing ‘‘win-wins’’ between healthy diets and sustainable production,21 in line with SDGs 3 (health and wellbeing) and 12 (sustainable production and consumption). This example highlights how croplandrelated land-use changes in producing countries are telecoupled to support for unsustainable consumption and production systems. A key policy lever for the EU is phasing out the support for intensive animal production, which produces increased feed import demands. A specific example is coupled payments within the EU’s CAP that currently function as a harmful subsidy22; while extensive, sustainable grazing systems are lacking support.23

# Several EU policies need to be refined to generate an integrated solution for the external effects of European imports

The EU Commission has currently presented a due diligence regulation to address sustainability issues caused by European importers.24 In contrast to human rights aspects, environmental considerations in this regulation remain vague and fall short on specifying explicit targets and responsibilities for involved actors.25 Another powerful regulatory approach is a broader carbon tax to internalize not only costs for carbon emissions, but also for reducing carbon sinks and biodiversity through degradation and deforestation. Current discussions on both carbon

address challenges along the entire value chain, including production, processing, retail, and consumption.27

# Improved standards and border regulations are needed to address negative sustainability trajectories and trade-offs between sustainability dimensions

Cocoa, for instance, is contributing to $2 8 . 4 \%$ of the EU’s imported deforestation. However, if managed in shaded agroforestry systems, it can contribute to ecosystem services such as carbon storage, carbon sequestration, biodiversity conservation, and water regulation,28 which provide benefits to land users and help farmers to diversify income sources and farm resilience,29 a potential that could be harnessed by EU policies through targeted support of these value chains. Similarly, palm oil can provide local sustainable economic potentials, but only if complemented by appropriate regulatory structures such as farming contracts, land tenure, and nature protection safeguards.30,31 Hence, the EU standards and trade policies need to be more specific on their requirements for imports to minimize trade-offs and harness synergies. This requires coherent and consistent policy packages, to generate an integrative solution that is sensitive to contextual elements of value chains and national regulatory frameworks.

# Taking responsibility in countries and value chains with high EU ‘‘leverage’’

# Our concept of leverage identifies countries and products with high shares of production destined for EU consumption, giving the EU a strong potential—and responsibility—for establishing sustainability standards

The EU has not managed to fully capitalize from its high leverage in producing economies, such as in the soybean-producing MERCOSUR countries or the ‘‘palm oil-rubber specialist’’ countries. So far, initiatives to lower EU demand for soybeans and meat have had little impact on prices and global production, while generating a possible telecoupled risk of relocating problems to other countries.32 Similarly, EU regulations for palm oil and biofuel blending33 have neither stopped deforestation nor

![](images/1319b0fe39c217e59b98a38821d24d36dbdf7c2528e71353b21c0f3bbd5f6537.jpg)  
Figure 6. Relevance (share of imports from specific developing countries) and leverage (share of domestic production exported to the EU) of telecoupled trade relations with developing countries for monetary import values (A), cropland footprint (B), and imported deforestation (C).   
Source: own calculations according to the values presented in Figures 2–5. The developing countries with the highest values for relevance and leverage have been grouped according to their product portfolio.

![](images/40835f9075990d2ab6827b8c77665ef14a4bef18d799d16a5ffb37d4c7faddce.jpg)

![](images/03262f779fd39a3ad130a5f08d9d002d0dc4ef3c52d3e1b3852fe9743af7c21d.jpg)

established sustainability safeguards; instead they encouraged South Asian governments to expand palm oil exports to other countries.3 4 Decoupling development opportunities from environmental degradation and deforestation requires addressing the needs of production systems and local smallholders beyond market demands.30 Market-based initiatives and development partnerships between consuming and producing countries (e.g., for sustainable biofuel production) can create governance structures capable of assuring transparent tenure systems, decent working conditions, and nature protection regulation.35

# Governing market access to large trade destinations, such as the EU, has a strong effect on generating winners and losers both among and within developing countries

This is illustrated by the particularly high leverage in monetary import value of the ‘‘ACP small sugar exporter’’ countries, who are former colonies from the EU-countries France, Belgium, the Netherlands, and the United Kingdom, which used to have a preferential market access (zero tariffs) to the EU’s common market in the 1970s and 1980s. While political price interventions and import tariffs in the EU have substantially been reduced, ACP countries enjoy preferential access for sugar into the EU. A further progressive liberalization of the EU’s sugar trade regime would lead to a reduction in the benefits arising from market access with preferential conditions, referred to as ‘‘preference erosion.’’36 While some argue that $30 \%$ of the trade-flows to the EU would not exist without granted trade preferences,37 others criticize the instrument of preferential trade agreements38 for generating a strong dependence of the producing country on one commodity, risking their technological lock-in. Hence, instead of supporting developing countries with preferential trade agreements in liberalizing commodity markets, the EU could provide targeted cooperation supporting sustainable and diversified agriculture beyond monopolization of single value chains.

# Trade relations in telecoupled systems need to consider the general geopolitical international relations between involved countries

An important example can be found when looking at the group of ‘‘East European and Central Asian grain exporters’’ and its strong imports of grains, crops, and sunflowers (monetary relevance value of $6 . 9 \%$ and footprint of $1 5 . 6 \%$ , Figure 4). Some countries have high leverage values (Ukraine, Serbia, Moldova) indicating a strong orientation toward the EU market. Beyond the EU markets, the grain and oilseed-exporters Russia, Ukraine, and Kazakhstan take large shares of the world market with large trade relations to import-dependent developing countries. Yet, the Russian military invasion of the Ukraine had important impacts on the world commodity markets putting global food security at risk.39 Current trade engagement with these countries conflicts with PCD and the sustainability agenda, which calls for peaceful and inclusive societies and accountable institutions (SDG 16). The economic sanctions on agricultural products from Russia lead to trade losses on both sides40 and dominate these trade relations. In political reality, geopolitical conflicts dominate PCD performance, thereby marginalizing (other) sustainability objectives, and are likely to produce spill-over effects in other geographical regions. The recent wars and escalating conflicts show the links between global security and trade and highlight

the need for anticipatory and adaptive governance, which prepares trade relations for external shocks. Sustainability agendas need a legal backbone to achieve results despite dynamic security-driven agendas.

# Sustainability of telecoupled agri-food systems requires complementary policies in both producing and consuming countries

# Experiences show that telecoupled environmental impacts of EU consumption cannot be mitigated by environmental policies alone

For instance, soybean imports from MERCOSUR countries account for $28 \%$ of the EU’s imported cropland footprint (see Figure 3). Even though a large share of the produced meat is then exported to countries such as China, environmental ‘‘spillover’’ effects remain in the EU.2 An example is the nitrification of soils and water bodies due to high levels of manure in pork production areas in Northern Germany.41 Despite associated threats to biodiversity and climate, soy imports have been supported by zero tariffs on oilseeds and feed-substitutes of the EU since the 1960s,42 and by coupled payments for animal production after 1992.43 At the same time, Argentina has been expanding its soybean production since the 1990s,44 driven by support from a coalition of the World Bank, international agricultural interests, and private landowners.45 The EU has initiated certification initiatives linking soy production to anti-deforestation measures.46 These initiatives have, however, resulted in ‘‘leakage’’ effects by driving deforestation in other places, since interventions were not coordinated with other land-use policies and value chain initiatives. 4 7 Accordingly, curbing deforestation trends requires complementary policies in producing countries and international development support. Trade negotiations especially with the MERCOSUR countries could include minimum statutory requirements or sustainability standards for nature protection, including deforestation and pesticide application.48

# Private market initiatives, particularly on high-value products such as coffee, can be a promising tool for mobilizing consumers’ willingness to pay

Our results on coffee indicate both a high relevance value for imported deforestation $( 3 8 . 4 \% )$ and a strong EU leverage value $( 3 7 . 9 \%$ monetary imports, $2 9 . 2 \%$ cropland footprint, $3 8 . 4 \%$ deforestation), indicating a strong potential for the EU to work toward more sustainable forms of production. Certification schemes are powerful instruments adding brand value, enabling traceability, and providing strong economic opportunities for farmers and communities.49 However, there are still valid doubts regarding the extent to which labeling initiatives can actually increase landowners’ incomes,50 assure workers’ rights,51 ensure equitable and reliable income,49 prevent deforestation, or safeguard biodiversity52 and cultural heritage.53 In fact, some farmers could be excluded from market access if not successfully complying with sustainability criteria.49 By contrast, currently dominating regulatory and financial incentives in agroforestry systems tend to prioritize intensified practices.54 To avoid rebound effects of sustainability initiatives, private initiatives (e.g., fair trade or sustainability standards) need ties to regulatory frameworks and institutional arrangements.55 The drafted Directive on Corporate Sustainability Due Diligence56 and the Corporate Sustainability Reporting Directive57 could

become important instruments in this regard; they will, however, need to be implemented in collaboration with producing countries to be aligned with the context-specific regulatory frameworks, domestic standards, and monitoring baselines.

# Limitations and outlook

The presented concepts’ relevance and leverage present an opportunity to assess the telecoupled effects of consumption that are important and often neglected elements of national sustainability agendas. The different dimensions of monetary import values, cropland footprint, and imported deforestation are, however, dealt with as parallel indicators and are not interrelated to facilitate possible trade-off decisions. Simple indices of ratios of the three indicators would potentially lead to misleading interpretations as they depend on the nature of a production system, the transparency and complexity of a value chain, and the question of balancing winners and losers among the value chain actors. Some value chains, such as for coffee or cocoa, might have very direct relations between producers and consumers, whereas other products such as soy or palm oil are often used as feed or ingredient for more composite end products. Furthermore, the telecoupling concept challenges the rather monodirectional perspective of the impacts caused by EU imports, and requires additionally to consider bidirectional flows and feedbacks connecting sending and receiving systems. In light of these interdependencies, effective policy options depend on the particularities of value chains including the socio-economic and ecological contexts, existing regulatory frameworks, and bi- and multi-lateral trade relations between trading countries.

In light of the complexity of such analysis, we argue that only case studies with a focus on specific products and trading countries can shed light on the nature of trade-offs, context-specific interactions, and telecoupled feedbacks. Data-based or transdisciplinary scenario analyses could further help investigating the potential impacts of policy sectors, tools, or intervention packages. Each trade relationship is unique in its distribution of costs and benefits and it will require case studies and comparative analyses to expand our insights on options for governing telecoupled agri-food systems.

# Conclusion

From a global perspective, a business-as-usual scenario for agrifood systems poses an overwhelming challenge in a system that currently exceeds multiple planetary boundaries. For example, including raising demands for bioenergy and industrial uses of crops requires an increase of cropland production of $60 \%$ by 2050 (relative to 2002 levels).58 Through unsustainable production systems and telecoupled consumption-driven trade relations, high-income countries exhibit substantial influence on land-use and deforestation in developing countries. The EU’s Green Deal and Farm to Fork Strategy signal a high awareness of these interlinkages, but still fail to translate these objectives into action and policy change. Hence, implementing these strategies will require governments and private actors to think beyond only responding to telecoupled problems17 and instead to start adjusting the agricultural, food, biodiversity, and trade policies that induce unsustainable telecoupled effects of the EU’s imports.

The concepts of relevance and leverage, as demonstrated in our analyses, can help prioritizing policy decisions by exposing central telecoupled challenges for the sustainability of global

agri-food systems. Explicitly targeting these telecoupled effects as part of domestic policies acknowledges the responsibility for external impacts of bilateral relations as required by the PCD principle.

The concept of relevance points to the magnitude of environmental and economic impacts and thereby helps to identify key trade relations with the largest potential for the EU to contribute to global sustainability. The EU can then target these trade relations, for instance, by regulating the demand for related agrifood products (e.g., on healthy diets, support for animal husbandry, adjusting EU market access, due diligence,56 or the Carbon Border Adjustment Mechanism taxes59) The concept of leverage identifies products and regions with high market shares providing a potential for the EU to establish and support sustainable forms of production. To reduce trade-offs and foster synergies, telecoupled governance needs to assure coherent incentives for sustainability agendas, particularly in ensuring environmental aspects such as nature protection and restoration are better included in trade and international relations. As interventions have shown to produce diverging effects for different stakeholder groups, PCD requires a policy design that is more sensitive in particular to the needs of vulnerable producers (e.g., smallholders).

While geopolitical conflicts remain an important and often neglected factor in trade and bilateral partnerships, the strong EU leverage still provides ample opportunities to contribute to global sustainability. High leverage with selected small countries and specific products, even if relevance values are low, can significantly support individual trading partners in moving toward sustainable and more equitable and just agri-food systems. Transformative EU policies in telecoupled systems will further require complementary efforts in producing countries (e.g., for assuring tenure rights, consistent land-use policies, and data baselines), which can be aligned in bi- and multilateral agreements and partnerships.

In sum, the EU is currently exceeding its biocapacity, thereby externalizing the costs of its production and consumption patterns to other regions. At the same time, any shift in trade, land-use patterns, and access to ecosystem services and resources in a telecoupled world can exacerbate inequalities and produce spill-over effects in other countries. Therefore, value creation and global social adjustment needs to be part of an integrative strategy within PCD. If the EU is committed to implement PCD and enable countries with the lowest GDPs to emancipate themselves from the role of biocapacity providers, it will need to support these countries in developing their economies beyond agriculture to value-adding sustainable industries and services.

# EXPERIMENTAL PROCEDURES

# Resource availability

The trade data from FAOSTAT,60 and the land-use and deforestation data,13 are publicly available and open access. Further requests for information should be directed to and will be fulfilled by the lead author, Yves Zinngrebe (yves.zinngrebe@ufz.de).

# Methods

# The analytical dimensions relevance and leverage

We evaluated the trade relations with developing countries and imported cropland products based on their relevance and leverage. When using the term

‘‘developing countries,’’ we refer to all developing and transition countries as identified by the United Nations Conference on Trade and Development.61

# Relevance

We defined relevance as the share of EU imports from a specific country (or of a specific cropland product) as a percentage of total EU imports of cropland products. We also refer to this as the import share (values range from 0 to 100). Countries (or products) have a high relevance if imports of the respective country (or product) account for a high share of total EU imports. In that sense, the respective country (or product) has a high relevance for any PCD strategy from a European perspective. To identify the relevance of the countries (i.e., trading partners of the EU) or of the imported products, we analyzed import shares in three dimensions.

(1) Monetary import value: the share of the EU’s imports (expressed in USD) as a percentage of total EU imports.   
(2) Cropland footprint: the share of cropland (expressed in hectares of cropland area harvested) as a percentage of the total cropland imported for EU consumption.   
(3) Imported deforestation: the share of deforestation (expressed as hectares of deforested area) as a percentage of the total deforestation induced by EU consumption of cropland products.

# Leverage

We defined leverage as the share of EU imports from a specific country (or of a specific cropland product) as a percentage of the total production value, area harvested, or deforestation within the country (or for the specific product among developing countries). The leverage determines the importance of trade with the EU for the developing countries, both at the country and at the product level. As previously defined for relevance, we also distinguish between the economic leverage for three dimensions.

(1) Monetary import value: the share of global market value of a product or cropland area in a country that is imported into the EU (expressed in USD).   
(2) Cropland footprint: the share of the total cropland area harvested for a product, or in an individual producing country that is exported into the EU (expressed in hectares of cropland area harvested).   
(3) Imported deforestation: the share of deforestation caused by cropland products in developing countries that is exported to the EU (in hectares deforested).

# Concept of figures

The figures are based on annual production and trade data from FAOSTAT60 as well as land-use and deforestation data based on Pendrill et al.13 The available datasets overlap for the period from 2009 to 2013 and arithmetic means of the respective values were used to calculate the relevance andleverage. We derived the indicators for all cropland products P (indexed by k) and for all developing and transition countries D (indexed by d), which is a subgroup from all countries in the world W (indexed by i). To ensure comparability with respect to the products, the products (cropland-based products) in all datasets were aggregated to primary products, as explained below. We derive economic relevance from the sum of imports from a country to the EU. The relevance is described by the share of imports from a country of a product divided by the total EU imports.

The relevance of a trading partner (y axis) is high if the import share is high in the EU, meaning the exporting country is relevant for the EU. Similarly, the leverage of the EU imports (x axis) is high if the quantity exported to the EU takes a high share in the country of origin in monetary terms, cropland footprint, or deforestation. If a country or product has a high share of the total EU imports (relevance) and the values also represent a high share in the country of origin (leverage), this country should be far from the origin. We marked this region as ‘‘high PCD-relevance.’’ The bubble-size represents the size effect in a country representing the absolute values for imports in monetary terms, cropland footprint, or deforestation. Countries with high relevance values have a high share, but the imports do not necessarily have influence in the country of origin. Therefore, these countries have intensive trade relations with the EU and we typically observe here land-rich countries like Indonesia, Brazil, and Ukraine.

On the other hand, for some countries the EU imports can have large domestic effects, i.e., share of the total production (economic leverage), the total area harvested, or the deforestation (ecological leverage). The leverage for PCD arises from the assumption that any measures implemented by the EU have the potential to affect the production in that country. Overall, both types of countries (high relevance, high leverage) matter for evaluating the PCD performance and strategy of the EU.

# Calculating monetary import values

Starting from the FAOSTAT60 trade matrix, which gives the quantities and values of bilateral trade (reported imports and exports for each country), we extracted the EU imports in monetary terms and subtracted intra-EU trade. Then, we calculated relevance and leverage for all developing and transition countries D and all cropland products P.

To determine the economic leverage, we calculated the production values at export prices using unit values. To this end, we used export data from the trade matrix to calculate the unit value of exports by dividing the value of exports for each country and each product by the corresponding exported quantity. The unit value was then multiplied by the average production quantities from FAOSTAT60 to obtain the production value at export prices. This is subject to some inaccuracy, as unit values do not consider differences in qualities (and thus different values of products), or at least assume an equal distribution of these qualitative differences, which would ultimately lead to them canceling each other out. Another shortcoming is that the production value for products with an exported quantity of zero cannot be calculated. For these cases, the production value based on unit values was replaced by the production value at farm gate level from FAOSTAT,60 if available. Using the production value at farm gate level does, however, not include value added within the country from farm to exporter and is more sensitive to domestic policies. Regardless of this, we assume that, while these biases could lead to some inaccuracy in the interpretation of the exact level of leverage across different countries, the exact level is of minor importance for the interpretation of the figures while the position relative to other countries is still comparable/meaningful.

# (1) Relevance (developing country D)

Formally, we calculated the economic relevance $R ^ { \mathrm { { I m p o r t s } } }$ of imports from country D to the EU, using the sum of the imports X of all products ${ \mathsf { P } } = \{ 1 , 2 ,$ , .,k} coming from a developing country D, divided by the sum of imports X from all countries W and all products P:

$$
P _ {\mathrm {d}} ^ {\text {I m p o r t s}} = \frac {\sum_ {\mathbf {k} = 1} ^ {\mathbf {P}} X}{\sum_ {\mathbf {i} = 1} ^ {\mathbf {W}} \sum_ {\mathbf {k} = 1} ^ {\mathbf {P}} X} \tag {Equation 1}
$$

# (2) Relevance (cropland product P)

The same procedure has been done for the economic relevance $R ^ { \mathrm { { I m p o r t s } } }$ of product P, following form Equation 2, summing up the imports X of a product P from all countries $\mathsf { D } = \{ 1 , 2 , . . . \mathsf { d } \}$ $\mathsf { D } =$ }, divided (again) by the sum of imports X from all countries W and all products P:

$$
R _ {\mathrm {k}} ^ {\text {I m p o r t s}} = \frac {\sum_ {\mathrm {d} = 1} ^ {\mathrm {D}} \mathbf {X}}{\sum_ {\mathrm {i} = 1} ^ {\mathrm {W}} \sum_ {\mathrm {k} = 1} ^ {\mathrm {P}} \mathbf {X}} \tag {Equation2}
$$

# (3) Leverage (developing country D)

The economic Leverage LImports of the EU with regard to country D is calculated by the sum of imports X of all products $\mathsf { P } = \{ 1 , 2 , . . . , \mathsf { k } \}$ of a country D, divided by the total production value Y of each product P in a country D:

$$
L _ {d} ^ {\text {I m p o r t s}} = \frac {\sum_ {k = 1} ^ {P} X}{\sum_ {k = 1} ^ {P} Y} \tag {Equation3}
$$

# (4) Leverage (cropland product P)

The leverage LImports of the EU with regard to product P is calculated by summing up all imports X from the countries $\mathsf { D } = \{ 1 , 2 ,$ .,d} of a product P, divided by the total production value Y a product P in all countries D:

$$
L _ {k} ^ {\text {I m p o r t s}} = \frac {\sum_ {d = 1} ^ {D} X}{\sum_ {d = 1} ^ {D} Y} \tag {Equation 4}
$$

# Calculating the cropland footprint

To derive the ecological indicators with respect to footprint, we rely on a method developed in Pendrill et al.13 This method is based on physical bilateral trade data from the trade matrix (available for about 350 primary and processed agricultural products) as well as on production data (available for around 130 crop products), both available at FAOSTAT.60 In a first step, the processed products were converted into primary equivalents based on their dry matter content. The resulting data were used, along with production data of the respective crop, to establish clear links between the countries where a primary crop is produced and where the products processed from it are consumed in their physical form (either as food or for industrial purposes). This calculation relies on matrix algebra and the assumption that a country’s consumption is met proportionally by its domestic production and imports for a given primary product. The resulting accounts indicate, at the level of individual countries, where the primary crops required for the (apparent) consumption in a given country were cultivated. The quantities were then translated into the corresponding cropland area harvested using crop- and country-specific yield data from FAOSTAT.60 We finally aggregated the data for the EU, subtracting intra-EU trade.

The formal calculations of ecological relevance $R ^ { \mathsf { F o o t p r i n t } }$ and leverage LFootprint follow the same method as described above for the economic relevance and leverage in the above-described forms (1) to (4). For the ecological relevance RFootprint, we sum up the footprints X all products P of a country D or otherwise all countries D of a product P, divided in both cases by the total footprint X of all countries W and all products P. In the same vein, the ecological leverage LFootprint is calculated by the sum of the footprint X either of all countries D or of all products P, in both cases divided by the sum of the harvested area Y of all countries D or of all products P.

# Calculating imported deforestation

Relevance and leverage with regard to deforestation were calculated based on data from Pendrill et al.13 The authors developed a model that connects satellite data on tropical deforestation with data on the extent of individual land uses and crop species, and with global trade and consumption data for crop products from FAOSTAT60 (see above). In the resulting dataset, deforestation is attributed to individual agricultural and forestry products and subsequently to the countries that consume these products. In line with the focus of this study, we restricted the data to only cropland products, excluding deforestation for pasture expansion and forest plantation expansion (for the period included, the expansion attributed to cropland products accounts for $8 7 \%$ of the total deforestation attributed in the dataset from (9 ). Again, we aggregated the data across the EU.

The formal calculations of ecological relevance $R ^ { \tt D e f o r e s t }$ and leverage LDeforest follow again the method described above for the economic relevance and leverage in the above-described forms (1) to (4). The ecological relevance $R ^ { \tt D e f o r e s t }$ is using deforestation data. We sum up deforestation by the EU X by all products P in a country D or otherwise all countries D of a product P, divided in both cases by the total footprint X of all countries W and all products P. In the same vein, the ecological leverage LDeforest is calculated by the sum of the footprint X either of all products P or of all countries D, in both cases divided by the sum of the harvested area Y either of all products P or of all countries D.

For the depictions of the figures with the products, we have excluded all product categories that are marked as "nes" (‘‘not elsewhere specified’’) in the FAO dataset, since these product categories usually include multiple products and they play a minor role in international trade. It is therefore not exactly clear what each country is measuring within these categories. However, the numbers are included in all calculations.

In all figures, we have omitted outliers with a leverage greater than one $( 1 0 0 \% )$ ), since a leverage above one does not make sense (by design) and is likely due to errors in the dataset. This is mainly related to developing countries with a comparatively small cropland area. To keep the figures clear, only countries and products represented in the $9 5 \%$ quantile of leverage and relevance are labeled.

# Clustering countries as ‘‘sending systems’’

We have taken the following steps for clustering the countries as listed in Figure 5.

(1) We have ranked the countries producing a list, which includes the countries with the ten highest values for relevance in monetary value, cropland footprint, and deforestation. We also produced a second list ranking the countries with the highest values for leverage in all three dimensions. The resulting list of countries compiled by the ten countries with the highest values from all lists was then used further to inductively produce clusters.   
(2) We used qualitative content analysis58 to cluster the countries according to their dominant products accounting for the relevance and leverage values for products destined for the EU.   
(3) We complemented the groups of countries with single countries with geographical proximity and similar product compositions and trade relations with the EU (e.g., including Uruguay in the MERCOSUR group with Argentina, Paraguay, and Brazil; or including Kazakhstan and Belarus in the group of Russia, Ukraine, Moldova, and Serbia).

# Methodological limitations

As methodological limitations of this study, we have to acknowledge that, to reduce complexity, we have downplayed the effects for countries with lower values for relevance and leverage, but PCD still applies to these countries. Aside from these main contributors to the relevance value of EU imports, other specific trade relations with high leverage values bear a strong potential for improving the EU’s PCD performance. Specialized value chains, such as cinnamon with Seychelles, olives with Morocco and Tunisia, or vanilla with Madagascar bear strong potential for using these value chains as key levers for sustainable transformation. The final leverage the EU has in countries depends very much on the contextual specificities of both value chains and bilateral relations of sending and receiving systems, which we were not able to give more attention to in this global study.

# SUPPLEMENTAL INFORMATION

Supplemental material A: Detailed values per products and countries

# SUPPLEMENTAL INFORMATION

Supplemental information can be found online at https://doi.org/10.1016/j. oneear.2024.03.002.

