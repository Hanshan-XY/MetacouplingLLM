# The neglected cost Ecosystem services loss due to urban expansion in China from a triple-coupling p

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:50:13.679585+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Kong et al. - 2025 - The neglected cost Ecosystem services loss due to urban expansion in China from a triple-coupling p.pdf
- Year: unknown
- DOI: 10.1016/j.eiar.2025.107827
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper analyzes how urban expansion in China from 2000 to 2020 causes ecosystem service (ES) losses through multiple, spatially linked mechanisms, using the metacoupling / telecoupling framework. The study covers 357 prefecture-level units across mainland China and is explicitly grounded in Liu et al.s metacoupling theory. It develops a triple-coupling perspective: intra-coupling (direct ES loss where land is urbanized), peri-coupling (indirect local ES loss where nearby natural land is converted to cropland to replace cropland taken by cities), and tele-coupling (indirect remote ES loss where distant regions convert natural land to cropland under off-site cropland compensation policies).

The authors combine high-resolution land-use and urban footprint data (mainly 30-100 m), national statistics, and biophysical datasets (DEM, soils, climate, vegetation) and use InVEST-based models to quantify four ES: carbon sequestration, habitat quality, water conservation, and soil retention. Climate is held constant to isolate land-use effects. They construct a composite ES index and then attribute ES changes to the three coupling pathways using spatial analysis and a set of accounting formulas linked to Chinas cropland balance and cropland trading制度. Drivers of pathway differences are examined with multiscale geographically weighted regression and a Tobit model.

Nationally, direct intra-coupling explains about 61 percent of ES loss, while peri- and tele-coupling together account for nearly 40 percent, indicating that neglecting indirect and distant effects would substantially underestimate impacts. Telecoupled losses are concentrated in economically and ecologically vulnerable regions such as the Northeast and Northwest, which supply cropland compensation to richer coastal cities. Carbon sequestration and habitat quality are especially affected by indirect pathways. Results demonstrate clear metacoupling dynamics: strong intra-coupling in fast-growing coastal regions, peri-coupling in cropland-rich eastern interior areas, and tele-coupling in remote frontier regions. The paper concludes that telecoupling mechanisms create spatial injustice by shifting ecological costs of urban growth onto vulnerable regions and argues for limiting urban sprawl, incorporating indirect impacts into planning, and reforming off-site cropland compensation systems.

## Structured Metacoupling Extraction

### Coupling Classification
- Applies full metacoupling: intra-, peri-, and telecoupling of urban expansion and ecosystem services in China.

### Intracoupling
#### Systems
- Urban land and local ecosystems within Chinese prefecture level regions.
- Cropland, forest, and grassland directly converted to built up land.
- City scale human socioeconomic systems and their local ecological base.
#### Flows
- Direct land conversion from cropland and natural land to impervious urban surfaces.
- Immediate loss of carbon, habitat, water regulation, soil retention locally.
- Local population, economic activity, and infrastructure expansion into surrounding land.
#### Agents
- Municipal governments directing urban growth and zoning.
- Developers and construction enterprises converting land to urban use.
- Local planning and land administration bureaus allocating land quotas.
#### Causes
- Rapid urbanization, population growth, and economic development in Chinese cities.
- Competition for limited land pushing expansion of built up areas.
- Policies allowing cropland to be converted if formally compensated.
#### Effects
- Largest share of national ecosystem service loss from urban expansion.
- Strong declines in water conservation and soil retention near expanding cities.
- Local loss of high quality cropland, forest, and grassland ecosystem functions.

### Pericoupling
#### Systems
- Urban cores and surrounding rural natural land within same region.
- Cropland deficit cities and nearby compensating landscapes east of Hu Line.
- Municipal jurisdictions interacting with adjacent counties and rural hinterlands.
#### Flows
- Conversion of nearby forest and grassland into cropland for local food balance.
- Displaced cropland area recreated from surrounding natural ecosystems.
- Indirect transfer of ecosystem service loss from city edge into peri urban zones.
#### Agents
- Local governments enforcing cropland balance inside their jurisdiction.
- Farmers and rural collectives reclaiming nearby natural land as cropland.
- Land and agricultural bureaus managing in situ compensation projects.
#### Causes
- Cropland balance rules requiring one to one replacement of urbanized cropland.
- Food security strategies assigning strict cropland quotas to regions.
- Urban expansion plus ecological restoration jointly driving cropland demand.
#### Effects
- Substantial indirect loss of carbon sequestration and habitat quality around cities.
- Significant peri urban natural land degradation in regions east of the Hu Line.
- Growing soil erosion and reduced water regulation where steep land is reclaimed.

### Telecoupling
#### Systems
- Economically developed coastal city regions with cropland scarcity.
- Underdeveloped Northwest, Northeast, and Southwest regions with land reserves.
- National cropland compensation trading system linking distant jurisdictions.
#### Flows
- Off site cropland compensation quotas traded from land rich to land scarce regions.
- Remote conversion of grassland and forest to cropland for distant cities.
- Monetary payments from developed cities to vulnerable supplying regions.
#### Agents
- Central government designing cropland quota and trading institutions.
- Developed city governments purchasing off site compensation quotas.
- Underdeveloped regional authorities and farmers providing reclaimed cropland.
#### Causes
- Capital rich, land scarce cities choosing to buy compensation rather than reclaim locally.
- Abundant reserve cropland resources and lower opportunity costs in inland regions.
- National objective to maintain food security while enabling urban growth.
#### Effects
- Concentrated remote loss of carbon storage and habitat in arid northern regions.
- Heightened ecological and economic vulnerability and spatial injustice in supplier areas.
- Increasing regional inequality as land development rights shift to wealthy cities.

### Cross-Coupling Interactions
- Urban expansion scale simultaneously drives intra loss, peri reclamation, and tele compensation needs.
- Resource endowments shift ES loss pathway dominance among intra, peri, and telecoupling.
- Telecoupling reinforces peri and intra effects by displacing cropland and natural land nationally.

### Research Gaps or Limitations
- Analysis restricted to prefecture level units; multi scale administrative interactions not quantified.
- Urban rural demographic and land feedbacks, including migration, only qualitatively discussed.
- Closed access and model assumptions limit transferability to other countries without recalibration.

### Search Keywords
- urban expansion ecosystem services telecoupling China cropland compensation
- triple coupling intra peri tele ecosystem service loss
- metacoupling spatial injustice vulnerable regions land use change

### Extraction Confidence
high
