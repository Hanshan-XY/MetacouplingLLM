# Land-use changes across distant places design of a telecoupled agent-based model

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:41:22.740258+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Dou et al. - 2019 - Land-use changes across distant places design of a telecoupled agent-based model.pdf
- Year: unknown
- DOI: 10.1080/1747423X.2019.1687769
- OA status: closed
- License: none recorded
- Category: Journal Articles\Methodological\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This methodological paper designs a telecoupled agent-based model (TeleABM) to simulate how land-use decisions in distant regions are linked through international agricultural trade. The work is firmly situated within the telecoupling/metacoupling literature and aims to operationalize the telecoupling framework in a spatially explicit, agent-based setting.

The geographic focus is the Brazil-China soybean trade. Brazil, especially Mato Grosso state, is treated as the sending system, where soybean expansion and deforestation occur. Heilongjiang Province in northeastern China serves as the receiving system, where soybean area has declined as imports rise. The model is intended to capture how land-use changes in both regions co-evolve through trade flows and price feedbacks.

TeleABM is structured as two coupled land systems with parallel hierarchies of agents: farmers, regional traders, and national governments. Farmer agents in each country make annual land-use decisions (e.g., crop choice, expansion vs intensification, rotation practices) based on local biophysical conditions, prices, regulations, and farm attributes. Regional and national agents manage trade, tariffs, and subsidies. Two main flows link the systems: traded soybean volumes and soybean prices, with price adjustments based on empirical trade elasticities and costs such as transport and currency conversion.

Methodologically, the paper reviews existing land-use ABMs and identifies gaps for telecoupled applications: typical models simulate a single landscape, treat distant drivers as exogenous, and do not represent feedbacks among systems. TeleABM addresses this by internalizing cross-border flows so that production in one system influences prices and decisions in the other. The implementation uses RePast Simphony and is designed to be adaptable to other telecoupled cases. The paper also discusses data needs (surveys, participatory mental models), validation strategies for both subsystems and flows, and example scenario questions on tariffs, environmental regulations, and climate shocks.

Overall, the study advances telecoupling/metacoupling research by providing a concrete, multi-scale ABM design that links distant land-use dynamics through explicit trade and policy feedbacks.

## Structured Metacoupling Extraction

### Coupling Classification
- Strongly telecoupled; focuses on distant Brazil China soybean trade and feedbacks
- Includes intra system land change and cross border economic ecological links

### Intracoupling
#### Systems
- Brazilian soybean region Mato Grosso as sending coupled human natural system
- Chinese soybean region Heilongjiang as receiving coupled human natural system
- Within region farm and landscape subsystems governed by local policies and markets
#### Flows
- Local flows of crops, fertilizer, labor, and capital within each region
- Information on prices, subsidies, and regulations circulating among local agents
#### Agents
- Farmer households managing fields and crop rotations
- Regional governments enforcing forest code, subsidies, moratoria
- Local traders aggregating production and transmitting prices
#### Causes
- Domestic policies like zero deforestation moratorium and legal reserve rules
- Local profit expectations, risk attitudes, technology, and labor availability
- Climate variability and soil conditions affecting yields and land suitability
#### Effects
- Deforestation and conversion of forest or pasture to cropland in Brazil
- Soybean replacement by corn and rice paddy in China
- Changes in farm income, fertilizer use, and agricultural intensification patterns

### Pericoupling
#### Systems
- Adjacent Brazilian municipalities around Mato Grosso soybean frontier
- Neighboring Chinese counties around Heilongjiang soybean areas
#### Flows
- Potential spillover of soybean expansion to nearby South American producers
- Leakage of logging or deforestation to other tropical regions
#### Agents
- Emerging soybean producers in other South American countries
- Regional authorities managing land use in bordering jurisdictions
#### Causes
- Displacement of land use due to national regulations or moratoria
- Regional competition for agricultural markets and infrastructure
#### Effects
- Cascading deforestation or land intensification in neighboring regions
- Indirect land use change and carbon emissions outside focal areas

### Telecoupling
#### Systems
- Brazil as sending system exporting soybeans globally
- China as receiving system importing soybeans
- International trade and price system linking both countries
#### Flows
- Bulk soybean shipments from Brazil to China via international trade
- Price signals for soybeans transmitted between international and local markets
- Policy signals such as tariffs, subsidies, and trade agreements
#### Agents
- International trading companies coordinating exports and imports
- National governments setting tariffs, environmental regulations, subsidies
- TeleABM meta agents representing cross system trade and price mechanisms
#### Causes
- Global food demand and international agricultural trade liberalization
- Chinese demand for imported soybeans and changing domestic crop support
- Brazilian comparative advantage and infrastructure enabling soybean exports
#### Effects
- Land use change in Brazil driven by export demand and higher soybean prices
- Land use change in China driven by import competition and lower soybean prices
- Cross border impacts on fertilizer use, carbon emissions, biodiversity, livelihoods

### Cross-Coupling Interactions
- TeleABM endogenizes feedback where Brazilian production shifts influence Chinese prices and land use
- Chinese policy responses on tariffs or subsidies alter Brazilian deforestation and cropping choices
- Scenarios explore cascading, spillover, and indirect land use effects across both systems

### Research Gaps or Limitations
- Spillover countries and additional flows like carbon and knowledge diffusion largely omitted in current design
- Empirical implementation, calibration, and validation of full two way TeleABM remain ongoing
- Causal attribution and measurement of telecoupled effects still limited in broader telecoupling research

### Search Keywords
- telecoupling soybean Brazil China agent based model TeleABM
- land use change deforestation agricultural trade coupled human natural systems
- soybean price elasticity cross border feedbacks Mato Grosso Heilongjiang

### Extraction Confidence
high
