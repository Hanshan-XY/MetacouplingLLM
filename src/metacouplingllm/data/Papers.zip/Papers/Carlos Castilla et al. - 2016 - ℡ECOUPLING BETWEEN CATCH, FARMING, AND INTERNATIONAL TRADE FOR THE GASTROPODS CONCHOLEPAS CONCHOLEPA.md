# ℡ECOUPLING BETWEEN CATCH, FARMING, AND INTERNATIONAL TRADE FOR THE GASTROPODS CONCHOLEPAS CONCHOLEPA

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:30:16.645414+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Carlos Castilla et al. - 2016 - ℡ECOUPLING BETWEEN CATCH, FARMING, AND INTERNATIONAL TRADE FOR THE GASTROPODS CONCHOLEPAS CONCHOLEPA.pdf
- Year: unknown
- DOI: 10.2983/035.035.0223
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This article analyzes how distant production and trade systems for high-value marine gastropods have become economically interlinked, focusing on the Chilean-Peruvian loco Concholepas concholepas and global abalone Haliotis spp. The geographic scope is primarily Chile and Peru for loco fisheries, with a global perspective on wild and farmed abalone production and Asian import markets.

The authors examine long-term official statistics for loco landings and exports from Chile (1950-2013) and Peru (1950s-2010s), together with FAO data on wild and aquaculture abalone production and prices. They reconstruct historical fishery trajectories, management regimes, and export trends, and then use regression analyses to test how global abalone prices, wild abalone catches, and farmed abalone output relate to Chilean loco export prices and loco landings.

For loco, Chile shifted from de facto open access and collapse in the late 1980s to a comanagement system based on territorial user rights (TURFs/MEABRs). Peru largely retained open-access-style regulations with seasonal closures. Over time, Chilean loco exports decreased in volume but rose strongly in unit value, while Peruvian exports remained smaller and lower priced. Globally, wild abalone catches declined while aquaculture expanded rapidly, eventually dominating supply.

Econometric results indicate that Chilean loco prices track global abalone markets: higher wild abalone prices raise loco export prices, whereas greater wild or farmed abalone supply reduces them. In turn, lower loco prices are linked to reduced official loco landings in Chile. The authors argue that these price signals also shape illegal and unreported harvests, which substitute closely for legal product.

The paper is explicitly about telecoupling. It shows how aquaculture expansion and market shifts in distant countries propagate through international seafood value chains to influence local catch levels, the effectiveness of Chilean TURF-based management, and the livelihoods and incentives of small-scale fishing communities. It calls for management and policy frameworks that explicitly account for such cross-border market linkages and build adaptive capacity in coastal systems.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling among Chile Peru and Asian markets via gastropod catch farming and trade

### Intracoupling
#### Systems
- Chilean coastal loco TURF MEABR management system
- Peruvian coastal loco open access style fishery
- National fisheries and customs governance institutions
#### Flows
- Local loco harvests from intertidal and subtidal zones
- Domestic loco meat consumption and internal trade
- Information flows on landings prices and enforcement
#### Agents
- Artisanal hookah and skin divers and shore gatherers
- Fishers unions and territorial user rights organizations
- National fisheries agencies and enforcement officers
#### Causes
- High local and export value of loco meat
- Open access or weakly regulated harvesting phases
- Implementation of TURF MEABR co management reforms
#### Effects
- Fishery collapse and closures under de facto open access
- Stabilized but reduced legal loco landings post reforms
- Growth of illegal unreported local loco markets

### Pericoupling
#### Systems
- Neighboring Chilean and Peruvian loco fisheries
- Border regions facilitating loco smuggling
- Regional Andean Pacific governance context
#### Flows
- Smuggled undersized loco from Chile to Peru
- Shared coastal ecosystems and loco stocks
- Regional trade of processed loco products
#### Agents
- Cross border traders and intermediaries
- Unregistered divers operating in both countries
- Peruvian and Chilean customs and control agencies
#### Causes
- Different minimum legal sizes and regulations
- Price gaps between neighboring national markets
- Weak cross border fishery enforcement coordination
#### Effects
- Distorted national catch statistics and monitoring
- Undermined Chilean TURF MEABR incentives
- Increased difficulty for binational stock management

### Telecoupling
#### Systems
- Chile and Peru small scale gastropod fisheries
- Global wild and farmed abalone production regions
- Asian seafood import markets especially East Asia
#### Flows
- Exports of canned frozen dried loco foot meat to Asia and Europe
- International shipments of wild and farmed abalone products
- Telecoupled price signals across gastropod markets
#### Agents
- Middlemen processors exporters and importers
- Asian seafood buyers traders and consumers
- International organizations compiling trade statistics
#### Causes
- Rising demand for luxury gastropods in Asian economies
- Rapid expansion of abalone aquaculture in Asia and elsewhere
- Global trade liberalization and integrated seafood markets
#### Effects
- World abalone prices shaping Chilean loco export prices
- Falling loco prices reducing legal landings in Chile TURFs
- Aquaculture growth threatening sustainability of distant small scale fisheries

### Cross-Coupling Interactions
- Abalone aquaculture expansion abroad indirectly reduces loco prices and alters Chilean harvest decisions
- International demand shocks translate into local co managed fishery stress and enforcement problems
- Illegal loco supply responds to same global prices as legal exports blurring management outcomes

### Research Gaps or Limitations
- Scarce data on illegal loco extraction and internal prices
- Limited analysis of substitution between abalone and loco in consumer markets
- Peruvian loco econometric analysis constrained by short data series

### Search Keywords
- telecoupling loco abalone Chile Peru Asia
- small scale fisheries TURF MEABR gastropod trade
- abalone aquaculture global seafood market integration

### Extraction Confidence
high
