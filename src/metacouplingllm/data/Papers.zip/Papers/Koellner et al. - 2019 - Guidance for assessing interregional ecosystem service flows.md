# Guidance for assessing interregional ecosystem service flows

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:49:55.527283+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Koellner et al. - 2019 - Guidance for assessing interregional ecosystem service flows.pdf
- Year: unknown
- DOI: 10.1016/j.ecolind.2019.04.046
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Methodological\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This methodological paper develops practical guidance for assessing ecosystem service (ES) flows that cross regional and national boundaries. The authors argue that most ecosystem assessments still treat countries or regions as closed systems, even though telecoupled interactions mean that consumption and risk in one place often depend on ecosystems elsewhere. The work is global in scope, but is explicitly geared toward national and regional ecosystem assessments and accounting frameworks.

Within the sTeleBES expert group, the authors synthesize scattered methods and propose a structured, three-step process: (1) define assessment goals, societal and policy context, and spatiotemporal boundaries; (2) select relevant ES and classify them into four flow types; (3) quantify flows with a tiered approach and interpret uncertainties, consequences, and governance options. The four flow types are: traded biomass-based goods; flows mediated by migrating or dispersing species; passive biophysical flows such as water, sediments, or air pollutants; and information flows underlying learning, recreation, and identities.

For each flow type, the paper reviews suitable data sources and analytical options, from simple literature-based indicators (Tier 1), through use of existing statistics and basic models (Tier 2), to data-intensive process models, spatial subsidies analysis, or fate-and-transport modelling (Tier 3). Examples include trade databases and footprint indicators for provisioning services, species range and citizen science data for migratory species, hydrological or atmospheric models for regulating services, and social media, tourism, and search data for cultural and informational flows.

The authors explicitly frame these interregional ES flows within the telecoupling concept and link them to Sustainable Development Goals, highlighting implications for dependency, equity, human security, and governance across sending, receiving, and spillover systems. They show that current SDG indicators largely overlook flows mediated by species migration. Overall, the paper is centrally about telecoupling/metacoupling and provides a high-level template to integrate distant ES dependencies into ecosystem assessments, trade analysis, and cross-border policy design.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong focus on telecoupling via interregional ecosystem service flows between distant regions and countries.

### Intracoupling
#### Systems
- Not identified.
#### Flows
- Not identified.
#### Agents
- Not identified.
#### Causes
- Not identified.
#### Effects
- Not identified.

### Pericoupling
#### Systems
- Neighboring countries sharing transboundary river basins and aquifers
- Upstream and downstream regions within international watersheds
#### Flows
- Cross-border freshwater quantity and quality regulation
- Transboundary flood mitigation and hazard regulation
#### Agents
- River basin organizations and water treaty institutions
- National water and environment agencies
#### Causes
- Shared hydrological systems crossing political borders
- Need for cooperative flood and drought risk management
#### Effects
- Cooperative or conflictive water governance outcomes
- Impacts on local water security and disaster risk

### Telecoupling
#### Systems
- Sending regions exporting biomass, regulating and cultural services
- Receiving regions importing ecosystem services and benefits
- Spillover regions hosting processing, transit, or displaced impacts
#### Flows
- Traded biomass goods carrying embedded ecosystem services and inputs
- Services mediated by migratory species across continents
- Long distance biophysical and information flows linking societies
#### Agents
- Producers, traders, and multinational companies in global supply chains
- National governments, international conventions, and NGOs
- Tourists, citizen scientists, and online media platforms
#### Causes
- Global trade, consumption patterns, and resource demand
- Species migration ecology and seasonal habitat needs
- Education, tourism, and media attention to distant nature
#### Effects
- Externalization of environmental pressures and land degradation abroad
- Cross border dependencies affecting security and equity
- Unequal sharing of conservation burdens and benefits

### Cross-Coupling Interactions
- Traded goods drive land use change that alters migration habitats and passive flows.
- Information flows reshape perceptions and policies about traded and biophysical flows.
- Telecoupled trade interacts with pericoupled water and air pollution across borders.

### Research Gaps or Limitations
- Limited methods and data for regulating and cultural service flows, especially via migration and information.
- Scarce temporal data on dynamics and lags of interregional ecosystem service flows.
- Uncertainties from coarse trade data and incomplete species distribution or social media coverage.

### Search Keywords
- interregional ecosystem service flows telecoupling guidance tiered approach
- traded goods migratory species passive biophysical flows information flows
- national ecosystem assessment SDGs embedded ecosystem services virtual water land footprints

### Extraction Confidence
high
