# Telecoupling mechanism of urban land expansion based on transportation accessibility A case study o

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:10:56.725116+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Wu et al. - 2020 - Telecoupling mechanism of urban land expansion based on transportation accessibility A case study o.pdf
- Year: unknown
- DOI: 10.1016/j.landusepol.2020.104687
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This article investigates how transportation accessibility shapes the spatially interconnected (telecoupled) dynamics of urban land expansion in the Yangtze River Economic Belt (YREB), China. The YREB covers 11 provincial-level units and over 40 percent of China’s population and GDP, making it a key arena for regional integration and rapid urbanization.

Working within a telecoupling framework, the authors treat cities as sending, receiving, and spillover systems linked through flows of capital, labor, information, and goods, with transportation networks mediating these flows. They use land-use remote sensing data (1990, 2005, 2015), digitized multi-modal transport networks, and socioeconomic statistics for 127 cities. Accessibility is measured with a gravity-type economic potential indicator based on travel time, and spatial interaction is captured using a second-order spatial autoregressive (SO-SAR) model that incorporates both historical and contemporaneous spillovers via time-cost matrices.

Urban land area in the YREB nearly doubled from 1990 to 2015, with fast expansion initially concentrated in the Yangtze River Delta and later spreading to central and western sections of the belt. Spatial-temporal autocorrelation analysis shows strong positive clustering of urban land expansion when city-to-city travel times fall between 2 and 3 hours; beyond roughly 4 hours, spatial dependence weakens noticeably.

SO-SAR results indicate strong path dependence: past urban land configurations strongly condition later expansion. In the early period, urban growth in neighboring cities within about 5 hours travel exerts positive spillover effects. From 2005 to 2015, improved transport reduces local expansion in immediately adjacent areas (within about 1 hour) but generates positive spillovers from more distant cities as accessibility improves. Among economic transition variables, openness, labor mobility, administrative hierarchy, and industrial structure consistently foster expansion; foreign direct investment is important only before 2005, while land finance matters mainly in the later period.

The study is explicitly framed as a telecoupling analysis of urban land expansion, demonstrating how transport-enhanced connectivity links distant urban land systems and calling for regional-scale coordination of transport planning, land quotas, and urban development.

## Structured Metacoupling Extraction

### Coupling Classification
- Study explicitly applies telecoupling to urban land expansion via regional transportation accessibility in China

### Intracoupling
#### Systems
- Individual YREB city as coupled human nature system
- Urban land and transport network within a single city
#### Flows
- Internal commuting and daily travel within city
- Within city capital and labor reallocation
#### Agents
- Municipal governments and planning bureaus
- Local residents and firms
#### Causes
- Local urbanization and industrialization policies
- Municipal land finance dependence
#### Effects
- Urban land expansion and sprawl inside city
- Loss of local farmland and ecological land

### Pericoupling
#### Systems
- Neighboring cities within 1 3 hour travel time
- Urban agglomerations inside YREB
#### Flows
- Short distance labor commuting and migration
- Nearby capital and technology diffusion
#### Agents
- Adjacent local governments in competition
- Regional transport and planning agencies
#### Causes
- Improved short range road and rail accessibility
- Regional integration and development zones
#### Effects
- Spatial spillover of urban land expansion to nearby cities
- Inhibition or stimulation of neighboring ULE depending on distance

### Telecoupling
#### Systems
- Lower reach YREB cities as sending regions
- Middle and upper reach YREB cities as receiving regions
- Spillover system of more distant cities
#### Flows
- Long distance flows of labor, capital, goods, information
- Industrial relocation and investment reallocation along YREB corridor
- Urban land quota and policy influences across provinces
#### Agents
- Central government designing YREB strategy
- Provincial governments implementing regional plans
- Developers and external investors including FDI
#### Causes
- Economic transition including marketization globalization decentralization
- National YREB development and central China rise strategies
- Construction of integrated multi modal transportation corridors
#### Effects
- Remote cities ULE positively affecting local ULE via accessibility improvements
- Path dependent regional urban land expansion patterns
- Farmland loss environmental pressure and uneven regional development

### Cross-Coupling Interactions
- Accessibility driven flows connect intra peri and telecoupled ULE processes across YREB
- Historical ULE interacts with new telecoupled flows creating path dependence and spatial lock in
- Telecoupled economic transition amplifies local land finance incentives and regional spillovers

### Research Gaps or Limitations
- Model omits factors like terrain culture detailed demographics
- Analysis uses administrative units rather than fine grid land data
- Daily accessibility thresholds may understate very long distance interactions

### Search Keywords
- telecoupling urban land expansion Yangtze River Economic Belt
- transportation accessibility spatial spillover SO SAR
- economic transition globalization land finance labor flow China

### Extraction Confidence
high
