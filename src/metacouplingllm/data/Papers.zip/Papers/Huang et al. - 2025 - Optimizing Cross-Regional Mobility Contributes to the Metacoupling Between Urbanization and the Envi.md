Article

# Optimizing Cross-Regional Mobility Contributes to the Metacoupling Between Urbanization and the Environment for Regional Sustainability

Ying Huang 1,2, Lan Ye 1, Qingyang Jiang 3, Yufeng Wang 2,3,4,5,6,7,8,9, Guo Wan 1,*, Peiyun He 3 and Bo Zhou 10

School of Fine Arts and Design, Art College of Chinese & Asean Arts, Chengdu University, Chengdu 610106, China; huangying@cdu.edu.cn (Y.H.); yelan@cdu.edu.cn (L.Y.)   
2 State Key Laboratory of Clean and Efficient Coal Utilization, Taiyuan University of Technology, Taiyuan 030024, China; wyf2022@swjtu.edu.cn   
3 School of Design, Smart Urban and Rural Environmental Sustainability Research Institute, Southwest Jiaotong University, Chengdu 611756, China; 2023212602@my.swjtu.edu.cn (Q.J.); hpyun@my.swjtu.edu.cn (P.H.)   
4 Engineering Research Center of Comprehensive Utilization and Clean Processing of Phosphorus Resources, Ministry of Education, Chengdu 610065, China   
5 Service Science and Innovation Key Laboratory of Sichuan Province, Chengdu 611756, China   
6 International Cooperation Joint Laboratory of Health in Cold Region Black Soil Habitat of the Ministry of Education, Harbin 150006, China   
7 Key Laboratory of Songliao Aquatic Environment, Ministry of Education, Changchun 130118, China   
8 Key Laboratory of Urban Stormwater System and Water Environment, Ministry of Education, Beijing University of Civil Engineering and Architecture, Beijing 102616, China   
9 Key Laboratory of Digital Mapping and Land Information Application, Minisitry of Natural Resources, Wuhan 430079, China   
10 College of Architecture and Environment, Sichuan University, Chengdu 610064, China; zxt001@163.com   
* Correspondence: wanguo@cdu.edu.cn

![](images/633795cd90cd37499e0568f0343860b69c309c8763f147d95dcfd870f6c076ba.jpg)

Academic Editors: Pengtao Wang, Wanxu Chen, Xufeng Cui, Meimei Wang, Basanta Paudel and Xingchuan Gao

Received: 15 June 2025

Revised: 13 July 2025

Accepted: 23 July 2025

Published: 20 August 2025

Citation: Huang, Y.; Ye, L.; Jiang, Q.;

Wang, Y.; Wan, G.; He, P.; Zhou, B.

Optimizing Cross-Regional Mobility

Contributes to the Metacoupling

Between Urbanization and the

Environment for Regional

Sustainability. Land 2025, 14, 1682.

https://doi.org/10.3390/

land14081682

Copyright: $^ ©$ 2025 by the authors.

Licensee MDPI, Basel, Switzerland.

This article is an open access article distributed under the terms and conditions of the Creative Commons

Attribution (CC BY) license

(https://creativecommons.org/

licenses/by/4.0/).

# Abstract

As a result of rapid urbanization, ecological and environmental problems have become increasingly severe. Sustainable regional development requires a balance between urbanization and the environment. With the intensification of economic globalization and technological innovation, the flow of various elements such as population, capital, information, and resources has gradually blurred administrative boundaries, leading to new cross-scale evolutionary characteristics in this relationship. However, existing studies have primarily been conducted at the local scale and have failed to capture the impact of cross-regional element flows on the relationship between urbanization and the environment. Under the metacoupling framework, this study improves the existing methodological framework by integrating the flows of production factors and ecosystem service (ES) to characterize the metacoupling between urbanization and the environment in the Chengdu-Chongqing urban agglomeration (CCUA). A new comprehensive index system for urbanization and environment was constructed, considering the cross-regional flow of multiple factors. The Coupling Coordination Degree model was employed to calculate the degree of intracoupling, pericoupling, and telecoupling between urbanization and the environment. The Geodetector model was used to determine the effects of local, adjacent, and distant flows of production and ES factors on these degrees. The results show that the intracoupling between urbanization and the environment was low, while the pericoupling and telecoupling increased from local to distant scales. Production factor and ES flows were the common factors affecting the metacoupling between urbanization and the environment, but population flows and capital flows were more strongly explained at the local scale, and ES flow was more strongly explained at the adjacent and distant scales. Based on these results, a systematic understanding of the complex relationship between urbanization and environment is provided, which in turn provides a basis for decision making regarding

the coordinated and sustainable development of urban and ecological management in the CCUA as well as other urban agglomerations.

Keywords: urbanization; environment; metacoupling; cross-regional mobility; regional sustainability

# 1. Introduction

Urbanization refers to transforming society from an agricultural lifestyle to a modern civilized lifestyle dominated by industry and services through the agglomeration and diffusion of resource factors [1]. The 2018 Revision of World Urbanization Prospects expects that, by 2050, $6 8 \%$ of the world’s population will live in urban areas [2]. According to the general law of global urbanization, the world has entered a stage of accelerated urbanization development [3]. It has been reported that China’s urbanization rate is projected to reach a peak of approximately $7 0 \%$ by 2030 [4]. During this period, the rapid expansion of urban construction land and excessive energy consumption and other human activities will significantly reduce the environmental carrying capacity, leading to a variety of environmental issues such as soil erosion, land degradation, water pollution, and changes in the atmospheric environment [5–8]. In addition to deteriorating the quality of the urban ecological environment, these issues also pose a significant obstacle to the achievement of sustainable urban development objectives [9,10]. Meanwhile, the rapid development of urbanization has led to conflict and unbalanced development with the environment. Furthermore, as economic globalization and technological innovations gradually intensify, the flows of multiple factors (e.g., cross-regional mobility of population, multi-level urban transportation networks) are gradually blurring administrative boundaries, resulting in new evolutionary features of the relationship between urbanization and the environment from neighboring to distant areas [11]. For example, through the transfer from the providing area (SPA) to the benefiting area (SBA), ES flows could realize cross-regional benefits and address spatial mismatches between the supply and demand of ESs (goods and services that humans obtain from ecosystems) [12]. In order to formulate urban development strategies, particularly in lower-income countries with rapid urbanization, it is necessary to conduct research on this relationship from local to distant scales [13].

The concept of coupling, which denotes the interaction among two or more systems, has its roots in physics and has subsequently found extensive application across natural sciences, social sciences, and the humanities [14]. Our current understanding of the human– nature coupled system and sustainability science is being shaped by studies of the coupling between urbanization and the environment [15,16]. Recently, most studies quantified the levels of ecological environment and urbanization by constructing evaluation index systems or applying comprehensive indices. In the field of urbanization assessments, traditional demographic–economic urbanization has evolved towards demographic, economic, spatial, and social urbanization [17,18]. In the field of environmental assessments, the pressure– state–response (PSR) model or environmental index has been widely utilized to describe the conditions and status of specific areas [19]. Using panel data collected from 41 cities in the Yangtze River Delta (YRD), Song et al. [20] formulated evaluation index systems for new-type urbanization, which covered four dimensions—economic, population, social, and spatial—and ecological environment from three dimensions—pressure, state, and response. Lei et al. [14] employed the Improved Remote Sensing Ecological Index (IRSEI) based on the Google Earth Engine (GEE), the MODIS images, and the GDP sub-industry spatialization model combined with nighttime light remote sensing data, land use data, and

socio-economic data to characterize the ecological environment and urbanization process in the Chengdu-Chongqing urban agglomeration. However, most of these studies are based on panel statistics and conducted at local scales, with a limited understanding of this coupling from local to distant levels, especially based on multi-factor flows across regions.

The metacoupling framework, first proposed by Liu in 2017, provides a new approach for analyzing the human–nature interactions from local to distant levels. Metacoupling is the interaction between humans and nature within and between neighboring and distantly coupled systems [21]. In contrast to coupling and telecoupling frameworks that focus on coupling within a single region, the metacoupling framework integrates three systems, including specific system (intracoupling), between adjacent systems (pericoupling), and between distant systems (telecoupling), thereby achieving full spatial research coverage [22]. This framework is currently widely used in economic geography studies, providing a solid basis for analyzing material, immaterial, and virtual flows ranging from neighboring to distant areas [23,24]. Herzberger et al. [25] analyzed how global food trade affects trade relationships and production between adjacent countries through the metacoupling framework. Zhang et al. [26] applied this framework to assess the ES flow within the basin as well as the ES flow between the basin and its external regions in the Huangshui River Basin. Therefore, this multi-scale perspective could enrich our understanding of the coupling between urbanization and the environment by evaluating multi-factor flows [27].

Therefore, under the metacoupling framework, we improved the current methodological framework by integrating production and ES factors to depict the metacoupling between urbanization and the environment in the Chengdu-Chongqing urban agglomeration (CCUA). The primary objectives of this study are as follows: (1) measure the levels of urbanization and environment in CCUA; (2) calculate the intracoupling, pericoupling, and telecoupling between urbanization and the environment; (3) determine the effects of local, adjacent, and distant flows of production and ES factors on intercoupling, pericoupling, and telecoupling. Research results contribute to a systematic understanding of the relationship between urbanization and the environment and provide a scientific basis for optimizing urbanization strategies and ecological protection systems. Additionally, this paper provides a new framework for understanding urbanization and the environment in other urban agglomerations.

# 2. Materials and Methods

# 2.1. Study Area

The Chengdu-Chongqing urban agglomeration (CCUA) is located in Western China and the upper reaches of the Yangtze River (Figure 1). There is a complex topography dominated by hills, plains, and basins, resulting in significant climate differentiation and ecological diversity [28]. This region of Western China has the highest level of urbanization and the greatest potential for development because of its unique ecological endowment, rich natural resources, and dense cities and towns [29]. Recently, CCUA has been known as one of the five national-level urban agglomerations in China [28]. Furthermore, this region also plays an important role in strengthening the ecological barrier in the upper reaches of the Yangtze River. It is therefore crucial to explore the connection between urbanization and the environment in CCUA to ensure the effective flow of natural resources and to maximize the strategic role of the nation, but it also provides valuable insights into how to achieve sustainable development within emerging economic circles [30]. In response to the administrative characteristics of Sichuan Province and Chongqing Municipality and the need for spatial analyses, the research units for this study were chosen to be prefecture-level and county-level administrative regions, including 15 prefecture-level administrative units

in Sichuan Province and 21 county-level administrative units in Chongqing Municipality, with a total area of $1 8 5 , 0 0 0 \mathrm { k m } ^ { 2 }$ .

![](images/41784a5657b16ae5716b40a7ce2ee3088c78d3084a3bed25c534877bf2e8ab56.jpg)  
Figure 1. Locations of study area.

# 2.2. Data Sources and Processing

This study used geospatial and statistical data concerning urbanization and the environment. (1) The administrative boundary data were obtained from the “Administrative Boundary Data of Chinese Counties” provided by the Resource and Environment Science Data Center of the Chinese Academy of Sciences (http://www.resdc.cn/). The 36 research units were created through ArcGIS 10.6 software. (2) The point-of-interest (POI) data were sourced from the Gaode map (https://gaode.com/). (3) The migration data were sourced from the Baidu Map migration big data platform (https://qianxi.baidu.com/). (4) The Baidu search index came from the Baidu Search Platform (https://index.baidu.com/). (5) The land use and land cover data were derived from the Resource and Environment Science and Data Center, Chinese Academy of Sciences (http://www.resdc.cn/). (6) The statistical data were obtained from the “China Urban Statistical Yearbook”, “China Urban and Rural Construction Statistical Yearbook”, “China County Statistical Yearbook”, “Sichuan Statistical Yearbook”, “Chongqing Statistical Yearbook”, “Sichuan Ecological Environment Bulletin”, and “Chongqing Ecological Environment Bulletin”, supplemented by statistical yearbooks and bulletins from relevant cities and counties.

# 2.3. Methods

# 2.3.1. Research Framework

To comprehensively understand the metacoupling between urbanization and the environment in the CCUA, this study develops a framework based on the metacoupling framework. This framework consists of three systems: focal, adjacent, and distant systems (Figure 2). Applying this framework, the CCUA, the Upper Reaches of Yangtze River Economic Belt (URYREB), and the Yangtze River Economic Belt (YREB) were regarded as focal system, adjacent system, and distant system, respectively. The URYREB should

be considered an adjacent system because of its geographical proximity, economic links, policy coordination, and administrative management [27]. The YREB was designed as a distant system because there is a natural hydrological connection between the URYREB and the YREB [26]. Thus, the division of the focal, adjacent, and distant systems can help to capture the coupling between urbanization and the environment in CCUA from local to distant levels. Specifically, this coupling can be embodied in three processes: intracoupling, pericoupling, and telecoupling. In CCUA, intracoupling, pericoupling, and telecoupling represent the coupling of urbanization and the environment under local, adjacent, and distant flows of production and ES factors.

![](images/d471b48b2806593142aeca2a4ee86f0d68e77d6c4cf270aa23d7dd63bc952683.jpg)

![](images/479b12472ff786b0bdcce2e51d4e32afa8e35997b6674c07cf9845729fd3ecc0.jpg)  
Figure 2. Theoretical framework based on metacoupling.

Overall, our research procedure comprised three sections (Figure 3): (1) constructing comprehensive evaluation indicator systems for measuring the urbanization level (UL) and environment level (El) with production factor flows and ES flow; (2) analyzing the intracoupling, pericoupling, and telecoupling between UL and EL by employing the CCD model; and (3) using Geodetector model to investigate the factors influencing intracoupling, pericoupling, and telecoupling between UL and EL.

![](images/98beddc9f9777a4241ef8751cb4e3aeec0f04424cf6ef78e8e68d28f57b4ddb3.jpg)  
Figure 3. Methodological flowchart of this study.

# 2.3.2. Construction of Index System

On the basis of previous studies [31–33], a new comprehensive index system for urbanization was constructed from four aspects: population urbanization, economic urbanization, social urbanization, and spatial urbanization. A comprehensive index system for environment was constructed by using the pressure–state–response (PSR) model. The specific parameters are shown in Table 1.

Table 1. Index system of urbanization and environment subsystems.   

<table><tr><td>System</td><td>Subsystem</td><td>Indicator</td><td>Unit</td></tr><tr><td rowspan="9">Urbanization</td><td rowspan="3">Population urbanization</td><td>Proportion of urban population</td><td>%</td></tr><tr><td>Proportion of employees in the secondary and tertiary industry</td><td>%</td></tr><tr><td>Population flow</td><td>/</td></tr><tr><td rowspan="3">Economic urbanization</td><td>Per capita GDP</td><td>CNY</td></tr><tr><td>Proportion of secondary and tertiary industries in GDP</td><td>%</td></tr><tr><td>Economic flow</td><td>/</td></tr><tr><td rowspan="3">Social urbanization</td><td>Number of hospital and health center beds per capita</td><td>Bed</td></tr><tr><td>Medical technicians per capita</td><td>Person</td></tr><tr><td>Information flow</td><td>/</td></tr><tr><td rowspan="9">Environment</td><td rowspan="3">Pressure</td><td>Industrial wastewater discharge</td><td>10 thousand tons</td></tr><tr><td>Industrial SO2 emissions</td><td>10 thousand tons</td></tr><tr><td>Industrial dust emissions</td><td>10 thousand tons</td></tr><tr><td rowspan="3">State</td><td>The cover rate of forest</td><td>%</td></tr><tr><td>Green coverage rate in built-up areas</td><td>%</td></tr><tr><td>Park green area per capita</td><td>m2</td></tr><tr><td rowspan="3">Response</td><td>Household garbage treatment rate</td><td>%</td></tr><tr><td>Industrial solid wastes comprehensively utilized rate</td><td>%</td></tr><tr><td>Domestic sewage treatment rate</td><td>%</td></tr></table>

# 2.3.3. Calculation of Cross-Regional Flow of Multi-Factors

Natural resources, capital, labor, technology, management, and information are the basic factors of production that drive social production [34]. In this study, three involved parts were considered and calculated for the production factor flow: population flow, capital flow, and information flow.

# (1) Population flow

Launched in early 2014, Baidu Map migration big data platform uses mobile phone users’ real-time location information to shape the trajectory and intensity of population flow [35,36]. Based on daily data of population migration and Python programming software 3.10, a population flow and migration matrix was constructed to characterize the spatial network of population flows among 133 prefecture-level cities of YREB in 2023.

# (2) Economic flow

Based on the chain network model, proposed by the British geographer Taylor [37], economic flow intensity was calculated by calculating the strength of economic linkages between two cities. The formula is as follows:

$$
R _ {i j, a} = V _ {i a} \times V _ {j a} \tag {1}
$$

where $\mathrm { R } _ { i j , a }$ is the strength of economic linkages between city $i$ and city $j$ for a particular type of enterprise $a ; \mathrm { V } _ { i a }$ is the value of enterprise a in city i; m is the number of cities; and $\mathrm { S } _ { i j }$ is the total strength of economic linkages between city i and city $j$ .

Banks, corporations, and securities enterprises were selected as the enterprise types, and, after obtaining the required POI data of each city and county in 2023 through the Gaode map, unequal weights were assigned to each type of enterprise according to different rank levels.

# (3) Information flow

Based on massive search data across different keywords, Baidu Search Index analyzes the intensity of information flow between cities and the direction in which it flows [38] and objectively reflects the association characteristics between different cities [39]. Using the keywords of city names, an information flow intensity matrix was constructed based on the average daily Baidu search index between the two cities at the ‘PC+Mobile’ level, to reflect the spatial network of information flows among 133 prefecture-level cities of YREB in 2023.

# 2.3.4. Calculation of Cross-Regional Flow of ESs

The flow of ecosystem services (ESs) is a spatial connection between service-providing areas (SPAs) and service-benefiting areas (SBAs), and it is a crucial link between the natural ecosystem and socioeconomic system [40,41]. Thus, ES flow is not limited to the local area but also often exhibits cross-regional characteristics [26]. In this study, the revised equivalent factor method and the breaking point model were used to quantify the ES flow within a specific region (CCUA), between adjacent regions (URYREB), and between distant regions (YREB).

The breaking point model, developed based on Newton’s law of gravity [42], has been used to analyze ES flows between regions [43,44]. It considers the attraction of a city to its surrounding areas to be proportional to its size and inversely proportional to the square of the distance between cities. In this study, the breaking point model was used to calculate the ESV flow between regions at three spatial scales with the following three steps.

Based on Newton’s law of gravity [42], we used the breaking point model to calculate the ESV flow at three spatial scales with the following three steps. First, the radiation

scope of the ES between regions (province and city level) was calculated. The formula is as follows:

$$
d _ {j} = \frac {D _ {i j}}{1 + \sqrt {m _ {j} / m _ {i}}} \tag {2}
$$

where $d _ { j }$ is the radiation distance of the ES from region $i$ (SPA) to region $j$ (SBA), $D _ { i j }$ is the shortest straight distance between region i and region $j ,$ and $m _ { i }$ and $m _ { j }$ are the ESVs of region i and region $j ,$ respectively.

Second, the field strength model was used to quantify the average radiation value of the ES between regions [45]. The formula is as follows:

$$
F _ {i j} = \frac {m _ {i}}{D _ {i j} ^ {2}} \tag {3}
$$

where $F _ { i j }$ is the average radiation value of the ES of region i to region $j$ .

Third, the ESV flow was calculated based on the radiation scope and the average radiation value between regions. The formula is as follows:

$$
E _ {i j} = F _ {i j} \times A _ {t} \times a \tag {4}
$$

where $E _ { i j }$ is the ESV flow from region $i$ to region $j , A _ { t }$ is the radiation area of region $i ,$ which is a circular area centered on its geometric center, and $a$ is the parameter of the spatial value transfer. In this study, according to the previous research [46], $a$ is set to 0.6.

# 2.3.5. Evaluation of Coupling Coordination Degree

Environment and urbanization interact in a nonlinear way. In this study, the CCD model was employed to characterize the intracoupling, pericoupling, and telecoupling between urbanization and the environment from local to distant levels. Overall, this model has been proven effective in providing insightful information about the degree of coherence between the systems [47–49] and has been widely applied to depict the coupling coordination between urbanization and the environment [50,51]. The formula is as follows:

$$
C = \sqrt {\frac {\left(U _ {1} \times U _ {2}\right)}{\left(\left(U _ {1} + U _ {2}\right) / 2\right) ^ {2}}} \tag {5}
$$

$$
C C D = \sqrt {C \times T} (0 <   C C D \leq 1) \tag {6}
$$

where C is the coupling degree between UL and EL; T is the comprehensive coordination index of the UL and EL system; CCD is the Coupling Coordination Degree between UL and EL; $U$ and $E$ are the normalized values of UL and $\scriptstyle \mathrm { E L } ,$ respectively; and $\alpha$ and $\beta$ are the contribution of $U _ { 1 }$ and $U _ { 2 } ,$ respectively.

According to the previous research [52,53], $\alpha$ and $\beta$ are set to 0.5. Higher CCD values indicate better-coordinated development, which means both the coupled system and its relationship are developed in a harmonious and consistent way. Based on previous studies [54], the values of CCD were categorized into five levels: excellent coordination $( 0 . 8 < \mathrm { C C D } \leq 1 )$ ), moderate coordination $( 0 . 7 < \mathrm { C C D } \leq 0 . 8 )$ ), primary coordination $( 0 . 6 < \mathrm { C C D } \le 0 . 7 )$ ), moderate imbalance $( 0 . 5 < \mathrm { C C D } \le 0 . 6 )$ , and severe imbalance $( 0 < \mathrm { D } \le 0 . 5 )$ ).

# 2.3.6. Geodetector Model

The Geodetector model is a spatial statistical method for analyzing the relationship between geographic objects and the influence degree of multiple factors in a spatially differentiated perspective [55]. Recently, this model has been widely used to study the influencing factors and their influence degree on the CCD [56,57]. This study first used a

factor detector to identify the influencing local, adjacent, and distant flows of production and ES factors and their influence degree on the CCD at three scales. The formula is as follows:

$$
q = 1 - \frac {\sum_ {h = 1} ^ {L} N _ {h} \delta_ {h} ^ {2}}{N \delta^ {2}} \tag {7}
$$

where $h = 1 , 2 , . . . , L$ refers to the layer of variables; $N$ and $\delta ^ { 2 }$ are the total number of sample units and the variances in the whole area, respectively; and $N _ { h }$ and $\delta _ { h } ^ { 2 }$ are the number of sample units and the variances in layer $h ,$ respectively. The range of the q value is [0, 1]; the larger the value is, the stronger the influence of factor X on CCD, and the weaker the opposite.

Interaction detectors determine if there is an interaction between two factors $\mathrm { { X } _ { 1 } }$ and $\mathrm { X } _ { 2 } )$ and if it enhances or weakens the explanatory power of spatial heterogeneity [58]. The types of interactions between variables are listed in Table 2.

Table 2. Types of interactions between pairs of variables.   

<table><tr><td>Type</td><td>Description</td></tr><tr><td>Nonlinear weakening</td><td>q(X1∩X2) &lt; Min (q(X1), q(X2))</td></tr><tr><td>Nonlinear enhancement</td><td>q(X1∩X2) &gt; q(X1) + q(X2)</td></tr><tr><td>Single-factor nonlinear weakening</td><td>Min (q(X1), q(X2)) &lt; q(X1∩X2) &lt; Max (q(X1), q(X2))</td></tr><tr><td>Double-factor enhancement</td><td>Max (q(X1), q(X2)) &lt; q(X1∩X2)</td></tr><tr><td>Independent</td><td>q(X1∩X2) = q(X1) + q(X2)</td></tr></table>

X factors were economic flow, population flow, information flow, and ES flow, whereas Y factors were the degrees of intracoupling, pericoupling, and telecoupling. The Geodetector model required categorical input variables, so the continuous variables were discretized in ArcGIS 10.6.

# 3. Results

# 3.1. Spatial Pattern of Urbanization Level

Figure 4a–c show the spatial pattern of urbanization subsystems with a consideration of cross-regional flows of production factors at local, adjacent, and distant scales. At local scales, high values of economic urbanization were primarily concentrated in the southeastern part, mainly in Chongqing Municipality, with Chongqing having the highest value of 84.79 (Figure 4a). The southwest had the lowest levels of economic urbanization, with all districts and counties below 50. The economic urbanization level of the southeastern region, when compared to peripheral areas, remains higher than adjacent and distant scales, with Chongqing achieving the highest score (70.58). Economic urbanization levels were lowest in the Southwest, led by Ya’an and Yibin, with Ya’an having the lowest value of 26.80.

At local scales, high values of population urbanization were predominantly located in the northern region, with Chengdu having the highest value of 92.36 (Figure 4b). Districts and counties in the east had the lowest levels of urbanization, with values below 30. It was still higher than peripheral areas in the northern region at adjacent and distant scales, with the highest score in Chengdu (90.25), followed by Mianyang (32.87). There were mostly low levels of urbanization in the east, with Fengdu and Dianjiang having the lowest values. A majority of the regions with higher levels of social urbanization belong to the central and western regions, dominated by Chengdu and Mianyang, with Chengdu having the highest score (Figure 4c). The counties with the lower values were concentrated in the northeast part, led by Fengdu and Dianjiang, with Liangping having the lowest value of 0.39.

![](images/af55efc5e303745aec43576c06f9513babff7f0f7b69b8d95819cab68ab00b7c.jpg)  
(a)   
Figure 4. (a–c) Spatial distribution of urbanization subsystems at local, adjacent, and distant scales ((a) Economic urbanization; (b) Population urbanization; (c) Social urbanization).

Figure 5a–d show the spatial pattern of the UL without and with consideration of crossregional flows of production factors in the CCUA. As local flows of production factors were not taken into account (Figure 5a), the north and southeast of CCUA had the highest levels of urbanization, with Chengdu and Chongqing having the highest values of urbanization in 2023. Counties with lower urbanization levels were mainly found in the east. The findings illustrated that the level of urban development in CCUA was highly polarized. Previous research found that the comprehensive urbanization levels have significant spatial heterogeneity on a global scale [59].

When local flows of production factors were taken into account (Figure 5b), the UL in the north of the CCUA was still higher than in the surrounding areas. The highest was in Chengdu and Chongqing. The areas with a lower UL were mainly in the northeastern region, led by Kai County and Fengdu County. The UL in the southwestern region decreased, suggesting that population, economic, and social mobility may influence the UL in these regions. However, these regions showed urban improvement, when cross-regional flows of production factors from neighboring (Figure 5c) and distant areas (Figure 5d) were considered. These results implied that the cross-regional flow of production factors may contribute to higher ULs in the CCUA.

![](images/b9c6dcde212d5083a6e2835fa85ae52e70891d08a9508e73ac9ead6f28bd937c.jpg)  
(a) CCUA

(b) CCUA   
  
![](images/b9810ddc6be3dcdb967306982213d29ae217fb88feaa09907e5f6986c8cf279d.jpg)  
-90.13 -36.93 -32.47 26.83-29.26 24.37-26.83 22.42-24.37 10.00-22.42 Chengdu-Chongqing urban agglomeration

![](images/fcbe7f135b87ab84d0f636516a89730808c10367efecc88de5f0c75462019825.jpg)  
0.2040 80 120 160 km

(c) URYREB

-91.13-36.93-32.4726.83-29.2624.37-26.8322.42-24.3718.30-22.42Chengdu-Ch

Figure 5. Spatial distribution of UI in CCUA ((a) No flow of production factors in CCUA; (b) Flow of production factors in CCUA; (c) Flow of production factors in URYREB; (d) Flow of production factors in YREB).   
![](images/9d1cb09f8b357dcfc06eb3bfbe1f68b211e291066a90fd4c70249d0b5c5bc6b9.jpg)  
93-91.13 47-36.93 29.26-32.47 26.83-29.26 24.37-26.83 22.42-24.37 18.22-22.42 ]Chengdu-Chongqing urban agglomeration

(d) YREB

# 3.2. Spatial Pattern of Environment Level

Figure 6a–c show the spatial pattern of ES flow at local, adjacent, and distant scales.

![](images/352a36a6dad07117adb74cbcefdc31d7d9e78e65706b50f8f764a2db72606b51.jpg)  
(a) CCUA

![](images/d4afddee0197bf63981e90038e91b73e2c04cd62dacb41b550b2de55426b96f3.jpg)  
(b) URYREB

Figure 6. Spatial distribution of ES flow at local, adjacent, and distant scales ((a) CCUA; (b) URYREB;Figure 6. Spatial distribution of ES flow at local, adjacent, and distant scales ((a) CCUA; (b) URYREB; (c) YREB).(c) YREB).   
![](images/e1aacbabd58b531bc16be677e62185e88a3ec057eae402645439a1c5f994dd91.jpg)  
22.61-2125.37   
2.97-22.61   
1.61-2.97   
0.51-1.61   
0.04-0.51   
Chengdu-Chongqing urban agglomeration

(c) YREB

ES flow

Figure 7a–d show the spatial pattern of EL without and with consideration of cross-At local scales, high values of ES flow were predominantly located in the central and regional flows of ESs in the CCUA. When local flows of ESs were not considered (Figureeastern regions, with Dazu having the highest value of 2125.37 (Figure 6a). Districts and

counties with ES flow values less than 3 were concentrated in the center. From adjacent to distant scales (Figure 6b,c), the values of ES flow in almost all regions have decreased. The lowest levels were mostly distributed in the center, led by Zigong and Rongchang, with Zigong having the lowest value of 0.04.

Figure 7a–d show the spatial pattern of EL without and with consideration of crossregional flows of ESs in the CCUA. When local flows of ESs were not considered (Figure 7a), regions with good and relatively good EL were mainly distributed in most regions, dominated by Chengdu, Ya’an, and Mianyang, with Chengdu having the highest score. Regions with poor and relatively poor ELs were mainly distributed in the northeast, dominated by Kai County. This indicates that the overall ecological situation of the CCUA was well. Ariken et al. also confirmed that the ecological environment of the Silk Road Economic Belt is at a relatively good level [18].

![](images/5af5e9836fab34de685d25f3f261fe96ca15812098194f6a454b93ab9a4cb898.jpg)  
(a) CCUA

![](images/1291387979848ff06334891caab1951554b4a3647777f027ce7412e48a77e46e.jpg)  
(b) CCUA

![](images/d98359296f75850e86b84bcd71e973d2ef04a6aa25f5fdcce7929c9e09cd3f25.jpg)

![](images/1b8cb9d7357488da496d8d473f1508d4feac73d7097c7736b1ef743b36563bf8.jpg)

![](images/9d70fe6c98e03714f68dd68482bd42ba2c6c8e85ad70e77cd25b9f932ab285f7.jpg)  
(c) URYREB

![](images/fde12043e3eed4bdb9592f55dd84f62609f8bc7d3e3b050f7f612c193d0151da.jpg)  
(d) YREB

![](images/7f4ec4bb1808893ded2b8122522ff7d6e4fb5e3b0c75954d554bcb632c24058e.jpg)  
Figure 7. Spatial distribution of EI in CCUA ((a) No flow of ESs in CCUA; (b) Flow of ESs in CCUA; (c) Flow of ESs in URYREB; (d) Flow of ESs in YREB).

When local flows of ESs were taken into account (Figure 7b), the values of EL in the surrounding area still remained higher than in other regions, whereas there was a decrease in the central and eastern regions. In addition, the surrounding areas experienced ecological degradation when cross-regional flows of ESs from neighboring (Figure 7c) and distant areas (Figure 7d) were considered. These results indicated that the cross-regional flow of

ESs was likely to threaten the EL of the UCCA, and the ES flow from the distant areas may have a significantly greater impact.

# 3.3. Analysis of the Metacoupling Between Urbanization and the Environment

# 3.3.1. Intracoupling

The coupling degree of urbanization and the environment in the CCUA had four types: severe imbalance, moderate imbalance, primary coordination, and excellent coordination (Figure 8a). Most cities were in the stage of moderate imbalance between urbanization and the environment. Among them, Chengdu had the highest CCD value, and Fengdu had the smallest CCD value. Wan et al. (2021) also found that the CCD between the social economy and ecological environment of the CCUA presents a low level overall [60]. Related research also reported that the CCD among the states of Kazakhstan is mostly at a low-moderate level [57]. Regarding the spatial pattern, the regions in the stage of moderate imbalance were mainly distributed in the middle part of the CCUA, while those with primary coordination types were on the north and south sides.

![](images/76b2123600b6cdab5ddffa5055c378a21e86b59e1619de51eab62163ca03dea9.jpg)  
(a) CCUA

![](images/84abb9ab8c0cc9a825e2f6e1c24e53a1553b4048e292671b22674100be6e39bc.jpg)  
(b) CCUA

# acoupling

Excellent coordination   
Moderate coordination   
Primary coordination   
Moderate imbalance   
Severe imbalance   
Chengdu-Chongqing urban agglomeration

![](images/ffa99059cfd03cc61cf02fb042dbeecd5b807ec69f70f98f264ed263bf8ae911.jpg)

![](images/76d30ede9664034cf6e88e39687e81af2d2664a788a1b1933e7398e70f7c1489.jpg)  
(c) URYREB

![](images/731ea642aa058e7690289f26a3267bbf95f947fc9220b7fcdba062c74ed9489f.jpg)  
Figure 8. Spatial distribution of the metacoupling between urbanization and the environment.

# Pericoupling

Excellent coordination   
Moderate coordination   
Primary coordination   
Moderate imbalance   
Severe imbalance   
Chengdu-Chongqing urban agglomeration

# Telecoupling

Excellent coordination   
Moderatecoordination   
Primary coordination   
Moderate imbalance   
Severe imbalance   
Chengdu-Chongqing urban agglomeration

The intracoupling degree of urbanization and the environment had four types: severe imbalance, moderate imbalance, primary coordination, and excellent coordination (Figure 8b). The majority of cities were experiencing moderate imbalances. Regarding the spatial distribution, areas in the stage of moderate imbalance were mainly found not only

in the middle parts but also the southwestern part, including Leshan, Yibin, and Meishan. And the primary coordination stage is mainly distributed in the northern region.

# 3.3.2. Pericoupling

The pericoupling degree of urbanization and the environment in CCUA had four types: severe imbalance, moderate imbalance, primary coordination, and excellent coordination (Figure 8c). There was moderate imbalance and moderate coordination in most regions. The highest value was found in Chengdu, while the lowest value was found in Kai Zhou. Spatial distribution indicated that moderately imbalanced areas accounted for almost all of the CCUA.

# 3.3.3. Telecoupling

The telecoupling degree in the CCUA had five types: severe imbalance, moderate imbalance, primary coordination, moderate coordination, and excellent coordination. The majority of regions were in the stage of moderate coordination or primary coordination (Figure 8d). Among them, Chengdu had the highest CCD value, and Dianjiang had the smallest CCD value. Areas in the stage of moderate imbalance were mainly located in the north, while the primary coordinated areas were located in the southwest. Our findings showed that, from local to distant scales, the cross-regional flow of factors may enhance the coupling between urbanization and the environment in the CCUA.

# 3.4. Factors Affecting the Intracoupling, Pericoupling, and Telecoupling

# 3.4.1. Main Factors

Based on single-factor detection, the q-values of each flow influencing the degrees of intracoupling, pericoupling, and telecoupling were calculated. In the CCUA, population flow $( \mathsf { q } = 0 . 3 9 )$ , economic flow $( \mathbf { q } = 0 . 3 7 )$ , and information flow $( \mathsf { q } = 0 . 3 5 )$ all had strong effects on intracoupling, while ES flow had the smallest influence $( \mathbf { q } = 0 . 1 0 )$ . Pericoupling was best explained by ES flow $( \mathbf { q } = 0 . 6 7 )$ ) in the URYREB, followed by population flow $( \mathbf { q } = 0 . 3 0 )$ , information flow $( \mathsf { q } = 0 . 2 9 )$ ), and economic flow $( \mathbf { q } = 0 . 2 8 )$ ). There was a significant influence of ES flow $( \mathbf { q } = 0 . 6 0 )$ on the spatial heterogeneity of telecoupling between urbanization and the environment, followed by economic flow $( \mathbf { q } = 0 . 2 4 )$ ), information flow $( \mathbf { q } = 0 . 1 9 )$ ), and population flow $( \mathsf { q } = 0 . 1 7 )$ in the YREB.

In summary, the dominant factors of coupling degree varied from local to distant scales. Those at the local scale were production factor flows, including population flow and economic flow. The dominant factors at the adjacent scale were ES flow and population flow, while economic flow and ES flow were at the distant scale. As a result of the factor detector, production factor flows and ES flows both played important roles in the metacoupling between urbanization and the environment. Production factor flows had greater explanatory power at the local scale, while ES flow had more explanatory power at the adjacent and distant scales. According to Ma et al. (2024), foreign trade and net inflows of foreign direct investment have adverse effects on urbanization–carbon emission efficiency coupling in 106 nations worldwide [59].

# 3.4.2. Interactions Between Cross-Regional Flow of Multi-Factors

Interaction detector results revealed that production and ES factors do not act independently; any interaction enhances the explanatory power of a dependent variable greater than any single factor alone.

There were five pairs of interactions between the cross-regional flow of multi-factors that demonstrated two-factor enhancements and one pair that showed nonlinear enhancements in the CCUA. Information flow and economic flow (information flow ∩ economic

flow) provided the strongest explanation for the intracoupling between urbanization and the environment among all interactions.

There were four pairs of interactions between the cross-regional flow of multi-factors that demonstrated two-factor enhancements and two pairs that showed nonlinear enhancements in the URYREB. Information flow and ES flow (information flow ∩ ES flow) provided the strongest explanation for the pericoupling between urbanization and the environment among all interactions.

There were three pairs of interactions between the cross-regional flow of multi-factors that demonstrated two-factor enhancements, and three pairs that showed nonlinear enhancements in the YREB. Information flow and ES flow (information flow ∩ ES flow) provided the strongest explanation for the telecoupling between urbanization and the environment among all interactions. These findings emphasized that the interactions between production and ES factors played important roles in promoting the urbanization– environment metacoupling in the CCUA.

# 4. Discussion

# 4.1. Exploring the Relationship Between Production Factor Flows and Urbanization Level

Urbanization is accompanied by the flow of various production factors. Our results indicated that the cross-regional mobility of population, capital, and information factors may contribute to higher ULs in the CCUA. A process of spatial reallocation, the emergence and development of these production factors is a powerful force for economic and social progress [35]. For example, rural–urban migration is dominated by the young and middleaged population, which contributes to supplementing the local labor market and improving the urban demographic structure [61]. Frequent economic activities and information exchange platforms increase closed interactions between cities and attract rural labor to cities [62,63]. This flow not only improves the population size of cities but also contributes to the rational allocation of local labor [64,65].

Meanwhile, the mobility and diversity of the labor force can be used to develop a variety of industries, including urban services and urban industries, as well as to develop the local industrial structure [66]. Through regional cooperation and complementarity, economic linkages can promote the optimal allocation of resources, achieve industrial transformation, and improve the industrial competitiveness of the entire region [67,68].

Further, the new inflow of people will result in new consumer needs such as housing, education, health care, and entertainment, stimulating the development of related industries in the city and stimulating the construction of local infrastructure and public service facilities, such as schools, hospitals, and public transportation [69]. Thus, interregional economic and social linkages can enhance public services across the region through the sharing of public service resources, such as health care, education, and culture [70,71]. In short, the cross-regional flows of production factors help to achieve regional collaboration, functional complementarity, and resource sharing, thereby promoting the urban agglomeration integration.

# 4.2. Exploring the Relationship Between ES Flow and Environment Level

Ecological and socioeconomic systems are interconnected by ES flow [41]. Our results found that the cross-regional flow of ESs may threaten the EL of the CCUA. On the one hand, as a result of cross-regional flow of ESs, certain regions may suffer from the overexploitation of natural resources, making their ecosystems more vulnerable [72]. On the other hand, the construction of roads and water pipelines is often necessary to maintain stable ES flows. The construction of such infrastructure may undermine the integrity of the natural ecosystem, leading to habitat fragmentation and decreased species diversity [73].

Therefore, the cross-regional characteristics of ES flow should be taken into policy making for optimizing ecological protection strategies [74].

# 4.3. Main Factors Influencing the CCD from Local to Distant Levels

The Geodetector model was used in this study to explore the underlying factors affecting the coupling degrees from local and distant regions. Our results indicated that urbanization–environment metacoupling in the CCUA was explained by production factor flows and ES flows; however, production factor flows were more strongly explained at the local level. In this regard, geographical environment and distance play an important role in determining the mobility of production factors within regions [75]. These flows usually tend to go to economically developed areas with improved infrastructure. The complex topography of the CCUA leads to high costs of infrastructure construction and technological innovation, which in turn limit the inflow of external capital and labor [76]. On the other hand, the greater the geographical distance, the higher the transport cost and time, and the smaller the scale of population migration. Therefore, the attenuating effect of geographical distance is still significant in China’s cross-provincial population flow [77].

Our results also indicated that ES flow was more strongly explained at the adjacent and distant scales. The CCUA, rich in natural resources and with a generally favorable ecological quality, serves as an important ecological function area in the western part of China and the crucial ecological barrier in the upper reaches of the Yangtze River. There are a number of critical ecological functions that the YREB performs, such as water yield, soil conservation, biodiversity, and flood storage, that are directly connected to the ecological security of the region [50]. Therefore, environmental preservation and green development should be prioritized in CCUA urban planning, with a focus on ecological restoration and conservation.

As a result of the CCUA, the population of ecological functional areas could be concentrated in urban agglomerations, the regional economy and population could be more productive, and a new development pattern could be developed that emphasizes the protection of ecological functional areas and the development of advantageous regions. Furthermore, stable ES flows depend on the effective management of transmission nodes and ecological networks [12]. First, infrastructure upgrades in the areas surrounding these nodes should be prioritized. Second, restoring ecological core zones and constructing ‘stepping stones’ can help to enhance the resilience and connective of ecological corridors, thereby ensuring the delivery of ESs to human societies.

# 4.4. Limitations and Future Erspectives

There are also several limitations to this study, which suggest that further research may be necessary. The production factor intensity was measured using multi-source big data, but policy flows were not considered, which will be further examined in future studies. Second, the dynamics evolution of metacoupling between urbanization and the environment across different temporal scales needs to be further considered. Finally, the results derived from the Geodetector model may not capture the mechanisms underlying cross-regional flows. Further research is therefore required to identify the key determinants and their underlying driving mechanisms that influence the metacoupling between urbanization and the environment.

# 5. Conclusions

The metacoupling between urbanization and environment needs to be clarified, providing departments with a theoretical basis for formulating urban development strategies, especially in lower-income countries where urbanization is accelerating. Under the meta-

coupling framework, we constructed a new comprehensive index system for urbanization and the environment, applied the Coupling Coordination Degree (CCD) model, and used the Geodetector model to investigate the effects of local, adjacent, and distant flows of production and ES factors on the degrees of intracoupling, pericoupling, and telecoupling. The principal findings are as follows:

1. During the study period, the UL of the CCUA was highly polarized when local flows of production factors were not taken into account. However, the southwestern region showed urban improvement, when cross-regional flows of production factors were considered.   
2. The overall EL of the CCUA was good when local flows of ESs were not taken into account, whereas the surrounding areas experienced ecological degradation when cross-regional flows of ESs were considered.   
3. The overall coupling degree between urbanization and the environment in the CCUA was low. However, the cross-regional flow of production and ES factors may enhance the coupling from local to distant scales. In the CCUA, production factor flows and ES flows were found to be the common factors that affected the metacoupling between urbanization and the environment.   
4. Both production factor flows and ES flow played important roles in the metacoupling between urbanization and the environment of the CCUA, with varying explanatory power at different scales. Among them, population and economic flows have stronger explanatory power at local scales, ES flow and population flow have stronger explanatory power at adjacent scales, and economic flow and ES flow have stronger explanatory power at long-distance scales.

The research results facilitate a systematic understanding of the relationship between urbanization and environment and provide a scientific foundation for optimizing urbanization strategies and ecological protection measures. The authors also hope that this paper will provide a new framework of analyzing urbanization and environment in other urban agglomerations. In the future, efforts should be made to consider the impact of additional types of flows (such as policy flows), assess the dynamics evolution of metacoupling between urbanization and the environment across different temporal scales, and analyze the driving mechanisms of cross-regional flows, to propose more realistic optimization strategies.

Author Contributions: Conceptualization, Y.H., L.Y., and P.H.; data curation, Q.J. and Y.W.; formal analysis, Y.H., L.Y., and G.W.; funding acquisition, Y.H. and Y.W.; investigation, G.W. and P.H.; methodology, Y.H., L.Y., and B.Z.; project administration, B.Z.; resources, Q.J.; supervision, G.W. and B.Z.; validation, Q.J. and Y.W.; visualization, Y.H.; writing—original draft, Y.H.; Writing—review and editing, Y.W., P.H., and B.Z. All authors have read and agreed to the published version of the manuscript.

Funding: This work was supported by Sichuan Science and Technology Program (2024NSFSC1233); State Key Laboratory of Clean and Efficient Coal Utilization, Taiyuan University of Technology (MINYSKL202409; MJNYSKL202510); the opening project of Engineering Research Center of Comprehensive Utilization and Clean Processing of Phosphorus Resources, Ministry of Education (2024CUCPPR04); Service Science and Innovation Key Laboratory of Sichuan Province (KL2407); International Cooperation Joint Laboratory of Health in Cold Region Black Soil Habitat of the Ministry of Education (HCRBSH202311-09); Key Laboratory of Songliao Aquatic Environment, Ministry of Education (JLJUSLKF042024009); Open Research Fund Program of Key Laboratory of Urban Stormwater System and Water Environment (Beijing University of Civil Engineering and Architecture), Ministry of Education (USSWE2024KF01); Hubei Key Laboratory of Digital Finance Innovation, Hubei University of Economics (DFIK2024Y09); the Level Enhancement Project of Xi’an Key Laboratory of Urban Low-Carbon Construction (Chang ’an University) (300102284501); Open Fund Project of Wuhan Red Culture Research Center (Key Research Base of Humanities and Social Sciences in Hubei Province’s

Universities) (WHHS20241001); Open Research Fund Program of Key Laboratory of Digital Mapping and Land Information Application, Minisitry of Natural Resources (ZRZYBWD202405); Traditional Crafts Institute, the Key Research Institute Academic Center of Chinese Culture for Sichuan Province (CTGY23YB05); Sichuan Center for Zhang Dagian Studies (zdq201905).

Data Availability Statement: Data will be made available on request.

Conflicts of Interest: The authors declare no conflicts of interest.

