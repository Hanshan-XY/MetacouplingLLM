# The financialization of rivers Clean Development Mechanism (CDM) subsidized hydropower in the Mekon

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:00:29.930175+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Motta et al. - 2025 - The financialization of rivers Clean Development Mechanism (CDM) subsidized hydropower in the Mekon.pdf
- Year: unknown
- DOI: 10.1016/j.gloenvcha.2024.102962
- OA status: hybrid
- License: cc-by-nc-nd
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This paper investigates how the Kyoto Protocols Clean Development Mechanism (CDM) has driven large-scale hydropower expansion in the Mekong Region, and how this links global carbon markets to local water conflicts. The geographic focus is on five major transboundary basins shared by China and its neighbors: the Irrawaddy, Salween, Red, Bei Jiang/Hsi, and Mekong.

The authors use the telecoupling framework to examine interactions among three interconnected systems. Europe and other Annex I countries act as the sending system, channeling climate finance and demand for carbon credits. Southwestern China, especially Yunnan, is the receiving system where most CDM-subsidized dams are built. The Mekong Region’s downstream and border communities form the spillover system, experiencing environmental and political consequences that are largely ignored in climate accounting.

Methodologically, the study combines global CDM registry data, the Greater Mekong Dam Observatory, and the Transboundary Freshwater Disputes Database. Over 1,000 CDM-registered large dams worldwide are mapped with GIS onto 310 international river basins. Project design documents are screened to verify locations and attributes. The authors then highlight case studies from Myanmar, Yunnan, and Vietnam to illustrate tensions.

They find that 484 CDM dams are in transboundary basins, heavily clustered in the Mekong Region. The Red, Salween, Bei Jiang/Hsi, and Irrawaddy - all previously classified as very high risk for hydropolitical tension - are the top four global recipients of CDM-funded large dams; the Mekong ranks fifth. Many projects primarily serve as financial assets for carbon markets and Chinese state-owned enterprises rather than reliable energy sources, creating overcapacity, grid bottlenecks, and so-called zombie credits. At the same time, downstream countries face heightened uncertainty, weak data sharing, and limited institutional capacity to manage rapid hydrological change.

The paper is explicitly about telecoupling/metacoupling. It demonstrates how carbon-focused climate finance, when blind to transboundary water governance, can deepen power asymmetries, fuel local and international conflicts, and effectively financialize rivers rather than support genuinely sustainable transitions.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling among Europe, China, and Mekong Region via CDM-financed hydropower and carbon markets.

### Intracoupling
#### Systems
- Yunnan provincial river basins with dense CDM hydropower development.
- European Union internal carbon market and corporate offset practices.
- Myanmar national context around Darpein 1 dam and civil conflict.
#### Flows
- Domestic electricity generation and curtailment within Yunnan grid.
- Internal EU trading of cheap CER-based hydropower credits.
- Internal population displacement around Myanmar dam conflict zone.
#### Agents
- Chinese provincial governments and state-owned hydropower firms.
- EU regulators, corporations, and carbon market intermediaries.
- Myanmar military actors and ethnic armed organizations.
#### Causes
- National development agendas favoring large hydropower expansion.
- EU reliance on offsets instead of deep domestic decarbonization.
- Centralized decisionmaking ignoring local hydropolitical risks.
#### Effects
- Overbuilt rivers, low utilization, and zombie hydropower projects.
- Greenwashed net zero claims using questionable old CERs.
- Escalation from dam disputes to broader armed conflict.

### Pericoupling
#### Systems
- China and immediately downstream Mekong countries sharing specific basins.
- Border regions along Red River and Mekong between China and Vietnam.
- Yunnan and neighboring Southeast Asian countries linked by power exports.
#### Flows
- Cross-border river water and unannounced dam releases near borders.
- Electricity exports from Chinese dams to neighboring states.
- Migration of displaced communities across short international borders.
#### Agents
- China and Vietnam national water agencies and diplomats.
- Chinese and Vietnamese hydropower companies and contractors.
- Borderland communities dependent on shared river resources.
#### Causes
- Hydropower clustering close to sensitive international borders.
- Limited or absent basin-level treaties and data sharing.
- Historical military tensions overlaying new infrastructure disputes.
#### Effects
- Reduced response time to dam releases and heightened downstream insecurity.
- Persistent mistrust and stalled cooperation over shared rivers.
- Long-running arbitration over binational dam contracts and performance.

### Telecoupling
#### Systems
- Europe and Annex I countries as capital and demand senders.
- Southwest China, especially Yunnan, as subsidy-receiving hydropower hub.
- Mekong Region transboundary rivers as spillover basins at high conflict risk.
#### Flows
- Climate finance and CDM subsidies from Europe to Chinese hydropower projects.
- Certified Emission Reductions and sustainability claims flowing back to Europe.
- Second-order flows like energy-intensive industries relocating to Yunnan.
#### Agents
- EU institutions, member states, and offset-buying corporations.
- Chinese state-owned hydropower enterprises and central planning agencies.
- Riverine communities and weaker Mekong governments bearing spillover costs.
#### Causes
- Global offset-based climate policy design privileging carbon fungibility.
- Financialization of rivers turning dams into primary investment vehicles.
- Political incentives to meet climate targets without structural fossil cuts.
#### Effects
- Hundreds of large dams in conflict-prone basins, amplifying power asymmetries.
- Creation of zombie CERs disconnected from real emission reductions.
- Carbon cost shifting from wealthy emitters to vulnerable Mekong communities.

### Cross-Coupling Interactions
- Telecoupled CDM subsidies intensify intracoupled Yunnan overcapacity and local environmental strain.
- Pericoupled border tensions in Red and Mekong basins are fueled by distant European carbon demand.
- Darpein 1 shows telecoupled finance feeding intracoupled civil conflict with regional spillovers.

### Research Gaps or Limitations
- Limited systematic evidence on cumulative hydropolitical impacts across all 200+ Mekong CDM dams.
- Incomplete or inaccurate project coordinates and technical data, especially near borders.
- Sparse monitoring of how legacy CDM credits shape emerging Article 6 carbon markets.

### Search Keywords
- CDM hydropower Mekong telecoupling financialization of rivers
- Yunnan zombie credits CER overcapacity conflict basins
- Red River Darpein Thuong Kon Tum hydropolitical risk

### Extraction Confidence
high
