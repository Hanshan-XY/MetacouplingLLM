# The local coupling and telecoupling of urbanization and ecological environment quality based on mult

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:52:21.675572+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Li et al. - 2023 - The local coupling and telecoupling of urbanization and ecological environment quality based on mult.pdf
- Year: unknown
- DOI: 10.1016/j.jenvman.2022.116921
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines how urbanization and ecological environment quality (EEQ) interact within and between provinces across China from 2000 to 2020, explicitly using a metacoupling-telecoupling perspective. The authors focus on both local linkages (within a province) and telecoupled influences (between provinces) under rapid globalization and domestic development.

They develop an enhanced remote sensing ecological environment index (RSEEI) to evaluate EEQ. RSEEI extends the widely used RSEI by adding two elements drawn from ecological index practice: a biological abundance index and a fine-scale environmental pollution index. The latter is derived by downscaling provincial sulfur dioxide, chemical oxygen demand, and solid waste emissions to 1 km pixels using population density, better capturing urban pollution patterns. RSEEI is constructed via principal component analysis from greenness, surface temperature, wetness, dryness, abundance, and pollution indicators, using MODIS, land cover, statistical, population, and nighttime light data.

Urbanization intensity is measured with a composite nighttime light index. The authors then apply an extended coupled coordination model (LTCCD) that includes both local coupling between a province’s urbanization and EEQ, and telecoupling effects from all other provinces weighted by distance. Trend analyses (Theil-Sen and linear regression) characterize temporal changes.

China’s average EEQ shows a slight national decline, with strong east-west contrast along the Heihe-Tengchong Line and better conditions in southeastern coastal provinces than in the northwest. Urbanization increases everywhere, fastest in major coastal metropolises. Regions with higher initial urbanization generally urbanize faster, while many high-EEQ southern provinces experience ecological deterioration. LTCCD values are consistently higher than traditional coupling values, indicating that interprovincial telecoupling strengthens apparent coordination and reduces relative disparities in the socio-ecological system.

Spatially, eastern coastal areas generally achieve higher coordination but face tradeoffs from dense development, central-north and central-south inland regions often have good EEQ but lagging urbanization, and northwestern provinces remain in low-low, disordered states. The work is explicitly about telecoupling/metacoupling, showing how distant urban-ecological interactions reshape regional sustainability patterns and supporting differentiated, region-specific policy strategies.

## Structured Metacoupling Extraction

### Coupling Classification
- Analyzes both local coupling and interprovincial telecoupling between urbanization and ecological environment in China

### Intracoupling
#### Systems
- Provincial urbanization systems within China
- Provincial ecological environment quality subsystems
#### Flows
- Within province land use change and pollution emissions
- Internal feedback between urban growth and ecological degradation
#### Agents
- Provincial governments and planners
- Local industries and residents
- Urban cluster core cities within the same province
#### Causes
- GDP oriented rapid urbanization and industrialization
- Population concentration and local pollution pressure
- Land conversion to construction and infrastructure
#### Effects
- Mismatch between urban growth and ecological quality
- Provincial patterns of ecological decline or improvement
- Shift from disorder to internal coordination in some provinces

### Pericoupling
#### Systems
- Neighboring Chinese provinces across shared boundaries
- Urban clusters spanning adjacent inland and coastal provinces
#### Flows
- Short distance spillovers of pollution and ecological stress
- Regional diffusion of urbanization from core to nearby areas
#### Agents
- Adjacent provincial governments
- Regional urban agglomeration authorities
- Interprovincial transport and energy networks
#### Causes
- Strengthened regional exchanges under national development strategies
- Spatial clustering of eco environment quality among neighbors
- Radiation of large cities to surrounding provinces
#### Effects
- Adjacent changes in LTCCD levels over time
- Expansion of basic coordination from coast to nearby inland
- Shared coordination problems in northern and central south inland regions

### Telecoupling
#### Systems
- Eastern coastal provinces and distant inland provinces
- Highly urbanized city regions and remote ecological regions
- National scale network of all Chinese provinces
#### Flows
- Long distance economic, trade and information interactions
- Remote influences of urbanization on external ecological systems
- Telecoupled coordination index linking non adjacent provinces
#### Agents
- National government shaping unbalanced development strategy
- Mega cities like Beijing Shanghai Hong Kong Macao
- Interregional trade logistics and technology sectors
#### Causes
- Globalization driven flows of people goods capital information
- Remote spillovers of urbanization and environmental impacts
- Policy driven concentration of development in leading regions
#### Effects
- Higher LTCCD than traditional CCD across provinces
- Stronger correlation between urbanization and ecology among regions
- Reduced relative disparities through telecoupled radiation effects

### Cross-Coupling Interactions
- Local CCD upgraded by adding telecoupling to form LTCCD at provincial scale
- Telecoupling amplifies influence of core coastal cities on remote inland ecosystems
- Urbanization level dominates LTCCD turning ecological impacts from negative to positive at high stages

### Research Gaps or Limitations
- Urban ecological index still needs accuracy validation against independent observations
- Telecoupling assessed only at provincial level not municipal or finer scales
- Earlier telecoupling studies focused on limited city clusters with short radiation range

### Search Keywords
- telecoupling urbanization ecological environment China LTCCD
- remote sensing ecological environment index RSEEI AI EPI
- spatiotemporal coupling coordination Heihe Tengchong Line

### Extraction Confidence
high
