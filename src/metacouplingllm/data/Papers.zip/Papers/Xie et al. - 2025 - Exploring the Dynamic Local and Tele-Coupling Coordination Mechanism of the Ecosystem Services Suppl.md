# Exploring the Dynamic Local and Tele-Coupling Coordination Mechanism of the Ecosystem Services Suppl

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:12:24.861400+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Xie et al. - 2025 - Exploring the Dynamic Local and Tele-Coupling Coordination Mechanism of the Ecosystem Services Suppl.pdf
- Year: unknown
- DOI: 10.1002/ldr.5559
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This article examines how ecosystem service supply and demand interact locally and over distance in the Yangtze River Economic Belt (YREB) of China, a major national development corridor covering 11 provinces from the upper to lower Yangtze. The focus is on three key ecosystem service subsystems that match prominent regional ecological issues and policy priorities: soil retention, water yield, and carbon storage.

Using InVEST-based models and statistical data for 2005-2020, the authors quantify ecosystem service supply and human demand for each subsystem, then construct composite indices with a combined entropy-CRITIC weighting method. They develop a dynamic local and tele-coupling coordination degree (DLTCCD) model that extends earlier coupling-coordination and local-telecoupling (LTCCD) approaches by (1) incorporating spatial spillovers between provinces using distance-based weights and (2) allowing the relative contribution of supply and demand to vary over time and space according to actual ESSD conditions, rather than fixed parameters. A random forest model with SHAP interpretation is then used to identify the main socioeconomic drivers of DLTCCD.

Results show clear spatial gradients: upstream provinces such as Sichuan and Yunnan are major suppliers of soil retention, water, and carbon storage, while downstream provinces, especially Shanghai and Jiangsu, are demand hotspots and often experience ecosystem service deficits, particularly for carbon. Water and soil services generally have surpluses across the belt, but carbon is strongly imbalanced in several urbanized areas. Overall DLTCCD levels improve over time but remain low or medium in many provinces, with persistent coordination problems in highly urbanized downstream regions.

Telecoupling and metacoupling are central to the study: the DLTCCD explicitly captures how ecosystem service imbalances and coordination are shaped by cross-provincial flows and spatial position within the basin, not just local conditions. Population size, urbanization rate, construction land extent, and industrial structure are identified as key drivers, suggesting that managing demographic patterns and urban land expansion is crucial for improving cross-regional ecological-economic coordination in the YREB.

## Structured Metacoupling Extraction

### Coupling Classification
- Explicitly about local coupling and long distance telecoupling of ecosystem service supply demand

### Intracoupling
#### Systems
- Ecosystem service subsystems for water yield soil retention carbon storage within YREB provinces
- Local human socioeconomic system including population industry urban land
#### Flows
- Internal flows of water soil conservation and carbon within each province
- Local demand flows for water use soil retention and carbon sinks
#### Agents
- Provincial and municipal governments managing land and ecology
- Local residents industries and farmers consuming ecosystem services
#### Causes
- Urbanization expansion of construction land and industrialization within provinces
- Provincial ecological protection and land use policies
#### Effects
- Imbalance between local ecosystem service supply and demand
- Changes in provincial ecological security and development sustainability

### Pericoupling
#### Systems
- Neighboring provinces along middle and lower Yangtze River
- Upstream and adjacent downstream subbasins within YREB
#### Flows
- Regional water transfers alleviating downstream water shortages
- Spatial spillover of soil conservation and carbon sinks to nearby provinces
#### Agents
- Basin level and provincial governments coordinating cross boundary projects
- Interprovincial infrastructure and water management authorities
#### Causes
- Shared river basin hydrology and terrain gradients
- Cross regional ecological projects and water diversion programs
#### Effects
- Improved water yield balance in deficit provinces like Jiangsu and Shanghai
- Spatial clustering of medium and high coordination in middle reaches

### Telecoupling
#### Systems
- Upstream ecological source regions such as Sichuan and Yunnan
- Downstream high demand regions like Jiangsu Shanghai Chongqing
- Broader human economic system interacting with regional ecosystems
#### Flows
- Long distance flows of ecosystem services via water atmosphere and transportation
- Telecoupled supply demand linkages of soil retention water yield and carbon storage
#### Agents
- National government designing Yangtze River Economic Belt strategies
- Enterprises and migrants driving demand in coastal cities
- Researchers applying LTCCD and DLTCCD telecoupling models
#### Causes
- Economic globalization and inland coastal development gradients
- Population concentration and industrial agglomeration in lower reaches
- National ecological protection and compensation policies
#### Effects
- Upstream provinces act as ecosystem service exporters
- Downstream provinces experience persistent ecosystem service deficits especially carbon
- Need for cross regional ecological compensation and coordinated planning

### Cross-Coupling Interactions
- Dynamic LTCCD model integrates local coupling with distance weighted telecoupling among provinces
- Telecoupling intensity moderated by spatial distance and evolving supply demand contribution coefficients
- Machine learning links demographic and economic drivers to spatiotemporal coupling coordination

### Research Gaps or Limitations
- No unified standard for selecting ecosystem service subsystems in ESSD assessments
- LTCCD and dynamic LTCCD mostly tested on single national region scales
- Influence factor analysis still mainly statistical lacking explicit spatial learning of drivers

### Search Keywords
- dynamic local telecoupling coordination degree DLTCCD model
- ecosystem service supply demand Yangtze River Economic Belt
- LTCCD telecoupling machine learning random forest SHAP

### Extraction Confidence
high
