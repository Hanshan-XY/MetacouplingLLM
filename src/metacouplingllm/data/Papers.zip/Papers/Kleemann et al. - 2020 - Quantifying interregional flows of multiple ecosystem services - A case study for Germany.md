# Quantifying interregional flows of multiple ecosystem services - A case study for Germany

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:49:44.254249+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Kleemann et al. - 2020 - Quantifying interregional flows of multiple ecosystem services - A case study for Germany.pdf
- Year: unknown
- DOI: 10.1016/j.gloenvcha.2020.102051
- OA status: hybrid
- License: cc-by-nc-nd
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This article investigates how people in Germany benefit from ecosystem services that are generated outside the country, and how these distant interactions create telecoupled links between social-ecological systems. The geographic focus is Germany as the receiving system, with sending systems in West and Central Africa, South America, Southeast Asia, neighboring European countries, and China. The work explicitly applies and operationalizes the telecoupling / interregional ecosystem services framework.

Using a tier 1.5 approach that combines existing global datasets with relatively simple modeling, the authors quantify four contrasting types of interregional ecosystem service flows: traded goods, migratory species, passive biophysical flows, and information.

For traded goods, they trace Germanys 2010 cocoa consumption back to producing countries with a trade matrix, then link these flows to cropland use, pollination dependence, and biodiversity loss. Over 90 percent of cocoa originates from seven countries, mainly in West Africa. Cocoa for German consumption occupies more than 0.9 million hectares of land abroad and would require many times more area without wild pollinators. Biodiversity impacts are concentrated in ecologically rich areas such as Cameroon and Ecuador, illustrating spatial mismatches between consumption and environmental damage.

For migratory species, they overlay range maps of pest-controlling bird species with German agricultural land. About 25 migratory species provide pest control in Germany while depending strongly on African habitats in humid and sub-humid zones, highlighting cross-continental ecological interdependence.

For passive biophysical flows, they apply an index-based flood regulation model to five transboundary river basins. Germany supplies roughly 40 percent of its ecosystem-based flood regulation service to downstream neighbors, especially the Netherlands and Austria, while importing about two-thirds of its own total flood regulation from upstream countries such as Poland and the Czech Republic.

For information flows, they combine Google Trends and newspaper content analysis around the Chinese loan of giant pandas to Berlin Zoo. Coverage is dominated by political and diplomatic themes, with relatively less emphasis on ecological or conservation information, showing how cultural telecouplings can be politically charged.

Overall, the study is directly about metacoupling/telecoupling and illustrates how multiple ecosystem service flow types can be quantified at national scale, with implications for environmental justice, shared responsibility, and international governance.

## Structured Metacoupling Extraction

### Coupling Classification
- Primarily telecoupling via interregional ecosystem service flows involving Germany.

### Intracoupling
#### Systems
- Not identified.
#### Flows
- Not identified.
#### Agents
- Not identified.
#### Causes
- Not identified.
#### Effects
- Not identified.

### Pericoupling
#### Systems
- Germany and neighboring EU states sharing major river basins.
#### Flows
- Cross border flood regulation and flood risk along shared rivers.
#### Agents
- National water agencies and river basin commissions.
#### Causes
- Upstream land cover change and flood management decisions.
#### Effects
- Altered downstream flood protection and exposure in neighboring countries.

### Telecoupling
#### Systems
- Germany as ES importer linked to distant sending regions.
- West Africa, Latin America, China, African flyways as senders.
#### Flows
- Cocoa and embedded services imported for German consumption.
- Migratory birds, flood regulation, panda related information flows.
#### Agents
- Farmers, traders, zoos, media, governments, conservation organizations.
- Migratory bird populations and upstream land managers.
#### Causes
- German demand for cocoa, agriculture protection, tourism, charismatic species.
- Global trade, migration ecology, international diplomacy, climate pressures.
#### Effects
- Deforestation, biodiversity loss, pollination dependence in cocoa regions.
- Shared flood risks, pest control benefits, political and cultural messaging.

### Cross-Coupling Interactions
- Cocoa driven forest loss may affect African migratory bird habitats.
- Trade, flood regulation, and information flows jointly shape equity issues.

### Research Gaps or Limitations
- Limited temporal analysis except for flood regulation indicators.
- Uncertainty from coarse species ranges, proxy ES indicators, simplified models.

### Search Keywords
- telecoupling ecosystem services Germany cocoa migratory birds flood regulation
- interregional flows panda diplomacy biodiversity trade environmental justice

### Extraction Confidence
high
