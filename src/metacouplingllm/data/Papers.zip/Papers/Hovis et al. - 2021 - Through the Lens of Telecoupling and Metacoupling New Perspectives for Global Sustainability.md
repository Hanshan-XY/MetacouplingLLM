Editorial

# Through the Lens of Telecoupling and Metacoupling: New Perspectives for Global Sustainability

Ciara L. Hovis $^ { 1 , * \oplus }$ , Yue Dou 2, Anna Herzberger 1 and Jianguo Liu $\mathbf { 1 } _ { \textcircled { 1 0 } }$

1 Center for Systems Integration and Sustainability, Department of Fisheries and Wildlife, Michigan State University, East Lansing, MI 48823, USA; ajherzberger@gmail.com (A.H.); liuji@msu.edu (J.L.)   
2 Environmental Geography Group, Institute for Environmental Studies (IVM), Vrije Universiteit Amsterdam, De Boelelaan 1087, 1081 HV Amsterdam, The Netherlands; Yue.dou@vu.nl   
* Correspondence: ciarahovis@gmail.com or hoviscia@msu.edu

![](images/475c99daf8d048d9f4c91ae7342f611fa93ec21d92e7b4e3c7a6e9a63a887ba1.jpg)

- -

Citation: Hovis, C.L.; Dou, Y.;

Herzberger, A.; Liu, J. Through the

Lens of Telecoupling and

Metacoupling: New Perspectives for

Global Sustainability. Sustainability

2021, 13, 2953. https://doi.org/

Received: 2 March 2021

Accepted: 5 March 2021

Published: 9 March 2021

Publisher’s Note: MDPI stays neutral with regard to jurisdictional claims in published maps and institutional affiliations.

![](images/e5acdbc0dc6003a1dc14c181598b231bae67911246d3f0a3901678663ee559b6.jpg)

Copyright: $^ ©$ 2021 by the authors. Licensee MDPI, Basel, Switzerland. This article is an open access article distributed under the terms and conditions of the Creative Commons Attribution (CC BY) license (https:// creativecommons.org/licenses/by/ 4.0/).

# 1. Introduction

Human and natural systems are more interconnected across distances than ever before [1–7]. The movement of people, organisms, material, information, money, and technology at the global scale has enabled the rapid growth of commerce, economies, industries, and the human population. However, it has also intensified and accelerated pollution, deforestation, environmental injustice, conflicts, climate change, and species extinctions. In today’s global economy, resources, goods, and services are increasingly consumed outside of the coupled human and natural systems that produced them [8]. Understanding the consequences of these complex interactions is challenging, but critical for the development of sustainable systems [9]. Overcoming these challenges requires research and policy approaches that not only examine human and natural systems as one, but also integrate the interactions with exogenous systems.

Telecoupling is an umbrella concept that was introduced in 2008 to refer to complex interactions of coupled human and natural systems across distances [10]. Later, the framework was expanded to the metacoupling framework which integrates human-nature interactions within local system (intracoupling), between adjacent systems (pericoupling), and between distant systems (telecoupling) [11]. The articles in this Special Issue utilize one or all three of these concepts and frameworks in their contributions.

# 2. Synopsis of the Contributions

The overarching theme of all 14 contributions to this Special Issue centered on the application of the telecoupling and metacoupling frameworks to tackle sustainability challenges [12]. Several of these articles were presented in sessions at the 2018 GLP-Asia conference (Global Land Program-Asia) [13] and are the outcomes from a workshop and a symposium on telecoupling held at the annual meeting of 2018 US-IALE (US Regional Association of the International Association for Landscape Ecology) [14]. The articles in this Special Issue focus on a broad range of topics and take the form of reviews, qualitative, and quantitative research. The review articles cover the methods that have been used and can be used in telecoupling studies, smallholders and marine telecouplings, and a holistic review of telecoupling studies. The flows in the quantitative articles include movement of tourists, water, information (e.g., citizen science), and different commodities including soybeans and wildlife. The systems studied in this Special Issue expand beyond land systems to include marine protected areas (MPAs), global marine fisheries, and estuarine islands.

The six review articles spanned many topics across both telecoupling and sustainability bodies of literature. Kapsar et al. (2019) reviewed and summarized the body of work referencing “telecoupling” published after the telecoupling framework was introduced in 2013 [12] and identified key points for future telecoupling studies (Contribution 1). Over the first five years, almost 90 articles have applied the telecoupling concept and framework,

with international trade, land use, and tourism being among the many emergent themes. However, these studies all faced similar challenges, one of which being causal relationship quantification which was reported by Carlson et al. In their review, they categorized the methods of causality determination employed in early telecoupling studies and presented a suite of tools for researchers to attribute causality more rigorously in telecoupled systems (Contribution 2). In another methodological review, Paitan and Verburg focused on impact assessment methods and their applicability to telecoupled agricultural supply chains to explicitly account for and distribute both indirect and direct land use change. They found that various trade-offs exist between methods and suggest that hybrid methods may better integrate all elements of telecoupled systems (Contribution 3).

Dou et al. presented a review of 12 case studies of smallholders’ agency that are impacted by not only telecoupled systems (i.e., distant) but also pericoupled systems (i.e., adjacent) (Contribution 4). Their results showed that positive effects were more often associated with strong smallholder agency, with pericoupling playing a role in mitigating negative effects resulting from being a spillover system. Zhao et al. identified and synthesized the trade-offs and synergies of the Sustainable Development Goals (SDGs) in 22 cases of tourism and wildlife translocations, utilizing the metacoupling framework to explicitly address spillover system interactions. They identified 33 instances of synergies and 14 trade-offs across 10 of the SDGs and suggested this method be used to improve sustainability strategies so that synergies can be better leveraged while minimizing tradeoffs (Contribution 5). Finally, Hull et al. demonstrated how the telecoupling framework can be used to better account for and understand the challenges of anthropogenic threats to MPAs and synthesized current methods that can be used to examine these systems (Contribution 6).

Four articles presented qualitative studies from around the world through the lens of telecoupling and metacoupling to illustrate how the frameworks can help tackle sustainability challenges in a variety of contexts. Merz et al. demonstrated the utility of the metacoupling framework applied to the Limpopo River watershed in southern Africa and discussed the importance of integrating anthropogenic drivers of water scarcity (e.g., population growth and agriculture expansion) into the understanding of this transboundary watershed (Contribution 7). Wu et al. presented the case of Chongming Island, an estuarine island in Shanghai, China, as an example of a coupled human and natural system that has a long history of being shaped by metacoupled processes, arguing that it can serve as a model system for coastal sustainability development (Contribution 8). Yang et al. showed how the telecoupling framework can be used to leverage the potential of citizen science in the case of transboundary species–human interactions, specifically the movement of the Monarch Butterfly throughout North America (Contribution 9). Matlhola and Chen presented the case of the donkey-hide trade between Botswana and China and discussed the impacts on livelihoods and policy related to the flow of this domesticated species (Contribution 10).

Finally, four of the articles in the Special Issue conducted quantitative analyses investigating a wide range of metacoupled and telecoupled systems. Herzberger et al. analyzed patterns of soybean, corn, and wheat trade from 1991–2016 in South America and demonstrated the effect telecoupled trade flows can have on intra- and pericouplings within and across different systems. They found that when distant export routes were restricted, pericoupled trade increased, lending insight into how distant demand impacts production and trade at domestic and regional scales (Contribution 11). Carlson et al. assessed and compared fisheries catches from 1950–2014 at multiple scales while accounting for their metacoupling types. In addition to providing a systematic comparison of intranational and international fish flows over 65 years, they also highlighted how metacoupled governance and the management of fisheries can improve food security (Contribution 12).

Andriamihaja et al. presented findings from a social network analysis of agents competing for land in northeastern Madagascar. They concluded that the little overlap or interactions of agents that operate in the economic and environmental domains, increased com-

peting land claims. They also found that distant influences related to vanilla/clove farming, biodiversity conservation, and telecoupled institutions (e.g., REDD+) reinforced land competition in this region (Contribution 13). Chung et al. examined ecosystems services supply and the rise of both international and domestic tourism in Qinghai Province, China. Their results demonstrated how tourism (and tourist spending) accelerated development of tourism infrastructure, thus leading to increased habitat degradation and decreased ecosystems services in the region (Contribution 14).

# 3. Synthesis

In this section we synthesize the articles according to the major components (systems, flows, agents, causes, effects) of the frameworks and research methods.

Systems examined in this Special Issue contribute novel perspectives from different geographic regions, habitats, and scales. In addition to telecoupled systems (i.e., distant interactions), pericoupled systems (adjacent interactions) were a particular focus (Contribution 4, Contribution 5, Contribution 7, Contribution 8, Contribution 11, Contribution 12). A majority of the studies directly examine spillover system dynamics (Contribution 4, Contribution 5, Contribution 7–9, Contribution 11, Contribution 14), responding directly to calls for a better understanding of these typically mired systems [15]. The specific systems studied in this Special Issue spanned four continents (Africa, North America, Asia, and South America) and terrestrial, aquatic, and marine habitats, with one study applying the metacoupling framework to the evolution of an estuarine island over the course of many centuries (Contribution 8). In addition to studies at the international scale, transboundary watershed (Contribution 7) and global (Contribution 12) scales of metacoupled systems were also analyzed.

Flows examined included transfers beyond goods and money (see Table 1). Several studied flows of information (Contribution 4, Contribution 6, Contribution 7, Contribution 9, Contribution 13), technology (Contribution 4, Contribution 7), and waste (Contribution 6, Contribution 8, Contribution 9). In particular, the case study of monarch butterfly migration and citizen science explored the dynamics of animal migration and information flows (Contribution 9). Different and conflicting flows of information were also shown to increase conflict in the case of land competition in Madagascar (Contribution 13). While the trade of animal parts (i.e., tusks, hides, bones) is typically focused on wild species, flows of domesticated species’ parts, like the donkey, were shown to exhibit different effects despite having similar causes as wild species flows (Contribution 10).

Agents involved in this Special Issue included farmers, fishermen, citizens, consumers, traders, governments, NGOs, tourists, animals, industries, and corporations. One specific category of agents given special attention were smallholders (agents whose income is derived from natural resources on small properties) (Contribution 4, Contribution 10). Dou et al. specifically evaluated the ‘agency’ these smallholders possessed in a given system, demonstrating how higher levels of ‘agency’ resulted in more favorable outcomes (Contribution 4). The role of larger agents such as governments and corporations were also assessed (Contribution 11, Contribution 13).

Causes of telecouplings and metacouplings exhibited a wide diversity across the studies and consisted of both environmental and socioeconomic sources. The geopolitical landscape was shown to impact types of metacouplings differently, with restrictions on trade increasing pericoupling in the case of the soybean trade between South American countries and China (Contribution 11). Similarly, trade restrictions on wildlife led to an increase in trade for the species in other countries, resulting in the creation or amplification of a spillover system (Contribution 5). In general, however, attributing causality in complex systems is a common challenge that researchers face. Carlson et al.’s review of causality in telecoupled studies showed that there is a need for greater rigor in methods and present several options (Contribution 2).

Table 1. Flow types and human activities explored in this Special Issue.   

<table><tr><td>Flow Type and/or Human Activity</td><td>Focus</td><td>Articles</td></tr><tr><td rowspan="4">Natural Resource Use</td><td>Water</td><td>Merz et al. (Contribution 7)Wu et al. (Contribution 8)Zhao et al. (Contribution 5)</td></tr><tr><td>Land</td><td>Andriamihaja et al. (Contribution 13)Chung et al. (Contribution 14)Paitan and Verberg (Contribution 3)Wu et al. (Contribution 8)Yang et al. (Contribution 9)</td></tr><tr><td>Waste</td><td>Hull et al. (Contribution 6)Wu et al. (Contribution 8)Yang et al. (Contribution 9)</td></tr><tr><td>Climate Change</td><td>Hull et al. (Contribution 6)Merz et al. (Contribution 7)Wu et al. (Contribution 8)</td></tr><tr><td rowspan="4">Trade</td><td>Agriculture</td><td>Andriamihaja et al. (Contribution 13)Dou et al. (Contribution 4)Herzberger et al. (Contribution 11)Paitan and Verberg (Contribution 3)</td></tr><tr><td>Domesticated spp.</td><td>Matlhola and Chen (Contribution 10)</td></tr><tr><td>Wild Spp.</td><td>Zhao et al. (Contribution 5)</td></tr><tr><td>Fisheries</td><td>Carlson et al. (Contribution 12)Hull et al. (Contribution 6)</td></tr><tr><td rowspan="2">Movement of people</td><td>Tourism</td><td>Dou et al. (Contribution 4)Chung et al. (Contribution 14)Wu et al. (Contribution 8)Zhao et al. (Contribution 5)</td></tr><tr><td>Labor migration</td><td>Dou et al. (Contribution 4)Wu et al. (Contribution 8)</td></tr><tr><td rowspan="3">Information</td><td>Cultural</td><td>Hull et al. (Contribution 6)</td></tr><tr><td>Citizen science</td><td>Yang et al. (Contribution 9)</td></tr><tr><td>Technology</td><td>Dou et al. (Contribution 4)Merz et al. (Contribution 7)</td></tr><tr><td rowspan="2">Investment</td><td>Land</td><td>Dou et al. (Contribution 4)</td></tr><tr><td>Infrastructure</td><td>Chung et al. (Contribution 14)Wu et al. (Contribution 8)</td></tr><tr><td rowspan="3">Movement of wild spp.</td><td>Invasive spp.</td><td>Hull et al. (Contribution 6)Wu et al. (Contribution 8)Zhao et al. (Contribution 5)</td></tr><tr><td>Stocking</td><td>Zhao et al. (Contribution 5)</td></tr><tr><td>Migration</td><td>Hull et al. (Contribution 6)Wu et al. (Contribution 8)Yang et al. (Contribution 9)</td></tr><tr><td rowspan="3">Governance</td><td>SDGs</td><td>Zhao et al. (Contribution 5)</td></tr><tr><td>Trade Sanctions</td><td>Herzberger et al. (Contribution 11)Matthola and Chen (Contribution 10)Zhao et al. (Contribution 5)</td></tr><tr><td>Protected Areas</td><td>Andriamihaja et al. (Contribution 13)Hull et al. (Contribution 6)Zhao et al. (Contribution 5)</td></tr></table>

Effects assessed in the studies were found to be both positive and negative, and impacted various aspects of coupled human and natural systems. Effects often have cascading impacts, which can result in beneficial or harmful outcomes. The effects of tourism and wildlife flows in Zhao et al.’s study presented synergies between different sustainable development goals, but also outlined trade-offs in some cases (Contribution 5). In the study of Chung et al., negative effects on ecosystem services were analyzed due

to incoming tourism flows (Contribution 14). In Andriamihaja et al., the absence of information flows between the local economic and environmental sectors involved in land-use decisions resulted in an increase in land competition, with distant flows also serving to reinforce the conflict (Contribution 13).

Research methods for studying complex metacouplings and telecouplings were explored in this Special Issue in multiple reviews (Contributions 1–3). Kapsar et al. examined how previous telecoupling studies have utilized the framework and found varying degrees of application, concluding that future studies would benefit from explicitly identifying aspects of their system using the shared language of the framework (e.g., agent, sending system, flow, etc.) (Contribution 1). Carlson et al. reviewed the methods for causal attribution of the same studies and presented options for more rigorous methods for future work (Contribution 2). Out of the 89 articles that analyzed telecoupling phenomena, only $6 3 \%$ utilized the terminology of the telecoupling framework (Contribution 1) and a mere $3 \%$ applied rigorous (i.e., qualitative–quantitative) causal analysis methods (Contribution 2). Paitan et al. conducted a comparative review of impact assessment methods and their suitability to be applied to telecoupled agricultural supply chains, concluding that no one method can address all components of telecoupled supply chains and that hybrid methods would be most appropriate going forward (Contribution 3). In addition to the in-depth case studies of individual systems (Contributions 7–10), the methods used in this Special Issue demonstrate the interdisciplinary nature of telecoupling and metacoupling research. Auto regressive integrated moving average models (Contribution 11), panel regression (Contribution 14), correlation (Contribution 12), and social network analysis (Contribution 13) were all successfully utilized to quantify the complex dynamics of the studies presented here.

# 4. Future Directions

This Special Issue is a collection of work that epitomizes the diversity of disciplines, capabilities, and contexts to which the telecoupling and metacoupling frameworks can be applied. While these studies break new ground in the field, there are still many research avenues to explore. We outline some areas for future work below, but it should be noted that this list is by no means exhaustive.

# 4.1. Quantitative Applications

This Special Issue highlights the potential for the applications of the telecoupling and metacoupling frameworks. Several articles applied the frameworks conceptually and proposed a multitude of areas that require more quantitative investigation in those specific contexts (MPAs, domesticated species trade, transboundary watersheds, islands, citizen science). Efforts to analyze these systems using empirical data are needed to further the understanding of these complex systems and provide evidence for policy and decision makers. Additionally, both conceptual and quantitative studies are needed for systems that have been less explored through the lens of telecoupling and metacoupling. Some examples that would greatly contribute to the field include disease spread [16,17], natural disasters [18,19], and social media [20].

# 4.2. Rigor and Consistency

The concepts and frameworks of telecoupling and metacoupling have been utilized by a wide range of researchers and practitioners. The adoption and use of the frameworks’ shared language and components will advance the field even further by facilitating the synthesis and review of studies across a variety of applications. Comprehensive reviews and applications of innovative methods add to the toolbox of researchers, and also encourage consistency in the application of the telecoupling and metacoupling frameworks. Methodological rigor is also an area that received much attention in this issue, with calls for and suggestions of more robust methods of causality attribution and impact assessment, for example.

# 4.3. Variation of System Components

An interesting avenue of inquiry is to consider the variation within system components and the potential impact on the rest of the system. For example, Dou et al. explored how the level of “agency” or involvement of smallholders in the creation of couplings impacted their livelihoods and well-being (Contribution 4). Examples of variation among agents that could also be investigated include power, affiliations, and social connectedness. Flow variation is also under studied, and important insights could be gained by considering things such as the seasonality, magnitude, and duration of flows. The dynamics of flow variation could also have implications for how to understand complex systems. For example, the variation of a flow may augment coupling causes and trigger more complicated effects.

# 4.4. Interactive Effects

Understanding the complex effects of telecoupled and metacoupled systems is an ongoing effort by researchers. While initially the effects of intertwined coupled human and natural systems can be nebulous and obscure in nature, the systematic contextualization provided by the telecoupling and metacoupling frameworks can aid researchers in the identification and characterization of these impacts. In this issue, Zhao et al. demonstrated how the structure of the metacoupling framework aided the identification of synergies and tradeoffs for the SDGs resulting from interactive effects (Contribution 5). Future research should employ the framework to further understand the consequences of interactive effects, their feedbacks, and potential leverage points for intervention.

# 4.5. Integrative Approaches

In addition to those studying distant system interactions, half of the studies in this issue explored system dynamics of focal and adjacent systems. Further integration of these levels of metacoupling will serve to create more complete and comprehensive understandings of these systems and sustainability challenges.

# 5. Conclusions

This Special Issue breaks new ground in both the conceptual and quantitative applications of the telecoupling and metacoupling frameworks. First, many of the studies demonstrated that distinguishing different types of flows and couplings is important. Specifically, pericouplings between adjacent systems deserve adequate consideration as telecouplings between distant systems because adjacent systems can have substantial influences on coupled human and natural systems dynamics. Second, the frameworks can be applied not only in the commonly used flows and systems, e.g., trade and land use systems, but they can also be utilized to study all types of habitats (e.g., terrestrial, marine, estuarine) as well as transfers of information. Third, methodological challenges remain a bottleneck to identify and quantify flows and impacts. More advanced methods to properly attribute the causes and effects associated with flows are needed.

These perspectives on sustainability are essential to developing effective strategies and policies going forward. As more researchers recognize and employ the flexibility of the telecoupling and metacoupling frameworks, sustainability challenges will be more readily understood and potential solutions identified.

# 6. List of Contributions

1. Kapsar, K.E.; Hovis, C.L.; Felipe, R.; Buchholtz, E.K.; Carlson, A.K.; Dou, Y.; Du, Y.; Furumo, P.R. Telecoupling Research: The First Five Years. Sustainability 2019, 1–13, doi:10.3390/su11041033.   
2. Carlson, A.; Zaehringer, J.; Garrett, R.; Felipe Bicudo Silva, R.; Furumo, P.; Raya Rey, A.; Torres, A.; Gon Chung, M.; Li, Y.; Liu, J. Toward Rigorous Telecoupling Causal Attribution: A Systematic Review and Typology. Sustainability 2018, 10, 4426, doi:10.3390/su10124426.

3. Paitan, C.P.; Verburg, P.H. Methods to Assess the Impacts and Indirect Land Use Change Caused by Telecoupled Agricultural Supply Chains: A Review. Sustainability (Switzerland) 2019, 11, doi:10.3390/su11041162.   
4. Dou, Y.; Felipe, R.; Mccord, P.; Zaehringer, J.G.; Yang, H.; Furumo, P.R.; Zhang, J.; Pizarro, J.C.; Liu, J. Understanding How Smallholders Integrated into Pericoupled and Telecoupled Systems. Sustainability (Switzerland) 2020, 1–24, doi:10.3390/su12041596.   
5. Zhao, Z.; Cai, M.; Connor, T.; Chung, M.G.; Liu, J. Metacoupled Tourism and Wildlife Translocations Affect Synergies and Trade-Offs among Sustainable Development Goals across Spillover Systems. Sustainability (Switzerland) 2020, 12, doi:10.3390/su12187677.   
6. Hull, V.; Rivera, C.J.; Wong, C. A Synthesis of Opportunities for Applying the Telecoupling Framework to Marine Protected Areas. Sustainability (Switzerland) 2019, 11, doi:10.3390/su11164450.   
7. Merz, L.; Yang, D.; Hull, V. A Metacoupling Framework for Exploring Transboundary Watershed Management. Sustainability (Switzerland) 2020, 12, doi:10.3390/su12051879.   
8. Wu, S.; Chen, R.; Meadows, M.E. Evolution of an Estuarine Island in the Anthropocene: Complex Dynamics of Chongming Island, Shanghai, P.R. China. Sustainability (Switzerland) 2019, 11, doi:10.3390/su11246921.   
9. Yang, D.; Wan, H.Y.; Huang, T.K.; Liu, J. The Role of Citizen Science in Conservation under the Telecoupling Framework. Sustainability (Switzerland) 2019, 11, doi:10.3390/su11041108.   
10. Matlhola, D.M.; Chen, R. Telecoupling of the Trade of Donkey-Hides between Botswana and China: Challenges and Opportunities. Sustainability (Switzerland) 2020, 12, doi:10.3390/su12051730.   
11. Herzberger, A.; Chung, M.G.; Kapsar, K.; Frank, K.A.; Liu, J. Telecoupled Food Trade Affects Pericoupled Trade and Intracoupled Production. Sustainability (Switzerland) 2019, 11, doi:10.3390/su11102908.   
12. Carlson, A.K.; Taylor, W.W.; Rubenstein, D.I.; Levin, S.A.; Liu, J. Global Marine Fishing across Space and Time. Sustainability (Switzerland) 2020, 12, doi:10.3390/su12114714.   
13. Andriamihaja, O.R.; Metz, F.; Zaehringer, J.G.; Fischer, M.; Messerli, P. Land Competition under Telecoupling: Distant Actors’ Environmental versus Economic Claims on Land in North-Eastern Madagascar. Sustainability (Switzerland) 2019, 11, doi:10.3390/su11030851.   
14. Chung, M.G.; Pan, T.; Zou, X.; Liu, J. Complex Interrelationships between Ecosystem Services Supply and Tourism Demand: General Framework and Evidence from the Origin of Three Asian Rivers. Sustainability (Switzerland) 2018, 10, doi:10.3390/su10124576.

Author Contributions: Conceptualization, J.L., C.L.H., Y.D., A.H.; writing—original draft preparation, C.L.H.; writing—review and editing, C.L.H., Y.D., A.H., J.L.; supervision, J.L.; All authors have read and agreed to the published version of the manuscript.

Funding: We are grateful for financial support from the National Science Foundation (grant #1924111, 1518518, 1340812), Rachel Carson Chair in Sustainability at Michigan State University, and Michigan AgBioResearch.

Acknowledgments: We thank the paper contributors to this Special Issue as well as reviewers and the editorial staff at this journal for their time and efforts in reviewing, improving and publishing this set of articles.

Conflicts of Interest: The authors declare no conflict of interest.

