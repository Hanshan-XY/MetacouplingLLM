# Telecoupling China_s City-Level Water Withdrawal with Distant Consumption

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:52:07.517627+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Li et al. - 2023 - Telecoupling China_s City-Level Water Withdrawal with Distant Consumption.pdf
- Year: unknown
- DOI: 10.1021/acs.est.3c00757
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper analyzes how consumption in distant places drives water withdrawal in Chinese cities, using a telecoupling perspective. The authors introduce a producer-centered indicator called telecoupled water withdrawal (TWW), defined as water extracted in a city to satisfy final demand in other Chinese regions and foreign countries.

The study focuses on mainland China (excluding Tibet) and covers 350 prefecture-level cities in 2015. It embeds a detailed multiregional input-output (MRIO) table for 31 Chinese provinces into a global MRIO (Eora26) by harmonizing both to 20 economic sectors. City-level water withdrawal by sector is compiled from multiple Chinese statistical yearbooks and water bulletins, then allocated across sectors using provincial water intensity data. An environmentally extended nested MRIO model traces how final demand in 19 major foreign economies and other Chinese provinces induces water withdrawal in each city and sector.

Nationally, about 38 percent of Chinas total water withdrawal is driven by nonlocal domestic consumption and 11 percent by foreign consumption; together these make up TWW. Roughly one fifth of TWW is linked to foreign demand, with the United States, Hong Kong, Japan, and South Korea as leading drivers. High-TWW cities are concentrated in the southeast coastal belt and the northwest, especially Xinjiang. Northwestern and northeastern cities account for a large share of agricultural TWW while contributing relatively little to GDP, reflecting specialization in low-value, water-intensive crops such as cotton. In contrast, affluent coastal cities like Beijing, Shanghai, Shenzhen, and Guangzhou generate high value with comparatively modest TWW, having outsourced water-heavy activities.

Sectorally, agriculture dominates TWW, especially for domestic demand, while electricity and energy supply and selected manufacturing industries (textiles, chemicals, equipment) are key for trade-related TWW. Case studies of the Beijing-Tianjin-Hebei, Yangtze River Delta, and Pearl River Delta agglomerations highlight how global production networks concentrate secondary-industry TWW in coastal manufacturing hubs.

The work is explicitly framed within telecoupling/metacoupling, showing how domestic and international trade redistribute water burdens among cities and suggesting the need for shared responsibility, ecological compensation, and coordinated management of water, energy, and emissions.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via domestic and international trade; limited explicit intra and peri analysis.

### Intracoupling
#### Systems
- Individual Chinese cities as coupled human water systems
- Tarim River Basin cotton production cities
- Megacities with service dominated economies
#### Flows
- Local water withdrawal for agriculture and industry
- Domestic water use for households and services
- Water use for urban electricity and heat production
#### Agents
- City governments managing water and economic planning
- Local industries and farms using water
- Urban households and service providers
#### Causes
- Mismatch of local water availability and demand
- Urbanization and sectoral economic shifts
- City scale policy decisions on industry location
#### Effects
- High water pressure in arid inland cities
- Low water use but high value added in megacities
- Local ecological risks from water intensive crops

### Pericoupling
#### Systems
- Neighboring Chinese cities within same province
- Interlinked cities inside major urban agglomerations
- Adjacent provinces exchanging water intensive products
#### Flows
- Intercity trade of agricultural goods and electricity
- Intra agglomeration manufacturing supply chains
- Regional virtual water embodied in domestic trade
#### Agents
- Provincial governments coordinating development
- Firms in Yangtze and Pearl River Deltas
- Logistics and wholesale companies
#### Causes
- Regional specialization in manufacturing and services
- Concentration of power plants in coastal clusters
- Domestic demand from richer coastal regions
#### Effects
- Northwest and Northeast cities exporting water intensive goods
- Coastal agglomerations importing virtual water
- Regional inequality in water use versus GDP

### Telecoupling
#### Systems
- Chinese cities as water withdrawing sending systems
- Foreign consuming countries like United States and Japan
- Hong Kong as trade gateway reexport hub
#### Flows
- Telecoupled water withdrawal driven by foreign final demand
- Virtual water embedded in exported agricultural and industrial products
- Sector specific TWW from electricity, chemicals, textiles
#### Agents
- Foreign consumers and firms importing Chinese goods
- Chinese exporters in agriculture and manufacturing
- National government shaping trade and dual circulation policy
#### Causes
- Globalized supply chains separating production and consumption
- Export oriented development strategy of China
- Demand from major economies and G20 partners
#### Effects
- High TWW in water scarce Xinjiang cities for low value exports
- Coastal manufacturing hubs bearing foreign driven TWW
- Unequal global distribution of water burdens across cities

### Cross-Coupling Interactions
- Domestic and international trade jointly drive city TWW, with domestic demand dominating overall pressure.
- Economic upgrading in coastal megacities shifts water intensive production to inland agricultural regions.
- Climate and carbon policies may unintentionally increase TWW via energy and industry transitions.

### Research Gaps or Limitations
- Does not integrate local water availability or city level water boundaries into TWW assessment.
- Relies on simplifying assumptions for provincial export allocation within global MRIO.
- Telecoupling of other environmental dimensions beyond water is noted but not quantified.

### Search Keywords
- telecoupled water withdrawal China cities MRIO
- city level virtual water trade inequality
- foreign and domestic drivers of water use

### Extraction Confidence
high
