# Telecoupling in urban water systems an examination of Beijing_s imported water supply

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:40:25.119620+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Deines et al. - 2016 - Telecoupling in urban water systems an examination of Beijing_s imported water supply.pdf
- Year: unknown
- DOI: 10.1080/02508060.2015.1113485
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This article examines how the emerging telecoupling framework can be applied to urban water systems, using Beijing, China, as a case study. Telecoupling refers to socio-environmental interactions linking distant human-natural systems. The study focuses on three ways Beijing imports water or water-related services from outside its basin: large inter-basin transfers, virtual water trade embedded in goods, and payments for ecosystem services (PES).

Geographically, the paper covers Beijing and several connected regions: the Han River basin in central China supplying the South-to-North Water Transfer Project (SNWTP), upstream areas in Hebei province that feed the Miyun Reservoir, and provinces across China that provide virtual water through trade. The authors synthesize existing literature and secondary data rather than collecting new field data. They map telecoupling elements (sending/receiving/spillover systems, flows, agents, causes, effects), compile water-volume estimates from multiple studies, and assess water risk using the WRI Aqueduct global dataset.

Key findings are that imported water and virtual water play a dominant role in Beijing’s water balance. By about 2020, the SNWTP middle route is projected to supply more than two-fifths of Beijing’s mean renewable physical water. The Miyun PES scheme adds only a small fraction of that volume but is highly cost-effective and improves both water quality and upstream livelihoods. Average virtual water imports in the 2000s are similar to, or larger than, Beijing’s local renewable supply and are growing rapidly.

Water-risk analysis shows that all major source regions have lower composite water risk than Beijing itself, meaning telecoupling partially reduces the city’s exposure but does not eliminate vulnerability. The study is explicitly about telecoupling/metacoupling, demonstrating that the telecoupling framework helps compare infrastructure-based transfers, market-driven virtual water flows, and PES, and exposes research gaps on impacts in sending and spillover systems and long-term sustainability of relying on distant water.

## Structured Metacoupling Extraction

### Coupling Classification
- Primarily telecoupling via distant physical and virtual water, with some peri-scale PES interactions

### Intracoupling
#### Systems
- Beijing municipality urban and peri-urban water system
- Local Hai River basin surface and groundwater within Beijing
#### Flows
- Local surface water withdrawals to reservoirs and treatment plants
- Groundwater pumping for municipal, industrial, agricultural use
- Recycled wastewater within Beijing distribution
#### Agents
- Beijing Water Bureau and municipal government
- Local households, industries, farmers
- Urban water utilities and infrastructure operators
#### Causes
- Rapid population growth and land-use change within Beijing
- Declining local surface water quantity and quality
- Historical over-extraction of groundwater causing subsidence
#### Effects
- Severe local water scarcity and high water risk index
- Groundwater table decline and land subsidence
- Shift from agriculture toward urban, industrial water use

### Pericoupling
#### Systems
- Beijing and neighboring Hebei upstream Miyun watershed
- Beijing and nearby Hebei reservoirs for short-distance transfers
#### Flows
- Short-range reservoir transfers from Hebei to Beijing
- PES-driven changes in runoff and nutrient export to Miyun
- Financial compensation payments from Beijing to Hebei farmers
#### Agents
- Beijing, Chengde, Zhangjiakou municipal governments
- Upstream Hebei farmers participating in PES
- Regional water management and agricultural agencies
#### Causes
- Decline of inflows and eutrophication in Miyun Reservoir
- Loss of Guanting Reservoir as potable source
- Need for cost-effective regional water quality protection
#### Effects
- Small but positive increase in Miyun inflow volume
- Improved reservoir nutrient status and drinking-water protection
- Altered Hebei livelihoods and fertilizer application patterns

### Telecoupling
#### Systems
- Beijing and Han River Danjiangkou Reservoir via SNWTP middle route
- Beijing and multiple Chinese provinces supplying virtual water
- Beijing and potential spillover areas along transfer canals and trade routes
#### Flows
- Long-distance inter-basin transfer of Yangtze tributary water
- Virtual water embedded in traded food and industrial goods
- Pollutants, biota, and greenhouse gases associated with transfers and trade
#### Agents
- Chinese central government planning and financing SNWTP
- Provincial governments, firms, traders enabling virtual water flows
- Displaced residents and resettlement authorities near Danjiangkou
#### Causes
- Spatial mismatch between southern water abundance and northern demand
- Globalization, dietary change, and economic specialization
- National strategies to reduce Beijing water shortage and risk
#### Effects
- Beijing gains large additional physical and virtual water supplies
- Sending basins experience reduced flows and resettlement impacts
- Spillover ecosystems face eutrophication, salinization, invasive species risks

### Cross-Coupling Interactions
- SNWTP imports may ease pressure on local groundwater and nearby agricultural users
- Virtual water imports interact with domestic agriculture decline around Beijing
- PES, transfers, and trade jointly diversify Beijing water portfolio yet shift risks outward

### Research Gaps or Limitations
- Limited quantification of spillover system impacts for PES and virtual water trade
- Substantial uncertainty and methodological divergence in virtual water estimates
- Need dynamic vulnerability analyses including feedbacks and changing trade patterns

### Search Keywords
- Beijing telecoupling urban water virtual water SNWTP PES Miyun
- inter-basin transfer South-to-North Water Transfer Project Danjiangkou
- Hebei Paddy Land to Dry Land program water risk Aqueduct

### Extraction Confidence
high
