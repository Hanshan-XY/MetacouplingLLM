# Progress and prospects of Geography in promoting the United Nations Sustainable Development Goals A

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:20:35.393483+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Zhao et al. - 2024 - Progress and prospects of Geography in promoting the United Nations Sustainable Development Goals A.pdf
- Year: unknown
- DOI: 10.11821/dlxb202411001
- OA status: unknown
- License: none recorded
- Category: Journal Articles\Review\Metacoupling
- Closed-access reason: no license info, oa_status=unknown

## Copyright-Safe Summary
This review examines how geography as a discipline contributes to understanding and implementing the UN Sustainable Development Goals (SDGs), and proposes a theoretical framework termed sustainable geography.

The study is global in scope but grounded largely in Chinese scholarship and initiatives. It situates geography within the Earth surface system and human-environment system, emphasizing natural geography, human geography, and geospatial information science. Methods are those of a narrative, theory-oriented review: synthesizing concepts, typologies, case examples, and indicator practices rather than conducting new empirical analyses.

The authors organize geography’s support for the SDGs around four interconnected components of a sustainable geography framework: (1) cascading elements within human-environment systems, captured by pattern-process-service-sustainability and IPBES nature’s contributions to people; (2) system dynamics, drawing on social-ecological resilience, regime shifts, planetary boundaries, and safe and just space; (3) spatial coupling among systems, where the metacoupling framework (intracoupling, pericoupling, telecoupling) is central for tracing flows, feedbacks, and spillovers across sending, receiving, and spillover systems; and (4) system regulation for SDGs via a Classification-Coordination-Collaboration (3C) approach that structures prioritization, multi-level governance, and stakeholder cooperation.

They review advances in: multi-source data and Earth observation for SDG monitoring; localization and multi-scale adaptation of SDG indicator systems; spatial and network analysis of synergies and trade-offs among goals; and scenario-based exploration of transformative SDG pathways. Key thematic application domains include climate and ecosystem change (SDGs 13-15), food-energy-water-land nexuses (2, 6-7, 12), regional development, urbanization and infrastructure (1, 8-11), human well-being and governance (3-5, 16-17), and dynamic SDG data systems.

Metacoupling/telecoupling is a core part of the argument: the paper explicitly adopts the metacoupling framework to analyze cross-scale flows (e.g., trade, virtual water, energy transfers) linking distant human-environment systems, and treats this as a pillar of sustainable geography for supporting global SDG implementation.

## Structured Metacoupling Extraction

### Coupling Classification
- Explicitly develops metacoupling with intra, peri, telecoupling for SDG-oriented human–nature systems.

### Intracoupling
#### Systems
- Single regional human–nature system within a country or basin
- Local social–ecological system for climate–ecosystem management
- Urban or rural development system within national territory
#### Flows
- Internal energy, water, carbon and material cycles
- Local information and governance signals within one region
- Intra-regional labor, capital and service movements
#### Agents
- National and local governments and planning agencies
- Firms, farmers and urban residents
- Scientific institutions and SDG data providers
#### Causes
- Climate change pressures and ecological degradation
- Urbanization, industrialization and land use change
- National poverty reduction and development strategies
#### Effects
- Changes in local ecosystem services and biodiversity
- Shifts in poverty, employment and inequality
- Progress toward localized SDG indicators

### Pericoupling
#### Systems
- Neighboring provinces or river basins within one country
- Adjacent urban–rural or metropolitan regions
- Cross-border regions with shared resources
#### Flows
- Interregional water diversion and energy transfer projects
- Short-distance trade of food, energy and construction materials
- Migration and commuting between neighboring regions
#### Agents
- Regional governments coordinating infrastructure and planning
- Utility companies managing interregional grids and canals
- Interprovincial or cross-border coordination bodies
#### Causes
- Spatial inequality in resources and development levels
- Infrastructure expansion and regional integration policies
- Need to balance food–energy–water nexus regionally
#### Effects
- Redistribution of water, energy and environmental burdens
- Regional poverty reduction and employment shifts
- Spatial spillovers in SDG progress and trade-offs

### Telecoupling
#### Systems
- Distant sending and receiving countries in global trade
- Spillover regions affected by external supply chains
- Global human–nature system constrained by planetary boundaries
#### Flows
- Long-distance trade of food, energy and manufactured goods
- Embodied water, carbon and land in traded commodities
- Transboundary information, finance and technology transfer
#### Agents
- National governments and international organizations
- Multinational corporations and global supply chain actors
- Global scientific networks and SDG partnerships
#### Causes
- Economic globalization and uneven development patterns
- Rising global demand for food, energy and materials
- Climate policies and environmental regulations across borders
#### Effects
- Distant ecological degradation and biodiversity loss
- Shifts in global inequality and development gaps
- Cross-border impacts on multiple SDGs via spillovers

### Cross-Coupling Interactions
- Metacoupling links intra, peri and telecoupling through element flows and SDG trade-offs.
- Food–energy–water nexus connects local resource use with regional and global supply chains.
- 3C framework coordinates national and international actions across coupled human–nature systems.

### Research Gaps or Limitations
- Limited multi-scale SDG decision models integrating metacoupling dynamics.
- Data scarcity and inconsistent SDG indicators at subnational and cross-border scales.
- Insufficient quantification of distant spillover effects in SDG assessment frameworks.

### Search Keywords
- metacoupling intra pericoupling telecoupling geography SDGs
- sustainable geography human–nature system coupling
- food energy water nexus planetary boundaries safe and just space

### Extraction Confidence
high
