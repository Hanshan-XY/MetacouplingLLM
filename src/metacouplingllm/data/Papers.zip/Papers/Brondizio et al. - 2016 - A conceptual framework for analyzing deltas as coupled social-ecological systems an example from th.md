# A conceptual framework for analyzing deltas as coupled social-ecological systems an example from th

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:29:29.350906+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Brondizio et al. - 2016 - A conceptual framework for analyzing deltas as coupled social-ecological systems an example from th.pdf
- Year: unknown
- DOI: 10.1007/s11625-016-0368-2
- OA status: closed
- License: none recorded
- Category: Journal Articles\Conceptual\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper develops and illustrates a problem-oriented conceptual framework for studying river deltas as coupled social-ecological systems, with the Amazon Estuary-Delta (Amazon Delta) as the main example. The geographic focus is the estuary-delta region at the mouth of the Amazon and Tocantins-Araguaia river basins, including Marajo Island and associated municipalities in the Brazilian states of Para and Amapa.

The authors integrate and extend existing social-ecological and institutional analysis frameworks, particularly Ostroms SES and IAD approaches, vulnerability analysis, and the telecoupling concept. They propose two linked components. First, they define delta SESs using five interrelated subsystems: socio-economic structures, governance arrangements, ecosystems and resource use, topographic-hydrological conditions, and oceanic-climate dynamics. These are examined together with six types of telecoupling and interdependence: socio-demographic, economic, governance, ecological, material, and climatic-hydrological linkages between local and distant places.

Second, they outline a stepwise procedure to analyze delta sustainability problems as nested collective action situations at local, delta-wide, and basin scales. Steps include identifying a focal problem, mapping cross-scale connections, defining appropriate SES boundaries, characterizing actors, rules, and interactions in each action situation, and evaluating outcomes using criteria such as equity, resilience, and legitimacy. A geospatial database (Amazon Delta-DAT) supports this by integrating social and biophysical data across spatial and temporal scales.

Using the Amazon Delta, the authors delineate a core SES and then apply the framework to an illustrative case: impacts of urban expansion and pollution on small-scale fisheries in the southern channel. They show how upstream cities, dams, industries, and changing rainfall patterns interact with local fishing practices and habitats, generating multi-level collective action and governance challenges.

The study is explicitly about telecoupling and closely related ideas (functional interdependence, cross-scale institutional fit), offering a structured way to diagnose how distant drivers and flows shape sustainability dilemmas in deltas and to enable comparison across delta systems.

## Structured Metacoupling Extraction

### Coupling Classification
- Conceptual SES framework for deltas with explicit telecoupling dimensions and cross-scale sustainability problems

### Intracoupling
#### Systems
- Amazon Estuary-Delta core SES of municipalities, communities, and local ecosystems
- Urban centers Belem and Macapa linked with surrounding rural floodplains
- Local fishing grounds, mangroves, floodplain farms within delta channels
#### Flows
- Local fishing and shrimp harvests between riverine communities and nearby towns
- Household migration and commuting between rural communities and nearby cities
- Untreated sewage, solid waste, and small industrial discharges into local rivers
#### Agents
- Riverine small-scale fishers and farming households
- Municipal governments and local planners in delta cities
- Local industries, mining plants, and service providers
#### Causes
- Rapid urban growth without sanitation infrastructure in delta municipalities
- Historical land concentration and unequal access to elevated settlement sites
- Increased use of modern fishing gear and motorized boats
#### Effects
- Degraded water quality affecting fisheries and human health
- Reduced local fish availability and higher market prices
- Local habitat loss along riverbanks and floodplains

### Pericoupling
#### Systems
- Northern and southern Amazon delta channels and adjacent coastal zones
- Delta municipalities and immediately upstream Tocantins-Araguaia sub-basins
- Amazon delta coast and neighboring Guianas coastal belt
#### Flows
- Sediment and nutrients shaping nearby coasts and sandy banks
- Regional trade in acai fruit, fish, and agricultural products
- Short-distance migration among municipalities and coastal settlements
#### Agents
- State governments of Para and Amapa
- Regional traders, port operators, and transport companies
- Protected area managers and coastal resource authorities
#### Causes
- Regional infrastructure expansion including ports, roads, and dams
- Growth of acai-based and resource-export economies
- Regional coastal processes of tides, waves, and sediment dynamics
#### Effects
- Shifting fishing grounds and coastal morphologies near communities
- Uneven economic benefits and persistent regional poverty
- Changing exposure to coastal flooding and erosion

### Telecoupling
#### Systems
- Amazon Estuary-Delta linked with distant Amazon and Tocantins watersheds
- Amazon delta and international commodity and seafood markets
- Amazon sediment plume influencing Guianas coasts and Orinoco delta
#### Flows
- Upstream river discharge, sediments, and pollutants reaching delta fisheries
- Global demand for acai, forest products, and shrimp
- Longshore transport of Amazon mud towards neighboring countries
#### Agents
- Upstream cities, industries, and dam operators outside core delta
- National and international traders, investors, and consumers
- International climate and river-basin governance actors
#### Causes
- External climatic variability including ENSO and sea-level changes
- Upstream land use, mining, and urbanization in large basins
- Globalized supply chains driving resource extraction and port development
#### Effects
- Teleconnected pollution and habitat changes impacting downstream small-scale fishers
- Altered flood regimes and sediment loads after large dams
- Cross-border coastal ecological impacts along Guianas and Orinoco

### Cross-Coupling Interactions
- Telecoupled upstream pollution intensifies local commons dilemmas in delta fisheries
- Institutional mismatches between basin-scale governance and local SES boundaries
- Functional interdependence of biophysical flows and multi-level social institutions

### Research Gaps or Limitations
- Limited empirical knowledge of combined climate, sea-level, and infrastructure impacts on Amazon delta SES
- Scarce integration of fishers, urban planners, and industrial actors in shared governance
- Framework still conceptual, requiring operational indicators and comparative delta applications

### Search Keywords
- Amazon River Delta social ecological system telecoupling governance
- delta sustainability action situations fisheries pollution urban growth
- institutional fit functional interdependence Ostrom SES framework

### Extraction Confidence
high
