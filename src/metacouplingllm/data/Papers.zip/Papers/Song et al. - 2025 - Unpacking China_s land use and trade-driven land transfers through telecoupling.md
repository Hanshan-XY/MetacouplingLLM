# Unpacking China’s land use and trade-driven land transfers through telecoupling

![](images/3b346ab0ae680973c70724ce4f58fa1192001bd27d7a144c22f6a72ef1e8f587.jpg)

Yaya Song $\mathrm { a } , \mathrm { b } _ { \oplus }$ , Xianjin Huang a,b,* , Qianjing Li c , Xinxian Qi a,b , Rui Sun a , Mingshu Wang d,** D

a School of Geography and Ocean Science, Nanjing University, Nanjing 210023, China   
b The Key Laboratory of Carbon Neutrality and Territory Optimization, Ministry of Natural Resources, Nanjing 210023, China   
c International Institute for Earth System Science, Nanjing University, Nanjing 210023, China   
d School of Geographical and Earth Sciences, University of Glasgow, Glasgow G12 8QQ, United Kingdom

# A R T I C L E I N F O

# Keywords:

Telecoupling

Land footprint

Virtual land

Driving factors

Multi-regional input-output

Structural decomposition analysis

# A B S T R A C T

Understanding land use dynamics through the lens of interregional interactions is critical to achieving sustainable territorial development in an increasingly interconnected world. However, most existing studies remain confined to administrative units, failing to systematically account for the spatial decoupling between land consumption and production. This study integrates a multi-regional input-output (MRIO) model with structural decomposition analysis (SDA) to investigate the spatiotemporal characteristics and driving forces of land use in China from 2002 to 2017. By constructing a detailed mapping between economic sectors and land use categories, we trace the intensity, direction, and scale of land flows embedded in domestic trade. The share of interregional land transfers rose markedly from $2 2 . 3 \%$ in 2002 to $5 7 . 4 \%$ in 2017, revealing a growing reliance on extra-local land resources. The results demonstrate that while China’s total land footprint expanded substantially, disparities in land use efficiency and regional dependency have intensified. Coastal provinces increasingly depend on external land through consumption-driven demand, while inland regions serve as net land exporters via resourceand land-intensive production. Technological improvements on the supply side significantly reduced land-use intensity; however, they were outweighed by the expansionary effects of economic growth and structural shifts in final demand. This study contributes methodologically by enhancing the telecoupling framework to incorporate virtual land flows within domestic trade, thereby providing a more nuanced understanding of land use dynamics that extend beyond administrative boundaries. The findings offer policy insights into optimizing the spatial allocation of land resources and guiding differentiated land governance in China and other rapidly urbanizing economies.

# 1. Introduction

Land use is a central issue in global environmental change and sustainable development research due to its profound implications for ecosystem services, resource consumption, and carbon emissions (Cabernard et al., 2024; Houghton and Castanho, 2023; Jin et al., 2019a, 2021). Over recent decades, human activities such as economic growth and rapid urbanization have significantly transformed land-use patterns in both developed and developing countries (Prabhakar, 2021; Song et al., 2018; Winkler et al., 2021).

In an increasingly interconnected world, however, land-use change is no longer confined to local drivers. Instead, it is increasingly influenced

by distant demands embedded in global production networks and interregional trade. Affluent economies, for example, often externalize their land demands by importing land-intensive goods and services from less developed regions (Cheng et al., 2023; Meyfroidt et al., 2020; Munroe et al., 2019; Yu et al., 2013). This spatial decoupling of land consumption from production frequently leads to asymmetric ecological exchanges and environmental burdens (Dorninger et al., 2021a; Hickel et al., 2022), exacerbating deforestation (Pendrill et al., 2019), soil degradation (Zhai et al., 2024), and biodiversity loss (Kastner et al., 2021) in exporting regions. As such, to fully capture the complexities of land use, it is essential to move beyond localized perspectives and adopt integrated, spatially explicit frameworks.

The telecoupling framework, proposed by Liu et al. (2013), provides a robust conceptual lens for analyzing socio-ecological interactions among distant systems (Liu, 2023). Telecoupling has been applied across diverse research domains, including land use change (Bai et al., 2024; Ma et al., 2019; Seto et al., 2012), food systems (Eakin et al., 2017), and biodiversity conservation (Yang et al., 2023a). However, its application in land use research at subnational scales remains relatively limited. Most existing telecoupling studies employ qualitative case studies or focus predominantly on international trade scenarios (Wang et al., 2024b), with few systematically integrating detailed economic data and diverse land-use types. Even though some studies combine telecoupling concepts with input-output models to explore virtual land (Cheng et al., 2023; Wang et al., 2024a), they rarely differentiate land use by specific ecological and economic functions.

Previous studies have examined international telecoupled land systems, demonstrating how consumption in economically advanced regions drives land pressures in less-developed areas (Arto et al., 2022; Li et al., 2022; Tramberend et al., 2019). Although insightful, these studies overlook significant domestic telecoupling processes within large, spatially heterogeneous countries such as China, India, or the United States. In China-specific research, studies employing multi-regional input–output (MRIO) analyses have explored land-use dynamics (Chuai et al., 2021; Guo et al., 2020a, 2020b; Tian et al., 2019; Wang and Wang, 2022). However, they generally focus on aggregated land categories, such as cropland or urban built-up land, treating land as a homogeneous resource. This simplification overlooks the distinct spatial distribution and economic roles of various land types (e.g., forestland, grassland, mining land, and aquaculture areas). Moreover, existing analyses primarily concentrate on production-side or local demand drivers, seldom addressing how interregional interactions and spatially decoupled production-consumption systems shape regional land footprints within national borders.

As the world’s most populous nation and the second-largest economy, China provides an ideal context for examining domestic telecoupling mechanisms. Driven by rapid urbanization, industrialization, and shifting consumption patterns, China’s demand for land resources has significantly increased, placing intense pressure on regional ecosystems (Wu et al., 2024). Land use patterns in China exhibit substantial spatial variations influenced by distinct economic development stages, industrial structures, and local policy contexts (Ning et al., 2018). The profound shifts in China’s production and consumption systems, such as the northward concentration of staple crop production (Qi et al., 2023), further underline the necessity of understanding interregional land linkages.

Our central hypothesis is that interregional interactions significantly reshape the spatial configuration of China’s land resources, with regional land use increasingly driven by spatially decoupled production and consumption systems. Specifically, we propose that the spatial reallocation of final demand is a critical yet underexplored factor influencing regional land-use patterns and their associated environmental pressures.

To address these research gaps, this study employs an MRIO-based framework combined with structural decomposition analysis (SDA) to systematically quantify the spatiotemporal dynamics and driving forces of China’s domestic land use under a telecoupling perspective. Specifically, this study aims to address the following research questions:

(1) From a telecoupling perspective, what are the spatiotemporal patterns and characteristics of various land use types associated with China’s interregional interactions?   
(2) From both production and consumption perspectives, what are the key drivers of regional land use changes, and how do these driving forces differ across regions of varying scales and economic development levels?   
(3) How can the telecoupling framework enhance the precision and cross-regional coordination of land governance in China, with broader implications for international policy?

The primary contributions of this study to the existing literature are threefold. First, it systematically applies the telecoupling framework to comprehensively analyze multiple land use types, including cropland, forestland, grassland, mining land, and aquaculture land, thus significantly advancing the specificity and granularity of telecoupling research. Second, it develops a refined classification system explicitly linking economic sectors to specific land use categories, enabling a more detailed exploration of sector-specific land use dynamics and their spatial distribution. Third, it adopts a comprehensive, multidimensional structural decomposition analysis that incorporates both productionand consumption-side factors, thereby providing deeper insights into the complex spatial mechanisms driving regional land-use redistribution within China.

# 2. Theoretical framework

This study proposes a theoretical framework to reconceptualize the spatiotemporal dynamics and driving forces of land use from a telecoupling perspective (Fig. 1). The telecoupling framework emphasizes the complex socio-ecological interactions among geographically distant regions, which are linked by resource flows, commodity trade, and information exchanges. For example, a country’s demand for agricultural products can significantly alter land use patterns and ecosystem structures in distant regions (Dorninger et al., 2021b; Kan et al., 2023).

We operationalize this concept by quantifying interregional land linkages through virtual or embodied land use embedded within commodity flows (Hubacek and Feng, 2016). Virtual land use is defined as the land area utilized in the production processes of traded goods (Würtenberger et al., 2006). Correspondingly, the "land footprint" reflects the total direct and indirect land area associated with the entire supply chain of a given product or service (Bruckner et al., 2015).

In our conceptualization, China serves as the national-level sending system, while other countries represent receiving systems in international contexts. At the domestic level, each province simultaneously functions as both a sender and receiver, exporting and importing virtual land through interprovincial trade. Consequently, the land footprint of each province is calculated by combining the local direct land use, virtual land inflows from other provinces, and virtual land outflows to other provinces.

Therefore, the dynamics of land footprint are shaped by multidimensional drivers related to both production (supply-side) and consumption (demand-side), influencing the trends and spatial patterns of regional land demand. The specific driving mechanisms can be categorized into two primary dimensions:

# Supply-side Drivers:

• Product supply sources: Changes in the geographical sourcing of commodities significantly shape regional land footprints. For instance, shifts from sourcing commodities in regions with higher land-use efficiency to those with lower efficiency typically increase regional land demand, primarily driven by fluctuations in production costs, market dynamics, or policy incentives (Jin et al., 2019a, 2019b; Liu et al., 2010).   
• Production structure: Alterations in regional industrial structures directly influence the scale and type of land utilization (Fu et al., 2021). For example, structural transformations, such as transitioning from an agricultural to a manufacturing-based economy, typically decrease agricultural land requirements but concurrently raise demands for industrial and built-up land, thereby affecting spatial land allocation.   
• Land use efficiency: Technological progress and improved manage ment practices enhance land productivity, thereby alleviating overall land-use pressures and reshaping spatial distribution patterns.

# Demand-side Drivers:

![](images/5088e8b9fe0c2f2b19362d1662429953a40ac761eb2cb2811a98a99641fb8a19.jpg)

![](images/2b0ec5775c32bb26cc41a95e978710ecfd18ec16f67ab07a4b03332716b58e80.jpg)  
Fig. 1. Conceptual framework for analyzing land use dynamics from a telecoupling perspective. Note: Labels in (a) denote provincial abbreviations, as listed in Table S1.

![](images/a2178f191c0e7944b747571c8733461b3ebd21c378e7e9347fef4c9fb65633f9.jpg)  
Fig. 2. Mapping between national economic sectors and corresponding land use types. Note: The codes, and names of the 45 economic sectors are provided in Supplementary Table S2.

• Population size: Population growth directly increases demands for residential land, public infrastructure, and agricultural resources, whereas declining populations correspondingly reduce these demands.   
• Economic development: Economic expansion tends to elevate the overall demand for land resources, particularly by intensifying the consumption of land-intensive commodities.   
• Consumption patterns: Changes in consumer preferences have a significant impact on land demand. For instance, increased demand for land-intensive dietary products such as meat indirectly raises agricultural land requirements (Lauk et al., 2022; Poore and Nemecek, 2018).   
• Residential land requirements: The rising demand for per capita housing space further intensifies urban and peri-urban land demands.

# 3. Materials and methods

# 3.1. Methods

# 3.1.1. Mapping of national economic sectors to land use data

To accurately link economic activity with land occupation, we developed a sector–land mapping framework (Fig. 2) that systematically illustrates one-to-one, one-to-many, and many-to-one relationships between economic sectors and land use categories. This mapping is based on China’s national land classification standards and builds upon methodologies from previous studies (Chen et al., 2019; Wang and Wang, 2022; Yu et al., 2013). The national economic sectors (S01–S45) are matched to corresponding land types using a combination of expert judgment, historical land transaction data, and proportional allocation based on employment.

In the mining, manufacturing, and service sectors, multiple subsectors are often mapped to a single land use category. For mining, manufacturing, and commercial service industries, the mapping is determined by each sector’s cumulative share in land market transactions since 2000. This approach captures the historical patterns of sectoral land occupation. For other service sectors (S40–S45), where detailed land transaction data are limited, we allocated land use based on the proportion of employment in each sector (Chen et al., 2019; Wang and Wang, 2022).

For Sector S05, which includes agricultural, forestry, animal husbandry, and fishery-related services, no significant land occupation could be identified due to a lack of spatially explicit data and the inherently minimal land requirements of these activities. Therefore, the land use for S05 was set to zero.

Sector S30, which represents the construction industry, encompasses activities such as surveying, design, installation, and building repair, as defined by the national industrial classification standard (GB/T 4754–2017). Because these activities are typically not associated with permanent land occupation (e.g., arable or forest land), the sector was mapped to commercial service land to reflect the spatial footprint of construction enterprises and operational facilities.

Although several assumptions were necessary due to data constraints, the overall mapping framework enhances conceptual clarity, improves logical consistency, and accurately reflects the functional roles of different economic sectors in land occupation. This framework also provides a replicable basis for integrating land-use dimensions into broader environmental footprint accounting systems.

# 3.1.2. Multi-regional input-output analysis

The MRIO model is commonly used to calculate the virtual resources and environmental elements embedded in trade (Liang et al., 2023). The underlying principle of the MRIO model is as follows:

The total output $X$ of each region and industry is determined as a response to the final demand vector Y:

$$
\mathrm {X} = (I - A) ^ {- 1} \mathrm {Y} \tag {1}
$$

where I represent the identity matrix, and A denotes the matrix of technical coefficients. These coefficients are calculated using the formula $a _ { r j } ^ { s i } = z _ { i , j } ^ { s , r } / x _ { r } ^ { j }$ , where $z _ { i , j } ^ { s , r }$ is the flow from sector i in region r to sector $J$ in region s, and $x _ { r } ^ { j }$ is the total output of sector $J$ in region r. To assess the land footprint, an environmentally extended MRIO model has been developed, enhancing the framework to incorporate environmental and resource dimensions (Mi et al., 2017; Turner et al., 2007; Wiedmann, 2009):

$$
\mathrm {L F} = \mathrm {E X} = \mathrm {E} (I - A) ^ {- 1} \mathrm {Y} \tag {2}
$$

where LF represents the land use scale of a region from the consumer’s perspective, accounting for both exports and imports. The matrix E denotes the land use intensity vector for each sector across all areas, which is calculated as $e _ { i } ^ { r } = e _ { i } ^ { r } / x _ { i } ^ { r }$ , where $e _ { i } ^ { r }$ represents the land use scale of sector i in region $r ,$ and $x _ { i } ^ { r }$ is the total output of sector i in region r.

The following equation can be used to calculate the scale of virtual land transfer between regions:

$$
\mathrm {M L F} = \operatorname {d i a g} (\mathrm {E}) (I - A) ^ {- 1} \operatorname {d i a g} (\mathrm {Y}) \tag {3}
$$

where MLF represents the matrix, with its elements indicating the scale of land use transferred from one production sector in a region to the same or a different production sector in another.

# 3.1.3. Structural decomposition analysis

The Structural Decomposition Analysis (SDA) method is a widely used quantitative tool for identifying the driving forces behind changes in key variables within economic systems. Its fundamental principle is to attribute overall changes in a target variable to the contributions of multiple underlying factors. Initially proposed in the 1970s (Rosenberg and Carter, 1971), the method has been progressively developed and formalized (Dietzenbacher and Los, 1998; Rose and Casler, 1996; Sun, 1998), and is now extensively applied in input-output (IO) analysis.

With the growing adoption of IO techniques in environmental research, SDA has become instrumental in uncovering the drivers of changes in environmental indicators such as carbon emissions, energy consumption, and material flows (Su and Ang, 2012, 2023; Wang et al., 2017a). Building on the standard SDA framework, this study further disaggregates the mixed structure of final demand—encompassing both sectoral and regional dimensions—into two distinct components: (1) the final demand product composition and (2) the source structure of final goods, following Hoekstra et al. (2016) and Pan et al. (2023). This dual decomposition enhances the analytical resolution of driving factor assessments in multi-regional settings.

The decomposition process begins with partitioning the final demand into the following four components:

$$
Y = p \cdot p y \cdot y i \cdot y d \tag {4}
$$

where Y represents final demand, $p$ denotes population size, py indicates per capita demand, yi refers to the demand structure of industries, and yd represents the structure of the sources of final demand.

Based on Eq. (2), the following decomposition results can be obtained:

$$
\begin{array}{l} \Delta \mathrm {L F} = L F _ {1} - L F _ {0} \\ = e _ {1} \cdot \mathrm {L} _ {1} \cdot p _ {1} \cdot p y _ {1} \cdot y i _ {1} \cdot y d _ {1} - e _ {0} \cdot \mathrm {L} _ {0} \cdot p _ {0} \cdot p y _ {0} \cdot y i _ {0} \cdot y d _ {0} \\ = e _ {1} \cdot L _ {1} \cdot p _ {1} \cdot p y _ {1} \cdot y i _ {1} \cdot y d _ {1} - e _ {0} \cdot L _ {1} \cdot p _ {1} \cdot p y _ {1} \cdot y i _ {1} \cdot y d _ {1} + \\ \mathrm {e} _ {0} \cdot \mathrm {L} _ {1} \cdot p _ {1} \cdot p y _ {1} \cdot y i _ {1} \cdot y d _ {1} - \mathrm {e} _ {0} \cdot \mathrm {L} _ {0} \cdot p _ {1} \cdot p y _ {1} \cdot y i _ {1} \cdot y d _ {1} + \\ \mathrm {e} _ {0} \cdot \mathrm {L} _ {0} \cdot p _ {1} \cdot p y _ {1} \cdot y i _ {1} \cdot y d _ {1} - \mathrm {e} _ {0} \cdot \mathrm {L} _ {0} \cdot p _ {0} \cdot p y _ {1} \cdot y i _ {1} \cdot y d _ {1} + \\ \end{array}
$$

$$
\begin{array}{l} \mathrm {e} _ {0} \cdot \mathrm {L} _ {0} \cdot p _ {0} \cdot p y _ {1} \cdot y i _ {1} \cdot y d _ {1} - \mathrm {e} _ {0} \cdot \mathrm {L} _ {0} \cdot p _ {0} \cdot p y _ {0} \cdot y i _ {1} \cdot y d _ {1} + \\ \mathrm {e} _ {0} \cdot \mathrm {L} _ {0} \cdot p _ {0} \cdot p y _ {0} \cdot y i _ {1} \cdot y d _ {1} - \mathrm {e} _ {0} \cdot \mathrm {L} _ {0} \cdot p _ {0} \cdot p y _ {0} \cdot y i _ {0} \cdot y d _ {1} + \\ \mathrm {e} _ {0} \cdot \mathrm {L} _ {0} \cdot p _ {0} \cdot p y _ {0} \cdot y i _ {0} \cdot y d _ {1} - \mathrm {e} _ {0} \cdot \mathrm {L} _ {0} \cdot p _ {0} \cdot p y _ {0} \cdot y i _ {0} \cdot y d _ {0} \\ \Delta e = \cdot L _ {1} \cdot p _ {1} \cdot p y _ {1} \cdot y i _ {1} \cdot y d _ {1} + e _ {0} \cdot \Delta L \cdot p _ {1} \cdot p y _ {1} \cdot y i _ {1} \cdot y d _ {1} + \\ \mathrm {e} _ {0} \cdot \mathrm {L} _ {0} \cdot \Delta p \cdot p y _ {1} \cdot y i _ {1} \cdot y d _ {1} + \mathrm {e} _ {0} \cdot \mathrm {L} _ {0} \cdot p _ {0} \cdot \Delta p y \cdot y i _ {1} \cdot y d _ {1} + \\ \mathrm {e} _ {0} \cdot \mathrm {L} _ {0} \cdot p _ {0} \cdot p y _ {0} \cdot \Delta y i \cdot y d _ {1} + \mathrm {e} _ {0} \cdot \mathrm {L} _ {0} \cdot p _ {0} \cdot p y _ {0} \cdot y i _ {0} \cdot \Delta y d \\ = \Delta L F _ {e} + \Delta L F _ {L} + \Delta L F _ {p} + \Delta L F _ {p y} + \Delta L F _ {y i} + \Delta L F _ {y d} \tag {5} \\ \end{array}
$$

where the subscripts $" 0 "$ and "1" refer to different years. However, the equation above represents just one form of structural decomposition. Based on the fundamental principles, multiple decomposition forms can be generated by varying the sequence of subscripts. Specifically, if the analysis includes n decomposition factors, the structural decomposition will yield n! (the factorial of n) distinct perfect decomposition forms. To address this complexity and obtain a representative result, this study adopts the averaging approach proposed by Dietzenbacher and Los (1998) and Sun (1998).

# 3.2. Data sources and preprocessing

Land use data were sourced from the China Land and Resources Statistical Yearbook, China Rural Statistical Yearbook, and China Urban and Rural Construction Statistical Yearbook. Employment data across sectors were obtained from the China Population and Employment Statistical Yearbook. Information on land market transactions was collected from the official China Land Market website (https://www. landchina.com), a government-recognized and regulated platform. Widely utilized in academic research, the dataset includes 2,077,513 land transaction records spanning from 2000 to 2017, with land use classifications aligned with the sectors defined in the input-output table. The cumulative land area for each land use category in 2002, 2007, 2012, and 2017 was calculated based on the official completion date of each transaction. For example, the commercial service land area in 2017 reflects the total area from all relevant transactions completed in that year or earlier.

The MRIO table for China was obtained from the Development Research Center of the State Council (Li et al., 2023; Shicun and Wang, 2007; Xu and Li, 2008), offering high temporal and sectoral resolution. To ensure price comparability across different years in the MRIO analysis, the data for 2002, 2007, and 2012 were adjusted to constant 2017 prices using the widely adopted double deflation method (Minx et al., 2011; Pan et al., 2018). The year 2017 was set as the base year (indexed at 100), and all other years were deflated accordingly to eliminate the effects of inflation and ensure consistency in temporal comparisons.

Additionally, the MRIO tables for the four benchmark years were standardized to a consistent classification comprising 45 economic sectors. To ensure consistency across datasets, the tourism sector in the 2002 input-output table was disaggregated and reallocated to relevant categories. To better capture sectoral heterogeneity, the aggregated category “agriculture, forestry, animal husbandry, and fishery product and service” was disaggregated into five distinct sectors: agriculture, forestry, animal husbandry, fishery, and associated services. Likewise, the chemical industry was subdivided into three more detailed subsectors: (1) chemicals and chemical products, (2) rubber and plastic products, and (3) pharmaceuticals, medicinal chemicals, and botanical products. This sectoral refinement—from the original classification matrix $\mathbb { A } ( s \times s )$ to the revised structure $\mathrm { B ( t \times t ) }$ —was implemented using a binary coordination matrix $\mathrm { C } ( s \times \mathrm { t } )$ and a proxy variable vector g $\left( \mathrm { t } \times 1 \right)$ , following the methodology proposed by Liang et al. (2020) and Yang et al. (2023b).

$$
\mathbf {B} = \left(\left(\widehat {\mathbf {C g}}\right) ^ {- 1} \left(C \widehat {\mathbf {g}}\right)\right) ^ {T} A \left(\widehat {\mathbf {C g}}\right) ^ {- 1} \left(C \widehat {\mathbf {g}}\right) \tag {6}
$$

If sector i is related to industry j, then $C _ { \mathrm { i j } } { = } 1$ ; otherwise, $C _ { \mathrm { i j } } { = } 0$ .

The proxy variables used to disaggregate the agricultural, forestry, animal husbandry, and fishery sectors, as well as the chemical industry, were based on the total output values of their respective sub-sectors, with data drawn from the China Industrial Enterprise Database. For the tourism sector, which spans multiple industries, regional income from associated sectors served as the proxy indicator, following the approach outlined by Lenzen et al. (2018). In addition, the “other social services” category in the 2002 national input-output table was disaggregated using the proportional relationship between the relative weights of the two industries in 2002 and their corresponding weights at both the regional and national levels in 2007. Furthermore, drawing on the China Industrial Enterprise Database for relevant years, the cultural and office machinery manufacturing component—originally part of the broader "Instrument Manufacturing and Cultural and Office Machinery Manufacturing" category in 2002 and 2007—was proportionally reallocated to the general equipment manufacturing sector to reflect industrial structure better.

# 3.3. Uncertainty

Despite efforts to ensure data reliability through multi-source integration and standardization, several uncertainties remain in the datasets and processing procedures used in this study.

First, the MRIO tables, compiled by authoritative institutions, are based on provincial input-output statistics. However, inconsistencies in data reporting standards, delayed updates, and estimation techniques across regions may affect the accuracy of interregional trade flows. Additionally, the harmonization process—including sectoral disaggregation and price deflation to 2017 constant values—introduces uncertainty due to the use of proxy variables and assumptions in reclassification.

Second, land use data were primarily drawn from national and regional statistical yearbooks and the official China Land Market database. While these sources are government-certified and widely used in academic research, classification inconsistencies (e.g., in mixed or marginal land types), underreporting of informal land use, and year-toyear reporting changes may influence the spatial and temporal comparability of the results.

Third, in mapping economic sectors to land categories, we employed a sector-land matching framework supported by expert knowledge and empirical proxies (e.g., employment, output value, transaction area). Although refined through disaggregation, this process still requires validation through actual research or more refined data.

To address these limitations, we identify assumptions in the Methods section and encourage future studies to adopt complementary modeling approaches (e.g., agent-based or system-dynamic models) and highresolution geospatial data to reduce uncertainty and enhance robustness.

# 4. Results

# 4.1. Spatiotemporal dynamics of land use

# 4.1.1. National trends and regional heterogeneity of land use

At the national scale, China’s total land area remained relatively stable from 2002 to 2017, recording values of 425.5, 423.0, 406.7, and 416.1 million hectares (Mha) for the years 2002, 2007, 2012, and 2017, respectively (Fig. 3a). Overall, this represented a modest decrease of approximately $2 . 5 ~ \%$ by 2017 compared to 2002. Despite the stability in aggregate terms, distinct land types displayed significantly varied trajectories. Specifically, cropland, garden, forestland, mining, and construction land demonstrated clear upward trends, increasing by $7 . 1 \ \%$ ,

![](images/065353dc8ce68052e4224a603ea4cb0d41827fbe4fdeff2342ad63f4aa7fcf7f.jpg)

![](images/36ebd971658a933b7b5facbebd2a7d45fd9d692aab3fce1d46ddc0e6f128d1b0.jpg)  
Fig. 3. National land use composition (a) and sector-specific land use characteristics (b).

$3 1 . 7 \%$ , $3 0 . 2 \%$ , $1 8 . 0 \%$ , and $3 9 . 2 \%$ , respectively. In contrast, grazing land experienced a pronounced downward trend, particularly after 2007, with an overall reduction of 50.4 Mha $( 2 5 . 3 \ : \% )$ ) across the entire study period.

The sector-specific analysis further highlights substantial differences in land-use intensity among various economic sectors. In 2017, the sectors most heavily dependent on land resources included animal husbandry $( 3 8 . 7 \% )$ , crop cultivation $( 3 8 . 7 \% )$ , and forestry $( 1 8 . 0 \% )$ (Fig. 3b). These sectors collectively accounted for the largest share of national land use.

Significant regional variations in land use dynamics were observed across China during the study period. The spatial pattern of China’s land footprint was characterized by a pronounced east-west gradient, with higher values concentrated primarily in western regions (Fig. S1). Notable hotspots of intensive land use were identified in the northwest, northeast, and southwest provinces. Specifically, provinces such as Xinjiang, Qinghai, Gansu, Inner Mongolia, and Heilongjiang exhibited large total land and high per capita land use (Fig. 4). Qinghai had the highest per capita land (7.1 ha/person), approximately 23.9 times the national average, followed by Inner Mongolia (2.6 ha/person) and Xinjiang (1.8 ha/person).

Additionally, 22 provinces experienced overall increases in land use area, with the fastest growth occurring in Hainan $( 2 4 . 5 \% )$ ), Heilongjiang $( 2 1 . 9 \% )$ , Jiangxi $( 2 1 . 3 \% )$ , Hubei $( 1 9 . 8 \% )$ , and Yunnan $( 1 9 . 6 \% )$ . In contrast, eight provinces—including Gansu, Xinjiang, Inner Mongolia, and Ningxia—demonstrated declining trends. These differences highlight the uneven distribution and divergent trajectories of regional land use changes, underscoring the necessity of region-specific management approaches in China’s national land policy.

# 4.1.2. Land use characteristics from a telecoupling perspective

From the telecoupling perspective, the sectors most closely associated with virtual land flows are food manufacturing and tobacco processing, agriculture, animal husbandry, and construction. In 2017, these sectors accounted for $2 4 . 6 \%$ , $1 7 . 1 \ \%$ , $1 6 . 0 \%$ , and $9 . 2 \%$ of the total virtual land use, respectively (Fig. 5). Among them, food manufacturing and tobacco processing exhibited the highest reliance on virtual land, reflecting extensive upstream dependencies on cropland and grazing land. Although the construction sector is not traditionally land-intensive in a direct physical sense, it nonetheless demonstrated a considerable virtual land footprint. This is primarily attributable to the land required for the production of upstream materials, such as cement, steel, and prefabricated components, which are integral to the construction supply chain.

The land footprints of 18 provinces—including Beijing, Henan,

Jiangxi, and Guangdong—showed an overall increasing trend from 2002 to 2017. In contrast, Gansu, Jilin, Inner Mongolia, and Qinghai experienced significant declines in their economic growth. Among the fastest-growing provinces, Beijing, Henan, Jiangxi, and Guangdong recorded increases of $1 5 7 . 0 \%$ , $1 1 3 . 3 \%$ , $8 1 . 7 \%$ , and $7 6 . 9 \%$ , respectively, over the study period. Conversely, the most pronounced decreases occurred in Gansu $( 6 0 . 8 \% )$ ), Jilin $( 5 4 . 2 \% )$ , Inner Mongolia $( 5 3 . 8 \% )$ , and Qinghai $( 5 3 . 2 \% )$ .

By 2017, the provinces with the largest land footprint scales were Henan, Guangdong, Inner Mongolia, Sichuan and Xinjiang, representing $7 . 0 \%$ , $6 . 5 \%$ , $5 . 5 \%$ , $5 . 3 \%$ , and $4 . 5 ~ \%$ of the national total, respectively (Fig. 4). In terms of per capita land footprint, Qinghai, Inner Mongolia, Xinjiang, and Beijing ranked highest, with 2.9, 0.9, 0.8, and 0.7 ha per person—equivalent to 9.6, 3.2, 2.5, and 2.2 times the national average. These figures reflect disparities in land-use intensity and population density, as well as regional differences in economic structure and land dependency.

# 4.2. Interregional virtual land flows

# 4.2.1. Domestic virtual land transfers

By 2017, interprovincial virtual land transfers significantly reshaped China’s spatial land-use patterns, accounting for nearly half of the national land footprint for all land categories except construction land. Specifically, virtual land transfer proportions reached $5 9 . 7 \%$ for mining land, $5 7 . 4 \%$ for grazing land, approximately $4 7 \ \%$ each for garden, arable, and forest lands, and $4 0 . 3 ~ \%$ for aquaculture land. Construction land exhibited the lowest transfer proportion $( 7 . 4 \% )$ , reflecting its inherently localized nature and immobility.

Between 2002 and 2017, the total volume of interprovincial virtual land transfers increased across all land categories, with growth rates ranging from $2 4 . 2 \%$ to $1 3 8 . 0 \%$ . Grazing land transfers experienced the most pronounced increase, rising from $2 4 . 1 \%$ in 2002 to $5 7 . 4 \%$ in 2017, followed by notable increases in garden, forest, arable, and aquaculture land.

The spatial distribution of net virtual land transfers in 2017 exhibited clear directional flows, predominantly from western to eastern and from northern to southern provinces (Fig. 6b). Notable sending provinces included Inner Mongolia, Qinghai, Xinjiang, and Heilongjiang, each with distinct transfer pathways. Inner Mongolia primarily exported virtual land to Beijing, Jiangxi, Anhui, Hebei, Hubei, Hunan, and Zhejiang. Qinghai’s primary receivers included Henan, Guangdong, Shaanxi, and Beijing, while Xinjiang transferred land mainly to Henan, Inner Mongolia, Fujian, Shaanxi, and Shandong. Heilongjiang primarily exported to Jiangsu and Tianjin. These flows highlight the growing

![](images/b73646dc32a3c42140bc54684115c50b212174a8a595c692e870d0ad87e7dd38.jpg)

![](images/dbed5127a27b40fd9945afc0e73ceb7e247eefe50543f81d3764b7a476d5b7fa.jpg)

![](images/95211647cb086be9a8fb2c95f1d48615e6bf67273f721459e9d3105648681a28.jpg)

![](images/8a628d3342f9cb549becb893299c1c404d7138cf45406d0603a12f37114777e4.jpg)

![](images/a4b8177521d744af67cdc0f2fc7b2b43c32e8d42babf182b19330712ff052477.jpg)

![](images/92df350e741b29dfb26ca0fb7f899c61155a950f2cb7f40eb71097d63e06a81a.jpg)

![](images/87d3ccd28498f103b93500fcb7d19ebb1805eae27e3989173e0a35c52cefb211.jpg)

![](images/a6742e488633b4acce3044bab5821600f7cc94cb8d022be387c108473ff896cf.jpg)

![](images/955c7c47e847a52695d5dbd52e56ddb2e24a6bc8ea3bbd8430e7e5140f04e19e.jpg)

![](images/09fc7cbf5ebbcfe396d60a09ffc7d5912723a0f02d38864a193855ee7993baf6.jpg)

![](images/544023508d3b3bb4e9e1a4c4714cbcdf4baa51304e1873a43496d4b9aeef38cb.jpg)

![](images/5403b049249a9c6f1056f3ff2de8bc26c83aeee7573997413ceb1ffc0a7ed0a1.jpg)

![](images/8b203cc547393c7ce223450ea3dfa138d05e271c93d4d28b4ed2b537416f91cb.jpg)  
Fig. 4. Top ten provinces by land area (row 1), land footprint (row 2), virtual land exports (row 3), and virtual land imports (row 4). Note: This figure illustrates, for each row, the total land amount by province (left column), per capita land use (right column), and land use intensity (center column). Bar colors represent provincial GDP per capita, ranging from red for the most affluent provinces to green for the least developed ones (see legend for scale).

![](images/1db3cfefd3dc6eaa6b78648bdf37bfcdbe924252f289fa301a71fde185c3c6dc.jpg)  
Fig. 5. Sectoral composition of national land footprint from a telecoupling perspective.

![](images/da73000ed014522a35f4839fa38b06e673fb83191c43583fa27be0cafb7876ca.jpg)

![](images/0040a6e763aff453f5315f40fd85d2da4ae878e7337f85f9b6da839105102618.jpg)

![](images/fb4b8e9e2b92ae8fb2d6dd6be9f8a9e897b59057e5b6cc363ba2eb09a3b93871.jpg)  
Fig. 6. Net land transfers over time (a), the spatial pattern of net virtual land flows (b), and overview of virtual land exchanges in 2017 (c). Note: In panel (b), node size represents the volume of net exports (or imports), with blue indicating net exporting provinces and orange indicating net importing provinces. The thickness of the connecting lines reflects the magnitude of virtual land flows embedded in interregional trade.

interregional dependencies and spatially uneven distribution of land resources driven by economic demand.

# 4.2.2. Spatial differentiation of net sending and receiving systems

Marked spatial and temporal variations existed in provincial roles as net senders and receivers of virtual land across China (Fig. 6a). Provinces such as Beijing, Tianjin, Hebei, and Shanxi consistently served as

net receivers throughout the study period, underscoring their sustained reliance on external land resources for local consumption and urban development. Conversely, provinces including Xinjiang, Qinghai, Guizhou, Heilongjiang, and Inner Mongolia consistently acted as net senders, highlighting their roles as major suppliers of land-intensive products and ecological services.

Several provinces demonstrated dynamic shifts in their net sending

or receiving roles over time. Fujian, for example, transitioned from being a net sender only in 2012 to a net receiver in other years, while Jiangxi changed from a net sender in 2007 to a net receiver thereafter. Similarly, Sichuan functioned as a net receiver in 2012 but as a net sender in other periods. Furthermore, provinces such as Yunnan (since 2017), Jilin (since 2012), Guangxi, Hainan, and Gansu (since 2007), as well as Ningxia (since 2012) and Hunan (since 2017), all transitioned toward net receiver roles. These dynamic shifts indicate evolving interregional economic linkages, sectoral structural adjustments, and changes in land-use demand, emphasizing the dynamic character of China’s domestic telecoupling system.

In 2017, 19 provinces were net receivers of virtual land, with Henan, Guangdong, Beijing, Shaanxi, and Jiangsu receiving the most significant inflows—totaling 16.4, 16.4, 13.6, 7.0, and 7.0 Mha, respectively. These figures corresponded to $1 4 . 9 \%$ , $1 4 . 9 \%$ , $1 2 . 4 ~ \%$ , $6 . 4 ~ \%$ , and $6 . 3 ~ \%$ of the total land inflows nationwide (Fig. 6c). In contrast, Inner Mongolia (36.5 Mha), Qinghai (22.3 Mha), Xinjiang (21.9 Mha), and Heilongjiang (9.1 Mha) emerged as the primary net senders, accounting for $3 3 . 1 \ \%$ , $2 0 . 3 \%$ , $1 9 . 9 \%$ , and $8 . 3 ~ \%$ of the total outflows, respectively.

The functional differentiation of provinces in terms of net virtual land flows varied notably across land-use types (Table 1). Southern provinces, such as Guangxi, Yunnan, and Hainan, primarily exported garden and forest land, reflecting their subtropical agricultural specialization and rich ecological resources. Northwestern regions, including Xinjiang, Qinghai, and Inner Mongolia, were dominant exporters of grazing and mining lands, consistent with their roles as national suppliers of livestock products and raw materials. Meanwhile, economically advanced eastern coastal provinces, notably Shanghai, Zhejiang, and Jiangsu, consistently served as primary receivers of forest, garden, and aquaculture lands, reinforcing their consumer-oriented roles within the national economy. Provinces such as Heilongjiang, Inner Mongolia, Xinjiang, Yunnan, and Gansu regularly appeared as top net senders across multiple key land categories (cropland, grazing land, garden land, and mining land), facilitated by their extensive land resources, resource-based economic structures, and lower population densities. In contrast, Beijing, Shanghai, Guangdong, Jiangsu, and Henan were consistently major net receivers across several land types, heavily dependent on virtual land inflows to sustain their urban consumption and industrial production. Beijing, in particular, emerged as a significant net receiver for nearly all land categories, highlighting its strong dependence on external land resources.

Table 1 Net sending and receiving provinces for different land use types in 2017.   

<table><tr><td>Land Use Type</td><td>Top 20 % Net Sending Regions</td><td>Top 20 % Net Receiving Regions</td></tr><tr><td>Cropland</td><td>Heilongjiang, Inner Mongolia, Jilin, Gansu, Yunnan, Xinjiang</td><td>Guangdong, Beijing, Shanghai, Tianjin, Shanxi, Zhejiang</td></tr><tr><td>Garden Land</td><td>Yunnan, Hainan, Guangxi, Hebei, Xinjiang, Shandong</td><td>Henan, Guangdong, Shanghai, Shaanxi, Beijing, Jiangsu</td></tr><tr><td>Forests</td><td>Guangxi, Yunnan, Inner Mongolia, Heilongjiang, Hunan, Jiangxi</td><td>Shanghai, Beijing, Henan, Guangdong, Shaanxi, Jiangsu</td></tr><tr><td>Grazing land</td><td>Inner Mongolia, Qinghai, Xinjiang, Gansu, Sichuan, Ningxia</td><td>Henan, Guangdong, Beijing, Jiangxi, Anhui, Hebei</td></tr><tr><td>Aquaculture land</td><td>Liaoning, Shandong, Heilongjiang, Jilin, Jiangsu, Jiangxi</td><td>Beijing, Henan, Shaanxi, Shanghai, Shaanxi, Tianjin</td></tr><tr><td>Mining land</td><td>Xinjiang, Inner Mongolia, Liaoning, Hebei, Shandong, Shanxi</td><td>Hubei, Zhejiang, Shanghai, Chongqing, Guangdong, Beijing</td></tr><tr><td>Construction land</td><td>Shandong, Inner Mongolia, Jiangsu, Zhejiang, Liaoning, Jiangxi</td><td>Yunnan, Henan, Beijing, Chongqing, Xinjiang, Tianjin</td></tr></table>

# 4.2.3. Virtual land export embedded in international trade

China’s land resources have also been extensively mobilized to meet external demand through international trade. The analysis reveals that the scale of virtual land exports increased markedly from 35.6 Mha in 2002 to a peak of 66.6 Mha in 2007 before declining to 33.6 Mha by 2017—representing an overall decrease of $5 . 6 \%$ over the study period. However, trends varied significantly by land type. Construction land exports grew most substantially $( + 1 0 6 . 7 \% )$ , followed by garden land $( + 2 4 . 9 \% )$ , forest land $( + 2 4 . 0 \% )$ ), mining land $( + 1 5 . 0 \% )$ , and arable land $( + 5 . 5 \% )$ , while pastureland exports declined sharply by $3 2 . 1 \ \%$ .

By 2017, China’s virtual land exports were predominantly composed of mining land $( 1 8 . 3 \% )$ ), aquaculture land $( 1 1 . 1 \% )$ ), garden land $( 1 0 . 7 \% )$ , forest land $( 9 . 9 \% )$ , arable land $( 9 . 2 ~ \% )$ , and grazing land $\left( 7 . 0 \% \right)$ , indicating an initial expansion phase followed by contraction. Spatially, exports were concentrated in the northwest, northeast, and eastern coastal regions, with Inner Mongolia $( 1 4 . 0 \% )$ ), Xinjiang $( 1 0 . 4 \% )$ , Qinghai $( 7 . 9 \% )$ , Shandong $\left( 6 . 9 \% \right)$ , Jiangsu $( 5 . 3 \% )$ , and Heilongjiang $( 4 . 8 \% )$ emerging as the leading contributors (Fig. 7).

Unlike domestic virtual land flows—typically characterized by inland provinces acting as net exporters and coastal regions as net importers—China’s international virtual land export structure exhibits a dual-source pattern. It combines contributions from both resourceabundant interior provinces (e.g., Xinjiang, Inner Mongolia, Heilongjiang) and economically developed coastal regions (e.g., Jiangsu, Guangdong, Shandong).

Over time, regional contributions to virtual land exports have shifted. The export shares of Inner Mongolia and Xinjiang declined from $1 9 . 9 \%$ and $1 8 . 6 \%$ in $2 0 0 2 \substack { - 1 4 . 0 \% }$ and $1 0 . 4 \%$ in 2017, respectively. Conversely, Guangdong, Shandong, and Jilin expanded their roles, with export shares rising to $7 . 9 \%$ , $6 . 9 \%$ , and $5 . 3 \% .$ , up from $5 . 5 ~ \%$ , $5 . 5 \% \%$ , and $4 . 3 \%$ . These changes signal evolving positions within global value chains, as coastal provinces increasingly dominate virtual land exports—particularly through high-value industrial and infrastructurelinked sectors.

# 4.3. Multidimensional drivers of land footprint change

# 4.3.1. National-level decomposition of driving forces

From 2002 to 2017, China’s land footprint dynamics were shaped by a complex interplay of consumption-side and production-side factors (Fig. 8).

On the consumption side, economic development was the most influential driver, accounting for a total contribution of $1 7 3 . 2 \%$ to the growth in land footprint. This impact varied across land types, with mining land exhibiting the highest growth contribution $( 2 5 . 2 \% )$ , followed by moderate increases in cropland, garden, forest, grazing, and aquaculture lands $( 1 0 . 7 \% - 1 5 . 6 \%$ ). In contrast, construction land had the lowest contribution from economic growth $( 2 . 6 \% )$ . Population growth and changing consumption patterns also significantly expanded land footprints. For instance, consumption patterns notably contributed to increased footprints for grazing land $( 7 9 . 1 \ \% )$ , forest land $( 5 7 . 7 \% )$ , garden land $( 5 6 . 3 \% )$ ), cropland $( 5 2 . 3 \% )$ , and aquaculture land $( 4 7 . 5 \% )$ . Furthermore, direct residential land expansion contributed a 6.6 Mha increase in construction land, with a contribution rate of $2 5 . 1 \%$ , reflecting urbanization-driven residential demands.

On the production side, the predominant mitigating factor was improvements in land-use efficiency, contributing to a $1 3 6 . 0 \%$ reduction in the overall land footprint. Technological advancements and productivity gains effectively offset the substantial growth in land footprint driven by economic and demographic pressures. Production structure adjustments also modestly reduced land footprints, although their effects varied by land type. For example, production structure contributed to an $8 . 5 ~ \%$ reduction in grazing land footprints, but also led to increases in other land types, reflecting complex industrial restructuring processes. Additionally, shifts in the geographic sources of consumer goods significantly altered spatial land-use patterns. Specifically, changes in

![](images/c1cfc8690df554ac385c57857a3f32bee444380d469359f595c910bb18fdb0c8.jpg)  
Fig. 7. Provincial distribution of virtual land exports by land type in China.

production locations increased grazing land footprints by 32.6 Mha $( + 1 7 . 8 \% )$ and mining land footprints by 1.3 Mha $( + 8 0 . 6 \% )$ , while slightly decreasing garden land footprints by 0.3 Mha $( - 3 . 2 \% )$ ).

Temporal analysis further reveals evolving contributions from these drivers. The influence of economic development on land footprint growth gradually diminished across periods (from $4 9 . 0 \%$ in 2002–2007 to $5 4 . 8 ~ \%$ in 2007–2012 and down to $1 6 . 4 ~ \%$ in 2012–2017). Similarly, the contribution of consumption patterns to footprint growth also declined steadily from $3 0 . 8 \%$ to $1 9 . 8 ~ \%$ and ultimately to $3 . 1 ~ \%$ . In contrast, land use efficiency improvements maintained a relatively stable and significant contribution to footprint reduction $( 2 3 . 5 ~ \%$ , $3 2 . 0 \%$ , and $1 9 . 2 \%$ across the three periods). Notably, changes in product supply sources showed mixed effects: it reduced the national land footprint by 23.3 Mha $( - 6 . 5 \%$ ) from 2007 to 2012 but increased footprints during 2002–2007 (12.2 Mha, $3 . 1 ~ \%$ ) and 2012–2017 (26.7 Mha, $7 . 2 \% )$ , underscoring the shifting spatial relationships between production and consumption regions.

# 4.3.2. Provincial-level dynamics and regional disparities

Provincial-level decomposition analysis (Fig. 9) highlights substantial regional heterogeneity in the driving forces behind land footprint dynamics, reflecting varied contributions of consumption- and production-side factors over time and across regions.

On the consumption side, population size has consistently driven land footprint growth in most provinces, although its influence weakened over the study period. Between 2012 and 2017, population growth significantly contributed to increases in land footprint in 24 provinces, with Guangdong $( 1 2 . 6 \% )$ ) and Xinjiang $( 9 . 0 \% )$ exhibiting the most significant effects. Economic development emerged as another critical factor, with average contribution rates of $4 2 . 6 \%$ (2002–2007), $5 5 . 4 \%$ (2007–2012), and $2 5 . 2 \%$ (2012–2017). Henan, Ningxia, Chongqing, Jiangxi, Anhui, and Hubei experienced particularly substantial growth

driven by economic factors, each surpassing $2 0 0 \%$ over the entire period. Temporally, economic growth predominantly impacted provinces such as Jilin, Anhui, and Inner Mongolia from 2002 to 2007; Liaoning, Hainan, and Heilongjiang from 2007 to 2012; and Fujian, Ningxia, and Shaanxi from 2012 to 2017.

Changes in consumption patterns exhibited mixed regional effects. From 2002–2017, Beijing $( 3 6 . 5 \% )$ and Shaanxi $( 3 5 . 6 ~ \% )$ ) saw substantial footprint increases driven by changing consumption behaviors, whereas 26 provinces experienced footprint reductions ranging up to $1 3 5 . 8 \%$ . Notably, from 2012 to 2017, consumption-driven footprint growth surged dramatically in Shaanxi $( 1 2 4 . 0 \% )$ ) and Inner Mongolia, while sharply declining in Ningxia $( - 5 4 . 9 \% )$ and Qinghai $( - 5 2 . 9 \% )$ , indicating a growing regional divergence in consumption-related land pressures. Additionally, direct residential land expansion consistently contributed modestly to footprint increases in nearly all provinces (except Gansu), especially between 2007 and 2012, with notable impacts in Jiangxi $( 5 . 1 ~ \% )$ ), Jiangsu $( 4 . 2 \% )$ , and Shandong $( 4 . 1 ~ \% )$ .

On the production side, the most significant mitigating factor was improved land-use efficiency, which consistently reduced land footprints across nearly all provinces. Between 2002 and 2017, provinces such as Beijing $( - 1 5 8 . 5 \% )$ ), Jiangxi $( - 1 3 9 . 8 \% )$ , and Guizhou $( - 1 3 6 . 1 \ \% )$ ) demonstrated particularly significant efficiency gains. The most notable improvements varied by stage, including Guangdong and Shanghai (2002–2007), Shanxi and Beijing (2007–2012), and Guizhou (2012–2017).

Adjustments in production structures also played a predominantly mitigating role, reducing footprints in 27 provinces from 2002 to 2017. Liaoning $( - 6 1 . 5 ~ \% )$ ), Henan $( - 5 6 . 0 \% )$ , Shanghai $\left( - 5 4 . 7 ~ \% \right)$ , and Beijing $( - 5 1 . 3 \% )$ saw significant reductions driven by industrial restructuring and technological advancements. However, in certain coastal provinces, notably Guangdong and Fujian, shifts in the production structure contributed to increases in land footprints in the final stage

![](images/745271d24acb48d287ce232af1886f4b7a902e881a41b68b6e2799e21afabdc5.jpg)  
(a) Cultivated land

![](images/15188ef5663cea5ac4c503057a8e3be3992ce919df7028f2c97428595e8dc332.jpg)  
(b) Garden land

![](images/6cf683c72edb2242a8614b9d8ccffdfbed314fabcb791d2d45a5f5e9b7003622.jpg)  
(c) Forest land

![](images/e78d2af802226af40446d28e58707437c042107dee79dd61c3581d705e6c0d4b.jpg)  
(d) Grazing land

![](images/1577ce478002d4dd70e47eefdf1ccbe77d0db707124793a5f555701706a16cd8.jpg)  
(e) Land for aquaculture

![](images/4cd929eca63a8c9950058e2256ad9685c0f3a843614588ff4269cc2a5b3d647e.jpg)  
(f) Mining Land

![](images/ac7f73fc77e63ce7d9364df4dfaa4348c372262b6a423b82c87d075533b03b1f.jpg)  
(g) Construction land

![](images/c69dd47686ae29be4abb728a91aa217c03e0ede90e82c80e4659610a86f0b68f.jpg)  
Fig. 8. Driving factors of national land footprint changes. Note: The elements within the dotted box represent consumption-side factors; all others correspond to production-side factors.

(2012–2017), reflecting regional differences in industrial dynamics and production specialization.

Finally, shifts in the sources of product supply—reflecting interregional reallocations of supply chains—showed mixed regional effects. Overall, from 2002 to 2017, this factor reduced footprints in 10 provinces (e.g., Xinjiang, Hainan) but increased them in 20 others, particularly Beijing $9 4 . 4 \%$ , $+ 6 . 8$ Mha) and Jiangxi $( 7 7 . 6 \%$ , $+ 5 . 3$ Mha). Such changes indicate increasing dependence of some provinces on external land resources, emphasizing the critical role of spatially explicit policy interventions.

# 4.3.3. Drivers of virtual land exports

Between 2002 and 2017, China’s total virtual land exports decreased by $5 . 5 ~ \%$ , driven by complex interactions among export scale, export structure, and land-use efficiency improvements (Fig. 10). Declining land intensity of exports, structural shifts toward less land-intensive sectors, geographic sourcing adjustments of product supply, and significant efficiency gains collectively moderated China’s virtual land outflow despite sustained export volume growth.

Specially, the overall increase in export volume contributed significantly $( + 7 7 . 9$ Mha; $+ 2 1 8 . 6 \%$ ) to virtual land use expansion, although this effect declined markedly over time, from $1 5 9 . 9 \%$ (2002–2007) to $1 1 . 6 \%$ (2012–2017).

Land-use efficiency improvements consistently mitigated virtual land exports, reducing land footprints by 35.1 Mha $( 9 8 . 6 \% )$ over the entire study period, with contributions of $4 0 . 5 \%$ , $2 5 . 2 \%$ , and $1 9 . 3 ~ \%$ in successive periods. Adjustments in the production structure also reduced virtual land exports in the first two stages $( - 1 7 . 2 \%$ and $- 8 . 4 \% )$ ,

although they slightly increased exports $( + 1 . 2 \% )$ ) during the final period (2012–2017).

Sectoral changes in export composition significantly influenced virtual land flows. A structural shift away from land-intensive sectors, notably agriculture and animal husbandry—whose export shares declined substantially from 2002 to 2012—led to significant reductions $( - 3 5 . 0 \%$ and $- 3 7 . 0 \%$ ) during the first two stages. However, a slight reversal occurred from 2012 to 2017 $( + 2 . 0 \% )$ , reflecting renewed growth in certain land-intensive exports.

Additionally, the geographic sourcing of exported products varied over time. From 2002 to 2007, rising exports from land-rich regions such as Xinjiang and Inner Mongolia contributed an additional 710 million ${ \mathrm { m } } ^ { 2 } ( 1 9 . 9 \% )$ to virtual land exports. Yet, this pattern reversed between 2007 and 2012 $( - 7 . 4 \% )$ , before slightly increasing again between 2012 and 2017 $( + 2 . 3 \% )$ ).

# 5. Discussions

# 5.1. Advantages and characteristics of the telecoupling perspective

Traditional land-use studies typically focus on localized drivers and physical land changes within administrative boundaries (Jia et al., 2024; Li et al., 2018; Verma et al., 2021), often neglecting the critical role of cross-regional interactions and spatial interdependencies. This study demonstrates that the telecoupling framework offers a comprehensive approach to systematically capture how geographically distant yet functionally interconnected regions influence each other’s land use through trade.

![](images/4784602652020146a7184e9c5aa927bdb9cb626076688e3bb5891ef17772673d.jpg)  
Fig. 9. Driving factors of provincial land footprint changes across different periods.

![](images/71816992d8cf425fcdb43a29122b6bcaf3a46496a0b294da53c262e268234023.jpg)  
Fig. 10. Driving factors of virtual land exports across different periods.

First, the telecoupling perspective helps identify indirect land pressures driven by interregional demand. This study demonstrates that economically advanced coastal provinces, such as Beijing, Jiangsu, and Guangdong, maintain relatively stable or declining local land use, but heavily rely on external virtual land inflows to support their consumption and industrial growth. Consequently, inland provinces—such as Inner Mongolia, Xinjiang, and Qinghai—bear increased ecological burdens, reflecting a clear spatial decoupling between land consumption and actual land use.

Second, adopting a telecoupling lens allows the explicit quantification of virtual land flows and their spatial structures. Between 2002 and 2017, the proportion of virtual land embedded in interprovincial trade

increased markedly, reaching over $5 7 \%$ of China’s total land footprint by 2017. Virtual land flows exhibited clear spatial directions, primarily from west to east and north to south, with resource-rich provinces (e.g., Inner Mongolia, Heilongjiang, Qinghai) supplying land-intensive commodities such as crops, livestock products, minerals, and forest products to high-demand eastern coastal regions (e.g., Beijing, the Yangtze River Delta, and the Pearl River Delta).

Third, the telecoupling framework facilitates a comprehensive understanding of multidimensional drivers of land demand from both production and consumption perspectives. Structural decomposition analysis reveals that, on the production side, improvements in land-use efficiency consistently served as the primary mitigating factor,

significantly reducing overall land footprints. Technological advancements and productivity enhancements have proven crucial for achieving sustainable land management and alleviating spatial pressures on land resources. In contrast, on the consumption side, economic development emerged as the most significant driver of land footprint growth, aligning with previous findings (Tian et al., 2019). Changing consumption patterns, including dietary transitions and growing urban residential demand, further exacerbated land pressures, especially in densely populated and economically vibrant regions.

Spatially, driving factors exhibit clear regional differentiation. Eastern coastal provinces experienced footprint growth primarily driven by shifting consumption patterns and reallocation of final demand sources, given their high reliance on imported food, timber, and construction materials. Conversely, inland and western provinces, such as Shaanxi and Inner Mongolia, experienced growth in land footprints largely driven by production-side factors—industrial restructuring and their roles as major suppliers of resource-intensive products.

Overall, adopting the telecoupling perspective provides valuable insights into China’s spatially interconnected land-use systems, highlighting critical regional dependencies and informing spatially targeted policies to address land sustainability challenges effectively.

# 5.2. New insights from a telecoupling perspective

This study complements and extends previous research on crossregional resource flows (Chen et al., 2019; Guo et al., 2020a; Wang and Wang, 2022; Wang et al., 2024a) by applying the telecoupling perspective to analyze land use changes, specifically contributing through temporal extension, enhanced sectoral resolution, and refined driver analysis.

First, by examining a long-term temporal scale from 2002 to 2017, our study captures the dynamics and structural transformations in China’s land system over an extended period. For instance, virtual land exports increased significantly between 2002 and 2007 but subsequently declined. Furthermore, the role of economic development as a driver of land footprint growth diminished over time, while consumption patterns emerged as increasingly critical, notably driving land footprint growth in provinces such as Shaanxi and Inner Mongolia. This highlights the rising importance of addressing demand-side factors in sustainable land management.

Second, this research enhances analytical precision by decomposing final demand into two distinct components: the product structure and the geographic source of final goods. This approach reveals that changes in national production layouts have substantially expanded grazing land footprints, and that shifts in product supply—particularly evident in Jiangxi and Guangdong—have further amplified regional land footprints. Such refined sectoral and spatial resolution provides deeper insights into the mechanisms underlying land-use change.

Third, the telecoupling framework underscores essential policy implications, particularly in alignment with Sustainable Development Goal 12 (Responsible Consumption and Production). Traditional sustainability approaches often emphasize localized, place-based interventions, inadvertently shifting environmental pressures to other regions (Liu, 2023). Our results explicitly demonstrate that land-intensive consumption in economically developed areas, such as Beijing and Tianjin, heavily depends on ecological resources from distant, resource-rich provinces like Inner Mongolia. This spatial displacement of environmental burdens emphasizes the urgent need to integrate telecoupling considerations into regional planning and land governance frameworks to avoid resource misallocation and ecological degradation (Chen et al., 2019; Jia et al., 2023; Y. Li et al., 2023).

Ultimately, this study lays the groundwork for a deeper understanding of environmental feedback mechanisms triggered by land-use intensification driven by trade and consumption. Increased land pressures in ecologically sensitive areas can exacerbate soil phosphorus depletion, elevate carbon emissions, and accelerate biodiversity loss

(Niu et al., 2024; Zhu et al., 2025). Recognizing land use as a systemic outcome shaped by complex regional and global interdependencies highlights the potential of telecoupling as an analytical approach for developing more integrated and spatially informed land management strategies.

# 5.3. Policy implications

The findings underscore the growing spatial decoupling between land production and consumption—not only in China but also across many countries globally. Land-intensive goods are increasingly produced in resource-rich, low-density regions and consumed in urbanized, high-income areas, reflecting deep interregional dependencies. Addressing these complexities requires integrated, cross-regionally coordinated, and spatially targeted land governance. Based on our results, we propose the following policy recommendations:

First, land governance should transition from jurisdiction-based systems to cross-regional coordination frameworks that explicitly incorporate virtual land flows. In China, the persistent net inflows of virtual land in coastal consumption hubs (e.g., Beijing, Jiangsu, Guangdong) and corresponding outflows from inland production zones (e.g., Inner Mongolia, Xinjiang, Qinghai) reveal entrenched structural dependencies. These patterns necessitate ecological compensation mechanisms and resource balancing tools, such as interprovincial water rights trading or carbon markets (Liu et al., 2019; Wang et al., 2017b). Globally, many countries—especially those with pronounced urban-rural divides—face analogous challenges and can benefit from telecoupling-informed land governance.

Second, tailored strategies are needed for land-intensive sectors and key regions. Provinces such as Shaanxi and Inner Mongolia, where both production and consumption patterns drive land consumption, should adopt policies promoting low-footprint industries and sustainable lifestyles. Simultaneously, land-exporting regions should receive targeted support for ecological restoration, technological upgrades, and improvements in land-use efficiency. Similar policy frameworks apply to other rapidly urbanizing economies, such as India, Indonesia, and Brazil, which are experiencing growing internal land transfers.

Third, demand-side management must be prioritized. As consump tion behaviors—particularly in urban and affluent areas—become a dominant force in driving land-use expansion, it is crucial to promote more sustainable consumption practices. Policies promoting dietary shifts, urban farming, circular economy principles, and sustainable public procurement can help mitigate the indirect environmental impacts of land use. For developed economies with strong trade linkages, such as the EU and North America, these measures are vital for rethinking their externalized land footprints and assuming greater ecological responsibility in global supply chains.

# 5.4. Limitations and prospects

Several limitations of this study suggest directions for future research. First, the analysis relies on MRIO tables and land-use data for 2002, 2007, 2012, and 2017—the most recent harmonized datasets available. While this long-term perspective enables the identification of structural trends and phased transitions in land telecoupling, it may not fully capture more recent shifts in land-use intensity, trade networks, and urbanization. We have accordingly clarified the temporal interpretation of our results and recommend incorporating updated MRIO data and satellite-based land metrics in future studies to reassess the persistence or transformation of observed patterns.

Second, the MRIO-based SDA framework, while effective for quantifying land flows and their drivers, simplifies the complexity of socioecological systems through its aggregated and linear structure. This limits the model’s ability to reflect feedback loops, non-linear dynamics, and ecological thresholds (Liu et al., 2013, 2018). For instance, externalities such as biodiversity loss, water stress, or ecosystem degradation

associated with land displacement are not explicitly modeled. Future research should integrate MRIO with dynamic or agent-based models to account for interregional feedback and policy interactions, thereby better reflecting the full complexity of telecoupled systems.

Third, although this study identifies spatial imbalances in land flows and disaggregates demand-side drivers, it does not fully address the socio-economic and ecological trade-offs associated with virtual land transfers. Future work should incorporate indicators of inequality, ecological vulnerability (e.g., soil erosion, nitrogen depletion), and social fragility to reveal the hidden costs of land displacement and better inform equitable land governance.

Finally, this study focuses on domestic land telecoupling within China. However, in the context of expanding global trade, international virtual land flows are increasingly critical. Future research should link China’s domestic MRIO system with global databases, such as EXIO-BASE or GTAP, to assess the full scale and impacts of international land imports and exports. This will provide a more comprehensive understanding of China’s role in global land-use redistribution and sustainability governance.

# 6. Conclusions

This study addresses the critical issue of spatially decoupled land-use dynamics in China through a telecoupling lens, aiming to identify the spatiotemporal characteristics and driving mechanisms underlying virtual land transfers among Chinese provinces. Our findings demonstrate significant increases in virtual land flows, driven by regional disparities in production efficiency, consumption patterns, and economic growth, which in turn lead to intensified ecological pressures in inland provinces. The telecoupling approach enhances our understanding by explicitly quantifying interregional dependencies, highlighting the urgent need for integrated, cross-regional land governance frameworks and tailored policy measures. By integrating virtual land metrics into spatial planning and developing targeted ecological compensation schemes, policymakers can mitigate unintended environmental consequences and promote sustainable regional development. Future research should incorporate dynamic modeling and global telecoupling analyses to provide deeper insights into the broader international implications of land-use transformations.

# Appendix A. Supporting information

Supplementary data associated with this article can be found in the online version at doi:10.1016/j.landusepol.2025.107709.

