# Modeling Atlantic herring fisheries as multiscalar human-natural systems

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:31:05.049252+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Carlson et al. - 2021 - Modeling Atlantic herring fisheries as multiscalar human-natural systems.pdf
- Year: unknown
- DOI: 10.1016/j.fishres.2020.105855
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper examines Atlantic herring fisheries as interconnected human-natural systems operating simultaneously at local, regional, and distant scales, using the metacoupling framework. The study area spans 27 exclusive economic zones (EEZs) in the North Atlantic, with detailed quantitative analysis for 17 EEZs in northern and western Europe and northeastern North America.

The authors treat herring catches from 1950 to 2014 as flows between coupled systems: Type 1 (countries fishing in their own EEZs), Type 2 (countries fishing in neighboring EEZs), and Type 3 (countries fishing in non-adjacent EEZs). They disaggregate catches by sector (industrial, artisanal, subsistence, recreational) using Sea Around Us reconstructed data, while explicitly assessing uncertainty. Time-series relationships and future trends are analyzed with ARIMA models that both capture autocorrelation and include other fishing sectors as external regressors.

Total herring catches are dominated by industrial fleets (over 90 percent of tonnage), with Type 1 and Type 2 industrial fishing together accounting for the vast majority of harvests. On average, fishing within a country’s own EEZ is slightly larger than fishing in adjacent EEZs, but Type 2 industrial fishing is the leading catch type in more than half the EEZs, especially in the more crowded Baltic Sea. Type 3 distant-water catches are relatively minor. Many EEZs show stable catches over the 65-year period, and model projections indicate mostly stable future catches to 2030, though some declines are expected, particularly for small-scale sectors.

The study finds predominantly positive statistical associations between artisanal and local industrial catches, but also identifies cases where industrial fishing in neighboring or distant EEZs is linked to reduced artisanal catches. Declining or vulnerable subsistence and artisanal sectors in countries such as Norway, Germany, and Sweden raise concerns for livelihoods and food and nutrition security.

This work is explicitly about metacoupling and telecoupling: it operationalizes the metacoupling framework with quantitative models, demonstrating how intra-EEZ, cross-border, and distant interactions among fishing sectors shape ecological outcomes, economic returns, and social equity in a highly interconnected marine fishery.

## Structured Metacoupling Extraction

### Coupling Classification
- Explicit metacoupling analysis of Atlantic herring fisheries across intra, adjacent, and distant EEZs.

### Intracoupling
#### Systems
- Individual EEZ herring social ecological systems
- National herring fisheries within own EEZ
- Industrial, artisanal, subsistence, recreational sectors per EEZ
#### Flows
- Type 1 catches within EEZ waters
- Local fish, money, information flows among sectors
- Subsistence harvests for household consumption
#### Agents
- Industrial, artisanal, subsistence, recreational fishers
- National fisheries agencies and managers
- Local fishing communities and processors
#### Causes
- National policies and management plans for herring
- Economic demand for fishmeal, fish oil, food
- Technological change in fleets and gear
#### Effects
- Changes in stock status and local catches
- Impacts on income, employment, cultural traditions
- Food and nutrition security for local populations

### Pericoupling
#### Systems
- Neighboring EEZs in Baltic, North Sea, North Atlantic
- Regional European herring fisheries network
- Shared forage fish ecosystems across borders
#### Flows
- Type 2 industrial catches in adjacent EEZs
- Cross border fish trade and market links
- Information and regulations via regional bodies
#### Agents
- Regional fisheries management organizations
- Neighboring national fleets fishing each others EEZs
- EU institutions and OSPAR governance bodies
#### Causes
- Geographic proximity of herring stocks and nations
- Regional access agreements and EU policies
- Effort reallocation after stock changes or collapses
#### Effects
- Type 2 dominated catches in many Baltic EEZs
- Competition between artisanal and regional industrial fleets
- Regional resilience to illegal distant water fishing

### Telecoupling
#### Systems
- Distant EEZs across North Atlantic
- Global markets for herring products
- International policy arenas on fisheries
#### Flows
- Type 3 industrial catches in distant EEZs
- Exports of herring, fishmeal, fish oil
- Diffusion of metacoupling concepts and models
#### Agents
- Distant water industrial fleets
- International organizations like FAO and IPCC
- Sea Around Us reconstruction experts
#### Causes
- Global demand for cheap animal protein and feed
- Telecoupling theory expansion to metacoupling
- Historical absence of EEZ boundaries before UNCLOS
#### Effects
- Relatively small but nonzero distant catches
- Limited exposure to severe distant water exploitation
- Inclusion of distant interactions in management scenarios

### Cross-Coupling Interactions
- ARIMA models linking Type 1, 2, 3 catches and sector interactions per EEZ
- Positive and negative cross scale effects, notably on artisanal sectors
- Metacoupling diagrams comparing flows and relationships across 17 EEZs

### Research Gaps or Limitations
- Catch reconstructions uncertain, especially recreational and subsistence sectors
- ARIMA cannot capture unexpected shocks like regime shifts or jellyfish outbreaks
- Need broader quantitative tools and inclusion of metacouplings in policy practice

### Search Keywords
- Atlantic herring metacoupling EEZ industrial artisanal subsistence recreational
- Type 1 Type 2 Type 3 fisheries ARIMA Sea Around Us
- cross scale social ecological fisheries management telecoupling

### Extraction Confidence
high
