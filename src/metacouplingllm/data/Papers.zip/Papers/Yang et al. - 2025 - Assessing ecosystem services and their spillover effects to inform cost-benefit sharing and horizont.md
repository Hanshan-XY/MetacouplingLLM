# Assessing ecosystem services and their spillover effects to inform cost-benefit sharing and horizont

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:14:32.645544+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Yang et al. - 2025 - Assessing ecosystem services and their spillover effects to inform cost-benefit sharing and horizont.pdf
- Year: unknown
- DOI: 10.1016/j.ecoser.2025.101764
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper analyzes how ecosystem services from the Qilian Mountains in northwestern China generate benefits far beyond the mountain region, and how these spillovers can guide fair horizontal ecological compensation (HEC) among regions.

The study focuses on eight services: material production, water retention, soil conservation, flood regulation, carbon sequestration, sandstorm prevention, pollination, and tourism-leisure. Using multi-source data (remote sensing, meteorological, hydrological, soil, statistical yearbooks, tourism and pollination data) from about 1980-2020, the authors apply InVEST, CASA, and RWEQ models plus Gross Ecosystem Product accounting to quantify both biophysical outputs and monetary values. They then adapt the breaking point model and field strength theory, commonly used for regional economic interactions, to estimate spatial spillover distance, intensity, and beneficiary areas at multiple scales.

Results show soil conservation, water retention, and carbon sequestration dominate the overall service value, mainly supplied by forest and grassland ecosystems. Natural vegetation also plays the leading role in flood regulation and sandstorm control. Within Gansu Province, services from Qilian extend to many downstream cities, especially along the Hexi Corridor, benefiting several million people through water regulation, agricultural support, dust control, and tourism. At a wider Chinese scale, the Yellow River Basin emerges as a major beneficiary region, with over 100 million people indirectly supported by Qilian ecosystem functions. Telecoupled links appear through global carbon sequestration benefits, international tourism, and regional trade in agricultural and livestock products along Belt and Road corridors.

The paper explicitly links these multi-scale flows to metacoupling/telecoupling concepts, treating Qilian as a sending system and distant social-ecological systems as receiving systems. It proposes three HEC pathways: within-province watershed arrangements, cross-province compensation within and beyond the Yellow River Basin, and future international mechanisms tied to carbon markets, ecological product trade, and ecotourism. The work is therefore directly about metacoupling and provides a quantitative basis and policy-oriented framework for cost-benefit sharing across coupled human-natural systems.

## Structured Metacoupling Extraction

### Coupling Classification
- Study explicitly analyzes intra-, peri-, and telecoupled ecosystem service flows and related compensation.

### Intracoupling
#### Systems
- Qilian Mountains ecosystems within Gansu Province
- Upstream mountain catchments and downstream Hexi Corridor cities
- Forests, grasslands, croplands, wetlands mosaics
#### Flows
- Water retention, soil conservation, flood regulation within provincial boundaries
- Local material production and pollination supporting nearby agriculture
- Tourism and leisure flows from Qilian Mountains to provincial residents
#### Agents
- Gansu provincial and county governments
- Upstream rural communities and herders
- Downstream urban residents and tourists
#### Causes
- Topography and climate driving water and sediment processes
- Land use and ecological restoration policies in mountains
- Demand for water, food, recreation from provincial cities
#### Effects
- Ecological benefits concentrated upstream, economic benefits downstream
- Environmental injustice and under-compensation of mountain residents
- Basis for intra-provincial horizontal ecological compensation schemes

### Pericoupling
#### Systems
- Qilian Mountains and Yellow River Basin provinces
- Qilian Mountains and neighboring Qinghai, Ningxia, Inner Mongolia
- Middle and lower Yellow River cities and agricultural areas
#### Flows
- Regional-scale water retention and soil conservation spillovers
- Sandstorm prevention from mountains to downwind provinces
- Interprovincial tourism oriented to Qilian Mountain landscapes
#### Agents
- Multiple provincial governments in Yellow River Basin
- Water, forestry, and ecological agencies across provinces
- Interprovincial tourists and agricultural producers
#### Causes
- Cross-provincial hydrological and wind connectivity
- Economic reliance of downstream basins on upstream regulation services
- Emerging cross-provincial HEC policies in China
#### Effects
- About 107 million people benefit from regional spillovers
- Need for interprovincial cost-benefit sharing mechanisms
- Development of cross-basin horizontal compensation agreements

### Telecoupling
#### Systems
- Qilian Mountains and global climate system
- Qilian Mountains and international tourism markets
- Qilian agricultural-pastoral production and Belt and Road countries
#### Flows
- Vegetation and soil carbon sequestration as global public good
- International tourist visits to Qilian national park region
- Export of livestock, crops, and medicinal products to foreign markets
#### Agents
- International tourists and tourism operators
- Foreign consumers and traders along Belt and Road
- Global climate and conservation finance institutions
#### Causes
- Global demand for nature-based tourism and green products
- China climate targets and recognition of Qilian carbon sinks
- Infrastructure and trade links to Central Asia and Europe
#### Effects
- Global beneficiaries of Qilian carbon sinks without direct payment
- Opportunities for international eco-compensation and carbon trading
- Potential to support SDGs on climate, poverty, and ecosystems

### Cross-Coupling Interactions
- Internal, regional, and global spillovers overlap, creating multi-scale beneficiary networks
- Domestic HEC design must consider simultaneous regional and global beneficiaries
- Tourism, carbon, and production services link intra-, peri-, and telecoupling domains

### Research Gaps or Limitations
- Models simplify glacier, permafrost, and grazing impacts on services
- Limited local data constrain parameter accuracy in mountain environments
- Need broader indicators and multisector data sharing for mature mechanisms

### Search Keywords
- Qilian Mountains ecosystem service spillover
- horizontal ecological compensation China
- metacoupling water retention carbon sequestration tourism

### Extraction Confidence
high
