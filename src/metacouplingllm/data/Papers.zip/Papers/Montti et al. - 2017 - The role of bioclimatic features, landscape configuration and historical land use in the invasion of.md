# The role of bioclimatic features, landscape configuration and historical land use in the invasion of

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:59:51.301936+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Montti et al. - 2017 - The role of bioclimatic features, landscape configuration and historical land use in the invasion of.pdf
- Year: unknown
- DOI: 10.1007/s10980-017-0563-2
- OA status: green
- License: cc-by-nc-sa
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: green OA but only submittedversion version available

## Copyright-Safe Summary
This paper analyzes how climate, landscape configuration, and land-use history shape the invasion of the Asian tree Ligustrum lucidum (Chinese glossy privet) in the Yungas ecoregion of northwestern Argentina. The study area includes humid subtropical forests around the main cities of San Miguel de Tucuman, Salta, and San Salvador de Jujuy, with a detailed local analysis near San Miguel de Tucuman and Sierra de San Javier.

The authors use a multiscale design. At the regional scale, they build a species distribution model with Maxent, using presence records and WorldClim variables, to estimate climatic suitability. At a sub-regional scale, they classify multi-temporal Landsat imagery (support vector machines, NDVI, terrain data) to map monodominant L. lucidum forests around three cities. At the local scale, they combine their 2010 invasion map with a time series of land-cover maps (1972-2010, Random Forest classifications) and apply landscape metrics, distance analyses, and logistic regression to link invasion patterns to environmental variables and historical land use.

Climatic modeling indicates that much of the Yungas is suitable for L. lucidum, yet actual forests are confined to three invasion hotspots around major cities. In 2010, invaded forest covered a small share of total forest area but was concentrated in numerous patches, especially in Sierra de San Javier. Invasion probability is higher at moderate elevations, on gentle slopes, near roads, rivers, urban areas, and preexisting Ligustrum stands, and strongly reflects a contagious spread from early foci. Over recent decades, the species expanded mainly into abandoned citrus plantations and montane grasslands, with distinct pulses linked to changes in land use and protection status.

The paper explicitly frames these dynamics as part of telecoupled cultural landscapes: historical and contemporary social-economic links between Asia and Argentina enabled introduction and proliferation of L. lucidum, while urban growth, infrastructure, and land abandonment control its spread. It is thus directly relevant to telecoupling/metacoupling theory, highlighting cities as key nodes connecting distant species sources, regional land-use decisions, and local ecological change.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling; intra- and peri-coupling in Argentine Yungas via cities and land-use change.

### Intracoupling
#### Systems
- Yungas ecoregion forests and peri-urban landscapes in northwest Argentina
- Peri-urban cluster around San Miguel de Tucuman and Sierra de San Javier
- Citrus plantations, sugarcane, grasslands, native montane forests within SSJ
#### Flows
- Local seed dispersal of Ligustrum via birds and gravity within invaded landscapes
- Human-driven movement of propagules within cities and nearby farms
- Land-use transitions from agriculture and grasslands to Ligustrum forests
#### Agents
- Local residents, farmers, landowners, urban planners in northwest Argentina
- Bird species dispersing Ligustrum seeds across local habitats
- Universities, conservation agencies managing Sierra de San Javier reserve
#### Causes
- Abandonment or disintensification of agriculture and grazing near cities
- Protected-area creation and land expropriation enabling forest regrowth
- Road and river networks creating dispersal corridors for invasive trees
#### Effects
- Expansion of monodominant Ligustrum forests over former crops and grasslands
- Replacement of native Yungas forest and altered successional dynamics
- Increased forest patch coalescence and changed landscape configuration

### Pericoupling
#### Systems
- Major Andean foothill cities and their immediate peri-urban belts
- Adjacent agricultural frontiers around Salta, Jujuy, Tucuman
- Cultural tourism and residential areas in Sierra de San Javier
#### Flows
- Ornamental and live-fence planting from urban centers into rural margins
- Urban expansion driving abandonment of marginal foothill agriculture
- Short-distance trade and transport spreading propagules along roads
#### Agents
- Municipal governments and urban forestry programs
- Nurseries, gardeners, homeowners selecting Ligustrum plantings
- Transport and tourism operators using mountain roads
#### Causes
- Urban growth, population density, and wealth increasing ornamental planting
- Scaling relationships between city size and invasion extent
- Peri-urban land-price changes making farming less competitive
#### Effects
- Invasion hotspots clustered around largest cities and peri-urban zones
- Higher invasibility of abandoned fields and citrus plantations near towns
- Creation of novel peri-urban forests dominated by an Asian tree

### Telecoupling
#### Systems
- Native Ligustrum region in southern China and East Asia
- Receiving socioecological systems in Argentina, especially Yungas
- Historical Asia–Europe–Americas trade networks including colonial routes
#### Flows
- Long-distance introduction of Ligustrum as ornamental and utility tree
- Historical exchange of crops, medicines, and cultural practices between China and Americas
- Contemporary global trade, migration, and information linking China and Argentina
#### Agents
- Historical traders and colonial authorities organizing transoceanic commerce
- Modern plant trade sector providing ornamental stock
- Asian diaspora communities influencing plant and garden choices
#### Causes
- Centuries of socio-economic teleconnections along silk and silver routes
- Globalization of horticulture and landscaping preferences
- Demand for pollution-tolerant, fast-growing urban trees
#### Effects
- Establishment of Ligustrum in Argentine cities far from native range
- Creation of telecoupled cultural landscapes enabling biological invasions
- Time-lagged ecological impacts emerging long after initial introductions

### Cross-Coupling Interactions
- Telecoupled introduction from China interacts with peri-urban land abandonment to trigger local invasion.
- Urban-scale propagule pressure amplifies climate-suitable areas revealed by regional niche modeling.
- Historical trade legacies combine with present urban scaling to shape invasion hotspots.

### Research Gaps or Limitations
- Remote sensing missed young or mixed Ligustrum stands and very small patches.
- Study covers part of species global range; broader-scale climatic drivers underexplored.
- Mechanistic links between city size, socioeconomics, and invasion intensity remain unclear.

### Search Keywords
- Ligustrum lucidum invasion northwest Argentina peri-urban Yungas
- telecoupled cultural landscapes invasive trees cities
- land-use change citrus plantations roads rivers propagule pressure

### Extraction Confidence
high
