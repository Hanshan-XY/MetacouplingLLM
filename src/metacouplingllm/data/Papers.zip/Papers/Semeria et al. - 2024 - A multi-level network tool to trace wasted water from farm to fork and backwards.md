LETTER • OPEN ACCESS

# A multi-level network tool to trace wasted water from farm to fork and backwards

To cite this article: Francesco Semeria et al 2024 Environ. Res. Lett. 19 074026

View the article online for updates and enhancements.

# You may also like

Evaluation of three approaches used for respiratory measurement in healthy subjects   
Xiaojuan Duan, Xin Song, Caidie Yang et al.   
Eating healthy or wasting less? Reducingresource footprints of food consumption Hanna Helander, Martin Bruckner, Sina Leipold et al.   
Limiting food waste via grassroots initiatives as a potential for climate change mitigation: a systematic review Nikravech Mariam, Kwan Valerie, Dobernig Karin et al.

![](images/135a831992b3e989c06256b8d2876b78e8f706507cad670083b2b004e3d0369b.jpg)

![](images/dcc595f0d2c0f8d68aa94f09189b7451f9b0fbcc914907aef2839444a945a99d.jpg)

# ENVIRONMENTAL RESEARCH

LETTERS

![](images/f1733e7807db179f15c58ae8e81bc3a7de06052f5fdc32b9c38090e518550ddb.jpg)

CrossMark

# OPEN ACCESS

# LETTER

# A multi-level network tool to trace wasted water from farm to fork and backwards

RECEIVED

15 January 2024

REVISED

10 May 2024

ACCEPTED FOR PUBLICATION

10 June 2024

PUBLISHED

17 June 2024

Original content from this work may be used under the terms of the Creative Commons Attribution 4.0 licence.

Any further distribution of this work must maintain attribution to the author(s) and the title of the work, journal citation and DOI.

![](images/ee9893470c7a4336b58f75fd765d74f4416f945b0325356bd1cf2e7b5d8c06d0.jpg)

Francesco Semeria∗, Luca Ridolfi and Marta Tuninetti

Department of Environment, Land and Infrastructure Engineering, Politecnico di Torino, Turin, Italy ∗ Author to whom any correspondence should be addressed.

E-mail: francesco.semeria@polito.it

Keywords: water-food nexus, food loss, food waste, wheat trade, water footprint, multi-layer networks Supplementary material for this article is available online

# Abstract

Food loss and waste (FLW) is an issue of great public concern, due to its major impact on food security and on the social, economic and environmental resources involved in food production, trade and consumption. In this work, we put the lens on water resources, as those lost in the different stages of FLW represent about a quarter of the total freshwater resources used in food crop production. To this end, we propose the NETFLOW model (Network-based Evaluation Tool for Food LOss and Waste) as an innovative tool capable of reconstructing, for each commodity, the complex global multi-layered network linking FLW at each stage of the value chain with the corresponding wasted water resources. Food re-exports, nested supply chains, telecoupling of food markets, and different levels of food transformation are taken into account. Focusing on the emblematic case of wheat and its derived food commodities (e.g. flour, bread, pasta), we show the complexity and extent of the FLW-linked water network. For example, in 2016, more than 100 countries used their water resources (almost $3 \mathrm { k m } ^ { 3 }$ ) to produce wheat which was ultimately lost or wasted along the food consumption value chain in Italy, with almost half of this amount being directly attributable to the bread value chain. On the supply side, we show that about $1 8 . 3 \mathrm { k m } ^ { 3 }$ of water resources in the U.S. were lost through wheat-related FLW in 144 countries, about $4 0 \%$ for flour, $2 7 \%$ for raw wheat (mainly used for feed), and $2 4 \%$ for bread. The NETFLOW model proves useful in unravelling the complex links between (i) product-specific global trade networks, (ii) primary and derived products, (iii) country- and stage-dependent FLW, and (iv) country- and product-specific virtual water content.

# 1. Introduction

Adequately feeding the world’s population is one of the most challenging tasks facing humanity [1]. In recent years, undernourishment has been on the rise again, following a decade-long decline until 2010. There are currently about 750 million undernourished people in the world [2]. There is an urgent need to implement integrated food security strategies that address the entire agri-food system, from production to consumption [3, 4].

Research efforts have focused on increasing food production, shifting to less resource-intensive diets, and reducing food loss and waste (FLW) [5–7]. The potential for reducing FLW appears to be considerable: the FAO and UNEP estimate that about one

third of the world’s food (by mass) is lost or wasted each year [8, 9]. Previous studies have shown that, if food crop losses would be halved, one billion extra people could be fed and about $7 8 ~ \mathrm { k m }$ [3] of water withdrawals could be avoided [10]. In addition, the halving of FLW is expected to bring significant socioeconomic benefits, both in terms of increased GDP and of poverty alleviation, thereby promoting sustainable development [11, 12].

At the global level, about $2 4 \%$ of the food supply (614 kcal/cap/day) is lost or wasted within the food value chain [10]. There are large variations between regions of the world: in North America & Oceania FLW reaches 1334 kcal/cap/day $3 2 \%$ of the food supply), while the lowest levels are found in South & Southeast Asia (404 kcal/cap/day, $1 8 \%$ ). In

high-income countries food is wasted mainly at the distribution and consumption stages, while in lowincome countries losses are concentrated in the agricultural and post-harvest stages [13, 14]. Losses in the early stages of the supply chain are usually related to low levels of mechanization of processes, unreliable transport services and lack of cooperation among farmers, issues that can be addressed through targeted investment in technology and knowledge transfer [13–15]. On the distribution and consumption side of the value chain, waste is mainly driven by consumer behavior, so actions to reduce and save should focus on public awareness [13, 15–17], supported by targeted public policies [18].

As agriculture accounts for about $7 0 \%$ of global freshwater withdrawals [19], FLW has a significant impact on water resources, beyond the social and economic dimensions. Nearly a quarter (about 175 million $\mathrm { m } ^ { 3 }$ per year) of freshwater resources used for food crop irrigation is eventually lost in FLW [10]. This figure highlights both the environmental burden of inefficiencies in the food value chain and the wider sustainability potential of reducing them [20]. Previous studies illustrated the implications of globalization and telecoupling in food markets [21, 22], focusing on dietary changes [23], supply shocks [24, 25], environmental degradation [26–28] and extreme events [29]. However, we still have limited insight into tracing the impacts of FLW along complex trade networks back to the countries of primary production, where water resources are used.

This work presents a novel quantitative approach to trace the impact of FLW on water resources, unravelling recursive loops in trade networks, where multi-level systems (i.e. one level per food item) are combined with the FLW of the value chain. We propose a novel modelling tool (NETFLOW—Networkbased Evaluation Tool for Food LOss and Waste) capable of distinguishing between primary and derived food commodities, and coupled with the CWASI crop water footprint database [30]. The tool also takes into account the different stages of the value chain where FLW occurs. These two key features of NETFLOW— i.e. item by item analysis and systematic description of FLW stages—differentiate our tool from previous studies, which typically convert derived products into primary equivalents and consider only some stages of the value chain or their aggregations [30–35]. Newly, we show that there are large differences in commodity trade networks and that FLW at different stages of the supply chain may impact different countries, and thus water resources, in different networks. To illustrate the application of this methodology, we have chosen wheat and its derived food commodities. Wheat was chosen because of its key role among cereals, which in turn account for more than half $( 5 7 \% )$ of the total FLW impact on freshwater resources [10], and because of the marked differences in the trade networks of its products.

# 2. NETFLOW rationale

# 2.1. Data sources

To define losses and waste occurring at different stages of the food value chain, we adopt the 5-stage classification widely used in the literature [10, 13, 14]: (i) agricultural losses, due to mechanical damage and/or spillage during harvesting and grading; (ii) postharvest losses, due to storage and transport between farm and distribution, and spillage and degradation during handling; (iii) processing losses, due to industrial or domestic processing; (iv) distribution waste, occurring in the market system, including wholesale markets, supermarkets, retailers, and wet markets; and (v) consumption waste, at the household level. In particular, in this work we have used the regional FLW shares from Gustavsson et al [13], for the Cereals commodity group (see table SM1).

From FAOSTAT, we obtain the agricultural supply and utilization data for wheat and its derived products [2]. Moreover, we obtain the additional estimates of food consumption of derived products missing from FAOSTAT from the Statista database [36]. Trade matrices $( Z )$ for each food commodity are taken from Tamea et al [30]: elements $z _ { i j }$ quantify the quantities (in tons) of food traded from country j to country i in any given year [30]. These matrices reconcile the bilateral trade flows of agricultural commodities reported by the FAO, correcting for inconsistencies in declarations of trade flows between exporters and importers in the original records. The wheat commodity tree includes the following commodities: (i) raw wheat, (ii) wheat flour, (iii) wheat bran, (iv) bread, and (v) pasta. These commodities cover more than $9 6 \%$ of processed primary wheat’s products and over $4 0 \%$ of processed wheat’s secondary products globally.

In order to evaluate the virtual water content [37] of FLW we refer to unit water footprints of wheat production $( u W F p )$ , which measure the amount of water required in each country to produce a unit amount of primary product (expressed in $\mathrm { m } ^ { 3 } / \mathrm { t }$ or $1 \mathrm { k g } ^ { - 1 } .$ ). The present work considers the sum of green water footprint (from rainfall) and blue water footprint (from surface water and groundwater bodies), obtained from the CWASI database [30] and mapped in figure SM1. For each crop c, the $u W F p$ value for a generic year $t$ in CWASI is calculated based on the fast-track approach developed by Tuninetti et al [38], as follows:

$$
u W F p _ {c, t} = \overline {{u W F p}} _ {= c, T} \cdot \frac {\bar {Y} _ {c , T}}{Y _ {c , t}} \tag {1}
$$

where $\overline { { u W F p } } _ { c , T }$ is a 10 year average $u W F p$ in country $c$ in the period $T = 1 9 9 6 { - } 2 0 0 5$ , used as reference (from Mekonnen and Hoekstra [39]), $\bar { Y } _ { c , T }$ is the average crop yield over the same period $T$ and $Y _ { c , t }$ is the annual crop yield in a generic year t. Crop yield,

![](images/27e99f8fbee2efc618264a3429311dc18859dc343bd0f71fd2e70674fe6a8c3b.jpg)  
Figure 1. Scheme of flow of a generic food supply chain, as modelled in NETFLOW. From gross food production of primary products (top layer), food wastes and losses (in red) occur along the chain, reducing the quantity to the one being consumed as food intake. Import, export and other outflows also need to be considered, after domestic agricultural and post-harvest losses are accounted for. Primary products are connected to derived products (mid and bottom layers) through processing. Note that many layers of derived products can be present between lv. 1 and lv. Z, as different processing activities may occur.

which depends upon meteo-climatic conditions and technology adopted for farming, is found to be the most important driver for country-scale $u W F p$ , while crop water requirements (evapotranspiration) appear exert a marginal effect [38, 40]. The whole analysis is conducted for the year 2016, which represents the most recent period for which published CWASI data about the unit water footprints of wheat production were accessible.

# 2.2. Modelling food loss and waste along the supply network

This work advances the methodology used in Kummu et al [10], which in turn already extended the one proposed in the pioneering study by Gustavsson et al [13]. The two main elements of novelty are (i) the discretization between the individual food commodities and (ii) the application of the algorithm proposed by Kastner et al [31] to each food commodity. To track FLW across different products, within NETFLOW we model food commodities within each country as interrelated variables linked by processing (figure 1), dividing them into (i) primary products (level 0) and (ii) derived products, produced after primary products (level 1) or from other derived products (level 2 and following). All products can be both processed and consumed raw. This hierarchical organization, created by integrating the multilevel network of wheat products with the supply chain linking producers to consumers, allows us to attribute the different stages of FLW to distinct food commodities and to observe flow relationships between

products, improving on previous methodologies that lumped together primary and derived commodities. We allocate FLW quantities to countries, according to the stage of the food value chain to which they contribute, as follows: (i) for the agricultural and postharvest stages, to the country of production; (ii) for the processing stage, to the country of processing; and (iii) for the distribution and consumption stages, to the country of consumption.

For primary products, the top layer in figure 1, we calculate agricultural losses $\cdot  { L _ { S 1 } } ^ { 0 }$ , the apex denoting the level 0 of the product hierarchy) after net domestic production $( P _ { N } ^ { 0 } )$ as in Gustavsson et al [13]:

$$
L _ {S 1} ^ {0} = \frac {l _ {S 1} ^ {0}}{1 - l _ {S 1} ^ {0}} \cdot P _ {N} ^ {0} \tag {2}
$$

where $l _ { S 1 } ^ { 0 }$ indicates the specific share of agricultural losses of the region to which the country belongs. Gross domestic primary production $( P _ { G } ^ { 0 } )$ is the sum of net domestic production and agricultural losses (i.e. $P _ { G } ^ { 0 } = P _ { N } ^ { 0 } + L _ { S 1 } ^ { 0 } )$ ). Post-harvest losses $( L _ { S 2 } ^ { 0 } )$ are then computed as a share $( l _ { S 2 } ^ { 0 } )$ of net primary production:

$$
L _ {S 2} ^ {0} = l _ {S 2} ^ {0} \cdot P _ {N} ^ {0}. \tag {3}
$$

The post-harvest product quantity $( H ^ { 0 } )$ is obtained by simply deducting post-harvest losses from net primary production. It should be noted that agricultural and post-harvest losses only impact domestic water resources. The following three stages

of loss and waste (processing, distribution, consumption) instead, impact countries’ domestic supply $( D ^ { 0 } )$ , which is constituted by post-harvest quantities originating from domestic production $( H ^ { 0 } )$ and imports from the international trade network $( I ^ { 0 } )$ , after subtracting exported quantities $( E ^ { 0 } )$ :

$$
D ^ {0} = H ^ {0} + I ^ {0} - E ^ {0}. \tag {4}
$$

After accounting for changes in the domestic supply given by stock variations $( \Delta ^ { 0 } )$ , we refer to it as adjusted domestic supply $( D _ { \mathrm { a d j } } ^ { 0 } )$ ). Different utilizations are present, as shown in figure 1: quantities directed to food consumption $( C ^ { 0 } )$ , quantities directed to processing $( T ^ { 0 } )$ , quantities destined to non-food uses $( U ^ { 0 } )$ , feed $( F ^ { 0 } )$ , seed $( S ^ { 0 } )$ and residuals $( R ^ { 0 } )$ :

$$
D _ {a d j} ^ {0} = T ^ {0} + C ^ {0} + U ^ {0} + F ^ {0} + S ^ {0} + R ^ {0}. \tag {5}
$$

Quantities directed to food consumption are subject to distribution losses $( L _ { S 4 } ^ { 0 } )$ , calculated as usual through the share parameter $l _ { S 4 } ^ { 0 }$ :

$$
L _ {S 4} ^ {0} = l _ {S 4} ^ {0} \cdot C ^ {0}. \tag {6}
$$

The quantity $A ^ { 0 }$ , representing primary crops that are brought to the consumer as food, can be derived by reducing $C ^ { 0 }$ by the quantity of $L _ { S 4 } ^ { 0 }$ . The last stage of food waste $( L _ { S 5 } ^ { 0 } )$ , related to consumption waste, is determined as a share $( l _ { S 5 } ^ { 0 } )$ of it:

$$
L _ {S 5} ^ {0} = l _ {S 5} ^ {0} \cdot A ^ {0}. \tag {7}
$$

For quantities directed to processing $( T ^ { 0 } )$ instead, only specific processing losses $( L _ { S 3 } ^ { 0 } )$ need to be considered, the latter being a share (regulated by parameter $l _ { S 3 } ^ { 0 }$ ) of the former:

$$
L _ {S 3} ^ {0} = l _ {S 3} ^ {0} \cdot T ^ {0}. \tag {8}
$$

To link level-1 derived food commodities to primary ones, we assume that processed quantity $B ^ { 0 } = T ^ { 0 } - L _ { S 3 } ^ { 0 }$ is equivalent to the cumulative production quantity of the level-1 derived products, since FAOSTAT data are already adjusted for extraction rates:

$$
B ^ {0} = \sum P _ {i} ^ {1}. \tag {9}
$$

For the example of wheat, it means that processed raw wheat must be equal to the sum of the production quantities of wheat’s derived products of level 1 (flour and bran). The same assumption also enables the connection between derived products at level $n$ and those at the preceding level $( n - 1 )$ .

For level-1 derived products, losses are defined in a similar way as they are for primary ones, as displayed in figure 1. Of course, neither agricultural $( L _ { S 1 } ^ { 1 } )$ nor

post-harvest $( L _ { S 2 } ^ { 1 } )$ losses are present, as they are specific of primary products. Domestic supply for level 1 derived products is then computed as follows:

$$
D ^ {1} = P ^ {1} + I ^ {1} - E ^ {1} \tag {10}
$$

where $P ^ { 1 }$ is defined as the domestic production of a derived product of level 1, $I ^ { 1 }$ indicates the imports from the countries’ international trade network and $E ^ { 0 }$ the exports. Losses $L _ { S 3 } ^ { 1 }$ and waste $L _ { S 4 } ^ { 1 }$ and $L _ { S 5 } ^ { 1 }$ are calculated using the same methodology as for the corresponding variables related to primary products.

Several levels of derived products can be present in a single commodity tree. Eventually, at the leaflevel (level Z) of the tree, only products which do not undergo further processing are present. Then, at level Z, no processing losses $( L _ { S 3 } ^ { Z } )$ are present, and only distribution- and consumer-level waste $\langle L _ { S 4 } ^ { Z }$ and $L _ { S 5 } ^ { Z }$ ) are to be considered.

As highlighted in the previous section, FLW occurring in a country can affect both domestic and foreign water resources, depending on the stage of the value chain and the supply network of countries for the specific food commodity. Bilateral trade matrices allow the quantification of imports and exports of food commodities between countries. However, countries often re-export products that they themselves have imported, creating feedback loops within the network. Without knowing more about the composition of each country’s supply, determining the true origin of its exports (whether imports or domestic production) becomes problematic. To add to the complexity, there may be different trading layers in the network, one for the primary product and one for each of the derived commodities, linked by processing. To overcome these challenges in the modelling of agri-food systems, Environmentally Extended Multi-Regional Input-Output (EE-MRIO) models are often employed [41–43], providing a thorough description of material flows in global supply chains, but introducing additional uncertainties due to known limitations of completeness and aggregation [44]. Parallel to this approach, a less data-intensive methodology was proposed by Kastner et al [31] and has been widely adopted to trace cultivation-related environmental impacts along food value chains [42, 45–49]. The assumption behind the algorithm is that a country’s consumption originates in proportional shares from its own production and its imports. This implies that the same proportions are maintained in a country’s exports, with this simplification effectively identifying a trade network that the countries of production to those of consumption, addressing the issue of re-export (see the supplementary material for a more detailed description of the algorithm). By feeding production vectors and reconciled bilateral trade matrices to the

algorithm proposed in Kastner et al (2010), we define a new network for each food commodity, in which consuming countries are linked to the countries of actual production (e.g. it is possible to quantify the amount of wheat consumed in Italy that has been grown in Canada, or the amount of flour consumed in France that has been milled in Australia). A nested application of the algorithm allows us to connect the different networks and trace the origin of FLW across the hierarchical levels of the commodity tree (e.g. to quantify the amount wheat grown in the U.S. that has been wasted as bread at the distribution stage in Germany).

Once the relationship between food-producing and FLW-producing countries is established, it is possible to quantify the virtual water trade between them, by simply multiplying the quantities of food commodities produced by each country by the value of their specific water footprint per unit of production $( u W F p )$ .

# 3. Results

The NETFLOW modelling tool assesses FLW and associated water wastage by reconstructing a network for each food commodity analyzed. It provides a dual perspective on the geography of each stage of FLW: (i) from fork to farm, it reconnects the FLW associated with the consumption of food in a given country or region back to the countries of production, (ii) from farm to fork, it connects the FLW associated with the cultivation of a primary crop in each country or region forward to the countries where the FLW is generated.

To illustrate the first case, we analyze the impact on global water resources of the FLW associated with Italy’s annual food consumption of wheat and its derivatives, quantities that can be considered as the virtual water content of the FLW associated with Italy’s food consumption. In table 1 we can see the estimated water resources affected by the FLW associated with the consumption of the different products of the commodity tree, disaggregated by stage of the value chain. Between the different products, the largest amounts of virtual water (1.39 billion $\mathbf { m } ^ { 3 }$ , $4 7 \%$ of the total commodity tree) are associated with the FLW generated within bread’s value chain. Other relevant contributions come from pasta $( 3 8 \% )$ and flour $( 1 4 \% )$ , while raw wheat and bran are not relevant, since from our data sources their food consumption appears to be negligible. Along the wheat chain, the consumption stage is the one that by far had the largest impact on water resources, with $1 . 4 8 ~ \mathrm { k m } ^ { 3 }$ $5 0 \%$ of total virtual water of FLW), thus supporting interventions to reduce waste at the consumer’s scale. Processing ranked second, with $2 4 \%$ , followed by post-harvest and agriculture stages $1 3 \%$ and $8 \%$ , respectively). Distribution, comprehending

FLW generated in markets and food services, produced the lowest impact as expected, with just $4 \%$ . It is interesting to notice that, for bread, 659 million $\mathbf { m } ^ { 3 }$ of virtual water are wasted at the consumption stage alone, $5 6 \%$ more than the entire value chain of flour consumed as food (424 million $\mathrm { m } ^ { 3 }$ ).

Overall, the total water footprint of FLW associated with the wheat-based products amounts to $2 . 9 5 ~ \mathrm { k m } ^ { 3 }$ . While the largest relative share of these water resources was drawn within Italy’s borders $( 3 9 . 2 \% )$ , 109 other countries are part of its supply network. Out of these, France $( 1 2 . 1 \% )$ , the U.S. $( 6 . 9 \% )$ and Canada $\left( 6 . 6 \% \right)$ experience large impacts on their domestic water resources due to the Italian consumption. Figure 2(a) (and the related tabular data, added in table SM2) highlights the complex pattern of the FLW associated with a country’s food consumption: globalized food trade (which underpins a globalized virtual water trade) implies that consumption in a given country can have repercussions on a significant portion of the globe. This is even more interesting looking at the different stages of the value chain, in which we observe even large variations in the origin of the virtual water, due to the different networks. In the agriculture stage (figure 2(b)) larger amounts of water resources are estimated to be lost in Kazakhstan and Turkey (28.2 and 27.5 million $\mathbf { m } ^ { 3 }$ , respectively) than in France (19.8 million $\mathbf { m } ^ { 3 }$ ), due to higher inefficiencies in the food value chain (as shown in table SM1) and larger local $u W F p$ values (as visible in figure SM1). Kazakhstan is ranked third in the post-harvest stage (35.4 million $\mathbf { m } ^ { 3 }$ ), with France being second (38.9 million $\mathbf { m } ^ { 3 }$ ), as displayed in figure 2(c). In the processing, distribution and consumption stages (figures 2(d)–(f)) the ranking topological relations (i.e. the country-to-country connections) remain relatively consistent with the overall ones, while there are variations in magnitudes between the different stages, as previously shown.

For illustrating the supply-side perspective, we present the case of water resources lost in the United States due to FLW occurring worldwide and associated with the utilization of wheat-based commodities, as food, feed or other purposes. Among the items (table 2), flour is the most relevant for FLWrelated virtual water, with $7 . 4 4 ~ \mathrm { k m } ^ { 3 }$ ( $4 0 . 7 \%$ of the total). Other relevant items are raw wheat $( 2 6 . 7 \%$ , mostly due to feed utilization) and bread $( 2 3 . 9 \% )$ . Analyzing the various segments of the value chain, we note that consumption is by far the most significant, with $9 . 5 8 ~ \mathrm { k m } ^ { 3 }$ of water wasted $5 2 . 4 \%$ of the total), while processing $( 1 9 . 7 \% )$ and other stages play a less relevant role. Remarkable insights can be observed through the disaggregated data we produced: for example, household waste of flour is estimated to have the largest impact on U.S. water resources, while the water footprint attributed to bread wastage at the same stage is found to be almost twice as high as that attributed to the agricultural losses of wheat

Table 1. Virtual water resources impacted by the FLW associated with the consumption in Italy of the different items in the commodity tree, disaggregated by stage of the value chain. Since direct food intake is not present for raw wheat and bran, no impacts are considered. Numbers in parentheses represent the percentage contribution to the total.   

<table><tr><td></td><td>Agriculture (106m3)</td><td>Post-harvest (106m3)</td><td>Processing (106m3)</td><td>Distribution (106m3)</td><td>Consumption (106m3)</td><td>Total (106m3) (perc.)</td></tr><tr><td>Wheat</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>Flour of wheat</td><td>38.39</td><td>62.94</td><td>8.80</td><td>23.68</td><td>290.04</td><td>423.85 (14.38%)</td></tr><tr><td>Bran of wheat</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td></tr><tr><td>Pasta</td><td>92.90</td><td>149.24</td><td>319.31</td><td>43.05</td><td>527.36</td><td>1131.87 (38.40%)</td></tr><tr><td>Bread</td><td>110.03</td><td>177.98</td><td>390.73</td><td>53.82</td><td>659.31</td><td>1391.87 (47.22%)</td></tr><tr><td>Total (perc.)</td><td>241.33 (8.19%)</td><td>390.17 (13.24%)</td><td>718.84 (24.39%)</td><td>120.55 (4.09%)</td><td>1476.71 (50.10%)</td><td>2947.59 (100.00%)</td></tr></table>

itself. It should be noted that in our modelling framework agriculture and post-harvest losses are computed prior to the trade module so, for the U.S. (and any other producing country), they would all occur within the country’s borders.

A total of $1 8 . 3 ~ \mathrm { k m } ^ { 3 }$ of virtual water from U.S. resources were lost or wasted in a utilization network composed of 144 different countries, including the United States themselves (figure 3(a)). This arises from the FLW of both wheat produced in the U.S. and of the wheat-based food commodities that were manufactured in other countries using the American wheat. The largest share $( 7 2 . 0 \% )$ is represented by FLW occurring within the U.S. borders, but a considerable amount of virtual water was lost or wasted in Japan $( 6 . 3 \% )$ , Nigeria $( 2 . 5 \% )$ , and Mexico $( 2 . 0 \% )$ . As in the previous case, we inspected how the patterns differ when looking at the different stages of the value chain. While only domestic losses are responsible for the loss of U.S. water resources in the agriculture and post-harvest stages, as explained before, we found interesting differences in the others (figures 3(b)– (d)). While the U.S. is still ranked first in all stages, in distribution Nigeria comes second (80.3 million $\mathbf { m } ^ { 3 }$ of virtual water), due to higher inefficiencies compared to Japan (69.6 million $\mathbf { m } ^ { 3 }$ ). In the consumption stage, due to low wastage in the Sub-Saharan region, Nigeria only wasted 39.4 million $\mathbf { m } ^ { 3 }$ , far less than the U.S. $( 7 . 3 \mathrm { k m } ^ { 3 } ,$ ), Japan (682 million $\mathbf { m } ^ { 3 }$ ) and the Republic of Korea (184 million $\mathrm { m } ^ { 3 }$ ). Detailed tabular results are shown in table SM3.

A more general perspective emerges when exploring the entire global network, examining the virtual water fluxes linking countries where water resources are employed for food production which is eventually lost due to FLW (anywhere in the value chain), and countries where the consumption responsible (directly or indirectly) for the generation of that FLW is located. Globally, $1 0 1 0 . 7 \mathrm { k m } ^ { 3 }$ of water were employed for wheat cultivation in 2016. Notably, nearly onefifth of this amount, equivalent to $2 0 0 . 6 \mathrm { k m } ^ { 3 } \left( 1 9 . 9 \% \right)$ , were lost or wasted across all utilizations in wheat’s commodity tree, and the consumption of wheat and

derivatives as food accounts for about $1 6 4 . 0 ~ \mathrm { k m } ^ { 3 }$ $( 8 1 . 8 \% )$ . By dividing this last figure for the VW employed in wheat cultivation, we find that $1 6 . 2 \%$ of water resources originally available were lost or wasted: this is similar to what was observed by Kummu et al [10] for the aggregated basket of cereals $( 1 9 . 7 \% )$ . Although there are some caveats to this comparison—as our study focuses only on wheat and derivatives and considers the sum of the green and blue water footprints, whereas Kummu et al considered only the blue water footprint and aggregated all cereals into a single food basket—we take it as positive feedback that the two figures are similar. The largest fluxes are by far those associated with the Indian and Chinese food consumption ( $1 8 . 7 \%$ and $1 8 . 6 \%$ of total virtual water, respectively) on their own water resources, with the U.S. $( 5 . 4 \% )$ , Pakistan and Russia (tied at $5 . 3 \%$ ) holding other significant shares (table SM4).

Transnational fluxes (covering $2 1 . 6 \%$ of the total) are those that carry the most interesting pieces of information, allowing one to quantify the transboundary impacts of FLW. In figure 4, we displayed the most significant ones, showing countries grouped according to Gustavsson et al [13], to also capture transcontinental impacts of FLW on water resources. The largest transnational flow is the one linking water resources in Russia to the consumption of wheatbased food commodities in Egypt $( 1 . 9 \mathrm { k m } ^ { 3 } ,$ ), tied with the one connecting Argentina to Brazil, accounting for more than $1 \%$ of global water footprint of FLW. Other major transnational fluxes are those from water resources in the United States to food consumption in Japan $( 1 . 5 \mathrm { k m } ^ { 3 } \cdot$ ) and from Kazakhstan to Azerbaijan $( 1 . 3 \mathrm { k m } ^ { 3 } $ ). More in general, one can observe that the North America & Oceania region (NAO) is the one that sees the largest share $( 5 5 . 7 \% )$ of its lost water resources associated with food consumption abroad. Conversely, Industrialized Asia (INA) showed the lowest share (less than $0 . 4 \%$ ), due to a predominant domestic use of its wheat production. Sub-Saharan Africa (AFR) is the region in which the share of its consumption-related FLW had the largest impact on

![](images/1d370f2e4d55469baba0272266c75116655afbe30fd5135f47841fb6af4dcba8.jpg)

![](images/29008510d10a4a4bd253f39c65e48483fe05065cd7a15bfa7954c45b238014e5.jpg)

![](images/04cf16d0784bedb7c7bf818d8e2b69b2f9ffd36672526dac6e1e3a63cf0a7857.jpg)

![](images/fd35227f9175252724b3a6679154d073e39d3a09342942503908274779d5a97d.jpg)  
Figure 2. In panel (a), the map of water resources impacted by FLW associated to the food intake of wheat and derived products by Italy in 2016 is displayed. All stages are merged together. In panels (b)–(f), results are disaggregated to show the contributions of the single stages of FLW (agriculture, postharvest, processing, distribution, consumption). The map in panel (a) can be seen as the sum of the 5 maps in panels (b)–(f). The classes of the legend are kept constant across the two panels.

foreign resources $( 6 5 . 0 \% )$ especially from NAO and EUR. The food intake of the NAO region is on the contrary the one that had the lowest relative impact on foreign water resources $( 6 . 7 \% )$ .

# 4. Limitations and sources of uncertainty

The proposed methodology has some limitations, which need to be understood for accurately interpretating the results. When managing trade data, we adopt the proportionality-based assumption as

in Kastner et al [31] to overcome the unknown reexport quotas, as explained in section 2. This simplification does not take into account any of the economic factors which undoubtedly drive this specific trade aspect. Moreover, in Gustavsson’s et al work (2011) there is no mention nor estimates of international transportation losses, which are then neglected. Even if these were included, the algorithm’s application yields a network directly connecting producing and consuming countries (as explained in section 1), thereby disregarding intermediate steps such as actual

Table 2. Water resources in the U.S. impacted by the FLW associated with the utilization of the different wheat-related items in the commodity tree worldwide, disaggregated by stage of the value chain. Note that this includes FLW generated in the production destined to food, feed, seed, residuals and other uses.   

<table><tr><td></td><td>Agriculture (106m3)</td><td>Post-harvest (106m3)</td><td>Processing (106m3)</td><td>Distribution (106m3)</td><td>Consumption (106m3)</td><td>Total (106m3) (perc.)</td></tr><tr><td>Wheat</td><td>1950.12</td><td>1911.12</td><td>1005.89</td><td>6.27</td><td>15.04</td><td>4888.44 (26.74%)</td></tr><tr><td>Flour of wheat</td><td></td><td></td><td>2596.15</td><td>451.87</td><td>4390.27</td><td>7438.29 (40.69%)</td></tr><tr><td>Bran of wheat</td><td></td><td></td><td>1.46</td><td>1.25</td><td>12.28</td><td>14.99 (0.08%)</td></tr><tr><td>Pasta</td><td></td><td></td><td></td><td>194.26</td><td>1382.88</td><td>1577.14 (8.63%)</td></tr><tr><td>Bread</td><td></td><td></td><td></td><td>579.36</td><td>3784.06</td><td>4363.42 (23.87%)</td></tr><tr><td>Total (perc.)</td><td>1950.12 (10.67%)</td><td>1911.12 (10.45%)</td><td>3603.50 (19.71%)</td><td>1233.01 (6.74%)</td><td>9584.52 (52.43%)</td><td>18282.28 (100.00%)</td></tr></table>

![](images/2bfc6ad3b8ae5f2170ba05e2ea8ccbe09667b8175383513902c0b8741ec53f91.jpg)  
a

![](images/c4b8603ab3d0f8f4a3468690dbeea3c007d7c55bbbfeeb04732a39171480f97c.jpg)  
b-Processing

![](images/715649a53ab7d84acceadb3095c496bfe9b0d0bf43ceb8d9a26deb7043b4a6e8.jpg)  
d - Consumption   
Figure 3. In panel (a), we can see the countries in which, through FLW of wheat and derived products, virtual water from U.S. resources is lost or wasted in year 2016. All stages are merged together. In panels (b)–(d), results are disaggregated to present the contributions of the single stages of FLW (processing, distribution, consumption). Maps about agriculture and post-harvest stages were not included, since such losses are located in the U.S. itself.

![](images/5f78007f2bc99caa5f8228fddfa3d9127def3a0ff8ba7d3ce7e3f0b963161e4d.jpg)  
Figure 4. Chord diagram of water resources lost or wasted though transnational FLW flows in 2016. Virtual water flows are depicted by oriented arrows from countries whose water resources are lost or wasted FLW to countries whose food intake is associated to the generation of that FLW. For a better visualization, only the largest 100 fluxes are displayed. Countries are grouped into 7 regions whose acronyms are displayed: AFR stands for Sub-Saharan Africa, EUR for Europe (including Russia), INA for Industrialized Asia, LAM for Latin America, NAO for North America & Oceania, NAWCA for North Africa & West-Central Asia and SSEA for South & Southeast Asia.

transport losses between nations acting as intermediaries. At last, this first version of the NETFLOW tool is not able to model food commodities which derive from a combination of multiple parent products (e.g. mixed-grains products) even if the extension is quite straightforward.

Regarding the potential sources of uncertainty, the NETFLOW tool is currently parametrized using the stage-by-stage FLW shares provided by Gustavsson et al [13], to the best of our knowledge the most complete source available. These parameters are provided as regional values (encompassing 7 global regions) for 7 food macro-baskets, based upon literature review and expert judgement by the authors. FAO data for within-country final food consumption had to be rebalanced using a different database (Statista), which provides estimates based on macroeconomic downscaling techniques. This was deemed necessary due to inconsistencies between the values reported in the original dataset and available food consumption statistics of bread [50] and pasta [51,

52], but the merging of the datasets introduced additional uncertainty. The uncertainty of the uWFp from the CWASI database has been estimated to be around $9 . 3 \%$ [38]—depending on yield, climatic conditions, crop calendars and farming technologies—and it is propagated to the waste values obtained using the methodology proposed here, which is, however, capable of accommodating any more refined estimates that will become available.

# 5. Conclusions

This study presents the NETFLOW model as an innovative tool to quantify the impacts on water resources of FLW. To the best of our knowledge, this is the first work to provide estimates for FLW disaggregating commodity trees into their different products, primary and derived, providing a countryscale network analysis of their different trade networks and water-related impacts. We have demonstrated an application that considers the case of wheat

and its derived products. Focusing on the exemplary cases of Italy (consumption side) and the U.S. (production side), we revealed the remarkable extension of the FLW-induced water waste network, and its heterogeneous topology, strongly depending on the specific FLW stage. Moreover, the NETFLOW model is able to generate outputs at an unprecedented level of detail, providing insights at commodity-level, for any stage in the value chain. In the emblematic example of wheat developed here, we found that household waste of bread in Italy is the largest contributor to water wastage (659 million $\mathbf { m } ^ { 3 }$ ) across any stage and any wheat-based commodity in analysis. Analyzing the utilization network of the United States, we estimated instead that flour household waste has the largest impact on U.S. water resources (almost $4 . 4 ~ \mathrm { k m } ^ { 3 }$ ), while bread wastage at the same stage of the value chain ranks second at $3 . 8 \mathrm { k m } ^ { 3 }$ .

Globally, the virtual water lost through the FLW of wheat and its derivatives is over $2 0 0 ~ \mathrm { k m } ^ { 3 }$ , of which $8 1 . 8 \%$ is due to human food consumption. The dominant contributors are, as expected given their large population, China and India, which together account for about $3 7 \%$ of the global virtual water losses. Nearly $2 2 \%$ of these losses are water resources impacted by food consumption in another country (transnational flows), highlighting the remarkable interconnections between virtual water resources and food consumption. Regionally, countries in North America & Oceania bear the highest share $( 5 5 . 7 \% )$ , of lost water resources linked to foreign food consumption, whereas countries in Industrialized Asia exhibit the lowest impact due to their predominantly domestic use of wheat production. Sub-Saharan Africa stands out for the significant impact $( 6 5 . 0 \% )$ of its consumption-related losses on foreign water resources, particularly from North America & Oceania and Europe. Conversely, the food intake of North America & Oceania has the lowest relative impact on foreign water resources $\left( 6 . 7 \% \right)$ .

The accuracy of NETFLOW greatly depends on the FLW shares, as given by the Gustavsson et al [13]. This is a key point and future efforts should prioritize collecting more detailed data, in order to improve the waste-water nexus global picture. The proposed NETFLOW approach is a flexible and scale neutral tool as it can easily incorporate (and benefit from) finer FLW shares that will be available in the future, and the number of stages of the value chain itself can be customized. Further developments include the extension to a broader range of commodities (including animal products). Time-dependent parametrizations would be needed to perform temporal evolution analyses, as additional trends should be taken into account, e.g. technological changes in agricultural practices, dietary shifts in food consumption, mutating FLW profiles of countries’ agri-food systems and climate changes.

The more detailed understanding of the impacts of FLW on water resources provided by this study has direct policy implications: the spatial heterogeneity revealed in this commodity-level analysis should be taken into consideration when formulating strategies to address FLW. The insights provided by NETFLOW can inform actions that target specific food commodities and stages of the value chain, taking into account the specific challenges and opportunities in different regions.

