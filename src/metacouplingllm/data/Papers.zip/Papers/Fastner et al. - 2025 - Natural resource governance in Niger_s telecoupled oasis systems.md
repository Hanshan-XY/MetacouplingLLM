# Natural resource governance in Niger’s telecoupled oasis systems

![](images/ea77c689ac5793e94e5a0da2068a249510c31cd4a2d22e744a3c9b0b36e07243.jpg)

Kira Fastner a,* , Abdoul Kader Ibrahim Mohamed b , Andreas Buerkert a

a Organic Plant Production and Agroecosystems Research in the Tropics and Subtropics, Organic Agricultural Sciences, Universitat ¨ Kassel, Witzenhausen, Germany b Facult´e d’Agronomie, Universit´e d’Agadez, Niger

# ARTICLEINFO

Keywords:

Traditional land use

Urbanization

Rural-urban linkages

Natural resource management

Commons

Sub-Saharan Africa

# ABSTRACT

West Africa’s rapid urbanization is challenging natural resource governance of its far distant rural hinterlands. This becomes visible in remote oases at the fringe of the Sahara Desert in northern Niger, which have gained access to food markets of growing coastal cities. Farmers have shifted from subsistence-oriented to large scale market production for urban consumers. However, the expansion and intensification of agricultural land use is heavily constrained by the availability of fertile land and quality irrigation water. The oasis of Timia in the Aϊr Mountains of northern Niger is a regionally exceptional example for sustainable agricultural intensification meeting market demands and fulfilling subsistence needs. Our study investigates Timia as a model for the successful adaptation of rural hinterlands to an urbanizing world through the effective governance of common natural resources. We combined GIS-based land use change and above ground water flow analyzes with agricultural production records, 98 surveys with oasis farmers, GPS tracks of pastoral activities, and well measurements. The results indicate agricultural land intensification in the oasis through agroforestry systems, with the addition of 12,000 citrus fruit trees between 1980 and 2023. Local social-ecological constraints limit land expansion and groundwater exploitation. The example shows that sustainable rural transformation and the creation of new livelihood opportunities may benefit from diversified crop-livestock production and niche market farming of high-value products. Social consensus appears to be a key prerequisite for fostering efficient, decentralized and community-led management of scarce natural resources. Investments in autonomous communities, knowledge building, access to infrastructure and technology minimize the need for policy interventions from central government bodies for sustainable development.

# 1. Introduction

Despite great efforts over the past decades to intensify agricultural systems in the West African Sahel, erratic and insufficient rainfall, low soil nutrient and organic carbon levels, along with complex social and political challenges, continue to undermine land and labor productivity in the region (Pretty et al., 2011; Buerkert and Schlecht, 2020). For centuries, cultivated agricultural land has rather been expanded than intensified. Consequences are widespread destruction of forests and erosion of surface soils in many parts of Sub-Saharan Africa, particularly in Niger (De Janvry and Sadoulet, 2010; Herrmann et al., 2020).

Niger is a landlocked country of which $7 7 ~ \%$ are covered by desert and the remaining $2 3 \ \%$ at its southern tip are suitable for marginal, rainfed agriculture (Moussa et al., 2016). In southern Niger, NGOs and governmental programs tried for decades to invest in land rehabilitation, such as tree planting and the construction of water and soil retention structures (zaïs and half-moons; Moussa et al., 2016; Mishra

et al., 2023). Northern Niger, in contrast, has seen much less land rehabilitation. At the southern fringe of the Sahara Desert population growth-driven land expansion and unregulated groundwater extraction for agricultural market production are increasingly jeopardizing livelihoods (Fastner et al., 2023). This is particularly true in the Aϊr Mountains. There, until the 2000’s, the indigenous nomadic Tuareg population had been poorly connected to distant urban markets and livelihoods had been largely subsistence-based (Fastner et al., 2023). However, products from the Aϊr, such as date (Phoenix dactylifera L.), millet (Pennisetum glaucum L.), wheat (Triticum aestivum L.) and potato (Solanum tuberosum L.) were exchanged on local and regional markets in Tabelot, Bilma, Fachi, Agadez, Zinder, and Kano in Nigeria for salt, sugar, and tea through caravans for millennia (Fig. 1; Morel, 1973; Spittler, 1989). Nowadays caravan trading has lost much of its importance and the sale of cash crops to West African cities, such as onion (Allium cepa L.), potato, garlic (Allium sativum L.) and citrus fruits, secures local livelihoods. Additional off-farm income is generated from

gold mining and, more recently, illicit trafficking of goods and migrants through the Sahara Desert.

The Aϊr Mountains are characterized by an arid climate with a short rainy season from July to September, during which most of the average annual rainfall of 200 mm occurs, therefore vegetation is sparse and agricultural production is only possible on irrigated land (Morel, 1973; Fastner et al., 2023). Irrigation water for crop production in these oasis gardens is made available through groundwater wells or springs (Fastner et al., 2023). The survival of local communities who have settled in oases depends on traditional small-scale crop-livestock production, including the use of vast, surrounding pastures for livestock herding (Mattingly and Sterry, 2020; Fastner et al., 2023). The common grazing lands are covered by sparse grasses and shrubs. While during the rainy season pastures are relatively lush, in the hot and dry season the availability of natural vegetation is limited. Agreements between the herders prevent the vegetation’s overuse. During the arid season, goats, sheep, camels, and donkeys partly depend on supplements from household leftovers or crop residues.

In the past two decades, rising food demand from West Africa’s coastal cities, improved infrastructure, and new communication technologies allowed oases in the Aϊr Mountains to connect to distant urban West African markets (Fastner et al., 2023). The resilience of the ancient agro-pastoral systems heavily depends on locally developed institutional arrangements to ensure social equity and to prevent overexploitation of natural resources (Ostrom, 1990). This includes pasture quality, groundwater availability, and soil fertility. The advent of telecoupled urban market demand has resulted in highly dynamic land use transformation including intensified, year-round irrigation of land, and subsequent stress on aquifers. Traditional land use arrangements have been challenged, scarce water resources and nutrients are increasingly exported through food products to urban centers, and the once relatively robust land use systems have become fragile. Nevertheless, the Aϊr Mountains of Niger present favorable conditions for the evolution of effective local, self-governing rights and resource institutions because (i) resources are relatively easy to monitor by everybody at low cost, (ii) rates of change in technology, economic, and social conditions are moderate, (iii) dense social networks exist, and (iv) outsiders are largely excluded from resource use (Dietz et al., 2003). Little is known about the current transformation of Saharan oases as remote indicators of the scope of globalized urbanization. These systems can provide examples of

how communities effectively manage scare natural resources, and at the same time increase their standard of living.

This study aims to analyze the effects of telecoupled market production on traditional land use systems and to derive limits and opportunities of local strategies for adaptive governance of natural resources. We hypothesize that (i) remote sensing analyses combined with field data allow to quantify land use transformation and associated challenges for communities to govern scarce common resources, and (ii) agroforestry systems, including niche market production, and integrated crop-livestock management can enhance sustainable resource use, risk spreading, and opportunities for new livelihoods.

# 2. Materials and methods

# 2.1. Study site

The rural community of Timia $( 1 8 ^ { \circ } 7 ^ { \prime }$ N, $8 ^ { \circ } 4 7 ^ { \prime } \mathrm { ~ E ~ }$ ) is situated in the southern part of the Aϊr Mountains and belongs administratively to the Department of If´erouane. It covers an area of $3 2 , 0 0 0 \mathrm { k m } ^ { 2 }$ . Neighboring communities are If´erouane to the north, Fachi to the east, and Tabelot to the south. East and north of Timia stretches the T´ener´e Desert towards Algeria and Libya, through which the caravans have passed for millennia. The community’s population, mainly Kel Ewey Touareg and Houssa, was 19,100 in 2012 and rose to 20,700 in 2015 and 23,700 in 2017 (Institute National de la Statistique Niger, 2020). The eponymous main town and administrative center of the community is located at an altitude of $1 0 0 0 \mathrm { m }$ above sea level (asl), southeast of the Adrar Egalah Mountain (1874 m asl) along a dry river valley (kori), that only carries water occasionally in the rainy season (Fig. 2). The selected study site of $6 . 6 5 \mathrm { k m } ^ { 2 }$ covers the administrative center of Timia with its main settlements and respective agricultural field gardens. In 2017, 10,300 inhabitants were living here (Plan de D´eveloppment Communal, Timia, 2020), which corresponds to half of the population of the entire community.

Timia’s main settlement was founded in 1920 after the French military had violently suppressed the Tuareg, who were fighting against colonialization of their country. Subsequently, surrounding villages were established by inhabitants of Timia searching for additional agricultural land.

After successive droughts in the 1970s and 1980s which caused

![](images/d122de361d155b07d27569d3f0607e54e0ac444905c38ead464af4c9745eb29b.jpg)  
Fig. 1. Map of Niger with road infrastructure and neighboring countries. The map shows Niger’s paved road network and the regional triangle caravan trade between Niger and Nigeria.

![](images/5d4b0adb01f1e79862d8dd86433bdab29dbcc98617640383aecc45571b0d0d1b.jpg)  
Fig. 2. Map of the study site in the Aϊr Mountains of Niger. Location and elevation of the administrative center of Timia (right) and displayed as a Digital Surface Models (DSM) in 3D view (left).

heavy livestock losses, several NGOs supported agro-pastoralists to adopt a combination of irrigated crop and livestock farming activities to diversify their livelihoods and to mitigate risks (Liniger et al., 2011). Nowadays, onion, potato, date palm and citrus are cultivated for sale, and wheat, maize (Zea mays L.), and pearl millet for auto-consumption (Liniger et al., 2011). Additional marketable crops are banana (Musa L.), fig (Ficus carica L.), papaya (Carica papaya L.), and pomegranate (Punica granatum L.; Fig. 3).

# 2.2. Climatic conditions

The air temperature in the sun, shade air temperature, and shade air

humidity data were recorded in 15 min intervals with a HOBO MX2202 and a HOBO MX1101 data logger (Onset Computer Corp., Bourne, MA, USA). The small weather station was set up 2 m above ground in May 2023 close to the town hall of Timia. Rainfall records determined with a manually operated pluviometer from 2009 to 2023 completed the meteorological data (Plan de D´eveloppment Communal, Timia, 2020; Fig. 4). The climatic seasons comprise a cold season (Tagrist) from November to March, a hot season (Awelan) from April to June, a rainy season (Ghafayt) from July to September, and an intermediate season (Gharat) from mid-September once rainfall ends until end of October before the cold season starts.

During the short rainy season most of the average annual rainfall of

![](images/64edc46c094c52706269a08cfe6eb0299518be485dd1552701471d04afb70391.jpg)

![](images/1d567c3556b9ce3acd84ad0641fad7256efd33733681b75cd0a19dd9856c6cbd.jpg)

![](images/435050ef852e5a97ca0047b50f092361fd870471ecac8cc466da5580c81220d0.jpg)

![](images/d82c2c486af337eb08c57c7069c0557b1d402baeba0f26250439db3cdf4e2007.jpg)  
Fig. 3. Photographs of the study site. The pictures show the oasis of Timia, Niger in February 2023.

![](images/7af0e059d9a9447bdaea0e26764bf248d8e95472979265ed45a3da4d38a1b3b0.jpg)  
Fig. 4. Annual precipitation (2009–2023) in Timia, Niger. Data prior to 2023 was taken from Plan de D´eveloppment Communal, Timia, 2020.

146 mm occurs. Measured average monthly temperatures varied between 19˚C and 35˚C whereby temperatures in the hot season may reach 45˚C in the shade and $5 9 ^ { \circ } \mathrm { C }$ in the sun, while temperatures in the cold season can fall to 6˚C (Fig. 5). Relative air humidity is highest during the rainy season with maximum values of $9 0 \mathrm { - } 1 0 0 \%$ in August, while during the other months of the year it remains dry with $< 3 0 \%$ air humidity on average.

# 2.3. Remote sensing and ground truthing

# 2.3.1. Imagery acquisition and processing

For the quantification of land use changes over the past 70 years high-resolution aerial photographs from the 1950s were purchased and georeferenced with the open-source Quantum GIS software (QGIS 243 vers. 3.10). Satellite imagery from 2003 and 2020 available on Google Earth Pro of the study site was used for further analyses with QGIS (Table 1). Drone images were taken in February 2023 by running a DJI Mini 2 automatically with Dronelink LLC. The images were orthomosaicked, Digital Surface Models (DSMs) and 3D models were generated based on triangle meshes with Pix4D Mapper (Pix4D SA). The boundaries of the study area were defined based on administrative village limits with their associated agricultural fields. The high-resolution drone images and modern-time satellite data made it possible to detect smallscale oasis gardens, their delimitation and cultivated fruit trees. For hydrological analyses Digital Elevation Models (DEM) were downloaded from USGS Earth Explorer and processed with ArcGIS Pro 3.1 from Esri.

# 2.3.2. Land use classification

The black/white and true color images (RGB) of high resolution $( <$ 2 m) were classified manually with QGIS by drawing polygons and points for the different land use classes comprising field boundaries,

![](images/88bdef73d15b502c338a991c90bb46c49f436dabbebf107133e74e954254d664.jpg)  
Fig. 5. Monthly air temperatures and humidity (June 2023-May 2024) in Timia, Niger. Data was recorded by a local weather station.

Table 1 Data set sources for remote sensing analyzes of Timia, Aϊr Mountains, Niger.   

<table><tr><td>Sensor/Image</td><td>Resolution</td><td>Date</td><td>Data Source</td></tr><tr><td>Aerial photograph (black/white)</td><td>1.7 m</td><td>1955–10–23</td><td>Institut national de l&#x27;information géographique et forestière (IGN) France</td></tr><tr><td>Maxar Technologies Image Landsat/Copernicus (RGB)</td><td>1.7 m</td><td>2003–08–01</td><td>https://earth.google.com/</td></tr><tr><td>DJI Mavic Mini 2 drone images (RGB)</td><td>0.1 m</td><td>2023–02–17</td><td>Personal data</td></tr><tr><td>SRTM-1 Digital Elevation Model (DEM)</td><td>30 m</td><td>2014–09–23</td><td>https://earthexplorer.usgs.gov/</td></tr></table>

cropland, fruit trees, date palms, built-up areas, and temporary watercourses, while the rest of the area consists of sand/stones/natural vegetation. This supervised classification was verified with approx. 50 Ground Truthing Points (GTPs) collected using the mobile application GPS Waypoints (vers. 3) and GPS Tracks (vers. 4.4) during field visits in August 2021 and February 2023. In the images from 1955, distinguishing between date palms and other fruit trees (mainly citrus) was not possible. Oral records confirmed that during the 1950s, the predominant tree species cultivated in the oases were date palms, with other fruit trees being introduced only after the droughts in the early 1980s. Therefore, all trees depicted in the early image were classified as date palms. Agricultural field boundaries, cultivated crops, and the location of wells were GPS-recorded, and data collection was complemented by crop calendars.

# 2.3.3. Surveys and records of market production quantities

The remote sensing and ground truthing work was complemented by semi-structured surveys programmed with CSPro 7.7 and conducted with 98 male farmers who own land in the oasis of Timia. The questions addressed general household characteristics (demography, income sources, physical assets), crop production (crop cultivation, managed area, inputs, sales), livestock keeping (species, numbers, sales), water and irrigation management, as well as general changes in agricultural land use over time. The survey’s purpose was explained to the farmers, and they were assured that their participation is voluntary, anonymous, and will not lead to any personal advantages or disadvantages. After the consent of farmers to participate, the questionnaire was deployed orally in French or Tamashek on the farmers’ land property. The answers were entered directly with CSEntry into a digital device and later transferred to Microsoft Excel, inspected for plausibility, and answers to open-ended questions were grouped. Answers to closed-ended questions were analyzed descriptively and explained by respective grouped answers to open-ended questions.

Since the main cash crops in Timia are onions, potatoes, and oranges (Citrus sinensis), their monetary importance for local livelihoods was assessed. For this, available local records on exports of marketable produce collected in the central storage facility of the village were analyzed. These data were matched with registered amounts of agricultural products coming from the Aϊr Mountains to the main transshipment and trading point of Agadez, where annual agricultural reports from La F´ed´eration R´egionale des Unions des Soci´et´es Coop´eratives d’Agadez (FRUCOOP/AZ) were available for the years 2013 and 2018–2022.

# 2.3.4. GPS tracking of herding activities

Herding activities of 10 different herds, consisting of sheep and goats, were recorded with GPS trackers in August 2021 (rainy season). In February 2023 (cold season) 4 of these 10 herds were again selected for GPS tracking. Thereby two animals of each herd were equipped with the GPS model GT-730FL-S in a light collar during daytime on two consecutive days. The GPS tracks indicated which pastures were grazed

during different seasons. The GPS tracks were complemented by participatory mapping with the herders of daily grazing routes in different seasons.

# 2.3.5. Hydrological analyses

Water flow directions, flow accumulations, and watersheds were calculated based on downloaded DEMs and DSMs derived from drone images by using the hydrology spatial analysis tool in ArcGIS Pro. Initially, flow directions in the filled DEM were determined by the deterministic eight neighbors (D8) method, which assigns the flow direction of each cell to its steepest downslope neighbor (Jenson and Domingue, 1988; Quinn et al., 1991). Afterwards, flow accumulations and stream orders (Horton, 1945; Strahler, 1952, 1957) were calculated. The Strahler stream order defines stream sizes based on a hierarchy of tributaries, whereby first-order streams are those which have no tributaries, second-order streams receive as tributaries only streams of the first order, and third-order streams are those which receive first and second order streams as tributaries (Strahler, 1957). Water outlet points within the study area were selected to visualize respective watersheds. The watersheds show the upslope area that contributes water to the selected outlet point. The analysis of watersheds made it possible to determine which field gardens and respective wells within the selected

study site are likely interdependent.

In February 2024, water levels of 179 wells distributed across Timia were measured. Distances to the water surface of wells were determined with a measuring tape from the soil surface and are referred to as “water level”, while distances to the well bottom are referred to as “well depth”.

Through GIS-based hydrological analyses the topography-dependent distribution of groundwater resources could be assessed and used for watershed management approaches.

# 2.3.6. Ethical authorization

The study was authorized by the Ministre de l’Enseignement Superieur et de la Recherche, Niamey, Niger under permit $N ^ { \circ } 0 0 1 9 6$ of 22/03/2023 while the data collection procedure and subsequent use of the data was approved by the Central Ethics Committee of the University of Kassel, Germany. The purchase of historical aerial photographs from IGN France was authorized by le Directeur G´en´eral de l’Institute Geographique National du Niger (IGNN) under permit $\mathrm { N } ^ { \circ } 0 0 1 / 2 0 2 1 / \mathrm { D G } /$ IGNN/DT of 09/11/2021.

![](images/ed73651da675e1c1ba4c7a50e71e1022fe6ffdc7373177cb386e541f206c58e5.jpg)  
Fig. 6. Supervised land use classifications in Timia, Niger. The maps show agricultural land use, built-up areas, and waterways in 1955, 2003, and 2023.

# 3. Results

# 3.1. Agricultural land use changes and market production

From 1955 to 2023 crop and fruit tree production in Timia had been expanded and intensified (Fig. 6). The number of field gardens increased from 40 to 147, resulting in 75 ha of additionally acquired private land. Today, the average size of a field garden is 1 ha. While cropland has only increased by 22 ha in total, around 12,000 fruit trees (mainly oranges) and 8500 date palm trees were added to the fields (Table 2).

The data indicates that in the 1950’s, Timia’s oasis farmers mainly produced cereals (millet, barley (Hordeum vulgare L.), and wheat) and dates for subsistence needs as well as for small-scale caravan trading in small gardens of less than 0.3 ha. Since the $ 1 9 8 0 ^ { \circ } { \mathsf { s } } _ { \mathrm { : } }$ , when population numbers in Niger quadrupled from 6.1 Mio in 1980 to 28.2 Mio in 2024, Timia’s fields have been increasingly cultivated with diverse annual cereal crops (maize, barley, wheat, millet) and vegetables (potato, onion, garlic, tomato (Solanum lycopersicum L.), cabbage (Brassica oleracea L.) as well as perennial fruit trees (date, orange, fig, mango (Mangifera indica L.), pomelo (Citrus maxima), tangelo (Citrus × tangelo), lemon $( C i t r u s \ \times \ l i m o n )$ , mandarin (Citrus reticulata), papaya (Carica papaya L.), and banana) in agroforestry arrangements (Fig. 7).

However, the overall area covered by field gardens has only slightly increased during the 50 years between 1955 and 2003. After 2003, 50 new larger fields (up to 3.8 ha in size) in the northern and southern part of the study area were established, which mainly contain citrus fruit trees (especially orange) for market production.

Half of the surveyed farmers stated an increase in their cultivated land area over the past 20 years due to rising market demand since the $2 0 0 0 ^ { \circ } s$ . For the past 5 years, $3 4 \%$ of the farmers have continued to expand their cultivated land, while $4 8 \%$ of the farmers reported that further expansion was not possible due to a lack of available fertile land. Additionally, $1 7 \%$ of the farmers indicated a decrease in cultivated land due to water shortages and changing climatic conditions. Cash crop production is generally constrained by seasonal water availability and irrigation practices of farmers who possess fields located upstream.

Products from Timia are exported throughout the year. Records show that in years of sufficient rainfall, as in 2020 with $2 1 5 \mathrm { m m }$ , annual exports from the entire community of Timia may reach 15,000 t for onion and 4500 t for potato grown on 342 ha (Plan de D´eveloppment Communal, Timia, 2020; Table 3). About $8 0 ~ \%$ of the onions are harvested between September and December. Farmers are exposed to fluctuating market prices, which can vary by up to $5 0 \%$ throughout the year (Table 3).

Timia’s farmers organize themselves in small cooperatives and collectively sell their products to the farmers’ organization FRUSCOOP/ AZ in Agadez, which serves as a distributor for national and international sales of agricultural produce from the Department of Agadez. All oranges registered by FRUSCOOP/AZ were produced in Timia and the data show a continuous increase in their production volume from 200 t in 2013 to 1300 t in 2022 and respective revenue (Fig. 8). The purchase prices for oranges by FRUSCOOP/AZ fell from $1 . 3 0 \mathrm { U S D } \mathrm { k g } ^ { - 1 }$ in 2013 to 0.6 USD $\mathbf { k g } ^ { - 1 }$ in 2022 and consequently Timia’s revenue per kilo of oranges sold has been reduced. Nevertheless, apart from the cash crops onion and potato, the sale of citrus fruits is a main contributor to Timia’s economy.

Table 2 Land use changes in Timia, Niger from 1955 to 2023.   

<table><tr><td>Land use</td><td>1955</td><td>2003</td><td>2023</td><td>Δ 1955–2023</td></tr><tr><td>Buildings (ha)</td><td>1.5</td><td>18</td><td>34</td><td>+ 32.5</td></tr><tr><td>Land properties (ha)</td><td>61</td><td>89</td><td>136</td><td>+ 75</td></tr><tr><td>Cropland (ha)</td><td>3</td><td>22</td><td>25</td><td>+ 22</td></tr><tr><td>Fruit trees (amount)</td><td></td><td>5370</td><td>12,090</td><td>+ 12,090</td></tr><tr><td>Date palms (amount)</td><td>900</td><td>8440</td><td>9350</td><td>+ 8450</td></tr></table>

However, some farmers reported difficulties in the organization between farmers to sell products collectively. Others mentioned major problems in the marketing of agricultural produce due to difficult access to markets and transport conditions.

# 3.2. Livestock and pasture management

The surveyed households keep on average 8 (range 1–45) goats and 10 (2− 30) sheep primarily for sale on local markets and for manure production to fertilize their crops. After crop production, livestock keeping is the second most important economic activity in the oasis. Most animals are sold within the local community or to the nearby town of Tabelot. $8 5 ~ \%$ of the surveyed households reported an increase in the sale of livestock over the past five years, $9 \%$ a decrease, and $6 \%$ of the respondents said there were no changes in livestock marketing. The increasing demand for meat, even seasonally, exceeds Timia’s production capacity. Reasons for production shortages include limited fodder availability and the shift of activities in the oasis towards crop and fruit tree production. While in the past the main problem of animal production was diseases (reported by $9 0 \%$ of the surveyed households), today limited forage availability restricts livestock production (reported by $6 0 \%$ ). Animals are herded daily, often in groups of two or three households. Sheep and goats primarily graze in Timia’s narrow side valleys where crop production is not feasible. This underlines the efficient use of land and sparse vegetation. In addition to grazing acacia (Acacia Mill.) fruits and diverse herbs in the pastures, the animals are fed with leftover harvest products. In the past, livestock keeping was predominantly extensive, but today there is a trend towards keeping livestock in small huts located near the homesteads.

Pasture usage and corresponding herding routes around the oasis center are coordinated among herders through traditional oral land use agreements to prevent overgrazing. In August 2021 (rainy season), daily herding routes averaged $1 4 \mathrm { k m }$ in length, while distances in February 2023 (cold season) averaged $1 7 \mathrm { k m }$ due to sparser natural vegetation (Fig. 9).

The GPS tracks and participatory maps (Fig. 10) indicate that new field gardens are increasingly being established in former rangelands to the east and south which resulted in the extension of herding routes. The recorded GPS tracks of August 2021 were much longer than what the participatory maps for the rainy season showed and overlapped with herding routes in the hot season.

# 3.3. Water resources and management

Agricultural field gardens are located in the river valley along second and third order water streams, and no upstream neighboring towns or fields tap the respective first order water streams (Fig. 11).

All gardens of Timia are located in one single watershed, whereby the northern water outlet point receives water only from the watershed area to the northwest (watershed 1), while the southern outlet point receives flows from the whole indicated watershed (watershed 1 and 2; Fig. 12). There are no other villages or field gardens in the same watershed north or east of Timia. In the year 2021, 190 groundwater wells were counted in the study area, which are established close to third order water streams in the river valley (Fig. 12).

Measurements in February 2024 of 179 wells distributed across the area showed average water levels of 15 m (12–23 m) below ground (Fig. 13), whereby wells with higher water levels are located close to the main kori. The average well depth in Timia was ${ 2 0 } \mathrm { m }$ . New field gardens, particularly in the southern part of the area, face challenges in accessing groundwater at depths of less than ${ } ^ { 2 3 \mathrm { ~ m ~ } }$ below ground. Some new borewells in the south reach more than $2 0 0 \mathrm { m }$ depth (white circles), likely tapping into different groundwater layers.

![](images/49a213a21f8511fff154c96bca5e0609b80711ec9c917c8a912c86ef380b8bce.jpg)

![](images/36a4b102a9229b8417ea9dc34e65f96289959fdad2c9e9ccb092624e454b12fe.jpg)  
Fig. 7. Agroforestry systems in Timia, Niger in February 2023.

Table 3 Seasonal calendar of market produces with sales volume and prices for the community of Timia, Niger in 2020 based on local records. Vertical lines stand for the beginning of the growing season, horizontal lines for the growing season, and black circles for the end of the harvest season.   

<table><tr><td>Crop</td><td>Jan Feb Mar Apr May Jun Jul Aug Sept Oct Nov Dec</td><td>Production quantity (tons)</td><td>Price (USD/kg)</td></tr><tr><td rowspan="2">Onion (Allium cepa L.)</td><td></td><td>3,400</td><td>0.48</td></tr><tr><td></td><td>12,200</td><td>0.54</td></tr><tr><td rowspan="2">Potato (Solanum tubersosum L.)</td><td></td><td>2,000</td><td>0.97</td></tr><tr><td></td><td>2,200</td><td>0.64</td></tr><tr><td>Oranges (Citrus sinensis)</td><td></td><td>1,500</td><td>1.21</td></tr><tr><td>Tangelo (Citrus×tangelo)</td><td></td><td>200</td><td>1.21</td></tr><tr><td>Mandarin (Citrus reticulata)</td><td></td><td>150</td><td>1.05</td></tr><tr><td>Pomelo (Citrus maxima)</td><td></td><td>150</td><td>1.05</td></tr></table>

![](images/2394126af05fd6c227a60d5351cbfca3fda5f3c4b6f8a1240477f64e1cb4eba3.jpg)  
Fig. 8. Orange production and revenue of Timia, Niger sold to FRUSCOOP/AZ in Agadez, Niger in 2013 and 2018–2020.

# 4. Discussion

# 4.1. Social-ecological transformation of oasis agro-ecosystems

Our analysis of social-ecological transformations in the oasis of Timia in the Aϊr Mountains of northern Niger contributes to the scarce body of literature on the scope of linkages between rapidly growing urban food market demand in West Africa and agricultural production in distant rural hinterlands. While other oasis systems in the region have expanded agricultural land with increasing monocropping of marketable irrigation intensive root crops (Fastner et al., 2023), in Timia agricultural production has been largely intensified on available land through agroforestry arrangements. Under the harsh climatic conditions and high evapotranspiration levels in the region (Fastner et al., 2023),

agroforestry systems provide partial ground cover, shade, and evaporative cooling for understory crops, improve water infiltration, and reduce the risk of soil erosion (Sauer et al., 2021). It may further help to enhance system resilience against climatic change effects of increasing temperature and variability in precipitation, including heavy rainfall events (Mbow et al., 2014; Sultan and Gaetani, 2016). Integrated crop-livestock systems allow risk spreading and contribute to closed nutrient cycles (Swinton, 1988; Powell et al., 2004). The introduction of citrus fruits by development aid programs in the 1980s and 1990s fostered the supply of high-value products to urban food markets and provided Timia with a unique market niche within the country of Niger. This has helped to generate income and contributed to food security (Liniger et al., 2011). Oranges from Timia are traded throughout Niger given their sweetness and high juiciness. Harsh environmental conditions in the region and poor access to technology, seeds, and knowledge limit the choices of farmers on cultivable market crops. Furthermore, globalized food supply chains and larger-scale, cheaper production of staple crops elsewhere (Moseley et al., 2010; Laroche Dupraz and Postolle, 2013; Ragasa et al., 2020), push farmers to focus on high-value niche products. Establishing supply chains for such products to regions with strong purchasing power often emerges as an effective strategy for marginalized rural agricultural systems to secure agricultural livelihoods and combat poverty (Zhou and Staatz, 2016).

In West Africa, the increasing demand for agricultural products results from the rapidly growing urban population numbers along the coastal corridor stretching from Lagos in Nigeria, through Cotonou in Benin, Lom´e in Togo, Accra in Ghana, to Abidjan in Ivory Coast (Zhou and Staatz, 2016; Fastner et al. unpublished). While West Africa’s increasingly telecoupled food provisioning systems (Karg et al., 2019, 2022, 2023) generate new income opportunities for vast rural hinterlands, they are especially prone to overexploitation of available groundwater and fertile land resources (Fastner et al., 2023). The example of Timia illustrates that access to technology and knowledge can contribute to agricultural intensification through diversification and

![](images/ba6fdd95ed80fb0759f6c7d3d77a78d5849592fc5edab40595f756e1f9eb30f3.jpg)

# Legend

Herding route in rainy season 2021   
Herding route cold season 2023   
Sampled household in 2021   
Sampled household in 2023   
Building   
Fieldsin2023   
Studyarea

Fig. 9. Sheep and goat herding tracks in Timia, Niger. The tracks were recorded with GPS trackers in the rainy season (August 2021) and cold season (February 2023).

![](images/6b13d5f4d9be3384792233b08d565af737e1a35fb3891ae0d28cbe57f7973d13.jpg)  
Fig. 10. Participatory map of herding routes in Timia, Niger. The routes were drawn for the rainy season (July-September), cold season (November-March), and hot season (April-June).

# Legend

Herding route in rainy season   
Herdingroutein cold season   
Herding route in hot season   
Building   
Fieldsin 2023   
Study area

efficient groundwater use. However, our results also indicate that the establishment of additional agricultural field gardens for cash crop production may not only lead to increasing conflicts over well water, but also to future farmer-herder quarrels about communal lands. Forced extension of herding routes or even the abandonment of pastoral activities may be the consequences. Currently, the survival of pastoral activities appears to rely on the flexibility and adaptability of herders, mainly women, not only to changing climatic conditions and associated variability in herbage quantity and quality, but also to the growing privatization of common pastureland (Oba, 2013).

The results of our surface-hydrological analyses and well measurements in Timia indicate that available groundwater resources in the

watershed are only utilized by the population of Timia’s main town, with no neighboring villages accessing the same water reserves. Older field gardens along the river valley have the advantage of groundwater levels being closer to the surface. New field gardens, especially those in the southern part of the area, face challenges in accessing groundwater reserves, with expensive deep drilling being the only viable way to reach such deeper aquifers. These natural limitations make further land expansion almost impossible.

# 4.2. Governance of common resources in marginal agro-ecosystems

Increasing market production through the exploitation of fertile land

![](images/91147487a7a97bca4777da6222a010ac70068c18dcc3e7fa43fada565c0f0447.jpg)  
Fig. 11. Water streams in Timia, Niger. The indicated water streams are based on hydrological spatial analyzes with GIS.

and irrigation water in marginal social-ecological systems of Niger’s arid zones may elucidate concerns about the classical tragedy of the commons (Hardin, 1968), meaning the overuse of common natural resources. This overuse typically leads to negative social-ecological consequences, including conflicts over resource allocation, degradation of ecosystem services, and increased vulnerability to climate change. Like elsewhere, farmers in northern Niger aim at individual profit maximization by acquisition of land for cash crop production (Fastner et al., 2023). This underlines that the much-discussed policy interventions towards private and liberal land property rights can result in local communities and actors failing to re-design their original self-governed systems (Ostrom, 1990; Blewett, 1995; Basupi et al., 2017). Ostrom (1990, 2009) argues that traditional common property regimes are capable of self-organization, when local users are able to adapt, design, and enforce their own rules, thereby drawing on inherited skills and established norms of behavior, such as trust and reciprocity. Privatization or rangeland enclosure schemes often increase the vulnerability of resources to degradation.

Recent studies point to the important role of land distribution and tenure security as drivers of resilient and inclusive rural transformation (Pierri et al., 2025). It is argued that land distribution and tenure security reforms will need to be accompanied by complementary support services and policies, such as basic rural infrastructure, agricultural extension services, research and development, and specific regulatory, fiscal and trade policies (Pierri et al., 2025). However, the considerable heterogeneity in findings on the effects of land tenure on agricultural

productivity highlights the need for policy responses that are context-specific and account for the broader macro-level conditions shaping rural systems (Place, 2009; Jayne et al., 2021).

Our results indicate that in contrast to many “tragic” examples, intensive oasis gardens in Timia are flourishing 40 years after their establishment, and take advantage of a telecoupled, apparently largely self-governed system. This may be partly due to environmental conditions such as the rugged topography with limited opportunities to cultivate new fertile lands, the limitation to the central kori as a single water source, and the nature of the agroforestry systems. However, collective rights and arrangements, as in the community of Timia, can also play a vital role for sustainable use of natural resources (Pierri et al., 2025). Timia’s communal development plan for 2021–2025 maybe romantically claims that: “The population of the municipality lives in perfect symbiosis and shares the same cultural values and identities. Within the settled and pastoral communities, there is a relatively strong social cohesion as they are grouped together in villages, hamlets, and settlements”.

Fastner et al. (2023) investigated villages on nearby Mont Bagzam and reported that these communities are characterized by rather sparsely distributed gardens and settlements with weak communal connectedness. Larger spatial distances between the villages within one watershed make groundwater appear an abundant resource with individual “first bird catches the worm” access opportunities beyond communal control. The establishment of local, self-governing rights and resource institutions will require users to support effective monitoring and rule enforcement (Dietz et al., 2003). To achieve this, it is essential

![](images/8087dd2e398e4ba1d65b65bebfd69ef27e674970c3a5219470980f54cb9c63f3.jpg)  
Fig. 12. Wells and watersheds in Timia, Niger. The illustrations are based on hydrological spatial analyzes with GIS and field data collection.

for farmers to understand how their actions impact others (Ostrom, 2009).

The NGOs’ development efforts in Timia have greatly contributed to agricultural knowledge transfer, the advent of new water-saving cultivation and irrigation techniques, and seed imports (Liniger, 2011). Villages on Mont Bagzam were only reachable on foot until 2015, which hindered exchange with the outside world. Until today, they remain much more isolated than Timia due to difficult road conditions (Fastner et al., 2023).

Agro-pastoral communities in the Aϊr Mountains of northern Niger may generally provide favorable conditions for the evolution of selfgoverned institutional arrangements that are resilient to external pressures (Dietz et al., 2003; Ostrom, 2009) if effective support systems can be established.

# 5. Conclusions

Changes in agricultural land use and natural resource extraction in the oasis of Timia in northern Niger are triggered by telecoupled urban food market demand from growing West African cities. In many neighboring oasis systems of the region these recent external influences have resulted in a classical tragedy of the commons with natural resources being exploited for individual profit maximization. Intensification of agricultural land in Timia, in contrast, builds on the use of agroforestry systems with diverse crops and fruit trees. These systems fulfill subsistence needs and generate income from market sales. Farmers’ cooperatives increase bargaining power on the markets and facilitate transportation under difficult road conditions. The absence of private companies and external investors leaves resource governance in the hands of individual users. The use and distribution of scarce natural resources in the region, especially land and irrigation water, require social consent, decentralized regulations, and community-led

management. Our study shows that through investment in autonomous communities, knowledge building, and the access to infrastructure and technology, little policy interventions from central government bodies are needed. Especially in countries with weak institutions, like Niger, decentralized sustainable development approaches of rural hinterlands can be very effective.

# Ethical authorization

The study was authorized by the Ministre de l’Enseignement Superieur et de la Recherche, Niamey, Niger under permit $N ^ { \circ } 0 0 1 9 6$ of 22/03/2023 while the data collection procedure and subsequent use of the data was approved by the Central Ethics Committee of the University of Kassel, Germany. The purchase of historical aerial photographs from IGN France was authorized by le Directeur G´en´eral de l’Institute Geographique National du Niger (IGNN) under permit N◦001/2021/DG/ IGNN/DT of 09/11/2021.

