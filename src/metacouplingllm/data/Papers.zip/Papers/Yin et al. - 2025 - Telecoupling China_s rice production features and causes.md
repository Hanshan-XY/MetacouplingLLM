# Telecoupling China_s rice production features and causes

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:16:22.341398+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Yin et al. - 2025 - Telecoupling China_s rice production features and causes.pdf
- Year: unknown
- DOI: 10.1016/j.landusepol.2025.107710
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines how rice production in northeast China influences, and partly displaces, rice cultivation in southern China, using telecoupling theory and county-level data from 1990-2016. The geographic focus is entirely domestic: northeast China is treated as a sending system, southern China as a spillover system, and the rest of the country as a receiving system within a largely self-sufficient national rice market.

Within this system, the authors build a telecoupling framework and apply two-way fixed-effect econometric models to 1,367 southern counties. They combine remotely sensed rice-area maps, land-cover and topography data, gridded population and GDP, national statistics on costs and profits of rice and selected alternative crops, and climate data. Key variables include rice area, shifts from rice to other crops, paddy abandonment, per capita rice area, and a province-level rice profit differential between northeast and southern China. They also test moderating roles of alternative crop profitability, slope, labor opportunity cost, land endowment, and national policies such as the minimum rice purchase price and arable land requisition-compensation balance.

Results show that expansion of profitable, large-scale, single-cropped rice in the northeast speeds up the contraction of rice area in the south, raising non-rice cropping and abandonment. When national rice supply exceeds demand, this constitutes an absolute crowding-out effect; in deficit years, both regions expand but southern growth is constrained, a relative crowding-out effect. The effect is stronger where southern farmers face high labor opportunity costs, fragmented or sloping land, and good alternatives such as citrus. Regions with better land endowment are more resilient.

Policy interventions reshape these telecoupled dynamics. The minimum price policy dampens crowding-out and stabilizes southern rice, but drives large stock accumulation. Land balance rules shift new paddy into higher, less suitable terrain, maintaining area while encouraging later abandonment. The paper explicitly develops and applies telecoupling (and implicitly nested telecouplings and cascading effects) to intra-national crop systems; it is squarely about telecoupling/metacoupling, not merely using the terms metaphorically.

## Structured Metacoupling Extraction

### Coupling Classification
- Primarily intracoupling and telecoupling within China; some referenced international telecouplings via soybean trade.

### Intracoupling
#### Systems
- Southern China rice production subsystems differentiated by plains vs mountains
- Northeast China rice production system with expanding single-cropping
- Other Chinese regions mainly rice-consuming with little production
#### Flows
- Domestic rice shipments from surplus to deficit regions inside China
- Internal shifts from double-cropping rice to single or non-rice systems
- Labor and capital reallocations between rice and alternative crops
#### Agents
- Chinese rice farmers in northeast and southern regions
- National and provincial governments designing agricultural and land policies
- Grain purchasing enterprises implementing price support schemes
#### Causes
- Regional differences in rice profitability and opportunity costs
- Topography, climate, and water availability shaping production advantages
- Policy interventions like rice price support and land balance rules
#### Effects
- Northward shift of national rice production center of gravity
- Concentration of rice area in northeast and central China
- Increased non-rice cropping and abandonment in southern mountains

### Pericoupling
#### Systems
- Adjacent southern provinces exchanging rice and labor
- Urbanizing zones encroaching on nearby paddy land
- Peri-urban horticulture competing with nearby rice land
#### Flows
- Short-distance trade of rice and high-value fruits between neighboring provinces
- Farmland conversion for expanding cities and infrastructure
- Local labor migration from nearby rural rice areas to towns
#### Agents
- Municipal and county governments managing land conversion
- Peri-urban farmers shifting to vegetables and fruits
- Local planners implementing arable land compensation projects
#### Causes
- Urbanization and industrialization near traditional rice areas
- Higher returns from nearby horticulture and cash crops
- Implementation of local-scale land requisition–compensation projects
#### Effects
- Rice pushed from low-elevation areas toward surrounding hills
- Mosaic of paddy, horticulture, and built-up land at regional scale
- Increased fragmentation and costs for nearby rice producers

### Telecoupling
#### Systems
- Northeast China as sending rice system supplying national market
- Southern China as spillover rice system crowded out by northeast expansion
- Other Chinese regions as receiving systems mainly consuming rice inflows
#### Flows
- Interregional rice supply from northeast to southern and other regions
- Economic signals via national rice prices and profit differentials
- Indirect flow: soybean imports enabling northeast cropland shift to rice
#### Agents
- Central government setting rice price floors and land policies
- International soybean exporters to China (Brazil, United States)
- Agricultural input providers and mechanization services in northeast
#### Causes
- Comparative profit advantage of northeast rice over southern rice
- Higher profitability of alternative crops in southern China
- Global soybean trade displacing domestic soybean and freeing land for rice
#### Effects
- Absolute and relative crowding-out of southern rice by northeast rice
- Cascade: soybean imports–northeast rice expansion–southern rice decline
- Rising national rice stocks and altered varietal consumption structure

### Cross-Coupling Interactions
- Telecoupled soybean imports reshape northeast cropping, which telecouples to southern rice decline
- Policies modulate telecoupling strength by weakening or reinforcing market-driven crowding-out
- Heterogeneous southern subsystems create nested telecouplings within one national rice system

### Research Gaps or Limitations
- Uses profit differential proxy instead of explicit interregional rice trade flows
- Does not model intra-southern rice telecoupling or varietal trade explicitly
- Lacks fine-scale data on Japonica vs Indica production and flows

### Search Keywords
- telecoupling rice China northeast southern crowding-out
- rice spatial shift profit differential land use policy
- soybean imports cascading effects metacoupling

### Extraction Confidence
high
