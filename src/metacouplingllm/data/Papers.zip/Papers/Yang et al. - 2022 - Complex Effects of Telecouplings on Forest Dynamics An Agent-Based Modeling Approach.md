# Complex Effects of Telecouplings on Forest Dynamics An Agent-Based Modeling Approach

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:13:49.516935+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Yang et al. - 2022 - Complex Effects of Telecouplings on Forest Dynamics An Agent-Based Modeling Approach.pdf
- Year: unknown
- DOI: 10.1175/EI-D-20-0029.1
- OA status: gold
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: no license info, oa_status=gold

## Copyright-Safe Summary
This study investigates how multiple telecouplings jointly shape forest dynamics in a rural coupled human-natural system, using China’s Wolong Nature Reserve as a case. Telecouplings are here understood as socioeconomic and environmental interactions over distance, particularly nature-based tourism from cities to the reserve and temporary rural-urban labor migration.

Wolong is a mountainous protected area in southwestern China that harbors giant panda habitat and about 4,900 residents. Historically, local livelihoods depended on agriculture and fuelwood, contributing to substantial forest loss. Since the early 2000s, the area has experienced rapid tourism development, expanding labor migration to cities, and the rollout of major conservation payment programs. These changes have coincided with a turn from net forest loss to forest recovery.

The authors build an agent-based model (ABM) that explicitly couples three submodels: demographic processes (birth, death, marriage, household formation), telecoupling processes (household participation in tourism and migration, and their interaction), and a spatial landscape module simulating forest loss and regrowth at 90-m resolution. Parameters are drawn from censuses, household surveys in 1998 and 2005, satellite-derived land-cover maps from 1997 and 2007, and prior econometric work on fuelwood use and forest change. The model is calibrated and validated against observed population, household numbers, telecoupling participation, and forest cover, achieving acceptable accuracy.

Scenario simulations from 1996 to 2030 show that, considered separately, both tourism and labor migration reduce household fuelwood use and significantly enhance forest recovery relative to a no-telecoupling baseline. However, tourism jobs decrease households’ likelihood of sending migrants to cities, reducing the overall number of migrant households by roughly one-fifth by 2030. This interaction dampens the aggregate forest gain: forest cover is lower when the tourism-migration tradeoff is included than when both telecouplings are assumed independent.

The paper is explicitly about telecoupling and illustrates an antagonistic interaction between two telecoupling flows within a metacoupled system. It highlights the need to evaluate multiple telecouplings together, and demonstrates ABM as a useful tool for exploring complex telecoupling effects and informing policies on tourism, migration, and conservation.

## Structured Metacoupling Extraction

### Coupling Classification
- Telecoupling study of rural reserve linked with distant cities via tourism and labor migration

### Intracoupling
#### Systems
- Wolong Nature Reserve forest ecosystem and resident households
- Local panda conservation and biodiversity habitats
- Household demographic structure and land-use within reserve
#### Flows
- Fuelwood extraction from nearby forests
- Household formation and land clearing
- Local energy transition from fuelwood to electricity
#### Agents
- Local rural households and individual residents
- Reserve administration and conservation programs
- Household members engaged in farming or local tourism jobs
#### Causes
- Population growth and household splitting in the reserve
- Subsistence agriculture and livestock needs
- Conservation incentive programs reducing deforestation
#### Effects
- Changes in forest cover and panda habitat quality
- Shift in household energy mix and fuelwood demand
- Nonlinear forest loss then recovery over decades

### Pericoupling
#### Systems
- Wolong reserve and nearby townships under same administration
- Wolong and surrounding provincial tourism destinations
- Regional forest and conservation policy implementation
#### Flows
- Tourist movements within the province
- Policy payments for forest monitoring and land conversion
- Knowledge and management practices among local offices
#### Agents
- Township governments under Wolong Administration Bureau
- Provincial tourism and forestry authorities
- Local program administrators for conservation schemes
#### Causes
- Provincial tourism development strategies
- Implementation of regional conservation programs
- Improved local road access within the region
#### Effects
- Spatially uneven tourism participation among townships
- Widespread enrollment of households in conservation programs
- Variation in deforestation and recovery near settlements

### Telecoupling
#### Systems
- Sending system: Wolong rural coupled human and natural system
- Receiving system: Chinese and foreign cities hosting migrants or tourists
- Spillover systems: Other rural areas with tourism and migration
#### Flows
- Nature-based tourists traveling from cities to Wolong
- Temporary labor migrants moving from Wolong to cities
- Remittances and tourism income returning to Wolong households
#### Agents
- Urban tourists and tourism operators
- Urban employers hiring rural migrant workers
- National and provincial governments shaping migration and tourism
#### Causes
- Urban demand for ecosystem services and rural recreation
- Rural–urban income gaps and expanding transport networks
- Panda loans and media exposure increasing destination visibility
#### Effects
- Reduced fuelwood collection through off-farm income
- Forest recovery that depends on telecoupling intensity
- Antagonistic interaction where tourism suppresses migration benefits

### Cross-Coupling Interactions
- Tourism participation lowers household probability of sending labor migrants to cities
- Combined tourism and migration yield less forest recovery than sum of separate effects
- Panda loan telecoupling can enhance tourism via increased global media attention

### Research Gaps or Limitations
- Model omits tourism attraction of former migrants returning from cities
- Telecoupling drivers and feedbacks in distant cities not explicitly modeled
- Other telecouplings and synergies mostly discussed conceptually, not simulated

### Search Keywords
- telecoupling tourism labor migration Wolong agent-based forest fuelwood
- rural-urban linkages panda habitat conservation China
- coupled human and natural systems long-distance interactions

### Extraction Confidence
high
