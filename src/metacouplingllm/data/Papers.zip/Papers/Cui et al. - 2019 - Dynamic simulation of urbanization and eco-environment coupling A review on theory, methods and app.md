# Dynamic simulation of urbanization and eco-environment coupling A review on theory, methods and app

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:39:00.122151+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Cui et al. - 2019 - Dynamic simulation of urbanization and eco-environment coupling A review on theory, methods and app.pdf
- Year: unknown
- DOI: 10.11821/dlxb201906002
- OA status: unknown
- License: none recorded
- Category: Journal Articles\Review\Telecoupling
- Closed-access reason: no license info, oa_status=unknown

## Copyright-Safe Summary
This review examines how dynamic simulation can be used to understand and manage the interactions between urbanization and the ecological environment. The authors focus mainly on China but draw on international work, and frame urbanization-environment linkages as a complex, nonlinear, open system with feedbacks across space and time.

The paper first synthesizes theoretical foundations from human-environment systems, urban social-ecological systems, complex systems theory, coupled human and natural systems, and the telecoupling (near-far coupling) framework. These perspectives jointly support viewing urbanization-resource-environment interactions as multi-scale, multi-level, and subject to thresholds, emergent behavior, and distant connections.

Methodologically, the review categorizes dynamic simulation tools into: (1) system dynamics models for macro-level feedbacks and scenario analysis; (2) artificial intelligence approaches such as neural networks and Bayesian networks for learning nonlinear and uncertain relationships; (3) land-system models (CLUE/CLUE-S, cellular automata, multi-agent systems) to represent spatial urban expansion and land-use change; (4) integrated approaches that combine system dynamics with GIS, CA, agent-based modeling, or other components; and (5) emerging human-computer interactive decision-support platforms. The authors emphasize strong trends toward methodological diversification, higher spatial and temporal resolution, model integration, and intelligent decision support.

Applications are grouped around three themes: diverse case-region types (national and provincial scales, city-regions, river basins, oases, and mountain areas); multi-factor coupling that highlights key constraints such as water, land, and topography and broader ecological carrying capacity; and simulations that explicitly address near-field and far-field linkages and regional coordination, especially in Chinese urban agglomerations like Beijing-Tianjin-Hebei and the Yangtze River Delta.

The review is directly relevant to telecoupling and metacoupling research. It adopts a near-far coupling lens, notes the importance of flows of water, energy, goods, and information among sending, receiving, and spillover systems, and calls for quantitative, system-wide telecoupling models that link distant interactions to regional planning.

Key gaps include fragmented theory, limited integration of methods and data, incomplete representation of dynamic control factors and coupling chains, and underdeveloped, operational telecoupling simulations for policy use.

## Structured Metacoupling Extraction

### Coupling Classification
- Covers intra urbanization environment coupling and cross scale telecoupling
- Emphasizes near local coupling and distant telecoupling between regions

### Intracoupling
#### Systems
- Urbanization resources environment system within a city or region
- Urban social ecological system and coupled human natural system
#### Flows
- Local flows of land water energy and pollutants
- Information and capital circulation inside urban ecological systems
#### Agents
- Local governments planners and regulators
- Residents industries utilities and other urban stakeholders
#### Causes
- Rapid urban expansion and population concentration
- Intensive resource use and neglect of environmental constraints
#### Effects
- Land cover change habitat fragmentation and pollution
- Nonlinear EKC like curves of environment versus urbanization

### Pericoupling
#### Systems
- Neighboring cities within urban agglomerations
- Upstream downstream subsystems in shared river basins
#### Flows
- Regional commuting trade and pollution transfer
- Surface water flows supporting multiple urban areas
#### Agents
- Provincial and regional coordination bodies
- Intercity enterprises and commuters
#### Causes
- Regional economic integration and industrial relocation
- Shared rivers and ecological corridors linking cities
#### Effects
- Coordinated or conflicting regional environmental quality
- Spatial heterogeneity in resource pressure and ecological risk

### Telecoupling
#### Systems
- Distant sending and receiving regions in globalization
- Urban agglomerations linked to remote resource areas
#### Flows
- Virtual water imports and interbasin water transfers
- Long distance trade in energy and materials
#### Agents
- National governments and transregional planners
- Firms engaged in distant trade and infrastructure
#### Causes
- Globalization accelerating population material and information flows
- Cost advantages and policy incentives driving distant sourcing
#### Effects
- Externalized emissions and ecological risks in sending regions
- Altered vulnerability and resilience of distant social ecological systems

### Cross-Coupling Interactions
- Near local couplings embedded within broader telecoupled networks
- Urban agglomeration planning must consider both local and distant linkages

### Research Gaps or Limitations
- Telecoupling simulations lack quantitative systemic integration and policy linkage
- Dynamic chains and key control factors of coupling remain incompletely revealed

### Search Keywords
- urbanization eco environment dynamic simulation telecoupling
- system dynamics land use models artificial intelligence CHANS

### Extraction Confidence
high
