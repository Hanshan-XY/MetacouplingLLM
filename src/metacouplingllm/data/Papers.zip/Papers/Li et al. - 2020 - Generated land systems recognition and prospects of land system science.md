# Generated land systems recognition and prospects of land system science

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:51:43.073967+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Li et al. - 2020 - Generated land systems recognition and prospects of land system science.pdf
- Year: unknown
- DOI: 10.1139/er-2019-0045
- OA status: green
- License: none recorded
- Category: Journal Articles\Conceptual\Telecoupling
- Closed-access reason: green OA without permissive license (none)

## Copyright-Safe Summary
This conceptual paper reexamines land system science by arguing that most research has over-relied on system integration theory, which treats land systems as collections of interacting subsystems. The authors propose instead a complementary perspective rooted in system generation theory and introduce the notion of generated land systems.

The topic is global and not tied to a specific country or region. Generated land systems are defined as historically accumulated, human-environment complexes produced by people transforming, using, and adapting the Earths surface and its subsurface and atmospheric space. These systems integrate three inseparable dimensions: biophysical environment, land use, and socio-economy. The basic unit is a land cell, such as a village or urban neighborhood, which already contains the information and conditions for system growth.

Methods are conceptual and synthetic rather than empirical: the authors review existing land system research, connect it with theories of complex systems, hypercycles, geographic processes, and regional differentiation, and then build a new framework. They distinguish system boundaries vertically (from deep subsurface to the top of the troposphere) and temporally (from the rise of agriculture into a foreseeable human future).

A central contribution is the emphasis on multifunctionality. Generated land systems simultaneously perform energy conversion, material production, ecological maintenance, resource supply, social security, and cultural functions. Trade-offs among these functions drive evolutionary trajectories, which can take the form of minor fluctuations, degradation, or optimization, depending on the balance between system efficiency (ascendency) and capacity to adapt and recover (resilience). Systems cycle through emergence, development, stabilization, decline, and possible reorganization via functional transformation.

Telecoupling is explicitly recognized as a core research issue: cross-regional flows of goods, information, capital, and people link multiple generated land systems and shape their evolution at different scales. The paper outlines a research agenda on generation mechanisms, processes, adaptability, scale effects, telecouplings, uncertainty, and management strategies, highlighting implications for sustainable land governance within a metacoupled world.

## Structured Metacoupling Extraction

### Coupling Classification
- Conceptual paper on land systems; mentions telecoupling as key multi-scale driver
- Focuses mainly on internal human-environment dynamics within land systems
- Recognizes telecoupling between multiple generated land systems as research priority

### Intracoupling
#### Systems
- Generated land systems as coupled human-environment systems
- Land cells such as villages or urban communities
- Rural and urban land systems within one region
#### Flows
- Internal energy, material, and information flows within land systems
- Land use intensity and pattern changes over time
- Feedbacks among biophysical environment, land use, and social economy
#### Agents
- Local land users and farmers
- Urban residents and communities
- Local policymakers and planners
#### Causes
- Human transformation, use, and adaptation of land surface and subsurface
- Population growth, technology change, and institutions
- Demand for multiple land system functions
#### Effects
- Fluctuation, degradation, or optimization of land system states
- Trade-offs among production, ecology, and social security functions
- Cycles of generation, development, stabilization, recession, collapse

### Pericoupling
#### Systems
- Adjacent rural and urban land systems
- Neighboring regional land systems within a country
#### Flows
- Rural to urban migration and labor movement
- Regional trade in land-based products and resources
- Spread of land management policies across nearby regions
#### Agents
- Regional governments and planning agencies
- Inter-regional traders and enterprises
#### Causes
- Uneven regional development and income differences
- Spatial heterogeneity of resources and environmental conditions
#### Effects
- Rural decline and village disappearance near growing cities
- Shifts in regional social security and livelihood structures
- Redistribution of development pressures on nearby land systems

### Telecoupling
#### Systems
- Distant generated land systems linked by globalization
- Global land system as aggregate of regional systems
- Export-oriented production regions and distant consumer regions
#### Flows
- Long-distance trade in food, fiber, minerals, and energy resources
- Telecoupled impacts of global markets on local land use
- Information and policy diffusion affecting distant land management
#### Agents
- International traders and corporations
- National and global policymakers
- Transnational research and governance networks
#### Causes
- Globalization and integration of commodity markets
- Cross-scale economic, institutional, and cultural differences
- Remote demand for land system functions and ecosystem services
#### Effects
- Telecoupled disturbances altering local land system trajectories
- Cross-scale transmission of uncertainty and nonlinear feedbacks
- Multi-scale constraints on sustainability and functional trade-offs

### Cross-Coupling Interactions
- Telecoupling between multiple generated land systems modifies local evolutionary paths
- Scale effects transmit processes and functions across intra, peri, and telecouped systems
- External telecoupled shocks interact with internal feedbacks and regional differentiation

### Research Gaps or Limitations
- Need to clarify land system boundaries and socio-economic extents across scales
- Limited understanding of telecouplings in generated land system processes and uncertainty
- Insufficient integration of social and spatial modeling for multi-scale simulations

### Search Keywords
- generated land systems telecoupling multifunctionality hypercycle
- land system generation theory evolution fluctuation degradation optimization
- multi-scale land system processes feedbacks regional differentiation

### Extraction Confidence
high
