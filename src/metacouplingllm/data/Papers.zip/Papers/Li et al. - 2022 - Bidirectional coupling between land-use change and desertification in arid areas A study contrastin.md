# Bidirectional coupling between land-use change and desertification in arid areas A study contrastin

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:51:55.094749+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Li et al. - 2022 - Bidirectional coupling between land-use change and desertification in arid areas A study contrastin.pdf
- Year: unknown
- DOI: 10.1002/ldr.4139
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines how land-use change and desertification influence each other in an arid river basin, explicitly contrasting intracoupling (within-sub-catchment interactions) and telecoupling (upstream-to-downstream interactions). The case is the Tarim River in Northwest China, a highly water-limited system bordering the Taklimakan Desert.

Using MODIS time series (NDVI, albedo, and land cover) from 2001-2019, the authors derive a land-use index (degree of human land exploitation) and a desertification index based on a desertification difference index. They analyze three hydrologically linked sub-catchments (upstream, midstream, downstream). A vector autoregressive (VAR) model with generalized impulse response functions is applied to log-differenced annual indices. Intracoupling is examined for 2001-2019 in each sub-catchment; telecoupling is evaluated for 2001-2010, focusing on effects of upstream land-use change on downstream desertification, while minimizing interference from a later ecological water transfer project.

Over 2001-2019, land-use intensity generally rose, especially upstream due to farmland expansion, while overall desertification severity declined, aided by ecological restoration and water management. Intracoupling analysis shows that higher land-use intensity tends to suppress local desertification over the long term, because oasis expansion and ecological projects improve local conditions. However, there are time windows where land expansion temporarily worsens desertification, likely through competition for water.

Feedback from desertification to land use is weaker but directionally depends on existing land-use intensity. In highly developed upstream areas, increased desertification eventually triggers further land development and ecological engineering (positive feedback), reflecting high social resilience and investment capacity. In less developed midstream and downstream areas, desertification tends to limit land expansion (negative feedback).

Telecoupling results highlight that intensifying land use upstream exacerbates desertification midstream and downstream by capturing scarce river water, despite local oasis benefits. In response, downstream degradation later leads to some restraint of upstream land expansion, but with a time lag.

The paper is explicitly framed within the metacoupling/telecoupling paradigm and shows that ignoring upstream-downstream telecoupling can misrepresent land-use–desertification dynamics in arid basins.

## Structured Metacoupling Extraction

### Coupling Classification
- Analyzes intracoupling within sub-catchments and telecoupling across sub-catchments via flowing water.

### Intracoupling
#### Systems
- Upstream, midstream, downstream sub-catchments of Tarim River
- Local land-use system in each sub-catchment
- Local desertification status in each sub-catchment
#### Flows
- Water allocation among land-use types within sub-catchment
- Local feedbacks between land-use degree index and desertification index
- Soil and vegetation condition changes affecting desert processes
#### Agents
- Farmers expanding or adjusting oasis agriculture
- Local governments implementing ecological restoration projects
- Water managers allocating irrigation and ecological water
#### Causes
- Expansion of farmland and intensified land-use degree locally
- Ecological water conveyance and afforestation projects
- Population growth and pursuit of agricultural income
#### Effects
- Higher land-use degree generally suppresses local desertification long term
- Short-term land expansion can locally worsen desertification
- Desertification constrains land expansion more where land-use intensity is low

### Pericoupling
#### Systems
- Not identified.
#### Flows
- Not identified.
#### Agents
- Not identified.
#### Causes
- Not identified.
#### Effects
- Not identified.

### Telecoupling
#### Systems
- Upstream Tarim sub-catchment as sending system
- Midstream and downstream sub-catchments as receiving systems
- River basin water system linking upstream to downstream
#### Flows
- River water flowing from upstream to midstream and downstream
- Telecoupled impact of upstream land-use index on downstream desertification index
- Ecological water conveyance altering basin-wide hydrological connectivity
#### Agents
- Upstream irrigators increasing or reducing water use
- Basin-scale water authorities planning ecological conveyance
- Regional policymakers setting land and water regulations
#### Causes
- Upstream farmland expansion increasing consumptive water use
- Insufficient runoff reaching lower reaches before water-saving measures
- Reactive upstream land-use adjustments to downstream degradation signals
#### Effects
- Upstream land intensification aggravates desertification midstream and downstream
- Downstream desertification prompts delayed reduction in upstream land exploitation
- Telecoupled feedbacks influence basin-scale land degradation trajectories

### Cross-Coupling Interactions
- Intracoupling mitigation upstream can simultaneously intensify telecoupled degradation downstream via reduced flows
- Telecoupled downstream degradation feeds back to upstream land decisions with temporal lag
- Cultivated land scale upstream shapes both local and distant desertification dynamics

### Research Gaps or Limitations
- VAR model assumes linear relations, potentially missing nonlinear land–desertification dynamics
- MODIS land-use product underestimates farmland, limiting accuracy of land-use degree estimates
- Analysis aggregated at sub-catchment scale, lacking grid-level spatial interaction detail

### Search Keywords
- Tarim River desertification land-use bidirectional coupling
- intracoupling telecoupling water-mediated land degradation
- vector autoregressive model oasis agriculture arid China

### Extraction Confidence
high
