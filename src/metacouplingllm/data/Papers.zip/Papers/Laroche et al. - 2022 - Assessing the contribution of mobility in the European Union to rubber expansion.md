RESEARCH ARTICLE

# Assessing the contribution of mobility in the European Union to rubber expansion

Perrine C. S. J. Laroche $\textcircled{1}$ , Catharina J. E. Schulp, Thomas Kastner, Peter H. Verburg

Received: 2 November 2020 / Revised: 16 March 2021 / Accepted: 16 May 2021 / Published online: 12 June 2021

Abstract Nearly three-quarters of global natural rubber production is used to produce tyres, supporting mobility around the globe. The projected increase in mobility could contribute to further expansion of rubber plantations and impact tropical ecosystems. We quantified the use of natural rubber in tyres in the European Union (EU), the corresponding land footprint, and explored drivers of tyre use using country-specific transport statistics and trade registers of rubber goods. Five percent of the world’s natural rubber is consumed in tyres used in the EU, using up to a quarter of the area under rubber plantations in some producing countries. Car use is responsible for $58 \%$ of this consumption, due to car-dependent lifestyles that are associated with economic prosperity and spatial planning paradigms. While the EU’s transport policy focuses on reducing dependence on fossil-fuels, cross-cutting policies are needed to address car-dependency and reduce the EU’s land footprint in tropical landscapes without compromising progress towards decarbonisation.

Keywords Carbon emission $\cdot$ Ecological impact - European Union $\cdot$ Natural rubber - Telecoupling - Transport

# INTRODUCTION

Over the past decade, demand for natural rubber has grown steadily by five percent every year (ETRMA 2019a) leading to the rapid expansion of rubber plantations in tropical countries (FAOSTAT 2019). High rubber

prices on international markets have triggered many governments to promote rubber production as a way to fight rural poverty (Ahrends et al. 2015). Numerous smallholders have adopted rubber production and large rubber plantations have been established by agribusinesses (Warren-Thomas et al. 2015). While the primary hotspot for rubber expansion is Southeast Asia (Dove 2018), similar trends are being observed in other parts of Asia (Debbarma and Purkayasthaıˆ 2019) and in Africa (Feintrenie 2014), and future expansion is expected in South America (Heer et al. 2015).

Rubber plantations have been associated with deforestation since colonial times (Lang 2001). More recently, rubber expansion has driven deforestation in China (Qiu 2009) and Southeast Asia (Reddy et al. 2016; Hurni and Fox 2018). In Sub-Saharan Africa, forested land has been converted into subsistence cropland near newly established rubber estates in order to meet the needs of local plantation workers (Feintrenie 2014). In many cases, rubber plantations have replaced forested land that had been degraded by years of shifting cultivation (Hurni and Fox 2018; Neyret et al. 2020). Due to its suitability to sloping terrain, rubber is additionally one of the few boom crops expanding into upland areas, threatening relatively untouched ecosystems such as the mountainous regions of Asia (Fox et al. 2014) or the central region of Coˆ te d’Ivoire (Ouattara 2019).

Land use change associated with increasing rubber cultivation has ecological consequences, such as biodiversity loss and erosion. High erosion rates from intense rainfall were reported in upland rubber plantations (Ahrends et al. 2015) because soil quality and understory structure are poor compared to forests. Additionally, lower organic matter input (Van Straaten et al. 2015) and high fertilizer inflows (Berkelmann et al. 2020) within monoculture rubber plantations threaten multitrophic abundance

and diversity (Barnes et al. 2014; Singh et al. 2019). Rubber plantations can support a diversity and abundance of some common animal species, but species of high conservation value prevail in natural forests in much larger numbers (Paoletti et al. 2018). Ecological disturbances are not as severe in rubber tree-based agroforestry systems, due to additional supply of organic matter and habitats (Liu et al. 2018; Warren-Thomas et al. 2020). Yet, currently agroforestry systems account for only half of the cultivated area in Indonesia and approximately $5 \%$ in Thailand (Penot et al. 2017).

Past trends have shown that the price of natural rubber is highly volatile in the long term (Grogan et al. 2019) due to the structure of the production sector, the seven-year ripening period, and the vulnerability of rubber trees to climatic events and pest outbreak (Meyer 2019; Millard 2019). Yet, prospects for rubber profits, and more recently carbon sink plantation plans and programmes (e.g. AFR100, the Bonn Challenge) (WRM 2020), are driving the global rubber boom, attracting smallholders (who supply $80 \%$ of world production), national governments, and investors into rubber production (Fox et al. 2014; Debbarma and Purkayasthaıˆ 2019).

The automotive industry is the biggest rubber user globally, with over $70 \%$ of global natural rubber production being used for tyres (Millard 2019). Trend-based scenarios expect a tripling of freight transport and a doubling of passenger flows by 2050 (ITF 2019). Private motor vehicle use in cities is expected to decrease as shared mobility increases, but nonurban private transport is expected to increase as rising per capita income in many countries is likely to enable growth in car ownership. Additionally, increasing leisure time and tourism opportunities might increase demand for transport (ITF 2019). Transport growth projections for the European Union (EU) are very modest when compared to other world regions (ITF 2019), as current mobility levels are already relatively high by global standards. Nevertheless, mobility patterns are heterogeneous in the EU, as demonstrated by strong variations in car ownership (Focas and Christidis 2017) and mobility cultures (Haustein and Nielsen 2016).

The EU’s transport policy currently focuses exclusively on reducing greenhouse gas emissions from the sector to a level $60 \%$ lower than in 1990 by 2050 without curbing projected mobility growth (European Commission 2011). However, aiming for ever higher levels of mobility in the EU might lead to an increase in global rubber production, with repercussions to ecosystem functioning in the tropics. Therefore, the objective of this study is to assess the current contribution of mobility patterns in the EU to global natural rubber use and production. We estimate the annual use of natural rubber per vehicle category and spatially allocate its related land footprint. We then assess links to

mobility patterns in the EU by comparing the rubber efficiency of overland vehicles and the correlations between per capita consumption of natural rubber in car tyres, and car use for everyday trips and long-distance travel for business or leisure.

# MATERIALS AND METHODS

We quantified the annual use of natural rubber for mobility in the EU based on transport statistics, and used bilateral trade records and production data to estimate and allocate the land footprint to countries where rubber is grown. We estimated the rubber efficiency of overland vehicles, i.e. the amount of natural rubber used to move a person or a metric ton of goods over a distance of $1 0 0 ~ \mathrm { k m }$ , and calculated the per capita use of natural rubber in car tyres at the country level to assess correlations with car use for different purposes. The three components of our methodology are depicted in Fig. 1 and elaborated upon in detail in the following sections.

# Natural rubber use in the European Union

To assess the quantity of natural rubber needed to support mobility in the EU, we translated country-specific transport statistics for a wide range of vehicles with tyres (including aircrafts) into annual use of vehicles, tyres, and natural rubber, using a number of conversion factors (Fig. 1). We analysed the sensitivity of our results to variations in certain parameters for which substantially different values were found (see Fig. S2). Minimum impacts were calculated by applying the minimum number of tyres per vehicle, lowest natural rubber content, and highest tyre lifespan, while maximum impacts were obtained with the maximum number of tyres, highest natural rubber content, and lowest tyre lifespan.

# Total vehicle use (vkm)

Tyre use depends on the total aggregated distance travelled annually by different categories of road vehicles, commonly labelled ‘‘vkm’’ in transport statistics. The latest vkm available for motorcycles and light vans are provided by TRACCS (2013) for 2010. For medium and heavy trucks, the latest vkm is reported by Eurostat (2020a, b) for 2017, broken down into 17 sub-categories according to the number of axles on front and towed vehicles. Only for Belgium, Hungary, Italy, Malta, and the Netherlands, we lacked data, so we used the vkm provided by TRACCS (2013) for 2010, matching the truck categories according to the maximum authorized weight (Gov.UK 2013) (Table S1). For cars and buses, DG MOVE (2018) provides

![](images/e732b7d28b5ba0c45cae0a4ab6e0b1b359b789e0bfabd73f637be42857f973fc.jpg)  
Fig. 1 Overview of the methodology

the total aggregated distance travelled in 2017 by all passengers, commonly labelled ‘‘pkm’’ in transport statistics. We converted the pkm into vkm, following Eq. (1), using country-specific occupancy rates, i.e. the average number of people traveling in one vehicle per trip, from Fiorello and Zani (2018) for cars and from TRACCS (2013) for 2010 for buses.

$$
\mathrm {v k m} (\text {e . g . c a r s}) = \frac {\mathrm {p k m} (\text {e . g . c a r s})}{\text {c o u n t r y - s p e c i f i c o c c u p a n c y r a t e} (\text {e . g . c a r s})} \tag {1}
$$

We estimated the vkm for bikes by multiplying the average distance (in km) cycled per capita per day (data collected between 2008 and 2015, from Steenberghen et al. 2017), by 365 and by the countries’ population in 2017. Our estimate is limited to 13 countries (Austria, Belgium, Cyprus, Denmark, Finland, France, Germany, Ireland, Latvia, Netherlands, Slovakia, Sweden, and United Kingdom), because data were not available for the remaining 15 countries. The countries that are included represent $56 \%$ of the EU’s population.

# Tyre use

The amount of natural rubber consumed during vehicle use is determined by tyre use, which depends on the number of

wheels per vehicle and the lifespan of a tyre (Table S2). Values for tyre lifespan were obtained from TNO (2016) and USTMA (2020a) for passenger cars and light vans, from ETRMA (2017) for buses and trucks, and from Schwalbe (2021) for motorcycles and bikes, while the number of wheels per vehicle was estimated based on the vehicles’ structure. We estimated tyre use per category of vehicle following Eq. (2).

$$
\text {t y r e} \quad (\text {e . g . c a r s}) = \frac {\mathrm {v k m} (\text {e . g . c a r s})}{\text {t y r e l i f e s p a n} (\text {e . g . c a r})} \\ \times \text {n u m b e r o f w h e e l s} (\text {e . g . p e r c a r}) \tag {2}
$$

Additionally, we calculated annual tyre use for aircrafts following Eq. (3), using the number of passenger aircrafts registered in each country in 2018 (DG MOVE 2018) and data regarding the number, composition and lifespan of aircraft tyres (the average number of landings before a tyre is replaced) (personal communication, 2019). Although the variety of aircrafts is high, we assumed Embraer 190 to be representative for passenger aircrafts with 150 seats or less and freight aircrafts with maximum take-off weight allowed includes aircraft and cargo weight (mtow) under 45 metric tons, and Airbus A330-200 to be representative for passenger aircrafts with more than 150 seats and freight aircrafts with mtow over 45 metric tons. These two aircraft

models are widely used in Europe (personal communication, 2019). We estimated the annual number of landings per aircraft from flight records for the year 2019 (Flightradar24 2021).

$$
\begin{array}{l} \begin{array}{l} \text {n u m b e r o f l a n d i n g s p e r y e a r} \\ \text {v} \end{array} \\ \mathrm {t y r e l i f e s p a n} \\ \times \text {n u m b e r o f w e e l s (p e r a i r c r a f t)} \\ \end{array}
$$

ð3Þ

Natural rubber (NR) use

In addition to the quantities of tyres used annually, the natural rubber content of tyres determines the demand for natural rubber. Tyre weight and composition are customdesigned to meet the needs of each vehicle model (USTMA, c2020), but such quantitative and detailed data are scarce. We used the most reliable data we could find into tyre manufacturers’ booklets from several world regions, blogposts, e-shops, rubber compound patents, and communication with experts (Table S2). We are confident that combining data from different years is not problematic since the substitution of natural and synthetic rubbers in industrial products and processes is practically challenging and unprofitable (Wagner 2020). We calculated natural rubber use following Eq. (4). The rubber content (in kg) in tyres is estimated by categories of land vehicles from market data for the year 2017 (JATMA 2019), indicating the number of tyres and tubes produced and the equivalent in tons of rubber. The proportion of natural rubber in passenger and light truck tyres is reported by USTMA (2020b), as well as in truck tyres, which we applied to buses and medium/heavy trucks tyres. In line with the composition of the rubber compound of standard motorcycle tyres described by Ngeow et al. (2013), we assumed $100 \%$ of synthetic rubber in motorcycle tyres, but also quantified the maximum impact with $100 \%$ natural rubber. For bike tyres, we used the weight and composition indicated for three bestseller models from Decathlon (2021). For aircraft tyres, the natural rubber content equals the weight of the tread as $100 \%$ of the rubber is natural (personal communication, 2019).

$$
\begin{array}{l} \times \text {r u b b e r c o n t e n t (e . g . i n c a r t y r e)} \\ \times \text {p r o p o r t i o n N R (e . g . i n c a r t y r e)} \\ \end{array}
$$

# Natural rubber origin and land footprint

Natural rubber is used in a wide range of products other than tyres and is traded in several forms between the

countries that harvest, transform or ultimately use it. We translated bilateral trade flows of rubber goods and new vehicles into metric tons of natural rubber, and used an input–output approach to trace back the origin of the natural rubber ultimately used in European countries (Kastner et al. 2011).

# Metric tons of natural rubber

We used global data on bilateral trade flows (import) from the United Nations (2013) COMTRADE database. We multiplied the traded quantities by the proportion of natural rubber in representative items for 17 categories of rubber goods (Table S3), based on the rubber compounds detailed in Chandrasekaran (2007), Nocil Limited, (2010), and USTMA (n.d.) (Table S4). Additionally, we translated bilateral trade flows of new vehicles with tyres (Table S3) because these are commonly traded with tyres. We used a sample of bilateral flows reported both in metric tons and in number of vehicles to estimate the average weight of a vehicle from each category, and used this weight to convert all bilateral flows into number of vehicles. Then, we multiplied the bilateral flows by a standard number of wheels per vehicle and by the share of natural rubber in a tyre to obtain bilateral flows in metric tons of natural rubber. To account for the volatility in bilateral trade relationships, we used an average of records for 2016, 2017, and 2018. For Slovenia, we excluded values for 2017 that were unusually high.

# Land footprint in rubber growing countries

We used an input–output approach to trace back the origin of the natural rubber finally used in the EU, following the method developed by Kastner et al. (2011). We used natural rubber production data from FAOSTAT (2019) for 2016. In the absence of explicit data on preferences for natural rubber from specific origins for specific goods, we assumed exports and domestic final consumption to originate proportionally from domestic production and imports, similarly to Kastner et al. (2011). We obtained the natural rubber sourcing matrix for the EU (see Fig. S5), indicating the contribution of each rubber growing country (rows) to the total amount of natural rubber available for final use in each EU country (columns), in proportions, and used it to allocate the EU’s natural rubber use in tyres calculated in Sect. 2.1., among the rubber growing countries (Fig. 1). The land footprint of EU mobility in 2017 is then estimated using country-specific yield data from FAOSTAT (2019) for 2016.

# Drivers of natural rubber use in the European Union

First, we compared the rubber efficiency of overland vehicles used for passenger and freight transport to reflect on the performance of different vehicle choices in the EU. Second, we assessed how car use for different purposes influences the average amount of natural rubber used per capita in 2017, using indicators available for all EU 28 countries.

# Rubber efficiency of vehicles

Passenger cars, buses, motorcycles, bikes, and passenger aircrafts are assumed to serve personal mobility, while light vans, medium and heavy trucks, and freight aircrafts are assumed to serve the transport of goods. Each type of vehicle uses a different amount of natural rubber to serve personal mobility or the transport of goods. To assess how the preference for certain types of vehicle influences demand for natural rubber, we compared the rubber efficiency of vehicles, i.e. the amount of natural rubber used to transport one person or one metric ton of goods over 100 km, on average, in the EU.

# Purposes of car use

Cars shape people’s lifestyles by supporting personal transport but also by serving as a means of expressing a certain lifestyle (Buehler et al. 2017). The car is currently the most widely used mode of transport in the EU (Pastori et al. 2018) for everyday travel and for long-distance trips for business or leisure (Aparicio 2016). To assess how these three main purposes of car use influence demand for natural rubber, we used country-level indicators for the EU 28 derived from data from DG MOVE (2014) and Eurostat (2020a, b) for 2017 (Table 1). We used the Spearman’s rank correlation, a non-parametric test without assumptions regarding the distribution of the data, to measure the

relation between per capita natural rubber use in car tyres in 2017, and the extent to which the car is used for different purposes at the country level. We also estimated correlations between car use for different purposes to understand co-occurrence.

# RESULTS

# Vehicles, tyres and natural rubber use in the European Union

Two-thirds of the total distance travelled in 2017 by overland vehicles with tyres registered in the EU is covered by passenger cars, while freight transport accounts for $17 \%$ of which $70 \%$ is comprised by light vans (Table 2). Passenger cars also dominate the demand for tyres $( 5 5 \% )$ . Motorcycles and bikes each constitute around $16 \%$ of the total demand for tyres, due to their lower average tyre lifespan (Table S2). Conversely, the relatively longer lifespan of truck and bus tyres compensates for the higher number of wheels when transforming distance into number of tyres used. We estimated that around 672 000 metric tons of natural rubber are consumed annually by the vehicles with tyres registered in the EU, corresponding to $5 \%$ of global natural rubber production (ETRMA 2019a). Nearly two-thirds of this amount is used for personal mobility, and one-third to move goods. Major contributors are passenger cars and light vans, due to long distances travelled, and trucks due to the high share of natural rubber in their tyres. Motorcycles do not contribute to natural rubber consumption as long as their tyres do not contain any natural rubber. Assuming $100 \%$ natural rubber in motorcycle tyres would increase their contribution to total natural rubber use to an amount similar to that of cars (Table 2). Aircrafts account for only $0 . 0 6 \%$ of the natural rubber consumption, even though the rubber used in aircraft tyres is $100 \%$ natural, and frequently renewed.

Table 1 Indicators of car use for three main purposes at the country level   

<table><tr><td>Purposes of car use</td><td>Indicator</td><td>Data source</td></tr><tr><td>Everyday travel, e.g. to and from work, housekeeping and leisure activities</td><td>Share of the population using the car as main mode of transport for everyday travel</td><td>DG MOVE (2014) for 2014</td></tr><tr><td>Travel to professional gatherings that involve at least one overnight stay</td><td>Number of business trips by car per capita</td><td>Eurostat (2020a) for 2017</td></tr><tr><td>Travel to vacations that involve at least one an overnight stay</td><td>Number of holiday trips by car per capita</td><td>Eurostat (2020) for 2017</td></tr></table>

Table 2 Contribution of vehicles with tyres used for personal mobility and transport of goods, to the total distance travelled, the number of tyres used, and the quantity of natural rubber used in a year in the EU 28. We considered bike use in 13 countries, representing $56 \%$ of the EU28 population, and did not assess the distance travelled by aircrafts   

<table><tr><td rowspan="2">Vehicle category</td><td rowspan="2">Distance (109vkm)</td><td colspan="2">Tyres used (106units)</td><td colspan="2">Natural rubber (103metric tons)</td><td colspan="2">Share of the total natural rubber use (%)</td></tr><tr><td>Mid value</td><td>Min-max</td><td>Mid value</td><td>Min-max</td><td>Under mid value</td><td>Under min-max values</td></tr><tr><td>Passenger cars</td><td>3279</td><td>202</td><td>101–262</td><td>391</td><td>195–508</td><td>58%</td><td>50%-32%</td></tr><tr><td>Buses</td><td>28</td><td>0.8</td><td>0.5–2</td><td>14</td><td>9–41</td><td>2%</td><td>2%-6%</td></tr><tr><td>Motorcycles</td><td>157</td><td>63</td><td>31–157</td><td>0</td><td>0–486</td><td>0%</td><td>0%-30%</td></tr><tr><td>Bikes (13 countries only)</td><td>144</td><td>58</td><td>29–144</td><td>17</td><td>5–99</td><td>3%</td><td>1%-6%</td></tr><tr><td>Passenger aircraft</td><td>NA</td><td>0.8</td><td>0.8–0.8</td><td>0.4</td><td>0.4–0.4</td><td>0.06%</td><td>0.1%-0.03%</td></tr><tr><td>Personal mobility</td><td>3609</td><td>325</td><td>162–566</td><td>422</td><td>209–1134</td><td>63%</td><td>53%-74%</td></tr><tr><td>Light vans</td><td>511</td><td>31</td><td>16–41</td><td>82</td><td>41–106</td><td>12%</td><td>11%-7%</td></tr><tr><td>Medium and heavy trucks</td><td>223</td><td>10</td><td>8–21</td><td>168</td><td>136–359</td><td>25%</td><td>35%-22%</td></tr><tr><td>Freight aircrafts</td><td>NA</td><td>0.1</td><td>0.1–0.1</td><td>0.04</td><td>0.04–0.04</td><td>0.006%</td><td>0.01%-0.0003%</td></tr><tr><td>Transport of goods</td><td>734</td><td>41</td><td>24–62</td><td>250</td><td>177–465</td><td>37%</td><td>46%-29%</td></tr><tr><td>Total</td><td>4342</td><td>366</td><td>186–628</td><td>672</td><td>384–1599</td><td>100%</td><td>100%</td></tr></table>

# Origin of natural rubber used in the EU 28 and respective land footprint

An area of 594 000 hectares is required to produce the natural rubber consumed annually through tyre use in the EU, corresponding to $5 \%$ of the total global area harvested annually (Table S5). This land footprint is mainly located

in Indonesia $( 3 2 \% )$ , Thailand $( 2 3 \% )$ , Malaysia $( 1 1 \% )$ , and Coˆte d’Ivoire $( 1 0 \% )$ , and China $( 1 1 \% )$ (Fig. 2). At the national level, the share of land harvested to produce tyres for use in the EU is particularly high in Cambodia $( 2 5 \% )$ and several African countries. In Coˆte d’Ivoire, Guinea, and Cameroon, more than $15 \%$ of the area under mature rubber plantations serves European mobility (Fig. 2).

![](images/b6a063ed147a86d04a2feb5240e50c1dfe2c97b599c904f5b6bdbcf0a53866dd.jpg)  
Fig. 2 Spatial distribution of the land footprint of mobility in the EU. For countries where the EU uses $> 5 \%$ of the harvested area, pie charts show the share of the total area harvested in 2016 used to support mobility in the EU in 2017

![](images/9cd87590a77d86d08e5da71e596fa055985278573dedf7898d0540e81f636da8.jpg)

Distance ton kilometers per year

Fig. 3 Modal share of overland vehicles used for personal mobility (left chart) and for transport of goods (right chart) in the EU according to the total distance travelled in pkm, and tkm   
![](images/0ec2a0e449817e528f18c2e03d64d76e1fbd3db212bfb09fd14ade1b144711f4.jpg)  
*average payload per light van: 1 ton   
cars buses motorcycles metro / tramway bikes rail light vans trucks

# Rubber efficiency of overland transport

More than three-quarters of the distance travelled overland in the EU in 2017 was by car. The remaining quarter was shared among buses $8 \%$ of total pkm), rail $( 7 \% )$ , motorcycles, bikes (estimation limited to 13 countries), and public transport (less than $1 \%$ each). The overland transport distance of goods (in tkm) mainly involved trucks with a payload over 3.5 metric tons (two-thirds), followed by vans $( 1 8 \% )$ and rail $( 1 5 \% )$ (Fig. 3).

In terms of natural rubber consumption, bikes are less efficient than cars for personal mobility, but this varies according to the type of bike used (Table S2), i.e. road bikes, which are the most convenient for long distances, are more efficient (Fig. 4). Cars are less efficient than buses because of their low occupancy and fast tyre turnover. The efficiency of motorcycles relies on the high proportion of synthetic rubber in the tyres. Metros, tramways, or trains do not use natural rubber for personal mobility, or for the transport of goods. Vans consume more natural rubber than trucks to transport one metric ton of goods over $1 0 0 \mathrm { k m }$ (Fig. 4).

# Car use

Per capita natural rubber use in car tyres varies strongly among European countries (Fig. 5). The highest

consumption in 2017 is observed in Luxembourg $( 1 . 1 0 \mathrm { k g } )$ and the lowest in Romania $( 0 . 2 6 \mathrm { k g } )$ . Higher levels of consumption are generally observed in wealthier countries with a relatively high motorization rate (Figure S2).

At the national level, per capita use of natural rubber in car tyres is positively correlated with national indicators reflecting the habit of using the car for everyday trips or long-distance travel for business and leisure (Table 3, Fig. S2). The strongest correlation (0.83) is found between per-capita natural rubber use and the share of population commuting by car. Weaker, yet positive correlations are found between per-capital natural rubber use and number of business and leisure trips by car per year per capita. Correlations between indicators of car use for different purposes are also positive, and often stronger than correlations with per capita use of natural rubber (Table 3).

# DISCUSSION

# Interpretation of the results

While the consequences of large-scale conversion of forested land into monoculture rubber plantations are increasingly documented, the demand for natural rubber, the main driver of these land use conversions, remains underexplored. Rapid, recent developments in China are

![](images/17b122a0b99f42282c92b63a80e31ca75e8c3efb0066829a8151cc1c4240da54.jpg)  
Fig. 4 Comparison of the rubber efficiency of overland vehicles (in g per $1 0 0 \mathrm { k m }$ ), between those used for personal mobility (left), and between those used to transport goods (right)

often mentioned as a major driver of the rubber boom (e.g. Qiu 2009; Warren-Thomas et al. 2015), whereas mobility patterns in Western societies are rarely addressed. Our study demonstrates that mobility in the EU uses nearly a fifth of the annual harvest of natural rubber in several producing countries, therefore contributing to the expansion of rubber plantations in the tropics (Fig. 2). Attributing the use of natural rubber to vehicle categories shows that natural rubber use is mainly related to car use (Table 2), underlining the role of personal mobility. We found large differences in the per capita natural rubber use in car tyres among countries of the EU, with highest values in more affluent countries (Fig. 5). This suggests that demand from the EU might increase with economic development in the eastern member states in the near future (Tsemekidi Tzeiranaki et al. 2020).

Clear differences in the rubber efficiency of overland vehicles (Fig. 4) suggest that modal shifts can contribute to decreasing the demand for natural rubber, but the substitutability of different overland vehicles might be limited or inefficient in practice. Vans are more convenient to transport goods over short distances with frequent stops, e.g. in urban centres (Browne et al. 2010) or for e-commerce deliveries for which vans might also substitute the use of private cars for shopping-related travel (Rotem-Mindali and Weltevreden 2013). Reducing the demand for natural rubber by favouring air freight is not desirable because it can increase carbon emissions. Transport by inland waterways is a rubber and carbon efficient option, but relies on climatic conditions (Sims et al. 2015) and availability of navigable waterways. Low average car occupancy rates $( < 2 )$ in most European countries (Fiorello and Zani 2018) explains car inefficiency for personal mobility. In low-

density areas, where collective alternatives to the car for commuting are limited, shared mobility could be an option (Sims et al. 2015). Nevertheless, even with rising occupancy rates, cars are unlikely to outperform public transport (Fig. S1). In urban centres, the promotion of bike use remains a sustainable option because it avoids energy consumption for mobility, but emerging trends, such as the use of electric fat bikes for everyday travel, could turn out to be a detrimental shift.

National indicators revealed that natural rubber use is related to the widespread use of cars for everyday travel, which in turn is associated with relatively frequent longdistance travel by car (Table 3). Car ownership is the strongest driver for frequent car use, ahead of commuting distance or access to public transport infrastructure (Focas and Christidis 2017). Motorization rates have been shown to increase with disposable income because, beyond its practicality, the car confers social status and gives access to symbolic activities such as leisure travel (Steg et al. 2001). Additionally, many Europeans receive a company car with a discounted access to fuel for business and personal travel (Gutie´rrez i Puigarnau and van Ommeren 2011), which results in a significant level of additional mileage (Shiftan et al. 2012). Conversely, the use of private cars can be limited due to operating costs (e.g. Poland, Czech Republic) or the preference for soft modes for everyday travel (e.g. Austria) (Haustein and Nielsen 2016) (Fig. S2).

# Limitations

There is a lack of official, openly available data on most aspects related to natural rubber use and production. We therefore had to rely on a wide range of data from hugely

![](images/86cd87ffbe7415bdc032709d4a235f7f952c684c38a04ebcd16b80e73f686f81.jpg)  
Fig. 5 Per capita natural rubber use (in kg) in car tyres in countries of the EU in 2017

Table 3 Spearman-Rank correlations between per capita use of natural rubber in car tyres and the extent to which the car is used for three main purposes. $P$ value: $^ { * * } 0 . 0 1$ , $^ { * * * } { 0 . 0 0 1 }$   

<table><tr><td></td><td>Share of the population using the car for most everyday travel</td><td>Number of business trips by car per capita per year</td><td>Number of leisure trips by car per capita per year</td></tr><tr><td>Per capita annual use of natural rubber in car tyres</td><td>0.83***</td><td>0.60***</td><td>0.49**</td></tr><tr><td>Share of the population using mostly the car for everyday travel</td><td></td><td>0.66***</td><td>0.58**</td></tr><tr><td>Number of business trips by car per capita per year</td><td></td><td></td><td>0.72***</td></tr></table>

different sources. As a consequence, uncertainties in some parameters are high (See Tables S2, S5, S6, and Fig. 4). Tyre lifespan estimates vary by a factor two, perhaps revealing the diversity of models that differ in size and

composition (ASDA 2019), to match different vehicles and ensure safety on the road under all weather conditions (Uniroyal 2018). Truck tyres ‘‘made in Europe’’ have a greater lifespan than imported tyres, because they are built

to be retreaded up to three times (ETRMA 2017b). Over the last decade, EU’s imports of truck tyres, especially from China, have increased (ETRMA 2017a), but the share of imported tyres in total use is uncertain as tyres can be reexported. In addition, the number of wheels per bus and truck varies with the type of vehicle but also with the load transported. When combining minimum numbers of wheels with maximum tyre lifespan, the contribution of personal mobility and transport of goods to natural rubber use for mobility in the EU are almost equal, and the land footprint is reduced to 342 000 ha. In the reverse scenario, the annual use of natural rubber reaches 1.6 million metric tons, including 486 000 metric tons used in motorcycle tyres, and the land footprint reaches 1.4 million ha, corresponding to $12 \%$ of the total area harvested in 2016. Finally, the contribution of bike use to natural rubber use in the EU is likely to be largely underestimated because data on the annual distance travelled were missing for 15 countries, and the contribution of e.g. city, road, all-terrain bikes to this distance is unknown. Accounting for missing countries would also likely increase the total land footprint.

We quantified natural rubber use through tyre use, but natural rubber is also used in small amounts in other vehicle parts (e.g. train car junctions, passenger car mats), meaning that transportation uses more than the estimated $70 \%$ of global natural rubber production. To quantify the land footprint, we used production and yield data from FAOSTAT (2019), because it is the only available comprehensive free global data source. However, a large proportion of these data is imputed by FAOSTAT (2019) because producing countries do not consistently report them (Table S8). Country-specific yields are particularly uncertain because they depend on planting and tapping schemes, which are not officially monitored. Natural rubber can have a wide range of exact specifications, and exporting countries might specialize in producing natural rubber for specific goods (e.g. tyres, industrial parts). However, we calculated the contribution of each producing country based on reported trade flows that only provide an aggregated figure for natural rubber and do not allow for distinguishing between specific products. Moreover, by applying the approach from Kastner et al. (2011) we included the main assumption that the natural rubber contained in exported items originates proportionally from import and production. While these two assumptions impact the distribution of the land footprint, our estimate that tyre use in the EU uses around $5 \%$ of global natural rubber production is in line with ETRMA (2019b), who report that the EU ultimately uses $9 \%$ of the natural rubber produced in the world, of which $70 \%$ is used in tyres. In addition, the EU’s strategy to reduce its dependence on Southeast Asia (ETRMA 2019b) is reflected in our estimate that almost $2 5 \%$ of the natural rubber imported in Europe

originates from Africa, which is more than Africa’s contribution to global production (FAOSTAT 2019).

# Implications

Political and economic decisions in recent decades have shaped urban planning and people’s preferences for private cars (Mattioli et al. 2020). Given that almost $7 5 \%$ of Europeans live in cities, suburbs and towns (Eurostat 2016), the potential impact of urban planning on reducing car use for commuting and the EU’s land footprint in tropical countries is high. Pricing measures targeting road and fuel use, and the expansion of cycling and walking lanes at the expense of parking and traffic space in congested cities, can encourage a modal shift (Sims et al. 2015). When economic stress is low, maintaining high car ownership rates does not prevent a reduction in car use for everyday travel (e.g. the Netherlands (Kroesen 2017)), but might result in an upturn in the car mileage for long-distance travel (Holz-Rau et al. 2014). To reduce the number of car owners, functional and symbolic aspects of passenger cars must be addressed (Axsen and Sovacool 2019). Environmental awareness can be a trigger, but habits (Sopjani et al. 2020) and active lifestyles (Haustein and Nielsen 2016), often involving high mobility to reconcile work and private life (Viry and Kaufmann 2015), are barriers. The Covid-19 pandemic has reduced travel opportunities, but its impact on car ownership is uncertain, as private cars allow for traveling while limiting social contacts (Kanda and Kivimaa 2020).

Solutions to limit the consumption of natural rubber result in synergies and trade-offs with the main objective of the Paris Agreement to drastically and rapidly lower global greenhouse gas emissions levels. Car use is responsible for around $12 \%$ of the EU’s carbon emissions (DG Climate 2011). A modal shift towards collective alternatives for overland personal mobility could reduce carbon emissions and pressure on land for rubber, as the emission intensity of cars is higher (Sims et al. 2015; Ivanova et al. 2018). Conversely, replacing the EU’s car fleet with electric cars is expected to decrease carbon emissions by up to $70 \%$ by 2050 (Lutsey 2015), but will not lower demand for natural rubber or non-exhaust particulate emissions from the wearing down of tyres (OECD 2020). Measures to regulate carbon emissions from air transport (Sims et al. 2015) might trade off into increasing use of natural rubber if passenger and freight transport is not reduced or taken over by rail and waterway transport.

The EU’s ambition to reduce the transport sector’s dependence on oil, in order to prevent the consequences of its scarcity on the competitiveness of the European economy (European Commission 2011), might increase rubber demand. Synthetic rubber is derived from mineral oil and

widely used to manufacture tyres (e.g. $56 \%$ of the rubber used in a passenger car tyre) (USTMA, c2020b). For the time being, the properties of synthetic rubber are essential for some tyre components (Millard 2019), but tyre manufacturers have already started to work on overcoming barriers to substitutability between synthetic and natural rubber (Krok 2017). Full replacement of synthetic rubber with natural rubber in all tyres would more than double the land footprint of mobility in the EU (Table S7), rendering a risk of carbon loss to the atmosphere through deforestation. A policy aiming at synthetic rubber substitution should carefully consider and avoid such trade-offs.

Demand projections are a factor influencing the expansion of rubber plantations. Given that the EU is willing to reduce its dependency on Southeast Asia (ETRMA 2019b), increasing demand might stimulate the expansion of rubber in other producing regions. In Central Africa, for instance, foreign investment in agro-industrial plantations is welcome, threatening vast areas of forested land that are often not adequately protected by governments (Feintrenie 2014). In addition, the ecological footprint of tyre use in the EU could extend beyond the tropics, as the EU is involved in research on the use of natural rubber produced from plants that can be grown at other latitudes (Cornish 2017).

Sustainability standards in natural rubber production are lagging behind those of other commodities (Millard 2019) because initiatives from the tyre industry are difficult to implement due to the large number of small producers (Warren-Thomas et al. 2015). Since 2019, however, a Global Platform for Sustainable Natural Rubber (GPSNR 2020) has been working towards managing sustainability in the supply chain, with particular attention to the long-term effects of production practices. To that respect, agroforestry systems can reduce the negative impacts of natural rubber production on biodiversity (Langenberger et al. 2017), but the land footprint tied to mobility can only be limited if the demand for natural rubber levels-off or decreases.

# CONCLUSION

Our quantification of natural rubber use in tyres has shown that mobility in the European Union in 2017 required around $5 \%$ of global rubber production area in 2016. Preference for road vehicles over other overland options for personal mobility and transport of goods drives the EU’s natural rubber consumption. Car tyres account for $58 \%$ of Europe’s annual use of natural rubber, highlighting the importance of personal mobility. This importance however varies across the EU, with annual per capita values ranging from $0 . 2 6 \mathrm { k g }$ in Romania to $1 . 1 0 \mathrm { k g }$ in

Luxembourg. High values are related to the predominant use of cars for everyday trips and frequent long-distance travel by car. Car travel is the norm in many European countries where car ownership and economic prosperity are high and spatial planning has produced car-dependent lifestyles. Daily car use triggers people to also use their car for long-distance business and leisure travel, which tend to be more frequent in countries with high per capita income. Addressing car dependency is therefore key to reducing future demand for rubber, avoiding pressures on tropical lands which otherwise risk conversion to rubber plantations. Policy action that cuts across the domains of transport, spatial planning, trade, and climate change is required to both address the multiple drivers of car use, and avoid trade-offs between natural rubber use and carbon emissions.

Acknowledgements This research was funded by the Marie Skłodowska-Curie actions (MSCA grant agreement No 765408 from the European Commission: COUPLED ‘Operationalising Telecouplings for Solving Sustainability Challenges for Land Use’, and the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation) project No. KA 4815/1-1. Authors are very grateful to personal contributors for providing valuable data, and to Cecilia Zagaria for proofreading the manuscript. Authors also thank the two anonymous reviewers for their insightful comments that helped to substantially improve the manuscript.

Open Access This article is licensed under a Creative Commons Attribution 4.0 International License, which permits use, sharing, adaptation, distribution and reproduction in any medium or format, as long as you give appropriate credit to the original author(s) and the source, provide a link to the Creative Commons licence, and indicate if changes were made. The images or other third party material in this article are included in the article’s Creative Commons licence, unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence, visit http://creativecommons. org/licenses/by/4.0/.

# AUTHOR BIOGRAPHIES

Perrine C. S. J. Laroche $( \boxtimes )$ is a doctoral student at the Department of Environmental Geography, VU University Amsterdam, the Netherlands. Her research interest lies in understanding and documenting the contribution of current and emerging Western lifestyles to ecological change occurring at a distance.   
Address: Institute for Environmental Studies, Vrije Universiteit Amsterdam, De Boelelaan 1087, 1081 HV Amsterdam, The Netherlands.   
e-mail: perrine.laroche@vu.nl

Catharina J. E. Schulp is an Assistant Professor at the at the Department of Environmental Geography, VU University Amsterdam. She is specialized in developing and applying spatial models to analyze societal demand for ecosystem services in relation to the supply by the landscape, to support science and policy.   
Address: Institute for Environmental Studies, Vrije Universiteit Amsterdam, De Boelelaan 1087, 1081 HV Amsterdam, The Netherlands.   
e-mail: nynke.schulp@vu.nl

Thomas Kastner is a Senior Scientist at the Senckenberg Biodiversity and Climate Research Centre (SBiK-F) and researcher at the Institute of Social Ecology in Vienna. His research focuses on systemic relations between international trade, biomass use, land use change, climate change and biodiversity trends.

Address: Senckenberg Biodiversity and Climate Research Centre (SBiK-F), Senckenberganlage 25, 60325 Frankfurt-am-Main, Germany.

e-mail: thomas.kastner@senckenberg.de

Peter H. Verburg is a Full Professor and Department Head of the Department of Environmental Geography at the Institute for Environmental Studies, VU University Amsterdam, the Netherlands. The focus of his work is in improving the understanding of human-environment systems, through land use analysis and modelling, for sustainability solutions especially connected to the development of decision-support tools.   
Address: Institute for Environmental Studies, Vrije Universiteit Amsterdam, De Boelelaan 1087, 1081 HV Amsterdam, The Netherlands.   
Address: Swiss Federal Research Institute for Forest, Snow and Landscape Research WSL, Birmensdorf, Switzerland.   
e-mail: p.h.verburg@vu.nl
