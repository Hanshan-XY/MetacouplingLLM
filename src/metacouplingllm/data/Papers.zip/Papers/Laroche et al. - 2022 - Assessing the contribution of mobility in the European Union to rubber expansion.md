# Assessing the contribution of mobility in the European Union to rubber expansion

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:51:05.119665+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Laroche et al. - 2022 - Assessing the contribution of mobility in the European Union to rubber expansion.pdf
- Year: unknown
- DOI: 10.1007/s13280-
- OA status: unknown
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: no license info, oa_status=unknown

## Copyright-Safe Summary
This paper investigates how mobility in the European Union (EU) contributes to global expansion of natural rubber plantations through tyre use. It explicitly applies a telecoupling perspective by linking European transport demand to land use change and ecological impacts in distant tropical producer regions.

Geographically, the study focuses on the EU-28 as the consuming system and all rubber-producing countries worldwide as sending systems, with global trade as the connecting flows. The authors compile EU-wide transport statistics by vehicle type, tyre lifespan and composition data, and bilateral trade records of rubber goods and vehicles. These are combined in a multi-step calculation to estimate: (1) annual natural rubber use in tyres by vehicle category; (2) the origin of that rubber using an input-output trade tracing approach; and (3) the associated land footprint using country-level yields.

They estimate that vehicles registered in the EU consume roughly 672,000 metric tons of natural rubber in tyres per year, about 5 percent of world production, requiring around 594,000 hectares of plantations. Passenger cars account for 58 percent of this use; overall, two-thirds of rubber use is for personal mobility, one-third for freight. Car-based lifestyles in richer, highly motorized EU countries drive especially high per capita rubber use. The land footprint is concentrated in Indonesia, Thailand, Malaysia, China, and Cote dIvoire, but in some countries, such as Cambodia and several African producers, up to about a quarter of the harvested rubber area serves EU mobility.

The study compares the rubber efficiency of different modes, finding that buses and trains are far more rubber-sparing than private cars and vans, while bikes are not always more rubber-efficient than cars, depending on tyre types. Correlational analysis shows strong links between national per capita rubber use in car tyres and indicators of car use for commuting, business, and leisure.

Relevance to telecoupling/metacoupling: the paper is clearly about telecoupled land-use impacts. It traces how EU transport policies, urban planning, and car dependency create distant ecological pressures via rubber demand, and discusses cross-sector policies needed to reduce these distant land footprints while pursuing decarbonization goals.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling between EU mobility demand and tropical rubber land use
- Limited intracoupling focus within EU transport and policy systems
- Pericoupling via regional EU trade and modal choices affecting external rubber demand

### Intracoupling
#### Systems
- European Union transport and mobility system
- EU vehicle and tyre consumption system
- EU policy system on transport, climate, land footprint
#### Flows
- Vehicle kilometers and passenger kilometers by mode within EU
- Domestic use of natural and synthetic rubber in tyres
- Policy measures on decarbonisation and mobility growth
#### Agents
- EU households and drivers
- Transport operators and logistics companies
- EU and national transport and climate policymakers
#### Causes
- Car dependent lifestyles linked to prosperity and planning
- Preference for road transport over rail and waterways
- Policy focus on greenhouse gas reduction without limiting mobility
#### Effects
- High EU demand for tyres and natural rubber
- Large variation in per capita rubber use among EU countries
- Potential conflicts between decarbonisation and material footprints

### Pericoupling
#### Systems
- EU neighboring and regional trade partners
- European tyre and automotive manufacturing sector
- Regional freight and logistics networks
#### Flows
- Trade in tyres and vehicles within and around EU
- Regional shifts between vans, trucks, rail, inland waterways
- Diffusion of mobility cultures and car ownership norms
#### Agents
- Tyre and vehicle manufacturers based in Europe
- Regional freight companies using vans and trucks
- Regional policymakers on urban planning and transport
#### Causes
- Growth in e commerce and urban deliveries
- Infrastructure favoring road freight over rail or waterways
- Corporate car provisioning and tax incentives
#### Effects
- Increased regional tyre turnover and rubber demand
- Modal choices affecting overall telecoupled land footprint
- Potential shift of freight modes influencing remote pressures

### Telecoupling
#### Systems
- EU as distant rubber consuming system
- Tropical rubber producing countries in Asia and Africa
- Global rubber trade and supply chain network
#### Flows
- Natural rubber embodied in tyres and vehicles exported to EU
- Land footprint of EU tyre use allocated to producer countries
- Information and investment signals driving rubber expansion
#### Agents
- Smallholder rubber farmers and plantation companies
- International traders, tyre industry, automotive firms
- National governments in producer countries promoting rubber
#### Causes
- EU mobility demand and car centric lifestyles
- Global tyre use dominated by automotive sector
- Policies to replace oil derived synthetic rubber with natural rubber
#### Effects
- Rubber plantation expansion and associated deforestation
- Biodiversity loss, soil degradation, erosion in producer regions
- High shares of national rubber area serving EU mobility

### Cross-Coupling Interactions
- EU transport decarbonisation policies may increase natural rubber demand abroad
- Modal shift and car dependency reduction can lower distant land pressures
- Diversifying rubber sourcing from Asia to Africa redistributes telecoupled impacts

### Research Gaps or Limitations
- High uncertainty in tyre lifespan, rubber composition, and yield data
- Underestimation of bike related rubber use due to missing country data
- Limited traceability of rubber origin and product specific supply chains

### Search Keywords
- EU mobility rubber telecoupling land footprint
- natural rubber tyres tropical deforestation Europe
- car dependency externalized environmental impacts

### Extraction Confidence
high
