# A metacoupling lens on the co-production of nature_s contributions to people Insights for sustainab

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:58:24.803989+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Mayer et al. - 2025 - A metacoupling lens on the co-production of nature_s contributions to people Insights for sustainab.pdf
- Year: unknown
- DOI: 10.1016/bs.aecr.2025.02.001
- OA status: closed
- License: none recorded
- Category: Journal Articles\Conceptual\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This conceptual paper applies the metacoupling framework to understand how natures contributions to people (NCP) are co-produced through interactions between natural and anthropogenic capitals across multiple spatial scales. It focuses on social-ecological systems that are locally embedded yet connected to adjacent and distant regions via flows of materials, information, people, and finance.

The authors build on the NCP and ecosystem services literature but emphasize co-production: NCP arise from ecosystems together with human inputs such as skills, institutions, infrastructure, and money. They argue that these anthropogenic capitals are often produced and mobilized in places different from where NCP are realized, making cross-scale linkages central for sustainability analysis.

Using the metacoupling framework, they distinguish intracoupling (within one system), pericoupling (between neighboring systems), and telecoupling (between distant systems). Three illustrative case examples demonstrate this lens: wood production in German temperate forests; natural pest control in German meadows provided by migratory lapwings; and non-material benefits from giant panda ecotourism in China. Each example shows how local NCP depend on imported machinery, knowledge, labor, tourists, conservation funding, or policy instruments, and how NCP themselves (e.g., wood, hay, tourism experiences) move across borders.

The paper identifies several challenges for applying metacoupling to NCP co-production: integrating diverse disciplines and knowledge systems, defining porous system boundaries, collecting comparable multi-scale data (especially for human and social capital), tracing complex actor networks along supply chains, and addressing justice and power dimensions in cross-scale interactions.

It also outlines opportunities: making hidden environmental and social spillovers visible, clarifying responsibilities and enabling local agency, enriching environmental justice analyses, improving understanding of governance contexts, and connecting local decisions to global social and planetary boundaries.

This article is explicitly about metacoupling and telecoupling: it extends these frameworks to the co-production of NCP and argues they are essential for evaluating sustainability, equity, and governance in a globally interconnected world.

## Structured Metacoupling Extraction

### Coupling Classification
- Conceptual paper on metacoupling in NCP co-production across intra, peri, and tele scales.

### Intracoupling
#### Systems
- German temperate production forests as focal social-ecological system.
- German wet grassland meadows hosting nesting lapwings.
- Chinese panda reserves like Wolong with bamboo forests.
#### Flows
- Local integration of natural capital and human, social, physical, financial capitals to produce NCP.
- On-site flows of wood, hay, and non-material experiences to local users.
- Local knowledge exchange and management decisions within each focal system.
#### Agents
- Forest owners, managers, local contractors, certification bodies staff.
- Farmers managing meadows, local conservationists, reserve rangers.
- Local communities, tour operators, guides, government officials.
#### Causes
- Demand for timber income and rural livelihoods in forest regions.
- Need for pest control and grassland production avoiding synthetic pesticides.
- Interest in ecotourism, conservation, and cultural identity linked to pandas.
#### Effects
- Changes in forest structure, biodiversity, and long-term wood productivity.
- Lapwing population decline or recovery depending on management intensity.
- Economic benefits and cultural meanings, with unequal local benefit sharing.

### Pericoupling
#### Systems
- German forests linked with neighboring European machinery producers.
- German meadows linked with nearby European hay markets.
- Chinese panda reserves linked with nearby Asian tourist-sending countries.
#### Flows
- Regional trade in harvesting machinery, forestry services, and processed wood.
- Exports of low-nutrient hay to nearby countries such as Switzerland.
- Tourist visits and information flows from neighboring Asian countries.
#### Agents
- Regional equipment manufacturers, logging contractors, sawmills.
- Hay traders, horse owners, regional agricultural agencies.
- Regional tour companies, media outlets, conservation NGOs.
#### Causes
- Regional market demand for wood products and services.
- Higher value of low-nutrient hay in nearby specialized markets.
- Proximity-based tourism demand and regional conservation agendas.
#### Effects
- Regional economic integration and potential displacement of local practices.
- Additional farmer income sustaining extensive biodiversity-friendly grasslands.
- Regional distribution of tourism revenues and environmental pressures.

### Telecoupling
#### Systems
- German forests connected to distant Asian and other European consumer regions.
- German meadows connected to distant research institutes and policy centers.
- Chinese panda reserves connected with North America and Europe.
#### Flows
- Exports of logs, sawn wood, and re-imported processed wood products.
- Long-distance flows of knowledge, subsidies, and agri-environment funds.
- International tourist flows, conservation funding, and global media attention.
#### Agents
- International traders, investors, certification organizations, distant consumers.
- Foreign research institutions, EU bodies, national ministries.
- Global NGOs like WWF, foreign tourists, international donors.
#### Causes
- Global demand for timber, furniture, and certified wood.
- Policy goals for biodiversity-friendly farming and climate mitigation.
- Worldwide fascination with pandas and global conservation campaigns.
#### Effects
- Environmental impacts and justice issues along distant wood supply chains.
- Dependence of local practices on external knowledge and subsidies.
- Unequal sharing of ecotourism benefits and cross-scale justice concerns.

### Cross-Coupling Interactions
- Interplay of intra, peri, tele flows of anthropogenic capitals shaping NCP sustainability.
- Spillover effects where local NCP decisions cause distant environmental and social impacts.
- Governance responses may induce, coordinate, or react to telecoupled NCP flows.

### Research Gaps or Limitations
- Limited data on peri and tele flows of anthropogenic capitals at fine spatial scales.
- Difficult quantification of non-material NCP and human or social capital flows.
- Challenges defining system boundaries and tracing multi-actor global supply chains.

### Search Keywords
- metacoupling nature contributions to people co-production
- German forest wood telecoupling panda tourism
- lapwing natural pest control anthropogenic capital

### Extraction Confidence
high
