# Sustainable minerals extraction for electric vehicles A pilot study of consumers_ perceptions of im

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:55:27.494028+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Liu et al. - 2022 - Sustainable minerals extraction for electric vehicles A pilot study of consumers_ perceptions of im.pdf
- Year: unknown
- DOI: 10.1016/j.resourpol.2021.102523
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper examines how electric vehicle (EV) owners perceive the social and environmental impacts of extracting minerals such as lithium and cobalt, which are essential for EV batteries. It focuses on EV consumers in North America and Europe, treating these regions as mineral “sending systems” in a telecoupled global supply chain, with mining regions in the Global South as “receiving systems.”

Using the telecoupling framework, the authors design a Q-methodology study combined with a short survey. They recruit 88 EV owners from an online forum and group them by primary purchase motivation: technology, financial, or environmental. A pre-sorting survey assesses awareness of mining impacts. Participants then receive a standardized factsheet about lithium mining impacts and complete a Q-sort of 37 statements that cover technology, consumer roles, supply chain practices, public opinion, and governance.

Results show that most EV owners initially know little about the ecological and social consequences of battery mineral extraction, though environmentally motivated owners are slightly more aware. After exposure to impact information, many participants recognize that EV supply chains are complex and that consumers, media, firms, and governments all influence outcomes. However, strong contradictions emerge. Some respondents acknowledge serious mining harms yet downplay the need to address them, defend EVs as green despite new information, or fear that stronger mineral governance could slow EV adoption. These patterns suggest cognitive dissonance, especially among pro-environment buyers.

The study is explicitly framed as a telecoupling analysis: it highlights distant links between EV demand in the Global North and mining impacts elsewhere, the role of information flows as feedback, and the need for governance that spans consumers, corporations, and states across regions. It calls for improved mineral governance that reflects different consumer motivations, strengthens information flows, incorporates consumer pressure and media scrutiny, and broadens supply chain initiatives beyond risk management to support global sustainable development.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling between EV-consuming countries and distant mineral-extracting regions; intra- and peri-coupling implied within systems.

### Intracoupling
#### Systems
- EV-consuming countries internal system of consumers, automakers, and domestic regulators
- Local socio-ecological systems within individual mining regions
- Corporate supply chain governance structures inside EV and mining firms
#### Flows
- Information and media narratives about EV benefits and mining impacts
- Corporate sustainability initiatives and reporting within firms
- National policies and incentives for EV adoption and mineral governance
#### Agents
- EV consumers categorized by purchase motivations
- Automaker sustainability and procurement teams
- National and local government agencies in single countries
#### Causes
- Domestic EV decarbonization policies and climate commitments
- Marketing of EVs as clean technology within home markets
- Corporate risk management and reputational concerns
#### Effects
- Limited consumer awareness of hidden extraction impacts
- Cognitive dissonance among pro-environment EV buyers
- Internal debates over prioritizing EV adoption versus stricter SME rules

### Pericoupling
#### Systems
- Neighboring or regional EV markets in North America and Europe
- Regional clusters of mining countries sharing ecosystems
- Transnational advocacy and media networks around mining issues
#### Flows
- Regional diffusion of EV incentives and standards
- Cross-border media coverage of lithium and cobalt mining impacts
- Regional policy dialogues on sustainable mineral governance
#### Agents
- Regional political groupings and forums
- Environmental NGOs operating across nearby countries
- Online EV owner communities spanning several regions
#### Causes
- Regional EV market growth and technology diffusion
- Shared concern over supply security and sustainability risks
- Spread of sustainability norms through regional institutions
#### Effects
- Converging consumer expectations on responsible mineral sourcing
- Regional pressure for transparency and certification schemes
- Emerging regional frameworks for SME coordination

### Telecoupling
#### Systems
- Sending systems: EV-consuming countries like USA and Europe
- Receiving systems: lithium, cobalt, copper mining regions in Global South
- Intermediary systems: global supply chains and trading networks
#### Flows
- Physical flows of EV-critical minerals from mines to battery and vehicle manufacturers
- Information flows on mining externalities reaching distant consumers
- Financial flows through EV purchases, subsidies, and SME initiatives
#### Agents
- EV owners segmented as technology-, financial-, and environment-driven buyers
- Automakers, battery producers, and mining companies
- Governments, international organizations, media, and civil society
#### Causes
- Global low-carbon transition policies and Paris Agreement goals
- Rapid EV adoption increasing demand for lithium, cobalt, nickel
- Governance gaps shifting responsibility toward consumers and downstream actors
#### Effects
- Environmental degradation and social disruption in extraction communities
- Weak or delayed feedback from affected communities to EV consumers
- Consumer pressures, policy debates, and potential governance reforms for SME

### Cross-Coupling Interactions
- Information about distant mining impacts alters perceptions and potential behaviors in EV-consuming systems.
- Consumer awareness and advocacy can reshape corporate supply chains and policies affecting distant mines.
- Telecoupled trade magnifies governance challenges created by cultural, economic, and institutional differences between systems.

### Research Gaps or Limitations
- Sample largely from online EV communities in North America and Europe; lacks perspectives from China and other markets.
- Limited consideration of political and institutional contexts shaping preferences in different countries.
- Voices of mining-country communities and Indigenous groups are not systematically integrated with consumer perspectives.

### Search Keywords
- telecoupling EV minerals governance consumer perceptions
- sustainable mineral extraction lithium cobalt Q-method
- electric vehicle supply chain social environmental impacts

### Extraction Confidence
high
