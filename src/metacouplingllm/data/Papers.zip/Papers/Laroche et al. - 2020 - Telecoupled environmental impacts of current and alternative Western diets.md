# Telecoupled environmental impacts of current and alternative Western diets

![](images/48e12b4e9157ecf4bdef4f2ad58f9662bc11e8f8f9efa6a916502aa62c759d87.jpg)

Perrine C.S.J. Larochea,⁎ , Catharina J.E. Schulpa , Thomas Kastnerb , Peter H. Verburga,c

a Vrije Universiteit Amsterdam, Institute for Environmental Studies, De Boelelaan 1111, 1081 HV Amsterdam, the Netherlands   
b Senckenberg Biodiversity and Climate Research Centre (SBiK-F), Senckenberganlage 25, 60325 Frankfurt-am-Main, Germany   
c Swiss Federal Research Institute for Forest, Snow and Landscape Research WSL, Birmensdorf, Switzerland

# A R T I C L E I N F O

Keywords:

Dietary change

Trade

Land use change

Ecosystem services

Telecoupling

Trade-offs

EAT diet

# A B S T R A C T

Low-meat and no-meat diets are increasingly acknowledged as sustainable alternatives to current Western food consumption patterns. Concerns for the environment, individual health or animal welfare are raising consumers’ willingness to adopt such diets. Dietary shifts in Western countries may modify the way human-environment systems interact over distances, primarily as a result of existing trade flows in food products. Global studies have focused on the amount of water, land, and $\mathrm { C O } _ { 2 }$ emissions embodied in plant-based versus animal-based proteins, but the potential of alternative diets to shift the location of environmental impacts has not yet been investigated. We build on footprint and trade-based analyses to compare the magnitude and spatial allocation of the impacts of six diets of consumers in the United States of America (USA). We used data on declared diets as well as a stylized average diet and a recent dietary guideline integrating health and environmental targets. We demonstrate that low-meat and no-meat diets have a lower demand for land and utilize more crops with natural nitrogen fixation potential, yet also rely more widely on pollinator abundance and diversity, and can increase impacts on freshwater ecosystems in some countries. We recommend that governments carefully consider the local impacts of the alternative diets they promote, and minimize trade-offs between the global and local consequences of dietary shifts through regulation or incentives.

# 1. Introduction

A continuation of current dietary, demographic, and economic trends would drastically increase global greenhouse gas (GHG) emissions, land clearing, and biodiversity threats caused by global food production by 2050 (Tilman and Clark, 2014). A significant share of the environmental pressures of Western diets, including land use, water use, GHG emissions, and nitrogen and phosphorus pollution, is a result of livestock rearing, especially due to the inefficient protein conversion of ruminants (Aleksandrowicz et al., 2016; Oita et al., 2016; Alexander et al., 2017; Bais-Moleman et al., 2019; Li et al., 2019). Moreover, the demand for beef in Western countries is a well-known driver of tropical deforestation (Rautner et al., 2013) and biodiversity loss (Machovina et al., 2015). Adopting alternative diets, richer in plant-based food and with fewer livestock products, shows potential to lower negative environmental impacts and simultaneously contribute to decreasing the risk of chronic non-communicable diseases worldwide (Tilman and Clark, 2014; Nelson et al., 2016).

Concerns about animal welfare, sustainability, and health

(Rosenfeld, 2018) as well as lifestyle preferences can increase the willingness to adopt low-meat diets in Western countries (ING Economics Department, 2017). The EAT-Lancet Commission recently suggested a Universal Healthy Reference Diet (EAT) informed by guidelines on healthy diets and sustainable food systems (Willett et al., 2019). Livestock products (excluding fish) account for $1 2 \%$ of the energy content of this diet, compared with a higher average of $2 9 \%$ in current Western diets (FAO (2019) for $2 0 1 3 ^ { 1 \cdot }$ ). The EAT diet derives a higher share of energy content from cereals, vegetables, legume crops, and nuts (Willett et al., 2019).

While numerous quantifications of the environmental benefits of reduced meat consumption are available, as emphasized in the recent IPCC report on Climate Change and Land (Jia et al., 2019), the impacts of different meat substitutes remain understudied. Research has shown that replacing meat with soy-based proteins or meat produced in vitro may imply higher direct energy inputs (Alexander et al., 2017), and certain nuts, fruits and vegetables may result in a higher risk of water scarcity (Poore and Nemecek, 2018). However, the sourcing of substitutes is never considered in assessments, despite potential impacts on

specific production systems and regional sustainability. For example, sourcing alternatives to beef from biodiversity hotspots like the Mediterranean Basin, Sundaland, or the Guinean forests of West Africa, could displace the threat of biodiversity loss to these regions (Chaudhary et al., 2016).

This potential displacement of threats is facilitated by the expansion of infrastructure, information and communication technologies, and networks that enhance interactions between distant locations (Liu et al., 2013). Investigating global processes resulting from this so-called telecoupling between distant socio-ecological systems may help us understand local drivers and key processes essential to tackling global sustainability challenges (Drakou et al., 2018).

Global trade of agricultural products is a major telecoupling process (Kapsar et al., 2019). Land system scientists have used long-term monitoring of trade flows (Kastner et al., 2011; MacDonald et al., 2015; Yu et al., 2013) to highlight dependencies among different countries (Galli et al., 2017; Nijdam et al., 2019) and quantify the impacts of these flows. Trade allows for the redistribution of a range of ecosystem services (ES) (Koellner et al., 2018), i.e. nature's benefits to people (Diaz et al., 2015), but also reallocates the environmental burdens of food production (Cederberg et al., 2019; Chaudhary and Kastner, 2016; Dalin et al., 2016). On a global scale, trade contributes to an abundance of available goods and services (MacDonald et al., 2015), but simultaneously detaches beneficiaries from the environmental impacts embodied in their lifestyles (Kastner et al., 2011).

This study presents an assessment of the domestic and outsourced impacts of different diets of consumers in the United States of America (USA). We allocate, characterize and compare the spatial distribution of the land footprint of diets that differ in meat content, and quantify impacts on water use, dependence on animal pollination, and nitrogen fixation at the country level. Through this study, we demonstrate how Western diets impact land use and ecosystems in other parts of the world. This provides novel insight into the benefits and trade-offs of dietary changes, beyond statements on aggregated reduction of land demand. Such insights may help maximize benefits of dietary shifts and inform action towards minimizing potential tradeoffs and spillovers. We study the USA as an example of a Western socio-ecological system with high potential for dietary shifts (Roe et al., 2019), and an economically strong agricultural sector (MacDonald, 2013). The availability of recent food intake data, including detailed profiles of vegetarian and vegan diets (Orlich et al., 2014), allowed for the analysis of diets of USA consumers up to the product level.

# 2. Methods

We quantified the demand for agricultural commodities in six USA diets: four declared diets obtained from micro-data collected using a Food Frequency Questionnaire, and two top-down diets obtained from macro-data based on national level supply data and current insights into what constitutes a healthy and sustainable diet (Table 1). We tracked the underlying agricultural products to their locations of cultivation, translated this information into a land footprint at the country level, and calculated a number of impact indicators (Fig. 1).

# 2.1. Quantifying demand for primary items

# 2.1.1. Collecting diets

We used declared consumption data from Orlich et al. (2014) on the average intake per capita, in g/day, for 52 food categories, for five diets. We disregarded the pesco-vegetarian diet as our study is limited to the investigation of land footprints (Table 1). Declared dietary habits were collected between 2002 and 2007 from the AHS2 cohort, which consists of members of the Adventist Church in North America (USA and Canada) known for having healthy lifestyles (e.g. non-smoking, low alcohol consumption) (Butler et al., 2008). In addition, we computed an Average American Diet (AAD), using average food availability data

(2000 - 2010) from Shepon et al. (2016), complemented by data from FAOSTAT (2019) for 2010 and USDA Economic Research Service, 2019 for 2010, matching the list of items derived from Orlich et al. (2014). We finally calculated a diet for the USA based on the recommendations of the EAT-Lancet Commission, by adjusting the intake (in g/day) of the AAD for each food category (e.g. all fruits) to the level recommended by the Commission (Willett et al., 2019). We assumed unchanged weights for each food item (e.g. apricot, cherries) in the total energy content (kcal/day) of each category. As the Commission does not include recommendations for alcohol, coffee, tea and cocoa intake (Willett et al. 2019), we assumed these items to remain at the AAD baseline level in the EAT diet.

# 2.1.2. Calculating the demand for primary items

2.1.2.1. Food. We subdivided each of the 52 food categories reported by Orlich et al. (2014), into raw ingredients. For processed food (e.g. salad dressings, soda), we consulted representative recipes through Open Food Facts2 to identify the ingredients. We did not account for ingredients such as additives, colorants, condiments, and salt, which usually represent less than $1 \%$ of products weight and are not reported in FAOSTAT. We used three conversion factors to quantify the primary agricultural items required to obtain the quantity of final products consumed (Fig. 1). The first factor subtracts the water added in cooked or processed items (e.g. applied to cooked rice to obtain the demand (in g) for dry rice, the standard traded form). Added water data originates from USDA Agricultural Research Service (2018), and can be found in Table S1. The second factor disaggregates the food categories into single traded items. For processed food, weights were distributed among ingredients as indicated in the recipe (in $\%$ ) or, if not indicated, according to their order in the recipe (Table S2). For food categories referring to more than one item, we allocated weights according to the relative contribution of each item to the market segment using FAOSTAT (2019) data for 2010 (done for alcoholic beverages, citrus fruits, other fruits, refined grains, seeds, and whole grains), or, if no other information was available, by assigning equal weights to each of the items. Applying these two conversion factors provided the demand (in g) for traded items in each diet. Finally, a third conversion factor transformed the demand for traded items into demand for primary items (crops). We calculated this third conversion factor by comparing the energy content of $_ { 1 0 0 ~ g }$ of traded item (e.g. shelled cashew nuts) with the energy content of $_ { 1 0 0 ~ g }$ of the corresponding primary item (e.g. cashew nuts with shell). We used the energy contents (in kcal) from FAO (2001) or, if not available, from USDA Agricultural Research Service (2018). We finally aggregated the demand (in g) for each primary item, calculated the energy content (kcal) in each diet, and adjusted all diets to 2500 kcal per day using a diet-specific multiplication factor (Fig. 1). As the AAD and EAT diets are initially quantified in traded products, we applied only the third conversion factor, and subtracted added water for juices.

2.1.2.2. Feed including grass. The demand (in g) for the primary livestock products considered (poultry, beef, pork, milk, and eggs) was translated into demand (in g) for concentrate feed made of corn, sorghum, barley, oat, soybean and wheat, and grass (Fig. 1). We used the feed composition per animal product, and feed conversion ratios from Eshel et al. (2015) as these factors reflect the USA context. The data from Eshel et al. (2015) allocates feed use at the national scale to the production of animal products, based on USDA data on livestock feed requirements, feed use, and livestock production. The partitioning among livestock products is done for poultry, beef, pork, milk, and eggs, after subtracting feed used for horses, sheep and goats.

Table 1 Characteristics of the six USA diets in this study.   

<table><tr><td>Diet</td><td>Period of data reporting</td><td>Data type</td><td>Description</td></tr><tr><td>Average American dieta,b,c</td><td>2000–2010</td><td>Top-down diet</td><td>A compilation of nation-wide food availability data per capita per day from Shepon et al. (2016)a, FAOSTAT (2019) for 2010b and USDA Economic Research Service, 2019 for 2010c consistent with the declared diets. Consumption of meat, eggs, and dairy is at current average level.</td></tr><tr><td>Non vegetariand</td><td>2002–2007</td><td>Declared diet</td><td>Consumption of non-fish meat &gt; 1 portion/month. Consumption of meat including fish &gt; 1 portion/weekd.</td></tr><tr><td>Semi vegetariand</td><td>2002–2007</td><td>Declared diet</td><td>Consumption non-fish meat &gt; 1 portion/month. Consumption of meat including fish between 1 portion/month and 1 portion/weekd.</td></tr><tr><td>EATe</td><td>x</td><td>Top-down diet</td><td>The EAT diet is calculated based on the AAD and follows the intake of food products recommended by the EAT-Lancet Commissione. Consumption of meat, eggs, and dairy is at a sustainable and healthy level.</td></tr><tr><td>Lacto-ovo vegetariand</td><td>2002–2007</td><td>Declared diet</td><td>Consumption of eggs/dairy products &gt; 1 portion/month; consumption of meat including fish &lt; 1 portion/monthe.</td></tr><tr><td>Vegan</td><td>2002–2007</td><td>Declared diet</td><td>Respondents classified as vegan by Orlich et al. (2014) declared occasional consumption of animal products: Consumption of eggs/dairy products &lt; 1 portion/month; consumption of meat including fish &lt; 1 portion/monthd.</td></tr></table>

a Shepon et al., 2016   
b FAOSTAT (2019) for 2010   
c USDA Economic Research Service, 2019   
d Orlich et al., 2014. Portion sizes correspond to standard servings for the adult population in the USA (e.g. plate, slice), and vary among food items. Daily food intakes (in g) were estimated using the product-sum method.   
e Willett et al., 2019

# 2.2. Quantifying and allocating the land footprint

# 2.2.1. Cropland for food and feed

In order to calculate the land footprint, we first determined the countries of origin for the 58 primary items considered. For this, we used a method developed by Kastner et al. (2011), which combines agricultural production and bilateral trade data from FAOSTAT with matrix algebra (Fig. 1). The calculation is based on the assumption that “the products consumed in a given country originate in proportional shares from the country's imports and own domestic production”. These calculations link primary products to a total of 231 producing countries, to finally provide the mix of countries of origin by primary product. For each diet, we then distributed the demand for primary items among the countries of origin using Eq. (1) and subsequently calculated the land footprint using national level crop yield data (Eq. (2)).

$$
\mathbf {d} (\mathbf {x}; \mathbf {i}) = \mathbf {d} (\mathbf {i}) * \frac {\text {c o n t r i b u t i o n} (\mathbf {x} ; \mathbf {i})}{\text {t o t a l a v a i l a b l e} (\mathbf {U S A} ; \mathbf {i})} \tag {1}
$$

$$
\mathbf {L U} (\mathbf {x}; \mathbf {i}) = \mathbf {d} (\mathbf {x}; \mathbf {i}) * \text {y i e l d} (\mathbf {x}; \mathbf {i}) \tag {2}
$$

where d is the demand per diet (in g/cap/year), x is the sourcing country, i is the food or feed primary item, USA is the consuming country, and LU is the land use (in $\mathbf { m } ^ { 2 }$ /cap/year). We used crop and country specific yields for the year 2010 from FAOSTAT (2018)

# 2.2.2. Grassland

To calculate the grassland footprint in each country, we first calculated the grassland conversion rate, i.e. the surface needed to produce one unit of beef and milk (in $\mathbf { m } ^ { 2 } / \mathbf { g } .$ ) following the top-down approach from de Ruiter et al. (2017), as described in Eq. (3) and Eq. (4). This approach assumes that all grasslands reported in FAOSTAT are used to support beef, mutton, and milk production. We present the equations for beef below, and equations for milk in the supplementary materials.

$$
\mathbf {g} (\mathbf {x}; \text {b e e f}) = \mathbf {g} (\mathbf {x}) ^ {*}
$$

$$
\frac {\mathbf {p} (\mathbf {x} ; \text {b e e f}) * \mathbf {f c r} (\text {b e e f})}{\mathbf {p} (\mathbf {x} ; \text {b e e f}) * \mathbf {f c r} (\text {b e e f}) + \mathbf {p} (\mathbf {x} ; \text {m u t t o n}) * \mathbf {f c r} (\text {m u t t o n}) + \mathbf {p} (\mathbf {x} ; \text {m i l k}) * \mathbf {f c r} (\text {m i l k})} \tag {3}
$$

$$
\mathbf {g c r} (\mathbf {x}; \text {b e e f}) = \frac {\mathbf {g} (\mathbf {x} ; \text {b e e f})}{\mathbf {p} (\mathbf {x} ; \text {b e e f})} \tag {4}
$$

where $\pmb { g }$ is the grassland area in 2013 (from FAOSTAT, 2019) in the

sourcing country x dedicated to beef, p is the quantity produced in 2013 (from FAOSTAT, 2019), fcr is the feed conversion ratio from de Ruiter et al. (2017), and gcr is the calculated grassland conversion rate for beef.

We then allocated the demand for beef to sourcing countries using an allocation process similar to food and feed, described in Eq. (5), and calculated the grassland footprint in sourcing countries, following Eq. (6).

$$
\mathbf {d} (\mathbf {x}; \text {b e e f}) = \mathbf {g} (\mathbf {x}; \text {b e e f}) * \frac {\text {c o n t r i b u t i o n} (\mathbf {x} ; \text {b e e f})}{\text {t o t a l a v a i l a b l e} (\mathbf {U S A} ; \text {b e e f})} \tag {5}
$$

$$
\mathbf {L U} (\mathbf {x}; \text {b e e f}) = \mathbf {d} (\mathbf {x}; \text {b e e f}) * \mathbf {g c r} (\mathbf {x}; \text {b e e f}) \tag {6}
$$

While this method accounts for variation of grassland productivity among countries, it does not reflect the huge variety of existing grazing systems, ranging from continuous grazing to silage-based production.

# 2.2.3. Comparison

For presentation purposes we aggregated the six diets into three aggregated diets for some of the results by averaging them: meat-rich (AAD, non-vegetarian), low-meat (semi-vegetarian, EAT), and no-meat (lacto-ovo vegetarian, vegan). We derived the land footprint for food, feed, and grass per country and calculated differences of the land footprint allocation between the aggregated diets, using meat-rich diets as a baseline.

# 2.3. Calculating impact indicators

Crops differ in their capacity to support the ecological functions that underpin ES provision, and in their reliance on ES. Consequently, dietary preferences may influence demand and supply of ES in, sometimes distant, areas of production. We quantified four impact indicators: land under permanent crops; dependence on pollinators (indicating the reliance on the conservation of pollinators and their habitats in the production locations); stress-weighted water footprint (indicating the impact on freshwater ecosystems); and nitrogen fixation (indicating the potential for limiting synthetic nitrogen inputs) (Fig. 1). These indicators were selected because of the availability of globalscale, crop-specific data.

![](images/251e37a7fed5ef886c90d2640122436b502bcdd4fe66dbcdd01264b16bb03434.jpg)  
Fig. 1. Flowchart summarizing the methodological approach.

# 2.3.1. Land under permanent crops

We quantified how the six diets are supported by land under permanent crops (Fig. 1) in order to reflect the influence of diets on landscape architecture, crop turnover and adaptation capacity at the farm level. We identified permanent crops based on the Indicative Crop Classification Version 1.0. (ICC) compiled for the FAO World Programme for the Census of Agriculture 2010 (2005).

# 2.3.2. Dependence on pollinators

We first calculated the current area that requires pollinator friendly management for each diet by summing the area under pollinator dependent crops from Gallai et al. (2009). Second, we calculated the area needed to cultivate pollinator dependent crops in the absence of pollinators. We extracted crop specific dependence levels from Gallai et al. (2009). The dataset indicates pollinator dependence for 31 of the 59 primary crops considered, a mixed response for four crops, no pollinator dependence for 23 crops, and a lack of data for walnuts and

grass. When a mixed response or no data was reported, we considered no dependence. Following the approach from Wolff et al. (2017), the difference between the area under crops dependent on pollinators in the current situation and in the absence of pollinators, is used to indicate the risk of land use change linked to dependence on pollinators.

# 2.3.3. Stress-weighted water footprint

We calculated the impact on freshwater ecosystems associated with each diet using the methodology from Ridoutt and Pfister (2010). The stress-weighted water footprint is the volumetric water footprint weighted by national water stress characterization factors derived from Pfister et al. (2009). We obtained the volumetric water footprint in $\mathbf { m } ^ { 3 }$ $\mathbf { m } ^ { 3 } / \mathbf { g } )$ . The volumetric water footprint is the sum of the water extracted and polluted in freshwater ecosystems. We used the global average values per crop calculated over the period 1996–2005 by Mekonnen and Hoekstra (2013) for 124 crops, covering 59 of the 60 crops involved in our diets (persimmons missing). For grass, we applied a blue water footprint of $1 . 8 \mathrm { m } ^ { 3 } .$ /ton and a grey water footprint of $2 \mathrm { m } ^ { 3 } /$ ton, corresponding to the average values for roughages indicated in Gerbens-Leenes et al. (2013).

# 2.3.4. Nitrogen fixation

Legumes can contribute to soil quality and reduce the need for chemical inputs by fixing atmospheric nitrogen through a symbiotic relationship between their roots and rhizobia soil bacteria (Wagner, 2011). The amount of nitrogen fixed by legumes varies among crops and is influenced by a wide range of factors such as water and nutrient availability (Peoples et al., 2009). As global-scale data on drivers of nitrogen fixation is lacking, we used a binary indicator to derive the area covered by nitrogen fixing crops in each diet. We attributed a value of one to peas, beans, vetches, lentils, soybeans and groundnuts (Wagner, 2011) and a value of zero to all other crops.

# 2.3.5. Trade-offs

Taking meat-rich diets as a baseline, we calculated the ratio between low-meat diets and the baseline, and no-meat diets and the baseline across our selected impact indicators. We used radar charts to visualize domestic and outsourced trade-offs among indicators.

# 3. Results

# 3.1. Demand for primary items

The different food consumption patterns presented by Orlich et al. (2014) translate into differences in the demand for primary items (Table 2). Transition from meat-rich towards no-meat diets translates into increasing demand for dark green (e.g. cabbage, spinach, cauliflower) and red-orange vegetables (e.g. tomato, carrot, pumpkin) and legumes, and decreasing demand for stimulant crops (e.g. coffee, tea, cocoa), pork, and beef. We observe a clear difference between consumption in the declared diets and in the top-down diets. Declared diets induce a lower demand for sweeteners, potatoes and soybeans, but higher demand for fruits and vegetable oils. Finally, the EAT diet is distinguished by a high demand for nuts and other vegetables.

# 3.2. Land footprint quantification

# 3.2.1. Total land footprint

The total annual land footprint varies strongly among the diets (Table 3, Fig. 2). The vegan diet requires the least land area while the AAD requires the most. The total land footprint of the AAD is about $2 0 \%$ larger than that of the non-vegetarian diet, and around twice that of the EAT diet.

# 3.2.2. Cropland

The cropland footprint differs only slightly among diets (maximum

difference: $2 9 \%$ between the non-vegetarian diet and the vegan diet), but its use for feed versus food production varies considerably (Fig. 2). The vegan diet has the largest cropland footprint for food. However, in other diets, smaller cropland footprints for food are more than compensated by cropland footprints for feed. The cropland footprint of the non-vegetarian diet is larger than that of the AAD for food, but smaller for feed.

Permanent crops comprise $2 5 \mathrm { - } 4 2 \%$ of the cropland footprint for food across the different diets. The area under permanent crops is lowest for the AAD and is twice as large under a vegan diet. Moreover, the declared diets require a larger area under permanent crops compared to the top-down diets (Fig. 2), largely explained by a strong difference in the demand for fruits (Table 2).

# 3.2.3. Grassland

The grassland footprint is higher than the cropland footprint for all diets except for the vegan, and makes up $5 3 \%$ of the total land footprint in the lacto-ovo vegetarian and $7 7 \%$ in the AAD (Fig. 2). The AAD has the largest grassland footprint because it contains a high amount of beef and milk which require grass feed (respectively $6 4 \%$ and $2 8 \%$ of feed). The grassland footprint of the vegan diet is not zero $( 4 1 ~ \mathrm { m } ^ { 2 } )$ ) because respondents included in the vegan category of Orlich et al. (2014) declared occasional consumption of animal products (Table 1).

# 3.3. Land footprint allocation

The outsourced land surface varies from $2 9 5 \ \mathrm { m } ^ { 2 }$ in the lacto-ovo vegetarian diet to $6 9 9 \mathrm { m } ^ { 2 }$ in the AAD. However, the vegan diet has the largest share of the land footprint outsourced $( 2 9 \% )$ (Table 3). The AAD requires high amounts of imported ruminant products resulting in a large outsourced grassland footprint. All other diets outsource mainly cropland, of which the majority is for food (Table 3). The main differences in the location of the outsourced footprint of diets (Fig. S1) relate to variation in the quantities of imported cashew nuts, cocoa, palm oil, coffee, olives, oranges, and livestock products consumed.

# 3.3.1. Cropland for food

Among all the diets, the vegan diet has the largest outsourced cropland footprint for food (Table 3). Compared to meat-rich diets, nomeat diets require an additional $1 7 0 \mathrm { m } ^ { 2 }$ of domestic cropland per capita per year for food (Fig. 3a), especially for wheat, legumes (beans, peas, lentils), nuts (almonds, walnuts), seeds (sunflower, safflower), tomatoes, and fruits (grapefruit, grapes, plums, apples). Inversely, meat-rich diets require more domestic cropland for maize and sugar. The cropland footprint for food in Côte d'Ivoire, India, Brazil, Tanzania, and Benin is also larger for no-meat diets than for meat-rich diets (Fig. 3), largely as a result of demand for cashew nuts (Fig. S4). There are clear countrybased differences between low-meat and no-meat diets (Fig. 3c). Only in Mexico, the difference is larger between meat-rich and low-meat diets (Fig. 3b). Besides Mexico, low-meat diets also have a larger cropland footprint than both no-meat and meat-rich diets in China, South Africa, Malaysia, Kenya and Papua New Guinea (Fig. 3c).

# 3.3.2. Cropland for feed and grassland

Meat-rich diets require more domestic land to grow feed crops and grass (Fig. 4, Table 3) than low-meat and no-meat diets, and have significantly larger grassland footprint abroad (Table 3). The grassland footprint represents $7 5 \%$ of the domestic land footprint of meat-rich diets, while the cropland footprint for feed is $1 2 . 5 \%$ . In Canada, meatrich diets require an additional $1 0 ~ \mathrm { m ^ { 2 } }$ of cropland for feed and an additional $1 3 \ \mathrm { m ^ { 2 } }$ of grassland compared to no-meat diets. Additional grassland areas are needed in Australia $( 2 3 6 \ \mathrm { ~ m } ^ { 2 } )$ ), Mexico $( 2 8 \ m ^ { 2 } )$ , Brazil $( 8 ~ \mathrm { ~ m } ^ { 2 } )$ , Uruguay, New-Zealand, and Nicaragua $( 6 \mathrm { ~ m } ^ { 2 }$ each) (Figs. 4, S2, S3).

Table 2 Demand for primary items (in g/cap/day) in six USA diets. We aggregated the demand by categories of items, reflecting the framework of the EAT diet as reported in the Lancet Commission report (Willett et al., 2019). Shaded cells indicate the highest consumption of the six diets, and the three aggregated diets. Demand for primary items at the item level (in g/cap/year) is provided in Table S4.   

<table><tr><td></td><td>AAD</td><td>Non-vegetarian</td><td>Semi-vegetarian</td><td>EAT</td><td>Lacto-ovo vegetarian</td><td>Vegan</td><td>Meat-rich</td><td>Low-meat</td><td>No-meat</td></tr><tr><td>Diet type</td><td>Top-down</td><td>Declared</td><td>Declared</td><td>Top-down</td><td>Declared</td><td>Declared</td><td>Aggregated</td><td>Aggregated</td><td>Aggregated</td></tr><tr><td>Eggs</td><td>19.61</td><td>23.69</td><td>18.94</td><td>12.61</td><td>15.23</td><td>2.48</td><td>21.65</td><td>15.78</td><td>8.85</td></tr><tr><td>Milk</td><td>340.57</td><td>425.81</td><td>343.51</td><td>242.45</td><td>232.29</td><td>6.99</td><td>383.19</td><td>292.98</td><td>119.64</td></tr><tr><td>Pork</td><td>16.21</td><td>8.20</td><td>0.78</td><td>4.58</td><td>0.00</td><td>0.00</td><td>12.21</td><td>2.68</td><td>0.00</td></tr><tr><td>Beef</td><td>52.72</td><td>11.43</td><td>1.10</td><td>6.79</td><td>0.00</td><td>0.00</td><td>32.08</td><td>3.95</td><td>0.00</td></tr><tr><td>Poultry</td><td>59.80</td><td>15.89</td><td>3.62</td><td>28.12</td><td>0.00</td><td>0.00</td><td>37.85</td><td>15.87</td><td>0.00</td></tr><tr><td>All fruits (incl. fruit juices)</td><td>171.80</td><td>570.92</td><td>633.17</td><td>183.89</td><td>658.66</td><td>828.44</td><td>371.36</td><td>408.53</td><td>743.55</td></tr><tr><td>Dark green vegetables</td><td>16.66</td><td>89.58</td><td>91.94</td><td>96.98</td><td>97.36</td><td>133.08</td><td>53.12</td><td>94.46</td><td>115.22</td></tr><tr><td>Red orange vegetables</td><td>178.12</td><td>363.31</td><td>397.56</td><td>325.10</td><td>422.93</td><td>460.09</td><td>270.72</td><td>361.33</td><td>441.51</td></tr><tr><td>Other vegetables (incl. avocados, onions)</td><td>20.85</td><td>40.59</td><td>43.17</td><td>96.98</td><td>45.06</td><td>63.96</td><td>30.72</td><td>70.07</td><td>54.51</td></tr><tr><td>Legumes</td><td>9.04</td><td>37.61</td><td>44.01</td><td>48.49</td><td>49.39</td><td>60.40</td><td>23.33</td><td>46.25</td><td>54.90</td></tr><tr><td>Grains</td><td>343.96</td><td>292.54</td><td>297.03</td><td>307.52</td><td>301.15</td><td>335.26</td><td>318.25</td><td>302.27</td><td>318.21</td></tr><tr><td>Tubers (incl. potatoes)</td><td>88.07</td><td>28.14</td><td>24.73</td><td>48.49</td><td>23.99</td><td>20.85</td><td>58.11</td><td>36.61</td><td>22.42</td></tr><tr><td>Sweeteners</td><td>51.35</td><td>6.90</td><td>5.83</td><td>15.54</td><td>5.55</td><td>2.42</td><td>29.12</td><td>10.68</td><td>3.99</td></tr><tr><td>Coffee, tea, cocoa</td><td>14.00</td><td>14.20</td><td>10.73</td><td>13.20</td><td>5.04</td><td>1.63</td><td>14.10</td><td>11.96</td><td>3.33</td></tr><tr><td>Soybeans</td><td>115.85</td><td>66.64</td><td>75.06</td><td>113.41</td><td>77.47</td><td>45.94</td><td>91.25</td><td>94.23</td><td>61.70</td></tr><tr><td>Nuts (shelled)</td><td>12.74</td><td>40.47</td><td>50.26</td><td>89.41</td><td>61.07</td><td>76.47</td><td>26.60</td><td>69.84</td><td>68.77</td></tr></table>

# 3.4. Impact indicators

# 3.4.1. Supply and demand for ES

3.4.1.1. Dependence to pollinators. In each diet, more than $5 0 \%$ of the land footprint demands pollinator friendly management, with the exception of the AAD $( 3 9 \% )$ . This land is mainly located in the USA, but also abroad. In the absence of pollinators (Fig. 5), the greatest risk of land use change for all diets is in the USA and in Côte d'Ivoire. In the USA, Brazil, India, and Turkey, the risk is higher for no-meat diets than for meat-rich diets. Inversely, in Côte d'Ivoire, Indonesia, Ecuador, Ghana, and Nigeria, meat-rich diets have the highest risk. In the USA, the extra land footprint relates to demand for various crops with different dependence levels. This includes beans, groundnuts, citrus fruits (low dependence), soybeans (medium), and various fruits and almonds (high). Abroad, a few highly pollinator-dependent crops (e.g. cashew nuts, coffee, and avocados) explain the extra land footprint in the absence of pollinators.

3.4.1.2. Stress-weighted water footprint. Overall, low-meat and no-meat diets are associated with a lower stress-weighted water footprint in the USA (Fig. 6), although the water footprint in the USA remains the highest. Abroad, low-meat diets have the highest stress-weighted water footprint in Mexico and China, and no-meat diets have the highest impact in Vietnam, India, Chile, Turkey, Thailand, Spain, and Italy (Fig. 6). In Peru and Brazil, meat-rich diets have the highest impact on freshwater ecosystems, but the impact is relatively low and so is the difference with low-meat and no-meat diets.

3.4.1.3. Nitrogen fixation. The EAT diet shows the highest reliance on crops with natural nitrogen fixation. Soybean is the major legume in all diets containing animal products, because it is used to feed livestock. Demand for soybeans decreases with lower amounts of animal products in the diet, while demand for other legume crops (beans, nuts, peas, and lentils) increases (Fig. 7). Non-soybean legume crops are the main potential sources of natural nitrogen fixation in the vegan diet. Lower consumption of animal products decreases support to crops with potential for natural nitrogen fixation (in $\mathbf { m } ^ { 2 }$ /cap/year) in the USA, Mexico, Canada, and Brazil. Inversely, support increases in China, Ghana, and South Africa due to the substitution with a more diverse mix of legume crops (Fig. 7).

# 3.4.2. Trade-offs

Domestically, low-meat and no-meat diets require smaller land areas for feed and grass. However, they need larger areas for plantbased food, especially for permanent crops and crops with potential for natural nitrogen fixation (other than soybean). This extra area for other legumes negates the lower area demand for soybeans in low-meat and no-meat diets. Additionally, the impact on freshwater ecosystems is lower in low-meat and no-meat diets, while the risk of land use change upon absence of pollinators (extra area) is similar in low-meat diets, but higher in no-meat diets (Fig. 8).

Abroad, trends are similar for grassland, cropland for feed, food, permanent crops, and nitrogen fixation, but different for the water footprint, the area dependent on pollinators, and the risk of land use change upon absence of pollinators (Fig. 8). The differences between the grassland footprint of different diets are even larger; low-meat diets

Table 3 Total land footprint $\mathbf { \hat { m } } ^ { 2 }$ per capita per year) per diet, area $( \mathbf { m } ^ { 2 }$ per capita per year) and share $( \% )$ of the land footprint (total, food, feed, and grass) outsourced, i.e. located outside the USA. Shaded cells indicate the highest values among the six diets, and the three aggregated diets.   

<table><tr><td></td><td colspan="2">Land footprint (m2/cap/year)</td><td colspan="4">Outsourced land footprint (m2/cap/year)</td><td colspan="4">Outsourced share of land footprint (%)</td></tr><tr><td>Diet</td><td>Total</td><td>Total</td><td>Cropland food</td><td>Cropland feed</td><td>Grassland</td><td>Total</td><td>Cropland food</td><td>Cropland feed</td><td>Grassland</td><td></td></tr><tr><td>AAD</td><td></td><td>5161</td><td>699</td><td>163</td><td>26</td><td>510</td><td>14%</td><td>27%</td><td>5%</td><td>13%</td></tr><tr><td>Non-vegetarian</td><td></td><td>4223</td><td>423</td><td>262</td><td>24</td><td>137</td><td>10%</td><td>32%</td><td>5%</td><td>5%</td></tr><tr><td>Semi-vegetarian</td><td></td><td>3276</td><td>321</td><td>268</td><td>18</td><td>36</td><td>10%</td><td>31%</td><td>5%</td><td>2%</td></tr><tr><td>EAT</td><td></td><td>2754</td><td>302</td><td>207</td><td>15</td><td>81</td><td>11%</td><td>27%</td><td>5%</td><td>5%</td></tr><tr><td>Lacto-ovo vegetarian</td><td></td><td>2502</td><td>295</td><td>266</td><td>12</td><td>17</td><td>12%</td><td>30%</td><td>5%</td><td>1%</td></tr><tr><td>Vegan</td><td></td><td>1057</td><td>305</td><td>304</td><td>1</td><td>1</td><td>29%</td><td>30%</td><td>5%</td><td>1%</td></tr><tr><td>Meat-rich</td><td></td><td>4692</td><td>561</td><td>213</td><td>25</td><td>324</td><td>12%</td><td>30%</td><td>5%</td><td>9%</td></tr><tr><td>Low-meat</td><td></td><td>3015</td><td>312</td><td>237</td><td>16</td><td>58</td><td>10%</td><td>29%</td><td>5%</td><td>3%</td></tr><tr><td>No-meat</td><td></td><td>1780</td><td>300</td><td>285</td><td>6</td><td>9</td><td>17%</td><td>30%</td><td>5%</td><td>1%</td></tr></table>

![](images/548aa9a0432942ab4e8d69d399ecb57391ac496a533f9c6570e19e3559042865.jpg)

![](images/2e3ae7159f36d4d341e9ec06765fed6bfaf5a39fe76137301934821a8df4199f.jpg)  
Fig. 2. Total land footprint (in $\mathbf { m } ^ { 2 }$ per capita per year) in six USA diets. We distinguish the cropland footprint (left) and the grassland footprint (right). The cropland footprint is subdivided into land used for food or feed, and under permanent crops.

rely on more area for crops providing natural nitrogen fixation; and nomeat diets rely on bigger areas under permanent crops. The impact on freshwater ecosystems of low-meat and no-meat diets is higher than that of meat-rich diets. Moreover, no-meat diets demand larger areas with pollinator friendly management than meat-rich diets. In contrast, the extra land footprint in the absence of pollinators is highest for meatrich diets, due to the outsourcing of crops that are highly reliant on pollinators.

# 4. Discussion

# 4.1. Interpretation of the results

Previous studies about food-related environmental footprints have

commonly highlighted how low-meat and no-meat diets reduce the overall impact on land and climate at the global level. Our analysis goes beyond studies inventoried by Aleksandrowicz et al. (2016) by analyzing the environmental trade-offs of current and alternative diets at the country level. For the USA, we show that, under current production and trade flows, low-meat and no-meat diets exert lower domestic environmental pressures. Abroad, no-meat diets show higher impacts on freshwater ecosystems and an increased dependence on pollinators. However, in case of pollinator loss, meat-rich diets would require the largest additional land area in most countries. Low-meat and no-meat diets also require additional area under permanent crops, which implies lower adaptive potential in farming systems (Lambin et al., 2013) both in the USA and abroad (Fig. 8). Finally, increased consumption of nonsoybean legume crops in alternative diets increases the potential for

![](images/2335f5a9967aa8bab44f32bdb3f8f1834b910ee4f13773368e6f5d5ae1c380ca.jpg)  
Fig. 3. Differences between the spatial allocation of the cropland footprint for food of three aggregated USA diets. (a) no-meat diets compared to meat-rich diets, (b) low-meat diets compared to meat-rich diets, (c) no-meat diets compared to low-meat diets. Only changes $\mathrm { > } 3 \mathrm { m } ^ { 2 }$ per capita per year are shown.

![](images/0cdb18feeffa4a8a317c274e00ad16738d482442ae45a26a3c15f650a4fd6e9f.jpg)

![](images/55dd40cbd4eee89223bd24b18173c616cd163f3ad96edfbe953d8b8a31b294bf.jpg)  
Fig. 4. Differences between the spatial allocation of the land footprints of no-meat diets compared to meat-rich diets in the USA, for (a) cropland for feed and (b) grassland (for feed). Only changes $> 3 ~ \mathrm { m } ^ { 2 }$ per capita per year are shown.

natural nitrogen fixation both in the USA and abroad.

Global concerns on the status and trends of pollinator abundance and species richness (Potts et al., 2016b) and the economic benefits derived from pollination (Lautenbach et al., 2012), suggest that conservation of pollinator habitat in agricultural landscapes is essential. We showed that no-meat diets rely less strongly on pollinator habitat in the USA, but more strongly on the conservation of pollinator habitat abroad. Therefore, no-meat diets contribute more to the export revenues of the countries producing pollinated crops (Lautenbach et al., 2012), but they are also more vulnerable to the fluctuations of commodity prices on international markets (Bauer and Sue Wing, 2016). The amount of extra land required provides an insight into the risk associated with the loss of pollinator habitat and the subsequent reduction of pollinator abundance and species richness. The biodiversity hotspot of Western Africa is particularly vulnerable, yet our results show that risks are reduced by dietary changes towards no-meat diets. Higher risks in Brazil and India (Fig. 5) call for increased global vigilance regarding pollinator abundance and diversity trends, which currently lack reliable data (Potts et al., 2016a).

Trade relationships contribute to water depletion if the commodities exchanged are reliant on overexploited aquifers (Dalin et al., 2017) or regions experiencing seasonal and dry-year scarcity (Brauman et al., 2016). Coffee consumption grounds the outsourced impact of USA meat-rich diets on freshwater ecosystems. In contrast, the high amounts of cashew nuts in no-meat diets, and of beans, lentils, and pulses in lowmeat diets result in a higher impact on freshwater ecosystems abroad (Fig. 6). These impacts are especially a result of these items currently being sourced from countries in which groundwater depletion is already experienced regionally (e.g. Northern China, North-western India) (Brauman et al., 2016; Dalin et al., 2017). Additionally, despite relatively low nitrogen inputs per unit area, leguminous crops have a relatively high grey water footprint per unit produced. In a situation of water stress, higher fertilizer leaching may result in increasing risk of eutrophication in water streams, and reduces safe water availability for human use (Camargo and Alonso, 2006; Mateo-Sagasta et al., 2017).

Finally, our results suggest that replacing animal products with a diverse mix of legumes in USA diets could support a shift towards agricultural systems that actually use lower amounts of synthetic fertilizers. This applies especially in the USA, as the majority of legumes is sourced domestically, but is also likely in Canada and China, i.e. countries supplying legumes to the USA (Fig. 7). Low-meat and no-meat

diets require less land to produce soybean in the USA, but instead more land to produce other legumes. Therefore, large-scale herbicide use in current USA soybean production systems (Perry et al., 2016), which has uncertain and contested implications for the environment and human health, may be reduced.

These findings must be brought into context within the USA's position in the global food system as a main exporter of staple crops, with an agricultural potential much bigger than the needs of its population (MacDonald et al., 2015). In the current diet (AAD), $8 6 \%$ of the land footprint is domestic, while the source countries of non-domestic commodities in the AAD are aligned with and consolidated by trade agreements (e.g. NAFTA,3 AUSFTA4 ). The major trade partners of the USA (Mexico, Canada, and Australia) are the main exporters of the key components of meat-rich diets.

# 4.2. Evaluation of the methods

In contrast to previous studies, we used declared food intake data at the item level to reflect dietary preferences. Besides comparing alternatives to the baseline diet (AAD), we also considered a suggested universal healthy diet (EAT). This detailed set of diets offers advantages, but several assumptions and underlying uncertainties may influence the robustness of our results. The lifestyle of respondents from the cohort used in our analysis is not fully representative of the USA as a whole, as the Adventist Church encourages healthy lifestyles, involving abstaining from tobacco, alcohol and coffee (Butler et al., 2008). Nonetheless, the declared diets are coherent with trends in other Western countries: data collected between 1986 and 2015 in the United Kingdom and the Netherlands show that low-meat diets are often associated with low alcohol consumption and increased consumption of fruits, vegetables, soy-based products, nuts, pulses, and whole grains (e.g. Davey et al., 2003; Gilsing et al., 2013; Clarys et al. 2014; Van Dooren et al. 2014,). To better frame our comparison of impacts, we analyzed a representative baseline USA diet (AAD) based on food availability data (e.g. Peters et al., 2016).

Biases in the quantification of demand for primary items relate to the initial structure of the Food Frequency Questionnaire (Orlich et al., 2014) that captures food preferences for major groups of items, but

![](images/2f5f807cc09be31aad83aa03d360c99d1facff76d00273f84ee84a4df7accbc6.jpg)

![](images/eb7e5049ac638c6a93f1cdd6fbe75fa7cb135bd9a6d93f01b645efea52e0c894.jpg)

![](images/2240ea0e20cd1600f5da8665f752754cb8e698f61025a887c1a52744b496df4c.jpg)  
Fig. 5. Spatial allocation of the extra land footprint for three aggregated USA diets, in case lower yields are achieved due to pollinator absence, relative to a situation of optimal pollination. Only values $\mathrm { ~ > ~ } 1 0 ~ \mathrm { m } ^ { 2 }$ per capita per year are shown.

excludes many less central items. Furthermore, the three conversion factors we used introduce uncertainties. For instance, we assumed most juices to be made from concentrates, and estimated the demand for fruits by first subtracting added water. In reality, concentrates may contain only small amounts of water. We may therefore be underestimating the demand for fruits used in juices by up to $2 5 \%$ . However, the incidence on the impact indicators as a result of this would likely be very small, as juices only explain a small share of the land footprint. In addition, the demand for primary items that we present in Table 2 for the EAT diet may surpass the quantities advised for the EAT diet of 2500 kcal per capita per day from Willett et al. (2019), because for some items we assumed the consumption and primary forms to be different (e.g. nuts are consumed unshelled, tomatoes are partly

consumed in soup or sauce).

We calculated that the AAD requires $1 1 9 4 ~ \mathrm { m } ^ { 2 } .$ /capita/year of cropland, of which $4 8 \%$ is for feed, and $3 9 7 9 \ \mathrm { m } ^ { 2 } .$ /capita/year of grassland. For a similar context (North America around 2007) and energy intake (2500 kcal/day), previous studies calculated that a baseline diet requires $1 6 0 2 ~ \mathrm { m } ^ { 2 } ,$ /capita/year (Kastner et al., 2012) or $1 8 2 7 ~ \mathrm { m } ^ { 2 } .$ /capita/ year (Peters et al., 2016) of cropland, and $1 1 6 7 \ \mathrm { m } ^ { 2 } ,$ /capita/year grassland (Peters et al., 2016). Differences in these results can be explained by methodological choices and input data. Quantifying the land use for grasslands in animal-based products remains challenging, resulting in strong inconsistencies in available area estimates. The productivity of grasslands varies with ecological and climatic conditions (Smit et al., 2008) and the share of roughage in the feed differs among agricultural

![](images/4ab1b749f62c346e304a5c8f9d5bd3292e8af77198f2a6707144e127c38d2ded.jpg)  
Fig. 6. Spatial allocation of the stress-weighted water footprint (in $\mathrm { m } ^ { 3 }$ /cap/year) for three aggregated USA diets. Only values $> 3 \mathrm { m } ^ { 3 }$ per capita per year are shown.

systems worldwide (Mekonnen and Hoekstra, 2013). Moreover, assuming that all reported grassland areas are used for cattle (de Ruiter et al., 2017), very likely results in an overestimation of the grassland footprint of diets, especially for diets rich in ruminant-based products. In specific areas, grasslands may refer to marginal or natural grasslands with little or no use. In comparison, Peters et al. (2016) assumed that part of the grass originates from grass grown in rotation with cropland, decreasing the grassland footprint, but raising the share of cropland used for feed to $6 0 \%$ . We calculated that a vegan diet had a $7 8 \%$ smaller land footprint than the baseline diet (AAD), which is in the same order of magnitude as the $8 5 \%$ reduction estimated by Peters et al. (2016).

We spatially allocated the footprint by using the latest material flows records available (2013) to come close to the current situation, but inconsistencies may arise from mismatches with the collection periods of dietary data (Table 1). Assumptions used to retrace bilateral

material flows (Kastner et al., 2011) may introduce bias in the allocation of the land footprint that are currently difficult to assess. Changes in trade patterns as a result of changes in import and export tariffs and boycotts will further affect the dynamics of allocation to countries.

We followed the methodology from Ridoutt and Pfister (2010) and estimated the stress-weighted water footprint from the sum of blue and grey water footprints. This method allows consideration of the impact of nitrogen application on freshwater ecosystems, but does not necessarily quantify the scarcity of water for human use, as polluted water may remain available for use. For grass, only values reported for an aggregated roughage category were available (Gerbens-Leenes et al., 2013), which are likely higher than values for grass alone. On the other hand, we did not account for blue water for cattle maintenance and care, nor for grey water from cattle waste (Mateo-Sagasta et al., 2017). Therefore, the impact of animal products on freshwater ecosystems

![](images/7cd0a98815fc90b62e9254b1e6bddfbf4790b0f2dec17517e0b6af1b2fa9f401.jpg)  
Land use (m2/cap/year)   
□1-5   
5-50   
50-150   
150-300   
300 -max 365

![](images/717b20a3bc32d218d50c6e0fb6f39e6005369a52aaed660a54382618abb668ae.jpg)  
Fig. 7. Potential for natural nitrogen fixation (in $\mathbf { m } ^ { 2 } ,$ /cap/year) related to legume crops, for six USA diets, and spatial distribution of the potential for the (a) AAD, (b) EAT, and (c) vegan diets. .

might be underestimated. In addition, nitrogen application rates in the 2010's may not be well reflected by the data used, collected in the late 1990′s (FAO, 2002).

We recalculated the yields in absence of pollinators based on an estimation of the economic dependence to pollinators (Gallai et al., 2009). However, the variation of the crop production value per unit of surface can also link to change in the price of the harvested output

(Fig. 5). However, absence of pollinator is not the most likely situation. Only a decrease in pollinator numbers would lead to less extra land being required than the theoretical maximum we present. A decrease of pollinator abundance and associated yield loss could also result in shifting production and consumption patterns. Leguminous crops are promoted as part of intercropping systems (Stagnari et al., 2017) due to their interaction with soil bacteria making nutrients available for

![](images/a58c66a3c3189a5af2c01e59a5c165bfe657e560a16a39c4cf95433253f5df05.jpg)  
DOMESTIC TRADE-OFFS

![](images/8da6ef83c71c0778d1885d75a5eee64ced889e0bee3146c34fce3c329d15c58b.jpg)  
OUTSOURCED TRADE-OFFS   
Fig. 8. Trade-offs of different USA diets, based on land footprint and impact indicators. Low-meat and no-meat diets are compared to meat-rich diets (baseline) for which all values are set to 1. Outsourced demand for grassland of no-meat diets is equivalent to ${ } ^ { 3 \% }$ of the demand of meat-rich diets, i.e. less than the minimum axis value of $1 2 . 5 \%$ (0.125), that was used for the sake of readability.

subsequent crops. We quantify N-fixation benefits of diets assuming legumes to be grown on monocrop systems (Fig. 8). Meeting demand for legumes with intercropping systems would result in a larger area converted to legumes and increase the potential for N-fixation benefits.

# 4.3. Implications

Our study confirms that reducing consumption of animal products leads to cumulative and substantial reductions of the overall environmental impact of diets, especially because the demand for feed and grass decreases (Bais-Moleman et al., 2019; Eshel et al., 2014). Our results indicate that with shifting food preferences, sourcing patterns change, affecting the ES demand and supply balance in the production locations. Goggins and Rau (2016) state that sustainable diets should build on sustainable sourcing. Indeed, although low-meat or no-meat diets have strong global benefits in terms of land use and GHG emissions (Aleksandrowicz et al., 2016) related to agricultural production, our results indicate that the regional consequences of promoted alternative diets also have to be considered. Overall, a large-scale change in diets in the USA should be supported by production standards and trade agreements that minimize these spatial tradeoffs.

The differences in spatial allocation of impacts resulting from different diets are calculated based on current sourcing patterns, which are related to the total consumption and occurrence of alternative diets among USA consumers. The absolute amounts and allocations we present are illustrative only, as they may prove to be unrealistic following large-scale changes in diets. As an illustration, if we upscale the additional land footprint per capita per year that we calculated for Côte d'Ivoire following a shift from meat-rich to no-meat diets $( + 1 0 \mathrm { ~ m } ^ { 2 } )$ across $1 0 \%$ of the USA's population,5 the total agricultural land in Côte d'Ivoire6 would not be enough to meet this demand. Under wider dietary shifts, global agriculture and trade relationships would reconfigure themselves. Also under such a reconfiguration, impacts on land use worldwide should be taken into consideration.

The higher dependence on pollinators of low-meat and no-meat diets suggests that wider uptake of low-meat or no-meat diets in Western countries require diversified farming systems and enhanced ecological infrastructure in agricultural landscapes, including a higher density of pollinator nesting habitats (Dormann et al., 2007; Potts et al., 2016a). Clean production systems for the perennial crops replacing part of the meat consumption is important to decrease water pollution risk. Altogether, low-meat or no-meat diets require less land but have a stronger reliance on a number of ES. The smaller land requirements in low-meat and no-meat diets allow for a land sharing approach, where the land released might be prioritized for less intensive and more varied land systems associated with lower yields. Such systems simultaneously build on and support a wider range of ES, due to lower application of chemical inputs (Seufert and Ramankutty, 2017).

Given the agricultural potential of the USA, we expect that a shift towards wider adoption of low-meat or no-meat diets in the country would primarily impact domestic land use. Part of the grasslands and cropland for cereals and sugar production could be converted into orchards for fruit and nut production, as well as cropland for legumes. However, we expect that part of the diet will remain outsourced. For instance, palm oil and cashew nuts are key crops for respective lowmeat and no-meat diets that only grow in the tropics. Additionally, some key items are grown in the USA, but only in very specific regions with favorable climatic conditions (e.g. almonds, avocados, and oranges in California), therefore facing spatial limitations to expansion.

The distant impacts of different diets demonstrate the importance of

strong environmental commitments (e.g. ensuring the protection of pollinators) in (American) trade agreements. Trade agreements as well as production standards can be a tool to govern sustainable and fair distribution of impacts in the global food system (Eakin et al., 2017). Overall, any trade relationship must account for the risk of environmental degradation associated with the production systems abroad. Such requirements are all the more relevant for Western countries whose food is strongly supplied through imports (Cederberg et al., 2019). Moreover, consumer-oriented policies must balance the potential global benefits (e.g. GHG emission reduction) of certain products with their potential local impact (e.g. increase eutrophication potential), and promote substitutes whose environmental impact can be managed. Communicating trade-offs to consumers is likely to enhance consumer agency (Leach et al., 2016; Vivero-Pol, 2017)

A major limitation in designing such policies is the lack of data on dietary change and dietary composition, limiting insights in changing demands for specific products (Hadjikakou et al., 2019) (EVU7 ). We therefore suggest better and more detailed monitoring of dietary change that considers food preferences in order to enable the quantification of regional environmental impacts. Such monitoring efforts may also be used to forecast the impacts of shifting towards diets richer in animal proteins in developing economies. It would also be more accurate to use sub-national indicators of resource availability and vulnerability, yet so far commodity flows are rarely traced beneath the national scale (Croft et al., 2018).

# 5. Conclusion

The spatial disaggregation of the land footprint of six USA diets demonstrated that sourcing patterns differ with food preferences. Domestically, the land footprint for feed and grass is lower in low-meat and no-meat diets compared to the average American diet. This is partially negated by additional land demand for plant-based food. The same patterns are observed abroad if analyzed at the aggregate level, but patterns in individual sourcing countries differ, with land footprint increasing in some countries abroad. Dietary shifts contribute to more sustainable agriculture in the USA and abroad, when combined with cleaner and more diversified production systems built on enhanced ecological infrastructure in agricultural landscapes. Given that large areas could be freed up by lower consumption of animal-based products, less intensive farming systems are a promising and realistic path. However, extra sourcing in some countries abroad can result in higher local impacts on freshwater ecosystems, and increased vulnerability to pollinator loss. Therefore, we suggest that trade relationships must account for the risk of environmental degradation associated with production systems in the sourcing regions. More rigorous assessments of both global and local impacts of substitutes, and investigations on how to align insights from such assessments with consumer preferences in the Western world, will ensure that the global benefits of dietary changes are not realised at the expense of local environmental contexts.

# Supplementary materials

Supplementary material associated with this article can be found, in the online version, at doi:10.1016/j.gloenvcha.2020.102066.

