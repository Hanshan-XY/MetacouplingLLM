![](images/7a2ae0c3616122b9f91dc2e4b1097d24d427f0919872a53da8535be62a1d4417.jpg)

Check for updates

# OPEN ACCESS

Ademola Braimoh,

World Bank Group, United States

REVIEWED BY

M. S. Suneetha,

Institute for the Advanced Study of

Sustainability (UNU-IAS), Japan

Gabriela Litre,

University of Brasilia, Brazil

*CORRESPONDENCE

Julie G. Zaehringer

julie.zaehringer@unibe.ch

SPECIALTY SECTION

This article was submitted to

Land, Livelihoods and Food Security, a section of the journal

Frontiers in Sustainable Food Systems

RECEIVED 19 September 2022

ACCEPTED 22 December 2022

PUBLISHED 12 January 2023

CITATION

Latthachack P, Llopis JC, Heinimann A,

Thongmanivong S, Vongvisouk T

Messerli P and Zaehringer JG (2023)

Agricultural commercialization in

borderlands: Capturing the

transformation of a tropical forest

frontier through participatory

mapping.

Front. Sustain. Food Syst. 6:1048470.

doi: 10.3389/fsufs.2022.1048470

© 2023 Latthachack, Llopis,

Heinimann, Thongmanivong,

Vongvisouk, Messerli and Zaehringer.

This is an open-access article

distributed under the terms of the

Creative Commons Attribution License

(CC BY). The use, distribution or

reproduction in other forums is

permitted, provided the original

author(s) and the copyright owner(s)

are credited and that the original

publication in this journal is cited, in

accordance with accepted academic

practice. No use, distribution or

reproduction is permitted which does

not comply with these terms.

# Agricultural commercialization in borderlands: Capturing the transformation of a tropical forest frontier through participatory mapping

Phokham Latthachack1,2, Jorge C. Llopis1,3,

Andreas Heinimann4,5, Sithong Thongmanivong6,

Thoumthone Vongvisouk6, Peter Messerli1,4,5 and

Julie G. Zaehringer1,4,5*

1Centre for Development and Environment (CDE), University of Bern, Bern, Switzerland, 2Faculty of

Environmental Sciences, National University of Laos, Vientiane, Laos, 3School of Natural Sciences,

Bangor University, Bangor, United Kingdom, 4Institute of Geography, University of Bern, Bern,

Switzerland, 5Wyss Academy for Nature, University of Bern, Bern, Switzerland, 6Faculty of Forest

Science, National University of Laos, Vientiane, Laos

Forest-frontier landscapes in the humid tropics display distinct land use change dynamics compared to other world regions, providing useful examples of current global environmental and development challenges. In northwestern Laos, part of the former Golden Triangle region, investments in value chains for commercial crops—mainly to fulfill Chinese market demands—have triggered various land use changes and put increasing pressure on remaining biodiverse forest areas. Capturing the existing land use change trajectories is a key initial step toward further studies assessing land use change impacts. However, methodological challenges arise when conducting spatially-explicit change assessments in these regions, given the high temporal variability of land use at the plot level, compounded by the paucity of good quality satellite imagery. Thus, we applied a novel approach combining analysis of very high-resolution (VHR) satellite imagery with participatory mapping. This enabled joint collection of annual land use information for the last 17 years together with local land users, shedding light on temporally dense land system dynamics. For decades, the government of Laos has sought to halt shifting cultivation, labeling it environmentally degrading, and to reduce poverty through promotion of permanent commodity-oriented commercial agriculture. Among other things, this gave rise to a boom in banana and rubber investments in Luang Namtha province in order to satisfy growing Chinese demand for these commodities. The present paper investigates the impact of these cash crop booms on land use transitions and whether they reduced pressure on forest-frontier areas, as ostensibly desired by government authorities. Our study is among the first to demonstrate in a spatially-explicit manner that subsistence agriculture—in less than two decades—has virtually disappeared in northern Laos due to diverse cash-crop production and agricultural commercialization initiatives linked to Chinese investments. As subsistence-focused cultivation systems are being replaced by

land uses solely aimed at commercial production for export, a telecoupled land system is being developed in northwestern Laos with potentially manifold impacts for sustainable development.

#

land use change, cash crops, forest frontier, participatory mapping, remote sensing, shifting cultivation, telecoupling, Laos

# 1. Introduction

Remaining tropical forests are under increasing pressure from expanding commercial agricultural plantations (Gibbs et al., 2010; Curtis et al., 2018). Economic growth in many tropical countries, especially in newly opened economies, is driven significantly by resource exploitation in forest-frontier areas (Barbier, 2005). Market linkages are seen as a major factor stimulating these land use changes (Mccarthy and Cramb, 2009; Fox et al., 2011). The resulting loss of natural forest resources— and related impacts on carbon sequestration, biodiversity, and various other ecosystem services—threaten achievement of sustainable development (Díaz et al., 2019).

Until recently, land use change research in Southeast Asia identified expansion of upland agricultural systems—such as shifting cultivation or swidden—as the leading cause of forest degradation and deforestation (Fox and Vogler, 2005; Kummer and Turner, 2007; Jepsen et al., 2019). Today, however, Southeast Asia’s forest frontier is a key target region of increasing global demand for commercial crops, which have seen major expansion in plantation areas. Examples include oil palm in Malaysia and Indonesia (Mccarthy and Cramb, 2009), coffee in the highlands of central Vietnam (Tan, 2000; Agergaard et al., 2009), and, more recently, rubber in the Lower Mekong Basin, comprising parts of Laos, Thailand, Cambodia, and Vietnam (Fox et al., 2009; Mann, 2009; Sturgeon, 2010).

Laos is a prime example of rapid land use change owing both to the expansion of large-scale agricultural investments (Schönweger et al., 2012; Nanhthavong et al., 2020) and to smallholder farmers leasing out land or signing contractfarming agreements with investors to satisfy demand from neighboring countries (Dubus, 2016; Friis and Nielsen, 2016; Lu and Schönweger, 2017). Landlocked Laos is squeezed between the powerful economic forces of China, Vietnam, and Thailand (Figure 1) (Dubus, 2016). In 2005, following the example of its neighbors, the Lao government established the policy of “Turning Land into Capital” (Dwyer, 2007; Baird, 2011; Kenney-Lazar, 2012). With the Lao government’s liberalization of trade, and the country’s integration into the wider regional economy, the number of companies and private investors seeking access to land for export-oriented

cash crop agriculture increased substantially (Thongmanivong et al., 2009). As a result, the Lao economy has become heavily dependent on investment from and trade with its neighbors. The Lao government provided many foreign investors with large-scale land concessions for plantations (Rutherford et al., 2008) in hopes that these would reduce local poverty (Dwyer, 2007). Further, it permitted investors to enter directly into leasing or contract-farming agreements with smallholders (Friis and Nielsen, 2016). However, evidence shows that because of high transportation costs, land-based investment in remote areas has been less attractive to investors than hoped, and poor rural families have been forced to migrate abroad for work due to the lack of income opportunities at home (Nanhthavong et al., 2020). Meanwhile, political and economic factors, as well as comparatively more stable societies and economies, have led certain actors to invest in neighboring countries instead of Laos (La-Orngplew, 2012).

One decisive political factor triggering land use change in Laos was the Chinese Opium Replacement Programme, which aimed at diverting rural labor from opium into rubber cultivation (Lu, 2017). Since the late 2000s, China has been the main source of capital investment in Laos (Lu and Schönweger, 2017). Despite signs of shifting cultivation systems and secondary forests in northwestern Laos being rapidly converted into rubber and maize plantations for export (Thongmanivong and Fujita, 2006; Vongvisouk et al., 2016), eradication of shifting cultivation remains at the core of the Lao Government’s development policies and supported by bilateral and multi-lateral collaboration agreements (MAF, 2007). In this context, generating time-dense, spatially explicit evidence is of high relevance to better understand land use dynamics, and to try illuminating the influence of policy implementation on them.

The present study focuses on Laos’ northwestern Luang Namtha province, bordering China, where landscapes have been experiencing rapid and intense land use change in recent decades. So far, the methods to monitor such dynamics have been limited to two main approaches. The first approach seeks to monitor land cover change using time-dense, but low-tomedium resolution remotely sensed spatial data such as Landsat imagery. Due to its coarse spatial resolution, this method is insufficient to study land use (i.e. different human uses of land)

![](images/67703a4dc4619fe6afeab43e2fd77e45f0bbe70f9b2463b4f4f69790a1ed31ed.jpg)

![](images/829538c1e68bae61e993e7564171eb4968626e7d3a23ae24ac19218d808c02b7.jpg)  
Legend

![](images/ae3e66bfca963c2f5485b2b72818627f50d9bfc17b5b485c49f4278af7942a3a.jpg)  
National Potected Areas Z Case Study Landscape   
District Boundary   
ZLuangNamtha Province   
Countries Boundary

![](images/15b2b921296f0c525ea15fda9872cecdce03821c60a59eacc9ca828564818210.jpg)  
FIGURE 1 Overview of the case-study landscape in the Sing district, Luang Namtha province, northwestern Laos. NPA, National Protected Area.

and only allows observers to infer land cover change (Weih and Riggan, 2010). Because of the relatively low spatial resolution, different land uses are conflated into just one land cover type. For example, what could be young shifting cultivation fallows, shrubs, or young rubber plantations might be lumped together as in a medium-height vegetation class.

The second approach relies on VHR spatial satellite imagery that enables evaluation of land use, but does not fully cover the Earth’s surface and does not go far back in time (Grenzdörffer, 2005; Hay and Castilla, 2006; Weih and Riggan, 2010). In Laos, for example, such imagery has only been available since 2005.

Meanwhile, for decades, remote-sensing and GIS specialists have struggled to develop classification procedures that move beyond pixel-based approaches (Csathó et al., 1999; Blaschke et al., 2000). One recent development on this front is objectbased classification, facilitated by software such as eCognition (Trimble, 2013). This classification approach considers both the

spectral and contextual properties of pixels in a segmentation process based on learning iteration algorithms. It achieves a semi-automatic classification process that might be more accurate than traditional pixel-based methods (Grenzdörffer, 2005; Blundell and Opitz, 2006).

The last two decades have witnessed a burgeoning use of participatory mapping to overcome the challenges associated with using remote sensing and GIS technologies to map spatially-explicit land use change (Chambers, 1994; Thomas-Slayter, 1995). Recent applications of participatory approaches to mapping land use and land use change include, but are not limited to, investigating the effects of rangeland policy on pastoral land use (Basupi et al., 2017), delineating village agricultural areas (Nackoney et al., 2013), and planning payments for ecosystem services initiatives in mangrove landscapes (Rakotomahazo et al., 2019).

In this study, we add to these applications and address the challenges involved in only using remotely sensed data to assess land use change by: (i) combining participatory mapping with VHR satellite imagery; and (ii) exploiting the strengths of objectbased classification. To accomplish this, we adapt a methodology developed by Zaehringer et al. (2018) in order to capture annual land use. This methodology has already been successfully implemented in other tropical regions, to understand, for example, land use regime shifts under cash crop booms in Myanmar (Zaehringer et al., 2020), and the combined effect of cash crop price fluctuation and protected area establishment on land use transitions in Madagascar (Llopis et al., 2019). In the present study, implementing this participatory mapping approach enables us to map land use trajectories over the course of almost two decades in northwestern Laos, a hotspot of Chinese agricultural investments. Our aim is to shed light on land use dynamics in the context of efforts by the Lao Government to foster local economic development by attracting foreign investments, as well as efforts by the Chinese government to steer land users toward rubber cultivation and away from opium cultivation.

# 2. Methods

# 2.1. Case study landscape

Our case study landscape is located in the Sing District of Luang Namtha Province in northwestern Laos, in the former “Golden Triangle” region, extending to the country’s borders with China (Yunnan province) and Myanmar (Figure 1). The study landscape encompasses 9,079 hectares (ha) and is predominantly mountainous, with elevations ranging from 1,200 to $1 { , } 9 0 0 \mathrm { m }$ (DOF, 2018). It features a humid tropical climate with temperature lows of around $5 ^ { \circ } \mathrm { C }$ at night in the dry and cold season from November to February, highs of up to $4 0 ^ { \circ } \mathrm { C }$ in the hottest months of March and April, and an average annual temperature of $2 5 ^ { \circ } \mathrm { C }$ . Intense rainfall normally occurs from May to October. While the Luang Namtha Province is inhabited by a large diversity of ethnic groups, in our case-study landscape the largest population group is Akha (Sino-Tibet ethno-linguistic group), comprising about $4 7 \%$ of the inhabitants. The second-most numerous are the Tai Lu, Tai Nua, Thai Dam, and Phunoi ethnicities (Tai-Kadai ethno-linguistic group), which together comprise $4 1 \%$ of the population, followed by the Hmong and Yao (Hmong-Mien ethno-linguistic group) comprising $1 2 \%$ , and lastly the Khmu (Mon-Khmer ethno-linguistic group) comprising about $1 \%$ of the population (Fujita et al., 2006). In our case-study landscape, we consider four villages, Oudomsin and Nammy (Lu-Mein/Yao ethnic groups), Nam Det-Mai, and Phaka (Akha ethnic group). Nammy, Nam Det Mai, and Phaka are located closer to the forest

frontier than Oudomsin (see Figure 1). Nam Det Mai is located near to the Panghai border crossing to China.

Land use in the area has been traditionally dominated by small-scale farming systems emphasizing subsistence rice cultivation, grown either in irrigated lowland paddies or through shifting cultivation in the uplands. Besides rice, vegetables for household consumption are also grown, as well as corn and seasonal vegetables in lowland areas with sufficient water. Further, some areas were converted into pasture land after rice cultivation. Collection of non-timber forest products (NTFPs) is a key component of the livelihoods of most local families, especially those living in the uplands. NTFPs contribute to food security alongside rice, either through direct consumption, or through sale of NTFPs to buy rice when people face food shortages (Vongvilay, 2006). Due to its proximity to the international border of China’s Yunnan province, the area has experienced a substantial influx of Chinese investments in recent decades, especially in rubber and sugarcane, and more recently, also in other perennial and seasonal cash crops like banana, cardamom, sacha inchi (Plukenetia volubilis L.), watermelon, and pumpkin, among others. Different investments models have been implemented, ranging from contract farming to land users leasing their land to investors directly (Friis and Nielsen, 2016; Vongvisouk et al., 2016; Broegaard et al., 2017; Lu, 2017).

# 2.2. Participatory mapping based on high-resolution satellite imagery

For this study, we adapted the methodological approach developed by Zaehringer et al. (2018), combining participatory mapping with object-based spatial classification using remotely sensed high-resolution imagery. This enabled us to produce a time series of 17 annual land use maps, which in turn enabled us to reconstruct land use transitions in the casestudy landscape from 2000 to 2017. During an exploratory field visit in April 2016, we held preliminary meetings with village authorities to obtain an initial overview of the land use changes prevalent in the area. The main land use changes related to the commercialization of agriculture began after 2000. We thus decided to select the year 2000 as the starting point for our empirical investigation of land use change. Based on knowledge obtained during this exploratory field visit about the different land use types present, we developed a detailed land use classification system that included all types present between 2000 and 2017 (Table 1).

In order to map current land use, and to provide a basis to construct the geometry for mapping previous land use, we sought to acquire the most-recent cloud-free VHR Pléiades satellite imagery available (at the time of the study). The VHR imagery used for subsequent analysis was acquired on 30 March 2017.

TABLE 1 Land use classification system.   

<table><tr><td>Land use type</td><td>Description</td></tr><tr><td>Bare soil</td><td>Permanent open area</td></tr><tr><td>Young fallow</td><td>Fallow of 1–5 years after upland rice cultivation</td></tr><tr><td>Old fallow</td><td>Fallow of 6–10 years after upland rice cultivation</td></tr><tr><td>Forest</td><td>Old-growth and secondary forest</td></tr><tr><td>Paddy</td><td>Paddy rice field, can contain other seasonal cash crops, rice is harvested</td></tr><tr><td>Built-up area</td><td>Villages, settlements, etc.</td></tr><tr><td>Young rubber</td><td>Rubber plantation younger or equal to 6 years</td></tr><tr><td>Old rubber</td><td>Rubber plantation older than 6 years</td></tr><tr><td>Cultivated upland crop</td><td>Plots of upland rice in a shifting cultivation system or young rubber planted in fields of upland rice, which will eventually disappear</td></tr><tr><td>Shrub</td><td>Mixed low-growth trees, usually located near rivers or on steep slopes</td></tr><tr><td>Banana</td><td>Intensive banana plantation area</td></tr><tr><td>Sugarcane</td><td>Sugarcane plantation area</td></tr><tr><td>Other</td><td>Bare soil, ponds, rivers, roads, settlements, shrub, and other agricultural land</td></tr></table>

Our mapping approach consisted of three steps. The first entailed conducting an object-based classification of the Pléiades VHR image, so as to generate polygons representing homogenous land use categories (Table 1). We outlined land use polygons using the multi-resolution segmentation tool included in the eCognition Developer Software (Trimble, 2013). We made systematic tests in order to identify the optimal combination of parameters (i.e., spectral band weights, scale, shape, and compactness) on behalf of the best-possible segmentation for a subsequent visual interpretation and classification of the land uses in the image. To increase the accuracy of each polygon’s boundary, we manually merged or split the polygons in a post-processing step, after confirming their actual boundaries with land users during the participatory mapping exercise (see next step). For those polygons where a visual interpretation of land use was directly possible based on the Pléiades image, we immediately assigned the corresponding land use type to the polygon (Table 1).

The second step of our mapping approach consisted of a participatory mapping workshop in each of the four villages covered in this study, with the exception of Nam Det-Mai. The inhabitants of Nam Det-Mai migrated and settled near the village of Nammy in 1984. Preliminary research revealed that the majority of the land in that area belonged to inhabitants of the villages of Nammy and Oudomsin, and as a result, the participatory mapping in those two villages encompasses the Nam Det-Mai area. These participatory workshops, conducted

between February and March 2017, enabled us to engage in indepth discussions with land users in the case-study landscape, and were facilitated by the first author of the present article— a native Lao speaker. The goals of the workshops were, first, to make necessary corrections to the land use polygons obtained through object-based segmentation; second, to identify and validate the attribution of land use types to the polygons for the 2017 land use map; and third, to obtain local knowledge on the history of land use in the case study landscape at different points in time since 2000. Workshop participants included people with knowledge on land use trajectories in each village, such as village authorities, representatives of women and youth unions, as well as elderly land users. As is generally the case when conducting field research in Laos, we had to seek consent from village authorities to invite participants to these workshops. Assuming that information about spatially-explicit land use change is relatively objective, we did not require participant groups to be representative of the local population. Instead, we sought people with knowledge of land use changes in the case study landscape over the last two decades or with detailed knowledge about more recent changes. The number of participants in each of the exercises ranged between three and five people (Table 2).

The participatory mapping exercise was part of a larger 6-year research project, led by a team of Lao researchers from the Faculty of Forestry at the National University of Laos. Through the project, engagement with village authorities and inhabitants of these four villages had started well before the participatory mapping workshops took place. This included a variety of interactions through different workshop formats, each of them starting with some icebreaker activities. During these project-level workshops, participants discussed and subsequently modified the project’s research questions, developed a joint understanding of the Sustainable Development Goals, prioritized land use changes with regards to their impacts on local wellbeing and identified a need to better understand these impacts through research. The first author of this paper conducted the participatory mapping workshops and field walks. Being a Lao national, researcher and lecturer at the National University of Laos strongly helped to gain trust from village authorities and inhabitants. Before engaging in any of the participatory mapping activities, he engaged informally with participants by visiting them at their homes and familiarizing himself with issues of interest and concern to them (such as the price of cash crops, education of their children, etc.). Similarly, before engaging in any research activity, every participatory mapping workshop started with casual talk about daily life. Participant’s consent with regards to the publication of the spatially-explicit land use change information in scientific publications was sought and their anonymity assured. For the workshops, we printed the VHR Pléiades satellite image on A1 formatted paper at a scale of 1:8,000, overlaid it with a basemap from ArcGIS (ESRI, 2016) and the land use polygons including previously assigned land use information in color, and covered

TABLE 2 Overview of participatory mapping workshops and field walks.   

<table><tr><td>Village</td><td>Year of village establishment</td><td>Main ethnic group</td><td>No. of workshops</td><td>No. participants</td><td>Field walks (km)</td></tr><tr><td>Oudomsin</td><td>1992</td><td>Mien/Yao</td><td>1</td><td>5</td><td>32</td></tr><tr><td>Nam Det-Mai</td><td>1984</td><td>Mien/Yao</td><td>0</td><td>na</td><td>16</td></tr><tr><td>Nammy</td><td>1980</td><td>Mien/Yao</td><td>1</td><td>4</td><td>12</td></tr><tr><td>Phaka</td><td>1997</td><td>Akha</td><td>1</td><td>3</td><td>18</td></tr></table>

it with transparent sheets. To support the mapping process, we also printed the same satellite image at a scale of 1:5,000 on A3 formatted paper to better address particular parts of the map of special interest (e.g., forest edges). The same was done with global forest change data from 2000–2017 provided by Hansen et al. (2013). After introducing the purpose of the workshop, participants were first asked to identify important landscape elements (e.g., rivers, mountains) in the basemap, which the facilitator then wrote down on the map using their local names. The identification of such landmarks was a crucial step to facilitate participants’ orientation on the map, and to then discuss land use change in detail. Based on the land use classification system, participants confirmed, modified, or added current land use information on the different polygons, with the VHR satellite image in the background. We then proceeded to obtain previous land use information for each polygon for the different sections of the case-study landscape (e.g., upland area, lowland area, forest, slopes, and valleys), discussing with participants histories of land use(s) for each polygon. The facilitator wrote the year of change on small sticky notes with a unique color assigned to each land use type, and attached them to the overlaid transparent paper sheet. At the end of the workshop, the facilitators made photos of the maps as a backup and kept the original maps for digitalization.

In the third step of our mapping approach, we conducted field walks with local villagers and land users who had been living and working in the area since 2000. The goal of the field walks was to acquire missing information on histories of land uses that we could not obtain in the previous step. We planned the routes for the field walks in consultation with local guides, with the goal of finding an accessible path that would transect all land use types in each section of the case-study landscape identified in the workshop. The modalities of the field walks depended on the terrain and steepness of the slopes; a motorbike was used where conditions allowed. We brought with us the current land use map with the classification results from the visual interpretation printed on A3 sheets (scale: 1:5,000), overlaid with transparent sheets containing the results from the workshop discussions. During the field walks, we used these materials to note missing land use information for each individual plot. Additionally, we captured GPS coordinates with a handheld GPS device, and took pictures in the four cardinal directions to synchronize with the geo-location of the pictures.

# 2.3. Data entry and analysis

After the field walks, we transferred the information on each polygon’s land use history to the polygon layer obtained through the first step of our approach in ArcGIS. The land use details for each year captured during the workshops and field walks were inputted into the polygon layer’s attribute table, which consisted of one column per year from 2000 to 2017. In some instances, we had to split or merge the polygons when the information obtained through the workshops or field walks indicated a different land use geometry in the past. Through this process, we created a spatially explicit data layer of land use polygons with information about the specific land use for each polygon for each year between 2000 and 2017. The final output was spatially explicit annual land use maps, which we employed to compute land use change statistics in ArcGIS, namely by calculating from–to land use change at the polygon level. We visualized land use change trajectories with stacked area charts using R statistical software (R Core Team, 2015), as well as visualizing annual area of change for the different from–to land use changes.

# 3. Results

# 3.1. Overall land use change between 2000 and 2017

The landscape encompasses two topographically distinct parts, each with its respective land uses (Figure 2). Lowland areas occupy about one fifth of the total area, and are located on the western side of the landscape, while the rest of the casestudy landscape can be described as upland areas. In 2000, the lowland areas were covered mainly by rice paddies and some sugarcane plantations, while the upland areas were dominated by forest, interspersed with some plots of cultivated upland rice and fallows.

Land use in the case-study landscape underwent major changes from 2000 to 2017 (Table 3). In the upland areas, forest and fallow land use categories followed a very similar pattern over the period studied, with forest area decreasing by $4 1 \%$ and fallow by $9 7 \%$ . Deforestation occurred in the vicinity and partly also within the Nam Ha National Protected Area

![](images/b8aa87ed439a21eedb6bcf39b41402f290ce43ad9221393573dc2fa413484bac.jpg)

![](images/5dd42425da820b21b6e83576909d36d5e58a0bd4942adb657953ac61f33d8c21.jpg)  
Legend   
Border Crossing

![](images/55fdb5d14321ea3248d6bfe2d2c60504074195674cbe6330fdea17b2ca521d4b.jpg)  
CaseStudy Villages

![](images/e0df9279e55bcbda3ffa2a5783dcc389f2f3914906f73ca04d3b3ae1166dac58.jpg)  
Other Villages

![](images/a01426e10c281daab4d2c85653cf1f3f59cce3e53cda3d474174ae6a041fe95b.jpg)  
Road

![](images/16ed80fbe8b0d2ab963bc56da5562ecf910fde815929c9dc6d8d26baaebd9d00.jpg)  
NationalBoundary

![](images/f7b5479417009deaac666f49d0bce01d88d57265c42a12b76f29910c8f1545c7.jpg)  
National ProtectedArea

![](images/8e961c3e52ed6459f67b090e7e133bb155fca487ae4f80d4e142a84f221023b1.jpg)

![](images/50866849fcb4a27ea6f03182317a2e731ca2b524156d336b5b5884f9cf8a1f54.jpg)

![](images/79be8354f72a1b18b1487a778ad8b0f58aef9b408c9884ba128dd10542cb29a8.jpg)

![](images/dcb58f985689016a96612e9a11f38450732b96e80833af1523e21b5213f900c4.jpg)  
Rubber

![](images/99354fa9fdccd6f803d52aedb3ed6ff9459f9f0feaf79352ed487cba1f48edf8.jpg)

![](images/7c6b5b61211ba22c7b8212714ebb562b2b4ce36abc07090ea58181e197e906a0.jpg)

![](images/f191f28af70158adf58d21837e69cbdd27ee398dd8591f2c4335e19e895e28f5.jpg)  
Upland

![](images/f62c6ceacc0456da367dffe318619411b21c06903eecab3733033e6535dd7384.jpg)  
1Crop

![](images/20062a64b09a03c694c0881a99db87c934f48431025502de84ef8b12f54e4be6.jpg)

![](images/d9f60893f4e37e9cbc33fcee6d7957d15f57c5593a5fadcd4b4251da42bd678a.jpg)  
Banana

![](images/8adbd43336f26d37cd6bf2a45de8562d3c40fbb321209bfa21fea68faa719725.jpg)

![](images/70877a34f3edd1bd62f7ea343c1aec70c223cd5430a8378a3cd5674f52530ad2.jpg)

![](images/3d12798aefd43612c6e83805285638dabc23b0bf3c96dcfcdd69adc1e4eeae77.jpg)  
Other

![](images/0546024e5eacd61b5ec0086546a157e00a016c49c396e16b3e5ad55c74268c53.jpg)

![](images/c16b672e8083bf73a6fa2b489473cb52f870e000c3556b7242803130756eb720.jpg)

![](images/ac6d84071cdcc16c96019dd03e9aab1a9909e55e0e92811f678198b99544ca60.jpg)  
High

![](images/d565f7b51ba08ec5c3401bd14050a023c52ffc0b7e4f1f030d3e7ba513a1a118.jpg)  
gh : 194

![](images/76f3ef459f38f018f4552514114d7a9f43b21049206c245b9e4a7fa66c54f5ff.jpg)

![](images/69a0567aec75c2f3313696f6ffc1870b865ecd6e55c783164e58eb862236d9f2.jpg)  
FIGURE 2   
Land use in the case-study landscape in (A) 2000 and (B) 2017. NPA, National Protected Area.

(Figure 2). At the same time, rubber plantations increased by $1 , 0 2 4 \%$ , from 369 ha in 2000 to 4,143 ha by 2017, and cultivated upland crops, especially rice, which had covered 92 ha in 2000, totally disappeared by 2017. This means that shifting cultivation, characterized by the presence of cultivated rice fields among fallow plots of different age, was no longer practiced as of 2017.

Meanwhile, our analysis indicated that, on the one hand, while the area of irrigated paddies decreased by $7 1 \%$ —or from 928 to 272 ha—banana plantations increased massively by $2 , 9 7 1 \%$ , namely from 17 to 522 ha. On the other hand, sugarcane increased by $1 6 \%$ , specifically from 459 to 532 ha between 2000 and 2017.

# 3.2. Detailed evolution of land use systems from 2000 to 2017

The visualization of annual land use information over 17 years illustrates the highly dynamic nature of land use changes in the case study landscape between 2000 and 2017 (Figure 3). At first, cultivated upland crop increased by 267 ha between 2002 and 2004 (or $2 . 9 \%$ of the case study landscapes), and then increased by another 253 ha between 2005 and 2006 (or

$2 . 8 \%$ ). However, between 2007 and 2017, cultivated upland crop decreased until it eventually disappeared entirely. Throughout the study period, forested areas underwent a steady decline, with higher-than-average deforestation rates (i.e., 129 ha/year) occurring between 2002 and 2003 (179 ha or $- 2 \%$ ), as well as between 2005 and 2007 (968 ha or $- 1 0 . 7 \%$ over 2 years) and between 2013 and 2014 (170 ha or $- 1 . 9 \%$ ). Meanwhile, rubber experienced a sudden increase of 647 ha $( 7 . 1 2 \% )$ between 2005 and 2006, increased 434 ha $( 4 . 7 8 \% )$ ) between 2006 and 2007, increased by another 1,318 ha $( 1 4 . 5 1 \%$ ) between 2012 and 2015, and continued to expand during the rest of the study period. The overall fallow area decreased by 400 ha $( - 4 . 4 \% )$ from 2000 to 2004, although in 2005, it expanded by 126 ha $( 1 . 3 8 \%$ ). Between 2012 and 2017, the extent of fallow land dropped by a total of 839 ha $( - 9 . 2 4 \% )$ ). All of these changes occurred in the upland areas of the case study landscape (Figure 2).

In the lowland area, the main land use between 2000 and 2004 was paddy rice—primarily for subsistence, but also for exchanging with other village inhabitants—and covered about 928 ha (or $1 0 . 2 2 \%$ of the case study landscape). Starting in 2005, the paddy rice area decreased continuously until 2014, by which point the total paddy rice area covered only $3 \%$ of the casestudy landscape. It remained this way until 2017. With respect

TABLE 3 Land use in the case study landscape in 2000 and 2017 and change in percent of the 2000 area.   

<table><tr><td colspan="2">Land use category</td><td colspan="2">Area in ha (2000)</td><td colspan="2">Area in ha (2017)</td><td colspan="2">(%) Area change</td></tr><tr><td>Aggregated</td><td>Non-aggregated</td><td>Aggregated</td><td>Non-aggregated</td><td>Aggregated</td><td>Non-aggregated</td><td>Aggregated</td><td>Non-aggregated</td></tr><tr><td>Forest</td><td>-</td><td>5,332</td><td>-</td><td>3,136</td><td>-</td><td>-41</td><td>-</td></tr><tr><td rowspan="2">Fallow</td><td>Young fallow</td><td rowspan="2">1,297</td><td>1,041</td><td rowspan="2">44</td><td>8</td><td rowspan="2">-97</td><td>-99</td></tr><tr><td>Old fallow</td><td>256</td><td>36</td><td>-86</td></tr><tr><td>Cultivated upland crop</td><td>-</td><td>92</td><td>-</td><td>0</td><td>-</td><td>-100</td><td>-</td></tr><tr><td>Paddy</td><td>-</td><td>928</td><td>-</td><td>272</td><td>-</td><td>-71</td><td>-</td></tr><tr><td rowspan="2">Rubber</td><td>Old rubber</td><td rowspan="2">369</td><td>2</td><td rowspan="2">4,143</td><td>2,745</td><td rowspan="2">1,024</td><td>137,150</td></tr><tr><td>Young rubber</td><td>367</td><td>1,397</td><td>281</td></tr><tr><td>Banana</td><td>-</td><td>17</td><td>-</td><td>522</td><td>-</td><td>2,971</td><td>-</td></tr><tr><td>Sugarcane</td><td>-</td><td>459</td><td>-</td><td>532</td><td>-</td><td>16</td><td>-</td></tr><tr><td rowspan="7">Other</td><td>Bare soil</td><td rowspan="7">585</td><td>43</td><td rowspan="7">431</td><td>47</td><td rowspan="7">-26</td><td>9</td></tr><tr><td>Pond</td><td>18</td><td>18</td><td>0</td></tr><tr><td>River</td><td>16</td><td>16</td><td>0</td></tr><tr><td>Road</td><td>23</td><td>23</td><td>0</td></tr><tr><td>Urban</td><td>128</td><td>129</td><td>1</td></tr><tr><td>Shrub</td><td>338</td><td>170</td><td>-50</td></tr><tr><td>Other</td><td>20</td><td>29</td><td>45</td></tr></table>

to sugarcane, the area planted with this crop encompassed 565 ha (or $6 \%$ ) between 2000 and 2011. However, the area under sugarcane decreased sharply between 2012 and 2016 until it only covered $1 \%$ of the total area, just to rebound again to some $6 \%$ (or 532 ha) in 2017.

Banana cultivation for export has been growing since 2010, reaching $4 \%$ of the total landscape area by 2012, then $1 0 \%$ in 2013, and finally $1 1 \%$ (or 984 ha) in 2016. However, in 2017, the area devoted to banana plantations abruptly decreased dramatically to $6 \%$ (532 ha).

# 3.3. Major from–to land use changes from 2000 to 2017

To obtain a clearer picture of land use change dynamics in our case-study landscape, we look closely at annual changes from one land use to another, and contrast them with important political and economic influcences on agrarian activities (Figure 4). We distinguish three distinct periods characterized by sudden land use changes in the uplands and lowlands, respectively: 2000–2005, 2005–2010, and 2010–2017.

During the first period (2000–2005), most land use changes took place in the upland area, mainly dominated by dynamics of shifting cultivation for upland rice production. The overall shifting cultivation pattern consists of slashing and burning

of existing fallow plots (rotational shifting cultivation) or oldgrowth forest plots (pioneering shifting cultivation), which are brought into rainfed rice cultivation for a year and then left fallow again until the next cultivation cycle. During this period, both rotational and pioneering shifting cultivation peaked between 2002 and 2003, when 226 ha of fallow and 179 of old-growth forest, respectively, were slashed-and-burned and brought into rice cultivation. Most forest conversion took place in the northern part of the case study landscape near the border with China, where forest is not protected. In the southeastern part, where the Nam Ha protected area is located, there was less deforestation, and none of it occurred inside the conservation zone. Throughout the study period, rotational (not pioneering) shifting cultivation dominated in terms of area slashed, with the exception of 2000–2001 and 2005–2006, when approximately 247 ha of forest and only 155 ha of fallow were converted to cultivated upland crop.

During the same period, in which the promotion of tree plantations through Laos’ “Socio-economic Development Plan 2001–2005” (GoL, 2001) coincided with the Chinese government incentivizing investment abroad (Lu and Schönweger, 2017), rubber cultivation started in the area. Rubber was mostly planted in former fallow fields, encompassing 90 ha between 2001 and 2002, and 159 ha between 2003 and 2004. During the entire period from 2000 to 2005, 221 ha of forest were directly converted to rubber plantations. About 22 ha of cultivated upland crop closer to

![](images/1c0d4d71d2179df5e1176a70847a3176b8692f0c8eebbe80e9730085d588d643.jpg)  
FIGURE 3 Aggregated land use transitions from 2000 to 2017 in lowland and upland areas. Each land use is represented as a percentage of the total mapped area for each year. “Other” land use includes bare soil, ponds, rivers, roads, settlements, shrub, and other agricultural land.

![](images/dfe7af3833e1529eb0523ea71ce275ab50982855e8bd559f6f1f7431ea482668.jpg)  
FIGURE 4   
From–to land use change from 1 year to the next between 2000 and 2017.

the villages changed to sugarcane between 2002 and 2003. Meanwhile, the lowlands experienced hardly any land use change, with only 19 ha of sugarcane converted to rubber from 2003 to 2004.

During the second period (2005–2010), the Lao Government’s policy of “Turning Land into Capital” (Dwyer, 2007) further promoted tree plantations through the 5-year “Socio-economic Plan” from 2006 to 2010, implemented by the

Ministry of Agriculture and Forestry (MAF, 2007) to attract private sector investment into rubber cultivation. This can be seen in Figure 4, as 2005–2006 saw the highest amount of direct conversion of forest to rubber (around $4 2 0 \mathrm { { h a } }$ ), and also of forest to cultivated upland crop, with 247 ha converted that same year. This means that, overall, the year 2005–2006 displayed the highest amount of forest loss of the entire study period, i.e., 874 ha, or $4 1 \%$ of the total forest loss (2,196 ha) between 2000 and

TABLE 4 Land use change trajectories, frequency of changes, and areas that remained stable between 2000 and 2017 in the case study landscapes.   

<table><tr><td>Land use change trajectory</td><td>Number of trajectory&#x27;s steps</td><td>Area (ha)</td><td>% of total landscape area</td></tr><tr><td>Total Change</td><td>0</td><td>4,830.38</td><td>53.20</td></tr><tr><td>Forest to rubber</td><td>1</td><td>1,442.04</td><td>15.88</td></tr><tr><td>Fallow to rubber</td><td>1</td><td>548.52</td><td>6.04</td></tr><tr><td>Forest to cultivated upland crop to fallow to rubber</td><td>3</td><td>634.74</td><td>6.99</td></tr><tr><td>Fallow to cultivated upland crop to rubber</td><td>2</td><td>580.47</td><td>6.39</td></tr><tr><td>Paddy to banana</td><td>1</td><td>291.85</td><td>3.21</td></tr><tr><td>Paddy to sugarcane to banana</td><td>2</td><td>186.93</td><td>2.06</td></tr><tr><td>Sugarcane to banana to sugarcane</td><td>1</td><td>185.81</td><td>2.05</td></tr><tr><td>Paddy to banana to sugarcane</td><td>2</td><td>158.20</td><td>3.28</td></tr><tr><td>Other to rubber</td><td>1</td><td>136.71</td><td>1.51</td></tr><tr><td>Sugarcane to rubber</td><td>1</td><td>133.73</td><td>1.47</td></tr><tr><td>Other changes</td><td>-</td><td>531.39</td><td>5.85</td></tr><tr><td>Total Stable categories</td><td>0</td><td>4,248.72</td><td>46.80</td></tr></table>

Only trajectories covering more than 130 ha of the total area assessed are presented.

2017. In the following year, 2006–2007, another 220 ha of forest were converted to rubber. Further, 193 ha of fallow land were converted to rubber cultivation from 2005 to 2006. Another peak of fallow to rubber conversion occurred from 2008 to 2009. In terms of location, rubber expansion began through the conversion of fallow land relatively close to villages, followed by further expansion of fallows closer to the forest frontier and directly from forest (786 ha), mainly by households that lacked adequate fallow land or paddy fields to convert to rubber production. After this rapid expansion of rubber on both forest and fallow land, much lower amounts of forest were converted to rubber between 2007 and 2010, with an overall expansion of rubber plantations of 1,654 ha in 2005–2010.

Meanwhile, in the lowlands, sugarcane plantations were also turned into rubber plantations, especially from 2006 to 2007 and from 2008 to 2009, when 43 ha were converted in each time period. Further, it was also during this period when intensive monoculture banana plantations were introduced in the case study landscape, specifically between 2009 and 2010, when 94 ha of paddy fields were converted to banana.

Finally, during the third period (2010–2017), the upland area of the case study landscape experienced another upward trend of rubber expansion in the wake of an “all-time high” of rubber prices in 2011 (about 14 CNY/kg) (Vongvisouk and Dwyer, 2016). The peak of that expansion occurred between 2013 and 2014, when 276 ha of fallow land and 167 ha of forest were turned into rubber plantations. By 2017, this resulted in a total area under rubber cultivation of 3,317 ha, of which 1,488 ha resulted in deforestation. Notably, between 2000 and 2017, also a total of 213 ha of the small part of the NPA included in our

case study landscape was deforested, of which 153 ha were for the establishment of rubber plantations.

From 2016 to 2017, almost no further expansion of rubber plantations occurred, coinciding with a collapse in rubber prices to a record low.

Meanwhile, in the lowlands in this period, a banana boom got underway in 2011 when Chinese investors began entering into direct land-lease agreements with local farmers (Friis and Nielsen, 2016). The expansion of banana plantations peaked between 2012 and 2013, when 300 ha of paddy rice fields and 316 ha of sugarcane plantations were transformed into banana plantations. Those eventually reached a maximum extent of 984 ha in 2016. However, after the Lao Government announced a ban on the conversion of paddy and sugarcane fields into banana plantations in 2014 (Government of Laos, 2014), and a parallel outbreak of the Panama disease occurred from 2016 to 2017 (Dubus, 2016), almost half of those banana plantations (488 ha) were converted to sugarcane plantations.

# 3.4. Land use change trajectories

Next, we will explore which land use changes were most widespread in the case study landscape. While, overall, $5 3 \%$ of the total case study landscape experienced at least one change in land use between 2000 and 2017 (Table 4), many agricultural plots underwent multiple changes. We refer to the sequence of land uses on the same plot as land use change trajectories. The most important of these in terms of area was the change of forest to rubber $1 6 \%$ of total case study landscape); followed by

forest to cultivated upland crops, then to fallow land, and then to rubber $( 7 \% )$ ). The remaining two trajectories started with fallow and ended with rubber cultivation, either with $( 6 \% )$ ) or without the intermediate step of cultivated upland crops $( 6 \% )$ . Overall, these four trajectories leading to rubber cultivation accounted for some $3 5 \%$ of the landscape, mostly in the upland area.

In the lowland area, the longest trajectories were from paddy to banana plantations, either without $( 6 \% )$ ) or with an intermediate step of sugarcane cultivation $( 4 \% )$ ). The other two trajectories ended with sugarcane cultivation, either from sugarcane to banana and back to sugarcane $( 4 \% )$ ) or from paddy to banana and then sugarcane $( 3 \% )$ .

# 4. Discussion

In the following section, we discuss the results in the light of our study objective. We first provide insights on land use before 2000, not assessed in a spatially explicit way, but gathered through the workshops. This provides background to the dynamics we subsequently investigated in a spatially explicit manner. Next, we discuss the situation in our case study landscape in three broad periods: 1990s–early 2000s; early 2000s–early 2010s; and 2010–2017. We pay particular attention to exploring the influence of key factors emphasized by participants as influencing their land use decisions.

# 4.1. The complete transformation of a tropical forest frontier

# 4.1.1. LUC: 1990s–early 2000s: The last years of subsistence cultivation

In the 1990s (and to some extent the 2000s, too), local people practiced shifting cultivation in the upland fallows and forests surrounding the villages. Many households also planted paddy rice in the lowland area and collected non-timber forest products (NTFPs) in the forest for food security. In the early 1990s, livestock (e.g., cow, buffalo, and poultry) was the second mostimportant asset category for local households, also serving as savings that could be sold in case of need for financial resources for particular events, such as unexpected health problems, celebratory ceremonies like weddings, or to cover children’s school fees.

At the same time, both the number of settlements and the total population expanded in the area for several interrelated reasons beyond natural population growth. On the one hand, the Lao government began implementing a series of policies resulting in the relocation of some of the populations in the area. The most important one was a resettlement scheme to move people from upland areas, which were considered underdeveloped (e.g., lacking infrastructure; lacking access to electricity, schools, and markets), to lowland areas, closer

to roads and services. This scheme was accompanied by policies aimed at eliminating opium growing, ending shifting cultivation, attempting to consolidate villages, and introducing “focal development areas” (Baird and Shoemaker, 2007). Further contributing to population increase was an agreement reached between the Lao government and the Government of Thailand to enable refugees living in Thailand since the end of the Vietnam War to resettle in Oudomsin village. Population growth in the case study landscapes also escalated land use change in the lowlands due to increased demand on the landscape’s resources.

# 4.1.2. Early 2000s–early 2010s: A gradual rubber boom in the uplands

The early 2000s marked a shift in Laos’ overall economic policy. After suffering through the Asian Financial Crisis of 1998 (Radelet et al., 1998), the Lao government realized that foreign capital was needed to achieve economic stability, and so the country unveiled a more open-door policy to attract foreign investments (OECD, 2017). Meanwhile, the Chinese government launched an “Opium Substitution Programme” together with the Lao government, in which Chinese investors were supported to invest in alternative agricultural land uses to replace opium cultivation in Northern Laos (Lu, 2017).

These broad macroeconomic trends influenced land use in the case study landscape. In the early 2000s, the traditional repeated cultivation of upland rice on fallows and in forests near to villages gradually gave way to conversion of these land uses to sugarcane and partly to rubber plantations. Rubber cultivation was first tested around 1994–1995 by a farmer from Oudomsin village, who cleared fallow and forest land to cultivate rubber close to the Chinese border. After successfully tapping the rubber trees to produce latex for the first time around 2002– 2003, the farmer introduced the rubber cultivation technique to farmers in Oudomsin village, who began taking up rubber cultivation, encouraged by increasing latex prices at that time (Junquera and Grêt-Regamey, 2019). The then-observed upward trend in rubber prices (from $0 . 7 \mathrm { U S D / k g }$ in 2000 to $4 . 0 \mathrm { { U S D / k g } }$ in 2011) convinced local farmers that rubber cultivation could be a new reliable source of income that would in turn help raise living standards in the area (Baird, 2011). After this, local authorities supported and promoted rubber cultivation in the area as the new cash crop that could help achieve sustainable development goals in northern Laos, while replacing shifting cultivation (Manivong et al., 2003; Charles et al., 2005; Fujita et al., 2007).

The subsequent expansion of rubber cultivation in the area was additionally fuelled by several other factors, including the increase of Chinese trade across the border and the Lao government’s promotion of rubber plantations under its “Socioeconomic Plan 2001–2005.” Another reason was the “Turning Land into Capital” policy introduced by the Lao government in the same period, aiming at increasing the value of land

(Dwyer, 2007; Baird, 2011; Kenney-Lazar, 2012). An additional political factor was the government’s “village consolidation” strategy. Previously, people and communities lived dispersed across the landscape and far from initial settlements and usual farming areas. So, the government sought to direct ongoing settlement into densely populated areas in order to better integrate them into the prevailing economic and cultural system. The government implemented this by consolidating smaller settlements into larger, more permanent ones, in order to better manage them (Baird and Shoemaker, 2007). At the individual level, by planting rubber, farmers sought to secure their land tenure and transform their customary land rights into a territorial strategy (Kramp et al., 2022). The interplay of these factors led to the conversion of hundreds of hectares of land from traditional subsistence cultivation to large-scale commercial-oriented plantations, as illustrated in our participatory mapping approach. Our data also indicated that, even after rubber prices fell in 2011–2012, local farmers still believed that rubber was the “Green Gold” that they could continue to rely on for a living. Further, they had available cash from leasing out land for banana cultivation in the lowlands, available labor due to the abandonment of irrigated paddy rice production, and access to inputs (Junquera et al., 2020). Concretely, prevalent subsistence practices, particularly shifting cultivation, began to be viewed as less attractive than rubber cultivation, particularly given the time demands of the former, and rubber cultivation held the promise of enabling acquisition of consumer goods. This eventually drove local farmers to divide their overall agricultural livelihood strategies into two broad, complementary sets (Polthanee et al., 2021): First, short-term, annual cash cropping, such as sugarcane, and to some extent paddy rice; and, second, longer-term cash cropping, such as rubber plantations, seen as an investment to provide more stable income in the future. This perception aided the general land use transition from subsistence to commercial agriculture, putting further strain on the forest border surrounding Nam Ha National Protected Area.

At the same time, a “rebound effect” (Meyfroidt et al., 2018) emerged with the expansion of rubber cultivation at the upland forest frontier, including inside the protected area, also driven by farmers’ increased financial capital thanks to income from renting out their paddy land for banana cultivation (see next section). This phenomenon has been observed in other areas in connection with expanding cash cropping, increasing pressure on National Protected Areas elsewhere as well (Thongmanivong and Fujita, 2006; Vongvisouk et al., 2016) and contrasting with the land sparing hypothesis (Green et al., 2005). Altogether, our study indicates that the Lao government’s strategy of halting deforestation by ending shifting cultivation and introducing a permanent cash crop—rubber—did not have the desired or anticipated effect. Instead, rubber turned out to be just as much a threat to the remaining forests as shifting cultivation was believed to be. This confirms more regional-level assessments

of rubber expansion and anticipated negative impacts on biodiversity are needed (Ahrends et al., 2015).

# 4.1.3. 2010s: A sudden and ephemeral banana boom in the lowlands

While most of the above-mentioned changes took place in the upland area of the case-study landscape, the lowland area also experienced intense land use changes beginning in the early 2010s. Here, many of the changes that emerged in this period were related to the increasing influence of links with China given the proximity to the border, which facilitated the arrival of Chinese businessmen in the area. These investors were interested in leasing agricultural land for the production of commercial crops, mainly banana produced in monocultures. They would offer around 9,000–15,000 Yuan (USD 1,328–2,214) a year per hectare of paddy rice or sugarcane plot, depending on soil quality and location, favoring those fields with easy access to roads and to irrigation water (Friis and Nielsen, 2017). Many villagers found the offer attractive, as this money was more than sufficient to buy the rice they would otherwise produce on that land through their own labor. Consequently, between 2011 and 2016 many farmers leased out their land to Chinese businessmen under 5-year contracts, either out of their own will, or through inter-peer pressure, although not all farmers were inclined to give up rice cultivation. However, as reluctant farmers’ plots began being surrounded by banana plantations, and the local irrigation scheme was altered to satisfy the requirements of banana cultivation, less water was available for the irrigated paddy fields. In this way, rice cultivation became more difficult, and many farmers ended up accepting the Chinese offer to lease out their land for commercial production.

Already by 2013, some two thirds of the paddy fields and sugarcane plantations in the area had been converted to banana plantations. This also increased pressure on the upland forest frontier, including on Nam Ha National Protected Area, given that as people earned money from renting out their paddy and sugarcane fields, they could afford to clear forest land for cash cropping, in particular rubber. Although in the first years banana plantations were very productive, an outbreak of the Panama disease (Fusarium oxysporu f. sp. cubense) soon began affecting them, such that some Chinese investors abandoned their plantations, even if the contract was still running, in an attempt to cut losses. In parallel, concerns increased in Lao society about the environmental risks of intensive banana monocultures, including high amounts of chemical inputs, plastic waste, and corresponding pollution of rivers and soils (Friis and Nielsen, 2017). In 2014, these dangers eventually spurred the Lao government to introduce a ban on any further conversion of paddy fields into banana plantations, under legislation No. 830/Government Office. Moreover, China abruptly started inspecting banana exports from Laos, slowing the burgeoning commerce and marking the first time that export

standards were implemented between the two nations (Taejun, 2020).

Eventually, many Chinese businessman harvested the banana crops and moved back to China, often without paying the local farmers all the money stipulated in the contract. Notably, it is materially difficult and economically costly to convert banana fields back into paddy rice cultivation, requiring tools and machinery that local communities lacked. Despite being stipulated in their leasing contracts, Chinese investors did not honor their obligation to rehabilitate the plots. Thus, even after the Chinese investors abandoned the banana plantations, many local land owners nonetheless kept on renting out their land for banana cultivation. This time they leased their land to other local farmers who struggled with access to land— particularly those from the minority Akha ethnicity (e.g., in Phaka village)—receiving only half the rental price originally arranged with Chinese investors. As Sikor and Pham (2005) showed for a Vietnamese upland village, this presents another strong example of how previously subsistence-based land users become “woven into a commodity web,” and, in our case, how even the disadvantaged benefit from these new economic opportunities, though less so than those already endowed with more land.

Eventually, however, banana prices dropped by $5 0 \%$ , driving local farmers to transform the banana fields into sugarcane plantations in late 2017, which was easier than converting them back to paddy fields. The output of these new sugarcane plantations was either sold to sugarcane factories in Sing district, also owned by private Chinese investors, or exported directly to China as raw materials. This illustrates the importance of path dependencies in land use change (Atkinson and Oleson, 1996; Chavez and Perz, 2013), as there was virtually no way of undoing the commercialization of agriculture once the soils were degraded by monocultures. In less than two decades, the abandonment of shifting cultivation in favor of commercial rubber plantations in the uplands, and the abandonment of irrigated paddy rice farming in favor of commercial banana or sugarcane plantations (or just the commercialization of agricultural land) resulted in a complete change in the livelihood practices of many farmers in our case-study landscape. These dynamics are not unique to Luang Namtha Province: similar levels of land use change have been observed on the Xieng Khouang plateau in Northern Laos (Burra et al., 2021), following the same general trend observed in northern Southeast Asia (Rao et al., 2021). Furthermore, the evidence from our results, based on a small case study, contributes to the understanding of changing drivers of rapid tropical forest loss—from the expansion of agricultural land previously driven by subsistencebased agriculture to the expansion driven by international demands for agricultural commodities and associated supply chains. The abovementioned transformation of the expansion drivers is increasingly the case in the Amazon and elsewhere in South-East Asia (Pendrill et al., 2022).

# 4.2. A participatory mapping approach to understand land use transitions at the forest frontier: Suitability, limitations, and outlook

While our participatory land use mapping approach has allowed us to illuminate some of the most important factors driving land use transitions in our case study landscape, its use in this context has also helped reveal several challenges of application. First, this approach enabled us to meet one key requirement of land system science research, namely, that of engaging with a holistic understanding of landscape dynamics as socio-ecological systems (Verburg et al., 2015). The approach also enabled us to engage in co-production of knowledge (which is different from co-designing the study) with local stakeholders, which is a key precondition for investigation of complex telecoupled problems in sustainable development research (Zaehringer et al., 2019). Finally, the approach enabled us to produce a robust case study, answering recent calls for studies that help to generalize land system knowledge (Magliocca et al., 2018).

In terms of challenges, one major challenge concerned data collection, in particular regarding the field walks. This step turned out to be very time-consuming, even when using motorbikes, as it took place on steep terrain in remote areas. A related challenge is the large amount of data that this approach yields, which requires careful handling and processing before being analyzed and interpreted. Another challenge was that of obtaining information on shifting cultivation activities, given the controversy surrounding this land system based on recent policies aimed at its eradication, especially in or near protected areas.

In future research endeavors aimed at exploring rapid land use change in forest frontier contexts, at least two innovations could be implemented. First, while we have shown how utilization of forest cover change products such as the Global Forest Change data (Hansen et al., 2013) can support use of VHR imagery and help triangulate findings from participatory mapping exercises, recent advancements can provide additional support. One such advancement is the Tropical Moist Forest Cover Change dataset published recently, which temporally extends this information back to 1990 (Vancutsem et al., 2021). A second innovation that could be exploited to monitor and map land use in remote and rugged terrain is that of unmanned aerial vehicles such as drones (Paneque-Gálvez et al., 2014; Zhang et al., 2016). These could help to increase our understanding of areas were traditional satellite imagery struggles, such as shaded areas. While use of drones can more easily capture current land use, it could also support investigation of rapid land use change processes in a participatory mapping setting. For example, it would be possible to discuss drone images and videos with farmers, saving time for field walks in challenging terrain.

# 5. Conclusion

Our study has shown the advantages of combining a participatory approach with VHR satellite imagery, enabling mapping of continuous land use change in very dynamic forest frontier landscapes. The participatory approach also enabled us to link jointly produced complex, timedense spatial information to land use trajectories, which appear to be influenced by key ongoing trends and discrete events. This in turn has enabled us to contribute to current debates on land use intensification at the forest frontier. Concretely, our detailed account of specific land uses, such as shifting cultivation, paddy, rubber, and banana, has provided new insights into current deforestation dynamics through rubber, and into the degradation of traditional subsistence land use systems, such as irrigated paddy rice systems, based on establishment of input-intensive commercial monocultures. Our study is among the first to demonstrate in a spatially explicit manner that subsistence agriculture, in less than two decades, has disappeared almost completely due to the effect of diverse cash-crop production and agricultural commercialization initiatives linked to Chinese investments.

The land use dynamics we have revealed prompt several concerns about food security and environmental integrity at the forest frontier. First, given the drastic reduction in subsistence agriculture and the strong reliance of local households on commercial agriculture to meet their food needs, rural populations are increasingly at the mercy of price fluctuations for both cash crops and food. Additionally, the loss of biodiversity-rich forests might have also affected food security through decreased availability of edible wild plants and animals, which would warrant further research though. Second, the current context of increasing foreign land acquisitions and leasing schemes, either promoted by the granting of concessions by national governments, or by direct contracts between investors and local producers, has the potential to lock rural producers into path dependencies, undermining their ability to handle future price fluctuations as well as environmental and climate change. And third, the rebound effects emerging as a result of increasing financial capital for farmers in the area highlight the possible impacts of unexpected consequences of “successful” agricultural commercialization of local livelihoods and landscapes, with likely implications for biodiversity and the provision of ecosystem services at the local and global scale. These challenges are further exacerbated by the fact that the case study landscape is very vulnerable to disasters, such as weather events like typhoons, flooding and droughts, rodent and pest attacks, and animal disease epidemics. The insights generated through this study could serve to inform land planning exercises to help address some of these ongoing pressures, and to increase the resilience of local populations and landscapes to future economic and environmental uncertainties.

