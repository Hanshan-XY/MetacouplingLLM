# Telecoupling cropland soil erosion with distant drivers within China

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:10:32.073502+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Wang et al. - 2021 - Telecoupling cropland soil erosion with distant drivers within China.pdf
- Year: unknown
- DOI: 10.1016/j.jenvman.2021.112395
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study investigates how soil erosion on Chinese cropland is linked to economic activities occurring in other provinces, using a telecoupling framework. The geographic scope is all 31 provincial-level regions in mainland China, examined within the national agri-food and industrial economic system.

Biophysical soil loss on cropland for 2015 is estimated at 30 m resolution using the Revised Universal Soil Loss Equation (RUSLE), with rainfall erosivity, soil erodibility, topography, land use, and crop-management and conservation factors from national geospatial datasets. These provincial erosion totals are then embedded as an environmental satellite account into a 2015 multiregional input-output (MRIO) table for China, disaggregated to separate crop agriculture from other primary sectors. The environmentally extended MRIO model traces how final demand in different provinces and sectors drives soil erosion via direct and indirect supply chains, and further decomposes impacts by supply chain tier and final demand category (households, government, investment, exports).

Cropland erosion in 2015 is about 1.94 billion tonnes, heavily concentrated in southwest China and several northeastern and central provinces. About 18-20 percent of domestically driven erosion is caused by consumption in other Chinese provinces, and an additional roughly 9 percent is linked to exports. Southwestern, northeastern, and some central provinces are major net suppliers of erosion embodied in agricultural products, while economically advanced coastal provinces are net beneficiaries that outsource erosion through imports of food and other agricultural inputs. Agriculture, food processing, and construction are the main sectoral drivers. Non-agricultural sectors together account for about two thirds of total and telecoupled cropland erosion. Shorter supply chains generate most of the absolute erosion, but the share driven by distant consumption and by exports and capital formation rises along longer supply chain tiers; household demand dominates in short chains.

The paper is explicitly framed as a telecoupling study within China, showing strong intracountry metacoupling: distant economic demand systematically shapes local soil erosion patterns and challenges place-based soil conservation policies.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong intracoupling of cropland, economy, and soil erosion within Chinese provinces
- Strong pericoupling across neighboring and regional Chinese provinces via agricultural trade
- Explicit domestic telecoupling linking distant provincial demand to local cropland erosion

### Intracoupling
#### Systems
- Provincial cropland ecosystems and soils
- Provincial economies and agricultural production
- Local households and industries consuming local farm products
#### Flows
- Soil loss from cropland within provinces
- Local agricultural product flows for intra provincial consumption
- Capital and labor invested in local agriculture
#### Agents
- Local farmers and agricultural producers
- Provincial governments and soil conservation agencies
- Local food processing enterprises
#### Causes
- Intensive cultivation and cropland expansion within provinces
- Topography, rainfall erosivity, and soil erodibility locally
- Local dietary demand and nearby industrial use of crops
#### Effects
- Onsite soil degradation and nutrient loss
- Reduced land productivity and food security risks
- Need for local soil and water conservation policies

### Pericoupling
#### Systems
- Adjacent or nearby Chinese provinces trading agricultural goods
- Regional supply chains connecting neighboring provinces
- Shared river basins with cross boundary erosion impacts
#### Flows
- Inter provincial trade of relatively short distance farm products
- Regional flows of processed food and construction inputs
- Embedded soil erosion transferred across neighboring provinces
#### Agents
- Regional traders and logistics companies
- Neighboring provincial governments coordinating agriculture
- Regional food processing and construction sectors
#### Causes
- Regional specialization in certain crops and products
- Infrastructure and transport enabling short range trade
- Demand mismatches between nearby production and consumption
#### Effects
- Spatial mismatch between erosion hotspots and beneficiaries
- Regional disparity in soil conservation responsibilities
- Need for inter provincial compensation and cooperation

### Telecoupling
#### Systems
- Erosion prone agricultural provinces in southwest, northeast, and central China
- Economically developed coastal and urban provinces importing food
- National scale supply chain network captured by MRIO model
#### Flows
- Virtual soil erosion embodied in agricultural and food trade
- Cross provincial flows driven by distant household consumption
- Cross provincial flows driven by construction, capital formation, and exports
#### Agents
- Distant urban consumers and exporting industries
- Agriculture, food processing, and construction sectors nationwide
- National policy makers designing soil and trade regulations
#### Causes
- Distant demand for agricultural products and processed foods
- Economic development shifting production to erosion intensive regions
- Supply chain lengthening through multi tier industrial processing
#### Effects
- Erosion costs shifted from rich importing provinces to poorer producers
- Around one fifth of cropland erosion linked to distant domestic demand
- Need for national scale, consumption based soil conservation policies

### Cross-Coupling Interactions
- Shorter supply chains create large absolute telecoupled erosion but lower telecoupled share
- Longer supply chains raise telecoupled share, especially via exports and capital formation
- Nonagricultural sectors amplify telecoupled erosion beyond local farming decisions

### Research Gaps or Limitations
- Soil erosion estimates rely on RUSLE simulations instead of dense field monitoring
- Agriculture and related sectors coarsely disaggregated in MRIO due to data limits
- Study excludes erosion from non cropland and assumes zero erosion in other sectors

### Search Keywords
- telecoupling cropland soil erosion China MRIO
- virtual soil erosion interprovincial trade
- agriculture food processing construction erosion drivers

### Extraction Confidence
high
