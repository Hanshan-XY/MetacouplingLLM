# Theoretical framework and scientific problems of smart city man-land system_ æ™ºæ…§åŸŽå¸‚äººåœ°ç³»ç»

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:21:25.233490+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Zhen et al. - 2023 - Theoretical framework and scientific problems of smart city man-land system_ æ™ºæ…§åŸŽå¸‚äººåœ°ç³»ç».pdf
- Year: unknown
- DOI: 10.31497/zrzyxb.20230901
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Conceptual\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This conceptual paper develops a theoretical framework for understanding the human-land system under smart city development, with a primary focus on China but implications for urban systems globally. It argues that rapid advances in AI, IoT, big data, and cloud computing are reshaping how people, technology, and urban environments interact, so traditional human-environment theories must be updated for the smart city era.

The authors synthesize several strands of theory. First, they use the idea of flow space, emphasizing that flows of people, goods, information, capital, and technology now structure urban relations more than static spatial form. Second, they extend the classic human-land system into a triadic people-technology-space coupling, where digital infrastructures and platforms mediate and transform human activities and their links to physical environments. Third, they introduce resilience and complex adaptive systems thinking to conceptualize how smart cities respond to chronic stresses and sudden shocks.

They propose a conceptual model of a smart city human-land system that highlights virtual-physical integration, multi-scalar interactions from households to global networks, and changing spatial and temporal scales of coupling. Key research directions include: building multi-source databases for smart city human-land analysis; identifying critical elements and their spatio-temporal coupling; explaining drivers and mechanisms at different scales (household, community, functional area, city, region, global); developing simulation and evaluation models using system dynamics, network analysis, and multi-agent approaches; and designing regulation and optimization strategies for infrastructure, land use, and governance.

The paper explicitly engages with telecoupling and metacoupling ideas through its emphasis on cross-scale, long-distance, and virtual couplings (e.g., remote interactions, online activities, global economic and information networks) that shape local urban human-land relations. While not using the metacoupling terminology systematically, it clearly addresses flows and feedbacks between local, regional, and global systems and between physical and digital domains, making it relevant to telecoupling-oriented research on smart, data-driven urbanization.

## Structured Metacoupling Extraction

### Coupling Classification
- Conceptual paper on smart city man-land systems with explicit intra, peri, and telecoupling content.

### Intracoupling
#### Systems
- Human activities, infrastructure, environment within a single smart city.
- Sub-city units: households, communities, functional zones, whole city.
- Urban subsystems: ecological, economic, social, land, technology, governance.
#### Flows
- Internal flows of people, goods, information, capital, energy, ecosystems.
- Daily mobility and online-offline activity flows inside the city.
- Data streams from sensors, platforms, and smart services.
#### Agents
- Residents and households as activity subjects and data sources.
- Municipal government, planners, smart city administrators.
- Firms, platform operators, infrastructure providers.
#### Causes
- Deployment of AI, IoT, big data, cloud computing in urban governance.
- Policy push for new infrastructure and smart urbanization.
- Need to enhance resilience, sustainability, and service quality.
#### Effects
- Restructuring of urban spatial organization and functional layouts.
- Changed behavior patterns, time use, and space-time coupling.
- Improved or stressed urban resilience, equity, and resource efficiency.

### Pericoupling
#### Systems
- Smart city and its surrounding metropolitan or regional system.
- Interacting communities and functional zones at the urban fringe.
- Regional networks of smart parks, corridors, and ecological spaces.
#### Flows
- Commuting, logistics, and service flows across city boundaries.
- Regional flows of resources, energy, ecosystem services, labor.
- Data, governance directives, and emergency responses across jurisdictions.
#### Agents
- Neighboring local governments and regional planning bodies.
- Transport and utility agencies operating across borders.
- Regional industries, logistics firms, and commuters.
#### Causes
- Regional integration, coordinated new-type urbanization policies.
- Infrastructure connectivity and shared ecological constraints.
- Smart platforms enabling cross-boundary coordination and monitoring.
#### Effects
- Reconfigured regional urban networks and hierarchy.
- Cross-boundary risk propagation and resilience dependencies.
- Spatial reallocation of industries, housing, and public services.

### Telecoupling
#### Systems
- Chinese smart cities and distant national or global city networks.
- Global production, innovation, and digital service systems.
- Remote ecological and resource-supplying regions.
#### Flows
- Telecoupled economic, trade, capital, and technology flows.
- Long-distance information, knowledge, and governance flows.
- Remote sensing, real-time data, and virtual interactions.
#### Agents
- National government and global institutions shaping smart city agendas.
- Multinational technology and platform companies.
- Translocal migrants, tourists, and digital workers.
#### Causes
- Globalization, digitization, and smart city diffusion worldwide.
- Teleconnected markets for capital, technology, and data services.
- Remote monitoring, control, and online activities reducing distance frictions.
#### Effects
- Telecoupled impacts on local land use, environment, and resilience.
- Dependence on distant infrastructures and data platforms.
- Emerging digital divides and uneven benefits across regions.

### Cross-Coupling Interactions
- Framework links intra-city dynamics with regional coupling and global telecoupling of flows and networks.
- Near and distant couplings co-determine resilience, risks, and sustainability of smart city man-land systems.
- Virtual-physical, local-remote interactions mediated by technology blur boundaries of man-land systems.

### Research Gaps or Limitations
- Lack of systematic empirical studies on complex urban spatio-temporal coupling processes under smart technologies.
- Need for multi-scale models integrating local, regional, and telecoupled man-land interactions.
- Insufficient attention to social equity, digital divide, and participatory governance in smart city coupling.

### Search Keywords
- smart city man-land system coupling resilience telecoupling
- space of flows people-technology-space virtual-physical interactions
- multi-scale spatiotemporal coupling digital twin city CIM

### Extraction Confidence
high
