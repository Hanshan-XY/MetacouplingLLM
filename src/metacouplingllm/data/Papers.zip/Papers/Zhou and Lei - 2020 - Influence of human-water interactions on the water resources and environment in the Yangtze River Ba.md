# Influence of human-water interactions on the water resources and environment in the Yangtze River Ba

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:21:52.957289+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Zhou and Lei - 2020 - Influence of human-water interactions on the water resources and environment in the Yangtze River Ba.pdf
- Year: unknown
- DOI: 10.1016/j.jclepro.2020.121783
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines how intertwined economic activities and water systems shape water resources and water quality in Chinas Yangtze River Basin, using a multiplex network approach. The basin-scale analysis covers 15 provinces from the upper reaches to the coastal delta, linking interprovincial trade, virtual water flows, real river discharge, and pollutant transport.

The authors construct human-water multiplex networks (HWMNs) with several layers: economic trade, virtual water use, virtual water environment capacity (gray water), and physical flows of water and pollutants along the river. They build provincial input-output extensions using national IO tables for 2014, combined with provincial water-use, pollution, and hydrological data, and a water-quality-based capacity model. Network flow metrics (including virtual imports/exports and control ratios) and topological indices (weighted degree, PageRank, and community structure) are calculated.

Results show that the Yangtze Basin accounts for about half of Chinas water use and water pollution. Economically advanced delta provinces (Shanghai, Jiangsu, Zhejiang) import substantial virtual water and especially virtual water environment capacity, while exporting high-value goods. Jiangsu and Shanghai emerge as key hubs: Jiangsu is the largest virtual importer and exporter of water resources and environmental capacity, and Shanghai exercises strong network control over water resources used in distant provinces such as Sichuan. This asymmetric dependence is interpreted as a telecoupling of water resources and water environment capacities between upstream and downstream regions.

Provinces are classified as net beneficiaries or net donors of water resources and environmental capacity through trade. Some midstream provinces appear environmentally disadvantaged in trade yet still have relatively abundant local water and capacity, highlighting the need to consider both trade and natural endowments. Community detection shows that virtual gray-water networks largely align with the rivers upstream-midstream-downstream geography, linking social and hydrological subsystems.

The paper explicitly engages telecoupling ideas, using multiplex networks to reveal long-distance economic-ecological linkages that conventional single-layer or local analyses would miss.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong intracoupling within Yangtze River Basin provinces via economic-water-pollution links.
- Pericoupling between Yangtze Basin and other Chinese provinces through virtual water and pollution trade.
- Telecoupling where downstream economic hubs control upstream water and environmental capacities.

### Intracoupling
#### Systems
- Yangtze River Basin human-water multiplex network of 15 provinces.
- Economic, water resource, and water environment subsystems as network layers.
#### Flows
- Virtual water resource and environmental capacity exchanges among basin provinces.
- Real river water and pollutant transport from upstream to downstream.
- Interprovincial product trade driving embedded water and pollution flows.
#### Agents
- Provincial governments and water management authorities.
- Industrial and agricultural sectors within each province.
- Environmental regulators monitoring water quality and discharge.
#### Causes
- Rapid regional economic growth and uneven industrial structures.
- Local water scarcity and limited pollution assimilation capacity.
- Policy and market-driven industrial production and trade patterns.
#### Effects
- Delta provinces gain economic and virtual water benefits but face local water stress.
- Upstream pollutant discharges reduce downstream environmental capacity.
- Indirect pollution transfer creates hidden micro environmental impacts.

### Pericoupling
#### Systems
- Yangtze Basin linked with other Chinese river basins via trade.
- Basin connected to rest of China through national input-output networks.
#### Flows
- Virtual water imports and exports between basin and other provinces.
- Virtual water environment capacity exchanged with rest of China.
#### Agents
- National economic planners and water authorities.
- Interprovincial trading firms and supply chains.
#### Causes
- National market integration and interprovincial trade demand.
- Regional comparative advantages in industry and water endowment.
#### Effects
- Yangtze Basin is net virtual water and capacity importer within China.
- China overall exports net virtual water and pollution capacity.

### Telecoupling
#### Systems
- Downstream metropolitan provinces and distant upstream provinces.
- Chinese economy linked to foreign countries via trade-embedded water.
#### Flows
- Virtual water and environmental capacity from Sichuan to Shanghai and Henan.
- Virtual water resources and capacity in exports and imports with other countries.
#### Agents
- Export-oriented industries in coastal provinces.
- Upstream resource and pollution-intensive producers.
- International trade partners consuming embedded water goods.
#### Causes
- Long-distance supply chains connecting upstream production to coastal demand.
- Global trade driving externalization of water use and pollution.
- Economic centrality of Shanghai and Henan in domestic networks.
#### Effects
- Downstream cities exert strong control over upstream water resources.
- Telecoupled environmental burdens distributed far from consumption sites.
- Telecoupling complicates equitable basin-scale water governance.

### Cross-Coupling Interactions
- Economic trade layer interacts with physical river layer, altering effective water and pollution burdens.
- Virtual pollution trade plus real downstream transport magnify cumulative impacts on delta provinces.
- Industrial relocation within basin can worsen downstream water quality despite local emission reductions.

### Research Gaps or Limitations
- Analysis limited to provincial and annual resolution; finer spatial-temporal dynamics missing.
- Data constraints prevent richer multisource and multiscale representation of multiplex networks.
- Multiplex topology algorithms adapted from single-layer networks; dedicated methods still needed.

### Search Keywords
- Yangtze River Basin human-water multiplex networks
- virtual water and gray virtual water telecoupling
- interprovincial water environment capacity trade China

### Extraction Confidence
high
