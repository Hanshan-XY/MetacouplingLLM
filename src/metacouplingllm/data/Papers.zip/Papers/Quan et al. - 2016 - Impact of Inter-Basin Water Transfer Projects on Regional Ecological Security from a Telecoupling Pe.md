Article

# Impact of Inter-Basin Water Transfer Projects on Regional Ecological Security from a Telecoupling Perspective

Yuan Quan 1,2, Chenxing Wang 2, Yan Yan 2, Gang Wu 2,* and Hongxun Zhang 1

1 College of Resources and Environment, University of Chinese Academy of Sciences, Beijing 100049, China; quanyuan13b@mails.ucas.ac.cn (Y.Q.); hxzhang@ucas.ac.cn (H.Z.)   
2 State Key Laboratory of Urban and Regional Ecology, Research Center for Eco-Environmental Sciences, Chinese Academy of Sciences, Beijing 100085, China; wangchenxing10@mails.ucas.ac.cn (C.W.); yany@rcees.ac.cn (Y.Y.)   
￥ Correspondence: wug@rcees.ac.cn; Tel.: +86-010-62849190

Academic Editor: Marc A. Rosen

Received: 1 December 2015; Accepted: 4 February 2016; Published: 6 February 2016

Abstract: Inter-basin water transfer projects (IBWTPs) offer one of the most important means to solve the mismatch between supply and demand of regional water resources. IBWTPs have impacts on the complex ecosystems of the areas from which water is diverted and to which water is received. These impacts increase damage or risk to regional ecological security and human wellbeing. However, current methods make it difficult to achieve comprehensive analysis of the impacts of whole ecosystems, because of the long distance between ecosystems and the inconsistency of impact events. In this study, a model was proposed for the analysis of the impacts of IBWTPs on regional ecological security. It is based on the telecoupling framework, and the Driver-Pressure-State-Impact-Response (DPSIR) model was used to improve the analysis procedure within the telecoupling framework. The Middle Line of the South-to-North Water Diversion Project was selected as a case study to illustrate the specific analysis procedure. We realized that information sharing is a key issue in the management of regional security, and that the ecological water requirement, in the form of a single index, could be used to quantitatively assess the impacts on ecological security from IBWTPs.

Keywords: ecological impact assessment; ecological water requirement; water diversion; the Middle Line of the South-to-North Water Diversion

# 1. Introduction

Inter-basin water transfer projects (IBWTPs) offer an effective solution to the uneven distribution of water resources [1]. IBWTPs play a role not only in alleviation of water shortages (e.g., for industrial, agricultural, and domestic water difficulties), but also in supporting regional socio-economic development, and resident quality of life [2–4]. Governments encourage construction of IBWTPs because they have huge economic and social benefits [5]. However, IBWTPs affect land use, the hydrological environment, the surrounding landscape, and the vegetation of water diversion areas, water receiving areas, and the areas along the water transfer route. These changes lead to changes in ecosystem evolution and ecological security [6]. For example, the Aral Sea has been shrinking since the 1960s, initiated by excessive Soviet irrigation projects, and related changes have also affected the local climate and resulted in increased occurrence and worsening of storms, extreme environmental pollution, and public health problems [7,8]. The Middle Route of the South-to-North Water Diversion Project of China has resulted in changes to land use across the Danjiangkou Reservoir catchment area, intended to reduce urban and agricultural run-off [9]. The man-made water diversion project was

conducted in the Tarim River and Hei River Basin in order to prevent the vegetation degradation and to reach the goal of ecological restoration [10–12].

Currently, studies of the influence of IBWTPs on regional ecological security have been focused on direct impacts on different areas of the ecosystem, through environmental impact assessment, ecological impact assessment, and index system methods [13]. The construction and operation of projects involve temporary or permanent occupation of a large amount of farmland, grassland, forest, and other ecosystems. This may cause changes in regional land use patterns, as well as development and loss of ecosystem services. Moreover, engineering and construction activities change ecosystem types, destroy vegetation, and may exacerbate regional water and soil erosion. Meanwhile, construction and operation may also destroy local biological habitat, affect biological activities, and potentially alter regional biodiversity. IBWTPs are closely related to conditions in aquatic environments and ecosystems, and their construction and operation unavoidably influence the water environment and aquatic ecosystem [14–16]. According to the methods and measures of environmental impact assessment and ecological impact assessment, such assessment of IBWTPs includes analysis and prediction of ecosystem impact for each process and section of an IBWTP [17,18]. The advantages of these methods are that the direct and short-term impacts on the ecosystems caused by project construction and operation can easily be recognized, and that predictions of the successional tendency of the ecosystems could reasonably be addressed. However, such methods have not paid enough attention to the potential impacts on other relevant regions, from project construction and operation.

That integrated analysis and assessment of the impacts from IBWTPs on the security of all relevant ecosystems would be helpful for water resources allocation and utilization, ecosystem protection, and construction and management of water diversion projects. IBWTPs have the characteristic of long distance between water diversion areas and water receiving areas, as well as wide areas of impact. This has made effective analysis and assessment very difficult. Telecoupling analysis is intended to study environmental and socioeconomic interactions among coupled ecosystems over long distances [19]. It has been used in fields involving global ecological issues (e.g., land transactions and invasive species) [20].

In this paper, a model was put forward for analysis of the impacts of IBWTPs on regional ecological security, based on a telecoupling framework. The Driver-Pressure-State-Impact-Response (DPSIR) model was used to improve the analysis within the telecoupling framework. It includes analysis of the sending systems, receiving systems, and spillover systems. Taking the Middle Line of the South-to-North Water Diversion Project in China as a study case, this paper illustrates the specific analysis procedure and discusses the information sharing issue of IBWTPs. Moreover, a quantitative method is proposed by which to assess the impacts of IBWTPs, which uses ecological water requirement in the form of a single index.

# 2. Methods and Materials

# 2.1. Telecoupling

The telecoupling framework includes five major and interrelated components: coupled human-natural ecosystems, agents, flows, causes, and effects. The framework of telecoupling is that causes produce a telecoupling between at least two coupled human and natural systems, which generate effects that are manifested in one or more coupled human and natural systems [21]. Moreover, telecoupling is conducted by agents that facilitate or hinder flows of material, energy, and information between systems. The main advantages of this approach reside in combining various aspects of the temporal and spatial scales involved.

IBWTPs are characterized by involvement of diversion areas, water receiving areas, and areas along the water transfer project route. Considering spatial scale, the diversion areas are far from the water receiving areas, and the resettlement of people displaced from IBWTP areas occupy additional land resources. Moreover, the impacts of projects in the different regions are also different. The primary

concern of water diversion areas is ecosystem health after water diversion. In water receiving areas the focus is on impacts from external water resources. Considering temporal scale, impacts on ecosystems include the short-term and long-term effects from construction and operation of IBWTPs. Above all, telecoupling could be a feasible tool for analyzing impacts of IBWTPs on regional ecological security.

# 2.2. Analysis Model of Impacts of IBWTPs on Regional Ecological Security

The analysis model for impacts of IBWTPs on regional ecological security, based on telecoupling, is intended to be able to consider fully the combined short-term and long-term effects on diversion ecosystems, water receiving ecosystems, ecosystems along the water transfer route, and on other ecosystems, from construction and operation of IBWTPs. The model takes the telecoupling analysis framework as its overall technical path. It maintains the sending systems, receiving systems, and spillover systems, as well as the material flows, energy flows, and information flows that link the complex ecosystems.

The improvement provided by this model is that the DPSIR model is applied to the sending systems, receiving systems, and spillover systems. The DPSIR model has been widely used in ecological security assessment. Wang put forward a DPSIR framework for ecological security of lake ecosystems [22]. Glaesner adopted DPSIR to construct a European soil framework directive to increase the effectiveness of conserving soil functions in the European Union [23]. The advantages of using the DPSIR model in ecology, is that it can reflect all the factors of study objects and their links. Thus, an index based on DPSIR could achieve a reasonable set of impact factor categories.

In this analysis model (see Figure 1), the agents of the systems, which could be governments, enterprises, the public, etc., adopt behavior that triggers ecosystem changes and affects ecological security of local and other regions. The agents also take action, such as water pollution control, ecological restoration, and resettlement action plans, to reply to the threats to ecosystems and to protect ecosystems. Different systems have different causes to implement and different reactions to IBWTPs. The water resources of the sending system are typically abundant and there are floods sometimes harm those regional ecosystems. Meanwhile, the receiving systems may be suffering drought. The causes are drivers and pressures that lead agents to take action regarding IBWTPs. The effects of systems are states and impacts of ecosystems. The interactions between systems and within systems are manifested by material flows, information flows, and energy flows.

![](images/19df49ac7373b7869fef2788c0cd64ed366301ad3bb065ad9355f8ba6e077bc1.jpg)  
Figure 1. Conceptual model of ecological security analysis and assessment of inter-basin water transfer projects (IBWTPs).

# 2.3. Study Areas

The Middle Line of the South-to-North Water Diversion Project starts from the Danjiangkou Reservoir. The length of the water transfer project, including open channels and tube culverts, is $1 4 3 1 . 9 5 \mathrm { k m }$ (see Figure 2). The project could divert up to 9.5 billion $\mathbf { m } ^ { 3 }$ of water from the middle basin of the Danjiangkou Reservoir to areas in North China (including the four municipalities of Beijing, Tianjin, Hebei, and Henan). The construction of project began in 2005 and water diversion started in December 2014. The ecological protection goal of the Middle Line of the South-to-North Water Diversion Project is to achieve inter-basin water transfer and optimal allocation of water resources, without lowering the Danjiangkou Reservoir or impacting the ecological environment in the Han River. At the same time, the projects will ease water supply problems in Beijing, Tianjin, and other parts of North China. The aim is to reduce water supply conflicts, and to provide reliable support for sustainable development and the creation of an ecologically sustainable civilization. The main issues to be resolved are the ecological conflicts related to urban crowding and agricultural runoff water, the grim situation of over-exploitation of groundwater and surface water, and the trend of continued deterioration of the ecological environment [24].

![](images/f3f1f452f3979a789e360948a0d070c3e675a085c6d263595a23342d02023bca.jpg)  
Figure 2. Study area.

# 3. Case Study of the Middle Line of the South-to-North Water Diversion Project

Taking the Middle Line of the South-to-North Water Diversion Project as an illustration case, the telecoupling-based analysis model of impacts of IBWTPs on regional ecological security incorporates complex ecosystems, agents, flows, causes, and effects. The complex ecosystems include sending systems, receiving systems, and spillover systems. In this case, the diversion ecosystem is the sending system. The water receiving ecosystem and the ecosystems along the water transfer route are receiving systems. The spillover systems include ecosystems in resettlement areas, downstream of the water diversion (see Figure 3).

![](images/32d03deee8a44cc4538413d39d1cd0b323d0096baa77985c531b09c2ef55398b.jpg)  
Figure 3. Analysis framework of the South-to-North Water Diversion Project.

# 3.1. Complex Ecosystems

# 3.1.1. Sending Systems

The sending system of the Middle Line of the South-to-North Water Diversion Project is a complex ecosystem of water diversion areas. It is located in Hubei Province and Henan Province (in terms of administrative boundaries), and the most important part is the Danjiangkou Reservoir. Based on the analysis model of impacts of IBWTPs on regional ecological security, the agents of the sending system are local governments and construction units. The drivers and pressures of the sending systems are abundant water resources, economic benefits, and national administration. The behavior and responses of the sending systems are IBWTP construction projects, including the engineering required for dam heightening and strengthening, source-water diversion projects, water quality management, and water-source protection. The states and impacts consist of reducing the risk of flooding, drought, and threats to biodiversity [25,26].

# 3.1.2. Receiving Systems

The ecosystems of the water receiving areas and the ecosystems along the water transfer project route are the receiving systems of the Middle Line of the South-to-North Water Diversion Project. They are located in the cities of Beijing and Tianjin, and in the provinces of Hebei and Henan. Beijing and Tianjin are both nature-economic complex urban ecosystems and have the characteristics of low water resources and huge demand. These conditions result in ecological destruction and environmental pollution, overuse of regional groundwater, and serious water pollution problems. From the telecoupling framework, the agents of the water receiving ecosystems are local governments, construction units, enterprises, and residents. The causes of the water receiving ecosystems are water shortage and water pollution. The impacts of IBWTPs on ecological security include changes to the water resources endowment, risk of species invasion, and other interference effects on ecosystems. Meantime, the high cost of such projects brings new problems related to water price, which could lead to reasonable allocation of water resources. Such problems also influence environmental quality, which is one of the most important aspects of ecological security.

The complex ecosystems along the water transfer project route, located in Henan and Hebei Provinces, are also receiving systems within the telecoupling framework. There are three aspects of the influence on the ecosystems of Henan and Hebei Provinces from the Middle Line of the South-to-North Water Diversion Project. First, the construction and operation of the IBWTPS could lead to changes in water level or soil-water content, and salinity. These could cause the aquatic ecosystems and terrestrial ecosystems to deviate from their original equilibrium states, especially in the case of diversion routes using existing river and lakes. Then, the changes in land use and water resources could trigger changes in the structure of regional industry, in the layout of tourist resources, and in residential employment. Finally, the diversion projects are close to important eco-function areas and ecologically sensitive areas, which results in more intense disturbance due to human activity, based on their vulnerability and sensitivity.

# 3.1.3. Spillover Systems

The downstream and upstream ecosystems of the diversion areas and ecosystems in the resettlement area, are spillover systems of the IBWTPs.

As to the Middle Line of the South-to-North Water Diversion Project, the part downstream of the Han River is the supreme spillover system. The project causes reduction of water supply to the downstream areas; thus, relevant environmental problems will occur, such as deterioration of water quality, riverbed erosion, and environmental degradation along the river. For example, in the Han River, the low-flow level of the main channel was increased but the water level of the river was decreased. The geomorphology of the river will likely change to the form of a single, stable, deep, narrow river, due to intense bed erosion.

Upstream of the Han River (Shaanxi Province, China) is also a spillover system of the Middle Line of the South-to-North Water Diversion Project. The intensity of utilization of water resources in Shaanxi Province could affect water resources in the diversion area.

Another spillover system comprises ecosystems in the resettlement areas. A large number of the affected population migrated to these areas, and they occupied large areas of land on which to build their workplaces and living space. The behavior of the new residents will bring new pressures to the local ecosystem and environment.

# 3.2. Agents

The Construction and Management Bureau of the Middle Line of the South-to-North Water Diversion Project, is the central agent for the projects. This bureau has charge of all engineering construction and environmental protection of the project. On one hand, it acts as the brain of the project; all information associated with the project is collected and analyzed by the bureau, to provide

support for decision making on aspects of the project. On the other hand, it is also the arms and legs of the project, and its officers take action to protect the ecosystem and to control pollution. The other governments in the diversion areas, receiving areas, and along the water transfer project route, are also agents of the Middle Line of the South-to-North Water Diversion Project. They are responsible for allocating the water for diversion to agriculture and industry needed to achieve the project goals of ecological security. Other agents, such as enterprises, research institutes, and residents have different responsibilities for achieving ecological security during construction and operation of the project.

# 3.3. Flows

The main material flow is water from diversion areas to receiving areas. However, considering ecological security, the material flows include water, aquatic organisms, and important species. The information flows include water transfer information and ecological information. The ecological information covers such as land use and ecosystems services. There are a variety of indices to indicate the ecological information related to IBWTPs, and these indices involve items such as ecological water requirement, water supply, water usage, and rainfall. Economic and social information, such as water pricing and industrial structure, is another information flow. The interactions between systems are reflected by flows between them.

# 3.4. Causes

Uneven distribution of water resources is the main natural reason for implementation of the IBWTPs. We analyzed the total water resources and per capital water resources of Hubei, Henan, Hebei, Tianjin, and Beijing from 2004 to 2013, using data from the National Bureau of Statistics of the People’s Republic of China. The average total water resource of Hubei Province was up to 90.05 billion $\mathbf { m } ^ { 3 }$ and the average per capita water resource was $1 5 6 5 . 2 2 \mathrm { m } ^ { 3 }$ . In stark contrast, Beijing’s annual capacity of 2.61 billion $\mathbf { m } ^ { 3 }$ of water resource (per capita resource of $1 4 8 . 6 8 \mathrm { m } ^ { 3 }$ /person), did not reach $1 0 \%$ of that in Hubei Province (see Figure 4). Moreover, the rainfall is abundant in the southern part of the water diversion area, and the risk of flooding is high, while conditions are opposite in the northern water receiving areas.

![](images/9ee5fb1cc490ef4c63b573508d0f339aa4a9127ddf3b58236492c11a0a28c17c.jpg)

![](images/fa387041f8f3c8942c642e582b878b183b15f133fb41ae4b8da327082ab7ea5e.jpg)  
Figure 4. Comparison of water resources of project areas.

The sustainability of the region is another key cause of IBWTPs construction. The implementation of the IBWTPs is the key to realizing sustainable regional development. Aquatic environment problems have become a primary factor limiting sustainable development of arid and semi-arid regions. The local shortage of water resources has seriously restricted industrial growth, and even endangered lives of residents in water receiving areas. What was worse is that this situation led to intense exploitation and utilization of existing groundwater and rapidly worsening water quality. A downward spiral

of worsening conditions was created. The operation of the IBWTPS would effectively alleviate the mismatch between supply and demand for water, and would provide residents with better water quality and water supply. As an additional benefit, it would provide new employment opportunities to residents in some parts of all the systems.

The reduction of ecological damage is another cause of IBWTPs construction. The shared problems affecting the ecosystems of the water receiving areas are excessive groundwater extraction and pollution of the aquatic environment. For instance, the size of the underground, funnel-shaped water tables near wells in North China (funnels form when well extraction exceeds recharge in an aquifer) are 12 times the size of those in the area of Beijing. Some of the water provided by the Middle Line of the South-to-North Water Diversion Project will be used to recharge groundwater aquifers to stop expansion of the underground funnels.

# 3.5. Effects

The IBWTPSs have direct and indirect effects on complex ecosystems. The direct effects include reduction of flood risks and improvement in the utilization efficiency of water resources in the diversion area. For the water receiving area, the construction and operation of water diversion projects is expected to lead to increased water supply for industry, agriculture, homes, and ecology. However, the risk of biological invasion of water receiving ecosystems may increase. The indirect effects include increase in soil moisture from water diversion. In addition, the amount of water downstream of the water source of the project will decrease after its construction, so that, in this area, aquatic organisms will be affected and water pollution could increase.

# 4. Discussion

# 4.1. Information Flows of Ecological Security

The ecosystems of the water diversion and water receiving areas are distant and the project has different impacts on different ecosystems [27,28]. Thus, information flows between ecosystems and within ecosystems is a key aspect of analysis and assessment within a telecoupling framework. Moreover, different agents, such as governments, enterprises, and residents, take charge of making decisions about construction and environmental protection. Inconsistencies in policies, construction, and ecological protection measures will result if the information flows do not reach every agent. For example, those in Shaanxi Province might increase the use of water from the Han River, so that the amount of water in the Danjiangkou Reservoir decreased. If the water diversion project continued operating at nominal rates, the worst case would be that the region downstream of the Han River would end up with too little water, which could result in greater environmental stress there. The cross-regional linkage mechanism, by which agents of all ecosystems would share engineering and ecological information simultaneously, is the key to ecological security.

# 4.2. Assessment Method for Impacts of Ecological Security of IBWTPs

The telecoupling provided the framework for analyzing impacts on the ecological security of the IBWTPs. The Middle Line of the South-to-North Water Diversion Project was taken as a case to illustrate the specific application of the analysis model, for impacts of IBWTPs on regional ecological security. In this case, the ecological water requirement (EWR) was chosen as one index to quantitatively assess the impacts, based on the telecoupling framework.

The EWR, related with the level of health of an ecosystem, was a measurement tool for evaluating whether the ecological protection goals of complex ecosystems are achieved [29,30]. The studies about the EWRs of rivers in Virginia, America, which was calculated by the Tennant methods, show that $1 0 \%$ volume of runoff, namely the general minimal ecological water requirements, caused the ecosystem degradation [31].

The EWR was selected as an assessment index mainly based on the following reasons. The first reason was that there was a mature theoretical support and calculation method of the EWR of every ecosystem. Taking the Tennant methods as a case, which was a frequent calculation method for the EWR, the American researchers undertook a large amount of research to prove the relation between health level of ecosystems and the EWR. The second reason was that the accurate data was accessible for calculating the EWR and there was technical guidance of EWR, which was released by the Ministry of Water Resource of China, to support the assessment. The third reason was that relevant organizations could regulate and control the ecological security according to the result of EWR in time. As to the Middle Line of the South-to-North Water Diversion Project, if the EWR of Han River was below the minimal ecological water requirements, the bureaus of construction and management of the projects would adjust the amount of water diversion and the regional governments would take ecological protection measures more quickly.

A causal diagram was constructed to reveal the interrelations among the ecosystems, which are affected by IBWTPs (see Figure 5). Considering the impacts of the IBWTPs, the increase of EWRs of water diversion ecosystems would increase EWRs of downstream of water diversion ecosystems, and decrease the EWRs of water receiving ecosystems and ecosystems along the water diversion route. Meantime, the EWRs of those ecosystems would influence the EWRs of water diversion ecosystems.

![](images/35e937ae90485562943ab1c41636541cd983782219a7f2df9129a37da6702dd0.jpg)  
Figure 5. Changes of ecological water requirements (EWRs) of complex ecosystems influenced by IBWTPs.

Taking the minimum ecological water requirements (mEWRs) as one index to reveal the impacts on ecological security from IBWTPs. The mEWRs could be considered the baseline of ecological security from the perspective of EWRs. This means that if the construction and operation of IBWTPs lead in the EWRs of ecosystems below the mEWRs of ecosystems, the ecosystems degradation would happen.

We calculated the mEWRs of ecosystems, which have been influenced by the Middle Line of the South-to-North Water Diversion Project, before the water diversion project began operation (see Table 1). The mEWRs of Danjiangkou Reservoir were calculated by the method of lake EWRs and the calculation data were calculated from the capacity of the Danjiangkou Reservoir in 2013 [32]. The

mEWRs of the complex ecosystems in Beijing and Tianjin showed the baseline of ecological security of the water receiving ecosystems, and the mEWRs of the complex ecosystems in Henan and Hebei showed the baseline of ecological security of ecosystems along the water diversion. The mEWRs of Beijing, Tianjin, Henan, Hebei, and Hubei were calculated from statistics in 2000–2013. The mEWRs downstream of the Han River, which is one of the spillover ecosystems, was calculated by the Tennant method for river EWRs. The mEWR downstream of the Han River was calculated from average runoff in 1997–2013. Another spillover system comprised the ecosystems in resettlement areas, which were located in Hubei Province. The mEWRs of the ecosystems in resettlement areas were calculated using statistics in 2000–2013.

Based on the analysis model for impacts of IBWTPs, the EWRs of every ecosystem, which influenced by the IBWTPs, should be ensured above the mEWRs, during the operation of IBWTPs.

Table 1. Ecological water REQUIREMENTS of the IBWTPs.   

<table><tr><td>Systems</td><td>Ecosystems</td><td>Regions</td><td>mEWRs (Billion m3)</td></tr><tr><td>Sending systems</td><td>Water diversion ecosystems</td><td>Danjiangkou Reservoir</td><td>20.40</td></tr><tr><td rowspan="2">Receiving systems</td><td>Water receiving ecosystems</td><td>Beijing Tianjin</td><td>0.59 0.09</td></tr><tr><td>Ecosystems along the water diversion</td><td>Hebei Province Henan Province</td><td>0.47 0.61</td></tr><tr><td rowspan="2">Spillover systems</td><td>Downstream of the water diversion ecosystems</td><td>Downstream of the Han River</td><td>1.32</td></tr><tr><td>Ecosystems in resettlement areas</td><td>Hubei Province</td><td>0.04</td></tr></table>

# 5. Conclusions

The telecoupling framework offered a useful analytical approach for comprehensive analysis of the impacts of IBWTPs on ecological security. In this framework, the ecosystems, which were relevant to IBWTPs irrespective of the distance between them, were all taken into account. Meanwhile, the DPSIR model was used within the sending systems, receiving systems, and spillover systems, to explain the impacts in detail. Above all, this analysis model of the impacts of IBWTPs on regional ecological security was a proper tool with which the impacts of IBWTPs on ecological security can be analyzed.

The analysis model also revealed the material flows, information flows, and energy flows between ecosystems. Thus, sharing information about ecological security is one of the key points for effective decision making for IBWTPs. Moreover, the ecological water requirement could serve as a single index for controlling the ecological security of ecosystems impacted by IBWTPs.

Acknowledgments: This study was supported by the State Key Laboratory of Urban and Regional Ecology (SKLURE 2013-1-02) of China and the National Key Technologies R&D Program (No. 2013BAJ04B01). The authors are grateful to all the people who helped complete this research and to the anonymous reviewers for their suggestions to improve the manuscript.

Author Contributions: Yuan Quan conceptualized the paper and completed the English writing. Chenxing Wang contributed to data collection and calculation. Yan Yan contributed to the conceptual model. Gang Wu and Hongxun Zhang contributed to manuscript revision.

Conflicts of Interest: The authors declare no conflict of interest.

