# Analyzing and forecasting water-land dynamics for sustainable urban developments: A multi-source case study of Lake Dianchi's environmental challenges (China)

![](images/4c17b765c53604f87cc02ad698d4d157489260ecec1bd070a875482c7bb6b4c5.jpg)

Yawen Wu a,1, Xinyu Wang b,1, Laszlo Kollanyi b, Jingli Zhang a, Tian Bai a,*

a College of Landscape and Horticulture, Yunnan Agricultural University, Kunming 650201, Yunnan Province, China   
b Institute of Landscape Architecture, Urban Planning and Garden Art, Hungarian University of Agriculture and Life Sciences, Budapest 1114, Hungary

# ARTICLEINFO

Keywords:

Water-shore relationship

Time series

Self-organizing diagram

Redundancy analysis

Lake Dianchi in China

# ABSTRACT

The delicate plateau lake ecosystem has been further damaged by extensive human construction projects, leading to water pollution in Lake Dianchi, China. This serves as a prominent example of urbanization and human interference, drawing global scholarly interest. Restoring Lake Dianchi's water quality remains a global challenge despite 40 years of treatment, with unclear links to surrounding land development. Therefore, this study constructed a GIS database, combined with 2013-2023 landsat-8/MODIS, Land Use/Land Cover (LULC) remote sensing data and multi-year water quality monitoring, to conduct a multi-scale analysis of the plateau Lake Dianchi and its surrounding land, and implemented it through a Self-Organizing Map (SOM). The classification of lakeshore pollution source clusters was further analyzed through Redundancy Analysis to explore the interaction and future trends between lake water quality and land development in the lakeshore zone. Research indicates the following: (1) According to cluster analysis, water quality in semi-urban lakeside areas (cluster 2) had the highest correlation with lakeside land use, followed by urban areas (cluster 1) and rural areas (cluster 3); (2) Lake water pollution was difficult to improve through the optimization of land development in the lakeshore zone. Combined with the results from (1), although semi-urban areas had a certain impact on water quality, over time, there was a trend of decorrelation between the steady state of water quality pollution and the development of urban construction. This trend indicates that urban development consistently contributes to single pollution sources in water quality; (3) At different scales, the water pollution index in semi-urban areas responded significantly to construction activities, indicating signs of tele-coupling; the response to farmland was complex, while the response to green space was small; (4) In the process of decorrelation between lake water quality and land development, the rate in urban areas (cluster 1) and rural areas (cluster 3) was faster than that in semi-urban lakeside areas (cluster 2). To sum up, it is difficult to restore the water quality of Lake Dianchi through optimizing urban land layout. Meanwhile, it is necessary to further prevent and control the impact of remote pollution sources on the water quality of Lake Dianchi. Protection of the plateau lake environment cannot remain at the optimization level; it should further realize the principles of multi-dimensional governance. This is also the key to addressing the lack of results in Lake Dianchi management for many years.

# 1. Introduction

Urbanization development in the lakeshore area has changed important characteristic indicators such as the quantity (Qu et al., 2023), quality, and structure of the original land, thereby affecting lakeshore habitat, water ecosystem, and service functions (Li et al.,

2022; Luo et al., 2023), leading to both point and non-point source pollution (Gu and Li, 2023).

In numerous studies, the extent of urban development, agricultural production, and land use change is considered to be closely related to the degradation of water quality. This has been observed in the upper reaches of the Nisa River in Europe and the Likangala River Basin in

Malawi, Africa (Kändler et al., 2017; Pullanikkatil et al., 2015). In Asia, researches from coastal areas in Malaysia to the Taral River Basin in the Iranian Plateau have indicated that land use and associated activities are the main contributors to water pollution (Camara et al., 2019; Kavian et al., 2018).

In China, rapid urbanization and ensuing urban expansion have sparked substantial construction demands, intensifying the strain on lake resources and leading to issues like eutrophication and escalating organic pollution (Jin, 2003). Compared to plain lakes such as Taihu (Liang et al., 2022) and Chaohu (Yang et al., 2020), plateau lakes like Lake Dianchi, a typical rift valley lake characterized by short water flow, numerous rivers, single outflow, and high susceptibility to pollutant accumulation (Zhou et al., 2012), have more fragile ecosystems and lower self-purification thresholds. They confront more daunting challenges in water-land relationships under similar land pressures (Ran et al., 2023).

Lake Dianchi, also known as the "Pearl of the Plateau", is the largest lake in southwest China. Over the past 40 years, research on land change and water quality in Lake Dianchi has become an important academic topic for many scholars (He et al., 2020). Conflicts between water quality and lakeshore development have been documented (Liu et al., 2015). On December 28, 1969, a lakeshore conflict occurred due to the "land reclamation movement around the lake", resulting in the landfill of nearly $23\mathrm{km}^2$ of Lake Dianchi wetland and the disappearance of natural wetland on several occasions. Additionally, with the urbanization development of Kunming City and the increasing complexity of the lakeshore, different land use changes have created a complex and dynamic lakeshore environment. Spatially, the river flows into the east side of the lake, passing through urban areas, farmlands; the river pollution load flows to the center of the lake (Luo et al., 2018), exacerbating the deterioration of water quality (Li et al., 2012). The Xishan mountain scenic area on the west side has a coast elevation difference of $450\mathrm{m}$ . Soil erosion and phosphate rock leaching have brought serious challenges to water quality maintenance. The $161.55\mathrm{km}$ of Lake Dianchi's

lakeshore records the development history of the city, forming a mixed land development stage ranging from rural areas to semi-urbanization and urbanization (Cao et al., 2012; Luo et al., 2023; Yang et al., 2023). Therefore, the quantitative description of the water-shore interaction process in Lake Dianchi still faces difficult challenges.

The water quality of Lake Dianchi has a significant response to different types of land use in the lakeshore area, such as the scale effect of construction land change and farmland pollution (Peng et al., 2024; Ran et al., 2023). The dispersion of pollution and changes in biological processes have led to instability in the correlation between the development of lakeshore areas and the water quality index (He et al., 2010; Jiang et al., 2021). These uncertainties highlight the critical need for a deeper understanding of water-lakeshore relationships.

In this study, we combined multi-source remote sensing data and multi-year monitoring data to scientifically divide the lakeshore buffer areas of Lake Dianchi at different scales. We analyzed the intrinsic relationship and spatiotemporal process between the comprehensive characteristics of the quality, quantity and structure of the land use and the water quality of Lake Dianchi (He et al., 2010), examining the spatial heterogeneity and temporal evolution of water pollution indicators in Lake Dianchi (Zhao et al., 2012). Furthermore, we simulated future scenarios and used historical data to predict water interaction trends, providing a scientific basis for urban policies.

# 2. Research area and materials

# 2.1. Study area and sampling methods

Lake Dianchi $(102^{\circ}22^{\prime} - 102^{\circ}58^{\prime}\mathrm{E}, 24^{\circ}22^{\prime} - 25^{\circ}36^{\prime}\mathrm{N})$ is an important ecological barrier in southwest China. It is arch-shaped, extending 40 km from north to south, with an average width of $7.5\mathrm{km}$ and a maximum width of $12.5\mathrm{km}$ . Its lakeshore is $163\mathrm{km}$ long. The water level of Lake Dianchi is $1886.5\mathrm{m}$ , with an average depth of $4.4\mathrm{m}$ and a maximum depth of $10.9\mathrm{m}$ . It covers an area of about $330\mathrm{km}^2$ and a total

![](images/19054bed08bdb03256df73197c3d5a40faf3736385ed2b4b135877b82f745f72.jpg)

![](images/bb67f06b1bbd5d498450391fae855200ec7296df40f809eb4307388bc2431ced.jpg)

![](images/124e50d1a9eeafc77a8a7e235947d3acbdc8efda64c0f8fc0f3d389df67e47ff.jpg)

![](images/1008d10007c972571fa45d5e321ae3b667ed9825ec9b9fb96363b267ecb9b780.jpg)  
Fig. 1. Study area map and description (GS (2020) 4619).

![](images/c346e27f9dab083c398a4ca3ef5cd7fef00285aefbe82f79162e11b56f82eb74.jpg)

![](images/881b2013f2f251842f35d67841dda97a09516910b1f4e9b4bfb2e4b9ef17922a.jpg)  
Fig. 2. Flowchart.

volume of 1.29 billion $\mathrm{m}^3$ . The narrowest part of the northern part of the lake is divided into two parts by a man-made sandbar $3.5\mathrm{km}$ long and $300\mathrm{m}$ wide. The northern part is called Caohai and the southern part is called Waihai (Fig. 2(d)) (He et al., 2020; Luo et al., 2018).

The research object was the water pollution index within a $400\mathrm{m}$ zone along the shore of Lake Dianchi and the buffer zone extending from the lakeshore $(0\mathrm{m})$ to $2800\mathrm{m}$ , with intervals of $400\mathrm{m}$ , resulting in a total of 7 annular areas. 100 basic datum cases were selected equidistantly along the lakeshore. The vertical distance between the inner and outer circles was calculated based on these points. After manual correction, 100 sampling points were obtained for each water/land circle (Fig. 1).

# 2.2. Research process

This thesis is structured into three main parts: a comprehensive assessment of water quality and land development, an analysis of the water-land relationship from 2013 to 2022, and a projection of future trends.

# 2.3. Data sources and preprocessing

# 2.3.1. Data types

The data in this study include two major categories, with a total of 7 subcategories, as shown in Table 1: (1) Water pollution inversion data: (1.1) Water quality inversion data includes pollution monitoring station data, covering 21 parameters. The monitoring indicators include: pH, Dissolved Oxygen (DO), Permanganate Index (PI), Chemical Oxygen Demand (COD), 5-day Biochemical Oxygen Demand (5-BOD), Ammonia Nitrogen (AN), Total Phosphorus (TP), Copper (Cu), Zinc (Zn), Fluoride (F), Selenium (Se), Arsenic (Ar), Mercury (Hg), Cadmium (Cd), Hexavalent Chromium $(\mathrm{Cr(VI)})$ , Lead (Pd), Cyanides (Cy), Volatile Phenols (VP), Petroleum (Petro), Anionic Surfactants (AS), and Sulfides (S); (1.2) Landsat 8 L2 satellite band data are used for the global inversion of water pollution indicators. (2) Land evaluation data: (2.1) Land use and land cover (LULC) data; (2.2) Landscape pattern data of farmland and green space; (2.3) Fractional Vegetation Cover (FVC), Leaf Area Index (LAI), and Primary Gross Product (GPP) data; (2.4) Land Surface

Temperature data (LST), Population density data (POP), and Nighttime light data (NTL) for construction land assessment.

# 2.3.2. Data preprocessing

The remote sensing data mentioned above were acquired and processed using the Google Earth Engine (GEE) platform (https://sthjj.km.gov.cn/), except for the LULC data sourced from (Yang and Huang, 2021). The preprocessing of the data is as follows: a. Remote sensing data: Landsat 8 L2 were processed by removing certain pixels related to clouds and shadows using the QA_PIXEL band, and then calculating annual median composites. The water surface remote sensing data were matched to monitoring data using the Modified Normalized Difference Water Index (MNDWI) to filter out unwanted data. b. LULC data: Land use was reclassified according to research needs, with similar land types (e.g., shrubland, grassland, forestland) merged, and categorized into 4 types: construction, water, green space, and farmland. c. NTL data: The MNDWI was employed to eliminate blooming effects on water bodies and mask water surface lighting. d. POP data: Worldpop's population dataset is available only up to 2020, so a per-pixel linear fitting algorithm was applied to estimate population data for 2021/2022 to maintain data consistency. e. LST data: Based on the single window algorithm (Ermida et al., 2020), the B10 band was used for land surface temperature inversion, followed by the calculation of annual average temperatures.

# 3. Model and methodology

# 3.1. Water pollution index inversion and lakeshore land evaluation

# 3.1.1. Inversion of water pollution indicators

The water quality parameters (WQPs) and pollutant monitoring results were correlated with specific bands and band combinations through Pearson correlation coefficients $(\mathrm{r} > 0.7)$ (Yang et al., 2022). Subsequently, the Moving Window Interquartile Range Test (IQR) was employed to filter out minor aquatic constructions such as bridges, embankments, and floating islands of Lake Dianchi. A $10 \times 10$ pixels $(300\mathrm{m} \times 300\mathrm{m})$ window was defined to calculate the 25th and 75th percentiles, representing the lower (Q1) and upper (Q3) quartiles within

Table 1 Overview of Data Sources.   

<table><tr><td>Data</td><td>Source</td><td>Resolution/ Scale</td><td>Time Period</td></tr><tr><td>Water Quality Monitoring Data</td><td>Kunming Municipal Bureau of Ecology and Environment</td><td>32 monitoring stations</td><td>2014–2022</td></tr><tr><td>Remote Sensing Satellite Bands</td><td>Landsat 8 L2</td><td>30 m</td><td>2013–2022</td></tr><tr><td>LULC Dataset</td><td>Finished data</td><td>30 m</td><td>2013–2022</td></tr><tr><td>Landscape Pattern Indices</td><td>LULC Dataset</td><td>30 m</td><td>2013–2022</td></tr><tr><td>FVC/LAI/LST</td><td>Landsat 8 L2</td><td>30 m</td><td>2013–2022</td></tr><tr><td>GPP</td><td>MODIS MOD17A2H</td><td>250 m</td><td>2013–2022</td></tr><tr><td>NTL</td><td>NPP/VIIRS</td><td>500 m</td><td>2013–2022</td></tr></table>

each pixel's local area. The IQR, the difference between Q3 and Q1, was computed to delineate the range of normal values, defined as $\mathrm{Q1} - 1.5\mathrm{IQR}$ to $\mathrm{Q3} + 1.5^{*}\mathrm{IQR}$ . Values outside this range were considered outliers. Finally, spatial characteristics of lake pollution were obtained through one-dimensional regression calculations including linear, exponential, logarithmic, inverse-power, and polynomial function.

The accuracy evaluation indices used to confirm the accuracy of the inversion model are the coefficient of determination $(\mathbb{R}^2)$ , mean absolute error (MAE), mean squared error (MSE), root mean square error (RMSE), and the pair analysis error (RPD) (Li, 1956; Meng et al., 2022). A PRD greater than 1.4 generally indicates that the model effectively estimates the sample content in response to the spatial distribution of the indicator.

$$
\mathrm {R M S E} = \sqrt {\frac {\sum_ {\mathrm {i} = 1} ^ {\mathrm {n}} \left(\mathrm {y} _ {\mathrm {i}} - \hat {\mathrm {y}} _ {\mathrm {i}}\right) ^ {2}}{\mathrm {n}}} \tag {1}
$$

$$
\mathrm {M A E} = \frac {\sum_ {\mathrm {i} = 1} ^ {\mathrm {n}} \left| \mathcal {Y} _ {\mathrm {i}} - \widehat {\mathcal {Y}} _ {\mathrm {i}} \right| ^ {2}}{\mathrm {n}} \tag {2}
$$

$$
\mathrm {M S E} = \frac {\sum_ {\mathrm {i} = 1} ^ {\mathrm {n}} \left(\mathrm {y} _ {\mathrm {i}} - \widehat {\mathrm {y}} _ {\mathrm {i}}\right) ^ {2}}{\mathrm {n}} \tag {3}
$$

$$
\mathrm {R P D} = \frac {\mathrm {S D}}{\mathrm {R M S E}} = \frac {\sqrt {\frac {1}{n} \sum_ {i = 1} ^ {n} \left(\mathcal {Y} _ {i} - \bar {y}\right) ^ {2}}}{\sqrt {\frac {1}{n} \sum_ {i = 1} ^ {n} \left(\hat {y} _ {1} - \mathcal {Y} _ {i}\right) ^ {2}}} = \sqrt {\frac {\sum_ {i = 1} ^ {n} \left(\mathcal {Y} _ {i} - \bar {y}\right) ^ {2}}{\sum_ {i = 1} ^ {n} \left(\hat {y} _ {1} - \mathcal {Y} _ {i}\right) ^ {2}}} \tag {4}
$$

where $y_{i}$ and $\widehat{y}_i$ are the measured and predicted values of each pollution indicator, respectively; $\overline{y}$ is the average of the measured values of the pollutions; $n$ is the number of samples. RPD is the ratio of the sample Standard Deviation (SD) to the RMSE, which quantifies the predictive power of the model and better points out the research scenarios to which different model accuracies apply.

At the post-processing stage, z-test was used to filter noise and anomalies within a $[-3, 3]$ confidence range. Focal statistics were then

applied for neighboring mean substitution of outliers, followed by global smoothing for further refinement. Based on the WQPs, the indicators were further screened/normalized and overlaid to generate the Water Pollution Composite Index (WPCI) (Fig. 3).

# 3.1.2. Analysis of comprehensive land indicators

This study adopted three dimensions: quantity, quality and structure (Table 2): (1) Quantitative dimension: The land along Lake Dianchi was gridded, and the occupancy of different land use types within each $1\mathrm{km}\times 1\mathrm{km}$ grid was calculated, serving as a quantitative evaluation index; (2) Quality dimension: Farmland and green space were evaluated according to China's ecological environment standards (HJ 1172-2021). Equal weight was applied to the superimposed LAI, FVC, and GPP. For construction land, we integrated NTL, POP, and LST. NTL reflects the intensity of land infrastructure development and commercial vitality, POP represents the degree of population agglomeration and land use intensity, and LST supplements factors often overlooked in urban fringes; (3) Structural dimension: Principal component analysis was used to select indicators explaining more than $85\%$ of the total variance. Selection indicators included cohesion, Edge density (ED), Largest Patch Index (LPI), and grid index. These structural indicators characterize the boundary complexity of land patches and their areas, influencing the flow of matter and energy and ecological efficiency to a certain extent (Bartel, 2000).

# 3.1.3. Weights and calculations between various comprehensive indices

The weighting of each indicator was determined using the Criterion Importance Through Intercriteria Correlation (CRITIC) method, an objective weighting method that considers both the contrast intensity $(S_{\mathrm{j}})$ and conflict $(R_{\mathrm{j}})$ between indicators. The calculation formula is as follows (Diakoulaki et al., 1995):

$$
W _ {j} = \frac {C _ {j}}{\sum_ {j = 1} ^ {p} C _ {j}} \tag {5}
$$

where $C_j$ is the information content calculated by multiplying $S_j$ (standard deviation, representing the variation of the indicator across different evaluation schemes) and $R_j$ (correlation coefficient, representing the conflict between indicators).

Table 2 Land Assessment Framework.   

<table><tr><td>Target Layer</td><td>Framework Layer</td><td>Indicator Layer</td></tr><tr><td rowspan="3">Comprehensive Farmland Assessment</td><td>Quantity</td><td>Land Use Ratio</td></tr><tr><td>Quality – Green Space/ Farmland</td><td>LAI + FVC + GPP</td></tr><tr><td>Quality – Construction Structure</td><td>LST + NTL + POP Landscape Patterns Index</td></tr></table>

![](images/c76ff049792280f81b70b12796ddade3a7b031bd99ddf92527af616cebe696a3.jpg)  
Fig. 3. Technical Process of Water Quality Inversion.

Based on the principle of evenly distributing pollution data across various categories, nine key pollution indicators were selected from three major categories of heavy metals (Cd, Cr(VI), Pd), non-organic (AN, TP, S), and organic pollutants (COD, VP, AS). These indicators were used to compute the WPCI, facilitating a detailed exploration of the overall spatial characteristics of water pollution:

$$
\begin{array}{r l} \mathrm {W P C I} & = \mathrm {C d} _ {\text {n o r}} + \mathrm {C r} (\mathrm {V I}) _ {\text {n o r}} + \mathrm {P d} _ {\text {n o r}} + \mathrm {C O D} _ {\text {n o r}} + \mathrm {A S} _ {\text {n o r}} + \mathrm {V P} _ {\text {n o r}} + \mathrm {A N} _ {\text {n o r}} \\ & + \mathrm {T P} _ {\dots} + \mathrm {S} _ {\dots} \end{array} \tag {6}
$$

where "nor" represents the result of max-min normalization. It is important to note that the sum of normalized pollution indicators does not represent the sum of pollution values but rather indicates a tendency of spatial trends.

The land use evaluation framework is complex. Quality indicators for green space and farmland are equally weighted, while structure indicators (Structure) for each land type and quality indicators for construction (Quality) require weighted addition using their respective CRITIC weights (W):

$$
\text {S t r u c t u r e} / \text {C o n s t r u c t i o n Q u a l i t y} = \sum \left(\mathrm {W} ^ {*} \text {I n d i c a t o r} _ {\text {n o r}}\right) \tag {7}
$$

Finally, the calculation of each type of land evaluation index (Farmland assessment composite indicator - FACI, Green space assessment composite indicator - GACI, Construction assessment composite indicator - CACI) follows the formula:

$$
\mathrm {F A C I} / \mathrm {G A C I} / \mathrm {C A C I} = \text {Q u a n t i t y} _ {\mathrm {n o r}} + \text {Q u a l i t y} _ {\mathrm {n o r}} + \text {S t r u c t i o n} _ {\mathrm {n o r}} \tag {8}
$$

# 3.2. SOM cluster classification of lakeshore pollution characteristics

To further understand the potential mechanism of pollution, we integrated the pollution trends of the sampling points and the fluctuation trends of various indicators over time. We used self-organizing map (SOM) to cluster the sampling points (Penn, 2005). Using the R-kohonen analysis package, we performed SOM + K-means clustering on the sampling points in two stages. Water quality sampling data along Lake Dianchi was inputted into the SOM network, and we determined the optimal number/structure of neurons through multiple iterations to achieve the smallest Quantification Error (QE) and Terrain Error (TE). Subsequently, we applied the weight obtained from the SOM clustering result as the initial cluster center and combined it with the Davies & Bouldin Index (DBI) to select the optimal number of clusters for K-means calculation. Finally, according to the actual location and urban development conditions, we clustered geographically uneven and dispersed areas.

# 3.3. Pollution response and correlation analysis

We preliminarily selected land rings at distances of $400\mathrm{m}$ , $1600\mathrm{m}$ and $2800\mathrm{m}$ from the front of Lake Dianchi as near, mid, and far sampling distances for different land uses, forming one set of ring layer data. For trend analysis with high heterogeneity in ring layers, we selected layers exhibiting unique features (identified through VIF test) in construction, farmland, and green space for inclusion in the study. It is important to consider that Pearson correlation analysis is sensitive to outliers and might not fully reveal complex relationships in multivariate environmental issues. Therefore, it serves as a quantitative supplement to Redundancy Analysis (RDA) (Hauke and Kossowski, 2011).

RDA provides a method to deeply analyze the relationships between environmental variables and water quality responses. After data dimensionality reduction, RDA assesses the contribution of environmental variables (such as land development indicators BACI, GACI, and FACI) to the variance of response variables from both independent and holistic perspectives (Liu, 1997). Combined with Pearson correlation and Canoco 5.0 RDA, we comprehended the interrelationships and influences between various indicators. It's important to note that we

excluded collinearity indicators based on Variance Inflation Factor (VIF) tests (Dormann et al., 2013).

# 3.4. Trend testing and future forecast

# 3.4.1. Getis-Ord $G i^{*}$

In this study, we used the Getis-Ord Gi* statistic provided by ArcGIS Pro for hotspot analysis:

$$
\mathrm {G I} ^ {*} = \frac {\sum_ {j = 1} ^ {n} w _ {i j} x _ {j} - \bar {X} \sum_ {j = 1} ^ {n} w _ {i j}}{S \sqrt {\frac {n \sum_ {j = 1} ^ {n} w _ {i j} ^ {2} - \left(\sum_ {j = 1} ^ {n} w _ {i j}\right) ^ {2}}{n - 1}}} \tag {9}
$$

$x_{j}$ is the attribute value of cell $j$ ; $w_{ij}$ is the spatial weight between cell $i$ and cell $j$ ; $\overline{X}$ is the mean of all cell attribute values; $S$ is the standard deviation of all cell attribute values. Positive values of $\mathrm{GI^{*}}$ represent hot spots, and negative values represent cold spots. When $|\mathrm{GI^{*}}| > 2.576$ , the confidence level is $99\%$ ; when $|\mathrm{GI^{*}}| > 1.960$ , the confidence level is $95\%$ ; and when $|\mathrm{GI^{*}}| > 1.645$ , the confidence level is $90\%$ .

# 3.4.2. Mann-Kendall test and Theil-Sen Median method

Using years of water pollution and land development grid data, we calculated the change trend of pollution/land quality on a pixel-by-pixel basis based on Theil-Sen median method on the ArcGIS Pro 3.0 platform. This method estimates the trend slope in a dataset (Sen, 1968), providing reliable and reliable quantitative measurements of trends through land and water quality data. For a dataset $\mathrm{X}_1$ , $\mathrm{X}_2$ , ..., $\mathrm{X}_k$ , $\mathrm{X}_j$ , ... $\mathrm{X}_n$ :

$$
\mathrm {S e n} ^ {\prime} \mathrm {s} = \text {M e d i a n} \left(\frac {\mathrm {X} _ {\mathrm {j}} - \mathrm {X} _ {\mathrm {k}}}{\mathrm {j} - \mathrm {k}}\right), \quad \text {f o r a l l j > k} \tag {10}
$$

The Mann-Kendall test (M-K test) (Mann, 1945), a non-parametric statistical method, is frequently employed to detect singular trends in time series datasets. In the M-K test statistic, S is calculated as follows:

$$
S = \sum_ {k = 1} ^ {n - 1} \sum_ {j = k + 1} ^ {n} \operatorname {s i g n} \left(X _ {j} - X _ {k}\right), \quad \text {f o r a l l} j > k \tag {11}
$$

where $n$ is the number of data points, $x_{j}$ and $x_{k}$ are the data values in time series; The sign function sign $(X_{j} - X_{k})$ evaluates to negative $(-1)$ when less than 0, positive (1) when greater than 0, and 0 when equal to 0. The variance is computed as:

$$
\operatorname {V a r} (S) = \frac {\mathrm {n} (\mathrm {n} - 1) (2 \mathrm {n} + 5) - \sum_ {\mathrm {k} = 1} ^ {\mathrm {m}} \mathrm {t} _ {\mathrm {k}} \left(\mathrm {t} _ {\mathrm {k}} - 1\right) \left(2 \mathrm {t} _ {\mathrm {k}} + 5\right)}{1 8} \tag {12}
$$

where $n$ is the number of data points, $m$ is the number of tied groups, and $t_k$ denotes the number of ties of extent $k$ . A tied group refers to a set of sample data with identical values. For sample size $n > 10$ , the standard normal test statistic $Z_S$ is computed using:

$$
Z _ {S} = \left\{ \begin{array}{c l} \frac {S - 1}{\sqrt {\operatorname {V a r} (S)}}, & \text {i f} S > 0 \\ 0, & \text {i f} S = 0 \\ \frac {S + 1}{\sqrt {\operatorname {V a r} (S)}} & , \text {i f} S <   0 \end{array} \right. \tag {13}
$$

Positive values of $Z_{s}$ indicate increasing trends, while negative values indicate decreasing trends. In this study, the significance level is set at 0.05. At the $5\%$ significance level, the null hypothesis of no trend is rejected if $|Z_{S}| > 1.96$ .

# 3.4.3. Curve-fitting forecast

Based on the ArcGIS Pro 3.0 curve fitting prediction tool, the most appropriate curve type (e.g., linear, parabolic, exponential or S-shaped) is selected for each pixel. This enables quantification of the change trend through the optimal prediction model.

This study constructed a space-time cube using 10 years of historical grid data on land development evaluation and water quality inversion. We employed the curve fitting prediction tool to forecast the Water-Land data for 2027. Setting a $95\%$ confidence level and retaining the data from the last time point in the dataset, we compared it with the predicted values to calculate the simulation accuracy of the model.

# 4. Results and analysis

# 4.1. Spatial analysis and time process of water pollution and coastal land

# 4.1.1. WQPs inversion results

The band combination with the largest absolute value of the correlation coefficient was used as the characteristic remote sensing in spectrum for this WQPs. After testing each type of univariate regression model, the model with the largest PRD was screened (Fig. 4).

The final WQPs inversion model and the corresponding accuracy metrics are as follows (Table 3).

# 4.1.2. Analysis of spatial hot spots of water pollution

By synthesizing multi-year WPCI and normalizing it, a significant "shoreline effect" in water pollution of Lake Dianchi was observed. Spatially, pollution levels increase from the center of the lake towards the periphery, particularly with higher pollution levels in the northern littoral areas compared to the south. The distribution of heavily polluted areas is notable, especially in Caohai, the northern part of Waihai, and the southwestern lake outlet area (Fig. 5(a)).

Correspondingly (Fig. 5(b1)-(b3)), Region 1, located near Kunming's city center, features a major construction development center on its eastern side (CACI hot spot) and borders the Xishan Nature Reserve, characterized by high-quality green space (GACI hot spot) on the western side. The narrow water body in this region facilitates pollution diffusion. Region 2, an emerging development area in Kunming, is active

in construction in the north (CACI hot spot) while the southern part remains rural with concentrated agricultural production (high FACI). The width of the lake gradually expands from this point. Region 3, the lake's only outlet, experiences further narrowing of the water body and pollution convergence. Surrounding this area are parts of high-value GACI regions, with the north being the Xishan area, and also a low-value CACI region, indicating less construction and predominantly rural land. Overall, the surrounding $3\mathrm{km}$ land of Lake Dianchi is still dominated by agricultural activities (average FACI value of 0.549), with a high reserve of green resources (average GACI value of 0.408) and a lower degree of construction (average CACI value of 0.228).

# 4.1.3. Asynchronous development analysis

In global statistics, FACI and GACI exhibited a significant downward trend, while CACI showed steady growth. Despite construction development, water quality pollution in the entire/edge area of Lake Dianchi did not show significant change trends.

In detail, water quality data, both globally and along the lakeshore, exhibited regular changes. This study analyzed three periods of fluctuations (2014-2016; 2017-2019; 2020-2022) using the paired sample Wilcoxon signed-rank test, indicating significant differences in global WPCI between these paired years $(\mathrm{P} < 0.01)$ , confirming the regular change in water quality pollution. Notably, the amplification of these global WPCI fluctuations was increasing, rising from 0.278 in 2014-2016 to 0.394 in 2020-2022.

Spatially, the littoral zone exhibited high pollution values, demonstrating a strong spatial correlation between land and water. Temporally, this initial observation suggests asynchronous and decorrelation states (Zhang et al., 2021) within the lake-shore system (Fig. 6).

![](images/604b40e51ef3c5b5e8292548bc67fa5595b4de4f6c7bf85ed1154cab9b1866d7.jpg)

![](images/4adc55b0d50955dd995577279d390bbf6fab55c2647386cfc65238e090b638c8.jpg)  
Fig. 4. Feature Band Combination Screening & Regression Modeling.

Table 3 Regression Model for the Inversion of Water Quality Concentration.   

<table><tr><td>WQPs</td><td>Unit (Scale)</td><td>Formula</td><td>RMSE</td><td>MSE</td><td>MAE</td></tr><tr><td>VP</td><td>mg/L(e-5)</td><td>y = 161.0078 + -203.0324 * log(x)</td><td>21.222</td><td>450.393</td><td>14.998</td></tr><tr><td>Cr (VI)</td><td>mg/L(e-4)</td><td>y = 17.7276 + 8.2418 * x + -3.6739 * x²</td><td>0.734</td><td>0.538</td><td>0.520</td></tr><tr><td>Pd</td><td>mg/L(e-4)</td><td>y = 56.0294 * x-2.7892</td><td>8.309</td><td>69.037</td><td>5.681</td></tr><tr><td>pH</td><td>-</td><td>y = 9.9780 * exp (-0.1504 * x)</td><td>0.286</td><td>0.082</td><td>0.216</td></tr><tr><td>COD</td><td>mg/L(e-3)</td><td>y = 128.0884 * exp (-1.0961 * x)</td><td>6.546</td><td>42.848</td><td>5.415</td></tr><tr><td>Petro</td><td>mg/L(e-3)</td><td>y = 0.2593 * exp (2.6156 * x)</td><td>5.529</td><td>30.571</td><td>3.436</td></tr><tr><td>TP</td><td>mg/L(e-2)</td><td>y = 591.7862 * exp (-2.0450 * x)</td><td>6.184</td><td>38.248</td><td>4.986</td></tr><tr><td>Hg</td><td>mg/L(e-6)</td><td>y = 4.5447 + 9.3986 * x</td><td>0.889</td><td>0.791</td><td>0.580</td></tr><tr><td>Cd</td><td>mg/L(e-5)</td><td>y = 6.4579 + 113.9169 * log(x)</td><td>6.755</td><td>45.633</td><td>4.076</td></tr><tr><td>AS</td><td>mg/L(e-2)</td><td>y = 1467.1418 * exp (-2.8230 * x)</td><td>5.514</td><td>30.405</td><td>3.638</td></tr><tr><td>Zn</td><td>mg/L(e-2)</td><td>y = 13.4098 * x-3.3394</td><td>0.724</td><td>0.524</td><td>0.560</td></tr><tr><td>S</td><td>mg/L(e-3)</td><td>y = 4345.9254 * exp (-3.5484 * x)</td><td>7.692</td><td>59.159</td><td>4.280</td></tr><tr><td>AN</td><td>mg/L(e-2)</td><td>y = 23729.2530 * exp (-3.2369 * x)</td><td>43.430</td><td>1886.175</td><td>30.618</td></tr></table>

![](images/4fdea391f5d8bc6abdae79cf76eb24424c3dbf55aafa38e14dbaac9e2bd26f48.jpg)  
Fig. 5. Multi-year WPCI&FACI/CACI/GACI Spatial Hotspots.

![](images/8fff5bd1806f67fa07558bfc2a4d66f81582bc130fcb46f8bb7c470c98a15183.jpg)  
Fig. 6. Multi-year WPCI&FACI/CACI/GACI Statistical Trend Analysis.

# 4.2. SOM clustering and Lake - Shore relationship analysis

# 4.2.1. Lakeshore classification from SOM clustering and actual

In the SOM clustering analysis of the Lake Dianchi lakeshore based on data from 2014 to 2022, using 6 time points' annual data of 9 water pollution indicators, the optimal network training effect was achieved with a neuron combination of $\mathrm{X} = 10$ , $\mathrm{Y} = 9$ after multiple iterations (QE = 52.802; TE = 0.590). The DBI value stabilized when the number of clusters reached 11 (Fig. 7).

Furthermore, the areas around Lake Dianchi were divided into three different categories: a highly developed area in the north (Cluster 1), a moderately developed area in the urban-rural transition stage on the east shore (Cluster 2), and a lightly developed area dominated by industrial and rural land on the west shore (Cluster 3). Regarding pollution features, pollution in Cluster 1 was mainly AN/TP/AS/Cr (VI), Cluster 2 exhibited primarily Cr (VI)/VP/Pd, and Cluster 3 was mainly Cr (VI)/

VP. COD and Cd indicators showed low values within all three clusters (Fig. 8).

Cluster statistics for land development indicators, while dominated by green space/farmland (GACI/FACI) with minimal construction indicator (CACI) across all clusters, revealed distinct compositional structures. Cluster 1 showed the highest degree of construction development, with the most balanced development, of the three land types. Cluster 2 overwhelmingly exceeded the other two in terms of FACI. Cluster 3 was dominated by green space and farmland, with extremely limited construction development (Fig. 9).

# 4.2.2. Relationship analysis based on RDA

In all clusters (Table 4), the first principal component (PC1) consistently explained a greater variance than the second principal component (PC2). PC1 emphasizes the dominant effect of land development on water quality degradation. In Cluster 1, PC1's variance explanation

![](images/b474c7986bc48e052d22bb3d8cf46f228d65924c7fa389e2bd4ab7765f09f394.jpg)  
(a2) SOM Neighbour Distances

![](images/11a043b9943dc9d7cb8f5eb8d4b748c772f7cc48857687054d7211c0ac26e212.jpg)  
(a3) SOM Mapping Results (2020 and 2022)   
Fig. 7. SOM clustering analysis of the Lake Dianchi lakeshore.

![](images/45cbff03cbc2d26932e22f55500784758bd036bed32bce60488f9ea0088ec5d8.jpg)  
Fig. 8. Further clustering of the Lake Dianchi shore zone based on planning and urban land use attributes.

often surpassed $50\%$ across most years, indicating a relatively high explanatory capacity of land change within this cluster. However, a notable decline from $52.75\%$ in 2014 to $27.87\%$ in 2022 highlighted a diminishing influence over time. Conversely, Cluster 2 consistently exhibited a high PC1, remaining above $60\%$ across all years. This demonstrates robust and steady explanatory power (Table 4), suggesting a more stable and significant correlation between land development and water pollution, likely due to consistent or regulated environmental conditions in that area. Cluster 3 showed lower and more variable explanatory power for PC1, revealing an inconsistent effect of environmental variables on water quality, with land development playing a less prominent role. Given the study's focus on the interaction between lakeshore land development and water quality pollution, Cluster 2, with its high and consistent PC1, was the most typical research area.

In the 2014 dataset for Cluster 2 (Fig. 10, (a1, b1)), construction activities, both distant and proximal, closely aligned with the majority of pollution indicators along PC1, demonstrating a strong positive correlation between land development and water quality deterioration during that period. The scenario in 2016 within the same cluster largely mirrored that of 2014, although the overall explanatory capacity of land development in explaining water pollution levels decreased compared to 2014, with notable influences observed from construction activities at

medium and distant ranges. Data from 2017 and 2019 showed a positive correlation between land development and water pollution, with minimal differences in the impact of construction across different ring layers (Fig. 10, (a2, b2)), suggesting a similar degree of impact of construction activities on water quality across different areas. In the analyses of 2020 and 2022 (Fig. 10, (a3, b3)), the 2020 data exhibited significant environmental gradient fluctuations. Although the relationship between construction and water pollution remained consistent with previous years, it showed an opposite trend to PC1. This suggests that while green space and farmland appeared to have a weaker influence in RDA analysis, they remained crucial in maintaining ecological balance and providing ecosystem services. They may help mitigate pollution caused by the expansion of construction, even if this mitigating effect is not the most prominent in the PC1 of RDA. However, the 2022 data showed a return to the pre-2020 state regarding the relationship between land development and water pollution in Cluster 2, indicating that the fluctuations in 2020 did not lead to long-term substantial improvements in the Water-Land relationship.

In summary, construction is the primary driver of water quality changes in the region. Pollution shows a stronger positive response to construction activities at distances of $1600\mathrm{m}$ and $2800\mathrm{m}$ , although this "stronger" comparison with construction at $400\mathrm{m}$ is not significant.

![](images/bcdc817dd2dc9b8a3d42db991a8b464408abed7992ea982043e6604859ab32a4.jpg)

![](images/975cb6a8b546a1a57cd2214dbc2f95c4980f46929da97f1504eb3bca6d1ec570.jpg)  
(a) Clusters' Water Pollution Indicators Stastics

![](images/90c832371551349fbc5a87aaef39199cd649757f00c81c50e8fc8aedabc1cd8c.jpg)

![](images/917369ff8b0267c352abeb8bd5ffdef8503cfb84162c77c0ffe1ecb38d2a9849.jpg)

![](images/75525f00d67ce555c22c00c1d4351d9474a2bd26f092c4abb428ff577cf6f383.jpg)

![](images/87aee84d8330c8b106b98bbf5407fd511ebe2e1d4e3c07a2925ec781fb6c9c92.jpg)  
(b) Clusters' Land Developing Stastics

![](images/8008fd57f153c4c6b7a7bd098ceb527606e4614e913dfd9b71bf579ea0cb206a.jpg)  
Fig. 9. Statistical analysis of land development characteristics in lakeshore zones based on clustering.

Table 4 RDA First (X) and Second (Y) Principal Component Proportions.   

<table><tr><td>Cluster</td><td>Principal component</td><td>2014</td><td>2016</td><td>2017</td><td>2019</td><td>2020</td><td>2022</td></tr><tr><td rowspan="2">Cluster 1</td><td>X (%)</td><td>52.75</td><td>61.73</td><td>46.82</td><td>60.09</td><td>48.63</td><td>27.87</td></tr><tr><td>Y (%)</td><td>6.93</td><td>0.58</td><td>10.05</td><td>9.44</td><td>6.74</td><td>6.18</td></tr><tr><td rowspan="2">Cluster 2</td><td>X (%)</td><td>63.82</td><td>63.89</td><td>61.34</td><td>66.89</td><td>68.93</td><td>68.86</td></tr><tr><td>Y (%)</td><td>2.32</td><td>5.19</td><td>3.86</td><td>4.10</td><td>4.14</td><td>1.70</td></tr><tr><td rowspan="2">Cluster 3</td><td>X (%)</td><td>22.33</td><td>35.68</td><td>16.00</td><td>51.38</td><td>32.76</td><td>30.38</td></tr><tr><td>Y (%)</td><td>15.20</td><td>19.58</td><td>0.75</td><td>7.00</td><td>14.11</td><td>2.21</td></tr></table>

There are irregular and significant negative responses observed towards to green space at $400\mathrm{m}$ and farmland at $1600\mathrm{m}$ and $2800\mathrm{m}$ . Cluster 2, categorized as a moderately developed and semi-urbanized area with significant construction intensity and a high frequency of land use changes, has a greater impact on water bodies compared to highly urbanized and low urbanization areas, addressing diffuse source control in this area as a critical issue.

# 4.3. Lake Dianchi water quality trend analysis and future simulation

# 4.3.1. Trend changes in land types and water quality in the lakeshore zone

Over 10 years, the overall pollution change range of WPCI was from $-0.237$ to $0.449$ (Global Mean: $-0.002$ ; Littoral Mean: $0.010$ ). The trend of increasing pollution was primarily observed along the lakeshore, while decreasing trend was noted in the northern and central areas of the outer lake. Among various subcategories of pollution indicators, the most significant changes globally were in COD/VP/Cd/Pd, with lesser changes in other indicators. However, apart from COD/AN/TP, most indicators showed an increasing trend in pollution in edge areas (Fig. 11).

FACI showed a slight global downward trend (Mean $= -0.022$ ), with significant declining trends corresponding to the growth areas of GACI/

CACI. However, GACI had significant declining cold spots in the northeastern part of Kunming and the southwestern Jinning District, with a more pronounced global downward trend (Mean $= -0.035$ ). CACI showed an overall positive trend (Mean $= 0.018$ ), with reductions observed in the western rural areas and significant development in the eastern semi-urban areas.

For land development trends in the three clusters (Fig. 11, (e)), CACI almost universally showed growth, with the most significant increase observed in Cluster 2, particularly in its mid-distance circles. FACI in Cluster 2 exhibited significant declining trends across all circles, while in Cluster 1, closer to urban areas, the decline in FACI was more pronounced in the nearshore, implying occupation of lakeside farmland. GACI showed consistent multi-layer declining trends across all clusters. In Cluster 3, apart from nearshore decay and distant surge in FACI, CACI also showed a bias towards mid-distance growth (Fig. 12).

# 4.3.2. Prediction and correlation analysis of future lakeshore water quality and land development based on curve fitting

Comparing the ten-year average data from 2013 to 2022, the global WPCI fluctuated slightly from 0.349 to 0.369, with littoral pollution values remaining nearly unchanged at 0.696 to 0.692, and no significant change in spatial trends observed. FACI and GACI indices showed the

![](images/0c089ba65fb7fb2d2d2e347790b0dedd88a1bc2a69f8217d6d134ba3b1f57969.jpg)

![](images/183255b3de5efa0b4bd2e7014b5789de11bab2cff29ea6897e5bd93f107bc582.jpg)

![](images/6206d3f9672a29a4c6d2a66472ef7d23ebb35b3d4879c24c0c0fd21299a1f1d3.jpg)

![](images/2227f4a4ecea6387633ecff1e3014b5b144f9ccd727413d104aadff3f2e694e0.jpg)

![](images/6f2ea45be983dcd26948040217e4ba9fb84e13b1874b95d458cfd27e76cdc07c.jpg)

![](images/261065f171e89e208d5e6d94c85483db2aa6f7227604ae23e95ef4ef7e35f00e.jpg)

![](images/09198491a662cc82950a068aa70a225d2482bb746d6df6979c6aeffa1167246c.jpg)

![](images/d3f98f65503554ae515cdb997000b5b66cbd608fe7bb9774c9f36d43095523ad.jpg)

![](images/14b59251896ac7c09aeb6745d9c0652aa72deaacaf6defc3d48fc99c7f87cc51.jpg)

![](images/f4120b4450d07c885cf779090904d50703ff2de16f5dd7b0b43ad8b5efb3623f.jpg)

![](images/80f48f7522d76fe9eb0226d60f5f89c8c2720e51f2913a259b971e33b2d2e510.jpg)

![](images/7ee12c857ba97ab20ad408edfcfe38f763b2f05ff1a5d3914faf4bd1293737ce.jpg)

![](images/de9e1a1b19bda35fc928167d35bec5bd5fac0c263da7080b1f95d5ba40de2ea2.jpg)

![](images/59616fc1a3b31949b603445d08ec2a82581f26f5a0d49d4d893b39f6f2ee8736.jpg)  
Fig. 10. RDA of land types and water pollution indicators in lakeshore zones during typical periods.

disappearance of some hot spot areas, with a decline in global averages (FACI: 0.549 to 0.481; GACI: 0.408 to 0.349). In the semi-urbanized area (Cluster 2), where many FACI hot spots disappeared, CACI showed a significant increase (0.228 to 0.267) in hotspots. The asynchronous development trend of Water-Land further intensified (Fig. 13).

In Cluster 1, pollution indicators were mainly related to distant construction and distant green space, but they did not align with environmental variables and therefore showed no response. Cluster 2 exhibited similarities, but farmland played a notable role, with COD showing a positive response to distant farmland, while other indicators showed a negative response. In Cluster 3, the explanatory power of the principal component increased, with near construction and mid to

distant farmland starting to show positive or negative associations with certain water pollution indicators. However, green spaces remained insignificant, acting as a disturbance factor across all clusters (Fig. 14).

# 5. Discussion

Analyzing the spatiotemporal changes in different land development characteristics and water quality is crucial for revealing the water-land relationship (Lee et al., 2009). Some studies have confirmed the correlation between construction around Lake Dianchi and water pollution indices (Li et al., 2012), while others have noted that the impact of land use and landscape pattern indices on water quality varies with scale (Shi

![](images/bf16ffd5a8fda316b291682dd115d4f035e4a5531092a5924ad470def275c7fb.jpg)  
(a) WPCI Theil-Sen's Slope $\mathbf{\Psi}_{\mathrm{(X10)}}$ & Tyson Map

![](images/d447e4e67b70a4089058ab723463b547b79b360abdd768957e5fe6ea4028d155.jpg)

![](images/d22caa48529709157cfdb4d34c559557dc65261bf133a543758b740f70bd3638.jpg)

![](images/3190a5b07f91fe4013449d751008746fb90f32ddb67a5c97de5f826ce4600f93.jpg)  
Inorganic Pollution

![](images/531f46adb0c540326014ac140a03296ba828351c326238211e8cb09e28107da6.jpg)

![](images/059254cbf8ae31e11f57f678fcc4fbd7365e1e2eaa9efa0e2515d43afce4e209.jpg)  
Heavy Metal Pollution

![](images/d14865c8f166260bb4b7b92521332fb21b0dd9dde0a39e665ce469975020c589.jpg)

![](images/05d4277e2591506e2b8f6e65f95b26d3e81695af6195aa9cc4f09ca4a63e8ab2.jpg)

![](images/2cc2d8aed7f68d3a176edc28977e07b095434ea0d0fffab5d5c64ffa6a429b2e.jpg)  
Fig. 11. Global analysis of WPCI in the past 10 years.

![](images/544983493cd7220d484b75e646e79fc74b1f8e996d4d6bbfcd93de53e76a4381.jpg)  
Fig. 12. Theil-Sen's slope of FACI/CACI/GACI in the past 10 years.

![](images/361ba9d731219723d7bdfaa4e381ac6d60569ab6b04c114e6348faae40747d86.jpg)

![](images/b96735dcbee69f0f3036f0f1c352ebcac3b037b3f174c10ad3eaeef6311d4f32.jpg)

![](images/8d15df167f03c2e08ed2b8d5ba06971bf995340a26ccc6d20c8006b93ef5e460.jpg)  
Fig. 13. Analysis on the gradual de-correlation trend between land development and water quality in the lakeshore zone.

![](images/b60c124287d471f4e5c6a5fdde229158a41ee70428752ff3b36f0afcd9d74018.jpg)  
(d1) 2027 Cluster 1   
Correlation

![](images/457d67d37d38c218526e5b7ada1454487c1781b10cfac4405deb4f0b4df7a247.jpg)  
(d2) 2027 Cluster 2

![](images/3737a05cb0cd28c3ee76f42532b9ca525141c914ce5c070222c2014b74f642e3.jpg)  
(d3) 2027 Cluster 3

![](images/ce950976c0c70240f521212f0d3b6d779696ca9e0f0fe0e205ece1228eb184e4.jpg)  
Legend   
Green Space

![](images/e54da2236cb6df47db1b24832381445b306c2394bfde5684d86d9cdaf7406074.jpg)  
Construction   
Farmland   
Relevance Legend:   
Fig. 14. RDA of various types of land development and water pollution indicators in the lakeshore zone based on trend prediction conditions.

and Li, 2012). However, this study adopts novel methods and multiscale perspectives (Yang et al., 2022), extending and deepening these findings. It comprehensively assesses the association between multi-year land development and spatial changes in water quality from the entire domain and at multiple scales.

# 5.1. Dynamic trend of de-correlation between water and land

The lakeshore, affected by land development and human activities, serves as a critical receptor for land-based pollution (Ma and Wang, 2015). However, our research indicates that despite an increase in the Lake Dianchi Surrounding CACI over time, water pollution has gradually become less correlated with land development. Additionally, global data shows periodic fluctuations in the WPCI over time. This trend may be

related to the dynamics of industrial activities and surrounding areas or phased advancement of environmental policies. Special events also play a role in water quality changes (Fernandes et al., 2021). Therefore, the Lake Dianchi water-terrestrial system is exhibiting a trend of asynchronous development and temporal decoupling. This suggests that land impacts may have delayed effects (Yang et al., 2010). Nevertheless, lakes, as complex systems of biotic and abiotic elements, have maintained the stability of their core functions and structures despite external disturbances (Kim et al., 2020).

However, the observed detachment-related situations also need to be separately addressed. Research indicates that different degrees of urban land development have varying impacts on water quality, with Cluster 2 having a greater impact than Cluster 1 and Cluster 1 having a greater impact than Cluster 3. Urbanized areas (cluster 1) and areas with high

natural vegetation (cluster 3) showed a low correlation with water pollution. Moderately developed areas (cluster 2), undergoing urban-rural transformation, show a significant water-land correlation, with RDA's pc1 explaining over $60\%$ of the variance. This aligns with previous research, which shows that natural vegetation has a positive impact on water quality (Zhong et al., 2022), while construction has a negative impact on water quality, but water pollution changes lag behind land development, reflecting in water quality stability and pollution incubation period (Luo et al., 2018). In economically developed areas (cluster 1), sewage treatment facilities (Ma and Wang, 2015) reduce point source and some non-point source pollution, thereby mitigating water pollution risks. Therefore, attention to semi-urban and semi-rural areas around the lake is crucial, given the risk associated with infrastructure development and non-point source pollution from buildings and farmland.

Therefore, we recommend formulating policies that consider the stable-state cycles of Lake Dianchi and dynamically implementing environmental measures to address varying water quality conditions and pollution sources. During periods of peak pollution, it is crucial to manage "acute" pollution sources swiftly to mitigate pollution levels. In contrast, during periods of lower pollution, long-term strategies should focus on the negative impacts of semi-urbanization rather than urban areas. Additionally, we advocate for the cautious implementation of ecological restoration and protection projects, such as lakeside wetland restoration, afforestation, and the creation of ecological corridors. According to response analysis, high-quality green space development can mitigate the adverse effects of land development on water quality; however, its direct impact on water quality pollution is not significant. Compared to the quantity of green spaces, optimizing the structure and quality of green spaces through the construction of "blue-green networks" (Huang et al., 2024) is more effective.

# 5.2. Distance and scale effects of lakeshore land development on water

Previous studies have demonstrated that the water quality of Lake Dianchi is significantly affected by the scale effect of land development (Liu et al., 2023; Yi, 2011). Additionally, some researches have explored how the landscape pattern can have long-range or local effects on water quality (Cao et al., 2012; Li et al., 2023), indicating that water pollution responds to long-range effects on land. This study rigorously segmented various ring layers around Lake Dianchi to conduct multi-year scale analyses on construction, farmland, and green space. In Cluster 2, RDA revealed a consistent positive correlation between construction and most water pollution indices across different distances, indicating a significant impact irrespective of scale. Conversely, farmland and green space exhibited negative correlations with construction, suggesting a disturbance relationship with water quality without significant improving the environment. Water pollution indices displayed varied responses to farmland and green space at different scales: $400\mathrm{m}$ green spaces showed a negative response, while $1600\mathrm{m}$ and $2800\mathrm{m}$ farmland also responded negatively. However, $400\mathrm{m}$ farmland exhibited an irregular positive response, indicating the dual nature of farmland as both a purification and a pollution source.

During the Eleventh Five-Year Plan period, Kunming established a comprehensive ecological belt along the Lake Dianchi shoreline, averaging approximately $200\mathrm{m}$ in width and covering an area of $33.3\mathrm{km}^2$ . Additionally, land use in the surrounding areas can be managed through zoning based on their distance from the lakeshore. In areas within $400\mathrm{m}$ of the lake, priority should be given to restricting on the development of construction land. Initially, these areas can be used for agricultural production, which can gradually be replaced with wetlands and green spaces to mitigate direct impacts on water quality.

# 5.3. The correlation and hysteresis potential between water and land

The Lake Dianchi ecosystem demonstrated nonlinearity and unpredictability in response to short-term land development and policy changes (Liu et al., 2021). Understanding and predicting the trends of Water-Land relationships is crucial for interpreting the current environmental state and formulating future environmental management strategies (Liu et al., 2015).

Theil-Sen Median method analysis showed that water pollution growth was concentrated along the shores of Lake Dianchi. In terms of land development, FACI showed a slight global decline, and GACI's declining trend was more pronounced, especially noticeable in the northeastern part of Kunming and the southwestern part of Jinning District. CACI showed a growth trend in almost all circle layers. Prediction results indicated a steady increase in water pollution, highlighting that water pollution control is a long-term task. While orderly land development has limited direct effects on water quality improvement, it plays an important role in mitigating the exacerbation of water pollution (Fernandes et al., 2021). A long-term comprehensive management plan is essential to effectively control water pollution during various stages of land development. Plateau lakes have a fragile ecological resilience and can respond quickly to nearby land development, with initial impacts resulting from even short-term changes. In addition, the lagged effects of land impacts require a long-term dynamic monitoring system to continuously track changes in land use and water quality.

Trend analysis showed that the impact of construction on water quality was gradually decreasing, farmland exhibited the dual nature of a purification and a pollution source. The positive effect of green space, especially its long-range effect, was more significant. However, as the relationship between water and land gradually became less correlated, the impact of land change on water pollution gradually weakened. Curve fitting reflects the future trend of asynchronous development of dual systems (Batáry et al., 2015; Moreno-Mateos et al., 2008). With the improvement of land pollution control regulations and infrastructure, the industrial structure behind land development will become the key to water pollution control in Lake Dianchi.

# 6. Conclusion

This study investigates water pollution dynamics around Lake Dianchi, Yunnan, using multi-source data, including satellite imagery, ground monitoring, and land use within a $3\mathrm{km}$ buffer zone. Employing SOM, RDA, Pearson correlation, M-K tests, and Theil-Sen Median method, we evaluated land development impacts on water quality and predicted future Water-Land relationships up to 2027.

Different from previous studies, our research emphasizes the comprehensive results of land development while focusing on changing patterns and future trends in time and space. Several findings have been obtained. The development of lakeshore areas closely correlates with the water quality of Lake Dianchi, yet a gradual disconnection in the development trends suggests a time lag between land development and subsequent changes in water quality. Through SOM classification, specific pollution indicators closely align with their spatial distribution across different cluster groups. The intensity of land development and corresponding changes in water quality along the lakeshore zone exhibit uneven spatial distribution. M-K test and Theil-Sen Median trend calculation reveal significant changes in indicators such as $\mathrm{Pd / Cr(VI)}/$ VP/COD. The area where FACI decreases overlaps with areas where GACI/CACI increases, indicating heavy occupation of cultivated land. However, the 2027 forecast indicates that the spatial characteristics of land development and water quality changes will be basically stable.

