# A new meta-coupling framework to diagnose the inequity hidden in China_s cultivated land use

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:36:29.556084+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Chuai et al. - 2021 - A new meta-coupling framework to diagnose the inequity hidden in China_s cultivated land use.pdf
- Year: unknown
- DOI: 10.1016/j.envsci.2021.08.001
- OA status: green
- License: cc-by-nc-nd
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This study develops and applies a meta-coupling framework to reveal hidden inequities in cultivated land use across China. The work is explicitly grounded in metacoupling/telecoupling theory, integrating intra-coupling within regional agricultural systems and tele-coupling among regions through domestic trade.

The geographic scope is mainland China, with 31 provincial-level regions as the basic units. The system boundary is the agricultural sector and its associated environmental impacts. Data include provincial statistics on cropland area, major agricultural inputs (water, diesel, machinery power, fertilizers, pesticides, plastic film), grain output, agricultural economic output, and nitrogen and phosphorus emissions, combined with a multiregional input-output (MRIO) table for 2012.

Methods are threefold. First, intra-coupling among agricultural elements is examined through correlation and nexus-style analysis at the national scale. Second, the MRIO model is used to track interprovincial flows of embodied cultivated land, inputs, outputs, and pollution, thus quantifying tele-coupled linkages and net exporters/importers. Third, Data Envelopment Analysis (DEA) assesses provincial cultivated land use efficiency, incorporating resource inputs and pollution as costs, and a new aggregation method summarizes multi-element inequity in interregional trade.

Results show that cultivated land strongly structures the whole agricultural nexus, driving input levels and outputs, including emissions. Tele-coupling analysis indicates that less developed, land-rich provinces in northern and central China (such as Heilongjiang, Inner Mongolia, Hebei) are major net suppliers of embodied cropland, inputs, and pollution, while developed eastern coastal regions (such as Jiangsu, Zhejiang, Guangdong, and large cities) are dominant receivers. High-yield, high-efficiency agriculture is often located in relatively poor or ecologically vulnerable regions. Many net supplier provinces bear substantial resource depletion and environmental burdens but receive comparatively limited economic gains, while developed regions benefit disproportionately.

The study illustrates how a meta-coupling lens can diagnose spatially displaced benefits and burdens in national food systems and argues for compensation, technology transfer, and region-specific policies to address agricultural inequity within China.

## Structured Metacoupling Extraction

### Coupling Classification
- Meta coupling of Chinas agricultural system linking intra and telecoupling, no explicit pericoupling.

### Intracoupling
#### Systems
- National agricultural system of China as a single coupled human natural system
- Provincial agricultural production units evaluated by DEA
#### Flows
- Internal use of land, water, energy, fertilizers, pesticides, film, diesel
- Generation of grain output, economic value, carbon, nitrogen, phosphorus emissions
#### Agents
- Farmers and agricultural producers within each province
- Provincial and national agricultural authorities
#### Causes
- Food security goals for a large and growing population
- Drive to raise yields on limited and shrinking cropland
- Intensive input based agricultural modernization policies
#### Effects
- Strong positive correlations among land, inputs, yields, emissions
- High resource consumption and pollution in high yield regions
- Spatially uneven cultivated land use efficiency across provinces

### Pericoupling
#### Systems
- Not identified.
#### Flows
- Not identified.
#### Agents
- Not identified.
#### Causes
- Not identified.
#### Effects
- Not identified.

### Telecoupling
#### Systems
- Cultivated land systems of developed eastern provinces
- Cultivated land systems of less developed central, northern, western provinces
- National interregional trade network represented by MRIO
#### Flows
- Embodied cultivated land transferred via interprovincial trade
- Embodied water, fertilizers, film, pesticides, energy and associated emissions
- Economic value flows of agricultural products between provinces
#### Agents
- Provincial governments influencing trade and agricultural policies
- Agribusinesses and traders mediating interprovincial commodity flows
- National planners designing compensation and technology transfer
#### Causes
- Regional disparities in natural endowments and hydrothermal conditions
- Uneven urbanization, population concentration, and local cropland loss
- Market driven specialization and comparative advantage in crop production
#### Effects
- Net resource and pollution export from less developed to developed regions
- Developed provinces gain food and economic benefits with outsourced environmental burdens
- Pronounced spatial inequity in agricultural costs and profits

### Cross-Coupling Interactions
- Intra coupling efficiencies shape which provinces become telecoupling suppliers or receivers
- Telecoupled trade redistributes environmental costs from high demand cities to rural hinterlands
- Combined intra and tele analyses reveal hidden inequity in cultivated land use

### Research Gaps or Limitations
- No explicit pericoupling or adjacent region interactions are modeled
- MRIO data and sector aggregation introduce uncertainty in flow estimates
- Analysis is static for 2012, lacking temporal dynamics of meta coupling

### Search Keywords
- China cultivated land meta coupling inequity MRIO
- interregional embodied land water pollution trade
- DEA agricultural efficiency telecoupling framework

### Extraction Confidence
high
