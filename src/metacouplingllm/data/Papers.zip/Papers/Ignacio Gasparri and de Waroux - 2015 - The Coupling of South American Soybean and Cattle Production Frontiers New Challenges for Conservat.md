# The Coupling of South American Soybean and Cattle Production Frontiers New Challenges for Conservat

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:47:46.583965+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Ignacio Gasparri and de Waroux - 2015 - The Coupling of South American Soybean and Cattle Production Frontiers New Challenges for Conservat.pdf
- Year: unknown
- DOI: 10.1111/conl.12121
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Commentary\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This policy perspective examines how soybean cultivation and cattle ranching in South America have become interconnected drivers of deforestation, and what this means for conservation policy and land change research.

Geographically, the paper focuses on key production frontiers in Argentina, Brazil, Paraguay, and Bolivia. It situates these frontiers within global commodity chains increasingly shaped by Chinese and European demand and by regional trade and investment links.

The authors propose two related ideas. First, soybean farming and cattle ranching now form a coupled driver system. Rather than acting as independent competitors for land, they are connected through land transactions, shared firms, and capital flows. Conversion of pasture to cropland can either intensify land use with limited new deforestation or, through capital transfers from crop producers to ranchers, indirectly finance further clearing of forest for new pasture. Remote sensing and statistics reveal patterns of forest-pasture-cropland transitions, while company-level evidence shows that many major agribusiness firms operate in both soy and cattle and across countries.

Second, the paper extends this to telecoupling between multiple frontiers. Production regions are linked not only through shared external demand but also by trade relationships and cross-border land acquisitions. Argentine and Brazilian firms invest heavily in land and production in Paraguay and Bolivia, integrating those areas into wider soybean-cattle commodity systems.

The analysis emphasizes that current conservation tools, such as national zoning, forest laws, voluntary moratoria, and sustainability labels, typically regulate individual territories or supply flows in isolation. In a context of coupled and telecoupled frontiers, these measures can shift deforestation elsewhere, accelerating leakage rather than reducing regional forest loss.

The contribution is conceptual and policy oriented rather than empirical. It is explicitly about telecoupling and metacoupling: it frames soybean-cattle land use change as a multi-actor, multi-location network of interactions and argues that effective conservation must target actors and capital flows across coupled frontiers, not just local land parcels.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling of South American soybean and cattle frontiers with global demand, especially China

### Intracoupling
#### Systems
- Soybean and cattle as one coupled driver system within South American frontiers
- Local land pool of forest, pasture, cropland within each frontier
#### Flows
- Land conversion among forest, pasture, cropland (F->P, F->C, P<->C)
- Capital transfers from soybean farming to cattle ranching via pasture sales
#### Agents
- Integrated agribusiness firms active in both soy and cattle
- Local soybean farmers and cattle ranchers
#### Causes
- Economies of scope between soy and cattle production
- Technological change enabling cultivation of former pastures
#### Effects
- Deforestation amplification when pasture expansion exceeds pasture loss to crops
- Land use intensification with increased cropland and relatively lower deforestation
- New channels for capital-driven forest loss despite local regulations

### Pericoupling
#### Systems
- Neighboring South American frontiers in Argentina, Brazil, Paraguay, Bolivia
- Adjacent ecoregions such as Amazon, Atlantic Forest, dry forests
#### Flows
- Regional trade of soybeans and inputs between bordering countries
- Relocation of companies and ranching operations to nearby frontiers
#### Agents
- Transnational South American agribusiness groups
- National governments implementing frontier-specific zoning laws
#### Causes
- Land price and regulatory differences across neighboring frontiers
- Shared infrastructure and regional trade agreements
#### Effects
- Deforestation leakage from regulated to less-regulated neighboring ecoregions
- Spatial reorganization of soy and cattle frontiers across borders

### Telecoupling
#### Systems
- South American soy-cattle production frontiers and distant consumer markets
- Producer regions in SA and global financial institutions
- Two-region model with capital-rich frontier and cheaper-land frontier
#### Flows
- Exports of soybean grain and products to China and Europe
- Soy and cattle product trade between SA countries via processing hubs
- Transnational land acquisition, investment, technology and knowledge transfer
#### Agents
- Large Argentine and Brazilian agribusiness investors operating abroad
- Chinese and European demand actors shaping commodity chains
- Banks and lenders applying or ignoring environmental standards
#### Causes
- Rising global demand for food, feed, and meat
- Internationalized, diversified agricultural value chains
- Asymmetries in capital, technology, processing capacity between regions
#### Effects
- Coupled deforestation dynamics across distant frontiers
- Leakage when one region adopts moratoriums or zero-deforestation rules
- Increased complexity for designing effective conservation policies

### Cross-Coupling Interactions
- Soy-cattle coupling within frontiers interacts with telecoupling through demand, trade, and land acquisition
- Local territorial policies interact with flow-centered measures, creating leakage pathways
- Actor-level integration links multiple sectors and regions under single decision structures

### Research Gaps or Limitations
- Limited public data on capital flows and land acquisitions by agribusiness actors
- Remote sensing and statistics poorly capture cross-frontier coupling processes
- Need empirical testing of proposed coupling and leakage framework

### Search Keywords
- South America soy cattle telecoupling
- deforestation leakage coupled frontiers
- agribusiness land use change conservation policy

### Extraction Confidence
high
