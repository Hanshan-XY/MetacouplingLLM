# Fishery and agriculture amidst human activities and climate change in the Mekong River A review of

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:00:17.662249+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Morovati et al. - 2024 - Fishery and agriculture amidst human activities and climate change in the Mekong River A review of.pdf
- Year: unknown
- DOI: 10.1016/j.jhydrol.2024.132043
- OA status: closed
- License: none recorded
- Category: Journal Articles\Review\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This review examines how fisheries and agriculture in the Lancang-Mekong River Basin (LMRB) are being reshaped by dams, other human activities, and climate change, with a focus on data gaps and implications for sustainable development.

Geographically, the paper covers the full basin from the Chinese Lancang headwaters through Myanmar, Laos, Thailand, Cambodia, and the Vietnamese Delta. It situates fisheries and agriculture as core to regional food security and trade, but highly vulnerable to altered flows, sediment trapping, and changing climate extremes.

Using a systematic literature review (over 200 English and Chinese sources from Web of Science, Scopus, Google Scholar, and reports), the authors synthesize evidence on hydrological change, fish populations, cultivated area, and climate impacts. They find that in the Lancang segment more than four-fifths of fish production now comes from aquaculture, with total fish output rising despite strong river fragmentation and indigenous species loss. Cultivated area there has been relatively stable. By contrast, the lower Mekong shows expanding agricultural land and irrigation, yet declining inland fish catches in Cambodia and Thailand and severe losses in some Tonle Sap fish populations.

Dams and water infrastructure have improved energy supply, irrigation, and flood control but disrupted longitudinal and lateral connectivity, modified flood pulses, and trapped large fractions of sediment once reaching the floodplains and Delta. Climate change is intensifying floods and droughts, altering inundation patterns critical for rice and floodplain fisheries. The review highlights serious data limitations: reliance on daily, not sub-daily, flow and level records; sparse, inconsistent fishery and irrigation data; and weak sediment monitoring.

The paper explicitly engages metacoupling/telecoupling. It argues that most studies ignore cross-sub-basin linkages and upstream-downstream dependencies, even though dams, irrigation expansion, and trade-driven fish and rice demand create strong interconnections. The authors call for basin-wide, transboundary flow-regime design and coordinated policies that account for migratory fish, sediment-nutrient delivery, and shared water use, rather than isolated sub-basin projects.

## Structured Metacoupling Extraction

### Coupling Classification
- Strongly telecoupled basin; also important intra- and peri-couplings among Mekong sub-basins

### Intracoupling
#### Systems
- Lancang upper Mekong within China
- Lower Mekong sub-basins including Tonle Sap and Delta
- Individual reservoirs and their local floodplains
#### Flows
- Local river discharge and water level variations
- Sediment and nutrient transport within sub-basins
- Fish biomass and agricultural water use
#### Agents
- Local farmers and fishers
- Provincial and national water agencies
- Hydropower operators at individual dams
#### Causes
- Local dam construction and operation decisions
- Indiscriminate fishing and gear choices
- Land use change, irrigation expansion, groundwater extraction
#### Effects
- Changes in fish community composition and extinction risk
- Altered soil fertility and erosion in floodplains
- Local flood and drought impacts on crops and livelihoods

### Pericoupling
#### Systems
- Adjacent Mekong sub-basins such as 3S Rivers and Nam Ngum
- Tonle Sap Lake and Vietnamese Delta interface
- Upstream Lancang reaches and downstream lower Mekong
#### Flows
- Seasonal flood pulse and reverse flows between lake and Delta
- Runoff contributions from tributaries to mainstream
- Cross-border fish migration along river corridors
#### Agents
- Riparian provincial governments along borders
- Mekong River Commission technical bodies
- Cross-border fishing and farming communities
#### Causes
- Tributary dams modifying downstream hydrology
- Dyke and canal networks fragmenting floodplains
- Uneven irrigation development between neighboring countries
#### Effects
- Reduced connectivity for migratory fish between sub-basins
- Changed inundation timing affecting shared rice areas
- Downstream salinity and subsidence linked to upstream trapping

### Telecoupling
#### Systems
- Entire Lancang-Mekong River Basin as sending and receiving system
- Global fish and rice markets linked to Mekong production
- External climate systems influencing basin hydroclimate
#### Flows
- Export of fishery products and rice to international markets
- Teleconnected climate signals like ENSO affecting rainfall
- Policy and investment flows driving dam cascades
#### Agents
- National governments pursuing energy and food security
- International donors and development banks
- Global seafood and rice supply chains
#### Causes
- Rising external demand for hydropower and cheap protein
- Global climate change altering floods and droughts
- Lack of basin-wide coordination in infrastructure planning
#### Effects
- Threats to Delta rice that supplies global markets
- Migration and livelihood risks for downstream communities
- Basin-wide fishery declines tied to distant drivers

### Cross-Coupling Interactions
- Upstream dams and small barriers fragment migrations, reducing fish catches in distant floodplains and Delta
- Sediment trapping in upper and mid-basin reservoirs amplifies coastal erosion and salinization downstream
- Climate-driven floods and droughts interact with dam operations to reshape basin-wide food security

### Research Gaps or Limitations
- Telecoupling among sub-basins and to external systems rarely quantified in existing hydrology and food studies
- Sparse, inconsistent data on withdrawals, irrigated areas, sediment, and sub-daily flows limit basin-wide modeling
- Most analyses focus on single dams or sub-basins, lacking integrated multi-country basin planning

### Search Keywords
- Mekong telecoupling fisheries agriculture dams sediment climate change
- Lancang hydropower connectivity Tonle Sap Delta food security
- sub-daily flow regime migratory fish irrigation sediment trapping

### Extraction Confidence
high
