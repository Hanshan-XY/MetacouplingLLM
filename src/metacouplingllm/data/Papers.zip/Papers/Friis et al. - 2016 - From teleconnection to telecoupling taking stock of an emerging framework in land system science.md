# From teleconnection to telecoupling taking stock of an emerging framework in land system science

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:44:56.582073+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Friis et al. - 2016 - From teleconnection to telecoupling taking stock of an emerging framework in land system science.pdf
- Year: unknown
- DOI: 10.1080/1747423X.2015.1096423
- OA status: closed
- License: none recorded
- Category: Journal Articles\Review\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This review paper examines how land system science has shifted from using the notion of teleconnection to the more expansive framework of telecoupling to understand land use change under globalization. It is explicitly about telecoupling and its future development.

The authors focus on land systems as coupled human-environment systems worldwide, with no single geographic case study. Instead, they synthesize conceptual and empirical work from land system science and related fields. They trace how classical place-based approaches and concepts such as proximate-underlying drivers and land use transitions have become insufficient as trade, information, capital, and governance increasingly link distant places.

The paper first reviews how teleconnection was adopted from climate science to describe distant environmental and socioeconomic linkages, especially through trade and urban-rural interactions. It then analyzes telecoupling as a broader framework that emphasizes reciprocal flows, feedbacks, and multiple interacting systems. Two main variants are identified: a structured, component-based approach (systems, flows, agents, causes, effects) and a more open, process- and network-oriented heuristic approach.

The authors highlight key challenges for applying telecoupling: the risk that the structured approach becomes a superficial checklist; ambiguities and power asymmetries when labeling systems as sending, receiving, or spill-over; and difficulties in defining system boundaries, scales, and time horizons in a highly interconnected world.

To address these problems, the paper argues for a more interdisciplinary telecoupling framework. It draws on economic geography (global value chains and production networks), socio-economic metabolism (material and energy flows and long term transitions), political ecology (power, distribution conflicts, historical trajectories), and cultural anthropology (exchange systems, scapes, and social notions of space). These perspectives are proposed as tools to deepen analyses of flows, agency, and scale in telecoupled land systems.

Overall, the article positions telecoupling as a promising but still evolving metacoupling framework that must integrate insights from multiple disciplines to robustly capture distant interactions driving land use change.

## Structured Metacoupling Extraction

### Coupling Classification
- Primarily a conceptual telecoupling review; distinguishes teleconnection and telecoupling in land system science.

### Intracoupling
#### Systems
- Local land systems treated as coupled human environment units.
- Urban regions and their immediate hinterlands.
- National land systems within their own governance context.
#### Flows
- Local land use drivers and feedbacks.
- Internal governance and policy processes.
- Place based livelihood and land management practices.
#### Agents
- Local farmers and land managers.
- Municipal and national authorities.
- Local communities and resource users.
#### Causes
- Local proximate land use drivers.
- National policy and regulatory change.
- Socioecological regime shifts within a region.
#### Effects
- Land use transitions within territories.
- Local environmental and social impacts.
- Changes in local vulnerability and adaptation.

### Pericoupling
#### Systems
- Cities and nearby hinterlands linked by urban land teleconnections.
- Neighboring regions connected through regional trade.
- Adjoint jurisdictions sharing governance arrangements.
#### Flows
- Regional commodity and labor exchanges.
- Short distance resource and information transfers.
- Cross boundary environmental spillovers.
#### Agents
- Regional planners and authorities.
- Firms operating across neighboring regions.
- Regional civil society networks.
#### Causes
- Regional integration and infrastructure development.
- Policy coordination across adjacent jurisdictions.
- Expansion of urban and peri urban areas.
#### Effects
- Shifts in regional land use patterns.
- Redistribution of environmental pressures locally and regionally.
- Emergence of cross boundary governance challenges.

### Telecoupling
#### Systems
- Distant coupled human environment systems such as exporting and importing countries.
- Sending, receiving and spillover land systems in global commodity chains.
- Telecoupled urban and rural regions worldwide.
#### Flows
- International trade of agricultural and forest products.
- Long distance flows of capital, information, people and policies.
- Embodied biomass, energy and material transfers.
#### Agents
- States, corporations and traders organizing global supply chains.
- International organizations and transnational NGOs.
- Consumers and investors influencing distant land systems.
#### Causes
- Globalization and spatial decoupling of production and consumption.
- Distal economic, political, technological and cultural drivers.
- Policy changes in one country affecting land elsewhere.
#### Effects
- Deforestation leakage and forest transitions influenced by distant demand.
- Asymmetric power relations and ecological distribution conflicts along commodity frontiers.
- Complex multi directional feedbacks complicating land governance.

### Cross-Coupling Interactions
- Telecouplings overlay intracoupling dynamics, creating multi level feedbacks.
- Pericouplings can evolve into telecouplings as trade and governance scales expand.
- Global production networks link many telecouplings into intersecting flow based systems.

### Research Gaps or Limitations
- Difficulty defining system boundaries, roles and scales in telecoupling studies.
- Risk that structured frameworks become checklists, oversimplifying complex processes.
- Need for deeper integration with economic geography, metabolism, political ecology and anthropology.

### Search Keywords
- telecoupling framework land systems globalization
- teleconnection spatial decoupling land use change
- global production networks socioecological metabolism political ecology anthropology

### Extraction Confidence
high
