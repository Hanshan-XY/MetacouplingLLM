# Telecoupling indirect ecological impacts of urban expansion in China from the perspective of the foo

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:48:14.035961+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Jia et al. - 2023 - Telecoupling indirect ecological impacts of urban expansion in China from the perspective of the foo.pdf
- Year: unknown
- DOI: 10.1002/ldr.4822
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper analyzes how urban expansion in China indirectly drives ecological degradation in other regions through cropland displacement and food trade, explicitly using a metacoupling-telecoupling lens.

The study covers mainland China and the rest of the world (ROW) from 2000 to 2019. Urban land growth is treated as the local system, surrounding rural areas within the same province as nearby systems, other Chinese provinces and foreign countries as distant systems. Direct ecological loss is the ecological land (non-cropland natural land covers) converted to urban use. Indirect loss arises when productive cropland is urbanized, grain production is lost, and new cropland is created elsewhere by clearing ecological land.

The authors combine 30 m national land cover data, downscaled gridded crop yield data for four staple grains, terrain and soil information, and national statistics on grain production, consumption, and trade. They construct a high-resolution map of cropland yield, then estimate grain loss from urban encroachment and grain gained from new cropland. A linear programming model simulates a 31-region (provinces plus ROW) food trade network that balances supply and demand while minimizing transport costs and diet-structure dissimilarity. Using a metacoupling framework, they distinguish near indirect ecological loss (within-province cropland compensation) and distant indirect ecological loss (in exporting regions supplying grain to deficit provinces).

Results show that about four-fifths of new urban land came from cropland, causing large grain losses. New cropland expansion, often in ecologically sensitive northern and western areas or forested southern regions, converted roughly 86,600 km2 of ecological land nationwide. Indirect ecological losses were around four times direct losses nationally and on average 8.4 times at the provincial level, with especially high ratios in developed coastal and some central-southwest provinces. While most indirect loss is near, distant losses exceed half of total indirect loss in Beijing, Shanghai, Tianjin, and Jiangsu. Eastern coastal urbanization shifts ecological burdens mainly to northeastern China and the ROW via food trade.

The paper is clearly about metacoupling and telecoupling, operationalizing intracoupling (direct loss), pericoupling (near displacement), and telecoupling (trade-mediated distant impacts) to inform cross-regional ecological compensation and more sustainable urban and agricultural policies.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via food trade and cropland displacement driven by Chinese urban expansion

### Intracoupling
#### Systems
- Urban land and ecological land within each Chinese province
- Provincial cropland and local grain production systems
#### Flows
- Conversion of cropland and ecological land to urban land
- Local grain loss and cropland expansion within province
#### Agents
- Provincial governments and planners
- Urban residents and local developers
- Local farmers converting land
#### Causes
- Rapid population growth and economic development
- Urban expansion mainly onto high yielding cropland
#### Effects
- Direct loss of forests, grasslands, wetlands, water bodies
- Local grain production decline near expanding cities

### Pericoupling
#### Systems
- Urban areas and adjacent rural areas inside same province
- Neighboring land-use mosaics around city fringes
#### Flows
- Cropland displacement from city fringes to nearby rural areas
- Movement of ecological loss from core cities to peri-urban zones
#### Agents
- County and municipal planners
- Rural landholders participating in cropland compensation
#### Causes
- Cropland protection and balance policies within provinces
- Priority to compensate grain loss internally before importing
#### Effects
- Near indirect ecological loss in rural ecological land
- Expansion of cropland into nearby forests and grasslands

### Telecoupling
#### Systems
- Developed coastal provinces and inland grain-surplus provinces
- China and rest-of-world agricultural export regions
- National food trade network linking all provinces
#### Flows
- Interprovincial grain trade for rice wheat maize soybean
- International grain imports embodying ecological loss
- Telecoupled cropland displacement and habitat conversion
#### Agents
- National government and trade authorities
- Food traders and logistics companies
- Farmers in exporting northeastern and overseas regions
#### Causes
- Urban grain deficits from cropland loss in developed regions
- Yield differences between lost cropland and new cropland elsewhere
- Policies like arable land balance pushing remote compensation
#### Effects
- Distant indirect ecological loss in northeast China and abroad
- Deforestation and grassland conversion for new cropland
- Regional ecological inequality between consuming and producing regions

### Cross-Coupling Interactions
- Local urban encroachment triggers nearby cropland expansion and distant cropland reclamation
- Food trade redistributes ecological costs from coastal cities to northeastern and foreign regions
- Telecoupled impacts feedback into national debates on ecological compensation and land policy

### Research Gaps or Limitations
- Assumes grain loss is offset only by new cropland or imports, not management improvements
- Trade network simulated for four staple grains, excluding other important crops
- Ecological impact measured mainly as area of ecological land lost, not multi-dimensional services

### Search Keywords
- telecoupling urban expansion China cropland displacement
- indirect ecological loss food trade network
- near distant ecological loss metacoupling framework

### Extraction Confidence
high
