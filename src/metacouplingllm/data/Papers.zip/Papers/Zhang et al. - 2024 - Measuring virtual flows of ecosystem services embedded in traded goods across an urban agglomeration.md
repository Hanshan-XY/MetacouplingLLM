# Measuring virtual flows of ecosystem services embedded in traded goods across an urban agglomeration

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:19:27.474931+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Zhang et al. - 2024 - Measuring virtual flows of ecosystem services embedded in traded goods across an urban agglomeration.pdf
- Year: unknown
- DOI: 10.1016/j.ecoser.2024.101651
- OA status: green
- License: cc-by
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: green OA but only submittedversion version available

## Copyright-Safe Summary
This article develops and applies a quantitative framework to measure ecosystem services (ES) that are virtually embedded in traded goods, with a focus on an urban agglomeration in China. The study examines how trade redistributes two key services - freshwater provisioning and climate regulation - between the Beijing-Tianjin-Hebei (BTH) region and the rest of China. It is explicitly grounded in the metacoupling framework, distinguishing intra-regional (intra-coupling), adjacent (peri-coupling), and distant (tele-coupling) interactions.

The authors combine three main components: spatial ES supply mapping, ES demand estimation from household consumption, and a multiregional input-output (MRIO) model extended with environmental coefficients. Water yield is modeled using InVEST, while vegetation net primary productivity (excluding cropland) serves as a proxy for climate regulation. Direct ES demand covers household on-site water use and direct energy consumption; indirect demand captures water use and carbon emissions embodied along supply chains of consumed products. The MRIO accounts for virtual flows of water and carbon among Chinese provinces and BTH cities in 2018.

Results show that BTH is a major net importer of virtual water but a net exporter of climate regulation service. Most virtual water imports originate from distant western and northeastern provinces, largely linked to food supply chains. Housing-related sectors dominate the export of embodied carbon (and thus virtual climate regulation service) from BTH to other, especially coastal, provinces. Across both services, indirect (trade-mediated) demand substantially exceeds direct demand, and two megacities, Beijing and Tianjin, capture a large share of external ES inflows.

By explicitly separating local, adjacent, and distant linkages, the study demonstrates that telecoupled ES flows are critical for understanding urban sustainability, supply-demand mismatches, and cross-regional environmental burdens. The authors emphasize that many previous ES assessments, which neglect virtual flows, are likely to underestimate urban dependence on external ecosystems and misidentify where interventions or compensation mechanisms should be targeted.

## Structured Metacoupling Extraction

### Coupling Classification
- Quantifies intra, peri, and telecoupling via virtual ecosystem service trade

### Intracoupling
#### Systems
- Beijing-Tianjin-Hebei urban agglomeration as local socioecological system
#### Flows
- Virtual water and climate regulation services traded within BTH cities
#### Agents
- Local households, firms, and municipal governments in BTH
#### Causes
- Household consumption and industrial production within urban agglomeration
#### Effects
- Internal ES supply-demand mismatches in large BTH cities

### Pericoupling
#### Systems
- BTH linked with adjacent provinces Inner Mongolia, Liaoning, Shandong, Henan, Shanxi
#### Flows
- Virtual water and carbon-related ES exchanged between BTH and neighbors
#### Agents
- Provincial governments and industries around BTH
#### Causes
- Regional trade in food, materials, and manufactured goods
#### Effects
- Neighboring provinces bear ES pressures from BTH demand

### Telecoupling
#### Systems
- BTH connected with distant Chinese provinces and coastal city clusters
#### Flows
- Long-distance virtual water imports and climate regulation exports
#### Agents
- National supply chains, distant producers, distant urban consumers
#### Causes
- Domestic long-distance trade driven by urban consumption
#### Effects
- Water-scarce western provinces stressed; distant coasts depend on BTH industry

### Cross-Coupling Interactions
- Telecoupled water flows dominate over pericoupled flows for BTH supply
- Climate regulation flows shaped by both distance and industrial structure

### Research Gaps or Limitations
- NPP proxy overestimates long-term climate regulation services
- Household-based demand omits government and corporate ecosystem service use

### Search Keywords
- virtual ecosystem service flows metacoupling China BTH
- multiregional input output telecoupling water carbon

### Extraction Confidence
high
