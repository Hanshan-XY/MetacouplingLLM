# Exploring the impacts of climate change and mitigation policies on UK feed barley supply and implica

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:15:36.741066+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Yawson et al. - 2020 - Exploring the impacts of climate change and mitigation policies on UK feed barley supply and implica.pdf
- Year: unknown
- DOI: 10.1007/s42452-020-2444-6
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This article examines how climate change and land-based mitigation policies could reshape the United Kingdoms feed barley supply and what this implies for both national and international food security.

The study focuses on feed barley and feed-barley-equivalent meat (FBEM) in the UK, a major barley producer and exporter. It uses simulated future barley yields from the AquaCrop model driven by UKCP09 climate projections under three emissions pathways (low, medium, high) for the 2030s, 2040s, and 2050s. These yields are combined with projected cropland areas from an official UK land use, land use change, and forestry (LULUCF) assessment that embodies several mitigation policy scenarios. Future demand for feed barley and meat is derived from population projections and per capita consumption pathways from international assessments.

Climate change alone tends to increase UK barley yields, especially under higher emissions, making the UK a potential biophysical beneficiary of warming for this crop. However, mitigation-driven reductions in cropland area mean that barley area in all policy scenarios shrinks to about 82-87 percent of the recent baseline, capping total production despite higher yields.

When projected supply is compared to demand, large domestic deficits emerge. Depending on scenario and time slice, feed barley shortages reach about 40-53 percent of demand by the 2050s, and FBEM gaps rise to roughly 65-71 percent. This would push the UK from a net exporter of barley to a substantial net importer of barley and/or meat.

Using a causal loop diagram and trade data for major barley partners (Ireland, France, Germany, Ukraine), the authors show that these UK deficits would increase competition for exportable surpluses. Some exporters already have limited or negative future surplus, and higher UK import needs would divert trade away from existing developing-country clients. The paper explicitly frames this as a telecoupling problem: UK mitigation and consumption choices reverberate through global grain and meat markets, potentially undermining food security in poorer, import-dependent regions. The article is directly about telecoupling/metacoupling.

## Structured Metacoupling Extraction

### Coupling Classification
- Explicit telecoupling of UK barley and meat deficits with global food trade and security

### Intracoupling
#### Systems
- UK agricultural land use and barley production system
- UK livestock and meat production sector
- UK national food security and consumption system
#### Flows
- Domestic flows of barley from farms to feed and malt uses
- Feed barley flows into national livestock production
- Policy-driven reallocation of UK cropland among uses
#### Agents
- UK government climate and land use policymakers
- UK farmers and barley producers
- UK livestock and meat industry actors
#### Causes
- UK land based climate mitigation policies reducing cropland for barley
- Climate change impacts on barley yields under different emission scenarios
- Population growth and stable or rising per capita meat demand
#### Effects
- Large future gaps between UK feed barley demand and domestic supply
- Reduction of UK self sufficiency and shift from exporter to importer
- Increased domestic vulnerability of meat availability and prices

### Pericoupling
#### Systems
- UK and European Union barley and meat markets
- UK and nearby European barley supplier countries
- Regional EU feed grain and livestock production system
#### Flows
- Regional trade of barley between UK and EU partners
- Shifting barley export flows within Europe due to UK deficits
- Cross border adjustment in meat and feed grain imports
#### Agents
- EU member state governments and trade negotiators
- European grain exporters in Ireland, France, Germany
- Regional feed and meat processing companies
#### Causes
- UK climate mitigation policies interacting with EU agricultural context
- Existing EU dependence on cereals for animal feed
- Brexit related uncertainty over EU UK agricultural trade
#### Effects
- Stronger competition for limited European barley exportable surplus
- Potential reduction of barley available to smaller European importers
- Regional price increases for feed barley and meat products

### Telecoupling
#### Systems
- UK food system as climate beneficiary barley producer transforming to importer
- Major barley exporting countries like Ukraine, France, Germany, Ireland
- Distal developing economies in Africa and Middle East dependent on imports
#### Flows
- Telecoupled trade of barley and barley based meat to UK from distant exporters
- Indirect flow of climate mitigation impacts into global grain prices and availability
- Redistribution of export shares away from developing country importers
#### Agents
- International grain traders and logistics companies
- Governments of barley exporting and importing countries
- Vulnerable consumers in food importing developing nations
#### Causes
- Land based mitigation reducing UK cropland despite higher climate driven yields
- Rising global demand for feed grains and meat toward mid century
- Limited exportable surplus in main supplier countries under own constraints
#### Effects
- UK import demand potentially exceeding several million tonnes of barley annually
- Tighter global barley market and significant price pressures
- Heightened food insecurity risks for poorer barley and meat importing nations

### Cross-Coupling Interactions
- Climate mitigation policy in UK triggers land use change that amplifies telecoupled food security risks abroad
- UK demand shifts alter trading partners export allocations, constraining supplies to other importers
- Feedback loops link UK deficits, global prices, and reduced access in vulnerable countries

### Research Gaps or Limitations
- Assumes fixed barley feed shares and static diets despite possible future shifts
- Ignores technological yield gains or improved feed conversion beyond modeled climate effects
- Simplified estimation of partner country future production and demand from limited data

### Search Keywords
- UK feed barley climate mitigation telecoupling
- land use change barley trade food security
- barley deficits UK imports developing countries

### Extraction Confidence
high
