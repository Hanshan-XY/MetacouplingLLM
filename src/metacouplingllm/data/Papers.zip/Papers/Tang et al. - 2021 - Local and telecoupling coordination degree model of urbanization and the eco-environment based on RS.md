# Local and telecoupling coordination degree model of urbanization and the eco-environment based on RS

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:08:00.952059+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Tang et al. - 2021 - Local and telecoupling coordination degree model of urbanization and the eco-environment based on RS.pdf
- Year: unknown
- DOI: 10.1016/j.scs.2021.103405
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study develops and tests a quantitative framework to assess how urbanization and ecological conditions interact both locally and across space, using the concept of telecoupling. The geographic focus is the Wuhan urban agglomeration (WUA) in central China, a multi-city system with strong economic and environmental linkages.

The framework replaces subjective indicator systems with remote sensing products. Urbanization intensity is derived from nighttime light imagery via an improved compounded night light index (ICNLI), constructed with principal component analysis to integrate light intensity and lit area. Eco-environmental quality is measured by a remote sensing ecological index (RSEI) built from MODIS-based indicators of vegetation, surface temperature, moisture, and dryness. ICNLI is validated against a composite socio-economic urbanization index based on population, land use, and economic variables.

To capture both local interactions between a citys own urbanization and environment and telecouplings with other cities, the authors extend the standard coupling coordination degree model. Their local and telecoupling coordination degree model (LTCCDM) combines: (1) local coupling between each citys ICNLI and RSEI, and (2) cross-city coupling terms weighted by inverse distance, representing how one citys urbanization interacts with other cities environments and vice versa. Equal weights are assigned to local and telecoupling components.

Applied to the WUA from 2008 to 2018, the results show: (1) urbanization and ecological quality both improve overall, but with opposite core-periphery patterns: Wuhan and nearby cities are highly urbanized but have relatively poorer ecological conditions, while peripheral cities are less urbanized with better environments; (2) the coordination between urbanization and the eco-environment shifts from generally uncoordinated to coordinated across the region; and (3) spatial disparities in coordination shrink when telecoupling is included, aligning with known trends of increasing regional integration.

This is explicitly a metacoupling/telecoupling study: it conceptualizes cities as open systems whose socio-environmental dynamics are shaped by both internal processes and distance-mediated interactions, and provides a transferable RS-GIS-based tool to quantify those coupled dynamics in multi-city regions.

## Structured Metacoupling Extraction

### Coupling Classification
- Strongly focused on intra urban agglomeration local coupling and telecoupling among cities

### Intracoupling
#### Systems
- Urbanization subsystem inside each Wuhan agglomeration city
- Local eco environment subsystem of each city
#### Flows
- Internal land conversion from ecological land to built up area
- Local pollution emissions and resource use within cities
#### Agents
- Municipal governments of Wuhan and surrounding cities
- Local residents and firms
#### Causes
- Rapid economic growth and urban expansion in central China
- Local planning and industrial development policies
#### Effects
- Rising local urbanization index values over time
- Decreasing ecological land and pressured core city environments

### Pericoupling
#### Systems
- Core city Wuhan and immediately adjacent smaller cities
- Neighbouring eco environments sharing air and water systems
#### Flows
- Short distance commuting and migration within Wuhan urban agglomeration
- Regional air and water circulation between neighbouring cities
#### Agents
- Inter municipal planning bodies for Wuhan urban agglomeration
- Regional infrastructure and transport authorities
#### Causes
- Geographical proximity and shared river basin within Hubei
- Integration policies like Wuhan City Circle plan
#### Effects
- Core periphery pattern in both urbanization and ecological quality
- Reduced regional disparities in coordination degree over time

### Telecoupling
#### Systems
- Internal urbanization system of one city
- External eco environment or urbanization systems of other agglomeration cities
#### Flows
- Intercity trade, capital, population, tourism, information flows
- Cross boundary environmental influences via air and water circulation
#### Agents
- Provincial and national governments coordinating regional strategies
- Enterprises relocating industries across cities
- Tourists and migrant workers moving among cities
#### Causes
- Globalization increasing distant socioeconomic linkages
- Open city systems within integrated urban agglomerations
- Infrastructure and market integration policies
#### Effects
- Telecoupling coordination degree rising from unbalanced to balanced
- Peripheral cities benefiting from core city economic spillovers
- Pollution and ecological pressures potentially spilling over from Wuhan to neighbours

### Cross-Coupling Interactions
- Model explicitly combines local coupling term with distance weighted telecoupling term
- Telecoupling weights decline with greater intercity distance using inverse distance weighting
- Balanced local and telecoupling coefficients chosen to reflect regional integration realities

### Research Gaps or Limitations
- Framework not yet tested on larger scales like national blocs or Belt and Road regions
- Telecoupling weights currently based only on geographic distance, not socioeconomic linkages
- Need to identify key drivers of coordination using additional statistical models

### Search Keywords
- telecoupling urbanization eco environment Wuhan
- local telecoupling coordination degree model LTCCDM
- nighttime lights ICNLI RSEI MODIS

### Extraction Confidence
high
