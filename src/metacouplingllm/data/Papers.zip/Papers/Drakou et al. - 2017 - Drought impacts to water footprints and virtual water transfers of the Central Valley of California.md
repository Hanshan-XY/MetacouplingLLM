# Drought impacts to water footprints and virtual water transfers of the <scp>C</scp>entral <scp>V</scp>alley of <scp>C</scp>alifornia

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:41:35.276663+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Drakou et al. - 2017 - Drought impacts to water footprints and virtual water transfers of the Central Valley of California.pdf
- Year: 2017
- DOI: 10.1002/2016WR020251
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This study analyzes how the 2012-2014 drought in California altered agricultural water use and virtual water flows from the Central Valley, one of the worlds major irrigated food-producing regions. The geographic focus is the 20 counties overlying the Central Valley aquifer, subdivided into the Sacramento, San Joaquin, and Tulare basins. The work sits in a coupled human-water systems and telecoupling context, emphasizing how local climatic shocks affect distant consumers through food trade.

The authors combine high-resolution county-level crop production data, a detailed crop evapotranspiration model (CUP+ driven by daily climate data), state irrigation-source statistics, and U.S. freight flow data to quantify: (1) water footprints of crop production by source (rainwater, surface water, groundwater) for 67 crops from 2011 to 2014 and (2) virtual water transfers among U.S. regions and to eight world regions. Groundwater versus surface-water fractions are inferred using historical county data on irrigation sources linked statistically to a drought index.

Despite a decline in harvested area during the drought, total crop water footprints increased due to higher crop water demand under warmer conditions and a shift from field crops to water-intensive orchards and vineyards. The groundwater component of the water footprint nearly doubled, with particularly strong growth in the Tulare Basin, where overexploitation and land subsidence are well documented. Surface and green water footprints fell, but were more than offset by extra groundwater use.

Food shipments by weight declined slightly, yet total virtual water transfers rose, driven by increasing volumes of groundwater embodied in traded products. Many U.S. regions and international markets became more dependent on Central Valley groundwater during the drought, including large California cities that indirectly consume substantial volumes via food supply chains.

The paper explicitly addresses telecoupling: it shows how a regional drought strengthens distant dependencies on a stressed aquifer through virtual water trade, and how global demand and cropping shifts feed back on local groundwater depletion.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling of Central Valley drought, groundwater use, and distant food consumers.

### Intracoupling
#### Systems
- Central Valley agricultural production and irrigation system
- Central Valley Aquifer and basin hydrology
- California urban water and food demand
#### Flows
- Blue and green water use in crop evapotranspiration
- Groundwater withdrawals and depletion
- Food and virtual water use within California
#### Agents
- Central Valley farmers and irrigation districts
- State water and environmental agencies
- Urban consumers in California cities
#### Causes
- Severe 2012-2014 California drought and higher temperatures
- Shift from annual field crops to permanent orchards and vines
- Surface water shortages driving reliance on groundwater
#### Effects
- Increased total and groundwater water footprints of crops
- Land subsidence and aquifer overdraft, especially Tulare Basin
- Reduced flexibility due to expansion of water-intensive permanent crops

### Pericoupling
#### Systems
- Central Valley counties and neighboring US freight zones
- Central Valley and other US agricultural regions
- Central Valley and nearby states dependent on imported feed
#### Flows
- Interstate food and virtual water shipments within the US
- Groundwater-based virtual water to US cities and states
- Declining cereal shipments but rising animal feed transfers
#### Agents
- US freight shippers and supply chain firms
- Livestock producers in importing states
- Urban water and food planners in western US
#### Causes
- Drought-driven reallocation from cereals to high-value crops
- Surface water project cutbacks to Central Valley farms
- Market prices incentivizing nut and perennial crop expansion
#### Effects
- More than doubling of groundwater dependence for 69 US zones
- Decreased green and surface virtual water, increased groundwater flows
- Changing exposure of US regions to Central Valley aquifer stress

### Telecoupling
#### Systems
- Central Valley agricultural-export system
- International regions importing Central Valley products
- Global food trade network linking climate shocks and diets
#### Flows
- Virtual water exports embedded in crops and animal feed
- Rising groundwater-based virtual water to most world regions
- Overall food exports slightly down, but virtual water exports up
#### Agents
- International food traders and logistics companies
- Foreign consumers of fruits, nuts, and feed
- National and international water and trade policymakers
#### Causes
- Local drought altering water sources and crop water footprints
- Global demand growth for nuts and permanent crops
- Trade patterns maintaining exports despite local water scarcity
#### Effects
- Foreign consumers increasingly reliant on overdrawn Central Valley aquifer
- Complex, region-specific changes in virtual water trade composition
- Global propagation of local groundwater depletion risk

### Cross-Coupling Interactions
- Local drought intensifies groundwater use, which boosts virtual water exports to US and global markets.
- Crop and water decisions in Tulare Basin create subsidence while supplying distant urban food demand.
- Domestic policy and markets reshape telecoupled virtual water flows during climate extremes.

### Research Gaps or Limitations
- Lack of crop-specific and 2011-2014 metered irrigation source data increases groundwater fraction uncertainty.
- Processed foods, livestock, and meat supply chains excluded, underestimating total virtual water transfers.
- Uncertainty and sensitivity of combined water footprint and trade estimates not fully quantified.

### Search Keywords
- Central Valley California virtual water groundwater drought telecoupling
- Tulare Basin groundwater footprint subsidence exports
- California agriculture water footprint virtual water trade

### Extraction Confidence
high
