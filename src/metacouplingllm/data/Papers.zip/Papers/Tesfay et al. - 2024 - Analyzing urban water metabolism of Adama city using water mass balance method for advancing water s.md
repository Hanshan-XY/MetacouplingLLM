Check for updates

# OPEN ACCESS

EDITED BY

Gianfranco Becciu,

Polytechnic University of Milan, Italy

REVIEWED BY

Mekonnen Maschal Tarekegn,

Ethiopian Civil Service University, Ethiopia

Daniel Lirebo Sokido,

Ethiopian Civil Service University, Ethiopia

*CORRESPONDENCE

Abraha Tesfay

abrahagisrs@gmail.com

RECEIVED 08 May 2024

ACCEPTED 15 October 2024

PUBLISHED 31 October 2024

CITATION

Tesfay A, Assefa T and Gebremariam E (2024)

Analyzing urban water metabolism of Adama

city using water mass balance method for

advancing water sensitive interventions.

Front. Water 6:1427788.

doi: 10.3389/frwa.2024.1427788

COPYRIGHT

$\circledcirc$ 2024 Tesfay, Assefa and Gebremariam. This is an open-access article distributed under the terms of the Creative Commons

Attribution License (CC BY). The use, distribution or reproduction in other forums is permitted, provided the original author(s) and the copyright owner(s) are credited and that the original publication in this journal is cited, in accordance with accepted academic practice. No use, distribution or reproduction is permitted which does not comply with these terms.

# Analyzing urban water metabolism of Adama city using water mass balance method for advancing water sensitive interventions

Abraha Tesfay*, Tibebu Assefa and Ephrem Gebremariam

Ethiopian Institute of Architecture, Building Construction and City Development, Addis Ababa University, Addis Ababa, Ethiopia

Urban water metabolism focuses on measuring water inflows and outflows within a defined urban system. As an emerging concept, it provides valuable understandings into water flow dynamics, supporting evidence-based decisionmaking. One approach to quantify these flows is the urban water mass balance method, which accounts for both human-induced and natural water resources. By equating these flows, it identifies whether water movement within the system is linear or circular. The primary goal of water mass balance analysis is to assess how closely a city aligns with water-sensitive management approaches. However, urban metabolism studies are rare in developing countries, where cities often lack the experience to estimate water inflows and outflows for informed water-sensitive interventions. This study addresses this gap by analyzing Adama city in Ethiopia using the water mass balance method to measure its water metabolism. The result revealed that the city faces a negative water balance with outflows exceeding inflows by 46.89 million cubic meters annually. The results indicated that Adama’s water flow follows a linear “take-make-use-dispose” model. The imbalance in Adama’s water cycle is driven by urbanization, impervious surfaces, and climate change, which increase runoff and evaporation. The study found that $6 1 . 3 \%$ of the city’s water comes from a centralized system, with $90 \%$ sourced from distant rivers through a telecoupling system. In the city, inadequate water harvesting, high population density and intensive water use are worsening water scarcity. Urban water metabolism indicators reveal significant losses and indicating the need for water conservation efforts. Despite the reliance on centralized systems, the study identifies strong potential for decentralized solutions and alternative water harvesting. To tackle these challenges, the research recommends adopting water-sensitive strategies such as low-impact development, sustainable urban drainage systems, and water-sensitive urban design and planning. These approaches can reduce the negative effects of urbanization, mitigate urban water scarcity risks and improve water management through water sensitive management approach. The study also emphasizes the need for collaborative learning, community involvement, and innovative technologies, supported by legal frameworks to ensure effective water wise interventions. Shifting toward circular water management and decentralized water systems will boost Adama’s resilience and promote sustainable water resource management, making the city more internally self-sufficient.

KEYWORDS

urban water metabolism, urban water mass balance, anthropogenic, water sensitive, intervention, Adama, Ethiopia

# 1 Background of the study

Settlements have always occurred when natural resources were thought to be  sufficient to sustain human existence. The physical existence of water is a basic requirement for the development of permanent settlements on Earth. The presence of water has always been considered a critical component in determining where people choose to live since ancient civilizations (IWA, 2024; Juuti et al., 2007). Water is fundamental to many aspects of human existence and economic activity making it an important component of economic and social development. Economic activity and societal well-being are significantly shaped by the water availability and its wise management (Cosgrove and Loucks, 2015). Water is lifeblood of every sector including service, industry, agriculture and urban developments (Zhou et  al., 2017; Mugagga and Nabaasa, 2016). Since water is necessary for both maintaining life and attaining long-term economic, social and environmental goals, water and sustainable development goals have always an unbreakable connection (UNICEF, 2023).

In the current context, urban development and spatial expansion trends compromise the protection of natural water cycles by causing over-extraction of fresh water and degradation of watershed landscapes (Cosgrove and Loucks, 2015). The increased impervious pavements such as roads, walkways, parking lots, residential houses, and other impervious pavements are altering the natural hydrological cycles (Chen et  al., 2022; Moglen, 2009). Consequently, the hydrological catchments that are crucial to supply water for urban areas are currently stressed (Cao et al., 2022). On the other hand, how urban water flows are changing over time due to rapid urbanization and climate change are still scantly explored (Renouf et al., 2017a). The inflow and outflow of water within urban boundaries are rarely quantified through proper water resource flow accounting or auditing systems. As a result, water resource planning often relies on rough estimates leading to ineffective policies and strategies implementations (Musango et al., 2017).

As a result, addressing the real-world situation requires a water management approach focused on understanding water flow dynamics. This involves quantifying water inflow and outflow, gaining understandings into wise management within the water supply system, understanding consumption patterns, and assessing transformations, including centralized and decentralized water recycling efforts. A contemporary approach that addresses those appealing questions is urban metabolism (Renouf et  al., 2017b; Musango et al., 2017). Urban metabolism (UM) serves as an analytical framework designed to measure and track the flow of resources systematically and its primary objective is to provide a comprehensive understanding of how resources are utilized and transformed within an urban landscape (Cui et al., 2019; Musango et al., 2017; Derrible et al., 2021).

Urban metabolism encompasses four core flows including water, materials, energy, and food (Pistoni and Bonin, 2017; Fu et al., 2022). This study focuses on urban water metabolism, which is defined as the process of water flowing through an urban entity, undergoing transformation, and being utilized to sustain the technical and socioeconomic activities within the city (Kennedy et al., 2010; Renouf et al., 2017b). Urban water metabolism research provides data-driven understandings that enable practitioners and local governments to make informed decisions regarding water-sensitive interventions and conservation efforts (Renouf et al., 2017a; Serrao-Neumann et al.,

2019). In urban areas, water flows are classified into two categories known as anthropogenic and natural flows (Farooqui et al., 2016). Anthropogenic flows are regulated by urban water infrastructure and include activities like water supply consumption, wastewater collection, treatment, recycling and disposal. In contrast, natural flows are those occurring naturally in the water cycle, such as precipitation, stormwater runoff, groundwater infiltration and evapotranspiration (Renouf et al., 2017a; Farooqui et al., 2016). A method for quantifying the inflow and outflow of water inside urban systems is known as the “urban water mass balance.” The concept was first put forth by Kenway et al. (2011) and subsequently improved upon by Renouf et al. (2017a).

This holistic conceptualization of urban water flow enables the generating of valuable understandings into the metabolic performance of cities, essential for informing urban and regional planning. Estimating the urban water mass balance provides critical understandings for identifying diverse water harvesting opportunities and determining whether the water flow follows a linear or circular metabolism (Renouf et  al., 2017a). Above all, identifying and measuring water resource flows in urban areas is important element to establish water sensitive cities. A “water-sensitive city” symbolizes an urban water management approach focused on strengthening resilience, sustainability, and overall well-being. A water sensitive city promotes a transition in urban water management from simply focusing on supply and wastewater disposal to flexible systems that incorporate multiple water sources, blend centralized and decentralized methods, and provide a variety of community water services (Renouf et al., 2017a). These cities serve as vital catchment areas for water resources, supporting ecosystem health and fostering safe, natural environments. Additionally, it fosters communities that actively engaged in water-related decision-making processes. Water sensitive city is based on three principles called city as water supply catchments, cities providing ecosystem services, and water-sensitive communities (Wong and Brown, 2009).

According to Wong and Brown (2009) the principle of city as water supply catchments emphasizes that urban areas can be self-sufficient by generating alternative water sources within their boundaries by supplementing traditional sources. The principle of cities providing ecosystem service indicates urban areas potential to enhance urban ecology by protecting water bodies, integrating green infrastructure, enacting water-conscious planning, and encouraging public participation in maintaining urban environments. The principle of water-sensitive communities promotes a water-conscious mindset and culture. These communities improve attitudes toward water conservation by embracing diverse alternative sources such as rainwater, stormwater runoff, greywater, and recycled wastewater. By raising awareness, they play a vital role in sustainable water management through water wise consumption and conservation practices.

Meanwhile, water-sensitive interventions are strategies implemented for the realization of water sensitive city visions (Wong et al., 2020). According to Renouf et al. (2017a), these interventions aim to enhance water efficiency and broaden water sources in cities through two key concepts including supply internalization and supply diversification. Supply internalization seeks to reduce dependence on external water sources by fostering local supply capabilities within urban boundaries. Supply diversification involves the integration of alternative water sources such as surface water, groundwater, roof water harvesting, and recycling to enhance resilience and sustainability. Sustainable water resource management in urban areas is a common

aim for both water-sensitive interventions and urban metabolism. By blending these approaches, policymakers and urban planners can develop water management plans that are more sustainable.

Empirical evidence underscores the necessity for urban centers to embrace the concepts of urban metabolism, water mass balance analysis, and innovative water-sensitive interventions to transition from traditional water supply methods to integrated systems. This shift, blending centralized and decentralized water flows holds potential for enhancing water sensitive urban water management practices (Renouf et al., 2017a; Wong and Brown, 2009; Musango et al., 2017). However, current government planning policies and implementation strategies often lack integration of urban water metabolism with water sensitive planning. Moreover, in most countries, urban metabolism knowledge remains disconnected from policymakers’ toolboxes (Serrao-Neumann et al., 2017). Notably, urban metabolism studies and implementation practices predominantly focus on developed countries, neglecting developing countries due to data scarcity (Teshome Tefera Tola and Wegayehu, 2019). There is limited knowledge and effort in developing countries to adopt urban water metabolism frameworks as strategic decision support systems in urban and regional planning practices (Zhang et al., 2015).

Currie and Musango (2017) indicated that research on water metabolism in developing countries, particularly in Africa, is scant and there is still limited understanding how water flows in the urban landscape. Consequently, today there are practical reasons for studying urban water mass balance of developing countries and the same is true for Ethiopia and Adama city. Hence, this study addresses the understanding of how the anthropogenic and natural water resource flows in the Adama city boundary as case study. The study uses an urban water metabolic framework as guiding framework and urban water mass balance method as quantification method to measure the system and type of urban water flow. The objectives include estimating water flows, measuring the city’s metabolic performance, and proposing alternative water sources aligned with water-sensitive interventions.

This research was motivated by several key factors. First, water flow characteristics vary significantly across different locations due to the influence of watershed features, land use patterns, urban development, and local attitudes toward water conservation. This underlines the importance of context-specific research to inform adaptive, water-sensitive management practices, particularly through water mass balance analysis. Second, in developing countries, urban metabolism studies remain unexplored. Urban centers often lack the tools to estimate water inflows and outflows within their system boundaries, which is crucial for effective urban water management. Thirdly, the urban water mass balance framework, originally developed by Kenway et al. (2011) and later refined by Farooqui et al. (2016) and Renouf et al. (2017a), still faces challenges in adapting to local contexts, especially when grassroots data is limited. This research employs an approach that integrates both top-down and bottom-up data collection methods to provide a more accurate and adaptable analysis.

# 2 Materials and methods

# 2.1 Description of the study area

Adama, one of the fastest-growing urban centers in Ethiopia, is located $9 9 \mathrm { k m }$ southeast of Addis Ababa, the capital of both Ethiopia

and Africa. Known for its role as a transport hub, tourism destination, conference center, and industrial location, Adama lies at $8 . 5 4 ^ { \circ } \mathrm { N }$ latitude and $3 9 . 2 7 ^ { \circ } \mathrm { E }$ longitude, with an average elevation of $1 , 7 1 2 \mathrm { m }$ above sea level. The city’s semi-arid to sub-humid climate features distinct rainy and dry seasons, with average annual temperatures between $1 9 ^ { \circ } \mathrm { C }$ and $2 2 ^ { \circ } \mathrm { C }$ and an average of annual rainfall of $8 9 7 . 9 \mathrm { m m }$ . With a population of 431,442 and an annual growth rate of $4 . 6 \%$ , Adama covers an area of 31,304 hectares (Figure 1).

# 2.2 Method to characterize the hydro climatology of Adama city

This study utilized gridded climate data on rainfall, temperature, and evaporation from the Ethiopian Meteorological Institute (EMI) to analyze the seasonal hydroclimatic characteristics of Adama city. The primary sources included the Enhancing National Climate Services Time Series (ENACT) datasets, renowned for their spatial resolution of $4 \times 4 \mathrm { k m }$ , covering the period from 1981 to 2022. The ENACT rainfall dataset was meticulously compiled by integrating quality-controlled data from Meteorological Stations with rainfall estimates derived from Tropical Applications of Meteorology using Satellite (TAMSAT). Temperature data, on the other hand, were synthesized from station data and Moderate Resolution Imaging Spectroradiometer (MODIS) satellite Land Surface Temperature (LST) estimates, alongside a digital elevation model. Both the ENACT rainfall and temperature datasets utilized for climate trend analysis were sourced from the Ethiopian Meteorological Institute (EMI).

# 2.3 Method to quantify the urban water mass balance

Quantifying urban water mass balance involves four key steps including (1) defining the system boundary, (2) identifying inflows and outflows, including anthropogenic and natural water sources, (3) calculating the mass balance, and (4) assessing the city’s water metabolism performance. The following section details each step.

# 2.3.1 Method to determine urban system boundary

Kenway et al. (2011) underscore the significance of delineating the boundaries of the urban water source flow system in studies concerning urban metabolism. According to Musango et al. (2017) establishing the urban system boundary provides a comprehensive understanding of the origins and destinations of water resource flows. In this regard, in this study factors such as watersheds, peri-urban areas and existing administrative boundaries were taken into account during system boundary delineation. Remote sensing techniques and Geographic Information Systems (GIS) were utilized to delineate the system boundary (Figure 2).

# 2.3.2 Method to collect data for anthropogenic water flows

Anthropogenic data, including population figures, details on centralized and decentralized water supply systems, and other

![](images/90348ec5462451f4696dbc1b2ad55d4b634fe4b20a477df34c903172f0fed03a.jpg)  
Adama City

![](images/7f90bb3905c0543eee9b1e9301590c8bf26647ce0454e6b68074847e990b1cb0.jpg)  
Africa   
Ethiopia

![](images/dac0f9fcbf5013ec162f68a59ffaeaa5d7b44c314ea700d7f828fc67026d48ef.jpg)  
Legend   
Borehole

![](images/26a66dd025e71ec2b22e79c91065d3cb227bc746c780ffc3e34ac80aea0a0808.jpg)  
Reservoirs

![](images/3b666a5693c5e406cb17eb8c7cc8b52ce0cd57897a83a17f292cb5b5c9f44773.jpg)  
annig Boundary

![](images/320326f47793b5561ad4cf7aae66dadda96b4253d40be4328053b725615af2f8.jpg)  
Water Pumps

![](images/1c125c10ab93370244181e4ff9b7349699ad42d9bdd6e0e134a3a2d262122910.jpg)  
Transmission_Line

![](images/261e9354df0b6d0726b256ccbd2b51f555a0909e413df7177622d57c886f7423.jpg)  
Region Boundary   
River

![](images/00c0bacf54a529e4d56d43afe40c1ba82a8a26de606e2de54cfd081dfe00bd0c.jpg)  
FIGURE 1   
Location map of Adama city.

![](images/9740c195da99226e7f3a034c2f48efe63ddb36f4b4234943e678027e6b464ec7.jpg)  
Delineation of Watershed Based Water Flow System Boundary

![](images/cc6b511a94f76b0089bb4136e7a8bbf25ce573aa783523c5379aaee8b83b840c.jpg)

![](images/89be5ea297f5a5d0362d7dca2e77b3c0102c7587833efd10890cf0ffab632d6d.jpg)

![](images/857fe1ab1f1441c92e21c50443eb7826e1a2d00866cd6c0ced3a59e3dea13585.jpg)

![](images/677b1fec9b6b454072eff84203d4a658791dbc6a6916187bfbed236abf270f66.jpg)

![](images/29d3241e8f2df902031b744dd33477a45c6a67b6ae22027846703a6786ceb889.jpg)

![](images/ed5452686f1f5b1b92759b13a078e20d57f7e9bfcc2e04263d1917cc6462f686.jpg)

![](images/cb241d2f8100485a3956ac2c05086c3397fd9bbb668bb6481a2e26427d2dfdb4.jpg)

![](images/6585030a520ae5d16f81e35f7f57de1d9c5ae62926666a2ac745b77383ff304a.jpg)

![](images/3717b81501363f762faa04aff42eaeb7104d72237059d5908f99593ccbbf2e9f.jpg)

![](images/883f3edf065fcb788abd6fb21ab8782923f468286351779fa1ea674ffbcece18.jpg)  
Legend   
Outlets

![](images/03a97d9145da3426c9de0ab9162394b7593db7ed71e30fac260f0cccb060abc3.jpg)  
City_Region_Boundary

![](images/c0e675db4c09711aa3d88cc8a2be2e429f095df5aa010373df341c37d67c5c32.jpg)  
Stream order one

![](images/d6643e183cffde26111f63c03a1b1187928b1144bc6ee49b767a98862bebb1c7.jpg)  
Streamordertwo

![](images/30f609bbe710a83e49bf60f5d46ebaa049a0840b445beb8f053d5e6c91b46f67.jpg)  
Streamorder three

![](images/40faa0a19c0aeabc153a06568a0ca5b1c40949a4f40830b59ccfbbf438c72872.jpg)  
Stream order four

![](images/f4a483d501261683981df56658b33b774f07620555267c3868f97551d20459cc.jpg)  
Watershed one

![](images/76c221047c02907e9ccb31b2d330925cd73276259005eb318168bc80f010be5b.jpg)  
Watershed two

![](images/a0b9fd7bf0a28dcf0dae5e32a599fb71af2b3f4d76a3d4d001ae7e2ca9e01e29.jpg)  
Watershed three

![](images/e9141d70d5ab81a7a2059652d0ef4d5c34c95128a70f97effbf7c704ef3196e9.jpg)  
Watershed four

![](images/23110467eb9d2a70d84922eef40a23ddbb9b7875f598d3c8c8368e14a94846c1.jpg)  
Watershed five

![](images/3b752529e91036630be4e7bbec7e4c386c8b5909c10b6f2ce7efb83e7b3c215d.jpg)  
Watershed six

![](images/3fd631d4717bb70e1bd1a36ac0187f9c99886b155d41567ebbb6eece16d5f0d3.jpg)  
Watershed seven

![](images/f8873e4aa33812ef6f10b947d5af12b2212fa284d339fe2bf1db05fc0665dd0c.jpg)  
Watershed eight

FIGURE 2   
Water flow urban system boundary of Adama city.   
![](images/c7e9d5fbb5ec15226ad5978b62397a863682aec3c6b02260a1caa517f6b7486c.jpg)  
Coordinate System: GCs WGs 1984   
Datum:WGS1984   
Units:Degree

Watershed nine

relevant parameters were collected from diverse secondary sources and primary data collection systems. Vital information on anthropogenic water flows and consumption patterns primarily were originated from the Adama city water consumption database. This database provided a wide array of water utility records, encompassing residential, commercial, industrial, and service-related data. Additionally, city-level water consumption reports, scholarly journals, official publications and data obtained from central statistical sources were used (Table 1).

# 2.3.3 Method to collect data for natural water flows

Natural water flow components were estimated using a hybrid approach that combined hydrological modeling with an analysis of historical records. This included an in-depth review of historical hydrological data to identify trends and variations in natural water flows over time. By integrating these methods, estimates were made for precipitation, runoff, evapotranspiration, infiltration, and changes in water storage (Table 1). The following section outlines the detailed steps for estimating runoff, evaporation, infiltration, and changes in storage, followed by the method for calculating the overall water mass balance.

# 2.3.3.1 Estimation of runoff using SCS-CN method

The SCS-CN method is widely acknowledged empirical approach for estimating surface runoff (Satheeshkumar et al., 2017; Lee et al., 2023; Ara and Zakwan, 2018). To estimate runoff, initially nine distinct watersheds corresponding to nine outlets were identified through watershed delineation using ArcGIS (Figure  2). This delineation enabled the calculation of runoff specific to each watershed. The second step was preparing hydrological soil groups, which are essential for runoff estimation. The hydrological soil group of the city was determined using The U. S. Department of Agriculture (USDA) Soil Conservation Service Classification method (USDA-SCS, 1986) (Equations 2.3–2.5). Based on their hydrological properties, soils of the city were categorized and assigned to the appropriate hydrological soil groups (Table 2 and Figure 3).

The preparation of data on land cover and use was the third step. Figure  4; Table  3 present a detailed categorization of land use classifications and their corresponding impervious surface properties. By combining the variables including, land use characteristics and hydrological soil groups, the SCS curve number approach was utilized to generate estimated runoff.

The Soil Conservation Service Curve Number (SCS-CN) method is formulated based on the water balance equation, taking into account

TABLE 1 Type and sources of data for water mass balance estimation.   

<table><tr><td>Parameters</td><td>Data description</td><td>Type of data/unit/</td><td>Sources</td></tr><tr><td rowspan="5">Land use and population</td><td>Land use</td><td>Raster</td><td>Adama city administration</td></tr><tr><td>Population statistics</td><td>Report</td><td>Adama city structural plan</td></tr><tr><td>City region boundary</td><td>Shape file</td><td>Adama city structural plan</td></tr><tr><td>Water shade boundary</td><td>Shape file</td><td>Researchers&#x27; GIS output</td></tr><tr><td>Population density</td><td>Raster</td><td>Adama city structural plan</td></tr><tr><td rowspan="7">Anthropogenic flow</td><td>Centralize surface water (Cs)</td><td>Volume (m3)</td><td>Adama City Water Supply and Sewerage Service Enterprise</td></tr><tr><td>Centralized groundwater (Cg)</td><td>Volume (m3)</td><td>Adama City Water Supply and Sewerage Service Enterprise</td></tr><tr><td>Decentralized ground water (Dg)</td><td>Volume (m3)</td><td>Reports and research outputs</td></tr><tr><td>Decentralized surface water (Ds)</td><td>Volume (m3)</td><td>Reports and research outputs</td></tr><tr><td>Decentralized rainwater supply (Dr)</td><td>Volume (m3)</td><td>Reports and research outputs</td></tr><tr><td>Centralized recycled water (Rw)</td><td>Volume (m3)</td><td>Reports and research outputs</td></tr><tr><td>System loss/leakages (unaccounted for water or nonrevenue water) (Cufw)</td><td>Volume (m3)</td><td>Adama City Water Supply and Sewerage Service Enterprise</td></tr><tr><td rowspan="4">Hydrological/natural water/flow</td><td>Precipitation (P)</td><td>Volume (m3)</td><td>Estimation from model</td></tr><tr><td>Evapotranspiration (ET)</td><td>Volume (m3)</td><td>Estimation from model</td></tr><tr><td>Surface runoff (Rs)</td><td>Volume (m3)</td><td>Estimation from model</td></tr><tr><td>Groundwater infiltration (G)</td><td>Volume (m3)</td><td>Estimation from model</td></tr></table>

Source: Adama City Water Supply and Sewerage Service Enterprise researchers’ hydrology model.

TABLE 2 Hydrologic soil (HSG) and their implication for runoff estimation.   

<table><tr><td>Soil group</td><td>Description</td><td>Runoff potential</td><td>Water transmission</td></tr><tr><td>A</td><td>Sand, loamy sand or sandy loam</td><td>Low</td><td>High rate</td></tr><tr><td>B</td><td>Silt loam or loam</td><td>Moderate</td><td>Moderate rate</td></tr><tr><td>C</td><td>Sandy clay loam</td><td>Moderate</td><td>Moderate rate</td></tr><tr><td>D</td><td>Clay loam, silty clay loam and sandy clay</td><td>High</td><td>Low rate</td></tr></table>

Source: Adopted from The U. S. Department of Agriculture (USDA) (1986).

![](images/f509d42516669402cd6f1c8e511407405ff373878391a06f4d3c9d0ad47c32e8.jpg)  
Hydrological Soil Group Map of Adama City   
FIGURE 3 Hydrological soil type map of Adama city. Source: FAO GIS dataset, 2014.

![](images/ff630b7789e4fa5ddc7d70735ecef1abd8ac17d118ecf6b685542efce1517ecb.jpg)  
Land Use Land Cover Map of Adama City   
FIGURE 4 Land cover land use of Adama city (2022/23).

key parameters such as total precipitation (P), initial abstraction (Ia), cumulative infiltration (F), and the coefficient for potential maximum retention (S) and initial abstraction (λ), where the standard value for λ is set at 0. 2.

$$
\mathrm {P} = \mathrm {I a} + \mathrm {F} + \mathrm {Q}
$$

(2.1)

$$
\frac {\mathrm {Q}}{\mathrm {P} - \mathrm {I a}} = \frac {\mathrm {F}}{\mathrm {S}} \tag {2.2}
$$

By combining Equations 2.1, 2.2, the overall runoff equation is derived as follows:

TABLE 3 Land use land cover and their curve numbers.   

<table><tr><td>Land use land cover</td><td>Detailed cover</td><td>Description</td><td colspan="4">Soil group and CN</td></tr><tr><td rowspan="4">Streets and roads</td><td rowspan="2">Asphalt</td><td rowspan="2">Asphalt paved surface</td><td>A</td><td>B</td><td>C</td><td>D</td></tr><tr><td>98</td><td>98</td><td>98</td><td>98</td></tr><tr><td>Cobblestone</td><td>Gravel surface</td><td>76</td><td>85</td><td>89</td><td>91</td></tr><tr><td>Unpaved</td><td>Soil cover surfaces</td><td>72</td><td>82</td><td>87</td><td>89</td></tr><tr><td rowspan="4">Urban districts</td><td>Commercial</td><td>Commercial surfaces (85% impervious)</td><td>89</td><td>92</td><td>94</td><td>95</td></tr><tr><td>Industrial (72% impervious)</td><td>Industrial (72% impervious)</td><td>81</td><td>88</td><td>91</td><td>93</td></tr><tr><td>Services (imperious)</td><td>Services (72% impervious)</td><td>81</td><td>88</td><td>91</td><td>93</td></tr><tr><td>Residential</td><td>Town houses (65% imp pervious)</td><td>77</td><td>85</td><td>90</td><td>92</td></tr><tr><td>Agriculture</td><td>Cultivated Agricultural land</td><td>Agricultural land for crops</td><td>60</td><td>72</td><td>80</td><td>84</td></tr><tr><td>Range land</td><td>Trees and bushes</td><td>&lt;50% ground cover</td><td>48</td><td>67</td><td>77</td><td>83</td></tr><tr><td>Water body</td><td>Open water bodies, wetlands, ponds, etc.</td><td>Open water bodies: lakes, wetlands and ponds, etc.</td><td>100</td><td>100</td><td>100</td><td>100</td></tr><tr><td>Trees</td><td>Small trees</td><td>Small trees with heavy grazing</td><td>45</td><td>66</td><td>77</td><td>83</td></tr><tr><td>Bare land</td><td>Bare soil</td><td>Bare soil with no any grass or plant coverage</td><td>77</td><td>86</td><td>91</td><td>94</td></tr></table>

Source: The U. S. Department of Agriculture (USDA) (1986).

$$
Q = \left\{ \begin{array}{c} \frac {\left(P - I a\right) ^ {2}}{\left(P - I a\right) + S} \text {f o r} P > I a \\ 0 \text {f o r} P <   I a \end{array} \right. \tag {2.3}
$$

$$
\mathrm {I a} = 0. 2 \mathrm {S} \tag {2.4}
$$

$$
S = \left(\frac {2 5 , 4 0 0}{C N} - 2 5 4\right) \tag {2.5}
$$

where,

• Q Runoff (mm).   
• P Rainfall (mm).   
• S Potential maximum retention (mm).   
• Ia Initial abstraction.

# 2.3.3.2 Weighted CN estimation method

Based on the hydrological soil group, the curve number of each land use class was assigned. Next to this step the weighted curve number of each watershed was determined. The process of summing the product of the curve numbers and its fraction of the total catchment area was performed. This procedure was used by Cayson et al. (2019), Adham et al. (2014) and Satheeshkumar et al. (2017). The equation to estimate the weight curve number is given in Equation 2.6.

$$
\mathrm {C N w} = \sum_ {\mathrm {i} = 1} ^ {\mathrm {n}} \mathrm {C N l} * \mathrm {A i} / \mathrm {A} \tag {2.6}
$$

where,

• CNw $=$ weighted curve number.   
• $\mathrm { { A } _ { i } = }$ area with the curve number, CN .   
• $\mathrm { A } =$ total area of the watershed.

# 2.3.3.3 Potential evapotranspiration estimation method

The Hargreaves-Samani approach, which uses temperature data as a basis, is one popular technique for calculating PET. Accordingly, this study was employed Hargreaves-Samani approach to estimate PET of the city (Equation 2.7).

$$
\mathrm {P E T} = 0. 0 0 2 3 * \left(\mathrm {T} \max - \mathrm {T} \min\right) ^ {0. 5} * \left(\mathrm {T} \text {a v e} + 1 7. 8\right) * \mathrm {R a} \tag {2.7}
$$

where

• PET is the potential evapotranspiration in millimeters per day.   
• Ra is the extraterrestrial radiation per square meter per day.   
• Tmax is the daily maximum temperature in degrees Celsius.   
• Tmin is the daily minimum temperature in degrees Celsius.   
• Tave is s the average temperature, calculated as $( \mathrm { T m a x } + \mathrm { T m i n } ) / 2$ .

# 2.3.3.4 Infiltration estimation method

In hydrology, effective rainfall is a commonly used technique to compute infiltration. Effective rainfall is the quantity of precipitation that, after various abstractions and losses, contributes to runoff or soil infiltration (Farmwest, 2024). Effective rainfall is combined with the Soil Conservation Service’s (SCS) Curve Number approach to estimate runoff and infiltration. The infiltration estimation method is mathematically expressed (Equation 2.8).

$$
\mathrm {E R} = \mathrm {P} - \mathrm {I a} \tag {2.8}
$$

where,

• ER is effective rainfall   
• P is the total precipitation   
• Ia is an initial abstraction

Infiltration is the difference between effective rainfall and runoff in a watershed (Equation 2.9)

$$
I = P - I a - R \tag {2.9}
$$

Where,

• I is infiltration   
• P is the total precipitation   
• Ia is an initial abstraction   
• R is runoff

# 2.3.4 Method to estimate water mass balance

The methodology employed to calculate the water mass balance involves utilizing the framework of Kenway et  al. (2011) which underwent further refinement by Farooqui et al. (2016) and Renouf et al. (2017a). The general water mass balance of Adama city is framed by Figure 5.

The water mass balance operates under the assumption of a steady state, where the sum of all input water flows (Qi) equals the sum of all output water flows $\left( \mathbf { Q } _ { 0 } \right)$ (Berndtsson et al., 2016) (Equation 2.10).

$$
\mathrm {Q i} = \mathrm {Q o} \tag {2.10}
$$

where

Qi is the sum of all inputs and Qo is the sum of all outputs (including losses). Furthermore, Water stored within the urban entity can be formulated by Equations 2.11, 2.12.

$$
\Delta S = \mathrm {Q i} - \mathrm {Q o} \tag {2.11}
$$

$$
\begin{array}{l} \Delta S = \left(\mathrm {P} + \mathrm {C g} + \mathrm {C s} + \mathrm {D r .} + \mathrm {D g} + \mathrm {D s} + \mathrm {R w}\right) - \\ \left(\mathrm {E T} + \mathrm {W} + \mathrm {R s} + \mathrm {G} + \mathrm {C u f w}\right) \tag {2.12} \\ \end{array}
$$

where,

$\varDelta S =$ Water stored or utilized by different subsystems

$\mathrm { P } =$ Precipitation or rainfall

$\mathrm { C g } =$ Centralized groundwater supply

$\mathrm { C s } =$ Centralized surface water supply

Dr = Decentralized rainwater supply

$\mathrm { D g } =$ Decentralized groundwater supply

Ds = Decentralized surface water supply

Rw $=$ Recycled water

ET $=$ Evapotranspiration

W $=$ Wastewater flow

$\operatorname { R s } =$ Stormwater runoff

${ \bf G } =$ Groundwater infiltration

Cufw $=$ System loss/leakages

# 2.3.5 Method to measure urban water metabolic performance

Renouf et al. (2017a) proposed several indicators for evaluating urban water metabolism performance, including population and water use intensity, the degree of water system centralization, rainfall potential, wastewater reuse potential, stormwater harvesting potential,

and total water use replaceability (%). Table  4 lists the suggested indicators.

# 3 Results and discussion

# 3.1 Hydrometeorological trend and its implication for water sensitive intervention

# 3.1.1 Annual hydrometeorological trend

The gridded precipitation climate data was aggregated to generate annual and monthly rainfall Precipitation dataset spanning 28 years (1982–2022) reveals that the city experienced a mean annual rainfall of $8 3 9 . 4 4 \mathrm { m m }$ over this period. Notably, the city recorded a minimum rainfall of $4 6 1 \mathrm { m m }$ in 1985 and a maximum of $1 , 1 2 0 \mathrm { m m }$ in 2011. Leta et al. (2024) reported that the annual average rainfall of Adama city was approximately $8 6 6 . 2 5 \mathrm { m m }$ . Hirko et al. (2020) also reported that the annual minimum and maximum rainfall ranges from $6 7 8 . 1 \mathrm { m m }$ to $9 7 3 . 5 \mathrm { m m }$ over the years. Bulti et al. (2021) conducted the analysis of extreme precipitation over 2021–2070 and indicated that extreme precipitation can increase up to $4 9 . 5 \%$ . The present result showed that in Adama, most of the rainfall occurs between June and September with July and August being the wettest months (Figure 6). The findings indicated that rainfall ranges from a minimum of $6 . 1 9 \mathrm { m m }$ in December to a maximum of $2 1 8 . 9 0 \mathrm { m m }$ in July. Weather and Climate (2024) reported that the majority of monthly rainfall occurs in August and September, with August being the wettest month, receiving $1 3 6 \mathrm { m m }$ of precipitation. December, the driest month, sees just 5 mm of rainfall while the dry periods extend through January, February, November and December. The implication of the precipitation analysis reveals that there are possibility of flood occurrence and the city needs flood protection strategies that may include construction of additional drainage system.

The results indicate that both the yearly average maximum and minimum temperatures exhibit fluctuating variations. Additionally, the result revealed a slight increase in the annual average maximum temperature since 2018 (Figures 7, 8). The result indicates that the average annual maximum temperature is $2 8 . 4 2 ^ { \circ } \mathrm { C } ,$ while the minimum is $1 4 . 4 4 ^ { \circ } \mathrm { C }$ . Similarly, Weather and Climate (2024) reported a comparable figure, with an average annual maximum of approximately $2 9 . 7 ^ { \circ } \mathrm { C }$ and a minimum of around $1 3 . 1 ^ { \circ } \mathrm { C }$ .

# 3.1.2 Seasonal hydrometeorological characteristics

This study measured the average seasonal spatial rainfall distribution across Ethiopia, focusing on three key seasons. During the “Kiremt” (June to September), the main rainy season, rainfall ranged from a minimum of $4 9 6 . 7 - 5 2 4 . 1 4 \mathrm { { m m } }$ per season to a maximum of 589–615 mm. In the Belg season (March to May), known for its short and sporadic rains, the minimum rainfall ranged from 152.03 to $1 6 1 . 9 \mathrm { m m }$ , with a maximum between 181.2 and $1 8 7 . 9 \mathrm { m m }$ per season. Conversely, in the Bega season (October to January), characterized by dry conditions, the minimum rainfall varied from 47.9 to $5 1 . 4 \mathrm { m m }$ , while the maximum ranged from 60.2 to $6 3 . 5 \mathrm { m m }$ per season (Figure 9). Hirko et al. (2020) similarly reported that in Adama, the average rainfall during the Kiremt (rainy season) can reach up to $4 5 0 \mathrm { m m }$ .

![](images/ec85f083001dd149ba25c87b4087e336084c713ec451ff225081c5daf9ea20c9.jpg)  
FIGURE 5 Water mass balance components adopted from Kenway et al. (2011).

TABLE 4 Urban water performance indicators.   

<table><tr><td>Indicators</td><td>Method</td><td>Formula</td></tr><tr><td colspan="3">I. Population and water use intensity</td></tr><tr><td>Population density (people/km2)</td><td>Population/area</td><td>Pop/A</td></tr><tr><td>Intensity of water use (GL/km2)</td><td>Total water use/area</td><td>(C+D)/A</td></tr><tr><td colspan="3">II. Water system centralization</td></tr><tr><td>Water supply centralization (%)</td><td>Centralized supply/total water use</td><td>C/(C+D)*100</td></tr><tr><td>Rainfall harvesting potential (%)</td><td>Decentralized water/rainfall</td><td>D/P*100</td></tr><tr><td colspan="3">III. Rainfall potential for water supply</td></tr><tr><td>Centralized supply replaceability (%)</td><td>Rainfall/centralized water</td><td>P/C*100</td></tr><tr><td>Total use replaceability (%)</td><td>Rainfall/total use</td><td>P/(C+D)*100</td></tr><tr><td colspan="3">IV. Wastewater potential for water supply</td></tr><tr><td>Centralized supply replaceability (%)</td><td>Wastewater flow/centralized water supplied</td><td>W/C*100</td></tr><tr><td>Total use replaceability (%)</td><td>Wastewater flow/total water use</td><td>W/(C+D)*100</td></tr><tr><td colspan="3">V. Stormwater potential for water supply</td></tr><tr><td>Centralized supply replaceability (%)</td><td>Stormwater flow/centralized water supplied</td><td>Rs/C*100</td></tr><tr><td>Total use replaceability (%)</td><td>Stormwater flow/total water supplied</td><td>Rs/(C+D)</td></tr></table>

Sources: Reproduced from Renouf et al. (2017b).

The result also revealed that the distribution of evapotranspiration in Kiremt (rainy season), revealing a range from a minimum of 659–688 mm/day to a maximum of 795–834. In the Belg season (short and sporadic rains) the evapotranspiration fluctuates between 779 and 803 mm/day to 870–893mm/day. Conversely, during the Bega (dry season), maximum evapotranspiration falls within the range of 679–699mm/day with a peak ranging from 756 to 776mm. Growing literatures witnessed that the seasonal variation in potential evapotranspiration alongside temperature changes, directly and indirectly affects water availability and consumption patterns. Nie et al. (2022) highlight that estimating potential evapotranspiration in a given area is a key factor in understanding the water cycle and

developing future intervention strategies. Similarly, Yadeta et  al. (2020) emphasize that changes in the quantity and spatial extent of evapotranspiration can significantly impact surface and groundwater characteristics.

# 3.2 Measuring water mass balance using natural and anthropogenic water flows

The city’s water mass balance was evaluated by incorporating all water inflows (Table 5) and outflows (Table 6) into the water mass balance equation (Equations 2.11, 2.12). The assessment shows that

Average monthly Rainfall   
![](images/59a815bbe381782ddf831e7b85d0ec391a268597a7043cf92a7907f62a0211e9.jpg)  
FIGURE 6   
Average monthly precipitation (1982–2022).

![](images/16da1ec5e04f81ec965dc912ebf7559643562667cdc6f968e04b49d46758e517.jpg)  
FIGURE 7   
Average annual minimum temperature (1982–2022).

![](images/02c8329ab98785f75e223a356f24cd1a0724b37b5236a9b743bacf86cd76c9ae.jpg)  
FIGURE 8   
Average annual maxim temperature (1982–2022).

the total inflow is approximately 290.51 million cubic meters, while the total outflow is about 337.45 million cubic meters. This results in a negative urban water mass balance of $- 4 6 . 8 9$ million cubic meters per year.

$$
\begin{array}{l} \Delta S = \text {I n f l o w s} - \text {O u t f l o w s} \\ \Delta S = \Delta S = (P + C s + C g + D g + D s + R w + D r) - \\ \left(\mathrm {E T} + \mathrm {W} + \mathrm {R s} + \mathrm {G I} + \mathrm {C u f w}\right) \\ \end{array}
$$

$$
\Delta S = \left( \begin{array}{l} \left(2 6 2. 8 + 1 5. 4 8 + 1. 1 + 8. 8 2 + 0. 4 6 + 1. 4 + 0. 4 5\right) - \\ \left(1 9 4. 6 7 + 9. 5 + 7 2. 6 2 + 5 7. 7 1 + 2. 9\right) * 1 0 6 \mathrm {m} ^ {3} \end{array} \right)
$$

$$
\Delta S = \left(- 4 6. 8 9 ^ {*} 1 0 6 \mathrm {m} ^ {3} / \text {y e a r}\right)
$$

The water mass balance quantification reveals a negative storage change of approximately 46.89  million $\mathbf { m } ^ { 3 }$ per year. According to

![](images/93ca33684a477acfce61d2b54916c98898d8d2208f0b6cf3068f215a66af418b.jpg)  
Kiremt Rainy Season (June to September) Rainfall Distribution Map

![](images/48d3c46edbeaed2b8b5f731d7399834fd3ced62d9b6a9132ae49b7b2e44d17cf.jpg)  
Belg Season (March to May) Rainfall Distribution Map

![](images/d562fb02f1f3f9ea82bc720b8a7cf3422d71bbb8714eadd58acd60b61f7e4ccf.jpg)  
Bega Season (October to January) Rainfall Distribution Map   
FIGURE 9 Spatial distribution of seasonal rainfall distribution of Adama city. Source: Ethiopian metrology agency (2023).

Renouf et al. (2017a) and Kenway et al. (2011), a negative change occurs when water outflow exceeds inflow within an urban system. This reduction in water availability is attributed to factors such as urbanization, increased impermeable surfaces, landscape degradation, and climate change (Renouf et al., 2017a). Additionally, O’Geen (2013) indicated that increased evaporation, subsurface lateral flow, deep infiltration and runoff contribute to this negative storage change. The negative storage change indicates that urban water flow follows a linear model with increased outflow due to a lack of internal water harvesting systems, reflecting shortcomings in circular metabolism practices. This suggests the city fails to align with the “city as water supply catchment” principle. According to Wong and Brown (2009) adopting circular metabolism through different alternative water harvesting methods can help cities become self-sufficient water catchments that can potentially generate alternative water sources within their boundaries.

# 3.3 Measuring urban water metabolic performance of Adama city

The results in Table  7 indicate that Adama city’s population density is estimated at 13,685.5 people/km2 , classifying it as a very

high-density urban center. According to Matt (2019) urban areas with a population density of 1,501 people $/ \mathrm { k m } ^ { 2 }$ or more are considered very high-density. This elevated population density has significant implications, including an increasing demand for water each year. The intensity of water uses $8 6 , 2 6 1 \mathrm { m } ^ { 3 } / \mathrm { k m } ^ { 2 }$ implies the need for water wise management via water sensitive community technology and spatial planning.

Table 5 shows that the centralized water supply in Adama city is estimated at 16.6 million cubic meters per year, while the decentralized supply is 10.66 million cubic meters per year. Table 8 further indicates that the ratio of centralized to total water supply (centralized and decentralized) is $6 1 . 3 \%$ . This demonstrates a high level of centralization in Adama’s water supply system.

Table 8 indicates that if all precipitation were harvested, it could replace the centralized water supply by $1 , 5 8 2 . 8 \%$ . Similarly, runoff has the potential to substitute $4 3 7 . 9 \%$ of the centralized water supply. Wastewater production could replace $1 , 4 5 2 . 3 \%$ , while avoiding system losses would provide a $1 7 . 5 \%$ substitution potential. If all available wastewater, precipitation, and runoff were utilized, the centralized water supply could be replaced by $2 , 1 4 5 \%$ .

Table  9 indicated that total precipitation has the potential to substitute $9 7 3 \%$ of both centralized and decentralized water supply. This suggests that the volume of precipitation significantly exceeds the

TABLE 5 Inputs water flow of Adama city for the years in 2022/2023.   

<table><tr><td>Inputs water flow</td><td>Unit</td><td>Quantity</td></tr><tr><td>Precipitation</td><td>M3/year</td><td>262.75*10^6</td></tr><tr><td>Centralized water</td><td></td><td></td></tr><tr><td>Centralized surface water (Cs) (from Awash River)</td><td>M3/year</td><td>15.48*10^6</td></tr><tr><td>Centralized groundwater water wells</td><td>M3/year</td><td>1.088*10^6</td></tr><tr><td>Decentralized groundwater (Dg)</td><td></td><td></td></tr><tr><td>Industrial Park boreholes</td><td>M3/year</td><td>7.5*10^6</td></tr><tr><td>Other industries</td><td>M3/year</td><td>1.3*10^6</td></tr><tr><td>Hotel boreholes</td><td>M3/year</td><td>0.018*10^6</td></tr><tr><td>Subtotal</td><td></td><td>8.82*10^6</td></tr><tr><td>Decentralized surface water (Ds)</td><td></td><td></td></tr><tr><td>Water supply for urban greenery</td><td>M3/year</td><td>0.459*10^6</td></tr><tr><td>Recycled water (Rw)</td><td></td><td></td></tr><tr><td>Industrial Park</td><td>M3/year</td><td>0.756*10^6</td></tr><tr><td>Household water recycling</td><td>M3/year</td><td>0.164*10^6</td></tr><tr><td>Adama science and technology university</td><td>M3/year</td><td>0.478*10^6</td></tr><tr><td>Subtotal</td><td></td><td>1.4*10^6</td></tr><tr><td>Decentralized rainwater (Dr)</td><td></td><td></td></tr><tr><td>Household-level roof water harvesting</td><td>M3/year</td><td>0.287*10^6</td></tr><tr><td>Industries</td><td>M3/year</td><td>0.17*10^6</td></tr><tr><td>Subtotal</td><td>M3/year</td><td>0.45*10^6</td></tr><tr><td>Grand total</td><td>M3/year</td><td>290.51*10^6</td></tr></table>

TABLE 6 Output water flow of Adama city for the years 2022/2023.   

<table><tr><td>Inputs water flow</td><td>Unit</td><td>Quantity</td></tr><tr><td>Evapotranspiration (ET)</td><td>M3/year</td><td>194.67*10^6</td></tr><tr><td>Wastewater flow (W)</td><td>M3/year</td><td>9.49*10^6</td></tr><tr><td>Surface runoff (Rs)</td><td>M3/year</td><td>72.62*10^6</td></tr><tr><td>Groundwater infiltration (G)</td><td>M3/year</td><td>57.71*106</td></tr><tr><td>System loss</td><td>M3/year</td><td>2.9*10^6</td></tr><tr><td>Grand total</td><td>M3/year</td><td>337.45*106</td></tr></table>

TABLE 7 Population and water use intensity.   

<table><tr><td colspan="4">Population and water use intensity</td></tr><tr><td>Indicator</td><td>Unit</td><td colspan="2">Estimated values</td></tr><tr><td>Population density (people/km2)</td><td>Population/area</td><td>Pop/A</td><td>13,685.5</td></tr><tr><td>Intensity of water use (m3/km2)</td><td>Total water use/area</td><td>(C + D)/A</td><td>86,261</td></tr></table>

current water supply, highlighting the city’s potential for roof water harvesting. Additionally, runoff has the potential to replace $2 6 8 . 8 \%$ of the combined water supply, indicating that urban runoff can serve as an alternative water source. The results also show that improving system losses could lead to a $1 0 . 5 5 \%$ reduction in overall water supply needs. Furthermore, if all available wastewater and precipitation were utilized, the centralized and decentralized water supply could be replaced by $1 { , } 5 7 4 \%$ .

# 4 Conclusion and recommendation

Quantifying urban water mass balance provides key benefits for water-sensitive interventions. It establishes a baseline fact for both natural and anthropogenic water flows that can reinforce the understanding of water flow dynamics in urban landscape. By measuring water inflows and outflows, decision-makers gain precise data to guide their urban water management actions. Such findings can reveal how urbanization affects water flows while also identifying areas of water loss for targeted conservation efforts. Ultimately, urban water metabolism information derived from water mass balance are crucial to implement water sensitive interventions to improve the current and future water supply problems.

In conclusion, Adama city’s water mass balance indicates a significant challenge, with a negative change of $- 4 6 . 8 9$ million cubic meters per year due to urbanization and inadequate water harvesting systems. The high population density and water use intensity underscore the urgent need for efficient water management strategies. Despite the city’s reliance on centralized water supply $( 6 1 . 3 \% )$ , there is substantial potential for decentralized sources and alternative water harvesting. By adopting circular water management and treating the city as its own water catchment, Adama can transition into a watersensitive city. This transformation would involve fostering watersensitive communities, technologies, legal frameworks, and spatial planning. Based on the facts obtained, this research recommends the following water-sensitive strategies.

# 4.1 Implementing household and institutional based roof water harvesting

To capitalize on favorable rainfall conditions, it is essential to promote roof water harvesting systems at both household and institutional levels. Given their larger roof areas, industries, service institutions, and commercial establishments are wellpositioned to adopt this technology. Encouraging these sectors to implement roof water harvesting can significantly enhance water conservation and contribute to sustainable water resource management.

# 4.2 Enhancing circular stormwater management via water sensitive urban design

The circular metabolism is one of the emerging water sensitive city management approaches where all water wastes are considered as potential sources. The system can be supported by improving the design though urban design elements such as by providing permeable pavements, providing an integrated blue and green infrastructure.

# 4.3 Adopting water-efficient appliances

The traditional view of water as an unlimited resource is no longer valid. The reality today highlights water scarcity, making water-saving practices essential. To enhance water availability at both

TABLE 8 Centralized supply replaceability/supply substitution of alternative sources (2022/2023).   

<table><tr><td colspan="7">% of potential replaceability/substitution of centralized water supply</td></tr><tr><td>% of total C/(C + D)*100</td><td>Rainwater (P/C*100)</td><td>Runoff (RS/C*100)</td><td>Wastewater (W/C*100)</td><td>System loss (Cufw/C*100)</td><td>Wastewater and rainwater (W + P/C*100)</td><td>All Alternative Waters (W + P + Rs)/C*100</td></tr><tr><td>61.3</td><td>1,582.8</td><td>437.5</td><td>1,452.3</td><td>17.5</td><td>1,707.4</td><td>2,145</td></tr></table>

TABLE 9 Total use replaceability/supply substitution of alternative sources (2022/2023).   

<table><tr><td colspan="5">% of potential replaceability/substitution of both centralized and decentralized water supply</td></tr><tr><td>Rainwater P/(C + D)*100</td><td>Runoff water Rs/(C + D)*100</td><td>Wastewater W/(C + D)*100</td><td>System loss Cufw/(C + d*100)</td><td>Wastewater and rainwater (W + P)/(C + D)*100</td></tr><tr><td>973</td><td>268.8</td><td>34.56</td><td>10.55</td><td>1,574.02</td></tr></table>

institutional and household levels, the adoption of water-efficient appliances such as flow regulators, sensors, and the promotion of a water conservation mindset should be  integral to water-sensitive intervention strategies.

# 4.4 Integrating water sensitive water management in to urban land use planning

One of the most effective ways to establish water-sensitive management practices is by adopting a nature-based planning approach that integrates water-sensitive land use planning. This approach should focus on promoting water-sensitive urban development through strategies like Low-Impact Development, Sustainable Urban Drainage Systems, and Water Sensitive Urban Design and Planning. These strategies prioritize integrated water management, flood risk mitigation, water conservation, and the use of green infrastructure. Collaborative learning, community involvement, and innovative technologies are crucial for transitioning toward sustainable, water-resilient cities.

# Supplementary material

The Supplementary material for this article can be found online at: https://www.frontiersin.org/articles/10.3389/frwa.2024.1427788/ full#supplementary-material

Ara, Z., and Zakwan, M. (2018). Estimating runoff using SCS curve number method. Int. J. Emerg. Technol. Adv. Eng. 8, 195–200.

Berndtsson, R., Singh, V. P., and Das, K. (2016). Chow’s Handbook of Applied Hydrology (Second Edi). Mc GrawHill. Available at: https://www.researchgate.net/ publication/306097368_Chow’s_Handbook_of_Applied_Hydrology   
Bulti, D. T., Abebe, B. G., and Biru, Z. (2021). Climate change-induced variations in future extreme precipitation intensity-duration-frequency in flood-prone city of Adama, Central Ethiopia. Environ. Monit. Assess. 193:784. doi: 10.1007/s10661-021-09574-1   
Cao, Z., Wang, S., Luo, P., Xie, D., and Zhu, W. (2022). Watershed ecohydrological processes in a changing environment: opportunities and challenges. Water 14:1502. doi: 10.3390/w14091502   
Cayson, F. C., Flores, M. J. L., City, C., Science, E., and City, C. (2019). Runoff estimation using SCS runoff curve number method in CEBU Island. Int. Arch. Photogram. Remote Sens. Spatial Inf. Sci. XLII, 109–115. doi: 10.5194/isprs-archives-XLII-4-W19-109-2019   
Chen, C.-F., Lin, J.-W., and Lin, J.-Y. (2022). Hydrological cycle performance at a permeable pavement site and a raingarden site in a subtropical region. Land 11:951. doi: 10.3390/land11060951   
Cosgrove, W. J., and Loucks, D. P. (2015). Water management: current and future challenges and research directions. Water Resour. Res. 51, 4823–4839. doi: 10.1002/2014WR016869   
Cui, X., Wang, X., and Feng, Y. (2019). Examining urban metabolism: a material flow perspective on cities and their sustainability. J. Clean. Prod. 214, 767–781. doi: 10.1016/j. jclepro.2019.01.021   
Currie, P. K., and Musango, J. K. (2017). African urbanization: assimilating urban metabolism into sustainability discourse and practice. J. Ind. Ecol. 21, 1262–1276. doi: 10.1111/jiec.12517   
Derrible, S., Cheah, L., Arora, M., and Yeow, L. W. (2021). “Urban Metabolism” in Urban informatics. eds. W. Shi, M. F. Goodchild, M. Batty, M.-P. Kwan and A. Zhang (Singapore: Springer), 85–114.   
Farmwest. (2024). Effective precipitation. Farmwest.Com/. Available at: https:// farmwest.com/climate/calculator-information/et/effective-precipitation/ (Accessed July 28, 2024).   
Farooqui, T. A., Renouf, M. A., and Kenway, S. J. (2016). A metabolism perspective on alternative urban water servicing options using water mass balance. Water Res. 106, 415–428. doi: 10.1016/j.watres.2016.10.014   
Fu, C., Fath, B. D., Daigo, I., Zhang, Y., and Deng, T. (2022). Tracking urban metabolism flows through the lifecycle of buildings, infrastructure, and durable goods at material, product, and sector levels. J. Clean. Prod. 336:130402. doi: 10.1016/j. jclepro.2022.130402   
Hirko, A., Mergia, G., Dandesa, T., and Niguise, A. (2020). Seasonal and annual climate profile of Adama. SSRG Int. J. Geoinf. Geol. Sci. 7. doi: 10.20431/2454-9444.0701002   
IWA (2024). A brief history of water and health from ancient civilizations to modern times. London, UK: IWA Publishing.   
Juuti, P., Katko, T., and Vuorinen, H. (2007). Environmental history of water – global view on community water supply and sanitation. London, UK: IWA Publishing.   
Kennedy, C., Pincetl, S., and Bunje, P. (2010). The study of urban metabolism and its applications to urban planning and design. Environ. Pollut. 159, 1965–1973. doi: 10.1016/j.envpol.2010.10.022   
Kenway, S., Gregory, A., and McMahon, J. (2011). Urban water mass balance analysis. J. Ind. Ecol. 15, 693–706. doi: 10.1111/j.1530-9290.2011.00357.x   
Lee, K. K. F., Ling, L., and Yusop, Z. (2023). The revised curve number rainfall–runoff methodology for an improved runoff prediction. Water 15:491. doi: 10.3390/w15030491   
Leta, B. M., Adugna, D., and Wondim, A. A. (2024). Comprehensive investigation of flood-resilient neighborhoods: the case of Adama city, Ethiopia. Appl. Water Sci. 14:14. doi: 10.1007/s13201-023-02053-7   
Matt, Rosenberg. (2019). Population density information and statistics. www. thoughtco.com. Available at: https://www.thoughtco.com/population-densityoverview-1435467 (Accessed June 15, 2023).   
Moglen, G. (2009). Hydrology and impervious areas. J. Hydrol. Eng. 14, 303–304. doi: 10.1061/(ASCE)1084-0699(2009)14:4(303)   
Mugagga, F., and Nabaasa, B. B. (2016). The centrality of water resources to the realization of sustainable development goals (SDG). A review of potentials and

constraints on the African continent. Int. Soil Water Conserv. Res. 4, 215–223. doi: 10.1016/j.iswcr.2016.05.004   
Musango, J.K., Currie, P., and Robinson, B. (2017). Urban metabolism for resource efficient cities: from theory to implementation. Available at: https://resourceefficientcities. org/wp-content/uploads/2017/09/Urban-Metabolism-for-Resource-Efficient-Cities.pdf (Accessed April 20, 2023).   
Nie, T., Yuan, R., Liao, S., Zhang, Z., Gong, Z., Zhao, X., et al. (2022). Characteristics of potential evapotranspiration changes and its climatic causes in Heilongjiang Province from 1960 to 2019. Agriculture 12:2017. doi: 10.3390/agriculture12122017   
O’Geen, A. T. (2013). Soil water dynamics. California: Nature Education.   
Pistoni, R., and Bonin, S. (2017). Urban metabolism planning and designing approaches between quantitative analysis and urban landscape. City Territ. Archit. 4:20. doi: 10.1186/s40410-017-0076-y   
Renouf, M., Serrao-Neumann, S., Kenway, S., Morgan, E., and Low Choy, D. (2017a). Urban water metabolism indicators derived from a water mass balance – bridging the gap between visions and performance assessment of urban water resource management. Water Res. 122, 669–677. doi: 10.1016/j.watres.2017.05.060 (Accessed March 20, 2023).   
Renouf, M., Sochacka, B., Kenway, S., Lam, K. L., Serrao-Neumann, S., Morgan, E., et al. (2017b). Urban metabolism for planning water sensitive city-regions: proof of concept for an urban water metabolism evaluation framework B1.2 milestone report. 1–55. Available at:. https://watersensitivecities.org.au/wp-content/ uploads/2017/12/Milestone-Report-Urban-metabolism_FINAL-1.pdf (Accessed March 20, 2023).   
Satheeshkumar, S., Venkateswaran, S., and Kannan, R. (2017). Rainfall–runoff estimation using SCS–CN and GIS approach in the Pappiredipatti watershed of the Vaniyar sub basin, South India. Model. Earth Syst. Environ. 3:24. doi: 10.1007/ s40808-017-0301-4   
Serrao-Neumann, S., Renouf, M., Kenway, S. J., and Low Choy, D. (2017). Connecting land-use and water planning: prospects for an urban water metabolism approach. Cities 60, 13–27. doi: 10.1016/j.cities.2016.07.003   
Serrao-Neumann, S., Renouf, M. A., Morgan, E., Kenway, S. J., and Low Choy, D. (2019). Urban water metabolism information for planning water sensitive city-regions. Land Use Policy 88:104144. doi: 10.1016/j.landusepol.2019.104144   
Teshome Tefera Tola, A. Z. K., and Wegayehu, F. (2019). Undertaking urban metabolism analysis in a data poor context: the metabolism of housing construction materials in Amdework – a small town in Ethiopia. Int. J. Urban Sustain. Dev. 11, 172–188. doi: 10.1080/19463138.2019.1618859   
The U. S. Department of Agriculture (USDA) (1986). Urban hydrology for small watersheds Technical Release 55. Available at: https://www.nrc.gov/docs/ML1421/ ML14219A437.pdf   
UNICEF (2023). Building access to clean water in support of sustainable development goal 6. Copenhagen, Denmark: UNICEFSupply Division.   
USDA-SCS. (1986). Urban hydrology for small watersheds. Washington, DC: USDA.   
Weather and Climate. (2024). Adama precipitation: average monthly rainfall and snowfall. World Weather & Climate Information all Rights Reserved. Available at: https://weather-and-climate.com/average-monthly-precipitation-Rainfall,adamaet,Ethiopia (Accessed August 24, 2024).   
Wong, T. H. F., and Brown, R. R. (2009). The water sensitive city: principles for practice 60, 673–682. doi: 10.2166/wst.2009.436   
Wong, T. H. F., Rogers, B. C., and Brown, R. R. (2020). Transforming cities through water-sensitive principles and practices. One Earth 3, 436–447. doi: 10.1016/j. oneear.2020.09.012   
Yadeta, D., Kebede, A., and Tessema, N. (2020). Potential evapotranspiration models evaluation, modelling, and projection under climate scenarios, Kesem sub-basin, Awash River basin Ethiopia. Model. Earth Syst. Environ. 6, 2165–2176. doi: 10.1007/ s40808-020-00831-9   
Zhang, Y., Yang, Z., and Yu, X. (2015). Urban metabolism: a review of current knowledge and directions for future study. Environ. Sci. Technol. 49, 11247–11263. doi: 10.1021/acs.est.5b03060   
Zhou, Q., Deng, X., and Wu, F. (2017). Impacts of water scarcity on socio-economic development: a case study of Gaotai County, China. Phys. Chem. Earth Parts A/B/C 101, 204–213. doi: 10.1016/j.pce.2017.03.009
