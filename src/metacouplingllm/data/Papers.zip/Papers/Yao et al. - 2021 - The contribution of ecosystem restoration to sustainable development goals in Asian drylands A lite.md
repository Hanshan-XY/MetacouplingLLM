# The contribution of ecosystem restoration to sustainable development goals in Asian drylands A lite

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:15:10.335923+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Yao et al. - 2021 - The contribution of ecosystem restoration to sustainable development goals in Asian drylands A lite.pdf
- Year: unknown
- DOI: 10.1002/ldr.4065
- OA status: closed
- License: none recorded
- Category: Journal Articles\Review\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This review examines how large ecosystem restoration programs in Asian drylands support or hinder progress toward key Sustainable Development Goals (SDGs), with emphasis on SDG 15 (Life on Land), SDG 13 (Climate Action), SDG 6 (Clean Water and Sanitation), SDG 1 (No Poverty), and SDG 2 (Zero Hunger). It synthesizes published evidence on 23 major initiatives across 38 Asian dryland countries, focusing on China, Iran, Mongolia, and Israel, including forest and grassland restoration, desertification control, and water management projects.

The authors classify restoration approaches into natural forest protection, planted forests, grassland recovery, anti-desertification engineering and chemical measures, and water resource schemes such as diversion, rainwater harvesting, wastewater reuse, and drip irrigation. They then evaluate social-ecological outcomes relative to SDGs, identifying both synergies and trade-offs.

Many programs jointly enhance several SDGs. Water diversion and rainwater harvesting in China and Israel can simultaneously raise vegetation cover, carbon sequestration, water availability, farm output, and income. Payment for ecosystem services in Chinas Grain for Green and grassland policies increases vegetation and carbon while compensating rural households, helping both poverty reduction and food security. Water-saving technologies and wastewater reuse in Israel strengthen the link between water efficiency, agricultural production, and farm livelihoods.

However, restoration often generates conflicts. Converting cropland or grazing land to ecological uses can lower local food production or livestock income, creating tensions between SDG 15 and SDGs 1 and 2. Large-scale afforestation and ecological flows consume scarce water, reducing supplies for agriculture and households and undermining SDG 6 and SDG 2.

To manage these interactions, the paper proposes a social-ecological framework linking four ideas: dryland boundaries (water, land, carbon limits), the water-food-energy-ecosystem nexus, the metacoupling concept (intra-, peri-, and tele-couplings among regions), and nature-based solutions emphasizing local ecological fit and community participation. The metacoupling lens is central: it highlights how restoration in one place redistributes water, materials, and benefits across distances, creating telecoupled synergies and spillover trade-offs that must be addressed for sustainable dryland restoration.

## Structured Metacoupling Extraction

### Coupling Classification
- Explicit metacoupling framing for dryland restoration across intra, peri, and telecoupled systems

### Intracoupling
#### Systems
- Local dryland social ecological systems in Asian countries
- River basins such as Heihe and Tarim within national borders
- Village and pastoral landscapes undergoing restoration
#### Flows
- Local water allocation among ecosystems, farming, and households
- Land conversion between cropland, grassland, and forest
- Payments for ecosystem services to resident households
#### Agents
- National and local governments designing restoration programs
- Farmers and herders adapting land use and livelihoods
- Water managers and forestry agencies implementing projects
#### Causes
- Ecosystem degradation from overuse, drought, and climate change
- National goals for SDGs, land degradation neutrality, and poverty reduction
- Sectoral policies for water security, agriculture, and afforestation
#### Effects
- Improved vegetation cover, carbon storage, and reduced desertification
- Changes in household income, employment, and food security
- Local trade offs between ecological land, farmland, and water uses

### Pericoupling
#### Systems
- Upstream, midstream, and downstream regions of shared rivers
- Adjacent dryland provinces or countries around deserts
- Urban centers linked to surrounding restoration areas
#### Flows
- Managed river diversions from upstream to downstream ecosystems
- Virtual water and food flows between agricultural and urban regions
- Migration of herders or workers responding to restoration policies
#### Agents
- Basin level authorities coordinating water allocation
- Neighboring provincial governments with competing demands
- Interregional agricultural and industrial enterprises
#### Causes
- Water diversion projects for downstream ecosystem recovery
- Expansion of irrigated agriculture affecting neighboring users
- Regional strategies for wind and sand control across borders
#### Effects
- Downstream ecological recovery with upstream water scarcity risks
- Shifting agricultural production and employment across regions
- Spillover of land and water conflicts to neighboring areas

### Telecoupling
#### Systems
- Asian dryland restoration regions and distant global markets
- Israeli desert agriculture linked to Europe and Africa
- Global climate system interacting with dryland carbon dynamics
#### Flows
- Trade in high value agricultural products from restored drylands
- Virtual water and embedded energy in export commodities
- Greenhouse gas and dust fluxes influencing distant regions
#### Agents
- International consumers and agribusiness supply chains
- Multinational investors in water saving technologies
- Global environmental institutions promoting SDGs and restoration
#### Causes
- Demand for export crops produced with water saving irrigation
- Global climate mitigation and carbon neutrality commitments
- International initiatives like the UN Decade on Ecosystem Restoration
#### Effects
- Economic benefits in drylands tied to distant market volatility
- Teleconnected carbon sequestration contributing to climate goals
- Potential displacement of environmental pressures to other regions

### Cross-Coupling Interactions
- Water transfers create intra basin gains but reduce upstream availability with broader regional implications
- Vegetation restoration enhances global carbon benefits while intensifying local water competition
- Payments for ecosystem services reshape local livelihoods and support export oriented agriculture

### Research Gaps or Limitations
- Limited quantification of multi scale metacoupling impacts on SDG synergies and trade offs
- Uncertain dryland boundaries for water, land, and carbon carrying capacities
- Need for models integrating WFEE nexus with metacoupling across spatial scales

### Search Keywords
- Asian dryland ecosystem restoration SDGs metacoupling
- water food energy ecosystem nexus drylands
- afforestation grassland restoration water diversion trade offs

### Extraction Confidence
high
