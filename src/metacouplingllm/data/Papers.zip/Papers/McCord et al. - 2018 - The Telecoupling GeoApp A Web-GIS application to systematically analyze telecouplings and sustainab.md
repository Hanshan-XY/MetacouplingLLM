# The Telecoupling GeoApp A Web-GIS application to systematically analyze telecouplings and sustainab

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:58:44.437102+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: McCord et al. - 2018 - The Telecoupling GeoApp A Web-GIS application to systematically analyze telecouplings and sustainab.pdf
- Year: unknown
- DOI: 10.1016/j.apgeog.2018.05.001
- OA status: closed
- License: none recorded
- Category: Journal Articles\Methodological\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper presents the Telecoupling GeoApp, a web-based geographic information system designed to implement the telecoupling framework for sustainability analysis. The work is global in scope, with a methodological focus, and draws on a detailed case study of soybean trade between Brazil (sending system) and China (receiving system). It is fully about telecoupling and how to operationalize it.

The GeoApp is part of the broader Telecoupling Toolbox and runs as a web-GIS on ESRI and Amazon Web Services infrastructure. It targets researchers and practitioners who need to analyze long-distance interactions among coupled human and natural systems without desktop GIS installation or proprietary licenses. The application is modular and spatially explicit, organizing tools into widget categories for mapping and visualization, querying and selection, satellite imagery analysis, and telecoupling-specific analysis.

Telecoupling analysis widgets map systems, agents, and flows, and provide quantitative tools for causes and effects. Effects are split into environmental and socioeconomic analysis, many of which are linked to InVEST ecosystem service models. Users can quantify land cover change, carbon stocks, habitat quality, crop production, tourism, economic costs and benefits, and nutrition-related indicators.

To demonstrate functionality, the authors analyze the Brazil-China soybean telecoupling, focusing on land conversion in Mato Grosso, Brazil, as the sending system. Using Landsat-based change detection, they identify substantial forest-to-cropland conversion from 1999–2004. A forest carbon edge effect tool estimates large above-ground carbon losses from cleared plots. Habitat quality modeling for the giant anteater shows declines in habitat suitability associated with roads and agricultural expansion. Crop production analysis reveals that newly converted land has soybean yields exceeding state averages, underscoring a trade-off between food production and environmental impacts.

The authors emphasize that the GeoApp can link specific flows and systems to multiple Sustainable Development Goals, especially those on climate, terrestrial ecosystems, food security, and infrastructure. Planned extensions include richer social and food security widgets and better support for receiving and spillover systems, reinforcing the GeoApp as a practical platform for metacoupling research and policy-relevant sustainability assessments.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling focus with supporting intra and potential peri interactions

### Intracoupling
#### Systems
- Brazilian soybean production landscapes in Mato Grosso and other states
- Chinese domestic food and feed consumption systems
#### Flows
- Internal land use change from forest or pasture to cropland
- Domestic soybean transport within Brazil to ports and crushing facilities
#### Agents
- Brazilian smallholder and large-scale farmers
- National and subnational government agencies in Brazil and China
#### Causes
- National policies on agriculture, infrastructure, and trade liberalization
- Rising domestic meat demand and dietary changes
#### Effects
- Local deforestation and habitat loss in Mato Grosso
- Changes in regional carbon stock and biodiversity indicators

### Pericoupling
#### Systems
- Neighboring Brazilian states and biomes bordering Mato Grosso
- Transit countries and ports involved in soybean shipping routes
#### Flows
- Overland soy transport through adjacent regions toward export hubs
- Potential nutrient and pollution runoff into nearby river basins
#### Agents
- Regional logistics companies and port authorities
- Local communities affected along transport corridors
#### Causes
- Infrastructure expansion connecting interior farms to coastal ports
- Spillover impacts from export-oriented agricultural policies
#### Effects
- Land cover and habitat changes in bordering regions
- Local environmental pressures near ports and transport corridors

### Telecoupling
#### Systems
- Brazil as sending system exporting soybeans
- China as receiving system importing soybeans
#### Flows
- International soybean trade from Brazil to Chinese cities
- Embodied CO2 and ecosystem services in traded soy
#### Agents
- Farmers, traders, and agribusiness corporations
- International organizations like WTO shaping trade rules
#### Causes
- Chinese WTO accession and reduced trade barriers
- Growth of Chinese middle class and meat consumption
#### Effects
- Deforestation and CO2 emissions from Brazilian land conversion
- Improved food and feed supply in China

### Cross-Coupling Interactions
- Telecoupled soy demand amplifies intracoupled deforestation and local land change
- Environmental effects in Brazil feed back into global climate systems

### Research Gaps or Limitations
- Uncertain exact destinations of soy from analyzed Mato Grosso plots
- Limited treatment of receiving and spillover system social outcomes

### Search Keywords
- Telecoupling GeoApp web GIS
- Brazil China soybean telecoupling

### Extraction Confidence
high
