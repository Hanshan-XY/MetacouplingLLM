# Spatiotemporal Differentiation and the Formation Mechanism of Transnational Women Trafficking in Anh

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:39:56.519194+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Dandan et al. - 2022 - Spatiotemporal Differentiation and the Formation Mechanism of Transnational Women Trafficking in Anh.pdf
- Year: unknown
- DOI: 10.13284/j.cnki.rddl.003541
- OA status: unknown
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: no license info, oa_status=unknown

## Copyright-Safe Summary
This study analyzes cross-border trafficking of women into Anhui Province, China, using a spatial-telecoupling perspective. The authors compile 151 criminal cases (2008-2022) from China Judgments Online, and extract information on offenders, victims, buyers, timing, locations, and routes. They then apply descriptive statistics and GIS-based spatial and hotspot analysis to characterize group profiles, temporal evolution, spatial patterns, trafficking paths, and formation mechanisms.

The work focuses on trafficking from Vietnam, Myanmar, Cambodia, and Laos into Anhui, with key transit links in Yunnan and Jiangxi. Offenders are mostly low-educated men aged roughly 31-50, often Han or Miao, living in Yunnan or Anhui. Victims are predominantly Vietnamese women who are lured by promises of work or marriage, sometimes entering China illegally before being sold. Buyers are mainly low-educated male farmers of marriageable age and their parents in economically lagging rural areas.

Temporally, cases rise from a low, fluctuating level (2003-2009), surge with multiple peaks up to 2017, then drop sharply after 2018. The authors link this pattern to skewed sex ratios, rising marriage pressures and bride prices, evolving anti-trafficking laws and enforcement, and the growing transparency of judicial documents online.

Spatially, origins cluster in neighboring Southeast Asian countries and several Chinese provinces; transit provinces form an arc with Yunnan as a core border hub; transit cities are concentrated along provincial and national borders. Destination cities and counties in northern and central Anhui display distinct arc-like and clustered patterns, with clear geographic-neighbor preferences and shifting hotspots over time.

Using push-pull migration theory combined with telecoupling (distant coupling), the paper frames trafficking as an abnormal, market-like population flow linking sending, transit, and receiving systems through agents (offenders and buyers), victim flows, and money/information flows. It explicitly contributes to telecoupling/metacoupling research by conceptualizing trafficking as coupled distant, adjacent, and internal human-environment interactions, and derives policy suggestions for coordinated control across origins, transit hubs, and receiving rural areas.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling among Southeast Asia, Yunnan transit, and Anhui destinations

### Intracoupling
#### Systems
- Rural counties in northern and central Anhui as receiving systems
- Border and inland Chinese provinces acting as internal transit systems
#### Flows
- Incoming foreign brides integrated into poor Anhui villages
- Money and information exchanged between buyers and traffickers
#### Agents
- Local single male farmers and their parents
- County level traffickers organizing reception and concealment
#### Causes
- Imbalanced sex ratio and marriage squeeze in Anhui villages
- Low education, traditional son preference, and high bride price
#### Effects
- Illegal marriages and hidden foreign population in rural Anhui
- Social risks to public order and local governance

### Pericoupling
#### Systems
- Anhui counties bordering Henan, Jiangsu, and Jiangxi
- Yunnan border prefectures adjacent to Vietnam and Myanmar
#### Flows
- Short distance transfers across provincial borders to Anhui
- Cross border movement of ethnic minorities along shared frontiers
#### Agents
- Cross border ethnic brokers familiar with terrain and language
- Interprovincial trafficking networks coordinating pickup and delivery
#### Causes
- Geographic proximity and convenient transport at provincial borders
- Shared ethnic culture and long term intermarriage traditions
#### Effects
- Hotspot transit cities at provincial and border junctions
- Expanded trafficking risk zones along provincial frontiers

### Telecoupling
#### Systems
- Sending systems in Vietnam, Myanmar, Cambodia, and Laos
- Receiving system of northern and central Anhui rural areas
#### Flows
- Trafficked women moved along Vietnam Yunnan Anhui routes
- Financial profits and crime information circulating across countries
#### Agents
- Transnational trafficking rings operating multi stage routes
- Foreign women victims seeking jobs or marriage abroad
#### Causes
- Economic disparities and low female status in origin countries
- Strong demand for wives in Chinese areas with surplus men
#### Effects
- Human rights violations and psychological harm to victims
- Threats to national image, border security, and social stability

### Cross-Coupling Interactions
- Push pull dynamics link distant sending regions with Anhui demand
- Transit provinces mediate and reinforce sending receiving system coupling

### Research Gaps or Limitations
- Judgment data cover only solved cases, underestimating true volume
- Offender roles not finely classified, crime networks underexplored

### Search Keywords
- transnational women trafficking Anhui telecoupling
- Vietnam bride trafficking Yunnan transit paths

### Extraction Confidence
high
