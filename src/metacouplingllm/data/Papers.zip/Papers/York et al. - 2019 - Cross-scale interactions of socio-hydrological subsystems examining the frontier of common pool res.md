LETTER • OPEN ACCESS

# Cross-scale interactions of socio-hydrological subsystems: examining the frontier of common pool resource governance in Arizona

To cite this article: Abigail M York et al 2019 Environ. Res. Lett. 14 125019

View the article online for updates and enhancements.

# You may also like

Off-stage ecosystem service burdens: Ablind spot for global sustainability Unai Pascual, Ignacio Palomo, William M Adams et al.   
Overview of multiscale turbulence studiescovering ion-to-electron scales in magnetically confined fusion plasma S. Maeyama, N.T. Howard, J. Citrin et al.   
Critical minerals for electric vehicles: atelecoupling review Datu Buyung Agusdinata, Hallie Eakin and Wenjuan Liu

![](images/40e520974f0ec9046ed295a20cd302022664811b7c08ca4ad4493368fadb7aca.jpg)

250th ECS Meeting

Otober 25-29, 2026

Calgary, Canada

BMO Center

![](images/165078090e6501a1ecbd9ae3d346f3f5f41d0128358b0d460f88ef3d153a625e.jpg)

The Electrochemical Society

Advancing solid state & electrochemical science & technology

Stepintothe

Spotlight

SUBMIT YOUR

ABSTRACT

Submission deadline:

March 27, 2026

# Environmental Research Letters

![](images/e0e9869c2bdcb3a9469adacbfc3c97c5a40a8e8ad80ea86b755e4be283e9017d.jpg)

CrossMark

# OPEN ACCESS

# LETTER

# Cross-scale interactions of socio-hydrological subsystems: examining the frontier of common pool resource governance in Arizona

RECEIVED

18 June 2019

REVISED

22 October 2019

ACCEPTED FOR PUBLICATION

28 October 2019

PUBLISHED

23 December 2019

Original content from this work may be used under the terms of the Creative Commons Attribution 3.0 licence.

Any further distribution of this work must maintain attribution to the author(s) and the title of the work, journal citation and DOI.

![](images/d2c643f1b59916d8c5bf05bda3d6addb26f96d99ef85f25533f650b3b1da90fa.jpg)

# Abigail M York1,4 , Abigail Sullivan2 and Julia C Bausch3

1 School of Human Evolution and Social Change, Arizona State University, United States of America   
2 Environmental Resilience Institute, Indiana University, United States of America   
3 Kyl Center for Water Policy, Arizona State University, United States of America   
4 Author to whom any correspondence should be addressed.

E-mail: abigail.york@asu.edu

Keywords: water, governance, socio-hydrology, coupled natural human system, telecoupling, scale

# Abstract

A critical frontier of water management in the western US is the challenge of cross-scale interactions. It is difficult to establish clear governance boundaries and collectively act when basins are interconnected, surface water and groundwater flows are interrelated, and urban and rural water demands are increasingly affected by regional and international telecoupling. Changing climate, snowpack, and rainfall, peri-urbanization, and shifting economics of rural landscapes further increase sustainable governance challenges. Using a lens of cross-scale interactions drawn from the social-ecological literature, we develop a set of conceptual frames for socio-hydrology that highlight:

(1) spatial and temporal mismatches, (2) telecoupled flows, and (3) networked and nested systems. Using the exemplary case of Central Arizona, we explore nesting of the system within the larger western sociohydrological system (SHS), impacts of changing Colorado River policies, such as the Drought Contingency Plan, and emerging institutional arrangements between the State of Arizona, agricultural communities, and Tribal Nations. We conclude with a set of questions that inform analyses of crossscale, multi-level governance within social-ecological systems. Without grappling with the dynamics and interconnectedness of SHSs, we cannot sustainably manage water in an increasingly arid West.

# Introduction

The critical frontier of water management in the western United States is due to the interconnectedness of hydrological basins, groundwater and surface water flows, and different management demands of urban and agricultural use such as the timing, flow, and quality. We focus on how system components are connected across scales or through telecoupling (Liu et al 2013). Telecoupling is ‘socioeconomic and environmental interactions over vast distances (Liu et al 2015: 1258832–3).’ We utilize Liu et al ’s (2015) framing of telecouples to include distant markets for agricultural products, ‘virtual water’ in international supply chains, water sources supplied by snowpack in mountain ranges across the West, and changes in governance at various levels that affect water decisionmaking in connected subsystems and across scales.

Over the past two decades, social-ecological systems and socio-hydrological systems (SHSs) conceptual frames emerged in response to the need for systems thinking and interdisciplinary scholarship to both understand and respond to crises in inherently complex systems (e.g. Walker et al 2002, Dietz et al 2003, Altaweel et al 2009). Some of this work draws on Ostrom’s (2005) insights about sustainably managing resources, such as the need to establish governance boundaries. Using a lens of cross-scale interactions amongst subsystems drawn from the social-ecological scholarship (Ostrom 2009), we develop a set of conceptual frames to advance our understanding of crossscale dynamics and the challenges and opportunities of multi-level governance of western water. We explore these issues with empirical insights from the exemplary case of Central Arizona. We conclude with

![](images/aa687378a233b128aa78df250210372baf56480fa9be154394449fae9ccd1142.jpg)  
Figure 1. Socio-hydrological system (Adapted from Eakin et al 2017).

a proposal for analyses of cross-scale, multi-level governance within social-ecological systems focusing on a set of critical questions. Without grappling with the dynamics and interconnectedness of SHSs, we cannot sustainably manage water in an increasingly arid West.

# Conceptualizing SHSs

Watersheds have been conceptualized as one of the relevant systems for resource governance in the West at least since John Wesley Powell’s famous report to Congress in the early 20th century. The US Geological Survey employs nested water basin categories based mainly on surface water flows as their primary analytical unit. Watersheds through special purpose districts (e.g. irrigation districts, drainage districts, or water control districts) and collaboratives are commonly used to manage water resources throughout the US (Imperial 2005, Ostrom 2011, Koontz and Newig 2014). Even though hydrological units serve as a foundation for governance of (some) water throughout the West, these multi-level governing bodies often fall short in managing the growing cross-scale linkages and telecoupling between distant basins.

A new and rapidly expanding literature on SHSs provides a framework to wrestle with these challenges. SHS largely follows a coupled natural human systems framing but explicitly incorporates water infrastructure (see for example Sivapalan et al 2012). SHS scholarship recognizes connections among basins and other spatially distant locations, e.g. through virtual water or via teleconnections (Savenije et al 2013) and we argue should explicitly move beyond teleconnections, conceptualized as biophysical flows, to include telecoupling from land system science (Friis et al 2016, Martín-López et al 2019). In SHSs, one important telecouple is related to the ‘precipitationshed’ where land use affects evapotranspiration in one area and precipitation in another (Keys et al 2012). Largely absent in this literature is the rich understanding of water governance gained by parsing the relationships between policies and norms, actors, and the

underlying resource, water; examining these components of the system helps us to understand, and overcome, collective action challenges required to sustainably manage water (i.e. Ostrom 1990, 2005).

SHS frameworks include feedbacks between the natural and built environment and human subsystems, or hydrology and society, but there is not careful nesting of systems and cross-scale dynamics. To conceptualize cross-scale, multi-level water governance, we build upon the social-ecological systems framework (Ostrom 2009), which incorporates nesting and dynamics between components of the system. A related conceptual framework was developed to understand Mexico City’s socio-hydrology incorporating a socio-political infrastructure with mental models, specific ‘action situations’ where public and private sectors interact (with given relations of power and influence), and formal and informal institutional arrangements (Eakin et al 2017). The conception of an action situation originated in the Institutional Analysis and Development Framework (Kiser and Ostrom 1982). Action situations are where actors generate rules and implement policies and also engage less consciously with norms and strategies (Ostrom 2005). Eakin et al (2017) conception explicitly considers power and influence a domain often overlooked by institutional scholars (Clement 2010). This socio-political infrastructure is coupled with decisions about land use, changes in weather patterns and the hydrological system, which in turn leads to differences in vulnerability and socio-hydrological risk. Sociohydrological vulnerability outcomes influence mental models, interactions, and socio-political infrastructure (figure 1).

Eakin et al (2017) conceptual framework encourages researchers to examine risk and vulnerability, ideas that are largely absent or undefined in similar frameworks, such as the social-ecological systems framework (Ostrom 2009), but well developed within geography and relevant to understanding how changing environments and institutions affect individual experiences, which in turn affect mental models of actors (see Baeza et al 2019). But where all these related

![](images/3d626d9c17c8456e380d1439a0f23695d1975647ab47facfb7b8cf798325eff1.jpg)  
Figure 2. Socio-hydrological system through time.

![](images/976130b8801f3e10d89f75a90ab4f3b014127a97039bc68da28d603c19f5408a.jpg)  
Figure 3. Conceptual diagram of multi-level socio-hydrological relationships (Adapted from Sayles and Baggio 2017).

frameworks, SHS, SES, and IAD, typically fall short is with regard to change through time; to visualize this, we layer the system indicating snapshots of the system at different points in time and allowing examination of change through time (figure 2). Recent work has focused on the impact of developing infrastructure on long-term vulnerabilities in SHSs (e.g. Tellman et al 2018). Action situations lead to decisions in the built environment and interact with the hydrological system and in turn affect socio-hydrological risk. Di Baldassarre et al (2018) describes a particular type of feedback in irrigated agricultural SHSs, the ‘reservoir effect,’ where a choice to build a reservoir leads over time to increased water demand exceeding the capacity of the system. Critical insights such as this require a temporal dimension (figure 2).

However, even this modified socio-hydrological framework does not encompass the known

teleconnections, telecoupling, and cross-scale flows between systems and subsystems. Telecoupled and virtual water flows are significant but largely ignored if we fail to nest a SHS and network it. Thus, we borrow from the emerging literature on networks in socialecological systems (Sayles and Baggio 2017, Sayles et al 2019).

Connections between local, regional, state, and national actors (tan circles) and between the social and hydrological dimensions (green watersheds) can be graphically depicted using a coupled network (figure 3). While figure 3 illustrates important network linkages between actors and hydrologies, the relevant detail in figure 2 has not been adequately integrated. Variables such as the dynamics of the system through time, the mental models, institutions, and interactions, or the relevant climatic and weather changes that affect hydrology are absent from most network

Table 1. Definition of key terms related to scale and level. Reprinted from Gibson et al (2000), copyright (2000), with permission from Elsevier.   

<table><tr><td>Term</td><td>Definition</td></tr><tr><td>Scale</td><td>The spatial, temporal, quantitative, or analytical dimensions used to measure and study any phenomenon.</td></tr><tr><td>Extent</td><td>The size of the spatial, temporal, quantitative, or analytical dimensions of a scale.</td></tr><tr><td>Resolution</td><td>The precision used in measurement.</td></tr><tr><td>Hierarchy</td><td>A conceptually or causally linked system of grouping objects or processes along an analytical scale.</td></tr><tr><td>Levels</td><td>The units of analysis that are located at the same position on a scale. Many conceptual scales contain levels that are ordered hierarchically, but not all levels are linked to one another in a hierarchical system</td></tr></table>

depictions. Instead of adding all the complexity to a single conceptual frame, we adopt a set of related conceptual frames. In order to further refine our conceptual framing, we must consider scale in an explicit way (Gibson et al 2000) (table 1).

As Gibson et al (2000) note, scale is ‘the spatial, temporal, quantitative, or analytical dimensions used to measure and study any phenomenon’, while level is ‘the units of analysis that are located at the same position on a scale. Many conceptual scales contain levels that are ordered hierarchically, but not all levels are linked to one another in a hierarchical system’ (218). Cross-scale and cross-level challenges arise when there is ignorance (lack of knowledge about the system dynamics), mismatch (frequently a mismatch between governance and biogeophysical scale), and plurality (not all actors in the system have the same ‘best’ scale or level) (Cash et al 2006). For our purposes, some of the key scales include spatial scales such as the watershed, region, and groundwater basin, and temporal scales related to decisions, such as daily, seasonal, annual, decadal, and generational. Cross-scale temporal dynamics result from decisions regarding land use, e.g. developing an agricultural parcel, which in turn may affect daily decisions about water, such as the inability to fallow residential parcels. Relevant levels include hierarchies of governing units, such as parcels nested within jurisdictions, and polycentricity: multiple overlapping authorities at the same level (e.g. local authorities with overlapping extents) and/or overlapping authorities at different levels (i.e. parts of counties within or outside Active Management Areas (AMAs) (the state’s groundwater management areas). All three of Cash et al’s (2006) scale challenges arise in our case.

# Case

Arizona is frequently criticized, even ridiculed for rapid, unsustainable growth (i.e. Ross 2013). Somewhat paradoxically, it has also been heralded for the 1980 Groundwater Management Act, a water policy achievement that primarily focuses on managing groundwater supplies surrounding urban centers (Jacobs and Holway 2004). By shifting water sources from nonrenewable groundwater resources to Colorado River water flowing through the Central Arizona Project (CAP) to Phoenix, the Phoenix AMA has made

significant strides toward achieving the goal of ‘safe yield’ of groundwater (Arizona Department of Water Resources 2009). Safe yield is defined by groundwater withdrawals not exceeding the recharge through rain or injections of surface water flows into groundwater basins (e.g. through the Central Arizona Water Banking Authority). We focus on Central Arizona, which we define as Maricopa County (where Phoenix is located) and Pinal County (a rapidly urbanizing county south of the Phoenix metro); these two counties are served by the CAP, as well as utilize groundwater and other surface water sources. The purpose of this case is to illustrate the tensions between competing uses and governance challenges in hydrologically interconnected social-ecological systems. These tensions are heightened with the anticipated changes in Colorado River water availability under the recently finalized Drought Contingency Plan and potential declaration of shortage in Lake Mead.

Since 1980 Arizona has managed groundwater through AMAs, which are defined by the state legislature and managed by the state Department of Water Resources with input from local stakeholders. Importantly there are large sections of land area in Arizona that are not restricted by the Groundwater Management Act. Governance of surface water in Arizona, like most of the West, is based upon prior appropriation where the oldest users of water (or more accurately the parcels of land with the oldest use of water) have the most secure water rights (Reich 1995). In times of shortage, prior appropriation leads to the most junior user losing a right first, and then the next most junior, and so on. These surface water rights are adjudicated through the courts, while groundwater within regulated areas (AMAs and Irrigation Nonexpansion Areas) is based (mostly) upon historic use and managed by the Department of Water Resources. Water claims are also subject to settlements associated with the Winters Doctrine, a US Supreme Court ruling, that led to the determination that Indian communities should have been granted surface water rights when reservations were created and that seniority of these rights should be the reservation establishment date (Colby and Young 2018); in Arizona claims result in very senior rights, as the reservations were created prior to most Anglo development in the region. As we will note below, recent Indian community settlements

![](images/c5467548ed44fba91739b4042642b96a438db01634635aa5fa300b60fbbf62aa.jpg)  
Figure 4. Overlapping action situation scales: space and time.

due to Winters are central to the ongoing negotiations surrounding the Drought Contingency Plan.

After the CAP was completed, surface water originating in the snowpack in the Upper Colorado states was delivered to the arid desert enabling a shift from reliance on groundwater, which was being depleted faster than it could be replaced by the desert’s limited rainfall and extended drought (Udall and Overpeck 2017). This transition to reduced groundwater usage did not occur swiftly in the case of Pinal County; an area with over half a century of documented history of subsidence due to groundwater pumping for agricultural production (Schumann and Poland 1969). Rather, a set of municipalities subsidized agricultural water use to incentivize a switch from ground to surface water and to ensure that the state maintained high levels of Colorado water use (there was fear that California would ‘steal’ the Colorado River water allocated to Arizona under the Colorado River Compact; see Hundley 2009). The reduced water cost encouraged both farm-level and irrigation-district level decisions supporting the maintenance and creation of new surface water infrastructure for CAP water and reduced reliance on local groundwater but also increased reliance on a historically, and soon-to-be, hotly contested western water source, the Colorado River.

Arizona, perhaps surprisingly, has been considered a pioneer in water governance, but these governance achievements in terms of reduction or elimination of groundwater overdraft have primarily relied on a shift to utilization of Colorado River water through the CAP (Larson et al 2009). Due to recent drops in Lake Mead reservoir levels and the developments around the Drought Contingency Plan (see Sullivan et al 2019 for discussion), this source will no longer be able to provide enough water to maintain the current allocated uses.

Telecoupling between distant systems further complicates the SHS. Central Arizona is one of the largest dairy-producing regions in the US, with approximately $\$ 500$ million in annual sales in Maricopa County and $\$ 280$ million in annual sales in Pinal

County (US Department of Agriculture and National Agricultural Statistical Service 2017). Much of the milk produced is consumed locally, but cheese and other processed dairy products are shipped throughout the country and the world. Additionally, due to low shipping costs to Asia, relatively low value, but high wateruse alfalfa is shipped from Arizona to Asia and the Middle East to feed forage animals. In our prior fieldwork, extension agents and farm operators noted that changing policies in the Middle East, namely the United Arab Emirates (UAE) and Saudi Arabia restricting agricultural production of water-intensive alfalfa, in concert with changing dietary preferences, led to increased shipments of alfalfa from Arizona (see Bausch et al 2015 for methodological details) and purchase of farmland, for example Saudi Arabian companies buying land in La Paz County to produce hay (Halverson 2016, Lambert and Bin Hashim 2017). But policy changes within the US also can have a demonstrable impact in Arizona. The groundwater controversy in California has led to the relocation of many farmers into nearby Mohave County Arizona (Jacobs 2018). Both La Paz and Mohave Counties debate appropriate responses to these changing sociohydrological relationships vis-à-vis the sustainability of groundwater.

Much of the water governance literature has focused on scale mismatch related to establishing the ‘appropriate’ boundaries for the system in terms of spatial extent (Moss 2012), but this issue is exacerbated by telecoupling and temporal scale (Evans et al 2009, Akamani and Wilson 2011). Building upon the ideas of Gibson et al (2000), we illustrate the action situations for various actors with the spatial scale on the y-axis, and the temporal scale on the $x$ -axis (figure 4). These spaces change over time, e.g. typical sets of actors may focus on smaller or larger scales and shorter and longer time frames, sometimes as a result of shifting authorities, e.g. annexation into cities or requirements to for secure water supplies, while in other cases due changing mental models, vulnerabilities, and decisions sets resulting from changes

![](images/a89d32c7044cadcf39426e9e573c74870c98767cb55334e0d83aa7b5e7f06c86.jpg)  
Figure 5. Illustrations of cross-scale and cross-level flows in water governance action situations.

within or external to the system. Analytically we argue there is value in mapping dominance of particular action situation scale extents, but urge caution in essentializing actors by type. Acknowledging heterogeneity within actor sets, we describe the action situation spatial and temporal extents. Urban residents make water decisions, but these usually impact a relatively small parcel with an action situation temporal extent usually between weekly (watering plants) and a decadal-scale (infrastructure decisions, i.e. pools or low flow fixtures); a farmer typically will be making decisions about multiple parcels with both high frequency, such as timing irrigation for particular fields, and a longer time horizon (such as with regard to onfarm infrastructure improvements).

Irrigation districts work between the farm and watershed spatial extents. These districts respond to farm-level demands with delivery and also make multi-decadal infrastructure and contracting decisions. AMA policymaking occurs through the Arizona Department of Water Resources (ADWR) with a similar time horizon and on the lower end of the ADWR’s spatial extent. ADWR does not make as frequent decisions, functioning on an annual to decadal basis. The Arizona Legislature has both a relatively short range of action situation types in both time and space; often the legislature only engages in major decisions, such as the adoption of the Drought Contingency Plan or extending groundwater regulation in the state. For example, in 2019, House Bill 2467 (Arizona House 2019) established the Mohave County and La Paz County West Basin Water Users Study Committee to explore options for sustaining groundwater in the face of telecoupling described above (Allhands 2019). Environmental NGOs vary tremendously in terms of the spatial extent, but the more dominant political players largely are active at the state and sometimes river basin scales and often focus on much longer temporal extents. The Bureau of Reclamation makes frequent decisions in terms of managing surface water flows and also is actively involved in managing river basin management and infrastructure decisions at the decadal temporal extent. Finally, the many Indian

communities in Arizona typically manage from watershed to regional extent and often consider a much longer temporal extent, frequently evoking multi-generational rhetoric as related to water. This visualization (figure 4) illustrates the need to consider space and time but is limited in that it presents conceptual spaces without regard to the connections.

If we add in a nation-state actor, for example, the UAE (figure 5), who passes restrictive water policies limiting water-intensive alfalfa production, that policy, in turn, affects demand for imported hay (Flow 1). This will increase water demand from farmers on the irrigation districts (Flow 2), which may result in increased water leases with Indian Communities (Flow 3). If there is a large enough impact on the market, it may also slow the conversion of agricultural to urban land through increased agricultural land rents (Kane and York 2017) and thus affect the built environment and urban water use (Flow 4). This telecoupling is further complicated once we recognize the polycentric nature of much of water governance (see Oberlack et al 2018 for discussion of telecoupling in polycentric systems) where shifting water demand (Flows 2 and 4) affects a set of governance actors and their water policymaking: irrigation districts, Indian communities, AMAs, cities, and the state, which in turn may affect each other with rule changes, for example.

# New conceptual framework

Taking our modified SHS framing that recognizes the flows between levels and across scales, as well as connected through networks to distant SHSs, we consider a particular aspect of the Central Arizona case: the Colorado River likely will be declared in shortage soon, with probability of $6 8 \%$ by 2022 (Bureau of Reclamation 2018). Both the Upper and Lower Basin states adopted Drought Contingency Plans in 2019 to reduce stress to the system caused by simply enforcing more senior water rights, which would result in more junior holders going without

![](images/8707d4748498df3f97419c14366894283800e68562d6fc187ada194a2bd10075.jpg)

![](images/639741bf1f38814d70a3f00f2eb74f11df4967120a147ba84babf51683accaa6.jpg)  
Figure 6. Connecting the Central Arizona socio-hydrological system to the broader western US system.

water. Planning for redistribution of Arizona water from more senior rights holders to more junior has occurred in an extremely heated process with multiple stakeholders with competing preferences, mental models, and action situation time and spatial extents (see Sullivan et al 2019 for discussion of the negotiation process).

DCP planning processes link the Central Arizona focal system to the larger western SHS; in the West reduced snowpack is affecting the hydrological system and perception of vulnerability (figure 6). This, in turn, is changing risk perceptions driving the finalization of the Drought Contingency Plan across and within states (DCP). Through DCP new actors joined

the socio-political infrastructure subsystem resulting in new action situations. These DCP interactions and conversations seem to be affecting mental models, at least for those agricultural stakeholders, although there is also intransigence of some narratives.

During the ongoing hearings and related media coverage, we noticed dramatic shifts in how agricultural interests discussed vulnerability (Davis 2019) reflecting what we argue are changes in socio-hydrological vulnerability and mental models (figure 6). Namely, now there is recognition of impending water shortage that threatens agriculture as a way of life, which contrasts our prior work where the farm sector rarely brought up water scarcity (Bausch et al 2015).

![](images/3d1a21695a274acd51b075eddaa6846eee14eb1379d5d340e7603910ad732806.jpg)  
Figure 7. Emerging socio-hydrological network in central arizona.

Agriculturalists still evoke narratives of tension with urban interests, Indian water rights, and generally do not openly discuss climate change illustrating the intransigence of mental models and narratives.

To reduce the vulnerability of the Central Arizona agricultural community to Colorado shortage, there is ongoing discussion about infrastructure development, specifically improvements to wells and potential construction of recharge facilities, and new water leases with Indian communities (a new actor in this context) (US Department of Interior. Bureau of Reclamation 2019). The proposed changes would alter hydrological flows between sub-basins and create new social ties in the multi-level socio-hydrological network (see the dashed lines between the actors) (figure 7). Tentative agreements for water delivery to farmers in the Pinal AMA are being scoped between the Salt Water Valley Users Association (otherwise known as the Salt River Project), which is connected through water sources and service to seven watersheds including the Upper Salt and the Gila River Indian Community with rights in the Upper Gila, which would potentially move water through existing infrastructure, or allow increased water pumping and subsequent recharge of water. As of yet, there is not an agreement to provide additional surface water to Pinal County, but likely if one will be struck it will depend on development of new institutional arrangements between the Gila River Indian Community via the Upper Salt, and the Pinal AMA thus generating a set of new socio-hydrological ties (figure 7).

The long-enduring tension, and sometimes open conflict, between the agricultural sector and Tribal Nations, makes collective action difficult, albeit not impossible (Colby and Young 2018). Brokering across

scales will be required (Ernstson et al 2011). The state of Arizona has stepped in to attempt to broker some of the relationships (top level in figure 7), but one potential challenge has been the different temporal extents that decision-makers are considering; e.g. the Gila River Indian Community has focused on intergenerational access to surface water, while Pinal County agriculturalists have been pushing for relatively short-term water leases. As the broker the Arizona Legislature is a central actor in this action situation, but it too has different temporal and spatial extents. It is unclear if this incongruence in decision-making will thwart the negotiation process. As Cash et al (2006) describe this has both issues associated with mismatch in terms of the authorities’ spatial extent, but also in terms of the plurality of views about the appropriate temporal and spatial extents.

Shifting our attention to future socio-hydrological risks, the nascent institutional arrangements between the state, Pinal County, and Tribal Nations may generate a reservoir effect (Di Baldassarre et al 2018) increasing agricultural production and water demand beyond capacity and pushing difficult decisions about water allocation into the future. Recognizing the telecoupling of anthropogenic drivers and precipitationsheds (Keys et al 2012) and changing climate more generally, there likely is reduced water availability in Gila, Salt, and Verde Rivers, as well as the Colorado (Sampson et al 2016); interestingly these rivers are not legally considered part of the Colorado although hydrologically are tributaries (Glennon 1995). With decreased surface water supply, we anticipate that communities reliant on the Gila, Salt, and Verde Rivers may seek leases from Tribal Nations for urban consumption, which likely will

cause the state to pivot and focus on brokering agreements for urban interests versus agricultural.

Considering socio-hydrological linkages across scales and telecoupling, we propose a set of critical questions for water governance in the western US; we note the conceptual frames used in our exemplary case provide the different vantage points to wrestle with the questions.

(1) Are there spatial and temporal mismatches in decision-making? (figure 5).   
(2) Are telecoupled flows, such as virtual water and policy spillovers, adequately modeled and considered in decision-making? (figures 5 and 6).   
(3) How is decision-making networked and nested? Are governance solutions harnessing these connections? (figure 7).

Our conceptual figures 6 and 7 allow us to focus on two aspects of these questions. In the first (figure 6), we highlight the role of different levels of actors and temporality and dynamics of the system where actors are able to influence their environments (and each other). While figure 7 engages with the idea of nested and networked social actors and hydrological spaces. Combining these with a mapping of the spatial and temporal action situation scales of various actors (figure 5) allows us to begin to unpack our three critical questions.

In Central Arizona, we see significant spatial and temporal mismatches, with central actors, focused on short time horizons (e.g. the state legislature) versus long-term perspectives (e.g. many Native American communities). These two parties are essential to managing the water crisis if and when the Colorado River shortage is declared. Water decision-making is networked and nested, but there are limited explicit coordination ties between the various levels and actors. The ADWR has been tasked with coordinating water decision-making, but with a state legislature largely unwilling to make dramatic water policy changes there has been limited action. Interestingly, although perhaps unsurprisingly, the DCP process has brought stakeholders together and has resulted in a recognition of some cross-scale and networked flows. Although extremely contentious, the DCP process has created a window of opportunity (Kingdon 2011) for collective action, in our view, with new actors, brokerage of these ties, new institutional arrangements, and potentially changing hydrological flows.

# Conclusion

Without recognizing the interactions across scale within SHSs, we cannot effectively manage water resources. Our proposed integration of the socio-hydrological model linking socio-political infrastructure, the built environment, the climatic-hydrological system (Eakin et al 2017), action situations with conceptions of scale

(Gibson et al 2000) and networked social-ecologies (Sayles and Baggio 2017) provides a new way of conceptualizing and incorporating complex, multi-scale, and telecoupled networked socio-hydrologies. In the future, we plan, and encourage others, to explicitly incorporate cross-scale action situation dynamics, telecoupling, and networked SHSs through empirical modeling, such as quantifying the flows described in figure 5. Similar to Ostrom’s (2005) approach to frameworks, we believe there is a need for a set of related conceptual frames to model complex systems and advance a comparative empirical research agenda.

Building on the sustainable governance literature (Ostrom 1990), we see an opportunity to clearly articulate the tensions and cross-scale mismatches and the networked flows between components, decisionmakers, and systems through a new set of conceptual frames for SHSs. By incorporating risk and mental models in an explicit way, we potentially can better understand which factors are actually driving decision-making and how potential changes in action situations may play out across the networked system through time and across space. Without grappling with these dynamics in a telecoupled, networked, and nested SHS, we cannot sustainably manage water in an increasingly arid West.

