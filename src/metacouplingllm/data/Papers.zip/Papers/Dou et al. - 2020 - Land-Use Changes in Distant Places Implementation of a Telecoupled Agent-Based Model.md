![](images/ad5fa02028f12905ac635659b9b77d5bf20dc6f7e07258b48ddf41541e28b698.jpg)

# Land-Use Changes in Distant Places: Implementation of a Telecoupled Agent-Based Model

Yue Dou1,2, Guolin Yao3, Anna Herzberger1, Ramon Felipe Bicudo da Silva4, Qian Song4, Ciara Hovis1, Mateus Batistella4,5, Emilio Moran1,6, Wenbin Wu4, Jianguo Liu1

1Center for Systems Integration and Sustainability, Michigan State University, 1405 S Harrison Rd. East Lansing, MI 48823, United States   
2Environmental Geography Group, Institute for Environmental Studies (IVM), Vrije Universiteit Amsterdam, De Boelelaan 1087, 1081 HV Amsterdam, The Netherlands   
3University of Maryland Center for Environmental Science, 301 Braddock Road, Frostburg, MD 21532 United States   
4Center for Environmental Studies and Research, State University of Campinas, Rua dos Flamboyants, 155 - Cidade Universitária Campinas - SP, Brazil   
5Brazilian Agricultural Research Corporation (Embrapa), Av. André Tosello, 209 Campus da Unicamp, Barão Geraldo,13083-886, Campinas - SP, Brazil   
6Center for Global Change and Earth Observations, Michigan State University, 1405 S Harrison Rd, East Lansing, MI 48823, United States

Correspondence should be addressed to yuedou@msu.edu

Journal of Artificial Societies and Social Simulation 23(1) 11, 2020

Doi: 10.18564/jasss.4211 Url: http://jasss.soc.surrey.ac.uk/23/1/11.html

Received: 15-03-2019

Accepted: 12-12-2019

Published: 31-01-2020

Abstract: International agricultural trade has changed land uses in trading countries, altering global food security and environmental sustainability. Studies have concluded that local land-use drivers are largely from global sources (e.g., trade increases deforestation in exporting countries). However, little is known about how these local land-use changes aect distant locations, namely the feedback between them. Yet these distant impacts and feedbacks can be significant for governing local land systems. The framework of telecoupling (i.e., socioeconomic-environmental interactions between distant places) has been shown to be an eective conceptual tool to study international trade and the associated socio-economic and environmental impacts. However, a systems simulation tool to quantify the telecoupled causes and eects is still lacking. Here, we construct a new type of agent-based model (ABM) that can simulate land-use changes at multiple distant places (namely TeleABM, telecoupled agent-based model). We use soybean trade between Brazil and China as an example, where Brazil is the sending system and China is the receiving system because they are the world’s largest soybean exporter and importer respectively. We select one representative county in each country to calibrate and validate the model with spatio-temporal analysis of historical land-use changes and the empirical analysis of household survey data. We describe the model following the ODD+D protocol, and validate the model results in each location respectively. We then illustrate how the aggregated farmer agents’ land-use behaviors in the sending system result in land-use changes in the receiving system, and vice versa. One scenario example (i.e., a high-tari scenario) is given to demonstrate the results of TeleABM. Such a model allows us to advance the understanding of telecoupling features and the influence on land system science, and to test hypotheses about complex coupled human-natural systems (e.g., cascading eect).

Keywords: Telecoupling, Agent-Based Model, Land System, Land-Use Change, Soybean Trade, ODD+D

# Introduction

1.1 Feeding the world’s population and achieving environmental sustainability is a grand global challenge which calls for global eorts to ensure food security with increasingly scarce natural resources, particularly land (Godfray et al. 2010; Lambin & Meyfroidt 2011). During the past several decades, the international trade of food and

agricultural products has grown exponentially, and almost a quarter of food produced is traded internationally nowadays (D’Odorico et al. 2014). Studies show that international trade can facilitate regional and global food security, especially under the risk of climate change (Baldos & Hertel 2015).

1.2 The globalization of food production systems, however, has spatially displaced food production and consumption activities in distant geographic locations. For example, the demand for palm oil in emerging economies (e.g., China, India) has expanded into the tropics (e.g., Indonesia, Columbia) and become a major driver of tropical deforestation that has global implications on carbon and climate dynamics (Butler et al. 2009; Furumo & Aide 2017). The international soybean trade has caused rapid land-use changes and deforestation in Mato Grosso, Brazil, threatening not only biodiversity but also regional hydrological conditions in the Amazon and Cerrado biomes (Barona et al. 2010; Lathuillière et al. 2012; Morton et al. 2006).   
1.3 The challenges posed by international agricultural trade for land systems and land-use sustainability worldwide call for a global perspective that goes beyond the classic place-based research framework. A key component of land system science is place-based research, and most land-use issues have been studied in the site-specific context of locally coupled human-natural systems (Friis & Nielsen 2017; Liu et al. 2007; van Vliet et al. 2015; Verburg et al. 2016). Although important, this approach lacks a linked global perspective and may have overlooked the feedback between the local changes and socio-ecological implications elsewhere when investigating landuse changes of international trade (Chen et al. 2019; Friis & Nielsen 2017). For instance, place-based land-use research has treated soybean trade as an external driver, focusing only on the deforestation and land-use changes within the state of Mato Grosso (Barona et al. 2010; Garrett et al. 2013; Morton et al. 2006). This mentality may lead to conclusions such as that China and European countries have benefited from the exacerbation of the local environment and natural resources (Lathuillière et al. 2014; Morton et al. 2006) and therefore overlook the potential impacts to these importing parties.   
1.4 To confront these shortcomings, the telecoupling framework is needed, which identifies causes and eects between distant coupled human-natural systems through the flows of material, species, and information (Liu et al. 2013, 2019). Since the first publication of the framework, there have been almost hundred articles and studies that use this framework (Andriamihaja et al. 2019; Dou et al. 2018; Liu 2014; Silva et al. 2017; Sun et al. 2017; Wang & Liu 2016; Yang et al. 2016), suggested by a recent systematic review (Kapsar et al. 2019). Empirical studies have demonstrated that telecoupled causes and eects on land systems can be significant (Dou et al. 2018; Silva et al. 2017; Sun et al. 2017). One example among many is the cascading eect. The soybean expansion in Brazil has pushed corn from a dominant crop to a second place (only grown in the second season that has higher climate risks than the first season). Adding factors such as trade and currency exchange fluctuation has caused a shortage of corn within the Brazilian domestic food market (Silva et al. 2017). For the importing countries, studies have found that soybean trade has also caused land-use changes and negative environmental impacts (Sun et al. 2017, 2018; Tong et al. 2017).   
1.5 These distant feedbacks, generated by land-use changes in agricultural frontiers and resulting in land-use changes in the importing regions, require a system simulation tool for researchers to study the flows and interactions between distant land systems and quantify eects of telecouplings on land-use dynamics across scales and space (Verburg et al. 2019). Using a simulation model, a series of overlooked research questions that link landuse demand and supply from dierent spatial locations can be answered. For example, how do telecoupling processes (e.g., trade) and internal processes (local land-use decision-making) enhance or oset each other in terms of their eects on human-natural dynamics (land-use changes in telecoupled land systems), and what eects does food production in the exporting countries at the national scale have on land uses in the importing countries at local and regional scales, and vice versa?   
1.6 Agent-Based Modelling (ABM) is a computer simulation tool in which a number of agents interact with a dynamic environment and with other agents through prescribed decision-making rules. It has been widely employed to simulate land-use changes in both theoretical and empirical grounds (An 2012; Huang et al. 2014; Huber et al. 2018; Parker et al. 2003). The major advantages of an ABM include its flexibility of incorporating any components of a system (Parker et al. 2003), the power of aggregating heterogeneous behaviors (Huang et al. 2013), and the capability of representing processes, social norms and structures (An 2012; Chen et al. 2014; Holzhauer et al. 2019).   
1.7 Current land-use studies usually focus on land-use changes in one place or system, as do most land-use ABMs. To the best of our knowledge, no land-use ABMs are designed to investigate how local land-use changes affect changes at distant locations, and vice versa. In other fields, scholars have begun to experiment on linking multiple ABMs to represent the feedbacks across boundaries and between systems, such as simulating human migration across dierent human-natural systems (Thober et al. 2018). However, the potential of using ABMs to represent a telecoupled land system has rarely been discussed (Liu et al. 2015).

1.8 While the purpose of this paper is to introduce model implementation, as an example we use a case study to explore the cascading eects and complex dynamics on land-use changes in two distant places triggered by a sudden shock in a telecoupled flow, which is an increase in the tari imposed by China, the importer, on soybeans from Brazil, the soybean exporter. The ABM, here aer known as TeleABM, is the first to model and simulate complex dynamics and interactions in a telecoupled land system. We first describe the TeleABM in the $O D = D + D$ protocol, discuss the land-use decision representations in the two dierent land systems, show the validation of the model results, and then demonstrate one sample simulation using the model. The objective of this model is to show the land-use feedbacks between supply and demand in two distantly located land systems, which are referred to as sending and receiving systems in the telecoupling studies, and to facilitate flow-based governance schemes. Using the high-tari scenario as an example, we address the question: what are the land-use eects of telecouplings on the area of production in the exporting country and the area of production in the importing country?

# Model Descriptions Following ODD +D Protocol

2.1 This section describes the TeleABM following $O D = D + D$ (Overview, Design concepts, and Detail, with the decisionmaking extension) protocol (Grimm et al. 2010; Müller et al. 2013; Polhill et al. 2008). The common concepts of ABM (e.g., emergence, adaptation) are summarized in the Appendix; so are the details (e.g., initialization, input data, submodels).

# Overview

# Purpose

2.2 The telecoupling concept and framework investigate socioeconomic and environmental interactions over distances and have been conceptually and empirically applied to a variety of cases. Some special land-use change eects (e.g. cascading eect, spillover eect) can, therefore, be identified using the telecoupling framework. A comprehensive system model that can represent and simulate land-use changes in telecoupled human and natural systems, however, is still lacking. Built on the telecoupling framework and written in Java using the RePast platform, our model simulates the land-use changes in sending and receiving systems and the interactions between them. TeleABM is also designed to be flexible to model land-use changes in other telecoupled land systems.

2.3 TeleABM is a hierarchical agent-based model to simulate soybean and other agricultural land-use changes in distant places (e.g., Table 4 in the Appendix). The model version presented in this paper uses the telecoupled Brazil-China soybean trade system as an example. The model is calibrated on empirical data and/or interviews of individual farmers’ behavior rules, and aggregated to regional-level land-use patterns and production to influence the soybean price in the other system. As a systems simulation tool, this model is a powerful tool to study the complex dynamics of telecoupled system compared to currently used approaches in the telecoupling field (e.g., network analysis, case study).

# 2.4 Study area

One county, Sinop, Mato Grosso state, Brazil is used to represent the sending system and one county Gannan, Heilongjiang province, China is the representative of the receiving system (Dou et al. 2019). We chose these two counties as study areas because (1) the two counties are similar in size, (2) soybean production is one of the main agricultural activities, (3) we conducted fieldwork in both counties, and (4) their land-use changes are consistent with the overall trends in the major agricultural commodity production regions in the two countries.

# 2.5 Agricultural intensification in the sending system

The main land-use phenomenon in Sinop the sending system is agricultural intensification. Multiple studies have found that soybean production in Mato Grosso has shied from predominantly single cropping systems to majority double cropping systems (Figure 14 in the Appendix). The areas used for single cropping increased from 20,056 hectares in 2004 to 30,885 hectares in 2014, while areas of double cropping have grown almost 3.5 times to 102,810 hectares in 2014 (Kastens et al. 2017). The growth in double cropping is strongly correlated with socio-economic development (e.g., measured by income, literacy, and longevity) and agricultural intensification (Garrett & Rausch 2016; Spera et al. 2014; VanWey et al. 2013).

# 2.6 Crop conversion in the receiving system

Since the soybean trade boom, farmers in Heilongjiang have converted large areas of soybean land to corn and

rice paddies (Figure 15 in the Appendix) (Sun et al. 2018, 2015). The conversion from soybean land to corn land and rice paddies results in increased nitrogen pollution (Sun et al. 2018) and largely alters the landscape, which aects biodiversity and regional water flux. The land-use maps of the two systems are in Figure 1.

![](images/82cc2a29f7ffed927c40d897ee1bfb9bbbb64b16f3588542145e6964a7aa0bfe.jpg)

![](images/6b5f4cc9d9c3ac0da1f081c88452eff7c6a1d8b01c9ddf4ec58ecad5e06ef9cd.jpg)  
Figure 1: Land-use maps of the sending system and receiving system. (a) Land-use map of Sinop, Moto Grosso in 2014 (Kastens et al. 2017); (b) Land-use map of Gannan, Heilongjiang in 2010 (Sun et al. 2015).

# Entities, state variables, and scales

2.7 The primary entities in this model are systems, agents and environment. All the entities are hierarchically structured (Figure 2): systems, agents, and environments all have an abstract class in the model with common properties shared between sending and receiving systems. The receiving and sending systems are derived from the abstract module to create an instance of agents and environments for the system with unique properties.   
2.8 Systems in TeleABM include the overall telecoupled soybean system which has the sending system and receiving system. The land-use changes in the sending and receiving systems are individually represented and interact with each other through the flows of soybean trade, which together constitute the telecoupled soybean system. In each system, there are agents interacting with the environment.

![](images/573cb96169ec2c640c9813b66e3a73b85d4fc4bd2b13a01fa5b7e1c2329de071.jpg)  
Figure 2: Hierarchical structure of TeleABM. From the abstract module, the model can be initialized and implemented to represent dierent systems (e.g., ABM-S, ABM-R). ABM-S is made of modules that are used to represent the sending system, constituting agents from the sending system (i.e., sendingSoybeanAgent, sendingTradeAgent, sendingGovernmentAgent) and environment that represents the biophysical conditions of the sending system. So is the ABM-R. The same shape of agents and environment in these systems mean that they share the same basic features and functions; however, dierent colours mean that the agents and environment in each system are initialized dierently as they may have unique attributes and functions.

2.9 Agents. In both sending and receiving systems, there are farmer agents, trade agents, and government agents (Table 1). In the abstract class, a farmer agent has a list of general properties (e.g., labor, capital, and land property) and a list of common abstract actions (e.g., land-use decision, calculate cost and profit). Farmer agents can be instanced as farmer agent class in the sending system (as a sendingSoybeanAgent class) or farmer agent class in receiving system (as a receivingSoybeanAgent class) based on the system’s initialization. Attributes of agents are drawn from household surveys, information from yearbooks, interviews, and mental models (a mathematical pairwise association that semi quantitatively captures the qualitative knowledge and perceptions of stakeholders (Gray et al. 2015; Mehryar et al. 2018) that were conducted in study areas.   
2.10 Additionally, there are government agents and trade agents. Government agents decide levels of commodity taris, crop subsidies, and trade volumes. International trade agents determine the soybean crop prices based on a partial demand-supply relationship and connect the two systems by flows of soybean commodity and soybean price. Local trade agents disseminate soybean prices and facilitate the trade by collecting soybeans from local farmers.   
2.11 Environment. The environment of TeleABM is based on a grid of cells, typically representing $9 0 0 ~ \mathsf { m } ^ { 2 }$ or 0.0625 $\mathsf { k m } ^ { 2 }$ based on the land-use map resolution (e.g., in the current version, we use $2 5 0 \mathsf { m } \times 2 5 0 \mathsf { m }$ land-use maps for the receiving county and $2 4 0 \mathsf { m } \times 2 4 0 \mathsf { m }$ for the sending county, due to data availability). Each cell has defined biophysical properties including empirical data (e.g., temperature, precipitation, elevation, and soil texture) and hypothetical data (e.g., cadastral ownership) (layer A in Figure 3). Cells are assigned to and managed by farmer agents (layer B and C in Figure 3). Crop yields are functions of fertilizer inputs and crop rotation, which are derived from literature and expert opinions from both sites (see Table 4 in the Appendix). Local trade agents interact with farmer agents who are within their spatial coverage (layer C and D in Figure 3), by passing the crop price to these farmer agents and purchasing their crop products.

# Process overview and scheduling

2.12 The initialization of TeleABM includes three parts: 1) setting the global parameters (e.g., users determine which system(s) to simulate, initialize farmer agents, use static crop price, empirical crop price, or simulated international price), 2) reading land-use and other maps (e.g., suitability map) and external files (e.g., empirical crop prices, subsidy); 3) initializing farmer agents and other agents, including land cells allocation to farmer agents, agents properties setup (e.g. capital, diversifying preference) according to empirical and/or hypothetical data, and farmer agents and trade agents connections.

Table 1: Agent properties and functions. Note: the symbol • is the common properties in the abstract module, while Xis the unique property that is not shared between the two systems and – is for sub-functions.   

<table><tr><td>Agent Class</td><td>Property</td><td>Function</td></tr><tr><td colspan="3">Farmer Agent</td></tr><tr><td></td><td>·land property, labor endowments, capital endow-ments</td><td>·read land uses from land-use maps (initialization step)</td></tr><tr><td></td><td>·land cells with current and historical land-use information</td><td>·get commodity price</td></tr><tr><td></td><td>·crop production and profits</td><td>·step (execute every year, including abstract func-tion of updating production, updating costs, up-dating profits, and land-use decisions, updating land uses)</td></tr><tr><td colspan="3">sendingSoybeanAgent</td></tr><tr><td></td><td>✓ diversifying preferences</td><td>✓ land-use decision in the sending system
- land-use probability
- expansion</td></tr><tr><td colspan="3">receivingSoybeanAgent</td></tr><tr><td></td><td>✓ number of family members</td><td>✓ land-use decision in the receiving system</td></tr><tr><td></td><td>✓ household head gender and age, unhealthy pro-
portion, dependent ratio, knowledge of soybean 
trade</td><td>- rice cultivation
- soybean and corn cultivation
- allocate crops to suitable cells
- expansion</td></tr><tr><td></td><td>✓ attitudes towards soybean trade</td><td></td></tr><tr><td colspan="3">Trade Agent</td></tr><tr><td></td><td>·capital endowments</td><td>·purchase soybeans and pass local prices to local 
farmer agents</td></tr><tr><td></td><td>·spatial coverage</td><td></td></tr><tr><td colspan="3">sendingTradeAgent</td></tr><tr><td></td><td></td><td>✓ deliver the international price to local farmer 
agents</td></tr><tr><td colspan="3">receivingTradeAgent</td></tr><tr><td></td><td></td><td>✓ deliver the international price to local farmer 
agents</td></tr><tr><td colspan="3">internationalTradeAgent</td></tr><tr><td></td><td></td><td>✓ conduct the international soybean trade</td></tr><tr><td colspan="3">Government Agent</td></tr><tr><td></td><td>·implement top-down policies</td><td></td></tr><tr><td colspan="3">sendingGovernmentAgent</td></tr><tr><td></td><td>✓ implement environmental policies</td><td>✓ SoyMoratorium scenario (future scenario)</td></tr><tr><td colspan="3">receivingGovernmentAgent</td></tr><tr><td></td><td>✓ tariff imported crops and subsidize domestic crops</td><td>✓ tariff scenario</td></tr></table>

2.13 Aer initialization, TeleABM operates on an annual basis and is divided into major steps of (1) human landuse decisions, (2) land cell changes and (3) annual accounting to update socio-economic and environmental conditions (Figure 4). Once both sending and receiving systems are simulated, telecoupling flows (e.g., the flow of soybean commodity and price) in the annual accounting are triggered, via international trade agents, who facilitate trade and update crop price.   
2.14 At every time step, the internal agent factors are updated first (e.g. last yearâĂŹs crop cost and profit), then

![](images/441468194024978ba810c3d49f7bd93cfddfdf1fe02df3ed9d2ae5f8019ca597.jpg)  
Figure 3: Layers and spatial representation. In layer B, colors represent dierent types of land use (e.g., in the sending system, double cropping and single cropping; in the receiving system, it is soybean, corn, and rice paddy). In layer C, patterns mean dierent property ownership. In layer D, patterns mean trade coverage of dierent trade agents.

farmer agents interact with local trade agents to obtain the crop price, which is either exogenous (i.e., if only one system is simulated, price information is given in the price file) or endogenous (i.e. the crop price is updated every year from the international trade agent). Farmer agents in the receiving system allocate their resources to grow soybeans, rice, and corn. Farmer agents in the sending system allocate their resources to grow a singleseason of soybeans, a double-season of soybeans and corn, and/or a double-season of soybeans and cotton.

2.15 Farmer agents pass the land-use decisions and associated agricultural input (e.g., fertilizer and fuel use) to land cells and update the land use for the current step. Previous land uses are recorded to land cell property. Land cells undergo ecological processes to generate the new crop yield and soil organic matter in response to fertilizer use (Materials Submodels in the Appendix). Sending and receiving systems have separate ecological processes that endogenize local-level environmental variability. However, for simplicity, in the example simulation average crop yield is assigned to each crop to highlight the land-use change aspects.   
2.16 Once all agents and land cells are updated, the model moves to annual accounting steps during which farmer agents’ profit is calculated and stored, as well as the environmental-impacts (i.e. water usage, fuel input, and crop production). When both sending and receiving systems are initialized, soybean production from the sending system is aggregated through the local trade agents and sent to international trade agent as a flow, so that next year’s crop price is estimated by the international trade agents (Figure 4). When only one system is initialized, the crop price is either a static price from the initialization step or a dynamic price that is read in from a configuration file. Aer this, the annual time step is finished and the model moves to the next time step.

![](images/55b875be60be1292c935d00146309ed8a1d8f5c6a9c0869228f0e7c1292b98c3.jpg)  
FlowchartofTeleABM   
Figure 4: Major steps in TeleABM flowchart (adapted from Murray-Rust et al. (2014)). Each system completes accounting its dynamics and communicates through the telecoupling flow (i.e., soybean commodity and price) facilitated by the international trade agent.

# Design concepts

2.17 Here we introduce the theoretical and empirical background, the decision-making representation, and the telecoupling flow. Common concepts of ABMs required by ODD+D are in the Appendix.

# Theoretical and empirical background

# Telecoupled soybean trade system

2.18 TeleABM is designed to test hypotheses that have emerged from the telecoupling framework (Liu et al. 2013). Using the telecoupled soybean system as an example, our model can answer “what-if” questions under alternative scenarios, such as the question in this paper “if China increases its tari on imported Brazilian soybeans, what land-use outcomes will occur in Brazil as well as China?”. The simulation results from addressing this “what-if” question can be used to evaluate the relationship between the telecoupling process (e.g., trade) and internal processes (e.g., local land use), and to test cascading eect hypothesis (e.g., changes in one land-use system radiate outward to land uses in other systems). Practically, we ask this specific question concerning the current soybean tari disputes between the United States and China. We hope that although the simulated scenario is between Brazil and China, the land-use consequences can still inspire policy makers in all trading parties.

# Individual decision making

2.19 We utilize dierent approaches to construct and validate the land-use change patterns in the two systems due to dierent fieldwork approaches and data availability. In our case, a household survey was conducted in the receiving system and a mental modelling approach (Özesmi & Özesmi 2004; van Vliet et al. 2010; Voinov & Bousquet 2010) was used per the project requirement and situation in the study sites (Dou et al. 2019).

# Representing decision making in the sending system

2.20 Several factors have been indicated to be main drivers of the agricultural expansion and intensification in Mato Grosso, Brazil (Garrett et al. 2013; Garrett & Rausch 2016; Richards et al. 2012), such as topography, climate conditions, and distance to the closest ports. Land-use history is also an important factor in Mato Grosso, because soybean land oen replaces land deforested for pasture or previously under pasture. Due to data availability

and research interests, we select the previous two-year land-use history (to be consistent with the usual practice in the field (Spera et al. 2014), yield, profit, and elevation, slope, distance to ports, and distance to urban area as explanatory factors (Table 2). Soil property is homogenous in Sinop; therefore we exclude it for this analysis. Using the crop cover maps from 2001 to 2014 that are provided by Kastens et al. (2017), we apply a multi-nomial logistic regression to calculate the probability of agricultural land use at year t.

$$
\operatorname {p r o b} \left(l c _ {i, t}\right) = f \left(l c _ {t - 1}, l c _ {t - 2}, C _ {i, t - 1}, P _ {i, t - 1}, S _ {i}, \text {e l e v a t i o n}, \text {s l o p e}, \text {d i s t a n c e}\right) \tag {1}
$$

where $l c _ { i }$ is the land cover type $i$ at year t, t − 1, and $t - 2$ . Land cover at year $t$ is the function of previous land covers, $C _ { i , t - 1 }$ is the cost of type $i$ land cover at year $t - 1$ , $Y _ { i , t - 1 }$ is the yield of the land cover $i$ at year $t - 1$ , $P _ { i , t - 1 }$ is the profit of crop $i$ at year $t - 1$ . $S$ is the frequency of crop $i$ at a specific cell across all years. We feed logistic regression when $t = 2 0 0 6$ and $t = 2 0 1 1$ , because we only have cost information in years 2000, 2005, 2010, and 2015, and land-use maps from 2004 to 2014. The results of parameters for this logistic regression are implemented in the decision-making module of farmers in the sending system. To compensate for temporal change and preference of intensification that is limited by the regression, we calibrate the probability for single cropping (i.e., subtract by 0.02 every year to match the decreasing trend) and double cropping (i.e., increase the probability by 0.02 every year) over time in the model.

Table 2: Empirical values of land-use characters in the sending system   

<table><tr><td>Unit (real/ha)</td><td>single-soybean gross return</td><td>soybean-corn gross return</td><td>soybean-cotton gross return</td><td>single-soybean cost</td><td>soybean-corn cost</td><td>soybean-cotton cost</td></tr><tr><td>year 2005</td><td>1833</td><td>3125</td><td>12148</td><td>1975</td><td>4410</td><td>8140</td></tr><tr><td>year 2010</td><td>2475</td><td>4285</td><td>11628</td><td>1611</td><td>3531</td><td>6529</td></tr><tr><td>Unit (me-ters)</td><td>distance to urban</td><td>distance to roads</td><td>elevation</td><td>Slope</td><td></td><td></td></tr><tr><td>mean value</td><td>17830</td><td>8173</td><td>364.6</td><td>0.982</td><td></td><td></td></tr></table>

2.21 In addition to land-use probability, farmers’ decision making is incorporated. Two factors (i.e., capital capacity and preferences for diversification) are identified as significant by soybean producers that we interviewed during fieldwork. In the model, even if the probability suggests double cropping, farmer agents would only be able to implement single cropping without enough capital endowments. The other property, “pro-diversifying”, is extracted from the fieldwork conducted by our team in the summers of 2016 and 2017. The preliminary analysis suggests that farmers in Brazil have dierent risk-taking attitudes. In current simulation, farmer agents are split evenly between the two risk-taking attitudes $5 0 \%$ simulated agents as “pro-diversifying” and $5 0 \%$ not) as a hypothetical distribution to even out the eects of this attitude, which will be explored in future work. The prodiversifying farmer agents have a higher probability of choosing double cropping over single cropping when all other factors hold the same.

# Representing decision making in the receiving system

2.22 The land-use changes in the receiving system mostly appear on small-scale farms which are operated by household labor. It is necessary to first establish crop suitability maps because rice paddy needs special topography and water condition. We then analyze land-use changes based on the extensive household survey conducted in the summer of 2017 to quantify the land-use decisions at the household level.

# 2.23 Crop suitability

First, empirical data on soil type (Institute of Soil Science - Chinese Academy of Science 2019; Liu et al. 2006), accumulated temperature $( \geq 1 0 ^ { \circ } \mathsf C )$ (Li et al. 2014; National Meteorological Information Center 2019), distance to water and distance to roads (calculated using ArcMap) are collected. Then, the multi-nomial logistic regression is used to calculate the probability based on the 2005 and 2010 spatial distribution of the three crops classified from remote sensing images and these land-use factors. This probability of crop presence is used as a proxy for suitability which is a common practice in land use and ecological modelling (Chen et al. 2010; Magliocca et al. 2013; Walsh et al. 2013). Last, the higher probability among the two time points is selected as the crop suitability, in case suitability has changed due to crop conversion (Figure 5).

![](images/821347e1bc960b0005b909a29059a0837c3fea7da9ea7ab11009672e455b2520.jpg)

![](images/2d9705c4dd01ea5cc5b4f0f971ce589000683e886d1b617aae591ba57fa33135.jpg)

![](images/708ab2fbc96b9f834995b1b594eb2a540454272c2f5f79c533b10fb24f8aae0f.jpg)

![](images/ec0eb6f6bc66a1f3eb4738e77484a9da2ff3d36345ac30fc7251ea737669bd5a.jpg)  
Figure 5: Crop suitability in Gannan, Heilongjiang (receiving system).

2.24 The choice of which crop to grow is a complex decision, and it is particularly true among smallholder farming households (An 2012; An et al. 2005; Huber et al. 2018). The representation of farmers’ land-use decisions crucially depends on the purpose of the study and the attributes of the system. There are many decision-making mechanisms and rules used in modelling farmer agents’ crop choice, among which the statistical regression model is oen used to describe the relationship between land-use patterns and empirical farmers’ attributes (e.g., LUDAS, see Le et al. 2008). Many factors have been noted crucial to the crop/land-use choices by smallholders, such as the dependent ratio that measures the number of dependants to farm workers and reflects the number of mouths each worker feeds (Chayanov 1966; Le 2005), the gender ratio that measures the number of adult males over the total number of family members (Walsh et al. 1999), the education level of the household heads and family members (An et al. 2002; Dou et al. 2017), and the size of o-farm income (Dou et al. 2017; Yang et al. 2018).   
2.25 In the receiving system of TeleABM, several tiers of statistical relationships are used to represent the land-use behaviors of these farmer agents (Figure 6). If agents engage in agriculture in a given year t, they 1) first decide the proportion of rice to cultivate on the whole property, 2) decide the proportion of soybeans and corn to cultivate, and then 3) allocate cells that are suitable for cultivating these crops. Data on farmer agents’ attributes were collected during a household survey in the year 2017 (total count: 411, Table 3), which were tested for collinearities and used for calculating the statistical relationships.

# 2.26 Rice cultivation proportion among rice-farmers

$$
\operatorname {p r o p} \left(R i c e _ {t} = f \left(H H _ {a g e}, H _ {f m}, R _ {d e p}, R _ {g}, R _ {u h}, E d u, N _ {s}, N _ {m}, A _ {d}, A _ {p}, F C _ {i, t}, G I _ {i, t}, H H _ {g}, K, H H _ {e d u}\right) \quad (2) \right.
$$

2.27 The receiving land-use module calculates the proportion of rice in a receiving farmer agent at the current year t using regression analysis. Only the rice cost and profit are used to calculate this proportion $F C _ { i , t }$ and $G I _ { i , t }$ are rice cost and gross income at the year t). These variables (Table 3) are initialized following the empirical distribution using the Monte Carlo approach. The proportion of corn and soybeans is assigned using the distribution of the two crops collected from the survey.

# 2.28 Soybean cultivation proportion in non-rice farmers

For farmer agents that do not grow rice, the proportion of soybeans is calculated using the following regression equation, and the corn proportion complements to $100 \%$ . This is because based on soybean and corn suitability, soybeans and corn are likely interchangeable. The $F C _ { i , t }$ and $G I _ { i , t }$ here are soybean cost and gross income at the year $t$ .

$$
\operatorname {p r o b} (\text {S o y b e a n}) _ {t} = f \left(H H _ {\text {a g e}}, H _ {\text {f m}}, R _ {\text {d e p}}, R _ {\text {g}}, R _ {\text {u h}}, E d u, N _ {\text {s}}, N _ {\text {m}}, A _ {\text {d}}, A _ {\text {p}}, F C _ {i, t}, G I _ {i, t}, H H _ {\text {g}}, K, H H _ {e d u}\right) \tag {3}
$$

# 2.29 Allocate cells

For a receiving farmer agent $i$ that owns $N$ number of land cells, it first sorts its $N$ land cells by rice suitability and then allocates $N _ { r } = N * \mathsf { p r o p } ( r i c e ) _ { t }$ to cultivate rice for year t. However, these cells have to be either rice paddy, or next to a rice paddy or water. Otherwise these cells are assigned to grow soybean or corn. The rest of the cells are sorted by soybean and corn suitability and allocated to soybean and corn cells respectively.

Table 3: Household characters in the receiving system   

<table><tr><td>variable abbr.</td><td>HHage</td><td>Hfm</td><td>Rdep</td><td>Rg</td><td>Edu</td><td>Ns</td><td>Nm</td><td>Ruh</td></tr><tr><td>variable names</td><td>Household head age</td><td>number of family members</td><td>dependent ratio</td><td>gender ratio</td><td>average school years</td><td>number off- farm salary</td><td>number of big machines</td><td>unhealthy proportion</td></tr><tr><td>mean value</td><td>44.8</td><td>3.672</td><td>0.2184</td><td>0.1346</td><td>9.721</td><td>0.4647</td><td>2.908</td><td>0.05615</td></tr><tr><td>variable abbr.</td><td>Ad</td><td>Ap</td><td>FCsoybean</td><td>FCcorn</td><td>FCrice</td><td>GIsoybean</td><td>GICorn</td><td>GIRice</td></tr><tr><td>variable names</td><td>rain-fed area (ha)</td><td>paddy area (ha)</td><td>soybean fertilizer cost (yuan/ha)</td><td>corn fertilizer cost (yuan/ha)</td><td>rice fertilizer cost (yuan/ha)</td><td>soybean gross income (yuan/ha)</td><td>corn gross income (yuan/ha)</td><td>rice gross income (yuan/ha)</td></tr><tr><td>mean value</td><td>3.371</td><td>2.198</td><td>347.2</td><td>870.1</td><td>1054.2</td><td>2847</td><td>4595</td><td>4599</td></tr><tr><td>variable abbr.</td><td>HHg</td><td>K</td><td>HHedu</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>variable names</td><td>household head gender</td><td>whether know soybean import</td><td>education of house-hold head illiterate: 2</td><td>elementary school: 56</td><td>middle school: 261</td><td>high school: 79</td><td>college: 13</td><td></td></tr><tr><td rowspan="2">head count</td><td>male</td><td>No: 146; Yes: 265</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>400; female 11</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

# 2.30 Property expansion

A receiving farmer agent can also reclaim non-agricultural cells as agricultural cells. We assume that every year the agent reclaims some new areas as agricultural land (i.e., follows a $u = 0 . 2$ , $\delta = 0 . 0 5$ Gaussian distribution for a hypothetical constant-paced expansion). The reclaimed cells are assigned to the highest profitable crop.

![](images/4ab523fa40c12d0e744e1faf0976d6cfacd59b630bd18b47fd9510d1c812246c.jpg)  
Figure 6: Decision-making process in the receiving system of TeleABM (ABM-R).

Environment rules:rice expansionis limited to cels that are next to existing ricepaddies or water

ABM-R

# Telecoupling features

2.31 TeleABM can simulate solely the sending system and its land-use changes, or the receiving system and its landuse changes, or both systems and their telecoupled interactions during one simulation. In this section, we describe how the telecoupling feedbacks are represented in this model.

# Model structure of telecoupling feedbacks

2.32 In each system, there are one government agent, local trade agents, and farmer agents. The two systems are connected through an international trade agent (Figure 7). In the sending system, farmer agents make land-use decisions based on a local soybean price $( p _ { s } )$ . Local trade agents purchase soybeans from local farmer agents, which are aggregated to the international trade agent. The total traded volume of soybeans from the sending system aects international soybean price $( p _ { f o b } )$ , which is passed to trade agents in the receiving system. This price is then distributed to local farmer agents $\left( p _ { r } \right)$ . The government agent in the receiving system sets up a subsidy based on the aggregated soybean production in the receiving system, which aims to meet a certain quantity of domestic production.

# Telecoupling flows in the model

2.33 Many factors aect international soybean trade and thus change the soybean prices. Such factors include tari disputes, transportation system improvements, favorable climate conditions or climatic hazards, and exchange rate fluctuations. It is unrealistic to include all potential factors and relationships in one model. We simplify the model by focusing on the land-use changes driven by the soybean supply and demand dynamics only. Several assumptions are applied to this international trade simplification: 1) the supply and demand relationship between Brazil and China determines their traded soybean price; 2) the two counties used as model examples represent the average land use and trade conditions in the two countries. In TeleABM, we use several relationships (e.g., elasticity) between soybean price and the supply-demand quantity obtained from literature to represent the dynamics of telecoupling flows between the sending and receiving systems.

![](images/f32bbe23c38387ec8ddfbcadb912c5bcc3721123d1ba538054081e171ad6ba26.jpg)  
Figure 7: Telecoupling feedback loop. Local trade agents aggregate all soybean productions from farmer agents in the sending systems and send the soybean as a flow to the international trade agent. This amount determines the soybean price in the international market $( p _ { f o b }$ , short for free on board), following a supply-demand relationship. This international price is disseminated to local trade agents in the receiving system as $p _ { r }$ (i.e., short for price in the receiving system) and in the sending system as $p _ { s }$ (i.e., short for local price in the sending system). Local trade agents then provide the local soybean price to farmer agents in the two systems. Solid lines represent soybean trade and price while dashed lines are policy and information.

# 2.34 Sending system aects international soybean prices

We assume the supply of soybean production aects the international soybean price $( p _ { f o b } )$ , and we use an export demand elasticity to measure this dynamic. The export demand elasticity measures the percentage change in exports associated with the $1 \%$ change in the price of the exporting country $p _ { f o b }$ (Reimer et al. 2012). We assume this export demand elasticity is fixed in the short run, and pfob is only aected by the supply changes resulted from mixed production changes $( Q ^ { t } - Q ^ { t - 1 } )$ in the sending system that are caused by climate, land-use change, and other factors. We apply the empirical point elasticity (-0.9) obtained from Reimer et al. (2012) and calculate the price at year $t$ given export change and price at year $t - 1$ .

$$
p _ {f o b} ^ {t} = p _ {f o b} ^ {t - 1} + p _ {f o b} ^ {t - 1} \cdot \frac {E Q ^ {t} - E Q ^ {t - 1}}{\epsilon_ {e p} \cdot E Q ^ {t - 1}} \tag {4}
$$

$$
E Q ^ {t} = Q ^ {t} \tag {5}
$$

where $\epsilon _ { e p }$ is the point elasticity of export demand (-0.9 estimated by Reimer et al. (2012). $Q$ is the quantity of soybeans produced in Brazil, and $E Q$ is the soybeans exported from Brazil to China. We assume that the demand of soybeans from China is unlimited and all the soybeans produced in Sinop, Brazil, are taken by the international soybean trade agent without tari dispute. Therefore, $E Q$ in this equation equals soybean production $( Q )$ in the sending system (we assume that the simulated county Sinop is a representative of Brazil) in the no-tari scenario in the model (for tari scenario, $E Q$ is changed, see below at the section of high-tari scenario). pfobt is the traded soybean price (free on board) at year $t$ . The soybean production $( Q ^ { t } )$ in the sending systems is endogenous from the model, except the initial one that is given.

# 2.35 International soybean price conversion to local prices

To local prices in the sending systems: Local prices in the sending system could also be impacted by its external factors, such as the global fuel price $( p _ { f u e l }$ , $\mathsf { U S S }$ per gallon), the proportion of Brazilian soybean production over the global soybean production $( R _ { B } )$ , and the proportion of Chinese soybean import over the global soybean production $( R _ { C } )$ , 2009 “zero-deforestation” supply-chain initiative (Gibbs et al. 2016)(ZD dummy $\scriptstyle ( 0 = { \mathsf { n o } }$ $\scriptstyle 1 = y \in S )$ ). Global soybean production reflects the climate eect and the global economy. Fuel price has proved a significant factor in global agricultural trade. The proportion of soybean import over global soybean production reflects the overall economy and demand of China. We thus convert international soybean prices calculated above to Brazil’s local soybean prices using the following calibrated regression:

$$
p _ {s} ^ {t} = f \left(p _ {f o b} ^ {t}, p _ {f u e l}, R _ {B}, R _ {c}, Z D\right) \tag {6}
$$

2.36 To the local prices in the receiving system: We employ a price transmission elasticity function (Reimer et al. 2012) to convert international soybean prices $( p _ { f o b } ^ { t } )$ to China’s local soybean prices $( p _ { r } ^ { t } )$ , given local prices in the last year $( p _ { r } ^ { t - 1 } )$ , the current international soybean prices, the trend (year), together with several other exogenous factors used above (i.e., $p _ { f u e l } , R _ { C } )$ , as well as local prices of corn and rice at current year t $( p _ { c o r n } ^ { t }$ and $p _ { r i c e } ^ { t }$ ). Local prices of corn and rice in the current year represent government policy on stockpiling and incentives. This price transmission function from international soybean prices to China’s local prices can be specified as:

$$
\ln p _ {r} ^ {t} = \beta_ {0} + \beta_ {1} \ln p _ {r} ^ {t - 1} + \beta_ {2} \ln p _ {f o b} ^ {t} + \beta_ {3} T R E N D + \beta_ {4} p _ {f u e l} + \beta_ {5} R _ {C} + \beta_ {6} p _ {c o r n} ^ {t} + \beta_ {7} p _ {r i c e} ^ {t} \tag {7}
$$

where the $\beta _ { S }$ are parameters estimated based on empirical data.

# 2.37 High-tari scenario: elasticity of ChinaâĂŹs soybean demands

In a high-tari scenario, we try to investigate the soybean import volume changes due to the tari-driven price increase. A tari increase in China that imposed to Brazilian soybeans will boost China’s received soybean prices from Brazil $( p _ { f o b } ^ { t - 1 } )$ . For this purpose only, we apply a bilateral import demand elasticity $\epsilon _ { e p }$ for China with respect to Brazilian soybeans. It means that a price increase in $p _ { f o b }$ will lower China’s soybean imports and thus impact Brazilian soybean exports and production. We followed the method from Reimer et al. (2012) and calculated the import demand elasticity of China with respect to Brazilian soybeans using the data over the years of 2009-2015 (Hjorth & Wilensky 2019; Bank 2019; UN Comtrade 2019). The import demand elasticity measures the percentage changes of import quantity $\Delta I Q$ with respect to one percent changes in Brazilian soybean price $\delta p$ . We use data aer 2009 to avoid the potential noise of 2007 and 2008 when there was a world food price and economic crisis. The calculated elasticity $\epsilon _ { i p }$ is approximately -0.29, meaning one percentage increase of soybean import price will reduce China’s import by 0.29 percent.

$$
\Delta I Q = \frac {\epsilon_ {e p} \cdot \Delta p \cdot I Q ^ {t - 1}}{p _ {f o b} ^ {t - 1}} \tag {8}
$$

where $\epsilon _ { e p }$ is the point elasticity of import demand (-0.29 as calculated above). $\Delta I Q$ is the change of import quantity caused purely by the tari increase. This value is zero in the no-tari scenario, because we assume all produced soybeans from the sending system will be bought and consumed by the receiving system. In the tari scenario, this value is subtracted by the sending soybean production at year $t$ (i.e., $E Q ^ { t } = Q ^ { t } - \Delta I Q ^ { t } )$ , to indicate the decline of import demands caused by the higher price resulted from the tari. $I Q ^ { t - 1 }$ is the imported soybean quantity from last year $t - 1$ (which is equal to the export quantity from the sending system). $p _ { f o b } ^ { t - 1 }$ is the lagged soybean international price from last year $t - 1$ .

# Validation

2.38 The validation of TeleABM requires two sequential processes: validation of the sending/receiving system independently, and then the validation of the flow between them. Due to dierent data availability and decisionmaking representation in the two systems, the validation methods are also dierent.

2.39 Two years’ $\hat { ( t \ ) } = 2 0 0 7$ and $t = 2 0 1 2$ ) land-use data are selected to validate the regression results using the receiver operating characteristics (ROC curve, presented in Figure 8). ROC is a commonly used measure of goodness-of-fit in classification problems (Chen et al. 2014; Sun & MüLler 2013). A ROC curve is derived by plotting the rate of true positives versus the rate of false positives. We select years 2007 and 2012 because one is in the earlier period and the other is at the later period over the simulated 10 years (2005-2015). The areas under the ROC curve for all three crops in both years are larger than 0.8.

![](images/b225b4c54632f59f06dff7f442b14156b62b364a11af120ede2c686ef78d5658.jpg)

![](images/b78271f4caadc087a60b932f153cd261b46033e77f55addfebbf796478b477fd.jpg)  
Figure 8: Validation of the sending system. ROC curve for simulated and empirical land use in the sending system: The ROC value for double-soybean, single-soybean, soybean-cotton for (a) the year of 2007 are: 0.9061, 0.8695, 0.9631, and for (b) the year of 2012 are: 0.8672, 0.8345, and 0.8974.

# Validation of the receiving system

2.40 In the receiving system, pattern-oriented modelling approach (POM) is used to calibrate and validate the simulation results. The POM is a strategy to construct and validate the model with multiple observed patterns at dierent scales and scopes of the modeled complex system (Castella & Verburg 2007; Grimm & Railsback 2012; Grimm et al. 2005). If a model can reproduce multiple patterns observed in real systems, we think it is less likely to falsify the model design than the ones that reproduce only one or no pattern. We compare patterns of agricultural land-use change at two levels: the crop planted areas and proportion at the county level (the aggregated area and aggregated proportion) (Figure 9) and the soybean proportion at the household level (Figure 10).   
2.41 At the aggregated level, the slope coeicients between time and the simulated crop area are compared with the slope coeicients between time and the empirical crop area by t-test (e.g., we compute the t-test statistics by dividing the dierence between the two slopes over the residual variance see Wuensch (2018). The results are not significant for all three crops, which indicate that the receiving system of TeleABM can reproduce the changing pattern of planted areas and the proportion of the three crops.   
2.42 At the household level, the soybean proportion of each agent (i.e., simulated soybean area over the total household agricultural area) at the beginning of the simulation (year 1) and at the end of the simulation (year 10) are recorded and compared with the reported soybean proportion from the household survey. The pattern of individual soybean proportion is that more farmers abandoned soybean cultivation or largely reduced the soybean proportion. Although the simulated soybean proportion distribution is not statistically identical to the observed distribution (using Kolmogorov-Smirnov test), we believe that the model can represent the pattern of farmers reducing and/or abandoning soybean production in the receiving system. The dierence in distribution may be due to the hypothetical initialization of properties.

![](images/3b0355a131f56d989183c7f122ea0b8bc70a0ff28bad20090e748bce88be2fe1.jpg)

![](images/8216b427571b2e06b0dac0c18a637b29c2f9466d221e4b5e22c1b4d61f99c7cf.jpg)

![](images/ab2cb8db1f9fc1cc04e3dca5218aabae7a8630923e1092f3e404a46b9728d901.jpg)

![](images/1b4b94a8ff812d67d2e80544978232b290b1eddd2ab6f4afa6c299a7aae43e21.jpg)

![](images/21c7e43d0d12113065b9c9bdcf9f1ba9d8ac9ae2f007846f5b9c53418a5b33a2.jpg)

![](images/9c7129c04c846f6728c86e1304616d2947fe812b476487f644aadb457ac9486f.jpg)  
Figure 9: Aggregated land-use area and proportion change in the receiving system. The x-axes are years (from the year 2006 to 2015, or the year 1 to 10 in simulation). The y-axis is either crop area or proportion. Figures in the le panel are the areas of three major crops (from top to bottom: (a1) soybean, (b1) rice, and (c1) corn). The red dots are the real crop planted area from yearbooks (note that some data are missing, so at certain years there are no actual land-use data; in addition, there is a systematic gap between actual land-use data from yearbooks and remote sensing classified land-use maps, we add a constant value to the actual area to match with the landuse map that is used for simulation, for example, 23,719 ha for soybean) and black dots are simulated results. Figures in the right side panel are the proportion of each crop in the total planted area (from top to bottom: (a2) soybean, (b2) rice, and (c2) corn). Because we have 20 replicates for the same model initialization, we have 20 black dots on every year.

# Validation of the telecoupling feature

2.43 The soybean price in the sending system is aected by the production change in the sending system and this price will aect the local soybean price in the receiving system along with other factors such as fuel price. Therefore, the simulated soybean prices in both systems are compared with empirical data, and t-tests show no significant dierence which indicates the telecoupling module of our model can reproduce the empirical price dynamics (Figure 11).

# A Sample Simulation

3.1 To show how the results can be used to understand telecoupling features, we include a simple sample simulation. The sample simulation has two settings: (A) Baseline scenario - no tari, and (B) High-tari scenario — $2 5 \%$ tari. In scenario (A), a business-as-usual international trade is assumed. This means that the international soybean price is determined only by the change of soybean production from the sending system, as well as the exogenous global factors such as average global fuel price. In scenario (B), a $2 5 \%$ tari is charged on the soybean production from the sending system to the receiving system starting from simulated year 5. The soybean price is then aected by both the import demand elasticity and export demand elasticity. All the other settings are the same. To eliminate randomness in the initialization and modelling process, 20 replicates are simulated for 10 years each.

# Less agricultural intensification in the sending system at the tari scenario

3.2 The land-use changes in the sending system under the tari scenario are compared to the baseline scenario (no

![](images/7fbbf140739e5369ab6d213d4dd99b1452e4b98c88d9671dc7b76ffc7c80ff5a.jpg)  
(a) Observed soybean proportion

![](images/d4650b52a7904329f8da83d2e6eff2e0b35f2f4fedeec477d31c98489b894347.jpg)  
(b) Simulated soybean proportion

![](images/d1d42060d724481fc9b17fd42969fe86c23f287111f32ce4fc0043e381573eba.jpg)

![](images/b6636e2e9dcbc8487143c9277d141164812170f8e6e4a33aa15a3ae07a2a05eb.jpg)  
Figure 10: Distribution of soybean cultivated proportion at household level in the receiving system. On the x-axis is the soybean proportion (areas cultivating soybean over the entire family property) and on the y-axis is the number of farmers (agents) with this proportion. The upper panel (a) is the distribution of soybean proportion among the interviewed 411 households (y-axis is from zero to 120 farm households). The le panels (a1 and b1) are their soybean proportions 10 years ago while the right panels (a2 and b2) present the current soybean proportion. The lower panel (b) is the simulated distribution (y-axis is from zero farmer agents to 6,000 simulated farmer agents).

![](images/538d97297767281a26b806226510445e32208da99836d270f737f4c3575d9783.jpg)

![](images/fff15a89cc8275cea3e175d2355e9d6b16117d72a94bdb6cd570408ab9bb6cb6.jpg)  
Figure 11: Simulated soybean price and empirical soybean price. The unit in the two systems are local currencies: (a) real/kg and (b) yuan/kg respectively. T-test results for the empirical and simulated soybean price in both systems are not significant, which indicates that the simulated and empirical soybean prices are from the same sample distribution. Empirical prices are adjusted for inflation.

tari) (Figure 12). Both scenarios indicate that the double-soybean planted area (soybean-corn) increases while single soybean cultivation decreases. However, when the tari charge starts at year 5, fewer cells are converted to soybean-corn each year, and more cells are converted to single soybean compared to the business-as-usual scenario. This suggests that the tari slows down the intensification on Brazilian soybean farms, because farm-

![](images/1580519b1f161b524394bd57f993487795b91e51657c07de55a394355118196b.jpg)

![](images/01382b399759a9cee14e8796e3886ba76b3ce31739c9e42a9e267ad435a96e8b.jpg)

![](images/44187c26a19ce30e7c12841da67389b0f8ac62ed63315b6dfd34509619580324.jpg)  
Figure 12: Annual land-use changes: (a) single soybean and (b) soybean-corn in the sending system in the sample simulation. The tari becomes eective starting from year 5. Hence we show results starting from year 4.

![](images/b2c15d20a4a36d8c6669d00148413f9532a3d2bfe9c0912da08766cba6020243.jpg)  
Figure 13: Annual land-use changes: (a) soybean and (b) corn in the receiving system in the sample simulation.

ers may not be able to prepare for a second growing season since they get less profit from the soybean trade.

# Cascading eect on the land-use changes in the receiving system

3.3 A cascading eect (i.e., chain events caused by the trade of one crop aecting other systems and components Silva et al. 2017) is also observed in this sample simulation. The tari not only aects the land uses in the sending system but also aects land-use changes in the receiving system (Figure 13). The tari drives the Brazilian soybean price and production down due to less demand from China which, in turn, aects the international soybean price. In the receiving system, because soybean imports are lower than domestic demand, the government agent provides a subsidy to local farmers for added soybeans to their crop cultivation (5,000 yuan/ha). This changes farmers’ preference from corn to soybeans and slows crop conversion from soybeans to corn in the receiving system. The dierences between the baseline scenario and the tari scenario in the receiving system start from year 6, which is one year later than the sending system (year 5) as a cascading eect.

# Discussion

# Dierent approaches used for receiving and sending system land-use simulation

4.1 To the best of our knowledge, there is no model in current ABM applications that represent two distant land systems in one model. As mentioned above, the individual systems in our model (i.e., sending and receiving systems) vary in agent attributes, behaviors, interactions, and market structure. One of the challenges of building telecoupled ABMs is to represent the land use and decision making of two very dierent land systems. Moreover, the available datasets for the two systems are most likely not interoperable. Fieldwork outcomes from the two systems are also very dierent: a quantitative database that details hundreds and thousands small farming householdsâĂŹ characteristics and land-use information in the receiving system, and a mixed qualitative and quantitative dataset that describes dozens of large soybean producers in the sending system. The key is to identify the common features and variations in both systems and minimize the modelling workload. This is discussed in detail in another article that focuses on the design philosophy of TeleABM (Dou et al. 2019).

# Aggregated errors from local simulation to telecoupling simulation

4.2 Another major challenge of TeleABM is validation, similar to many other modeling eorts (van Vliet et al. 2016). The validation of ABMs can use either the structure or the model outcome (Evans 2012; Millington et al. 2011). For TeleABM, we need to validate both the individual system as well as the flows between the two systems. Therefore, in total three validations are conducted for TeleABM. Validation methods for the sending and receiving systems dier and are based on data availability. For the sending system, the land use is validated by using a ROC curve while in the receiving system, the land-use simulation results are validated by the pattern-oriented approach. The flow between the receiving and sending systems is compared to the simulated soybean price with the historical local soybean prices. Based on insights gained during the validation process, we recommend the integration of many datasets from multiple coupled human-natural systems into a common, interoperable database following the telecoupling framework. This will eliminate errors for calibration and validation.   
4.3 The flow between the two systems is represented by the supply and demand function and calibrated with several other global factors (e.g., average fuel price). For validation, we use the simulated soybean supply from the sending system to feed the international soybean trade agent, which is dierent from the empirical soybean supply. Although this dierence (between empirical soybean supply and simulated soybean supply) is within the acceptable range, it may be passed from the international soybean trade agent to local soybean trade agents in China, creating a larger deviation of soybean price in the receiving system from the empirical soybean price.

# Alternative modelling structures

4.4 One of the shortcomings of ABMs is the YAAWN syndrome (Yet Another Agent-Based Model...Whatever...Nevermind... ), which addresses that many ABMs in land science are case-specific (O’Sullivan & Manson 2015). There have been attempts to easily apply ABMs from one place to other places, such as proposing generalized modelling frameworks including MP-MAS (Marohn et al. 2013; Schreinemachers & Berger 2011) and the CRAFTY framework (Arneth et al. 2014; Blanco et al. 2017; Murray-Rust et al. 2014), or using inter-model comparisons to identify the common attributes and functions (Huber et al. 2018; Parker et al. 2008).   
4.5 The presented model is constructed from empirical data and common variables from land system science, rather than following CRAFTY or a similar modelling framework. This is because these frameworks are oen accumulated from European land-use changes and modelling. It may underrepresent certain important features if applying such frameworks in agricultural frontier (Brazil) or in small farming households (China), or require rich datasets to calibrate. As new research pointed out, in urban studies the field is dominated by global north researchers which underrepresent urgent issues in the global south (Nagendra et al. 2018). Our decision-making processes in the sending and receiving systems are both based on widely used statistical methods (e.g., logistic regression); hence it can be easily adopted by other cases with similar properties.   
4.6 Some scholars have suggested to the first author to use individual ABMs and then connect the simulation results in a dierent program (e.g., system dynamics models or computable general equilibrium model) instead of the current format as simulating multiple systems in one model. This indeed is the approach that another project adopted for studying the telecoupling land-use changes in Brazil (Millington et al. 2017). However, we argue that the focus of this other telecoupling project is solely on the local land-use changes in Brazil in the telecoupled

soybean system. What we care most about and what insights our model can oer is the causes and eects of local land-use changes on the other land systems. Moreover, if we externalize the feedbacks in another program, the validation might be an additional challenge since it is diicult to adjust the chain of changes in local land systems caused by the change from the flow.

# Future directions and policy implications

4.7 The design, development and implementation of the first ABM that represents land-use changes in two systems distantly connected through trade flows opens new research avenues for many issues in dierent research fields, such as the sustainable governance in land system science and environmental impact assessment of international trade. In the present study, we simplify international trade dynamics by only modeling flows between the sending and receiving systems. Future work could expand upon this by simulating flows between multiple senders and receivers as well as flows to spillover systems. For example, TeleABM could be expanded to include land-use change in the United States, the second largest soybean producer and exporter. Producers in the U.S. are aected by trade dynamics between Brazil and China and vice versa. Spillover systems are one of the most elusive and underrepresented components in current telecoupling studies (Liu et al. 2018). For example, TeleABM could be improved by including some emerging soybean producing regions (e.g., Argentina, Uruguay).   
4.8 TeleABM can play multiple roles within land system science and can be used to derive policy implications. First, TeleABM addresses the omission of distant land-use actors and processes in current land-use modeling practise (Verburg et al. 2019). The underlying mechanisms of certain land-use demand that are generated from outside of the modeled area can be explicitly represented in one model. Second, we can employ the model to simulate potential policies and technology changes in one system and evaluate the responses in its telecoupled partners. For example, in the high-tari scenario, potential subsides from Brazilian government to local soybean farmers could reshape land uses in China. In the future, improvements in domestic transportation and port access will influence Brazilian farmers’ production decisions and thus potentially aect China’s land-use changes. Meanwhile, China’s eorts to protect its natural land cover (Liu et al. 2018), such as the Grain-to-Green Program (Liu et al. 2008), could reduce China’s crop production, incentivize imports from its trading partners, and impact land uses in the exporting country. Lastly, as a tool to analyze distantly coupled human-natural systems, TeleABM can enable researchers and policy-makers evaluate potential trends and policies, such as land consolidation and crop diversity, to achieve food security and sustainable development in the overall food production system including both importing and exporting regions.

# Conclusion

5.1 In this study, we develop TeleABM, a novel telecoupled agent-based model using a hierarchical modelling structure and the telecoupling framework. The validated model is used for a sample simulation of a high-tari scenario on international soybean trade and the eects on land-use changes in both sending and receiving systems were demonstrated. TeleABM is useful in three major aspects. First, it fills a gap in current land systems science. Besides assessing the one-way land-use changes under external forces, it demonstrates land-use feedbacks between distant land systems. Second, it is a valuable research tool for testing telecoupling hypotheses and quantifying telecoupling relationships across distant land systems. Last, the experiences and lessons learned through its construction can be used to advance the methodology of agent-based modelling, since no ABM has simulated more than one land system simultaneously.

# Model Documentation

The model was implemented in RePast Simphony 2.4 (https://repast.github.io/download.html). The code is available at: https://www.comses.net/codebases/c7e925e0-a228-4e56-81e9-07455f453497/ releases/1.0.1/.

# Appendix

Table 4: General description of sending and receiving systems   

<table><tr><td></td><td>Year</td><td>Sending system Sinop, Mato Grosso, Brazil</td><td>Year</td><td>Receiving system Gannan, Heilongjiang, China</td></tr><tr><td>area (km2)</td><td></td><td>3,194</td><td></td><td>4,792</td></tr><tr><td>population</td><td>2017</td><td>135,874</td><td>2012</td><td>390,000</td></tr><tr><td>soybean planted area (km2)</td><td>2017</td><td>1,437</td><td>2012</td><td>318</td></tr><tr><td>soybean production (tons)</td><td>2016</td><td>403,200</td><td>2012</td><td>56,335</td></tr><tr><td>soybean yield (kg/ha)</td><td>2016</td><td>3300</td><td>2015</td><td>2007</td></tr></table>

![](images/1252b09e318613423e10546d269ca540cc8c4d2d31ed4a8883fbe1f952c0b6bf.jpg)  
Figure 14: Land-use changes in the sending system, Sinop, from 2004 to 2014 (Kastens et al. 2017).

![](images/1d50ddb2a2e66495f0a1203323bb4d323c0c9360f1d8983ac31bf89554a411e2.jpg)  
Figure 15: Land-use changes in the receiving system, Gannan, from 2000 to 2012. Data source: Heilongjiang Provincial Bureau of Statistics & Survey Oice of the National Bureau of Statistics in Heilongjiang (2019).

# Common ABM concepts represented in the model

The feedback between distant places is the primary feature of TeleABM. To follow the $O D = D + D$ protocol, we still document the following properties even though some concepts are not used in this paper.

# Emergence

Farmer agents’ land-use behaviors are expected to vary when their characteristics are initialized dierently, the crop subsidy changes, and by the trading/climate scenarios. The expansion of rice paddy in the receiving is expected to emerge as well as the expansion of soybean-corn in the sending system.

# Adaptation

Farmer agents do not change their decision-making rules. However, they adjust their land-use behaviors according to the crop price, profit, labor, previous land use, and other factors.

# Objectives

Farmer agents in both systems try to maximize the suitability of the land cells in their property.

# Learning

Farmer agents in the two systems update the crop profit every year. They also learn from their neighbors about the crop profit and use it to decide next year’s land-use decision, if they do not grow the crop at current year.

# Fitness

No survival fitness is included in the model.

# Prediction

Farmer agents are not able to predict accurate crop price for next time step.

# Sensing

Farmer agents can sense the crop profit of neighbour agents if they themselves do not grow this crop.

# Interaction

Direct interactions occur between farmer agents and local trade agents. Direct interactions also happen between neighbour agents from observing each other and aecting the landscape (e.g., only when a neighbouring cell is rice paddy one can change it to rice paddy). Indirect interactions occur between farmer agents in the sending and receiving systems through international trade agents. Farmer agents also interact with the environment through land-use decisions and management.

# Stochasticity

Farmer agents have individual variation in attributes and decision-making parameters, which are drawn from survey data and set as statistical distribution. Furthermore, noises are added to crop management (e.g. a random number is added to fertilizer input and yield) and crop price (e.g. the crop price sensed by farmer agents have a small random value).

# Collectives

The crop production from individual farmer agents is aggregated at the end of each time step, and enters the international trade agent. The crop price generated by the international trade agent later aects the individual land-use changes in both systems. Government agent also implements certain policies by reviewing the aggregated land-use results.

# Heterogeneity

Heterogeneity is represented by farmer agents’ properties, such as farm size and education. It is also determined by varying certain decision-making features, such as pro-diversifying in the sending system.

# Observation

At each time step, land uses are recorded at each farmer agent level, as well as their capital and environmental usage (e.g. fertilizer use, yield, water usage).

# Path dependence

Land-use decision of cell i at step t is aected by the land use of this cell at previous steps. The influence comes from (1) soybean farmer agent’s knowledge of dierent crops, (2) land-use history that aects current crop choice and yield, (3) neighbours’ land-use conversions from and to rice paddy can aect the possibility of agent’s rice paddy decisions.

# Details

# Initialization

The initialization includes three parts:

Users set up global parameters: users determine which system(s) to run simulation on, the scenario of crop prices, and number of initial farmer agents and vision.

• static crop price: the model reads crop price written by users at the panel, and will stay the same over the simulation time steps

• dynamic crop price: the model reads files that include crop price at every year   
• telecoupling feature: the model has sending and receiving systems, and exchange price information during simulation.

The model reads configure files and maps to initialize land cells:

• crop land-use maps from remote sensing data   
• empirical crop suitability map   
• empirical or hypothetical soil map

The model initializes agents and their characteristics:

• initialize parameters for each system, such as the range of production cost   
• several attributes of agents (e.g. capital, gender ratio, education) are initialized based on weighted or normal distribution drawn on statistical distribution from survey data and other sources.

# Input data

TeleABM uses three types of input data, which also corresponds to three initialization steps.

Table 5: Input data of TeleABM   

<table><tr><td>Input file</td><td>Function</td></tr><tr><td>Parameter setting</td><td></td></tr><tr><td></td><td>sending system representation</td></tr><tr><td></td><td>receiving system representation</td></tr><tr><td></td><td>number of initial farmer agents in sending system</td></tr><tr><td></td><td>number of initial farmer agents in receiving system</td></tr><tr><td></td><td>price of crops (soybean, corn, rice, cotton): if &gt;0, static price, if &lt;0, use dynamic price or use telecoupling price</td></tr><tr><td>Bio-physical data</td><td></td></tr><tr><td></td><td>land-use maps (classified MODIS images(2005 and 2010) and Landsat images (2000, 2006, 2011, 2016, as a verification source) of Gannan, Heilongjiang, and PRODES data (2004-2014) of Sinop, MT)</td></tr><tr><td></td><td>temperature and precipitation map (empirical data, such as maps of annual accumulated temperature above 10°C and maps of precipitation of Hei-longjiang)</td></tr><tr><td></td><td>nmaps of soil types</td></tr><tr><td></td><td>maps of elevation and slope</td></tr><tr><td>Socio-economic scenario</td><td></td></tr><tr><td></td><td>text files contain annual price of crops</td></tr><tr><td></td><td>different settings of tariff</td></tr><tr><td></td><td>maps of distance to urban and roads</td></tr></table>

# Submodels

Ecological model. In this model (LandCell class in the receiving system), yield of crops (converted to land cell spatial unit from per ha) is a function of fertilizer, precipitation, and temperature, based on relationships found in literature. However, in this version, we do not include the crop yield response to fertilizer use in the receiving system. Crop yield is a constant value using the survey average (i.e., soybean $2 , 0 0 8 ~ \mathsf { k g / h a }$ , corn yield 9,597 kg/ha, and rice 8,112 kg/ha). In the sending system, the parameterization of each crop yield is given based on experts’ opinion (Table 6 in the Appendix). For instance, if a cell is used as soybean-corn, the soybean yield is $3 , 0 0 7 . 2 \AA 9 0 \%$ kg/ha and the corn yield is $4 { , } 1 2 0 ^ { \ast } 1 0 0 \% \mathsf { k g }$ /ha.

Table 6: Average crop yields to each land use type in Sinop, MT, Brazil   

<table><tr><td>crop</td><td>average yield (kg/ha)</td><td>land use</td><td>parameter (%)</td></tr><tr><td rowspan="3">soybean</td><td rowspan="3">3007.2</td><td>single soybean</td><td>105</td></tr><tr><td>soybean-corn</td><td>95</td></tr><tr><td>soybean-cotton</td><td>95</td></tr><tr><td>corn</td><td>4120.0</td><td>soybean-corn</td><td>100</td></tr><tr><td rowspan="2">cotton</td><td rowspan="2">3346.2</td><td>single cotton</td><td>105</td></tr><tr><td>soybean-cotton</td><td>95</td></tr></table>

