Original Articles

# A novel methodology for poverty evaluation and spatiotemporal coupling coordination between poverty and eco-environment quality: a case study in the Yunnan-Guizhou Plateau, China

![](images/4ee019ae14519121e04d245b3cc949f1b9ff7d266600aabdd884477489b5f160.jpg)

Yun Liu a , Weiheng Xu b,* , Leiguang Wang c , Ning Lu b , Weili Kou d , Guanglong Ou a Huan Wang b , Juxiang He b , Xiongfu Gao b

a College of Forestry, Southwest Forestry University, Kunming, Yunnan 650233, China   
b College of Big Data and Intelligent Engineering, Southwest Forestry University, Kunming 650233, China   
c College of Landscape Architecture and Horticulture, Southwest Forestry University, Kunming 650224, China   
d Key Laboratory of National Forestry and Grassland Administration on Forestry and Ecological Big Data, Southwest Forestry University, Kunming 650224, China

# A R T I C L E I N F O

Keywords:

Poverty

Geospatial Comprehensive Poverty Index

Ecological Environment Quality

Local and Tele-Coupling Coordination Degree

Yunnan-Guizhou Plateau

# A B S T R A C T

The coordinated development between poverty alleviation and ecological restoration is essential for sustainable socioeconomic and environmental progress. As poverty alleviation efforts intensify in the Yunnan-Guizhou Plateau (YGP), the ecological environment has become increasingly fragile. However, traditional methods of poverty measurement face challenges in data collection, model construction, and dynamic analysis. Moreover, the interactive mechanism between poverty and Ecological Environment Quality (EEQ) remains unclear. Therefore, this study developed a novel Geospatial Comprehensive Poverty Index (GCPI) using multiple datasets to identify poverty and verified its applicability. Furthermore, the interaction between poverty and EEQ was investigated utilizing the Local and Tele-coupling Coordination Degree (LTCCD) model. This study also analyzed the spatiotemporal dynamics of GCPI, RSEI, and LTCCD between poverty and EEQ in the YGP from 2012 to 2023. The results revealed that: 1) GCPI showed a decreasing trend, with an average annual decline rate of − 0.0015 year− 1 , indicating effective poverty alleviation. 2) RSEI exhibited an increasing trend, with an average annual growth rate of $0 . 0 0 3 5 \ \mathrm { y e a r } ^ { - 1 }$ , and its mean value increased from 0.5318 to 0.5830 reflecting continuous improvement in the overall EEQ across the YGP during the study period. 3) The LTCCD between poverty and EEQ across all counties ranged from 0.592 to 0.829, with a slightly increasing trend, demonstrating a high level of coordinated development between poverty and EEQ in the YGP. This work provides a novel methodology for assessing coupling coordination between poverty and EEQ, which can support the long-term sustainable development of regional society-economy-environment system.

# 1. Introduction

Poverty is a global issue with significant impacts on human development and social stability. In 2015, the United Nations 2030 Agenda for Sustainable Development identified the eradication of extreme poverty for all people everywhere by 2030 as a key Sustainable Development Goal (Nation, 2015). As the world’s largest developing country, China has seen a notable decline in its poverty rate, from $1 0 . 2 \%$ in 2012 to just $0 . 6 ~ \%$ in 2019 (Qiu, 2021). By the end of 2020, the country had successfully lifted all impoverished individuals out of poverty according to national standards, thereby accomplishing its targeted poverty

alleviation tasks on schedule (Huang, 2021). However, previous studies have demonstrated that poverty alleviation and economic growth have led to increased energy consumption, accelerated urbanization and industrialization, intensified urban heat islands, and higher carbon emissions (Ran et al., 2022a), all of which negatively effect regional EEQ. These impacts include landscape fragmentation (Chen et al., 2021), air pollution (Dong et al., 2023), and encroachment on forests and farmland (Liu et al., 2023c). Therefore, evaluating regional poverty and EEQ and assessing their interrelationships are critical for promoting the sustainable development of regional social, economic, and ecological systems.

Over the past few decades, growing governmental and international focus on poverty alleviation has prompted extensive research into the accurate identification and assessment of regional poverty (Imran et al., 2014; Ma et al., 2019; Wang et al., 2022; Yu et al., 2015). Traditionally, poverty status has been evaluated using single economic indicators such as income, expenditure, GDP, or per capita GDP (Benson et al., 2005; Hyman et al., 2005). However, poverty is influenced not only by economic conditions but also by social, political, and environmental factors. Thus, a single economic index cannot adequately reflect the true extent of poverty. With the refinement of socioeconomic census data, poverty assessment methods have shifted from unidimensional economic indices toward multidimensional metrics. For example, the multidimensional poverty metrics such as Human Poverty Index (HPI) (Weziak-Bialowolska and Dijkstra, 2014), Multidimensional Poverty Index (MPI) (Gachanja and Yang, 2025), Multi-source Data Poverty Index (MDPI) (Niu et al., 2020), and Human Development Index (HDI) (Niu et al., 2020) have been developed to identify poverty. These indicators are typically constructed using axiomatic approaches, information-theoretic technique, importance–performance analysis, and so on (Ma et al., 2019). Although most of these approaches can provide accurate poverty measurement, they depend on detailed and high-quality survey data, which are often difficult to obtain, costly, and limited in timeliness and spatiality. Compared with traditional statistics and census data, highresolution, readily accessible, and objective remote sensing data have great advantage in geographical poverty (regional poverty with spatial information) identification (Imran et al., 2014; Lin et al., 2021; Putri et al., 2022). Some investigations have indicated that Nighttime Light (NTL) data can effectively reveal regional socioeconomic development levels (Yu et al., 2015; Zhang et al., 2022). However, because NTL data are insufficient to characterize the multidimensional attributes of poverty, numerous geospatial comprehensive poverty indices have been constructed for monitoring geographical poverty by leveraging multisource remote sensing data (NTL, Sentinel-2, Sentinel-5P, topography,

Table 1 Abbreviations in this article.   

<table><tr><td>Abbreviation</td><td>Meaning</td><td>Abbreviation</td><td>Meaning</td></tr><tr><td>GCPI</td><td>Geospatial Comprehensive Poverty Index</td><td>POI</td><td>Points of Interest</td></tr><tr><td>RSEI</td><td>Remote Sensing Ecological Index</td><td>DEM</td><td>Digital Elevation Model</td></tr><tr><td>EEQ</td><td>Ecological Environment Quality</td><td>GDP</td><td>Gross Domestic Product</td></tr><tr><td>CCD</td><td>Coupling Coordination Degree</td><td>NLT</td><td>Nighttime Light</td></tr><tr><td>LTCCD</td><td>Local and Tele-Coupling Coordination Degree</td><td>YGP</td><td>Yunnan-Guizhou Plateau</td></tr><tr><td>NDVI</td><td>Normalized Vegetation Index</td><td>DNB</td><td>Day-Night Band</td></tr><tr><td>HIS</td><td>Human Settlement Index</td><td>HPI</td><td>Human Poverty Index</td></tr><tr><td>PD</td><td>POI Density</td><td>MPI</td><td>Multidimensional Poverty Index</td></tr><tr><td>PCD</td><td>POI Cost Distance</td><td>QRL</td><td>Quality of Rural Life</td></tr><tr><td>LST</td><td>Land Surface Temperature</td><td>RPI</td><td>Relative Poverty Index</td></tr><tr><td>Wet</td><td>Wetness Index</td><td>MDPI</td><td>Multi-source Data Poverty Index</td></tr><tr><td>NDBSI</td><td>Normalized Difference Built-up and Soil Index</td><td>HDI</td><td>Human Development Index</td></tr><tr><td>mNDWI</td><td>modified Normalized Difference Water Index</td><td>PCA</td><td>Principal Component Analysis</td></tr><tr><td>SI</td><td>Soil Index</td><td>PC1</td><td>First Principal Component</td></tr><tr><td>IBI</td><td>Building Index</td><td>LISA</td><td>Local Index of Spatial Auto-correlation</td></tr><tr><td>Moran&#x27;s I</td><td>Global Spatial Auto-correlation Index</td><td>IDW</td><td>Inverse Distance Weight</td></tr></table>

and point of interest data), with relatively high accuracy (Putri et al., 2022; Shi et al., 2020; Wang et al., 2023). Despite these advances, such indices still face challenges in their establishment and application, including subjectivity and uncertainty in determining parameter weights, inefficiencies in integrating multi-source data, and a lack of long-term dynamic analyses of regional poverty trends.

Regarding regional EEQ assessment, the Remote Sensing Ecological Index (RSEI) is a commonly used indicator that integrates four ecological elements: vegetation greenness, moisture, aridity, and temperature. it is developed by Xu Hanqiu in 2013 (Xu, 2013). Owing to its advantages in timeliness, visualization, and scalability, RSEI has been extensively used to evaluate EEQ in different ecosystems, including urbans (Shi et al., 2023b; Zhang and Kuang, 2024), forests (Liu et al., 2023c), mining areas (Liu et al., 2023b), wetlands (Jing et al., 2020), and desert areas(Jiang et al., 2019). On the one hand, to enhance the accuracy of EEQ assessment in specific geographical environment, some strategies (e.g., replacing the original indicator, adding a new index, or modifying weight setting methods) were employed to improve RSEI (Liu et al., 2022; Xu and Deng, 2022; Zhang and Kuang, 2024). For instance, Liu et al. (Liu et al., 2023c) calculated the three-dimensional greenness of forest to replace the greenness indictors (NDVI) in RSEI, constructing improved RSEI to make a more scientific forest EEQ assessment. On the other hand, many studies of the EEQ dynamics (Min et al., 2022; Shi et al., 2023b), EEQ drivers(Hu et al., 2024a; Liu et al., 2023a), EEQ prediction (Zhang and Kuang, 2024; Zhong et al., 2023), and implement effects of ecological restoration project (Yang et al., 2023) have become current hots. Some scholars have found that the urbanization, land use change, and economic growth (e.g. per capita GDP) are primary drivers for EEQ changes (Min et al., 2022; Shi et al., 2023b). Hence, the coupled and coordinated connection between EEQ and urbanization, land use carbon emissions have been analyzed in regions such as Indonesia (Hasanah and Wu, 2024), China (An et al., 2023), Wuhan province (Tang et al., 2021), and the Chengdu-Chongqing Economic Circle (Zhao et al., 2025). Tang et al. (2021) observed that the EEQ and urbanization in Wuhan province have a high coupling coordination degree in 2018. Although numerous studies have explored the connection among economic, social, and ecological development (Xiao et al., 2022; Zhang et al., 2024; Zhang et al., 2021), further investigation is still needed regarding the coupled and coordinated degree between poverty and EEQ.

Previous studies have revealed that poverty, poverty reduction and ecological environment have a strong spatial interaction (Cheng and Gao, 2009; Li, 2014; Zhou et al., 2008). Rapid socioeconomic development reduces poverty. Conversely, strict ecological protection policies may restrict socioeconomic development (Cao et al., 2015; Ran et al., 2022a; Wang and Jia, 2017). To measure the interaction between poverty and the environment, several methods have been introduced by these researchers, including correlation analysis method (Zhou et al., 2008), regression fitting method (Cheng and Gao, 2009), and the Coupling Coordination Degree (CCD) model (Cao et al., 2015; Niu and Wang, 2017; Wang and Jia, 2017). Among these, the CCD model is the most popular approach for measuring the coupled and coordinated relationship between socio-economic and environmental development. For example, Chen et al. (2021) investigated the interaction of ecological fragility and poverty using CCD model throughout Guizhou province, China. However, the CCD model can only determine the local-coupling between socioeconomic factors and environment, ignoring the tele-influence on them resulting from trade, information, traffic, energy, and other interaction methods. To address this issue, Tang et al. (2021) developed the local and telecoupling coordination degree (LTCCD) model by introducing the Inverse Distance Weight (IDW) into the traditional CCD model, quantifying the LTCCD of urbanization and EEQ across the Wuhan province in 2021. Currently, the LTCCD model has been employed to analyze the interaction of synergistic development among society, economy, and environment (An et al., 2023; Li et al., 2023a; Xie et al., 2025; Zhao et al., 2025).

![](images/9098a0a9a214059144283ac29846d4307aa39939af6bf0c3711d9256fe4dd327.jpg)

![](images/c538745ea809a8fc9d2750ddc3041e3ab3c65f930c489a3b01787afbd4d63d94.jpg)

![](images/3614ce08eab84955e1d3d1e3b5347c3c277cfe76aa88d636c238b8abbea250e4.jpg)

![](images/33087d3bbc32d10c3b218f4bc720042be2984e068ba28a283ccd428cb41de587.jpg)

![](images/187867aa4901ad7419a9cb82249cb6a9259f192e771a9b4d7c934e8e9d951611.jpg)

![](images/6b9f032897f782fd231a8d3efdecd848c390f08e2792560ebf90a628e0e62f05.jpg)  
Fig. 1. Location maps of the study area. (a) and (b) present the geographical location and each county name in YGP. (c), (d), (e), and (f) show the DEM, NDVI, Nighttime light, and POI in the YGP, respectively.

Nevertheless, the coupled and coordinated degree between poverty and EEQ at local and tele-coupled scales remains uninvestigated using the LTCCD model.

The YGP is one of a fragile ecology region in the word, developing the most complex and representative karst landforms (Pu et al., 2024; Yuan et al., 2007), and it also distributes the highest concentration of state-level poor counties and poor population in China (Huang, 2021; Qiu, 2021). Cheng et al. (2021) identified that the fragile karst ecosystem with low carrying capacity, rigidity threshold, and biocapacity limits regional economic development and residents’ income growth, resulting in poverty. Consequently, the targeted poverty alleviation, poverty alleviation and relocation, and rocky desertification control policies were adopted by Chinas’ government to reduce poverty and improve ecological quality in the YGP, aiming to promoting socioeconomic and environmental sustainability (Ran et al., 2022a). These advancements in poverty alleviation and eco-environment restoration within the YGP have established favorable conditions for investigating the coupled and coordinated mechanisms between poverty and ecological quality.

The above review identifies the following research gaps in evaluating regional poverty and EEQ and measuring the interactive relationship between them: 1) Traditional poverty identification models utilizing multiple source dataset have high subjectivity and uncertainty, and the spatio-temporal dynamics of poverty remain underexplored. 2) There are limited researches on the LTCCD between poverty and EEQ in the YGP. Therefore, this study constructed the GCPI and RSEI based on multiple source remote sensing datasets to assess regional poverty and EEQ (all abbreviations and their explanations were listed in Table 1),

and measured the LTCCD between poverty and EEQ in the YGP.

This study aims to achieve the following specific objectives: 1) To develop the GCPI by integrating multi-source remote sensing datasets for poverty identification and to evaluate its applicability. 2) To measure the LTCCD between poverty and EEQ. 3) To analyzed the spatial–temporal dynamics of poverty, EEQ, and LTCCD between poverty and EEQ in the YGP from 2012 to 2023. This work provides a possibility of synergistic governance of both poverty alleviation and ecological improvement.

# 2. Materials

# 2.1. Study area

The Yunnan-Guizhou plateau (YGP) is located in southwest China $( 9 7 ^ { \circ } 3 1 ^ { \prime } - 1 0 9 ^ { \circ } 3 6 ^ { \prime } \mathrm { E }$ , $2 1 ^ { \circ } 0 9 ^ { \prime } { - } 2 9 ^ { \circ } 1 5 ^ { \prime } \mathrm { N } )$ ) and includes Yunnan and Guizhou provinces (Fig. 1a). It consists of 217 county-level administrative regions (Fig. 1b), and covers an area of approximately $5 7 0 , 2 0 0 \mathrm { k m } ^ { 2 }$ , accounting for approximately $5 . 9 \%$ of China’s overall territory (Nie et al., 2024). As shown in Fig. 1c, the elevations of this plateau range from $7 4 \mathrm { m }$ to 6,740 m, with the most typical Karst landforms (Yuan et al., 2007). In terms of climate, the YGP is characterized by the Southeast Asian monsoon, with mean annual temperature values of $1 6 . 2 ^ { \circ } \mathsf { C }$ and an annual rainfall that ranges from 800 mm to $1 { , } 5 0 0 \mathrm { m m }$ (Zheng et al., 2008; Zhu et al., 2022). In addition, this region has the highest concentration of impoverished individuals in China, the nighttime light ranges from 1.38 nano-wcm $^ { - 2 } \mathrm { s r } ^ { - }$ 1 to 138.41 nano-wcm $^ { - 2 } \mathrm { s r } ^ { - 1 }$ , and POI are mainly distributed in the urban region of YGP (Fig. 1e and Fig. 1f).

![](images/a0542f4710a290bc1f68dfb26b75df0c89357077aa24adf88d6aeeb8be6a3fa4.jpg)  
Fig. 2. A framework for quantifying the LTCCD between poverty and EEQ using multisource datasets.

The YGP was chosen as the study region for three primary reasons: 1) The YGP is a crucial battlefield for targeted poverty alleviation in China, and its economy has shown a notable increase from 2012 to 2022 (Huang, 2021; Yin et al., 2020). 2) The region serves as a vital ecological security barrier in southwestern China (Cheng et al., 2020). 3) As a representative ecologically sensitive area, the YGP exhibits an obvious interaction between poverty and EEQ (Nie et al., 2024).

# 2.2. Data and preprocessing

Satellite imagery and social statistical datasets served as the sources of data employed in the research. The satellite imagery contains MOD09A1, MOD11A2, and MOD13A1 products derived from the Moderate-Resolution Imaging Spectroradiometer (MODIS), the Top-of-Atmosphere (TOA) Nighttime light product (VNP46A1), DEM, and Google Earth Images with high spatial resolution from Google Earth Pro

software. The MOD09A1, MOD11A2, MOD13A1, and VNP46A1 products for the YGP were collected from the USGS EROS Center (https://lp daac.usgs.gov), spanning the period from 2012 to 2023. Among the MOD09A1 and MOD11A2 products were pre-processed by cloud and cloud shadow, mean synthesis, resampling, and water_mask methods to calculate RSEI (Gorelick et al., 2017; Liu et al., 2023a). Furthermore, the Day-Night Band (DNB) and Normalized Vegetation Index (NDVI) selected from VNP46A1 and MOD13A1 products were used to construct the Human Settlement Index (HSI) in the GCPI model. The VNP46A1 product was obtained by the Suomi National Polar-orbiting Partnership (SNPP) Visible Infrared Imaging Radiometer Suite (VIIRS) supports a Day-Night Band (DNB) sensor, with the spatial resolution of $5 0 0 \mathrm { m }$ (Hu et al., 2024b; Yu et al., 2015). The DEM was collected from NASA SRTM Digital Elevation data on the GEE platform at a resolution of 1 arcsecond (approximately $3 0 \mathrm { ~ m } )$ (https://www.nasa.gov/), which was employed to calculate slope for assessing topographic change. Social

Table 2 Formula for ecological indicator calculation and its interpretation in RSEI.   

<table><tr><td>Indices</td><td>Calculation formula</td><td>Explanation</td></tr><tr><td>NDVI</td><td>(B2-B1)/(B2+B1)</td><td>B1, B2, B3, B4, B5,</td></tr><tr><td>WET</td><td>0.1147B1+0.2489B2+0.2408B3+0.3132B4-0.3122B5-0.6416B6-0.5807B7</td><td>B6, B7 characterize Red, Near-Infrared band 1 (NIR1), Blue, Green, Near-</td></tr><tr><td>NDBSI</td><td>(SI + IBI)/2</td><td></td></tr><tr><td>LST</td><td>0.02ρ1-273.15</td><td>Infrared band 2 (NIR2), Short-Wavelength Infrared 1 (SWIR1), and Short-Wavelength Infrared 2 (SWIR2) bands of the MOD09A1 products, respectively (Shi et al., 2023a). Besides, SI is the soil index and IBI is the building index (Li et al., 2023a). ρ1 is the gray value of the MOD11A2 daytime surface temperature band (An et al., 2023).</td></tr><tr><td>mNDWI</td><td>(B4-B6)/(B4+B6)</td><td></td></tr></table>

statistic datasets include POI data, per capita Gross Domestic Product (GDP), and poverty-stricken county data, etc. The POI data was a group of point locations for human activities with the information of site/facility names, locations, and their categories. In this study, the 19 types of POI in the YGP were downloaded from the Place API of Baidu Maps (htt p://map.baidu.com/), computing POI Density (PD) and POI Cost Distance (PCD) based on the kernel density estimation and cost distance analysis. The data on per capita GDP and poverty-stricken counties were downloaded from the statistical Yearbook of Yunnan and Guizhou provinces. It should be noted that all remote sensing datasets of RSEI and GCPI construction in this study were processed by mean synthesis, and the specifics of the above datasets were provided in Table A-1 in the supplementary materials.

# 3. Methods

This study involves four technical stages within its methodological framework (Fig. 2). Firstly, the multiple source datasets were utilized to develop the poverty and ecological indicators (e.g. NDVI, WET, NDBSI, LST, Slope, SHI, PD, and PCD). Secondly, these indicators were employed to construct RSEI and GCPI using PCA method. Thirdly, the coupling degree between poverty and EEQ was quantified by LTCCD model. Finally, this study explored spatio-temporal dynamics and heterogeneity of RSEI, GCPI, and LTCCD between poverty and EEQ for suggesting of the YGP development.

# 3.1. Construction of RSEI

This study introduced RSEI to evaluate EEQ in the YGP from 2012 to 2023. The RSEI integrates greenness, wetness, dryness, and heat ecological elements easily perceived by the human body, and these ecological elements are characterized by the indicators of NDVI, Land Surface Temperature (LST), Wetness Index (Wet), and Normalized Difference Built-up and Soil Index (NDBSI), respectively (Xu, 2013). The detailed calculations and corresponding results of these ecological indicators were presented in Table 2 and Fig. A-1a-d in the supplementary materials. Besides, the weights of four ecological indices were obtained using principal component analysis (PCA) method in RSEI construction, among PC1 integrates the most of indicator information is selected to couple RSEI (Xu et al., 2019). Thus, the formula of the primary function of RSEI can be written:

$$
R S E I _ {0} = 1 - P C 1 [ f (N D V I, W E T, N D B S I, L S T) ] \tag {1}
$$

Before generating RSEI, to ensure that WET can truly reflect the wetness elements, the modified Normalized Difference Water Index (mNDWI) was calculated to update mask waterbody within the research region (Xiong et al., 2021).

Since each indicators present various unit and numerical range, this study normalized above ecological indices within [0,1] before PCA. The mathematical expression for normalization is as follows:

$$
N _ {i} = \left(V _ {i} - V _ {\min }\right) / \left(V _ {\max } - V _ {\min }\right) \tag {2}
$$

Where $N _ { i }$ and $V _ { i }$ are the indicator values of normalized and original in the i-th pixel, respectively. $V _ { m a x }$ is maximum value and $V _ { m i n }$ is minimum value of ecological index in the YGP. The RSEI was generated from $R S E I _ { 0 }$ by using Eq.2, and the RSEI values were used to directly reflect EEQ in previous study. The RSEI values were divided into five categories: Poor [0–0.2), Fair [0.2–0.4), Moderate [0.4–0.6), Good [0.6–0.8), and Excellent [0.8–1), and the values of RSEI closer to 1 reflect superior EEQ (Ren et al., 2023).

# 3.2. Development of GCPI

Poverty is considered to be influenced by complex and multidimensional elements such as natural, economic, and geographic, etc. (Feng et al., 2024; Gachanja and Yang, 2025). This study referenced the previous studies to develop a novel index of GCPI to assess poverty statues in the YGP. In GCPI, the Slope, HSI, PD, and PCD were employed to reflect the topographic change, human settlements, human survival and productivity, and socio-economic development (Niu et al., 2020; Shi et al., 2020; Yin et al., 2020). The GCPI was developed by the weighted summation method in the YGP:

$$
G C P I _ {i} = 1 - \left[ \sum_ {j = 1} ^ {4} \left(W _ {i j} \times X _ {i j}\right) \right] \tag {3}
$$

Where $G C P I _ { i }$ is the initial value for poverty in the i-th pixel, $W _ { i j }$ represents the weight for j poverty indicators in the i-th pixel. This weight is calculated using the first principal component of PCA approach, as PCA is a very useful method for determining feature weights. As shown Table A-2, the contribution rate of eigenvectors in PC1 was greater than $4 6 . 7 1 ~ \%$ from 2012 to 2023, indicating that PC1 integrated the most features of Slope, HSI, PD, and PCD indicators. Furthermore, the loadings of the four poverty indicators in PC1 were relatively stable compared to PC2-PC4. In PC1, Slope represented topographic change and PCD represented accessibility (resistance) were positive values, while PD reflected economic vitality and HIS reflected human survival and productivity were negative values. This showed that Slope and PCD had a negative impact on poverty, while PD and HIS had a positive impact on poverty, which was consistent with the actual situation. Therefore, the loadings of the four poverty indicators in PC1 served as weights of their weights. $X _ { i j }$ characterized the normalized values for j poverty element in the ith pixel, and the values of these poverty factors are normalized using Eq.2 before developing GCPI. The poverty values are normalized from initial poverty values, and the GCPI were categorized into five levels: Lower [0–0.2), Low [0.2–0.4), Medium [0.4–0.6), High [0.6–0.8), Higher [0.8–1). These levels increase as the degree of poverty becomes severe.

Fig. A-1e-h shows the calculated results of slope, PD, PCD, and HIS indices. This study derived the slope from DEM data, and computed the PD and PCD based on POI data through spatial analysis method using ArcGIS 10.7 software. Additionally, Human Settlement Index (HSI) is a systematic indicator for directly reflecting residents’ living standards and quality of life, which has negatively correlated with poverty degree (Ma et al., 2018; Wang et al., 2022). The calculation of HSI specified below:

$$
H S I = \frac {\left(1 - n d v i _ {\text {m a x}}\right) + n p p _ {\text {n o r}}}{1 - n p p _ {\text {n o r}} + n d v i _ {\text {m a x}} + \left(n p p _ {\text {n o r}} \times n d v i _ {\text {m i n}}\right)} \tag {4}
$$

where $n d \nu i _ { m a x }$ is maximum value of NDVI from MOD13A1 data in the YGP, while $n d \nu i _ { m i n }$ is minimum value of NDVI. $n p p _ { n o r }$ denotes the normalized value of the DNB band from VNP46A1 NPP-VIIRS data, and the normalized process of DNB is referenced the Eq.2.

# 3.3. The LTDCC calculation between poverty and EEQ

The Local and Tele-Coupling Coordination Degree (LTCCD) model is proposed by Tang et al. (Tang et al., 2021) on the CCD model and IDW approach in 2021, which cannot only reveal the interaction between two and more systems within a region, but can also reflect the tele-coupling coordinated relationship among them (An et al., 2023; Li et al., 2023a). Therefore, the LTCCD model was employed to assess the coupled and coordinated mechanism between poverty and EEQ, its construction process was as follows:

Firstly, the coupled degree of poverty and EEQ could be defined as:

$$
C \left(P _ {i}, E _ {i}\right) = \sqrt {\frac {P _ {i} \times E _ {i}}{\left[ \left(P _ {i} + E _ {i}\right) / 2 \right] ^ {2}}} \tag {5}
$$

$$
V _ {j} = \left(X _ {\max } - X _ {j}\right) / \left(X _ {\max } - X _ {\min }\right) \tag {6}
$$

Where i is the i-th county, $P _ { i }$ is the average value of standardized GCPI in i-th county, and $E _ { i }$ is the average value of RSEI in i-th county. Due to the fact that GCPI is a negative index, the high value of GCPI reflects the high poverty degree. Thus, the GCPI was standardized using Eq (6), to ensure that its directionality is consistent with that of RSEI (Hasanah and Wu, 2024). $V _ { j }$ and $X _ { j }$ represent the standardized and original values of GCPI in the $j .$ -th pixel, the higher standardized GCPI values indicate low poverty degree, $X _ { m a x }$ is maximum value of GCPI, and $X _ { m i n }$ is minimum value of GCPI within the YGP.

Secondly, the IDW approach is introduced to formulate the local and tele-coupling degree $( C _ { S i } )$ , the mathematical expression of it is as follows:

$$
C _ {S i} = \mu \times C \left(P _ {i}, E _ {i}\right) + \lambda \left[ \frac {\sum_ {k = 1} ^ {n} w _ {i k} \times C \left(P _ {i} , E _ {k}\right) + \sum_ {k = 1} ^ {n} w _ {k i} \times C \left(P _ {k} , E _ {i}\right)}{2} \right] \tag {7}
$$

where $n$ is the total number of counties, $k$ is an integer from 1 to n and $k$ ∕= i. $P _ { i }$ and $P _ { k }$ are the standardized GCPI for county i and county $k ,$ respectively, $E _ { i }$ and $E _ { k }$ are the RSEI for county i and county $k ,$ respectively. $C ( P , E )$ represents the coupling degree between poverty and EEQ. $\mu$ and $\lambda$ are the local and remote contribution coefficients, respectively, with the values of 1/2 (Zhao et al., 2025). $w _ { i k }$ indicates the weight based on the IDW, which can be formulated as follows:

$$
W _ {i k} = \frac {D _ {i k} ^ {- p}}{\sum_ {k = 1} ^ {n} D _ {i k} ^ {- p}} \tag {8}
$$

Where $D _ { i k }$ shows the distance between the center of county i and county $k _ { : }$ , and $p$ represents the distance power, with the common value of 2 (Xie et al., 2025).

Thirdly, the local and tele-connect level between poverty and EEQ $( T _ { S i } )$ based on IDW is expressed as:

$$
T \left(P _ {i}, E _ {i}\right) = \alpha \times P _ {i} + \beta \times E _ {i} \tag {9}
$$

$$
T _ {S i} = \mu \times T \left(P _ {i}, E _ {i}\right) + \lambda \times \left[ \frac {\sum_ {k = 1} ^ {n} w _ {i k} \times T \left(P _ {i} , E _ {k}\right) + \sum_ {k = 1} ^ {n} w _ {k i} \times T \left(P _ {k} , E _ {i}\right)}{2} \right] \tag {10}
$$

where $T ( P , E )$ is the local connect level between poverty and EEQ. $\alpha$ and $\beta$ represent the weight coefficients of poverty and EEQ, respectively. As referenced in previous studies, the $\alpha$ and $\beta$ are usually set to 0.5, and $\mu$

Table 3 The categories of LTCCD between poverty and EEQ.   

<table><tr><td>LTCCD (DSi)</td><td>Category</td><td>LTCCD (DSi)</td><td>Category</td></tr><tr><td>0–0.1</td><td>Extremely unbalanced degeneration</td><td>0.5–0.6</td><td>Barely coordinated development</td></tr><tr><td>0.1–0.2</td><td>Severely unbalanced degeneration</td><td>0.6–0.7</td><td>Slightly coordinated development</td></tr><tr><td>0.2–0.3</td><td>Moderately unbalanced degeneration</td><td>0.7–0.8</td><td>Well-coordinated development</td></tr><tr><td>0.3–0.4</td><td>Slightly unbalanced degeneration</td><td>0.8–0.9</td><td>Superiorly coordinated development</td></tr><tr><td>0.4–0.5</td><td>Nearly unbalanced degeneration</td><td>0.9–1.0</td><td>Extremely coordinated development</td></tr></table>

and λ are the local and remote contribution coefficients, respectively, with the values of 1/2 (Tang et al., 2021; Xing et al., 2019).

On the basis mentioned above, the equation of LTCCD between poverty and EEQ is described as:

$$
D _ {S i} = \sqrt {C _ {S i} \times T _ {S i}} \tag {11}
$$

Where $D _ { S i }$ is the LTCCD between poverty and EEQ, which are divided into ten categories as presented in Table 3.

# 3.4. The methods of change trends and spatial heterogeneity analysis

The Theil-Sen median slope estimator and the Mann-Kendall trend test are the nonparametric statistical analysis approaches, and they are unaffected by error, outliers, and missing values (Hamed, 2008; Sen, 1968; Theil, 1950). Thus, these methods are widely used to analyze the spatio-temporal change trends and their significance in extended temporal series datasets across various fields, such as vegetation, hydrology, climate, and other studies (Gadedjisso-Tossou et al., 2021; Guo et al., 2018; Li et al., 2023b). This research combined the above two approaches to analyze the dynamics of GCPI and RSEI from 2012 to 2023. The statistical significance for GCPI and RSEI was defined by the Zvalue. When the absolute value of Z exceeds 1.65, 1.96, and 2.58, which indicates that the change trend of the GCPI and RSEI has passed the significance test with $9 0 ~ \%$ , $9 5 ~ \%$ , and $9 9 ~ \%$ confidence level, respectively (Liu et al., 2023a).

To explore the spatial heterogeneity of LTCCD between poverty and EEQ at the county scale, the Global Spatial Auto-correlation Index (Moran’s I) and the Local Index of Spatial Auto-correlation (LISA) were utilized (Anselin, 1995; Lin et al., 2002), based on GeoDa 1.18 software. Moran’s I values are closer to $^ { - 1 }$ or 1, which indicates a higher autocorrelation and homogeneity on LTCCD between poverty and EEQ, with a range of [-1, 1]. Besides, the LISA for LTCCD between poverty and EEQ is classified into five spatial clusters, including High-High, High-Low, Not-Significant, Low-High, and Low-Low. High-High represents the cluster areas with superior LTCCD, while low-low indicates the cluster areas with adverse LTCCD. The High-Low characterizes objective counties with high LTCCD enclosed by adjacent counties with low LTCCD, while Low-High illustrates the opposite. Not-Significant demonstrates an arbitrary spatial pattern of LTCCD without discernible spatial connection (Zhao et al., 2025).

# 4. Results

# 4.1. The spatial patterns and temporal variations of poverty in the YGP

As shown in Fig. 3, the GCPI values in the western areas were higher than that in the eastern areas of YGP from 2012 to 2023, showing that poverty had a spatial distribution pattern of being higher in the west and lower in the east. In addition, the GCPI at high and higher levels were mainly located in the northwestern regions of Yunnan province (Zhang et al., 2022). These regions are covered with snow or primary forest all

![](images/7a2eedc96b5e0fecce8007517dd8b6207b9e0223d1da26041b4cedf0944ac174.jpg)

![](images/65777386bdf863474b573d2263494711d8eebaf357cbf972c50459f35237536d.jpg)

![](images/a9a34592a43388e62288831d0e5a178c32778e6881f78e45b1d2d3fe33d52fc2.jpg)

![](images/f3b2308451e5363c12f2301bf182c6c914f52b65ae609478dad229bf3e28c7e3.jpg)

![](images/406d2cb25b4ba6700270542ac6caa9be21c37583018d2c2595124dd7178de4be.jpg)

![](images/dd5554c461c71fc1a619181894eed8870b15bd9e5a986fdd174bd036f6ef7196.jpg)

![](images/c4b65cb0ad4b5ffcc13b56805c0761f1e956d63ce6e70e4af1b9ebead19fadef.jpg)

![](images/7e654d9902c36588d1f44a02d54762af4aafe98ada965edd1b0858abf975aaca.jpg)

![](images/8f4a20132b0718b618922689bceea7e636ef8b9575dec5ad644849a06450aa23.jpg)

![](images/5ea87cb5f2be51f5e213941f2bfc2750c0e71a0f9a4f4a2e8ae9e942606811d5.jpg)

![](images/8c1b2d787e63aa7b71109aaec13be66c4c897be98332d66105e96c50a16a50b6.jpg)

![](images/1ed29780860e13208d5b1c59522cc9a45b6bd17d67799e034905e6f912f92e5f.jpg)  
Medium High   
Higher

GCPI: Lower

Low

![](images/8528785284bdb709301284e8a55ed81cf8be14df1729b10e60a6c0f4e4da08b4.jpg)  
Fig. 3. The spatial distribution pattern of GCPI in the YGP.

![](images/3a624fb4fda3263b363e8aa3bf4cc4cca9965be5f0f1899d056fcc30c3035c98.jpg)  
（(b)

![](images/f6c4c7443a1c7669952d7d3bd415f5ab3f8a8af74eb622149965708632d505bb.jpg)

![](images/3fd5455a6c9647c635c8ab99e4a5a19cb21d7241819a129e291ed62a92ceca7b.jpg)  
  
Fig. 4. The spatio-temporal dynamics of GCPI in the YGP from 2012 to 2023.

![](images/1256ffb20f7d6caa56226ecc4a92a227a55540a0e9a30f6b19e3e87f3212e734.jpg)

![](images/eb0376d81234dd8cc2f9ec4a8c4f5ed70c7ea0b0dda06dbe931e6b6d9a16f7f1.jpg)

![](images/7bf2e5d12a1f34fd32623956b147941f241826fbe6308e6881414f9c061272b7.jpg)

![](images/edba78d97aee56685f0befa1d2a48d8371af2fbc3408052adb4d431e6cfbfe24.jpg)

![](images/ce383ed21901c7921dc56c4ae520f4bd626302fe5065891f1c0eadba8a06add2.jpg)

![](images/6cfbe6859126362639ece268a04f840afc60612dcd6f088a2fb3ca7aad0d0b11.jpg)

![](images/3bae193ede17c11b953553d898227610b2ff4b315a08a10d84a85e4e1de75217.jpg)

![](images/861fd9bf568b3a44a0f36eafeca9febad309c4f59d745f98a7fe54a047a49650.jpg)

![](images/6acdd341f6c620f5362e4ed514b4924705eaddd124c074c7d6708360b4eb253e.jpg)

![](images/9df60324b75aa918f868195ee155d113374387904db03d6457f557a34d2cd1d3.jpg)

![](images/ee156688cdfef4a83e167fb8de0bda25d2ca4b6c8948c5be2dbaffba624e10f0.jpg)

![](images/85fe39fa4afe9f81dc980849f9258f3196cce174383ab5621349651577eb4edd.jpg)

![](images/23d3ae49fffdcff08a72ce08668b4d086ee1a25ccde08e9ceb5f21e0f113baec.jpg)  
RSEI:   
Excellent

![](images/efd30ea32fc4df6c28e61f06df66cdb8d1dc373fd2ffffef525c999a9e5feb10.jpg)  
Good

![](images/7e7a95f2326b819ea874d9af8dae2aff5d2a97c69db51b44a49fbab1b7fee098.jpg)  
Moderate

![](images/ed33b31fa5ca66281654db28b640433661f6d6ab916e398622dd8c7edd6fe070.jpg)  
Fair

![](images/278af1e345861f2a67ece3ca549cee2976b2bb4d68817b853399379c600d0048.jpg)  
Poor   
Fig. 5. Annual spatial pattern of RSEI in the YGP from 2012 to 2023.

![](images/642a791a0df9774d495389320aab6152fed4caaa00575a6104defb250f76449c.jpg)

![](images/bac49fca2148f189315071ad33a65876acdd7471664f232d88977f2bde189f4d.jpg)

![](images/4cdbf53183c60882f9843b1393117a30fe82daa2bddf0fdbccf769f5eb4fb687.jpg)  
(b)

![](images/94913f1b4ebb4ded735f0c95af4954b6ff4c82f646155a981bd900312ef3fbb1.jpg)  
  
Fig. 6. Temporal and spatial trends of the RSEI from 2012 to 2023.

![](images/c9d0deb8228d1b4b51902c4574847c43093dc0dc45d03f75c5b1d4a8e9b35150.jpg)

![](images/669499a22c7b0ff756239dcfb89322f96f75d1c2137a14c267390c6754809ffa.jpg)

![](images/ca906e052c78e8dc927ccf8ebb3324302e808ae353e8f55afa0b66f778b34b54.jpg)

![](images/baeed9554bea243f6120d1558500e7a986d79844ad591db662fa65e5c8571ace.jpg)

![](images/fca90f52186d645c29f13d393dd1690e43effcea41c8bcdd1e041bf3516b794f.jpg)

![](images/a7e85642c78c4ffedd20ea9d03b79920fd1cef54e154d2cff7252753d6083e7d.jpg)  
Fig. 7. Local and tele-coupling coordination degree between poverty and EEQ.

year round with high slope, resulting in a harsh challenging living and production environment. The GCPI at the lower and low levels were predominantly located in the central urban zone of counties, because there was a more prosperous economy in these zones (Yu et al., 2015), and the medium level GCPI has the widest distribution. The above results collectively indicated a high geographical poverty in the

northwestern, western, north-central, and northeastern regions of YGP (e.g. Deqin, Gongshan, Fugong, Luquan, Luchuan, Jingping, Yanhe, and Congjiang counties). This was similar to the findings of existing studies (Lin et al., 2021; Yin et al., 2020).

Fig. 4 displays the spatiotemporal variations of GCPI in the YGP from 2012 to 2023. The GCPI in the YGP exhibited an obviously decreasing

![](images/d0597efdbd75aabb755fddaa4b9ed027b6ecd9ca99d663f4d4e54b32c2dc34f6.jpg)  
(a1) 2012   
Standardized GCPI:

![](images/23b9ff25ef2918cbf66c3083da1857526660df181859c27b80cf79c0ad3cf5f0.jpg)

![](images/667f70257d7792277d14e9c721e511f06e718ef49f9cfa14640d155dd657053b.jpg)  
(a2)2018

![](images/93768eb979edcfc2fac8cf92e780ba4869e0c3271b350f9b48a301fc3afbdcd2.jpg)  
Medium (0.4-0.6)

![](images/b09528a348f7f3f8481d4f430cc604f3eac1c7faf1ab1ef53125e3610b63f4b6.jpg)

![](images/488a0617297507557d02b47ad72d440f7a0a65eaa00b186e47047c14bc1cf161.jpg)  
(a3) 2023   
Low (0.6-0.8)

![](images/6fd8606b244a6338edef9c0718b9138d22843f0ca1b71bd84020a59f548bb793.jpg)  
Lower (0.8-1)

![](images/01fb25b13e8291ba4594df90c4aa831f6b761ca2ecb914a6953e4da4b2779357.jpg)  
(b1) 2012   
RSEI:

![](images/fe6b042b82c634c81dba9b4c4789d53b69beae6fc8fde3f9e9ec6c1565cc1394.jpg)  
Fair (0.2-0.4)

![](images/1a86a084cbd21fc387f420fcb40bc784b9c9cf4ba13bd7443d0a96cb0ce13354.jpg)  
(b2)2018

![](images/19c6b92c7ba3b66b3b394f6822608fb81ef205da335feda1809940d62aa0a860.jpg)  
Moderate (0.4-0.6)

![](images/e353a2301a2db50b75a6e829cea5d40e0bb7926c77e6e8c7c11fe2718159f1dd.jpg)  
(b3)2023

![](images/a971df51a764d8fb67539c94db51d743a1326c5e5c7dfabb87bd1e6e26e05faa.jpg)  
Good (0.6-0.8)

![](images/01560deea0c8ab497d49e84887f01ef1bdb63def2f2e23cbb19c56a14ebd0a7f.jpg)  
(c1) 2012

![](images/77b2f95bfb9c29c861260918aef293b8822b521bc9b4cdceee86c0acb0815bc0.jpg)  
LTCCD:   
Barely coordinated   
development (0.5-0.6)

![](images/852730ab839ca59fa9fb96a4b175c36d3e44f750aab98ad0f4d260bcb9699a75.jpg)  
(c2) 2018

![](images/6437b9f2875964ded5987e4dab68165f949ee47a614970d8646fd975e005ae7a.jpg)  
Slightlycoordinated   
development (0.6-0.7)

![](images/0597e74b10a75ef98ff4dc4ad88bd31fbda760e4275209756b93feda1738c438.jpg)  
Well-coordinated   
development (0.7-0.8)

![](images/f3284ea7eb6ef84af258a8416450aa78ed1c67aef77b23b9dba7928c904a48b6.jpg)  
Superiorly coordinated   
development (0.8-0.9)   
Fig. 8. The maps of standardized GCPI, EEQ, and LTCCD in 2012, 2018, and 2023. Note: A high GCPI indicates high poverty, while a high standardized GCPI indicates low poverty.

trend from 2012 to 2023, with a decline rate of $- 0 . 0 0 1 5 \mathrm { y e a r } ^ { - 1 }$ , and the mean values of GCPI decreased from 0.4581 to 0.3953 (Fig. 4a). This result revealed that poverty in the YGP had been effectively alleviated from 2012 to 2023, which benefits from the poverty alleviation policies implemented by the Chinese government (Li and Zhou, 2025; Ran et al., 2022a; Wu et al., 2023), including targeted poverty alleviation, employment assistance, and poverty alleviation and relocation, etc. Furthermore, the percentages of high and higher-level GCPI had a decreasing trend, while that of low and lower-level GCPI showed a pattern of initial growth, subsequent decline, and later resurgence (Fig. 4b). From Fig. 4c, the GCPI presented a general decreasing trend across the majority of the YGP region during 2012–2023 (Theil-Sen’s slope $< 0$ ), and the maximum decline rate of GCPI reached $- 0 . 0 8 1 7$ year− 1 . Some region with increasing trend were observed in the northwest, south, and mid-east of YGP (Theil-Sen’s slope $< 0$ ), and the highest GCPI increased rate of 0.0695 year− 1 was observed in Deqin county. Notably, the change trends of the GCPI in the YGP during 2012–2023 was insignificant (Fig. 4d). These findings indicated that there was a slight risk of poverty recurrence in the scattered areas of northwestern, southern, and mid-eastern YGP.

# 4.2. Overall evaluation of EEQ in the YGP

The annual spatial pattern of RSEI in the YGP during the period from

2000 to 2020 is illustrated in Fig. 5. The RSEI at the good and excellent levels were mainly distributed in the western and eastern regions of YGP. This may be explained by the extensive coverage of ecological land and forests in these areas, which are well-protected under national policies. In the YGP, RSEI at the moderate levels were most commonly observed. Furthermore, the RSEI at poor and fair levels were concentrated in the central region of YGP from 2012 to 2023. These areas have a concentrated population and severe urbanization, with intense human disturbance. This resulted in the regions having a relatively high surface temperature and dryness, which is negative for RSEI. These results revealed a spatial pattern of terrible EEQ in central areas and superior EEQ in western and eastern regions in the YGP. At the same time, this study also observed that the content of excellent EEQ exhibited a slight expansion trend in the YGP from 2012 to 2023.

The temporal and spatial trends of the RSEI in the YGP from 2012 to 2023 are shows in Fig. 6. The result indicated that RSEI had an upward tendency from 2012 to 2023, with slight fluctuations (Fig. 6a). The average values of RSEI in the YGP rose from 0.5318 to 0.5830, with the growth rate of $0 . 0 0 3 5 \mathrm { y e a r } ^ { - 1 }$ . This revealed that the EEQ in the YGP was continually improved. This may be driven by the major ecological restoration projects and forestry policies implemented in this region, including Grain for Green (Shao et al., 2022), ecological protection and restoration in key areas (Ran et al., 2022b), steep slope ecological improvement (Wang and Tao, 2016), and desertification control (Wen

Table 4 The Moran’s I value of LTCCD between poverty and EEQ.   

<table><tr><td>Years</td><td>Moran&#x27;s I</td><td>Years</td><td>Moran&#x27;s I</td></tr><tr><td>2012</td><td>0.848</td><td>2018</td><td>0.830</td></tr><tr><td>2013</td><td>0.819</td><td>2019</td><td>0.849</td></tr><tr><td>2014</td><td>0.866</td><td>2020</td><td>0.853</td></tr><tr><td>2015</td><td>0.807</td><td>2021</td><td>0.854</td></tr><tr><td>2016</td><td>0.815</td><td>2022</td><td>0.794</td></tr><tr><td>2017</td><td>0.850</td><td>2023</td><td>0.786</td></tr></table>

et al., 2024), which would improve greenness and wetness, further enhancing EEQ. Fig. 6b shows that the percentages of RSEI at the excellent and good levels were gradually increased in the YGP, while that of RSEI at the poor and fair levels were decreased from 2012 to 2023. Furthermore, RSEI in the most regions presented a general increased tendency in the YGP (Theil Sen’s slope values $> 0$ ), and the maximum growth rate of $0 . 3 6 5 6 \ \mathrm { y e a r } ^ { - 1 }$ . Conversely, the RSEI values was decreased in the southwestern and mid-eastern regions of YGP (e.g. MengLa, Jinghong, Gengma, Xinping, Leishan, Kaili, Majiang, Guiding, Wudang, and Huaxi counties), with the maximum decline rate of − 0.3222 year− 1 . Additionally, the RSEI dynamic trends in the in the YGP were mainly included the insignificant increase and insignificant

decrease types. This revealed that the change of EEQ in the Yunnan and Guizhou plateau remained relatively stable.

# 4.3. Local and tele-coupling coordination degree between poverty and EEQ

# 4.3.1. Result analysis of LTCCD between poverty and EEQ in the YGP

The changes of LTCCD between poverty and EEQ for each county in the YGP from 2012 to 2023 are presented in Fig. 7. The LTCCD between poverty and EEQ (measured by standardized GCPI and RSEI) exhibited a slightly upward trend for most counties of the YGP. The values of LTCCD between poverty and EEQ from 2012 to 2023 ranged from 0.592 to 0.829, which indicates a high level of coordination development between poverty alleviation and EEQ improvement in the YGP. It is necessary to note that the LTCCD between poverty and EEQ in the Deqin, Dongchuan, and Yuanmou counties was less than 0.66, which resulted from the region with high poverty and inferior ecological quality (Fig. 8). Furthermore, the spatial distribution pattern of the LTCCD between poverty and EEQ revealed that there were four levels of coupling coordination development in the YGP, including barely coordinated development (0.5–0.6), slightly coordinated development (0.6–0.7), well-coordinated development (0.7–0.8), and superiorly coordinated development (0.8–0.9), without not unbalanced degeneration

![](images/8272374d63d2083182c2fd92943a81f6afd252cbc699ae3ef7332ffaa2e1ca9e.jpg)

![](images/dd68defa564091576e2b348f5ab5c0db44b7938fd7302d8f150986019a82724a.jpg)

![](images/37d2f58a9a9242f0b6c4e2dd07d14de4d7e1bbf65ae9bfacdcc71577ac410b58.jpg)

![](images/da1b0d794c7f62677eae968a97cd7885c3459be435a6313fd8b8b530ef582ef4.jpg)

![](images/1fa6771d1f5d8d53d2580f9cace09719118fb071dd1cc3a846f2562b680f9981.jpg)

![](images/189707425c7cf03a8205770c6d92b2ad2259eeca418c00940ea08df800954b92.jpg)

![](images/07ef2234b670092e5960a159bef0be75d3e627575b5c5d1202d42943f591ccf6.jpg)

![](images/f0b473b6956563120af33a93708fe8788a7033dd0ebd19e59e74ae00ee431d8b.jpg)

![](images/7191622dbb365890ddc377cfb598d97dabbe7c3c44dfeb367ce4e946673dec93.jpg)

![](images/d1210437a59df48887897cd32c9a4858a9c0e30bd615fb4d8b4cf575c21f21ca.jpg)

![](images/47aae628a092aff490f1f26e388ee991cd20a7e9c2b4dde1da45fcf6b8fc370e.jpg)

![](images/3f77e00e587f6cc0e07f788586d3e7df4ddcf80782094d5bca9395c83c8ebd45.jpg)

![](images/23d362f4baeb3992f531526c64eae8080907d416a71300828c774949921f0429.jpg)  
Not-significant

![](images/5690e5df80e389618b258f9170b6b8abd3db93f7ac84f3d1eb6c644275878217.jpg)  
High-High

![](images/61930659ef4ebe166ba81d2ce8559fe5e66a851cdfdd29a6d1c0853026ef58cf.jpg)  
High-Low

![](images/22a7166a6d9202c378c2221481c1b4c4685728b2b1e13d5a6e8e4d9405197f5b.jpg)  
Low-High

![](images/46028b258b64a79ff9ae84c8a0dd004a6bdcb0b62e98f667342f909a61e66dca.jpg)  
Low-Low   
Fig. 9. The LISA cluster maps of LTCCD in the YGP.

![](images/60ca262c45f3b59b06937a84f971c39262a51eeb37569239cc6a978fc1ec4d4d.jpg)

![](images/b00d57b14aac408f34870ab55623a703a93bf2f3823933bc0990d2ffb22532d7.jpg)  
Fig. 10. The correlations between GCPI and poverty factors.

<table><tr><td>Indices</td><td>GCPI and Slope</td><td>GCPI and POI cost distance</td><td>GCPI and HSI</td><td>GCPI and POI density</td></tr><tr><td>Pearson&#x27;s r</td><td>0.96</td><td>0.66</td><td>-0.48</td><td>-0.34</td></tr></table>

counties. Among the barely coordinated development and slightly coordinated development between poverty and EEQ were widely observed in the northwestern region, while the well-coordinated development and superiorly coordinated development between them were located in the southwestern and eastern regions (Fig. 8c1-3). Besides, the LTCCD between poverty and EEQ for most counties increased from barely coordinated development and slightly coordinated development in 2012 to well-coordinated development and superiorly coordinated development in 2023. This finding demonstrated that the YGP has achieved a shift from barely coordinated to well-coordinated development in terms of poverty and EEQ across the majority of its counties.

# 4.3.2. Spatial auto-correlation analysis of LTCCD

To investigate the spatial interdependence of the LTCCD between poverty and EEQ at the county-level, this work utilized Moran’s I and LISA models to examine the spatial aggregation features of cities. Table 4 illustrates the Moran’s I values of LTCCD between poverty and EEQ in the YGP from 2012 to 2023. The values of the Moran’s I index ranged from 0.786 to 0.866, exhibiting a fluctuating yet overall decreasing trend. This result suggested that there was strong spatial autocorrelation and aggregation of LTCCD between poverty and EEQ in the YGP, but the spatial heterogeneity of LTCCD between poverty and EEQ decreased over the study period. From Fig. 9, the High-High clusters of LTCCD were concentrated in the eastern and southwestern counties of YGP, whereas Low-Low LTCCD clusters were mainly observed in the northwestern and central counties. Not-significant cluster regions had the highest and most extensive distribution, indicating that LTCCD in these counties lacked spatial dependence. There was only one or two county towns distributed the High-Low and Low-High clusters in 2015, 2017, 2022, and 2023, which revealed that LTCCD between poverty and EEQ in the YGP had low spatial heterogeneity and high aggregation.

# 5. Discussion

# 5.1. GCPI offers a reliable evaluation of poverty in the YGP

The GCPI model integrated slope, HIS, PD, and PCD factors offers a comprehensive assessment of poverty from a geographical perspective. To quantify the association among GCPI and these poverty factors, the Pearson’s correlation analysis method and 300,000 random points were employed to calculate the correlation coefficient (Pearson’s r) between GCPI and slope, HIS, PD, and PCD in the YGP. As shown Fig. 10, the Pearson’s r between GCPI and slope, HIS, PD, and PCD were 0.96, − 0.48, − 0.34, and 0.66, respectively. This suggested that the slope was the most important driver for poverty in the YGP. The prior studies also observed that high slope directly constrains arable land availability and road construction, reducing agricultural productivity and market access—key drivers of persistent poverty in mountainous areas (Yin et al., 2020). Furthermore, the GCPI values increased with the growth of slope and PCD values, while it decreased as HIS and PD values declined. This result indicated that slope and PCD were positively related with poverty, whereas HIS, and PD exerted a negative influence on poverty, which is consistent with realistic conditions and findings reported in previous researches (Yin et al., 2020; Yu et al., 2015).

To further assess the reliability of poverty identification using GCPI model in the YGP, at the county-level scale, the data of per capita GDP and state poverty county in three key phases of poverty alleviation were utilized for comparison with GCPI, including the proposal of state poverty counties (2014), the mid-stage in poverty alleviation (2018), and the comprehensive achievement of poverty alleviation (2022) (Huang, 2021). As presented in Fig. 11a and Fig. 11b, the high CPI (0.6–1) and relatively high average GCPI (0.4–1) values were mainly distributed in some poverty-stricken and deeply impoverished counties, but were less observed in non-poor counties in 2014 and 2018. Additionally, low values of per capita GDP were concentrated in some poverty-stricken and deeply impoverished counties with low GCPI values, and the distribution of high values of per capita GDP was

![](images/a850615c6646da80762701e2fb3afc3bc81ac258d8de686667dc0dffad33c522.jpg)  
Fig. 11. The comparison of GCPI, per capita GDP, and poverty-stricken counties for the YGP.

opposite. These results indicated that GCPI had a relatively high accuracy on poverty identification in the YGP (Fig. 11a–c). Moreover, the GCPI and per capita GDP both reflected that the number of povertystricken counties had a decreasing trend in the YGP from 2014 to 2022. This is because during the study period, the Chinese government implemented poverty alleviation policies (Ran et al., 2022a), including targeted poverty alleviation (Li and Zhou, 2025), employment assistance (Lin et al., 2021), poverty alleviation and relocation (Ran et al., 2022a), etc. Therefore, these findings revealed that the GCPI model was capable of identifying and assessing poverty in the YGP with a high reliability. It was notable that all counties reportedly achieved complete poverty alleviation in 2022 based on per capita GDP statistics and the designation of state poverty counties (Huang, 2021), but the GCPI still identified poverty in some counties. This is because the data on poverty county and per capita GDP focused on the basic living needs and economic income of residents, while GCPI reflects more dimensions of poverty factors (e.g. economic income, development potential, infrastructure, environmental quality, etc.). Therefore, these results implied that counties with high GCPI values after 2022 may face a relatively high risk of returning to poverty. Due to the fact that these counties with low population distribution density, perilous terrain and scarce infrastructure, which is industrial vulnerability-induced risk of poverty relapse. In response to this risk, the local authorities have carried out various poverty reduction strategies for industry in the YGP, such as Big Data Poverty Alleviation, Macadamia, Tobacco, Tea, and Apple industries (Li, 2021; Wu, 2023).

Besides, the Google Earth images of six cases were further collected to qualitatively validate the applicability of poverty identification by

GCPI in the YGP. Fig. 12 shows the results of the qualitative validation of poverty identification by the GCPI in 2023. These cases with high and higher levels of GCPI were observed in the mountainous and hilly regions characterized by high altitude, limited accessibility, extensive snow cover, and scarce infrastructure (Fig. 12 Case1-Case3). Conversely, cases with lower and low levels of GCPI were found in urban areas with flat terrain, dense buildings, abundant water resources, and convenient transportation (Fig. 12 Case4-Case6). These results have also been discovered in prior research (Shi et al., 2020; Wang et al., 2023), which indicated that GCPI provided a reliable evaluation of poverty in the YGP. Commonly, the superior geographical conditions can facilitate the improvement of the socio-economic system (Li and Zhou, 2025; Putri et al., 2022). However, previous studies have found that rugged mountainous terrain, transportation bottlenecks, acute arable land scarcity, recurrent natural hazards, and severe Karst rocky desertification in Yunnan and Guizhou provinces contribute to persistent poverty in the YGP (Feng et al., 2024; Lu et al., 2019; Wu et al., 2023).

# 5.2. Recommendations for the sustainable socioeconomic and ecoenvironmental development

Global economic integration and technological innovation have facilitated the cross-regional interaction of population, information, and energy, accelerating the economy, society, and the construction of longdistance interconnection networks between ecosystems (Xing et al., 2019). Therefore, the flow elements generate profound effects on local poverty reduction and economic development, which subsequently

![](images/9c66d918d6a8dbd45aa054f5ebd9327281a4653a1387b87eca5ab98e55e0ade9.jpg)  
Fig. 12. Qualitative validation of GCPI based on Google Earth images in the YGP in 2023.

influence economic performance and the stress dynamics within ecosystem interactions. Thus, the tele-coupling coordination approach was proposed to quantify the interaction between the socio-economic of distant human communities and ecological systems (Tang et al., 2021; Yan, 2023).

This study calculated the variation coefficient of CCD and LTCCD between poverty and EEQ to assess the dispersion between the two datasets. From Fig. 13, the variation coefficients of local coupling coordination degree were greater than that of local and tele-coupling coordination degree in the YGP from 2012 to 2023, indicating that the LTCCD dataset had a more concentrated distribution. This result indirectly reflected that the economic and ecological discrepancy between counties in the YGP decreased in the context of telecoupling, and the poverty and EEQ within each county were more closely related, which was similar to the results of previous studies (An et al., 2023; Li et al., 2023a; Tang et al., 2021). Additionally, this study found that the poverty in the YGP has been effectively alleviated from 2012 to 2023 (Fig. 4), the ecological quality had an improved trend (Fig. 6), and the LTCCD between poverty and EEQ exhibited a high coupling coordination development (Fig. 7 and Fig. 8). Compared to Lüliang and Qinba regions of

China, the YGP had a relatively higher coupling coordination degree between poverty and EEQ in 2014 (Cao et al., 2015; Li and Wang, 2014). In these studies, similar results have been found that the economically impoverished areas exhibit a poor ecological environment, with a lowlevel coupling coordination degree between the economy and the environment. At the same time, Kartiasih et al. (Kartiasih and Pribadi, 2020; Sharma et al., 2021) also observed that there is a strong correlation between poverty and the environment in Indonesia and India, poverty has a negative influence on the environmental quality.

Based on the study of poverty, EEQ, and the LTCCD between them, several recommendations were proposed to promote the coupling coordination development of the economy and ecology in the YGP. First, a “tailored to local conditions” strategy should be implemented to prevent poverty reoccurrence. For instance, in harsh environments such as highaltitudes, perennially snow-covered, and karst landform areas, measures such as poverty alleviation relocation (Feng et al., 2024), steep slope ecological improvement (Wang and Tao, 2016), and desertification control (Wen et al., 2024) should be adopted to reduce the risk of poverty reoccurrence. Given the impact of PCD and PD on the GCPI, infrastructure of certain county-level cities should be further enhanced,

![](images/329395eeeb652441ac40a71100bb796e9c72e6159c964306be0baa4723e4376e.jpg)  
Fig. 13. The variation Coefficient of CCD and LTCCD of poverty and EEQ.

as suggested by Yin et al. (2020). Second, the EEQ at the poor and fair levels were primarily located in the central urban area of each county (Figs. 5 and 6), so the area of urban green spaces (e.g., parks, forests, wetlands, and grasslands) and greenness land (e.g., green road, roof garden, etc.) should be increased to improve the EEQ of urban areas (Min et al., 2022; Tian et al., 2014). Finally, in the counties with the barely and slightly coordinated development levels between poverty and EEQ (e.g., Deqing, Yuanmou, Dongchuan, etc.), it is critical to implement strict land-use control based on ecological functional zoning. This can be operationalized by defining and enforcing ecological protection redlines, which would restrict incompatible industrial activities and promote comprehensive restoration projects (Xiao et al., 2021). Besides, for the counties with superiorly coordinated development levels regarding poverty and EEQ in the YGP, the focus should shift to enhancing the green economy through ecotourism and organic agriculture, and deploying innovative technologies like remote sensing for real-time monitoring of poverty and environmental conditions (Chen et al., 2021).

# 5.3. Constraints and Perspectives

The study developed the GCPI and RSEI to accurately and effectively assess poverty and EEQ in the YGP from 2012 to 2023, and calculated the coupling coordination degree between poverty and EEQ based on the LTCCD model. However, there are several limitations that will be further studied in future work. First, poverty and EEQ are related to the interaction of multiple factors, including economy, society, politics, environment, etc. (Huang, 2021; Lin et al., 2021). Due to a limited number of data sources, the poverty identification based on GCPI ignores social and political factors, while RSEI construction only took into account natural factors, which makes GCPI and RSEI difficult to reflect all the drivers of poverty and EEQ. Thus, more diverse datasets should be utilized to quantify regional poverty and EEQ in future studies. Second, the spatial resolution was not precise enough. This work mapped GCPI and RSEI using multiple datasets at a spatial resolution of $5 0 0 \mathrm { m }$ , but the YGP exhibits the most typical and extensive karst landforms, with serious stone desertification and landscape fragmentation, which may lead to the relationship between micro ecology and poverty being ignored (Pu et al., 2024; Zhang et al., 2023). In the future, multiple remote sensing datasets with finer spatial resolution will be employed to obtain accurate results. Third, the accuracy of GCPI was verified only using per capita GDP and poverty county designations. The external validation data (e.g., household surveys, poverty registrations, independent validations, etc.) will be used to verify the poverty

identification models in future research on poverty identification models. Finally, the LTCCD model improves upon the CCD model by considering only distance weights to introduce the concept of telecoupling. However, the influence of cross-border factors such as crossborder trade, population migration, and transport linkages, energy cycle, and ecological footprint on the interaction between poverty and EEQ is complex, which cannot be simply described by the distance decay in the LTCCD model (An et al., 2023; Tang et al., 2021). For example, data from China’s sixth (2010) and seventh (2010) national population census show that the number of people born in Yunnan Province but residing in Guizhou Province increased from 6,549 to 11,504, while those born in Guizhou and migrating to Yunnan increased from 19,064 to 23,387. Such interprovincial migration has reshaped the economic structure and land cultivated patterns of in certain households, forming a unique “tele-coupling” model (Luo and Yi, 2023). Therefore, future research on near- and long-range dynamic coupling among social, economic, and ecological systems should also take these factors into account.

# 6. Conclusion

This study developed a novel model of GCPI to map poverty in the YGP from 2012 to 2023. On the one hand, the coupling coordination degree between poverty and EEQ were measured using the LTCCD model. This model took into account the impact of the distance on telecoupling by assigning corresponding weights based on the IDW method. On the other hand, the spatial patterns and temporal changing trends of poverty, EEQ, and LTCCD between them was explored. The results of the work indicated that GCPI exhibited an obviously decreasing trend (with a decline rate of $- 0 . 0 0 1 5 \ \mathrm { y e a r } ^ { - 1 } ;$ ), while RSEI presented a continually increasing trend (with an increase rate of 0.0035 year− 1 ) in the YGP from 2012 to 2023, although both trends were insignificant. These findings reveal that poverty has been effectively alleviated and EEQ has improved over the study period. However, counties with high GCPI values (e.g., Deqin) remain at risk for poverty recurrence due to environmental constraints (Section 4.1), necessitating targeted strategies such as ecological migration and ecological governance of steep slopes (Section 5.2). Furthermore, the LTCCD values between poverty and EEQ ranged from 0.592 to 0.829, indicating a highlevel coupling coordinated development on poverty alleviation and EEQ improvement in the YGP. At the same time, Moran’s I of the LTCCD (ranged from 0.786 to 0.866) also presented a high concentration and low spatial heterogeneity in the YGP. It is worth noting that the LTCCD between poverty and EEQ in the Deqing, Yuanmou, Dongchuan, and some counties were at the slightly coordinated development level. These findings can provided decision-making suggestions for ecological restoration planning, poverty reoccurrence prevention, and mitigation management in ecologically sensitive and economically underdeveloped plateau regions.

# Appendix A. . Supplementary data

Supplementary material related to this article can be found, in the online version, at DOI:

# Appendix B. Supplementary data

Supplementary data to this article can be found online at https://doi. org/10.1016/j.ecolind.2025.114436.

# I have shared link to my data/codes at the attach file step

