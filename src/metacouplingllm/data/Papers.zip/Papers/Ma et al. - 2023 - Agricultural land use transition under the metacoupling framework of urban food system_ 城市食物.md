# Agricultural land use transition under the metacoupling framework of urban food system_ åŸŽå¸‚é£Ÿç‰©

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:57:04.347872+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Ma et al. - 2023 - Agricultural land use transition under the metacoupling framework of urban food system_ åŸŽå¸‚é£Ÿç‰©.pdf
- Year: unknown
- DOI: 10.11821/dlxb202312009
- OA status: unknown
- License: none recorded
- Category: Journal Articles\Conceptual\Metacoupling
- Closed-access reason: no license info, oa_status=unknown

## Copyright-Safe Summary
This conceptual paper develops a theoretical framework for understanding agricultural land use transition using the metacoupling perspective, with a focus on urban food systems in China but with broader relevance. It is explicitly about metacoupling/telecoupling.

The authors argue that conventional agricultural land use research has mostly treated land as place-fixed and has paid little attention to demand-driven, long-distance linkages and teleconnections. They propose integrating Liu et al.s metacoupling framework with food system thinking to better capture cross-scale human-nature interactions among cities, peri-urban areas, and rural hinterlands.

The core idea is to use the urban food system as the key linkage that connects rural production areas with urban consumption and that merges flow space (flows of products, people, capital, information, technology) with location-based land use. Agricultural land use transition is interpreted as the outcome of four interacting forces: intrinsic resource conditions, external inputs of production factors, market allocation processes, and government regulation. These operate through three main pathways: feedback of urban production factors to rural areas, urban food shortages that stimulate external sourcing, and demand-driven shifts in diets and preferences (including leisure and landscape functions).

Methodologically, the paper is conceptual and synthetic, drawing on the metacoupling literature, Chinese land use transition research, and food system studies. It introduces a geospatial network perspective that embeds specific places within networks of infrastructure, supply chains, and factor flows. The authors distinguish five key effects of factor flows on land use: trigger, echo (return flows of capital, skills, technology), reconfiguration, spillover, and disruption.

The paper outlines a future research agenda: mechanisms by which metacoupled food systems drive land use change, spatial gradients and evolution of agricultural land patterns within an urban food shed, how farmers and other actors respond to changing demand, and how to regulate land use transitions to balance food security, rural revitalization, and environmental sustainability. It also notes significant data challenges for empirically tracing metacoupled food and factor flows.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling focus; also covers intracoupling within cities and pericoupling with surrounding food-sheds.

### Intracoupling
#### Systems
- Urban food system within a single city
- Rural agricultural land system around one city
#### Flows
- Local labor shifts between farm and nonfarm jobs
- Within-city food distribution and retail networks
- Local capital and technology reinvested in nearby farms
#### Agents
- Urban and rural households near the city
- Local governments and planning agencies
- Nearby farmers cooperatives and agribusinesses
#### Causes
- Urbanization and rising local incomes
- Local dietary upgrading and diversified food demand
- City expansion reducing intra-urban farmland
#### Effects
- Shifts from grain to higher value crops near cities
- Intensification and mechanization of nearby farmland
- Coexistence of land abandonment and land consolidation

### Pericoupling
#### Systems
- Core city and its suburban fringe
- City and neighboring metropolitan hinterlands
#### Flows
- Regional food supply from surrounding counties
- Daily labor commuting and seasonal migration
- Regionally circulating agricultural inputs and services
#### Agents
- Suburban farmers and family farms
- Regional wholesalers and logistics firms
- Provincial regulators and extension agencies
#### Causes
- City food self-sufficiency decline from built-up expansion
- Market incentives for specialized horticulture belts
- Infrastructure improving regional connectivity
#### Effects
- Spatial gradients of land rent and crop choice
- Regional differentiation of agricultural functions
- Water stress in nearby supply areas from high-water crops

### Telecoupling
#### Systems
- Large cities and distant rural producing regions
- Domestic producing regions and foreign import sources
- Less developed exporting areas and developed consumers
#### Flows
- Long-distance traded food and feed commodities
- Remittances, investment, knowledge and technology backflows
- Virtual land and biodiversity footprints embodied in trade
#### Agents
- Migrant workers and returning entrepreneurs
- International and national agrifood corporations
- Central governments designing food and land policies
#### Causes
- Globalization of food supply chains
- Urban demand growth and dietary transition
- Comparative advantage and price differentials in crops
#### Effects
- Land-use change in distant supplying regions
- Externalized environmental and biodiversity pressures
- Inequitable distribution of environmental costs and benefits

### Cross-Coupling Interactions
- Metacoupling integrates internal, nearby, and distant land-food linkages via flows, agents, causes, effects.
- Urbanization-driven labor outflow triggers local land reconfiguration and distant supply dependence simultaneously.
- Food-system networks transmit shocks and policies across intra-, peri-, and telecoupled regions.

### Research Gaps or Limitations
- Lack of systematic teleconnection theory in agricultural land transition studies.
- Data scarcity and commercial secrecy for detailed food-flow statistics, especially from smallholders.
- Limited attention to non-cropland farm types and biodiversity-focused land transition research.

### Search Keywords
- urban food system metacoupling agricultural land transition
- factor flows telecoupling land-use teleconnection China
- food system near-far coupling geospatial network

### Extraction Confidence
high
