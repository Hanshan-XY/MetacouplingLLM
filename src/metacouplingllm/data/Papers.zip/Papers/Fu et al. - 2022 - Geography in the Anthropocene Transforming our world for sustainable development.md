# Geography in the Anthropocene Transforming our world for sustainable development

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:45:18.687353+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Fu et al. - 2022 - Geography in the Anthropocene Transforming our world for sustainable development.pdf
- Year: unknown
- DOI: 10.1016/j.geosus.2021.12.004
- OA status: gold
- License: cc-by-nc-nd
- Category: Journal Articles\Commentary\Metacoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This editorial discusses how geography as a discipline can help society confront Anthropocene challenges and move toward sustainable development. It is global in scope, synthesizing ideas presented at the 2021 International Geography and Sustainability Workshop, with contributions from scholars working on multiple continents. Rather than reporting original empirical results, the paper reviews disciplinary evolution, emerging frameworks, and priority research directions.

The authors describe a shift in geographic research from descriptive mapping, to quantitative analysis of spatial patterns and processes, to geospatial technologies, and now to artificial-intelligence-enhanced simulation and prediction of complex human-environment systems. They argue that geography is well positioned to address many Sustainable Development Goals (SDGs), because it bridges natural and social sciences and focuses on coupled human-nature systems.

Several integrative frameworks are highlighted. Landscape sustainability science emphasizes place-based analysis of ecosystem services and human well-being within heterogeneous landscapes, including governance and local knowledge. The metacoupling framework explicitly addresses interactions within, between, and among distant coupled systems, capturing intracoupling, pericoupling, and telecoupling, and uncovering spillovers and feedbacks across scales. A Pattern-Process-Service-Sustainability (PPSS) framework links land and landscape patterns to ecological processes, ecosystem services, and sustainability outcomes, stressing multi-scale analysis, modeling, and dynamic prediction.

The editorial applies these ideas to key domains where geography can advance sustainability: sustainable agriculture and bioenergy, disaster risk monitoring and resilience, climate change mitigation through land and ecosystem management, and integrated strategies for achieving SDGs. It also outlines future research priorities, including metacoupling for biodiversity, resource use, climate adaptation, urbanization, and cultural conservation, as well as work on safe and just operating spaces, classification-coordination-collaboration approaches, and geographical education.

Telecoupling and metacoupling are central themes, treated as core conceptual tools for understanding cross-scale human-environment interactions and guiding more coherent sustainability policies.

## Structured Metacoupling Extraction

### Coupling Classification
- Conceptual metacoupling focus linking local, nearby, and distant sustainability dynamics.

### Intracoupling
#### Systems
- Local coupled human nature systems within landscapes or regions
- National human environment systems managing resources and risks
#### Flows
- Local resource extraction and land use changes
- Information, governance, and education within a country
#### Agents
- Local communities and farmers
- National governments, planners, and scientists
#### Causes
- Intensive agriculture and land degradation drivers
- Domestic policies targeting SDGs and ecological civilization
#### Effects
- Changes in ecosystem services and human wellbeing locally
- National decoupling of economic growth and environmental pressure

### Pericoupling
#### Systems
- Neighboring regions sharing watersheds or coastlines
- Bordering countries linked by shared ecosystems
#### Flows
- Transboundary water, pollutants, and disasters across regions
- Regional trade affecting land use and emissions
#### Agents
- Regional organizations and river basin authorities
- Provincial and cross border governments
#### Causes
- Upstream land use and groundwater overuse
- Shared regional development and infrastructure projects
#### Effects
- Downstream flooding, water quality, and ecosystem decline
- Regional risk cascades and SDG trade offs

### Telecoupling
#### Systems
- Distant countries connected by global trade and climate
- Global earth system and distributed human societies
#### Flows
- International trade in food, bioenergy, and resources
- Long distance greenhouse gas emissions and climate impacts
#### Agents
- Multinational corporations and global investors
- International organizations and environmental agreements
#### Causes
- Global demand for food, energy, and materials
- International climate, biodiversity, and SDG policies
#### Effects
- Remote biodiversity loss and land use change
- Uneven climate impacts and cross border disasters

### Cross-Coupling Interactions
- Local sustainability can shift burdens to distant systems through trade
- Spillovers and feedbacks link intracoupling, pericoupling, and telecoupling scales

### Research Gaps or Limitations
- Limited empirical metacoupling case studies across multiple scales
- Insufficient understanding of safe and just operating spaces geographically

### Search Keywords
- metacoupling framework geography sustainability Anthropocene
- intracoupling pericoupling telecoupling SDGs landscape sustainability

### Extraction Confidence
high
