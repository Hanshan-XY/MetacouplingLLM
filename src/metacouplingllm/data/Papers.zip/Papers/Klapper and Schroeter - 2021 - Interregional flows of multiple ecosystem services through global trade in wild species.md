# Interregional flows of multiple ecosystem services through global trade in wild species

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:49:24.440906+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Klapper and Schroeter - 2021 - Interregional flows of multiple ecosystem services through global trade in wild species.pdf
- Year: unknown
- DOI: 10.1016/j.ecoser.2021.101316
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This article analyzes how multiple ecosystem services move between world regions through the legal trade in wild CITES-listed species, framing these movements as interregional ecosystem service flows and telecouplings.

The study is global in scope, focusing on terrestrial wild species recorded in the CITES Trade Database from 2014-2018. It uses detailed trade records (exporter-importer pairs, purpose of trade, wild source only) and range maps for selected taxonomic groups (amphibians, birds, mammals, reptiles, and many plants and insects). Species are interpreted as service-providing units. Trade purpose codes are mapped to six ecosystem service classes: decoration and pets, science, medicine, education, entertainment, and conservation. Species range data from IUCN, BirdLife, and GIFT are overlaid on a 100 x 100 km grid and aggregated by five IPBES-style world regions to identify sending regions; importing countries define receiving regions. Hotspots are defined as the upper 10 percent of grid cells in terms of exported species richness, and then compared with hotspots of threatened species and with protected-area coverage.

The analysis shows that most traded wild species support scientific uses, with smaller shares for ornamental, educational, entertainment, conservation, and medicinal purposes. Exports come mainly from South- and Mesoamerica and Africa, while imports concentrate in North America and Europe and Central Asia, reflecting a strong telecoupling between a biodiverse global South and a consuming global North. About one eighth of traded species are already threatened and most of the remainder could become threatened without regulation. Hotspots of exported species lie largely in tropical South America, Mesoamerica, and parts of Africa; they overlap strongly with vulnerability hotspots but are only partly protected, though more protected than sending regions overall.

The paper is explicitly about telecoupling and interregional ecosystem service flows. It introduces a method that connects trade records, ecosystem service categories, and spatial species ranges, enabling finer scale mapping of where globally traded, service-providing species originate and how distant demands may shape conservation priorities.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via global wildlife trade linking biodiversity hotspots to distant consumer regions

### Intracoupling
#### Systems
- Not identified.
#### Flows
- Not identified.
#### Agents
- Not identified.
#### Causes
- Not identified.
#### Effects
- Not identified.

### Pericoupling
#### Systems
- Not identified.
#### Flows
- Not identified.
#### Agents
- Not identified.
#### Causes
- Not identified.
#### Effects
- Not identified.

### Telecoupling
#### Systems
- Sending systems: biodiverse regions in South and Mesoamerica and Africa
- Receiving systems: consumer countries in North America, Europe, parts of Asia
- Intermediate systems: global trade and CITES regulatory infrastructure
#### Flows
- Wild terrestrial species flows as traded individuals, parts and products
- Interregional ecosystem service flows: science, pets, medicine, education, entertainment, conservation
- Information and regulatory flows through CITES permits and reporting
#### Agents
- Exporting country authorities and local harvesters of wild species
- Importing country customs, research institutions, zoos, traders, consumers
- CITES Secretariat, IUCN, IPBES and conservation organizations
#### Causes
- Global demand for pets, luxury wildlife products, research and traditional medicine
- Economic dependence of biodiversity rich global South on export revenues
- International conservation policy regulating endangered species trade
#### Effects
- Concentration of biodiversity exploitation pressures in unprotected hotspots
- Mismatch where ecosystem service benefits accrue far from ecological costs
- Partial protection of export hotspots, with gaps in Africa and South America

### Cross-Coupling Interactions
- Telecoupled trade alters local protection needs in sending regions, influencing conservation planning
- Regulation by CITES modifies trade flows, affecting both economic benefits and biodiversity risks
- Ecosystem service burdens shifted from Northern consumers to Southern provider regions

### Research Gaps or Limitations
- Marine species, illegal trade, and intra regional flows largely excluded from analysis
- Only subset of CITES records used due to missing distribution or purpose information
- Quantities of individuals not standardized, limiting flow intensity estimation

### Search Keywords
- telecoupling wildlife trade CITES ecosystem service flows
- sending receiving regions biodiversity hotspots protection gaps
- service providing units endangered species global South North trade

### Extraction Confidence
high
