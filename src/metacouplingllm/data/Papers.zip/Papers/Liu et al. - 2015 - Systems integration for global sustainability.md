# Systems integration for global sustainability

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:54:11.059251+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Liu et al. - 2015 - Systems integration for global sustainability.pdf
- Year: unknown
- DOI: 10.1126/science.1258832
- OA status: green
- License: none recorded
- Category: Journal Articles\Review\Telecoupling
- Closed-access reason: green OA without permissive license (none)

## Copyright-Safe Summary
This review examines how to better integrate diverse human and natural systems to advance global sustainability. It is global in scope and focuses on cross-scale linkages among environmental, economic, and social processes, including distant connections among countries and regions.

The authors argue that many major challenges - air pollution, biodiversity loss, climate change, water scarcity, food and energy security, disease, and species invasions - are tightly interlinked across organizations, space, and time, yet usually analyzed sector by sector. They synthesize several influential integrative frameworks: ecosystem services, environmental footprints, planetary boundaries, human-nature nexus approaches (such as food-energy-water and air-climate-energy nexuses), and the telecoupling framework for long-distance interactions.

Using examples such as biofuel expansion and virtual water trade, the paper shows how systems integration reveals hidden consequences and feedbacks. For biofuels, integrated models uncover indirect land-use change, carbon leakage, biodiversity impacts, and interactions with water constraints and food prices that simple climate or energy assessments miss. For virtual water, analyzing trade networks highlights how water-rich regions effectively support water-poor countries, while also shifting ecological burdens, governance risks, and deforestation pressures across continents.

Telecoupling and metacoupling are central themes. The review formalizes telecoupling as flows of material, energy, organisms, information, and capital among sending, receiving, and spillover systems, mediated by specific agents and causes. It emphasizes feedbacks, spillover effects, and multi-scale dynamics, and points to applications in land use, payments for ecosystem services, species invasions, trade, and conservation.

The authors outline future priorities: incorporating more human and biophysical components simultaneously, explicitly identifying and quantifying spillover systems, modeling feedbacks and cross-scale interactions, developing new tools (e.g., agent-based and big-data approaches) for complex networks, and embedding these insights in policy and management. The paper is explicitly about telecoupling and broader metacoupling, proposing systems integration as a foundation for governing an increasingly interconnected world.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong focus on global telecoupling with supporting intra and peri linkages across scales.

### Intracoupling
#### Systems
- Protected areas like Wolong Reserve as coupled human nature systems.
- National energy food water systems within single countries.
- Urban regions managing local air climate and resource issues.
#### Flows
- Local land use change and deforestation within reserves.
- Domestic water withdrawals and groundwater pumping for irrigation.
- In country trade of grain and virtual water between regions.
#### Agents
- Local households farmers and landowners.
- Municipal and national government agencies.
- Protected area managers and conservation NGOs.
#### Causes
- Household fuelwood collection and forest harvesting near homes.
- Agricultural intensification and fertilizer overuse.
- Short term economic growth and energy demand policies.
#### Effects
- Habitat degradation and biodiversity loss in protected areas.
- Eutrophication of rivers and coastal zones from farm runoff.
- Local improvements in jobs with hidden long term emissions.

### Pericoupling
#### Systems
- Neighboring agricultural landscapes and downstream coastal ecosystems.
- Upstream watersheds and downstream cities within same country.
- Adjacent marine areas linked through coastal resource management.
#### Flows
- Nutrients and sediments from farms to downstream fisheries.
- Surface water flows from watersheds to urban reservoirs.
- Species spillover from marine reserves to fished areas.
#### Agents
- Regional water managers and farmers.
- Coastal zone planners and fishers.
- Provincial and basin level authorities.
#### Causes
- Conversion of upland forests to cropland or plantations.
- Implementation of payment schemes between cities and upstream farmers.
- Designation of marine or coastal protected areas.
#### Effects
- Reduced downstream water quality and coastal productivity.
- Improved city water supply but shifted rural livelihoods.
- Fish stock replenishment and changed local fishing pressure.

### Telecoupling
#### Systems
- Brazil China Caribbean and African regions linked via trade and dust.
- Australia as coal exporter and multiple importing regions worldwide.
- Water rich Americas and Australia exporting virtual water to water poor importers.
#### Flows
- Soy trade Brazil to China affecting global food markets.
- Coal exports from Australia with embodied CO2 emissions.
- Virtual water in agricultural and industrial products traded internationally.
#### Agents
- National governments energy and trade ministries.
- Farmers agribusiness traders shipping companies.
- International organizations climate and conservation initiatives.
#### Causes
- Rising global demand for food energy and raw materials.
- Biofuel mandates and climate mitigation policies in major economies.
- Globalization of markets and pursuit of economic efficiency.
#### Effects
- Deforestation and biodiversity loss in exporting regions.
- Global greenhouse gas emissions and climate impacts on distant societies.
- Water scarcity alleviation in importers but ecosystem stress in exporters.

### Cross-Coupling Interactions
- Biofuel policies create land use telecoupling plus local intracoupling impacts on ecosystems.
- Virtual water trade links telecoupled water flows with national food energy nexuses.
- Dust transport from Sahara telecouples with Caribbean health tourism and investors from distant nations.

### Research Gaps or Limitations
- Need systematic quantification of spillover systems including causes agents and flows.
- Limited integration of frameworks like ecosystem services footprints planetary boundaries and telecoupling together.
- Insufficient temporal analysis of feedbacks legacies and rare extreme events across coupled systems.

### Search Keywords
- telecoupling framework global sustainability systems integration
- biofuels indirect land use virtual water trade
- ecosystem services environmental footprints planetary boundaries nexuses

### Extraction Confidence
high
