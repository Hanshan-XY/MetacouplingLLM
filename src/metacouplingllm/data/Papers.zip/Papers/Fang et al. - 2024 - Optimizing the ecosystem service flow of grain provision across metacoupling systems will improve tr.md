# Optimizing the ecosystem service flow of grain provision across metacoupling systems will improve tr

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:43:47.864873+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Fang et al. - 2024 - Optimizing the ecosystem service flow of grain provision across metacoupling systems will improve tr.pdf
- Year: unknown
- DOI: 10.1016/j.apgeog.2024.103420
- OA status: hybrid
- License: cc-by-nc-nd
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This article examines how optimizing grain provision as an ecosystem service (ES) flow can improve transmission efficiency within and beyond a major urban agglomeration. The study focuses on the Beijing-Tianjin-Hebei (BTH) region in North China, a key grain-producing area and national transport hub that is nevertheless not fully grain self-sufficient.

Within a metacoupling framework, the authors distinguish intracoupling (flows among counties within BTH and among its three provincial units) from intercoupling (flows between BTH and other Chinese provinces). They compile grain production, population, and consumption data for all mainland provinces and for BTH counties for 2020, then derive county- and province-level supply-demand balances. Grains include major staples and indirect uses (feed, seed, other uses).

First, they simulate original grain flows using a metacoupling-based allocation that routes surplus to deficit areas under a national supply-demand constraint. Second, they apply linear programming to minimize distance-based transport costs while still meeting all grain deficits, allowing reallocation of both intra- and extra-regional flows. Third, they construct directed flow networks (before and after optimization) and a road-based transmission network, and analyze them using basic graph metrics (density, degree, betweenness centrality) to identify structural changes and core transmission nodes.

In 2020 BTH accounted for about one-tenth of national grain flow and was a net deficit region. Initially, more than half of its flow was extra-regional, including both imports from northern surplus provinces and exports from Hebei to southern deficit provinces. Optimization sharply reduced extra-regional dependence and eliminated exports, increased intra-regional flows, and cut distance costs by more than half while maintaining total provision. The optimized network became far sparser and less complex, with clearer main corridors and key transmission nodes that either concentrate surplus or sit at multimodal transport junctions.

The study is explicitly about metacoupling: it uses intracoupling and intercoupling concepts to quantify and then reconfigure ES flows, showing how coordinated within-region and cross-region grain routing can enhance food security and system resilience.

## Structured Metacoupling Extraction

### Coupling Classification
- Explicit metacoupling study of grain ecosystem service, covering intra- and inter-regional flows and optimization.

### Intracoupling
#### Systems
- Counties and cities within Beijing-Tianjin-Hebei urban agglomeration
- Provincial subsystems Beijing, Tianjin, Hebei
- Road-based grain transmission network inside BTH
#### Flows
- Grain provision flows among BTH counties before optimization
- Distance-cost-optimized grain flows among BTH counties
- Virtual and real grain transmissions along intra-BTH road network
#### Agents
- Local governments managing food security in BTH
- Farmers and grain producers within Hebei and BTH counties
- Transport and logistics operators using regional road networks
#### Causes
- Spatial mismatch between local grain supply and population grain demand
- Urbanization reducing cropland and increasing urban grain demand
- Policy emphasis on regional food self-sufficiency within BTH
#### Effects
- Intra-regional grain flow share increases after optimization
- Two main west and east intra-BTH grain linkages emerge
- Reduced network complexity and higher resilience of local food system

### Pericoupling
#### Systems
- Bordering provinces such as Inner Mongolia, Liaoning, Shandong
- Adjacent deficit and surplus cities around BTH boundary
- Cross-boundary transport corridors linking BTH and neighbors
#### Flows
- Optimized inflows from nearest surplus provinces to remaining deficit BTH cities
- Original limited exports of Hebei surplus to neighboring deficit provinces
- Short-distance cross-border grain transports aligned with road axes
#### Agents
- Provincial authorities coordinating near-border grain trade
- Regional planners of Beijing-Tianjin-Hebei integration corridors
- Transport hubs at BTH edges handling interprovincial shipments
#### Causes
- Proximity-based cost minimization in grain transport
- Deficits in northern BTH cities bordering other provinces
- Integrated development plans along Beijing-Baoding-Shijiazhuang and coastal axes
#### Effects
- Reliance on nearby provinces for marginal deficits after optimization
- Strengthened economic and infrastructural ties along border corridors
- Improved alignment between spatial planning axes and food flows

### Telecoupling
#### Systems
- Beijing-Tianjin-Hebei region as focal grain-demand hub
- Distant surplus provinces in Northeast and North China
- Distant deficit provinces mainly in southern and eastern China
#### Flows
- Pre-optimization inflows from far northeastern surplus provinces to Beijing and Tianjin
- Pre-optimization outflows of Hebei surplus grain to distant southern deficit provinces
- National-scale grain trade network approximated via surplus-deficit allocation
#### Agents
- National government pursuing overall food security and self-sufficiency targets
- Interprovincial grain traders and transport companies
- Statistical and planning agencies providing national grain data
#### Causes
- National-scale imbalance between grain production zones and consumption centers
- Policy priority to secure grain for the capital region over other areas
- Market-like allocation based on provincial surplus and deficit structure
#### Effects
- BTH involved in about one tenth of national grain flows
- Optimization reduces dependence on distant northeastern suppliers
- Telecoupled exports from Hebei cut to zero in optimized scenario

### Cross-Coupling Interactions
- Intracoupling optimization inside BTH reshapes telecoupled inflows and removes remote outflows.
- Metacoupling analysis links system-level grain balances with road-network transmission properties.
- Core transmission nodes mediate both local redistribution and access to extra-regional supplies.

### Research Gaps or Limitations
- Actual grain trade data scarce, so flows and optimization are simulations, difficult to validate.
- Linear programming neglects market dynamics, policies, prices, and other behavioral constraints.
- Road network simplified, excluding rail, waterways, multimodal routes, and temporal variability.

### Search Keywords
- metacoupling grain flow Beijing Tianjin Hebei linear programming network analysis
- ecosystem service flow food provision intra-regional extra-regional optimization
- core transmission nodes road network food security China urban agglomeration

### Extraction Confidence
high
