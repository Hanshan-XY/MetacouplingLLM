# Product level dataset on embodied human appropriation of net primary production

Nicolas Roux, Lisa Kaufmann, Sarah Matej, Thomas Kastner, Alberte Bondeau, Helmut Haberl, Karlheinz Erb

# To cite this version:

Nicolas Roux, Lisa Kaufmann, Sarah Matej, Thomas Kastner, Alberte Bondeau, et al.. Product level dataset on embodied human appropriation of net primary production. Data in Brief, 2023, 51, pp.109725. ff10.1016/j.dib.2023.109725ff. ffhal-04304639ff

HAL Id: hal-04304639

https://amu.hal.science/hal-04304639v1

Submitted on 26 Nov 2023

HAL is a multi-disciplinary open access archive for the deposit and dissemination of scientific research documents, whether they are published or not. The documents may come from teaching and research institutions in France or abroad, or from public or private research centers.

L’archive ouverte pluridisciplinaire HAL, est destinée au dépôt et à la diffusion de documents scientifiques de niveau recherche, publiés ou non, émanant des établissements d’enseignement et de recherche français ou étrangers, des laboratoires publics ou privés.

Data Article

# Product level dataset on embodied human appropriation of net primary production

![](images/3d8b4999f0e5a90e9aae67ffcfb14cb405f5a95a70668fbf52e841c99de9999c.jpg)

Nicolas Rouxa,∗ , Lisa Kaufmanna , Sarah Mateja , Thomas Kastnerb , Alberte Bondeauc , Helmut Haberla , Karlheinz Erba

a University of Natural Resources and Life Sciences, Vienna, Department of Economics and Social Sciences, Institute of Social Ecology, Schottenfeldgasse 29, 1070 Vienna, Austria   
b Senckenberg Biodiversity and Climate Research Centre, Frankfurt am Main, Germany   
c Aix Marseille Univ, Avignon Univ, CNRS, IRD, IMBE, Marseille, France

# a r t i c l e i n f o

Article history:

Received 6 October 2023

Revised 18 October 2023

Accepted 20 October 2023

Available online 29 October 2023

Dataset link: Product level dataset on embodied Human Appropriation of Net Primary Production (Original data)

Keywords:

Land use

Land-use intensity

Biomass

Trade

Agricultural products

Animal products

Food

# a b s t r a c t

This dataset includes data on the embodied human appropriation of net primary production (eHANPP) associated with products derived from agriculture and forestry. The human appropriation of net primary production (HANPP) is an indicator of changes in the yearly availability of biomass energy from photosynthesis that remains available in terrestrial ecosystems after harvest, under current land use, compared to the net primary production of the potential natural vegetation. HANPP is an indicator of land-use intensity that is relevant for biodiversity and biogeochemical cycles. The eHANPP indicator allocates HANPP to products and allows tracing trade flows from origin (the country where production takes place) to consumption (the country where products are consumed), thereby underpinning research into the telecouplings in global land use. The datasets described in this article trace eHANPP associated with the bilateral trade flows between 222 countries. It covers 161 primary

crops, 13 primary animal products and 4 primary forestry products, as well as the end uses of these products for the years 1986 to 2013.

$^ { © }$ 2023 The Authors. Published by Elsevier Inc.

This is an open access article under the CC BY license

(http://creativecommons.org/licenses/by/4.0/)

Specifications Table   

<table><tr><td>Subject</td><td>Environmental Science</td></tr><tr><td>Specific subject area</td><td>The production and consumption of agricultural and forestry commodities is putting pressure on ecosystems and biodiversity on land. These commodities are increasingly being traded internationally. The field of land use and international trade is quantifying the pressure on ecosystems and biodiversity embodied in the international trade and consumption of land-based commodities.</td></tr><tr><td>Data format</td><td>Processed data</td></tr><tr><td>Type of data</td><td>Table</td></tr><tr><td>Data collection</td><td>Production, trade and end uses of agricultural and forestry products were taken from FAOSTAT, combined with data on the potential state of ecosystems calculated using the LPJml vegetation model, and factors from previous HANPP assessments to calculate the pressure on ecosystems embodied in global supply chains of biomass products.</td></tr><tr><td>Data source location</td><td>Primary data sources (see section on Experimental design, materials and methods for more details):FAOSTAT (downloaded on July 2021, see Table 1), Vegetation model (LPJmL), relying on CRU_TS4.03 historical climatology data (Harris et al. 2020)Land use maps [1]Cultivar maps [2], FAO Gridded Livestock of the world</td></tr><tr><td>Data accessibility</td><td>Repository name: ZenodoData identification number: 10.5281/zenodo.8384359Direct URL to data: https://doi.org/10.5281/zenodo.8384359Instructions for accessing these data: .csv files can be opened with any data processing software. Version 1.0.0 of the data, available in the same link, contains the same data in .rds format, for lighter data handling, which can be opened in R, or in Python (with the “pyreadr” package).</td></tr><tr><td>Related research article</td><td>Roux, Nicolas, Lisa Kaufmann, Julia Le Noe, Sarah Matej, Perrine Laroche, Thomas Kastner, Alberte Bondeau, Helmut Haberl, and Karlheinz Erb.&quot;Embodied HANPP of Feed and Animal Products: Tracing Pressure on Ecosystems along Trilateral Livestock Supply Chains 1986–2013.&quot; Science of The Total Environment 851 (December 10, 2022): 158198.https://doi.org/10.1016/j.scitotenv.2022.158198.</td></tr></table>

# 1. Value of the Data

• The dataset on embodied Human Appropriation of Net Primary Production (eHANPP) reveals pressures on biodiversity and ecosystems, including their carbon balance, embodied in global supply chains of agricultural and forestry products.   
• The data reveal trade flows between 222 countries, at the product level for 161 primary crops, 13 primary animal products and 4 primary forestry products, as well as the end uses of these products, for the years 1986 to 2013.   
• The dataset is useful for consumption or flow-based accounts of the pressure on ecosystems, or to study effects of international trade on ecosystems and biodiversity, such as the displacement of ecological pressure to other countries, the global reallocation of agricultural production, etc.   
• These data can be interesting for researchers, NGOs, consultancies or policy makers working on global supply chains and anthropogenic pressures on ecosystems.

• The data can be used to visualize the evolution of pressure on ecosystems linked to specific supply chains, to determine which commodities and trade flows are causing most pressure on ecosystems. It can also be used to compare the pressure on ecosystems linked to different end uses as animal products, vegetal human food, or materials and energy.

• Embodied HANPP Data are also of growing interest to quantify the overshoot of nations over planetary boundaries. See [3,4]

# 2. Data Description

For semantic explanations of the HANPP and eHANPP indicators, refer to [5].

File 1 [embodied_HANPP_all_uses_no_ap_trade_cl_gl_resid_by_feed_products.csv]

Contains HANPP embodied in the bilateral trade of primary crop products (excluding the residues used as feed), roughage and residues used as feed, by end uses (direct human food, animal feed, other uses), between 1986 and 2013. The HANPP embodied in bilateral trade flows of animal feed corresponds to the total trade flow from the country producing the feed to the country producing the animal product.

File 2 [embodied_HANPP_all_uses_incl_ap_all_cl_gl_resid_by_animal_products.csv]

Contains HANPP embodied in the bilateral trade of primary crop products, roughage and residues used as feed, combined to animal products, by end uses (direct human food, animal products, other uses), between 1986 and 2013. Unlike in File 1, the HANPP embodied in bilateral trade flows of animal products corresponds to the total trade flow from the feed producing country to the country finally consuming the animal product.

File 3 [trilateral_embodied_HANPP_cl_gl_resid_avg_2011_2013.csv]

Contains HANPP embodied in the trilateral trade (trade flows between countries producing feed, countries producing animal products, and countries consuming animal products) of feed crops, roughage and residues used as feed combined to animal products. Because of the size of the data, we only display the average data over the period 2011-2013 (for other years, please contact the authors). Each row represents the HANPP embodied in one combination of feed and animal product trade between a country producing feed, a country producing the animal product, and a country consuming the animal product (for example soybeans produced in Brazil, exported to Germany to produce pig meat, which itself is exported to and consumed in Austria).

FILE_NAME4 [embodied_HANPP_forest_IRW_and_WF.csv]

Contains HANPP embodied in the bilateral trade of 4 primary forestry products, between 1997 and 2013.

# 3. Experimental Design, Materials and Methods

FAOSTAT Data were accessed using the fenixservices API on July 2021 (code from https: //github.com/martinbruckner/fabio_v1). Required FAOSTAT Data are described in Table 1. Note that the data structure and zip file names of FAOSTAT have been changed since we originally downloaded the data (e.g., production and commodity balances). The data downloadable through the FAOSTAT URLs in Table 1 do hence not exactly correspond to the original data used in this article.

Countries that changed their border between 1986 and 2013 were the USSR, Belgium-Luxembourg, Yugoslavia, Serbia-Montenegro, Czechoslovakia, Ethiopia-Eritrea, Sudan. When factors were missing either for the subsequent countries, the factor of the former country was applied to the divided countries. When indices (degree of industrialization, biome, etc.) were missing for the former aggregated country, the index from the largest of the divided countries was taken. Spatially explicit data were shared according to country areas.

Calculation steps are summarized in Fig. 1.

Table 1 FAOSTAT Data required for the HANPP and eHANPP calculation.   

<table><tr><td>Data</td><td>Bulk download Zip file</td><td>Filtered element or item</td></tr><tr><td>Crop production, crop harvested area</td><td>Production_Crops_E_All_Data_(Normalized).zipCurrent URL: https://fenixservices.fao.org/faostat/static/bulkdownloads/Production_Crops_Livestock_E_All_Data_(Normalized).zip</td><td>Production, Area harvested (Element)</td></tr><tr><td>Livestock production</td><td>Production_Livestock_E_All_Data_(Normalized).zipCurrent URL: https://fenixservices.fao.org/faostat/static/bulkdownloads/Production_Crops_Livestock_E_All_Data_(Normalized).zip</td><td>Production</td></tr><tr><td>Livestock animal numbers (Cattle and buffaloes)</td><td>Production_LivestockPrimary_E_All_Data_(Normalized).zipCurrent URL: https://fenixservices.fao.org/faostat/static/bulk/downloads/Production_Crops_Livestock_E_All_Data_(Normalized).zip</td><td></td></tr><tr><td>Market feed from crops, end uses</td><td>CommodityBalances_Crops_E_All_Data_(Normalized).zip(Not fully reported anymore by the FAO)</td><td></td></tr><tr><td>Market feed from livestock products</td><td>CommodityBalances_LivestockFish_E_All_Data_(Normalized).zip(Not fully reported anymore by the FAO)</td><td></td></tr><tr><td>Forestry products production</td><td>Forestry_E_All_Data_(Normalized).zipURL: https://fenixservices.fao.org/faostat/static/bulkdownloads/Forestry_E_All_Data_(Normalized).zip</td><td>Production (Element)</td></tr><tr><td>Physically cropped area</td><td>Inputs_LandUse_E_All_Data_(Normalized).zipURL: https://fenixservices.fao.org/faostat/static/bulk downloads/Inputs_LandUse_E_All_Data_(Normalized).zip</td><td>Cropland (Item)</td></tr><tr><td>Bilateral trade matrices agriculture</td><td>Trade_DetailedTradeMatrix_E_All_Data_(Normalized).zipURL: https://fenixservices.fao.org/faostat/static/bulkdownloads/Trade_DetailedTradeMatrix_E_All_Data_(Normalized).zip</td><td></td></tr><tr><td>Bilateral trade matrices wood products</td><td>Forestry_Trade_Floows_E_All_Data_(Normalized).zipURL: https://fenixservices.fao.org/faostat/static/bulk downloads/Forestry_Trade_Floows_E_All_Data_(Normalized).zip</td><td></td></tr></table>

# 3.1. Step 1 Calculation of the HANPP factors per product

The product level HANPP calculation is similar in most steps to previous HANPP assessments [6,1,7], but keeping product disaggregation as much as possible.

# 3.1.1. Step 1. $H A N P P _ { h a r v }$ and $N P P _ { a c t }$ on Cropland

The calculations of $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ on cropland were similar to Kastner et al. [1] and Haberl et al. [6], except that crops were never aggregated.

$$
\begin{array}{l} H A N P P _ {h a r v, c r o p} = (C r o p p r o d u c t i o n d. m. + u s e d b y p r o d u c t i o n + u n u s e d b y p r o d u c t i s) \\ \times s h o o t t o t a l r a t i o \end{array}
$$

We first converted crop production from fresh weight to dry matter using crop specific water content factors.

$$
C r o p \quad p r o d u c t i o n \quad d r y \quad m a t t e r = \quad C r o p \quad p r o d u c t i o n \quad f r e s h \quad w e i g h t \times (1 - w a t e r \quad c o n t e n t \quad f a c t o r)
$$

We calculated used by-products (out of which some are used as feed) and unused residues with specific multipliers (harvest indices) for each world region [8], differentiating annual and

![](images/58bc8bcb4fc823b8238ae83535c9513ab312390daeb116eb439cfd7c11b5ae18.jpg)  
Fig. 1. Calculation steps. Data sources are referred to in round brackets (…). Matrix or vector names are written in square brackets […]. $\mathrm { \Delta N P P _ { p o t } }$ : potential Net Primary Production, $\mathrm { N P P _ { a c t } }$ : actual Net Primary Production, $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ : HANPP induced by crop harvest or grazing, $\mathrm { H A N P P _ { l u c } }$ : HANPP induced by land use change.

permanent crops.

used by products = Crop production d.m. $\times$ multiplier used by products

unused by products $=$ Crop production d.m. $\times$ multiplier unused by products

Some annual crops, called $A _ { 0 }$ , had no harvest indices. These were attributed a multiplier of unused by-products defined as the average ratio of by-products of crops with harvest index $( A _ { H I } )$

unused by products A0 = Crop production d.m. A0

$$
\times \frac {\text {t o t a l u s e d b y p r o d u c t s} A _ {H I} + \text {t o t a l u n u s e d b y p r o d u c t s} A _ {H I}}{\text {t o t a l c r o p p r o d u c t i o n} A _ {H I}}
$$

Total above-ground $H A N P P _ { h a r \nu }$ was defined as:

Aboveground HANPPharv, cropland $=$ Crop production d.m. + used by products + unused by products

The total above and below-ground $H A N P P _ { h a r \nu }$ was calculated with a shoot to total ratio of ${ \sim } 0 . 8 7$ [9]. This yields the $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ on cropland at the product level.

$$
H A N P P _ {h a r v, c r o p} = \frac {\text {A b o v e g r o u n d H A N P P} _ {h a r v , c r o p}}{\left(\frac {0 . 5 3}{0 . 5 3 + 0 . 0 8}\right)}
$$

We calculated pre-harvest losses according to each country’s degree of industrialization [10]. For permanent crops, the additional NPP remaining in ecosystems is estimated to 1.5 times the production [6]. The sum of the preharvest losses and the NPP remaining for permanent crops yields the NPPeco for each product.

$N P P _ { e c 0 , c r o p } = p r$ e harvest losses × HANPPharv, crop + 1.5 × permanent crops

The sum of the $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ and the $\mathrm { N P P _ { e c o } }$ is the $\mathrm { \Delta N P P _ { a c t } }$ , at the product level.

$$
N P P _ {a c t, c r o p} = N P P _ {e c o, c r o p} + H A N P P _ {h a r v, c r o p}
$$

# 3.1.2. Step $1 . 2 ~ H A N P P _ { h a r v }$ on Grassland and animal feed

The $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ on grassland was calculated using the grazing gap method, i.e. by calculating grazed biomass as the residual feed requirement after subtracting market feed and crop residues used as feed [11]. All equations are at the country and year level.

$$
\begin{array}{l} H A N P P _ {h a r v, g r a s s l a n d} = t o t a l \text {r u m i n a n t f e e d d e m a n d} - 1. 5 \times (T o t a l \text {m a k e t f e e d} \\ - \text {f e e d} \\ \end{array}
$$

Daily feed (hay equivalent) demand for milk cows and beef cattle were taken from the linear functions between milk (beef) yield and feed intake, from Krausmann et al. [11].

$$
F e e d \quad \text {d e m a n d} _ {\text {b e e f a n d b u r f a l o m e a t}} [ \mathrm {M t} \mathrm {d m} \text {h e a d} ^ {- 1} \mathrm {y r} ^ {- 1} ] = (0. 0 3 6 3 6 1
$$

$$
\times \text {C a r c s a w e i g h t} _ {\text {b e e f a n d b u f f a l o m e a t}} + 1. 7 0 2 0 0 6) \times 3 6 5
$$

$$
F e e d \quad \text {d e m a n d} _ {\mathrm {m i l k}} [ \mathrm {M t} \mathrm {d m} \text {h e a d} ^ {- 1} \mathrm {y r} ^ {- 1} ] = (0. 0 0 1 5 5 \times \text {Y i e l d} _ {\mathrm {M i l k}} + 4. 8 3 7 5) \times 3 6 5
$$

Because the distinction between meat cattle and milk cattle is not straightforward, the feed demand from cows and cattle were set to the maximum between the two values (milk and meat).

$$
\begin{array}{l} \text {T o t a l} \quad \text {d e m a n d} _ {\text {c a t t l e}} \left[ \mathrm {M t} \mathrm {d m} \mathrm {y r} ^ {- 1} \right] = \text {c a t t l e} \\ \times \max  \left\{\text {F e e d} \quad \text {d e m a n d} _ {\text {b e e f a n d b u r f a l o m e a t}}; \text {F e e d} \quad \text {d e m a n d} _ {\text {m i l k}} \right\} \\ \end{array}
$$

Feed demand (hay equivalent) from other ruminants and grazing animals as horses (hereafter called ruminants or grazing animals) was calculated with a demand per head factor (Table 2). For sheep and goats, the factors are as well specific to the degree of industrialization.

Table 2 Factors for feed demand per head - other ruminants.   

<table><tr><td></td><td></td><td>Developing countries</td><td>Industrialized countries</td></tr><tr><td>Sheep</td><td>kg dm/head/day</td><td>1.0</td><td>1.5</td></tr><tr><td>Goats</td><td>kg dm/head/day</td><td>1.0</td><td>1.5</td></tr><tr><td>Horses</td><td>kg dm/head/day</td><td>10.0</td><td></td></tr><tr><td>Asses</td><td>kg dm/head/day</td><td>6.0</td><td></td></tr><tr><td>Mules</td><td>kg dm/head/day</td><td>6.0</td><td></td></tr><tr><td>Camels</td><td>kg dm/head/day</td><td>10.0</td><td></td></tr></table>

$$
\text {T o t a l} \quad \text {f e e d} \quad \text {d e m a n d} _ {\text {o t h e r} \text {r u m i n a n t s}} \left[ \mathrm {M t} \mathrm {d m} \mathrm {y r} ^ {- 1} \right] = \text {F e e d} \quad \text {d e m a n d} _ {\text {o t h e r} \text {r u m i n a n t s}} * \text {h e a d s} * 3 6 5 / 1 0 ^ {9}
$$

Feed demand for monogastrics was calculated via world region specific feed demand per unit product factors (Table 3).

$$
\begin{array}{l} \text {T o t a l f e e d} \quad \text {d e m a n d} _ {\text {r u m i n a n t s}} \left[ \mathrm {M t} \mathrm {d m} \mathrm {y r} ^ {- 1} \right] = \text {T o t a l f e e d} \quad \text {d e m a n d} _ {\text {c a t t l e}} \\ + \text {T o t a l} \\ \end{array}
$$

$$
\begin{array}{l} \text {T o t a l} \quad \text {f e e d} \quad \text {d e m a n d} _ {\text {m o n o g a t r i c s}} \left[ \mathrm {M t} \mathrm {d m} \mathrm {y r} ^ {- 1} \right] \\ = \text {F e e d} _ {\text {m o n o g a s t r i c s}} * \text {p r o d u c t i o n} _ {\text {m o n o g a s t r i c p r o d u c t s}} \\ \end{array}
$$

We converted market feed from the commodity balances into dry matter, and allocated it in priority to monogastrics, as they cannot eat large quantities of roughage. Where market feed alone was not sufficient to cover the feed requirements of monogastrics, we assumed that the rest would have come from kitchen residues and other unformal sources, to which we do not allocate a HANPP rucksack.

$$
\begin{array}{l} M a r k e t f e e d f o r m o n o g a s t r i c s \left[ M t d m y r ^ {- 1} \right] \\ = \min  \left\{T o t a l f e e d \text {d e m a n d} _ {\text {m o n o g a s t r i c s}}; T o t a l \text {m a k e t f e e d} d m \right\} \\ \end{array}
$$

Market feed for ruminants was defined as the difference between total market feed (in dry matter) and the market feed allocated to monogastrics. For the grazing gap method, market feed for ruminants was multiplied by 1.5 to convert it into hay equivalents.

Table 3   
Factors for feed demand per product : monogastrics.   

<table><tr><td>Product</td><td>Unit</td><td>East Asia</td><td>East Europe</td><td>Latin America</td><td>North Africa and W. Asia</td><td>North America and Oc.</td><td>South and Central Asia</td><td>Subsaharan Africa</td><td>West Europe</td></tr><tr><td>Eggs Primary</td><td>kg feed/kg eggs</td><td>3</td><td>3</td><td>3</td><td>3</td><td>2.8</td><td>3.8</td><td>4</td><td>2.8</td></tr><tr><td>Meat, pig</td><td>kg feed DM/kg meat FW</td><td>5</td><td>5</td><td>9</td><td>6</td><td>4</td><td>8</td><td>8.5</td><td>4</td></tr><tr><td>Meat, Poultry</td><td>kg feed/kg meat</td><td>4.3</td><td>4</td><td>3.6</td><td>4.4</td><td>3</td><td>5.1</td><td>5.5</td><td>3</td></tr></table>

Market f eed f or ruminants in hay equivalent

$$
\begin{array}{l} = \min  \left\{T o t a l f e e d \text {d e m a n d} _ {\text {r u m i n a n t s}}; (T o t a l m a r k e t f e e d d m \right. \\ - \text {M a r k e t f e e d f o r m o n o g a s t r i c s}) * 1. 5 \} \\ \end{array}
$$

Used crop residues were taken from the cropland calculation, and multiplied by a country specific factor of residues used as feed for cereals and other crops. Residues used as feed were downscaled when these exceeded the remaining feed requirement of ruminants.

Residues used as f eed $=$ min {cropland used by products $\times$ share residues used as f eed;

(Total f eed demandruminants − Market f eed f or ruminants in hay equivalent)}

The total feed from grazing, i.e. $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ on grassland, was calculated as the feed requirement of ruminants, neither covered by market feed nor by crop residues. Note that because the FAO does not report roughage from fodder crops (green maize etc.), the latter are embedded in the $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ on grassland.

Total HANPPharv, grassland $=$ Total f eed demandruminants−Market f eed f or ruminants in hay equivalent − residues used as f eed

Previous calculation steps were similar to previous studies. For our purposes grazing has to be allocated to the various grazing animals. We hence calculated the shares of market feed, residues and roughage (grazing including roughage fodder crops) in the total feed demand of all ruminants.

$$
S h a r e _ {f e e d t y p e, r u m i n a n t s} = \frac {f e e d t y p e _ {r u m i n a n t s}}{T o t a l f e e d d e m a n d _ {r u m i n a n t s}}
$$

Where f eed type = {Grazing; crop residues; market f eed in hay equivalent}

These shares are then multiplied to each ruminant’s total feed demand. In other words, in each country, cattle, goats and sheep would be allocated the same share of market feed, crop residues and roughage.

f eed typeanimal = Share f eed type, ruminants $\times$ Total f eed demandanimal

Where animal $=$ {cattle; sheep; goats; horses; asses; mules; camels}

To retrieve the market feed in market feed equivalent, the market feed in hay equivalents must be divided by 1.5.

The shares of each market feed product within the total market feed were as well attributed to all animals. Therefore, within their respective market feed, pigs get the same share of soy cake or brans as do cattle.

$$
S h a r e _ {f e e d p r o d u c t} = \frac {f e e d p r o d u c t}{T o t a l m a r k e t f e e d}
$$

$$
\begin{array}{l} \text {M a r k e t} f e e d _ {\text {f e e d p r o d u c t , a n i m a l o r p r o d u c t}} = \text {S h a r e} _ {\text {f e e d p r o d u c t}} \\ \times \text {m a r k e t} \\ \end{array}
$$

Where animal or product $=$ {cattle; sheep; goats; horses; asses; mules; camels; eggs; poultry meat; pig meat}

# 3.1.3. Step 1.3 Fallow land and double cropping

We calculated the difference between the national cropland area under arable crops, and the total harvested area over all arable crops in each country.

$$
\Delta \text {a r e a} = \text {P h y s i c a l}
$$

In countries and years where -area is negative, we consider it to be due to multiple cropping of arable crops (several harvesting periods on the same area).

$$
m u l t i p l e c r o p p i n g f a c t o r = \frac {\text {T o t a l p h y s i c a l a r a b l e c r o p l a n d a r e a}}{\sum_ {\text {a r a b l e c r o p s}} \text {a r e a h a r v e s t e d}}
$$

The multiple cropping factor is hence multiplied to the respective harvested area of each arable crop to obtain the physically cropped area.

$$
\text {P h y s i c a l} \quad \text {c r o p p e d} \quad \text {a r a b l e} \quad \text {c r o p} = \text {a r e a} \quad \text {h a r v e s t e d} _ {\text {a r a b l e}} \quad \text {c r o p} \times \text {m u l t i p l e}
$$

In countries and years where -area is positive, we set the difference to be fallow land.

Unlike previous HANPP assessments, we had to distribute this fallow to each arable crop, and opted for distributing it according to their respective physically cropped area.

$$
f a l l o w \quad \text {l a n d} _ {\text {a r a b l e c r o p}} = \text {t o t a l} \quad \text {f a l l o w} \quad \text {l a n d} \times \frac {\text {P h y s i c a l} \quad \text {c r o p p e d} \quad \text {a r a b l e} \quad \text {c r o p}}{\text {T o t a l} \quad \text {p h y s i c a l} \quad \text {a r a b l e} \quad \text {c r o p l a n d} \quad \text {a r e a}}
$$

# 3.1.4. Step $1 . 4 ~ H A N P P _ { h a r v }$ of wood products

We first isolated the production of the four primary products, namely: industrial roundwood, coniferous; industrial roundwood, non-coniferous; Wood fuel, coniferous; Wood fuel, nonconiferous. Following previous HANPP assessments, wood volumes were converted in tonnes of dm biomass using the following wood density factors. We added the bark of the tree using bark factors, accounted for non-removed fellings with recovery rates, and for belowground NPP with a shoot over total ratio. For each of the primary products:

$$
\mathrm {H A N P P} _ {\text {h a r v , w o o d p r o d}} = \frac {\text {w o o d m a r k e t v o l u m e} \times \text {w o o d d e n s i t y}}{\text {B a r k f a c t o r} \times \text {r e c o v e r y r a t e} \times \text {s h o o t o v e r t o t a l}}
$$

# 3.1.5. Step $1 . 5 ~ N P P _ { p o t }$

Global gridded $\mathrm { \Delta N P P _ { p o t } }$ at half degree spatial resolution is provided yearly by the LPJmL dynamic global vegetation model (Schaphoff et al. [12]). The model is driven by the following input data: i) monthly temperature, precipitation, cloudiness, and rainy days from the CRU_TS4.03 historical climatology (Harris et al. [13]), covering the time period 1901 to 2018, ii) yearly atmospheric co2 concentration (Tans and Keeling, [14]), iii) soil texture (Nachtergaele et al., [15]).

The $\mathsf { N P P } _ { \mathsf { p o t } }$ was attributed to countries and land cover types based on spatially explicit land cover data from Kastner et al., [1]. Country and land cover type specific $\mathsf { N P P } _ { \mathsf { p o t } }$ data were then smoothed over the entire period, using a loess method, and set to 0 where the result was negative.

For the product level HANPP factors, $\mathrm { \Delta N P P _ { p o t } }$ has to be allocated to products and animals. $\mathrm { \Delta N P P _ { p o t } }$ on cropland was proportionally allocated to crop products based on their respective physically cropped area, including the fallow land. For permanent crops, the physical cropped area is the harvested area, and fallow land is null. The crop specific $\mathrm { \Delta N P P _ { p o t } }$ was adjusted based on the location of the cultivars, with factors from [16], which were calculated from Monfreda et al. cultivar maps for the year 2000 [2]. The total was scaled to the new total $\mathrm { \Delta N P P _ { p o t } }$ values.

$$
\begin{array}{l} N P P _ {\text {p o t . c r o p}} = \left(\text {P h y s i c a c r o p e d a r e a} _ {\text {c r o p}} + f a l l o w \text {l a n d} _ {\text {c r o p}}\right) \times N P P _ {\text {p o t . c r o p}} \text {p e r} h a _ {\text {K a s t n e r} \text {e t a l .}} \\ \times \frac {N P P _ {\text {p o t} , \text {c r o p l a n d}}}{\sum_ {\text {c r o p s}} \left(\left(\text {P h y s i c a l c r o p p e d a r e a} _ {\text {c r o p}} + \text {f a l l o w l a n d} _ {\text {c r o p}}\right) \times N P P _ {\text {p o t} , \text {c r o p}} \text {p e r} h a _ {\text {K a s t n e r} \text {e t} \text {a l .}}\right)} \\ \end{array}
$$

In countries where factors from Kastner et al. [16] were missing, we allocated the $\mathrm { \Delta N P P _ { p o t } }$ proportionally to the physically cropped area.

$$
N P P _ {p o t, c r o p} = \frac {\text {P h y s i c a l c r o p p e d a r e a} _ {c r o p} + f a l l o w \text {l a n d} _ {c r o p}}{\text {t o t a l p h y s i c a l c r o p p e d a r e a}} \times \text {T o t a l N P P} _ {p o t, c r o p l a n d}
$$

$\mathrm { \Delta N P P _ { p o t } }$ on fallow was isolated by multiplying crop and country specific NPPpot per hectare values, to the corresponding fallow area.

$$
N P P _ {p o t, c r o p, f a l l o w} = \frac {N P P _ {p o t , c r o p}}{\text {P h y s i c a l c r o p p e d a r e a} _ {c r o p} + f a l l o w \text {l a n d} _ {c r o p}} \times f a l l o w \text {l a n d} _ {c r o p}
$$

$\mathsf { N P P } _ { \mathsf { p o t } }$ on grassland was first distributed to minor grazing animals (asses, mules, camels) proportionally to their respective share in the total $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ on grassland in each country.

$$
N P P _ {\text {p o t , g r a s s , m i n o r g r a z i n g a n i m a l s}} = \frac {H A N P P _ {\text {h a r v , g r a s s , a n i m a l}}}{\text {T o t a l} H A N P P _ {\text {h a r v , g r a s s l a n d}}} \times \text {T o t a l} N P P _ {\text {p o t , g r a s s l a n d}}
$$

For cattle and buffaloes, goats, horses, and sheep (hereafter called major grazing animals), we proceeded to a further adjustment of the $\mathrm { \Delta N P P _ { p o t } }$ , to consider that certain animals (often cattle) graze on more productive land than others (often sheep and goats). We calculated $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ per head, and combined it to the dasymetric (DA) Gridded Livestock of the World (GLW) spatially explicit dataset from the FAO (https://www.fao.org/livestock-systems/global-distributions/en/), for the year 2010, to globally map the $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ on grassland for each animal for all years.

Within each pixel:

$$
H A N P P _ {h a r v, g r a s s, a n i m a l} \text {i n p i x e l} = \# a n i m a l s \text {i n p i x e l} \times \frac {H A N P P _ {h a r v , g r a s s , a n i m a l}}{\text {T o t a l} \# a n i m a l s _ {\text {G r i d d e d} \text {l i v e s t o c k}}}
$$

Where animal $=$ {cattle and buffaloes; goats; horses; sheep}

Summing the $\mathrm { H A N P P _ { h a r v } }$ maps of all animals, we gridded the share of each animal’s $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ in total $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ on grassland. We combined the gridded shares of $\mathrm { H A N P P _ { h a r v } }$ to the gridded $\mathrm { \Delta N P P _ { p o t } }$ from grassland of major grazing animals, and multiplied the $\mathsf { N P P } _ { \mathsf { p o t } }$ of grassland by each animal’s share of $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ from grazing within each pixel, to obtain the animal specific $\mathrm { \Delta N P P _ { p o t } }$ .

$$
N P P _ {p o t, a n i m a l} = \left(T o t a l N P P _ {p o t, g r a s s} - T o t a l N P P _ {p o t, g r a s s, m i n o r g r a z i n g a n i m a l}\right) \times s h a r e N P P _ {p o t, a n i m a l}
$$

$$
N P P _ {p o t, a n i m a l} = \left(T o t a l N P P _ {p o t, g r a s s} - T o t a l N P P _ {p o t, g r a s s, m i n o r g r a z i n g a n i m a l}\right) \times s h a r e N P P _ {p o t, a n i m a l}
$$

For countries small countries that were not in the raster, we kept the proportionally allocated values (as for minor grazing animals).

In some countries, the $\mathrm { H A N P P _ { h a r v } }$ of wood products exceeded the $\mathrm { \Delta N P P _ { p o t } }$ in forests. We assumed this is because wood products, especially wood fuels, may be harvested on other land cover types than forests, for example bush lands and savannahs. We hence adjusted the $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ of wood products, to isolate the $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ in forests only. We first removed the excessive $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ from the $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ of wood fuel (wf). In countries where this was still not sufficient, i.e. where the $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ of industrial roundwood (ir) alone was above the $\mathsf { N P P } _ { \mathsf { p o t } }$ of forests, we removed the remaining excess from the $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ of industrial roundwood.

$$
I f \quad T o t a l H A N P P _ {h a r v, w o o d} > N P P _ {p o t, f o r e s t}:
$$

$$
\begin{array}{l} H A N P P _ {h a r v, w f, \{c o n i f e r o u s; n o n c o n i f e r o u s \}, f o r e s t} = H A N P P _ {h a r v, w f, \{c o n i f e r o u s; n o n c o n i f e r o u s \}} \\ - s h a r e _ {w f. \{c o n i f e r o u s; n o n c o n i f e r o u s \}} \\ \times \left(T o t a l H A N P P _ {h a r v, w o o d} - N P P _ {p o t, f o r e s t}\right) \\ \end{array}
$$

Where

$$
\text {s h a r e} _ {w f, \{c o n i f e r o u s; n o n c o n i f e r o u s \}} = \frac {\text {H A N P P} _ {\text {h a r v} , w f , \{c o n i f e r o u s ; n o n c o n i f e r o u s \}}}{\text {H A N P P} _ {\text {h a r v} , w f , c o n i f e r o u s} + \text {H A N P P} _ {\text {h a r v} , w f , n o n c o n i f e r o u s}}
$$

Is the share of coniferous and non-coniferous wood in the total $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ of wood fuel.

$$
\begin{array}{l} I f \quad T o t a l H A N P P _ {h a r v, i r} > N P P _ {p o t, f o r e s t}: \\ H A N P P _ {h a r v, w f. f o r e s t} = 0 \\ \end{array}
$$

$$
\begin{array}{l} - s h a r e _ {i r, \{c o n i f e r o u s; n o n c o n i f e r o u s \}} \\ \times \left(T o t a l H A N P P _ {h a r v, w o o d} - N P P _ {p o t, f o r e s t} - H A N P P _ {h a r v, w f}\right) \\ \end{array}
$$

Where shareir,{coni f erous; non coni f erous} is the share of coniferous and non-coniferous wood in the total $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ of industrial roundwood.

We can now allocate the $\mathsf { N P P } _ { \mathsf { p o t } }$ in forests proportionally to the $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ in forest of the four primary wood products.

$$
N P P _ {p o t, f o r e s t, p r o d} = N P P _ {p o t, f o r e s t} \times \frac {H A N P P _ {h a r v , p r o d , f o r e s t}}{T o t a l H A N P P _ {h a r v , f o r e s t}}
$$

# 3.1.6. Step 1.6 $\cdot \ H A N P P _ { l u c }$ and HANPP

$\mathrm { H A N P P _ { l u c } }$ on fallow was calculated by multiplying the $\mathsf { N P P } _ { \mathsf { p o t } }$ on fallow with factors from [7]. $\mathrm { N P P _ { a c t } }$ on fallow is hence the difference between the $\mathrm { \Delta N P P _ { p o t } }$ on fallow and the $\mathrm { H A N P P _ { l u c } }$ on fallow. The total $\mathrm { N P P _ { a c t } }$ on cropland is the sum of the $\mathsf { N P P _ { a c t } }$ cropland and the $\mathsf { N P P _ { a c t } }$ on fallow. $\mathrm { H A N P P _ { l u c } }$ on cropland is the difference between $\mathsf { N P P } _ { \mathsf { p o t } }$ on cropland and total $\mathrm { N P P _ { a c t } }$ on cropland. The crop specific HANPP on cropland is the sum of the crop specific $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ and $\mathrm { H A N P P _ { l u c } }$ on cropland.

$$
\begin{array}{l} \text {T o t a l N P P} _ {\text {a c t}, \text {c r o p}} = N P P _ {\text {a c t}, \text {c r o p}} + N P P _ {\text {p o t}, \text {c r o p}, \text {f a l l o w}} \times \left(1 - H A N P P _ {\text {l u c}, \text {f a l l o w}} \text {p e r} N P P _ {\text {p o t}}\right) \\ H A N P P _ {l u c, c r o p} = N P P _ {p o t, c r o p} - N P P _ {a c t, c r o p} \\ H A N P P _ {c r o p} = H A N P P _ {h a r v, c r o p} + H A N P P _ {l u c, c r o p} \\ \end{array}
$$

Country specific average $\mathrm { H A N P P _ { l u c } }$ per $\mathsf { N P P } _ { \mathsf { p o t } }$ on grassland were taken from [7], and multiplied to the animal and country specific $\mathrm { \Delta N P P _ { p o t } }$ values. The animal specific HANPP on grassland is the sum of the animal specific $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ and $\mathrm { H A N P P _ { l u c } }$ on grassland. $\mathsf { N P P a c t }$ on grassland is the $\mathrm { \Delta N P P _ { p o t } }$ minus $\mathrm { H A N P P _ { l u c } }$ on grassland. $\mathrm { N P P _ { e c o } }$ on grassland is the $\mathrm { N P P a c t }$ minus $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ on grassland. Where the $\mathrm { N P P _ { e c o } }$ on grassland was below $5 \%$ of the $\mathsf { N P P a c t }$ , we adjusted the $\mathrm { N P P a c t }$ upwards (and therefore the $\mathrm { H A N P P _ { l u c } }$ downwards) as to have a $\mathrm { N P P _ { e c o } }$ of minimum $5 \%$ of $\mathrm { N P P a c t }$ while keeping the $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ constant. This can be thought of as increasing grassland productivity through fertilization, as it is done in several intensive grazing systems (Netherlands, etc.).

For all animals, countries and years where $N P P _ { e c o } < 0 . 0 5 ~ \times N P P _ { a c t }$

$$
\begin{array}{l} N P P _ {e c o, g r a s s, a d j u s t e d} = \frac {0 . 0 5}{0 . 9 5} \times H A N P P _ {h a r v, g r a s s} \\ N P P _ {a c t, g r a s s, a d j u s t e d} = N P P _ {e c o, g r a s s, a d j u s t e d} + H A N P P _ {h a r v, g r a s s} \\ H A N P P _ {l u c, g r a s s, a d j u s t e d} = N P P _ {p o t} - N P P _ {a c t, g r a s s, a d j u s t e d} \\ H A N P P _ {\text {g r a s s , a d j u s t e d}} = H A N P P _ {\text {h a r v , g r a s s}} + H A N P P _ {\text {l u c , g r a s s , a d j u s t e d}} \\ \end{array}
$$

We did not allocate any $\mathrm { H A N P P _ { l u c } }$ to crop residues used as feed. Therefore, the only HANPP allocated to crop residues used as feed was the mass of these residues $\left( \mathrm { H A N P P } _ { \mathrm { h a r v . } } \right)$ ). This comes from the assumption that the land use change occurred primarily for the main product of the corresponding crop (for example wheat), and not for its by-product (straw).

For forestry products, the $\mathrm { H A N P P _ { l u c } }$ is set to 0. $\mathrm { N P P a c t }$ is hence equal to $\mathrm { \Delta N P P _ { p o t } }$ and $\mathrm { N P P _ { e c o } }$ equals $\mathrm { \Delta N P P _ { p o t } }$ minus HANPPharv,forest (i.e. excluding the $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ exceeding the $\mathrm { \Delta N P P _ { p o t } }$ in forest), all at the primary product level.

# 3.1.7. Step 1.7 factors used to calculate HANPP / product ratios

For cropland, we calculated the factors per tonne of crop by first removing the residues used as feed from the $\mathrm { H A N P P _ { h a r v } }$ and the HANPP on cropland, and dividing the respective value by the crop production quantity (in dry matter).

For grassland and crop residues used as feed, the allocation to animal products requires one further step, for grazing animals, namely the attribution to milk or meat (we did not consider other products as leather and materials, hence overestimating the rucksack of meat and milk).

For grazing animals, we allocate HANPP values according to the number of heads reported for the production of milk or meat respectively.

$$
\text {s h a r e} = \frac {\# \text {a n i m a l s} _ {\text {p r o d}}}{\# \text {a n i m a l s}}
$$

Where $p r o d = \{ m i l k ; m e a t \}$ and animals $=$ {cattle; sheep; goat}

For horses, asses, mules, and camels, we did not allocate the HANPP to the reported milk and meat, as we assumed that these animals are mainly kept for services and leisure, and we do not know how many animals are grown exclusively for products.

We finally calculate NPP and HANPP values per tonne of product, by dividing by the production quantities of the respective animal products.

For wood products, factors per tonne of product were calculated by dividing NPP and HANPP values by the production of wood in dry matter. Note that these values do not include the HANPP exceed the $\mathrm { \Delta N P P _ { p o t } }$ in forest, which are saved separately.

This finishes the HANPP calculation at the product level. Product level HANPP data can be visualized interactively and downloaded under https://ijsadihsadoaisjd.shinyapps.io/shiny_app_ hanpp_all_lu_types/

# 3.2. Step 2: Bilateral trade and correction for reexports

# 3.2.1. Step 2.1 Crops, animal products, and wood products

The calculation of the trilateral trade data relies on the same procedure as the one described in [17–19]. In this method, bilateral trade matrices are built, based on the reports from the importing countries. When the data from the importing country were missing, they were filled with data reported by exporting countries, yielding bilateral trade matrices between 222 countries.

283 traded vegetal products were converted to 159 primary crops, based on their dry matter content. Similarly, bilateral trade matrices were built for 66 traded animal products, converted to 13 primary animal products.

$$
\text {b i l a t e r a l} \quad \text {t r a d e} _ {\text {p r i m a r y}, d m} = \sum_ {\text {p r o d}} \text {b i l a t e r a l} \quad \text {t r a d e} _ {\text {p r o d}, \text {p r i m a r y}, f w} \times (1 - \text {w a t e r c o n t e n t f a c t o r})
$$

Where prod, primary $=$ all secondary products associated to a given primary product

Special treatment was given to sugar crops, often reported as “sugar refined”, which have to be split into sugar beet and sugar cane. We hence calculated the available supply of sugar beet and cane in each country, by correcting a first time for reexports, as described in [19], solely for sugar beet and cane. We then split the trade flows of refined sugar proportionally to the apparent consumption of sugar beet and cane in each country exporting refined sugar.

$$
\text {s u g a r r e f i n e d} _ {\left\{\text {b e a t}; \text {c a n e} \right\}} = \frac {\text {a p p a r e n t c o n s u m p t i o n} _ {\left\{\text {b e a t}; \text {c a n e} \right\}}}{\text {a p p a r e n t c o n s u m p t i o n} _ {\text {b e a t}} + \text {a p p a r e n t c o n s u m p t i o n} _ {\text {c a n e}}} \times \text {s u g a r r e f i n e d}
$$

We could then correct for reexports for all primary crops as described on [19]. The difference of $0 . 3 \%$ between total production and the results of the corrected trade matrices was allocated to domestic consumption. Following the notation of [19], we hereafter call $\bar { R }$ the $( n \times n )$ sized bilateral trade matrix for a given crop, corrected for reexports, where $\bar { R } _ { i j }$ is the the apparent consumption of country i originating from country j.

Despite the reported milk and meat products for Asses, Camels, Horses, Mules, we decided to neglect the production and international trade of these products, given that the large share of these animals is not used for their products. For examples, horses are likely rather used for horse riding than for horse meat. We hence considered that all the footprint of these animals was domestic.

For wood products, we followed the methodology of [20]. This method is similar to Kastner et al. [19], but corrects trade flows for the recovered paper and pulp, such that the trade flows

reflect only exports of virgin (non-recovered) paper. As bilateral trade of wood fuel is small and not reported, we allocated all wood fuel to domestic consumption.

# 3.2.2. Step 2.2 Animal products trade in primary crops equivalents

In order to calculate the matrix of livestock product trade in feed crop equivalents S¯, we need to multiply the bilateral trade matrices of animal products by factors of feed crops per tonne of each animal product. Feed products per tonne of animal product were calculated previously for the grazing gap method. However, feed products have to be converted into primary crops. We hence built equivalence tables between the feed products reported in the FAO commodity balances and the primary crops. For example, some categories as brans can correspond to various crops (wheat, rice, etc.). Commodity balances products were hence distributed to the primary crops found in the description column of the FAOSTAT definitions, based on the respective apparent consumption of each crop calculated at the previous step through the bilateral trade matrices of crop products. Therefore, if corrected for imports and exports, out of all the crop products reported in the definition of brans, a country had an apparent consumption of 70 tonnes of wheat and 30 tonnes of rice, we allocated $7 0 \%$ of the brans to wheat and $3 0 \%$ to rice.

$$
\begin{array}{c} \text {f e e d c r o p e m b o d i e d i n a n i m a l p r o d u c t t r a d e = A P t r a d e \times C B S f e e d p r o d u c t p e r t o n n e o f a n i m a l} \\ \text {p r o d u c t \times s h a r e o f p r i m a r y c r o p s i n f e e d p r o d u c t s} \end{array}
$$

where

$$
\text {s h a r e} = \frac {\text {a p p a r e n t c o n s u m p t i o n} _ {\text {c r o p}}}{\sum_ {\text {c r o p s i n f e e d p r o d}} \text {a p p a r e n t c o n s u m p t i o n} _ {\text {c r o p}}}
$$

Animal products used as feed (e.g. cow milk or fish meal fed to other animals) were neglected from this step. Consequently, any animal product used as feed was dealt with as if it would have been finally consumed in the country where it was used to feed other animals, hence underestimating the international footprint of animal products. Hereafter, we call S¯ the matrix of a given animal product, in feed crops equivalent.

# 3.3. Step 3: Calculating the final uses, adjusting for seeds and losses

We linked the trade data of crops to their final uses (feed, direct human food and other uses), adjusting for seed use and losses, based on the commodity balances (CBS) from the FAO. Again, the first step was to allocate all products from the commodity balances to primary crops according to apparent consumption, using the method described earlier (for the feed products). Sugar refined was again replaced by sugar cane and sugar beet.

$$
\begin{array}{l} f i n a l u s e _ {p r i m a r y c r o p} = \sum_ {c b s p r o d u c t s} f i n a l u s e i n d r y m a t t e r _ {c b s p r o d u c t} \\ \times \frac {\text {a p p a r e n t c o n s u m p t i o n} _ {\text {p r i m a r y c r o p}}}{\sum_ {\text {p r i m a r y c r o p s i n c b s p r o d u c t}} \text {a p p a r e n t c o n s u m p t i o n} _ {\text {p r i m a r y c r o p}}} \\ \end{array}
$$

For example, if 10 tonnes of brans are used as feed in a country, and that country apparently consumes 30 tonnes of wheat and 70 tonnes of maize, and that apart from brans 60 tonnes of maize are used for animal feed, then $1 0 \times \frac { 7 0 } { 7 0 + 3 0 } + 6 0 = 6 7$ tonnes of maize are used as feed in that country. The final use “processing” was removed to avoid double counting.

Trade matrices are to be adjusted to seed use, as the consumption of a crop in a given country should include the quantity of seeds globally used to produce that crop, but exclude the amount of that crop which this country is using for its own seeds. We adjusted trade matrices for seed use, by adding seeds to the production (and exports), and eventually removing them

from the consumption (and imports). Ideally, one should add seeds from the previous year to the production, and remove seeds from that year from the consumption (as these are to be used the following year). However, for calculation ease (especially in the case of countries whose borders changed) we decided to assume that all seeds were used the same year. The adjustment for seeds does hence not affect the global quantity of crops, but solely the trade patterns.

Call v = 1 + $\nu = 1 +$ seeds in producing countryproduction in producing country the vector adjusting production and exports for seed use, and $\hat { \nu }$ the corresponding diagonal matrix.

Call $w = 1 -$ seeds in consuming countryconsumption in consuming country (including seeds) the vector adjusting consumption and imports for seed use, and $\hat { w }$ the corresponding diagonal matrix.

Then we calculated the trade matrix adjusted for seeds:

$$
\overline {{R _ {s e}}} = w \times \bar {R} \times v
$$

We allocated losses to feed, food and others (for simplicity, we assumed no losses in seeds). We calculated a loss adjustment factor in each country for each crop, and applied this factor to the quantity of feed, food and other uses.

$$
\begin{array}{l} f i n a l \quad u s e \quad a d j u s t e d \quad f o r \quad l o s s e s _ {p r i m a r y c r o p} = \left(1 + \frac {\text {l o s s e s} _ {p r i m a r y c r o p}}{\sum_ {\{f e e d ; f o o d ; o t h e r u s e s \}} f i n a l \quad u s e s _ {p r i m a r y c r o p}}\right) \\ \times f i n a l \quad u s e _ {\text {p r i m a r y c r o p}} \\ \end{array}
$$

We eventually calculated the share (including losses) of the final end uses feed, food and other uses.

$$
\begin{array}{l} s h a r e \quad f i n a l \quad u s \quad a d j u s t e d \quad f o r \quad l o s s e s _ {p r i m a r y} c r o p \\ = \frac {\text {f i n a l} \quad \text {u s e} \quad \text {a d j u s t e d} \quad \text {f o r} \quad \text {l o s s e s} _ {\text {p r i m a r y} \quad c r o p}}{\sum_ {\left\{\text {f e e d ; f o o d ; o t h e r} \quad \text {u s e s} \right\}} \text {f i n a l} \quad \text {u s e s} \quad \text {a d j u s t e d} \quad \text {f o r} \quad \text {l o s s e s} _ {\text {p r i m a r y} \quad c r o p}} \\ \end{array}
$$

By multiplying the values of $\overline { { R _ { s e } } }$ by the shares of the final uses adjusted for losses, we obtained the trade data of crops by end uses. Where data for final uses were not available, we attributed the data to the category “unknown final use”.

We calculated $\overline { { S _ { l o } } }$ the matrix of a given animal product, in feed crops equivalent, adjusted for the losses in feed crops.

$$
\begin{array}{l} f e e d c r o p e m b o d i e d i n a n i m a l p r o d u c t t r a d e d a d j u s t e d f o r l o s s e s \\ = \text {f e e d c r o p} \\ \times \left(1 + \frac {\text {l o s s e s}}{\sum_ {\{\text {f e e d ; f o o d ; o t h e r u s e s} \}} \text {f i n a l u s e s}}\right) _ {\text {p r o d u c i n g c o u n t r y}} \\ \end{array}
$$

We omitted the differences in final uses of animal products (e.g. leather).

3.4. Step 4: Origin of the feed for the production and consumption of livestock products

$$
c = \overline {{R _ {s e}}} \times i
$$

is the row sum of $\overline { { R _ { s e } } }$ , and hence the vector of apparent consumption adjusted for seed use, with i a summation vector of $1 , { \hat { c } }$ is the diagonal matrix with the entries of c.

$$
\hat {c} ^ {- 1} \times \overline {{R _ {s e}}}
$$

is the mix of origin for that crop adjusted for seed use.

$$
s = i ^ {\prime} \times \overline {{S _ {l o}}}
$$

is the feed embodied in the production of that animal product, adjusted for losses. $\hat { s }$ is the diagonal matrix with the entries of s.

Then $\overline { { S _ { p } } } = \hat { s } \times \hat { c } ^ { - 1 } \times \overline { { R _ { s e } } }$ is the trade matrix reflecting the origin of the feed required for the production of that animal product. $\overline { { S _ { p } } } _ { i j }$ is the feed originating from country j used to produce an animal product in country i.

$$
\overline {{S _ {-} c}} = \overline {{S _ {l o}}} \times \hat {c} ^ {- 1} \times \overline {{R _ {s e}}}
$$

is the trade matrix reflecting the origin of the feed embodied in the final consumption of that animal product. $\overline { { S _ { c i j } } }$ is the feed originating from country j embodied in the final consumption of an animal product in country i.

We calculated $\overline { { S _ { p } } }$ and $\overline { { S _ { c } } }$ for all crops and animal products. The level of disaggregation would show the quantity of a given crop originating from country A embodied in the production or in the final consumption of an animal product in country B (for example the quantity of soybeans originating from Brazil embodied in the pig meat production or final consumption in Germany).

$$
\overline {{S _ {l o}}} \times \hat {s} ^ {- 1}
$$

is the mix of final destination of an animal product in each country’s production of that animal product. By multiplying the entries of $\overline { { S _ { p } } }$ by the shares of each final destination of the animal product, we calculated the amount of each crop originating in country A, used to produce animal products in country B, which are eventually consumed in country C (for example, the quantity of Brazilian soybeans embodied in pig meat produced in Germany and exported to China).

# 3.5. Step 5: Calculate the HANPP embodied in trade

For eHANPP from cropland and forestry products, we calculated the HANPP (and other HANPP components, as $\mathrm { H A N P P } _ { \mathrm { h a r v } }$ , $\mathrm { H A N P P _ { l u c } }$ or physically cropped area) embodied in the final use of crops for food and other uses, as well as for animal products production and final consumption, by multiplying the HANPP factors calculated in step 1.7, to the corresponding trade matrices.

For eHANPP from grassland and crop residues used as feed, we applied the HANPP factors directly to the trade matrices of animal products. For simplicity, we omitted international trade in crop residues (straws) and roughage (grass and fodder crops). The HANPP embodied in the production of animal products was hence set to the HANPP calculated in step 1. As explained earlier, we as well set the HANPP embodied in the “final consumption” of asses, camels, horses and mules equal to their HANPP in that given country, reflecting the idea that most of the feed and grazing of these animals is not meant to produce meat and milk, but rather to provide services (transport, work or leisure) enjoyed domestically.

Data handling were performed using the R software. The calculation explained above, combining raw data and factors from various sources, makes this dataset unique. All code can be found attached to this article. The final eHANPP data files are publicly available under https://doi.org/10.5281/zenodo.8384359

# 4. Limitations

See section 4.3. “Limitations” in the related research article [21] https://doi.org/10.1016/j. scitotenv.2022.158198.

# Ethics Statement

the authors have read and follow the ethical requirements for publication in Data in Brief and confirming that the current work does not involve human subjects, animal experiments, or any data collected from social media platforms.

# Supplementary Materials

Supplementary material associated with this article can be found, in the online version, at doi:10.1016/j.dib.2023.109725.

