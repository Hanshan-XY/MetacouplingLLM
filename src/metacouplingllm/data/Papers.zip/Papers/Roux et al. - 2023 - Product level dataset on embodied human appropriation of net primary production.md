# Product level dataset on embodied human appropriation of net primary production

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:03:45.091277+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Roux et al. - 2023 - Product level dataset on embodied human appropriation of net primary production.pdf
- Year: unknown
- DOI: 10.1016/j.dib.2023.109725
- OA status: unknown
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: no license info, oa_status=unknown

## Copyright-Safe Summary
This data article presents a global, product-level dataset on embodied Human Appropriation of Net Primary Production (eHANPP) in traded agricultural, livestock, and forestry commodities. HANPP measures how human land use and biomass harvest alter the net primary production available in ecosystems, making it a key indicator of land-use intensity, biodiversity pressure, and implications for carbon cycles.

The dataset links HANPP to specific commodities and their trade flows between 222 countries, thus enabling analyses of environmental pressures along global supply chains. Spatially, it is global; temporally, it covers 1986-2013 for crops and animal products, and 1997-2013 for forestry products. It includes 161 primary crops, 13 primary animal products, and 4 primary forestry products, with attribution to final uses (human food, feed, other uses).

Input data come mainly from FAOSTAT (production, harvested and cropped area, commodity balances, bilateral trade, forestry production and trade), gridded vegetation modeling (LPJmL for potential NPP), land-use and cultivar maps, and FAO Gridded Livestock of the World. The authors compute product-level HANPP factors by combining harvested biomass, residues, grazing requirements, and differences between potential and actual NPP for cropland, grassland, and forests. They then build bilateral and, for livestock, trilateral trade matrices (feed origin - livestock producer - consuming country), correct for reexports, allocate processed items back to primary products, and adjust for seeds and losses. Multiplying trade matrices by product-specific HANPP factors yields eHANPP for production, trade, and consumption.

The main outcome is a set of CSV files that quantify how much ecological pressure, measured as HANPP, is embodied in bilateral and trilateral trade flows and in different end uses. This work is directly about telecoupling and metacoupling: it traces distant environmental impacts of consumption, shows how land-use pressures are displaced across borders via trade, and supports assessments of national responsibilities and planetary boundary transgressions related to biomass use.

## Structured Metacoupling Extraction

### Coupling Classification
- Highly relevant for global telecoupling of land-use impacts via biomass trade.

### Intracoupling
#### Systems
- National agricultural and forestry production systems
- Domestic livestock feeding and grazing systems
#### Flows
- Biomass appropriation within national cropland, grassland, forests
- HANPP flows among crops, livestock, forests domestically
#### Agents
- Farmers and foresters within each country
- National livestock producers
#### Causes
- Domestic food, feed, and material demand
- National land-use intensity and management choices
#### Effects
- Changes in national ecosystem NPP and biodiversity pressures
- Domestic carbon balance and biogeochemical impacts

### Pericoupling
#### Systems
- Neighboring or regionally connected trading countries
- Regional livestock-feed supply chains
#### Flows
- Regional trade of crops, animal products, and wood
- Embodied HANPP in short-distance biomass trade
#### Agents
- Regional traders and processors
- Regional agricultural policy bodies
#### Causes
- Regional specialization in crop, livestock, or forestry production
- Cross-border supply security and market integration
#### Effects
- Spatial redistribution of ecosystem pressure within regions
- Regional leakage of land-use and grazing impacts

### Telecoupling
#### Systems
- Global network of 222 trading countries
- Remote producer, trader, and consumer nations
#### Flows
- Bilateral trade in 161 crops, 13 animal, 4 forestry products
- Trilateral feed-livestock-consumption trade chains
#### Agents
- International commodity traders and agribusiness
- National governments and global NGOs
#### Causes
- Rising global demand for food, feed, fiber, and energy biomass
- International trade liberalization and specialization
- Consumption-driven relocation of ecosystem pressure abroad
#### Effects
- Embodied HANPP displacing biodiversity pressure to distant countries
- Global reallocation of agricultural and forestry production
- National overshoot of planetary boundaries via imported HANPP

### Cross-Coupling Interactions
- Dataset links domestic HANPP to bilateral and trilateral trade, connecting local land use to distant consumption.
- Livestock supply chains couple feed exporters, animal producers, and final consumers across multiple continents.
- Telecoupled trade can mask or amplify intracoupled ecosystem impacts through reexports and complex routing.

### Research Gaps or Limitations
- Some limitations delegated to related article; details not fully restated here.
- Animal products used as feed and some roughage trades omitted, underestimating certain telecoupled impacts.
- Assumptions on seed timing, missing FAO balances, and border changes introduce uncertainty in trade patterns.

### Search Keywords
- embodied HANPP dataset trade 222 countries
- biomass telecoupling feed livestock supply chains
- land-use intensity biodiversity pressure global supply chains

### Extraction Confidence
high
