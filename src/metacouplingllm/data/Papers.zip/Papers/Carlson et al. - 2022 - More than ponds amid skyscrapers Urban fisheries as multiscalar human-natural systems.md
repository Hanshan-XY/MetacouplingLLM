# More than ponds amid skyscrapers Urban fisheries as multiscalar human-natural systems

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:31:21.704923+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Carlson et al. - 2022 - More than ponds amid skyscrapers Urban fisheries as multiscalar human-natural systems.pdf
- Year: unknown
- DOI: 10.14321/aehm.025.01.49
- OA status: closed
- License: none recorded
- Category: Journal Articles\Conceptual\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This conceptual paper examines urban fisheries as coupled human-natural systems that operate across multiple spatial scales. The geographic focus is global, with illustrative cases from cities such as Stockholm, Berlin, and multiple locations in the United States, where data on anglers, trips, and expenditures are comparatively rich.

The authors situate urban fisheries within the metacoupling framework, which analyzes human-nature interactions both within a single system (intracity or local couplings) and between adjacent or distant systems (intercity, urban-rural, and interstate couplings). They emphasize flows of people (anglers, managers, tourists), money (license fees, equipment, travel spending, program budgets), and information (knowledge, regulations, education, social norms) among sending, receiving, and spillover systems such as neighborhoods, water bodies, agencies, and surrounding businesses.

Methods are primarily conceptual and synthetic: the paper integrates prior empirical studies, policy histories, and program evaluations, with some quantitative illustrations from U.S. angler surveys and expenditure data supplied in appendices. The analysis classifies agents, causes, and effects of different types of flows and highlights how social movements, environmental legislation, and equity concerns shaped the emergence of urban fisheries programs.

Key findings are that urban fisheries provide substantial nutritional, recreational, social, and cultural benefits, especially for populations with limited mobility or income, but they also create trade-offs around pollution exposure, crowding, conflicts between urban and rural anglers, funding constraints, and inequitable enforcement or access. The metacoupling lens helps reveal how close-to-home fishing can reduce environmental footprints, while urban-to-rural travel extends impacts and management responsibilities across regions.

The paper is explicitly about metacoupling and telecoupling. It argues that urban fisheries are ideal testbeds for metacoupling analysis and calls for quantitative modeling, expanded attention to spillover systems, and a transition from isolated, site-specific management to integrated, multiscale governance that is both socially just and ecologically sustainable.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong focus on intracoupling within urban fisheries and pericoupling with adjacent urban rural waters
- Telecoupling discussed conceptually and via interstate, international angler and information flows

### Intracoupling
#### Systems
- Urban water bodies and fish populations inside cities
- Urban resident communities and neighborhoods
- City level fisheries agencies and parks departments
#### Flows
- Local angler trips to nearby ponds, lakes, rivers
- Money spent on urban licenses, gear, local infrastructure
- Information exchange via education programs, signage, community networks
#### Agents
- Urban anglers including youth, minorities, families, elderly
- State and city fisheries biologists and managers
- Urban educators, park staff, law enforcement officers
#### Causes
- Desire for close to home recreation and food security
- Political pressure to serve urban residents and equity goals
- Environmental movement emphasizing clean, fishable city waters
#### Effects
- Improved access to fishing and nature contact in cities
- License revenues funding local conservation and facilities
- Enhanced environmental awareness but also local pollution and contamination risks

### Pericoupling
#### Systems
- Urban fisheries and surrounding rural lakes and rivers
- Cities and nearby towns hosting bait shops, restaurants, hotels
- Neighboring municipalities within same state or region
#### Flows
- Angler travel from cities to nearby rural fishing sites
- Spending at adjacent businesses linked to fishing trips
- Regional coordination of regulations and education campaigns
#### Agents
- Urban anglers visiting peri urban and rural waters
- Bait and tackle retailers, restaurants, lodging providers
- County governments and regional planning bodies
#### Causes
- Search for larger or different fish species outside cities
- Economic incentives to attract angling tourism nearby
- Need to harmonize management across urban rural gradients
#### Effects
- Expanded environmental footprints and potential habitat impacts
- Economic benefits and dependence for nearby communities
- User conflicts between urban visitors and rural anglers

### Telecoupling
#### Systems
- Urban fisheries in different states or countries
- National fisheries agencies and interstate governance structures
- Global research and policy networks using metacoupling
#### Flows
- Interstate angler travel and associated spending
- Long distance transfer of management knowledge and data
- Dissemination of metacoupling methods and tools
#### Agents
- Mobile anglers traveling across states or borders
- Universities, research consortia, international NGOs
- National fisheries agencies and funding bodies
#### Causes
- Interest in diverse fishing experiences and destinations
- Scientific drive to generalize urban fisheries insights globally
- Policy diffusion and adoption of metacoupling framework
#### Effects
- Growth in national scale economic value of recreational fishing
- Spread of holistic management ideas among distant cities
- Need for models capturing long distance social ecological linkages

### Cross-Coupling Interactions
- Local urban programs shape regional travel patterns and interstate angling flows
- Telecoupled knowledge networks influence city level policy and education design
- Urban to rural angler movements connect intracoupling dynamics with pericoupling impacts

### Research Gaps or Limitations
- Limited quantitative modeling of metacouplings and Type1 Type2 interactions in urban fisheries
- Insufficient knowledge on spillover systems like restaurants, hotels, tackle shops
- Need for culturally sensitive evaluation of discrimination, equity, and justice in urban fisheries

### Search Keywords
- urban fisheries metacoupling telecoupling
- angler mobility people money information flows
- equity justice urban to rural fishing systems

### Extraction Confidence
high
