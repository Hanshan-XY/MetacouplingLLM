# “Resource-carbon” redistribution caused by Japan_s cement production and consumption a life-cycle b

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:27:56.131227+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Bai et al. - 2025 - “Resource-carbon” redistribution caused by Japan_s cement production and consumption a life-cycle b.pdf
- Year: unknown
- DOI: 10.1016/j.eiar.2025.108051
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper investigates how cement production and consumption in Japan redistribute resource use and carbon emissions across domestic regions and foreign resource suppliers. The study focuses on Japan’s 47 prefectures over 2010-2022, with particular attention to 2022 as a recent benchmark.

The authors build a process-based, life-cycle, multilayer supply network that links three levels: raw material and energy extraction, cement production, and cement demand in different end-use sectors. They combine plant-level life-cycle inventory data, inter-prefectural freight statistics, trade and port data on fuel imports, and a gravity model where direct trade data are missing. Environmental burdens are quantified using two indicators: total material requirement (TMR), which captures both direct and hidden resource extraction, and carbon footprint (CF), including both process and energy-related emissions plus transport.

In 2022, Japan’s cement demand generated roughly 94 million tonnes of TMR and 25 million tonnes CO2-equivalent. Around three quarters of CF and nearly 90 percent of TMR are linked to inter-prefectural trade and imported fuels, while transport itself adds about 5 percent of both impacts. Major extraction and production prefectures in northern and southern Japan, such as Hokkaido, Yamaguchi, Fukuoka, Oita, and Kochi, largely serve metropolitan consumers in Kanto, Chubu, and Kinki, which together dominate cement use but bear a smaller share of production-side impacts. Internationally, about two-fifths of TMR is shifted to coal-exporting countries, with a recent shift from Russian to Australian and Indonesian coal raising shipping impacts.

Network and community-detection analysis shows persistent clusters of impact transfer and relatively stable core trade relationships over time, despite evolving demand and supply patterns. The paper is explicitly about telecoupling and metacoupling: it quantifies cross-scale linkages between Japanese consumption centers, domestic resource regions, and overseas fuel suppliers, and highlights how these connections shape the distribution of material and carbon burdens and the design of region-specific mitigation and logistics strategies.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong intracoupling within Japanese prefectures, plus pericoupling and telecoupling via interregional trade and coal imports.

### Intracoupling
#### Systems
- Cement plants, quarries, and power use within individual Japanese prefectures.
- Within-prefecture construction sectors using cement in buildings and infrastructure.
- Internal waste and byproduct recycling into local cement production.
#### Flows
- Local extraction and processing of limestone, clay, gypsum, and recycled materials.
- Within-prefecture cement distribution to building, infrastructure, and concrete producers.
- Local emissions and resource use from quarrying, kilns, and on-site power.
#### Agents
- Cement manufacturers and quarry operators in each prefecture.
- Local construction companies and concrete product producers.
- Prefectural governments setting local climate and resource policies.
#### Causes
- Prefectural construction and infrastructure demand for cement.
- Availability of local limestone deposits and industrial byproducts.
- National decarbonization and circular economy policies implemented locally.
#### Effects
- Local resource depletion and hidden material extraction around cement plants.
- Prefecture-level carbon emissions and air pollution from cement processes.
- Creation of local jobs and dependence on cement for economic activity.

### Pericoupling
#### Systems
- Japanese prefectures linked by inter-prefectural cement and limestone trade.
- Regional clusters such as Kyushu, Chugoku, Kanto, Chubu, and Kinki.
- Neighboring prefectures exchanging recycled wastes and clinker-based products.
#### Flows
- Cement shipments from production prefectures to nearby consumption hubs.
- Inter-prefectural transfers of limestone, silica stone, and coal-derived energy.
- Truck and coastal shipping flows between inland and coastal prefectures.
#### Agents
- Regional logistics companies operating trucks and domestic ships.
- Prefectural-level planners coordinating infrastructure and industrial siting.
- Industry associations aggregating regional cement and transport data.
#### Causes
- Spatial separation between limestone-rich areas and urban demand centers.
- Regional differences in production capacity and clinker plant locations.
- Cost-driven logistics choices and multi-modal transport networks.
#### Effects
- Displacement of TMR and carbon burdens from cities to resource regions.
- Regional carbon leakage and unequal responsibility for emissions.
- Formation of stable impact-transfer communities among neighboring prefectures.

### Telecoupling
#### Systems
- Japan’s cement sector and coal-exporting countries like Australia, Indonesia, Russia.
- International maritime shipping routes linking exporting ports and Japan.
- Global waste-plastic and alternative-fuel supply chains interacting with Japan.
#### Flows
- Imported coal, oil, and gas driving cement thermal energy and electricity.
- Embodied TMR and carbon in overseas resource extraction and long-distance shipping.
- Shifts in coal sourcing after geopolitical events altering maritime impacts.
#### Agents
- Foreign mining companies supplying fossil fuels to Japan.
- Shipping firms operating long-distance bulk carriers.
- National governments influencing trade via sanctions and export bans.
#### Causes
- Japan’s resource scarcity and high dependence on imported fossil fuels.
- Geopolitical shocks such as conflicts and export restrictions.
- Price advantages and logistics of overseas open-pit coal mining.
#### Effects
- Externalization of large shares of TMR and emissions to supplier countries.
- Increased maritime transport impacts when sourcing shifts to distant suppliers.
- Heightened vulnerability of Japan’s cement chain to international disruptions.

### Cross-Coupling Interactions
- Domestic cement demand triggers intracoupling production, pericoupled regional trade, and telecoupled fossil-fuel extraction.
- Geopolitical changes abroad reshape coal trade, altering both overseas and domestic transport impacts.
- Demand reductions in core cities propagate upstream to regional plants and foreign coal exporters.

### Research Gaps or Limitations
- Assumes local sourcing and simplified transport for recycled inputs despite complex inter-prefectural waste flows.
- Relies on global-average TMR coefficients, missing regional mining-intensity differences.
- Gravity-model and data gaps limit precision for inland trade and mode-specific transport patterns.

### Search Keywords
- Japan cement supply chain telecoupling TMR carbon footprint
- inter-prefectural cement trade coal imports Australia Indonesia Russia
- life-cycle multilayer network cement community detection

### Extraction Confidence
high
