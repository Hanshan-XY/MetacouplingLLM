# Quantifying Interregional Flows of Ecosystem Services to Enhance Water Security in the Yellow River

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:18:47.285434+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Zhang et al. - 2023 - Quantifying Interregional Flows of Ecosystem Services to Enhance Water Security in the Yellow River.pdf
- Year: unknown
- DOI: 10.1061/JWRMD5.WRENG-5891
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines how ecosystem services related to water move between regions within the Yellow River Basin in China, and how those interregional flows affect water security and equity. The work is explicitly framed in terms of telecoupling, focusing on spatial linkages among upstream and downstream areas within a single large watershed (a metacoupled system).

The authors analyze four water-related ecosystem services: water yield, flood mitigation, water purification (nitrogen retention), and soil retention. The geographic scope is the entire Yellow River Basin, with results aggregated at subbasin and provincial levels for the years 2000 and 2015. Ecosystem service supply is modeled using the InVEST suite (water yield, nutrient delivery, soil delivery) and empirical approaches for flood mitigation. Demand is constructed from socio-economic and environmental data, including agricultural, industrial, and residential water use, pollution discharges, population in floodplains, and soil loss reaching streams.

They first estimate local supply and demand at fine spatial resolution, then determine local surplus or deficit. Residual surpluses are routed downstream along hydrological flow paths to quantify interregional ecosystem service flows from upstream to downstream regions.

Results show that local ecosystems provide most services overall, but about one-third of the basin area depends primarily on upstream inputs, with more than half of service provision there originating from interregional flows. The spatial extent of these flow-dominated areas expanded between 2000 and 2015. Upstream provinces, especially Qinghai and Gansu, deliver the majority of water yield, flood control, pollutant retention, and soil retention to downstream beneficiaries, with the monetary value of these flows rising over time. Patterns of dependence differ among provinces, revealing clear donor-recipient relationships.

The study demonstrates that ignoring interregional flows underestimates both dependency and responsibility across administrative boundaries. It argues that quantifying actual flows, rather than only local potential supply, can better support telecoupled governance, guide ecological compensation schemes, and inform coordinated, basin-wide water and land management.

## Structured Metacoupling Extraction

### Coupling Classification
- Telecoupling of upstream ecosystem services supporting downstream water security
- Intracoupling and pericoupling within Yellow River Basin subbasins and provinces

### Intracoupling
#### Systems
- Local subbasins within the Yellow River Basin
- Provincial water and land management systems
#### Flows
- Local matching of water-related ecosystem service supply and demand
- Redistribution of services within individual subbasins
#### Agents
- Local residents and farmers using water resources
- Municipal and county water managers
#### Causes
- Urbanization and agricultural intensification increasing local water demand
- Land use change altering local ecosystem service supply
#### Effects
- Local water scarcity and pollution risks
- Changes in local flood and soil erosion regulation

### Pericoupling
#### Systems
- Neighboring upstream and downstream subbasins
- Adjacent provinces like Gansu and Ningxia
#### Flows
- Freshwater, flood mitigation, and purification between neighboring provinces
- Soil retention benefits moving to nearby downstream reaches
#### Agents
- Provincial governments negotiating water allocation
- Regional river basin authorities
#### Causes
- Hydrological connectivity along river networks
- Provincial economic development shaping regional water use
#### Effects
- Interprovincial dependence on regulating services
- Need for transboundary compensation and coordination

### Telecoupling
#### Systems
- Upstream ecological source regions in Qinghai and Gansu
- Downstream beneficiary regions in Ningxia, Inner Mongolia, Henan
#### Flows
- Interregional flows of water yield, purification, flood mitigation, soil retention
- Monetary value transfers via potential eco-compensation
#### Agents
- National policymakers designing basin-wide policies
- Ecosystem modelers quantifying service flows
#### Causes
- Spatial mismatch between service provision and beneficiaries
- Climate change and globalization increasing distant dependencies
#### Effects
- Strong downstream reliance on distant upstream ecosystems
- Equity debates over responsibility and compensation for exported services

### Cross-Coupling Interactions
- Local land use change in upstream alters regional and distant service flows
- Urbanization downstream reduces outward flows and increases imports

### Research Gaps or Limitations
- Models ignore groundwater and belowground ecological processes
- Human infrastructure and temporal dynamics of flows poorly represented

### Search Keywords
- Yellow River Basin interregional ecosystem service flows
- water security telecoupling flood mitigation purification soil retention

### Extraction Confidence
high
