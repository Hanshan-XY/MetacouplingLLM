# Measuring the potential for sustainable intensification of aquaculture in Bangladesh using life cycl

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:47:08.656901+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Henriksson et al. - 2018 - Measuring the potential for sustainable intensification of aquaculture in Bangladesh using life cycl.pdf
- Year: unknown
- DOI: 10.1073/pnas.1716530115
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This study examines how intensifying freshwater aquaculture in Bangladesh affects environmental sustainability, and what scope exists for more sustainable intensification. It focuses on pond-based fish and shrimp systems across major aquaculture districts in Bangladesh, a country where farmed fish now supply most fish consumed and land for further agricultural expansion is scarce.

The authors analyze 14 aquaculture production technologies using life cycle assessment (LCA), covering only the production stage. They use detailed survey data from 2,678 farms plus feed-industry surveys and secondary life cycle inventory databases. Environmental pressures are calculated per ton of live fish at farm gate for six impact categories: contribution to climate change, acidification, eutrophication, freshwater ecotoxicity, consumptive freshwater use, and land occupation. Intensification is represented by yield and farm-gate value per hectare.

Results show a complex pattern rather than uniform improvement or deterioration. Higher-intensity systems are associated with increased acidifying emissions, nutrient pollution, and toxic stress on freshwater organisms, largely driven by greater use of formulated feeds and fertilizers whose production relies on global agricultural inputs and pesticides. In contrast, more intensive farms use less freshwater per unit of fish because higher yields and shorter cycles reduce evaporation per ton produced. Climate impacts and total land occupation per ton show no clear relationship with intensity, but the location of impacts shifts: extensive systems affect mainly local ponds and surrounding landscapes, whereas intensive systems shift greenhouse gas emissions, land use, and ecotoxicity to distant crop and feed-production regions, often overseas.

Feed efficiency emerges as the main leverage point: better feed formulations, management, species and strain choices, and husbandry can reduce several impacts at once, although some trade-offs (e.g., energy use for aeration) remain. The paper explicitly addresses telecoupling and metacoupling by tracing how intensification in Bangladesh externalizes environmental burdens to other regions through globally traded feed ingredients, illustrating spatial burden shifting in a telecoupled food system.

## Structured Metacoupling Extraction

### Coupling Classification
- Study links local Bangladeshi aquaculture intensification with distant environmental impacts via globalized feed and input chains.

### Intracoupling
#### Systems
- Aquaculture ponds and ghers in Bangladesh producing carp, tilapia, pangasius, koi, shrimp, prawn, small fish.
- On-farm pond ecosystems, soils, and immediate surroundings affected by water use and emissions.
#### Flows
- Local water evaporation and withdrawals for ponds and integrated rice-fish systems.
- Nutrient discharges, chemicals, and methane emitted directly from ponds.
- Use of manures, fertilizers, and farm-made feeds sourced from nearby agriculture.
#### Agents
- Bangladeshi fish farmers operating 14 production technologies.
- Local feed mixers, small mills, and input retailers.
- National research and development organizations and extension projects.
#### Causes
- Rising domestic demand for fish protein and food security goals.
- Limited land for horizontal expansion, pushing intensification.
- Adoption of fertilizers, supplementary feeds, and improved strains.
#### Effects
- Increased local eutrophication, acidification, and ecotoxicity with higher input use.
- Lower freshwater consumption per ton fish due to higher pond productivity.
- Shifts in methane and nutrient dynamics within ponds and adjacent fields.

### Pericoupling
#### Systems
- Bangladesh aquaculture areas and nearby agricultural landscapes producing feed crops.
- Coastal aquaculture zones and neighboring mangroves, wetlands, and rice fields.
#### Flows
- Regional nutrient runoff from ponds to adjacent waterways.
- Pesticides and therapeutants moving from surrounding agriculture into aquatic habitats.
- Effluents discharged into nearby rivers, canals, or coastal waters.
#### Agents
- Regional crop farmers supplying rice bran, oilcake, and other ingredients.
- District-level feed factories and transporters.
- Local regulators managing water quality and land use.
#### Causes
- Spatial concentration of fish farms in high-production districts.
- Expansion of pond area into agricultural and coastal lands.
- Regional clustering of feed manufacturing and logistics.
#### Effects
- Localized water quality degradation and toxicity hotspots.
- Competition for freshwater between ponds and irrigated crops.
- Loss or alteration of nearby rice fields, wetlands, and coastal ecosystems.

### Telecoupling
#### Systems
- Bangladesh aquaculture value chains and distant feed-crop regions overseas.
- Export-oriented shrimp and prawn farms and foreign consumer markets.
- Global input industries supplying energy, fertilizers, and chemicals.
#### Flows
- Embedded land and water use in imported soy, wheat, and other feed ingredients.
- Greenhouse gases, acidifying and toxic emissions from foreign crop and feed production.
- Exported seafood products transported and processed for international markets.
#### Agents
- International feed ingredient producers and traders.
- Foreign consumers and retailers purchasing Bangladeshi shrimp and prawn.
- Multinational input suppliers and shipping companies.
#### Causes
- Global demand growth for animal protein and seafood.
- Reliance on globally traded feeds to intensify production.
- Economic incentives favoring export of high-value aquaculture products.
#### Effects
- Spatial shifting of land occupation and pollution to other countries and continents.
- Potential deforestation and biodiversity loss in distant feed-source regions.
- Increased vulnerability to international commodity price volatility.

### Cross-Coupling Interactions
- Intensification moves impacts from local ponds to regional fields and distant crop lands.
- Land-scarce Bangladesh reduces local land pressure while externalizing land and toxicity burdens abroad.
- Exported shrimp link foreign consumer choices to Bangladeshi farm intensification and global supply chains.

### Research Gaps or Limitations
- Study excludes post-farm processing, distribution, and consumption stages of seafood chains.
- Farm energy use and some chemotherapeutant data missing, likely underestimating several impacts.
- Social and economic outcomes of intensification and cross-sector food-system interactions not assessed.

### Search Keywords
- Bangladesh aquaculture intensification life cycle assessment telecoupled feed impacts
- sustainable intensification fish farming spatial burden shifting
- aquaculture LCA eutrophication ecotoxicity freshwater consumption land occupation

### Extraction Confidence
high
