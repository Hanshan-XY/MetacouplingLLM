Paving the Ground for Biodiversity-Positive Transformative Change in Fashion: An Exploration of Drivers of Biodiversity Loss and Barriers to Transformative Change in the Textile, Apparel, and Fashion Sector

RESEARCH ARTICLE

PEDRO NAVARRO-GAMBÍN $\textcircled{1}$

MARTA BONETTI $\textcircled{1}$

MATTEO VILLA

GIANLUCA BRUNORI $\textcircled{1}$

DANIELE VERGAMINI $\textcircled{1}$

]u[ubiquity press

*Author affiliations can be found in the back matter of this article

# ABSTRACT

Biodiversity-positive transformative change requires transformations at the societal level and transitions in specific sub-systems directed at addressing the indirect drivers of biodiversity loss. Despite the recognised need to target the sectors most responsible for nature’s decline, the dynamics of biodiversity loss and biodiversity-positive transformative change in the textile, apparel, and fashion sector have never been directly studied by academic contributors. This explorative study maps direct and indirect drivers of biodiversity loss in fashion’s supply chain activities and identifies barriers for transformative change to reflect on the potential direction of a biodiversity-positive transformation of the sector. We base our mapping on the qualitative thematic content analysis of semi-structured interviews with experts from the fashion sector in Italy and grey literature publications. Our results suggest that land-use change due to raw material production is the direct driver to which the industry contributes the most, while economic indirect drivers are the most influential for determining the intensity and distribution of the direct drivers. We identify seven barriers to biodiversity-positive transformative change: i) the ideology of perpetual growth, ii) fashion consumerism, iii) telecouplings, iv) rigid political boundaries, v) uncoordinated institutions and policies, vi) lack of understanding, human capital and measuring, and vii) poor availability of biodiversity-positive technologies. Moreover, we reflect on the direction of transformative change by addressing these drivers beyond panaceas, simple interventions, and single governance levels. Finally, we identify the absence of attention to power relations and equity as a potential obstacle to biodiversity-positive transformative change in fashion. Rather than a systematic and conclusive research endeavour, this study must be seen as a starting point from which further discussions can be developed to promote a transformative governance of biodiversity in fashion.

# CORRESPONDING AUTHOR: Pedro Navarro-Gambín

Pisa Agricultural Economics (PAGE), Department of Agriculture, Food and Environment (DAFE), University of Pisa (UNIPI), Pisa, IT p.navarrogambin@gmail.com

# KEYWORDS:

biodiversity; transformative change; transformative governance; biodiversity loss drivers; textile, apparel and fashion (TAF); sustainable fashion

# TO CITE THIS ARTICLE:

Navarro-Gambín, P., Bonetti, M., Villa, M., Brunori, G., & Vergamini, D. (2025). Paving the Ground for Biodiversity-Positive Transformative Change in Fashion: An Exploration of Drivers of Biodiversity Loss and Barriers to Transformative Change in the Textile, Apparel, and Fashion Sector. International Journal of the Commons, 19(1), pp. 322–341. DOI: https://doi. org/10.5334/ijc.1458

# A. INTRODUCTION

The intensity of the current global biodiversity loss crisis has led numerous scientists and activists to call for biodiversitypositive transformative change, i.e., a fundamental systemwide reorganisation to halt and reverse biodiversity loss (Chan et al., 2020; IPBES, 2019a; M. Kok et al., 2022; Pascual et al., 2023; Visseren-Hamakers et al., 2021). That call has been reinforced by the abundant evidence showing that biodiversity policies and governance arrangements1 have been insufficient (Cardona Santos et al., 2023; Coffey et al., 2023; de Koning et al., 2023; Dupuis et al., 2023; Otero et al., 2020; Petersson & Stoett, 2022; Wyborn et al., 2021). As argued by Smallwood et al. (2022, p. 60), that governance seems “unable to confront the economic, political and social paradigms that drive the destruction of biodiversity globally”. Those economic, political, and social paradigms have also been called ‘indirect drivers’ of biodiversity loss, i.e., “the ways in which people and societies organize themselves and their interactions with nature at different scales” (Díaz et al., 2015, p. 6). Moreover, it has been argued that transformative change can and should be governed and directed at addressing the indirect drivers of biodiversity loss (IPBES, 2024a; Visseren-Hamakers & Kok, 2022). This implies going beyond panaceas to recognise that the governance of complex socio-ecological issues cannot be reduced to single solutions, governance levels, or dimensions (Ostrom et al., 2007; Ostrom & Janssen, 2005). However, the conversation about how to govern transformative change is at its infancy (Korhonen-Kurki et al., 2025; Penca, 2023).

This explorative study contributes to the debate about biodiversity-positive transformative change by analysing the connection between biodiversity loss and the textile, apparel, and fashion (TAF) sector.2 Transformative change refers to macro transformations at the societal level, but also requires transformations in specific sub-systems, e.g., the global economic sectors most responsible for nature’s decline (IPBES, 2024a; M. Kok et al., 2022; Linnér & Wibeck, 2019). Despite this, to our knowledge, this is the first academic study that explicitly addresses the topic of biodiversity in the fashion sector. We argue that the fashion sector is potentially relevant for biodiversity-positive transformative change for several reasons. Fashion has been described as a complex socio-ecological system, in which its material dimension (i.e., environmental resource use, fibre and material production) interacts with broad socio-economic and cultural dynamics that co-produce unsustainable patterns of production and consumption (Leventon et al., 2024; Palm et al., 2021). Fashion has a critical role in the global economy as one of the oldest and wealthiest manufacturing sectors, which has contributed

and accelerated economic globalisation and many of its negative socio-ecological outcomes, e.g., cultural homogenisation and impoverishment, labour exploitation, GHGs emissions, deforestation, water pollution (Bertola & Colombi, 2024; Moran et al., 2021; Niinimäki et al., 2020). Therefore, the fashion sector could potentially intensify the direct drivers of biodiversity loss (e.g., climate change, pollution) at the same time it reproduces some of its indirect drivers, e.g., unsustainable production patterns. Given fashion’s complex and systemic nature, the problems caused by the fashion system cannot be reduced to single causes or resolved with simple interventions (Palm, 2023). In other words, fashion needs transformative change and governance to reduce its potential pressures on biodiversity.

This study makes two contributions to define a starting point to discuss biodiversity-positive transformative change in fashion and the potential direction of its governance. First, we map and assess direct and indirect drivers of biodiversity loss connected to the main fashion value chain (FVC) activities to show the main dynamics through which the fashion sector contributes to biodiversity loss. Inspired by the Intergovernmental Science-Policy Platform on Biodiversity and Ecosystem Services’ (IPBES, 2019a) explanation of the causes of biodiversity loss, we include direct drivers in our analysis because indirect drivers can just be defined in their interaction with the direct ones. This approach is based on the assumption that the governance of transformative change “should be based on a thorough understanding of the dynamics of, and interactions among, the main indirect drivers underlying a physical environmental problem in a specific context, and should aim to address these indirect drivers” (Visseren-Hamakers et al., 2021, p. 24). Second, starting from the evidence about our mapped indirect drivers, we identify potential barriers to biodiversity-positive transformative change in fashion. To do this, we use the list of barriers already defined by IPBES Transformative Change Assessment (IPBES, 2024a) as an heuristic tool, and then we further explain their specificity in the context of the fashion sector. We base our mapping of drivers on the qualitative thematic content analysis of grey-literature documents from business associations, NGOs, and civil society organisations that have recently addressed the topic of fashion and biodiversity, and semistructured interviews with fashion experts in Italy.

The paper is structured as follows. Section B introduces our theoretical framework, including biodiversity, drivers of biodiversity loss, transformative change, and the transformation of fashion. Section C presents our analytical framework and the main methods and materials we used. Subsequently, Sections D, E, and F respectively present our results about direct drivers, indirect drivers, and barriers. In Section G, we discuss data gaps, future directions for

research, the study’s limitations, and the possibility to tackle the identified barriers as a starting point to direct biodiversity-positive transformative change in fashion. Finally, in Section F, we present our conclusions.

# B. THEORETICAL FRAMEWORK

# A. BIODIVERSITY

In this research, we take a ‘normativist’ approach in defining biodiversity as a holistic concept to recognise the variety of life on Earth,3 which has served scientists to communicate about the preservation of that variety as a desirable social goal (Sarkar, 2017, 2019; Turnhout & Purvis, 2020). The concept was officially embraced in the international science-policy interface when the UN Convention on Biological Diversity (CBD) entered into force in 1993 (Convention on Biological Diversity, 1992; Farnham, 2017). Rather than an intrinsic property of nature, biodiversity is a complex and multidimensional concept for which it seems impossible to find a unitary definition, indicator, or measurement level (Keune et al., 2022; Newman et al., 2017). There is a multiplicity of valid biodiversity definitions and measurements (e.g., genetic diversity, species diversity), and none of them is neutral: they all have underlying assumptions, goals and interests about what part of nature should be protected, why, and how (Díaz & Malhi, 2022; Pascual et al., 2021). Notwithstanding the multidimensional and normative nature of biodiversity, we start from scientific evidence to describe the current trends of global biodiversity loss.

# B. BIODIVERSITY LOSS

It is well-established that the degradation of terrestrial, freshwater, and marine ecosystems due to human activities in the last decades has driven a quantitative and qualitative decline of global biological diversity both in terms of components and ecosystem goods and services (Díaz & Malhi, 2022; IPBES, 2019a; Rockström et al., 2023; WWF, 2022). Biodiversity loss is a planetary boundary far surpassed beyond the safe operating space for humanity (Mace et al., 2014; Rockström et al., 2009). Approximately 1 million species (i.e., average of $2 5 \%$ of total species) are now threatened with extinction (IPBES, 2019a); while there is an average decline of $6 9 \%$ in species populations since 1970 (WWF, 2022). Biodiversity loss is mediated by both direct and indirect anthropogenic factors or drivers. Direct drivers, e.g., land-use change, have a direct physical (mechanical, chemical, etc.) and behaviour-affecting (disturbance, etc.) impact on nature (IPBES, 2019a; Jaureguiberry et al., 2022; Millennium Ecosystem Assessment, 2005). Indirect drivers, e.g., patterns of production and consumption, are “the

ways in which people and societies organize themselves and their interactions with nature at different scales” (Díaz et al., 2015, p. 6), which interact to alter and influence direct drivers.

# C. DELIBERATE TRANSFORMATIVE CHANGE

Conceptualisations of societal sustainability transformations are multiple, e.g., socio-ecological transitions, transformative adaptation, deliberate change (Feola, 2015). Although all approaches agree that transformations involve non-linear and non-teleological changes that bring about a fundamentally new system, each approach involves distinct assumptions about what is to be defined as ‘transformative’ and how change comes about (Chaffin et al., 2016; Fisher et al., 2022). In our case, we focus on transformative change as “a fundamental, system-wide reorganisation across technological, economic and social factors, including paradigms, goals and values” (IPBES, 2019b). Although we recognise the inherent complexity and unpredictability of transformative change processes, we embrace a ‘problem-based’ or ‘transformational social sciences’ approach in assuming that change can be partially directed and governed: it is possible to hypothesise specific outcomes for change to be considered transformative and ways to achieve that change (Feola, 2015; Linnér & Wibeck, 2019).

Furthermore, transformative change involves societywide transformations as well as transformations in specific sub-systems (M. Kok et al., 2022; Linnér & Wibeck, 2019). Specifically, transformations in global economic sectors, e.g., fashion, require attention, since ‘driving systemic change in the sectors most responsible for nature’s decline’ and ‘transforming economic systems for nature and equity’ have been identified as key strategies to bring about transformative change (IPBES, 2024a). We follow the deliberate transformative change approach in assuming that transformative change should be directed at addressing the indirect drivers of biodiversity loss (IPBES, 2024a; Smallwood et al., 2022; Visseren-Hamakers et al., 2021). Moreover, we further follow IPBES (2024a) in considering the barriers to transformative change (Appendix 1) as potential entry points to catalyse that change if directed at addressing the indirect drivers, although they should not be addressed in isolation. These assumptions informed our choice to focus on indirect drivers in our mapping, and to identify barriers to transformative change in fashion connected to them. Furthermore, we agree that, to study deliberate transformative change, specific attention must be granted to power relations and equity to avoid reproducing the current status quo of unsustainable discourses and practices. Unless this is done, risks are multiple, e.g., the co-optation of transformative

processes by powerful actors with vested interests (Blythe et al., 2018; Massarella et al., 2021), the reproduction of the epistemological and normative exclusion of Global-South an indigenous peoples’ knowledge and values (Lele, 2021; Zafra-Calvo et al., 2020), or shifting the burden and costs of transformations to vulnerable parties (Blythe et al., 2018).

# D. THE TRANSFORMATION OF FASHION

Despite the arguments we mentioned in the introduction to justify the relevance of studying the dynamics of biodiversity loss in fashion, to our knowledge, the fashion sector has never been academically studied in explicit connection to biodiversity. Several fashion-specific and sustainability-related topics have been studied in the last years, e.g., environmental impact (Munasinghe et al., 2021), circular fashion (de Aguiar Hugo et al., 2021), or sustainable consumer behaviour (Khan et al., 2023), but the fashion sector has only recently been addressed by transformation theorists. Since fashion could be seen as a complex system, involving multiple globalised production processes and cultural elements, nested within broader ecological, socio-economic and political systems, it has been argued that the sector makes an excellent example to study transformations at different levels (Leventon et al., 2024). Recent studies have analysed the ‘fashion system’ through the lenses of ‘socio-ecological systems’ (Palm et al., 2021), sustainability transitions (Buchel et al., 2022; Dzhengiz et al., 2023), or sustainability transformations (Beyers, 2024; Leventon et al., 2024), but none has focused on biodiversity or deliberate transformative change.4

The results of the abovementioned studies help us hypothesise potential indirect drivers playing a role in the impact of fashion on biodiversity, as well as barriers to biodiversity-positive transformative change. Starting with economic drivers, the socio-ecological unsustainability of the fashion system has been connected to the growing volumes of fashion consumption and production driven by a paradigm of economic growth (Buchel et al., 2022; Leventon et al., 2024; Palm et al., 2021). Consequently, it has been argued that sustainable fashion “is not about the relative benefits of fibres and textiles as such, it is about altering the quantity of fibres and textiles being produced” (Palm et al., 2021, p. 663). Therefore, we expect ‘patterns of consumption and production’ to be a relevant driver. Additionally, we expect to identify economic barriers, e.g., ‘the ideology of economic growth’, posing challenges to transformative change in fashion. Moreover, the unequal distribution of the economic benefits and the negative social outcomes present in global FVCs (e.g., poor working conditions, violations of labour rights, low wages, child labour, modern slavery, or cancer risks due to carcinogenic human toxicity) have also been reflected upon in the

literature within discussions about the current climate crisis, with the goal of understanding the dynamics of a ‘just ecological transition’ (Bonelli et al., 2024; Dzhengiz et al., 2023; Karaosman & Marshall, 2023). Therefore, we expect economic drivers connected to trade, and barriers connected to unequal power and socio-economic relations, e.g., ‘socio-economic disparities’ or ‘international monetary system constraining policy autonomy’ to be relevant to explain the impact of fashion on biodiversity. Finally, concerning governance drivers, there is a growing recognition that the focus on individual voluntary and managerial-based governance (e.g., CSR, certification schemes) has failed to tackle the negative socio-ecological outcomes of the fashion system, which has opened the door to discussing collective governance initiatives and legallybinding fashion-related legislation (Beyers et al., 2023; Hileman et al., 2020). Therefore, we expect governance drivers and barriers, e.g., ‘uncoordinated institutions and policies’, to be relevant to understand the impact of fashion on biodiversity and the potential challenges to achieve transformative change.

# C. METHODOLOGY

This study is integrated within the EU funded project PLANET4B5 as a specific case study focusing on potential biodiversity-positive transformations in the fashion sector. It starts from a group of researchers at the University of Pisa who share the assumption that the preservation of biodiversity is a desirable and inevitable social goal because of its intrinsic and relational value, as well as its important contributions to people.

# A. ANALYTICAL FRAMEWORK

The decision to undertake an exploratory mapping of drivers was motivated by the fact the topic of biodiversity loss in the fashion sector has been almost completely neglected in the academic literature.6 We included indirect drivers as the core of the analysis because of the central role they play in driving biodiversity loss and the importance they are attributed for transformative change. Indirect drivers can only be defined in their interaction with the direct drivers (Díaz et al., 2015), so we included direct drivers in the mapping. Table 1 presents the typology of drivers that we use to structure our mapping.

To identify potential barriers for biodiversity-positive transformative change, we started from the barriers defined in IPBES Transformative Change Assessment (see summary in Appendix 1) as a heuristic. Then, we explained their specificity in the fashion sector based on our results.

To integrate the fashion sector within our analytical framework, we followed IPBES (2019a) in placing fashion

Table 1 Direct and indirect drivers of biodiversity loss with examples. Source: authors’ compilation based on IPBES (2019a).   

<table><tr><td>DRIVERS</td><td>TYPES</td><td>EXAMPLES</td></tr><tr><td rowspan="5">Direct</td><td>Land/sea-use change</td><td>Expansion of agriculture</td></tr><tr><td>Overexploitation of plants and animals/ Resource Extraction</td><td>Freshwater withdrawals</td></tr><tr><td>Pollution</td><td>Contaminants in water</td></tr><tr><td>Climate Change</td><td>Temperature rise</td></tr><tr><td>Invasive alien species (IAS)</td><td>Pressures on native species</td></tr><tr><td rowspan="5">Indirect</td><td>Inadequate Sociocultural and Social Values7</td><td>Instrumental human-nature values</td></tr><tr><td>Economic</td><td>Increased material consumption 
Concentrated production</td></tr><tr><td>Governance</td><td>Uncoordinated conservation policies</td></tr><tr><td>Demographic</td><td>Lack of human capital (e.g., education, skills)</td></tr><tr><td>Technological</td><td>Technological changes in primary sectors (e.g., agriculture)</td></tr></table>

as one of the human activities or sectors linking direct and indirect drivers of biodiversity loss. The fashion sector involves different processes with different potential impacts on

biodiversity, therefore we looked at its value chain (Figure 1), i.e., “the full range of activities that firms and workers perform to bring a [fashion] product from its conception to end use and beyond” (Gereffi & Fernandez-Stark, 2016, p. 7). A first evaluation of our data sources showed that data was only available for supply-chain activities, i.e., processes of transforming raw materials to components to final products that are finally delivered to consumers, therefore we decided to specifically focus on those activities for our mapping. In Appendix 2, we summarise the activities we included in our analysis based on Munasinghe et al. (2021) and Niinimäki et al. (2020). A summary of our analytical framework can be found in Figure 2.

# B. METHODS AND MATERIALS

According to IPBES (2019a), quantitative assessments of indirect drivers are complicated because they tend to be diffuse and interact with each other and with the direct drivers to result in biodiversity losses or gains, therefore quantitative causal relationships are difficult to infer. We chose a qualitative approach to be able to narratively explain these interactions as well as identifying barriers to transformative change, although quantitative indicators are used to support the presentation of our results. Our mapping is based on the qualitative analysis of two main data sources:

Semi-structured expert interviews $( \mathsf { N } = 1 2$ ) conducted in June and July 2023. The experts belonged to organisations engaged in the promotion of sustainable fashion practices

![](images/c5372f0b3b74478a1e8723636e852db40250f912bce8d877aa000a99d604d948.jpg)  
Figure 1 Fashion Value Chain. Source: Frederick & Cassill (2009).

![](images/21d8e98aad7377c36b5ed05b0b04ed60b716757f89c1c5e1dcd8637a74b86939.jpg)  
Figure 2 Summary of our analytical framework. White arrows represent interactions and feedbacks. Source: own making based on IPBES (2019b).

or biodiversity-focused policies in Italy. Based on the Quintuple Innovation Helix model for transdisciplinary analysis of sustainable development (Carayannis & Campbell, 2010), our final sample included actors from academia, public and private sector, civil society organisations (CSOs), and journalism. The interviews were recorded and subsequently transcribed and anonymised. The list of interviewees can be found in Appendix 3.

Grey-literature publications $( \mathsf { N } = 1 2 ^ { \cdot }$ ) from civil society organisations, business associations, and environmental NGOs from 2016 to 2023. To select the sample, we conducted a Google search using the keywords (“Biodiversity” AND “Fashion”) and (“biodiversity” AND “textile industry”) and collected references from our interviews to preliminary extract 27 articles and reports written in English. We eliminated redundant documents and those not explicitly addressing the topic of biodiversity. The final list of publications can be found in Appendix 4.

The interview transcriptions and the publications were coded and submitted to qualitative thematic content analysis using the software Atlas.ti. Relevant text sections were selected and divided into ‘direct drivers’ and ‘indirect drivers’ and further classified using the typologies we presented in Table 1. ‘Indirect drivers’ text sections were further reviewed to identify barriers following the categories presented in Appendix 1. We triangulated the data by using some of the literature reviews we had selected in the previous steps of the research8 and further sources referred by the grey-literature publications. Findings about direct drivers are summarised in the next section. Findings about indirect drivers and barriers are reported narratively due to

their abovementioned characteristics. A summary of our results can be seen in Figure 3.

# D. RESULTS: DIRECT DRIVERS

Table 2 shows the three main direct drivers we found in our data (i.e., land-use change, pollution, and climate change), the supply chain activities where those drivers appear, the contribution of fashion to the drivers, and the impact on biodiversity loss. Our results suggest that land-use change is the main direct driver of biodiversity loss to which fashion contributes. Despite the overexploitation of natural resources and invasive alien species are relevant drivers according to IPBES (2019b), they are almost completely absent from our data. The contribution of fashion to landuse change are reported by type of material, while the contributions to pollution and climate change are reported by supply chain activity. Raw material extraction seems to be the most impactful stage, followed by manufacturing, end-of-life, and use. Although transport and retailing could be contributors to climate change, explanations of their contribution to biodiversity loss were absent from our data.

# E. RESULTS: INDIRECT DRIVERS

All the interviewees mentioned indirect drivers as the root causes of biodiversity loss connected to TAF industries. Greyliterature documents 7, 8, 10 and 12 explicitly mention these drivers, every publication implicitly mentions some of them.

![](images/242297ed7533a56e9472cfcd9d20cb99b249ee8d98856bba7f7ba89db22688e0.jpg)  
Figure 3 Summary of results.

Table 2 Key findings on direct drivers at the intersection of fashion and biodiversity.   

<table><tr><td>DIRECT 
DRIVERS</td><td>LAND USE CHANGE (LUC)9</td><td>POLLUTION (MAINLY WATER 
POLLUTION)10</td><td>CLIMATE CHANGE11</td></tr><tr><td>Supply chain 
activity</td><td>Raw material extraction stage</td><td>Manufacturing and (in lesser extent) raw 
material extraction, consumer use, and 
product&#x27;s end-of-life</td><td>Difficult to establish due to global 
interconnections</td></tr><tr><td>Contribution 
of the fashion 
industry</td><td>General: 35% more land projected for 
raw material production by 203012 
Plant-based fibres: cotton uses 2.5% of 
global cropland; 73% irrigated fields; 
10,000–20,000 litres of water per kg13 
Animal fibres/materials (e.g. leather): 
26% of the planet&#x27;s ice-free land used 
for grazing; 33% of cropland for feed 
production14 
MMCFs (e.g. viscose): 150 million trees 
logged annually, 30% from endangered, 
50% from uncertified forests15</td><td>Whole textile, apparel and fashion industry: 
93 billion cubic meters of water usage and 
20% of global water waste,16 4% of global 
water withdrawal,17 7% of groundwater and 
drinking water losses globally18 
Manufacturing (textile dying and treatment): 
toxic chemical and microplastics in water;19 
20–25% of global industrial water pollution.20 
Chemical release in air and ground21 
Raw material extraction: cotton cultivation 
(pesticide and fertiliser pollution, 22.5% 
of global insecticide use, 10% pesticide 
use)22, livestock (water pollution by manure, 
antibiotics, hormones, fertilizers)23 
Consumer use: microplastic release through 
washing, 35% of microplastics in oceans 
come from textiles24</td><td>General: fashion drives GHG emissions 
and accelerates climate change. 1.7 
billion tons of CO2, 8–10% of global 
GHG emissions;25 fourth largest 
emitting sector;26 70% of GHG 
emissions stem from raw material 
extraction and manufacturing27 
Manufacturing: 2/3 of that 70% are 
associated with synthetic material 
production and manufacturing.28 
Energy intense processes (e.g., leather 
tanning)29 
Raw material extraction: fossil fuels 
(i.e., for fertilisers and pesticides); land 
use change, expansion of cultivation 
and grazing; emissions from livestock30 
Consumer use: energy use in washing, 
dying, ironing31 
End-of-life: landfills and incineration 
releasing GHGs32</td></tr><tr><td>Impact on 
biodiversity</td><td>Plant-based fibres: ecosystem conversion, 
habitat fragmentation, land erosion, loss 
of soil quality 
Animal fibres/materials: expansion of 
rangeland, habitat conversion and 
fragmentation, soil degradation; decline of 
species, soil microbes and organic matter 
MMCFs: deforestation (e.g., Canada, 
Brazilian Amazon); less food, shelter, and 
breeding habitat for animals; changes in 
nutrient and soil acidification for plants</td><td>Manufacturing: contaminations of waterways, 
destruction of freshwater and marine habitats 
Raw material extraction: cotton cultivation 
(contamination of soil and water, destruction 
of insect populations, reduction of soil 
microorganisms), livestock (pollution of 
water and land, oxygen depletion of aquatic 
ecosystems, soil and water acidification; 
species loss) 
Consumer use: microplastic and detergent 
pollution impacting freshwater and marine life</td><td>Sea level rise leading to vulnerability 
of coastal areas and wetlands, habitat 
reduction 
Changes in temperature and extreme 
events affect species behaviour and 
ecosystem functions</td></tr></table>

# A. ECONOMIC DRIVERS

All sources consider economic indirect drivers as the most impactful.33 We identified two main economic drivers:

# i. Production and consumption patterns: material resource use intensification

All interviewees regard the increment in material resource use, in combination with a linear economic model, as the biggest driver of biodiversity loss. It generates a dynamic of overproduction (i.e., more production than consumption, high amount of waste) and overconsumption (i.e., more consumption than needed, short use time, quick disposal) of fashion. It intensifies the direct drivers of land-use change, overexploitation of natural resources, pollution, and climate change by intensifying raw material and input sourcing, resource use, industrial manufacturing, and the amount of produced waste.

# 1. Overproduction

Global fibre production has increased from 58 M tons in 2000 to 116 in 2022 and is projected to grow to 147 M tons in 2030.34 Per-capita fibre and textile production have increased from $8 . 3 ~ \mathsf { k g }$ in 1975 to $1 4 . 6 ~ \mathsf { k g }$ in $2 0 2 2 ^ { 3 5 }$ and from $5 . 9 \ \mathsf { k g }$ in 1975 to $1 3 \ \mathsf { k g }$ in 2018,36 respectively. Yearly production of textile waste is estimated in 92 M tons.37 Preconsumer textile waste (i.e., production waste) accounts for $1 0 { - } 1 5 \%$ of the total fabric used.38 Regarding recycling, $12 \%$ of textile waste is downcycled and less than $1 \%$ is closed loop recycled, i.e., recycled into the same or similar quality applications.39 Moreover, $73 \%$ of the fibre produced in 2015 was incinerated or disposed in landfills.40

# 2. Overconsumption and consumer preferences

Europeans consumed $2 7 \ k \ g$ of textiles per-capita in 2017.41 This high consumption is influenced by lower relative prices driven by the increased production efficiency and per-capita income. E.g., average per-capita expenditure on clothing and footwear in the EU and UK has decreased from $30 \%$ of the total household expenditure in the 1950s to $5 \%$ in 2020.42 The low prices intensify the increased consumption, speed, and quicker obsolescence of items. E.g., between 2000 and 2015, the time of use of clothes globally decreased by $3 6 \%$ ;43 between 2000 and 2015, consumers disposed $60 \%$ of their clothes within a year of buying them.44 Furthermore, overconsumption was partially fostered by changes in consumer preferences towards a ‘consumerism culture’, valuing immediacy and novelty, and disregarding recycled and reused clothes.45

# 3. Fast fashion

Overproduction and overconsumption are connected with the ‘fast fashion’ business model, i.e., “a fashion, textile and

apparel industry business model often characterised by prioritising quick turnover, high volumes and cheap prices, leading to intensive natural resource use and associated impacts and dependencies” (CISL, 2023, p. 7). The speed and short-term vision of such model is incompatible with the necessary long-run vision to implement changes to preserve and regenerate biodiversity.46 Fashion companies have intensified this dynamic with marketing strategies and an increment in the number of fashion seasons from two to as many as several dozen.47 E.g., from 2000 to 2011, Zara released 24 collections a year; H&M released between 12 and 16.48 Moreover, the importance of consumer perception and companies’ environmental reputation create the risk of companies making false environmental claims, i.e., greenwashing.49 However, the extent of greenwashing for fashion businesses regarding biodiversity remains unexplored.

# ii. Trade dynamics: global and fragmented FVCs

The lengthening and fragmentation of global value chains and the increased flows of goods and materials are global dynamics critically affecting FVCs.50 Our data does not suggest a well-established connection between FVC’s trade dynamics and an increased biodiversity loss. However, those dynamics seem to influence its global distribution by outsourcing environmentally harmful production processes and their consequences on the direct drivers of biodiversity loss (i.e., displaced land-use change, water pollution, and waste).51 The vertical disintegration and global dispersion of FVCs’ productive processes is motivated by operational reasons (e.g., proximity to natural resources), the search for a convenient labour force (i.e., cheaper, less rights, less protection), and more flexible environmental regulations.52 Consequently, the main locations of raw material extraction and manufacturing (e.g., China, Pakistan, Bangladesh, India, Mexico, Brazil, Cambodia, Turkey) are far away from the main consumption hubs (oversimplified, the US and Europe). E.g., $90 \%$ of fast fashion is produced in low-middle income countries,53 approximately $80 \%$ of finished textiles consumed in the EU are manufactured outside of the EU.54 However, those production locations disproportionally suffer the consequences of the direct drivers of biodiversity loss, e.g., the ten rivers that carry more than $90 \%$ of the plastic waste that ends up in the oceans, e.g., Mekong, Ganges, Nile, are in low-income countries with high intensity of clothing manufacturing.55 Moreover, the disconnection between producers and consumers makes FVCs very opaque for companies, consumers, and legislators.56

# B. GOVERNANCE DRIVERS

Governance drivers are regarded as a key driver of biodiversity loss when policies are inexistent, weak, or

badly designed and implemented. All grey-literature publications argue that there could be strong incentives for fashion businesses to implement biodiversity policies (e.g., operational, regulatory, or financial motivations). Three main levels of governance are relevant:

# i. State and inter-state legislation

Interviewees 2, 3, 5, 6, 8, 9, 10, 11 and 12 consider weak environmental and labour legislation, along with easy access to and ownership of natural resources, as a driver of biodiversity loss and the globalisation and fragmentation of FVCs. Recent EU strategies regarding the fashion sector, i.e., the EU Strategy for Sustainable and Circular Textiles (EU Strategy for Sustainable and Circular Textiles, 2022) and the Transition Pathway for the Textiles Ecosystem (2023), hardly mention biodiversity (i.e., once each) and do not address biodiversity loss. However, our sources point at recent and forthcoming EU legislative action (announced, proposed, and passed) with potential to address some indirect drivers, for example, consumer awareness and marketing, e.g., ‘Green Claims Directive’; trade, e.g., EU Deforestation Regulation (EUDR), Corporate Sustainability Due Diligence Directive (CSDDD); or labelling and product design, e.g., Eco-design for Sustainable Products Regulation, Digital Product Passport.57

# ii. Global Coordination

The Kunming-Montreal Global Biodiversity Framework (GBF) from December 2022 commits governments to adopt policies to halt and reverse biodiversity loss by 2030. Target 15 calls for the mandatory assessment and disclosure of businesses’ risks, impacts and dependencies on nature. However, the potential impact for the TAF sector remains unknown (i.e., its specifics will depend on national biodiversity strategies).58

# iii. Voluntary and managerial-based governance

Certification schemes, sustainability labels, and thirdparty valuation and standards have been common market-based sustainability governance tools in FVCs for years (e.g., Global Organic Textile Standard, Better Cotton Initiative, Ethical Trading Initiative).59 The only existing initiative with a specific focus on biodiversity and fashion is the Textile Exchange Biodiversity Benchmarking (Textile Exchange, 2021). Multistakeholder initiatives (MSIs), e.g., the German Partnership for Sustainable Textiles, have not historically focused on biodiversity. Some Responsible Business Initiatives (RBIs), e.g., the Fashion Pact or Business for Nature, are recently including biodiversity in their agreements. Moreover, voluntary sustainability disclosure schemes specifically focused on biodiversity, i.e., Science-Based Targets for Nature (SBTN), are currently on

trial. Front-running individual companies have developed biodiversity strategies and impact assessments, e.g., the Kering Group and H&M.

# C. DEMOGRAPHIC DRIVERS

# i. Human capital

Our data suggests that human capital (i.e., formation, knowledge, human capabilities, skills, or environmental education) is an important driver of biodiversity loss and a positive driver of change if developed in the future. Biodiversity management is a complex multidimensional environmental issue requiring broad knowledge about ecological interactions, and the impacts and dependencies of fashion companies and broader societies on it.60 Otherwise, impacts can hardly be avoided, policies be effective, and solutions and interventions be well-designed and implemented. Some companies have started to quantify their impacts on biodiversity in different ways, e.g., Kering’s Environmental Profit and Loss (EP&L) or H&M’s Biodiversity Footprint Assessment tool, while CSOs as Textile Exchange (i.e., through their Biodiversity Benchmarking) and RBIs as the Fashion Pact are helping companies to better understand biodiversity-related impacts and dependencies.

# ii. Demographic growth

Population growth is mentioned as a cause of the increased fashion demand and production and the intensification of the direct drivers of biodiversity loss associated to them.61 In low-middle income countries, this increased demand could also be fostered by the emergence of a new middle class.62 However, the increment in production outweighs population growth: in the period 1975–2022, global population grew from 4.07 to 7.95 billion people, while percapita fibre production increased from 8.3 to 14.6 kg.63

# D. TECHNOLOGY DRIVERS

Technological changes in primary sectors with direct use of nature (e.g., agriculture) are an indirect driver of biodiversity loss. In fashion, raw material extraction might involve different production techniques (e.g., regenerative, organic, or conventional cotton) with different impacts on biodiversity.64 Different types of materials (e.g., natural and synthetic) involve different impacts (e.g., water use, energy use, CO2 emissions), which highlights the importance of assessing the environmental trade-offs of different products and materials within FVCs.65 Moreover, the absence of technological innovations in FVCs is considered a driver of biodiversity loss.66 They normally refer to technologies to produce, manufacture, recycle, and dispose the materials and products that can increase the production efficiency through reductions in the material use (which drives land-

use change and climate change) and pollution intensity per unit of production. E.g., development and scalation of water purification procedures, new easily recyclable materials, and textile recycling technologies. Regarding recycling technologies, a key innovation would be a more efficient separation and recovery of polyester, although it is recognised as a highly complex chemical process.67 Some sources mention technological innovations as part of a ‘circular fashion’ to close the material loops and lengthen product’s durability.68

# F. RESULTS: BARRIERS

Our results show evidence to identify seven barriers to biodiversity-positive transformative change in the fashion sector:

# A. THE IDEOLOGY OF PERPETUAL GROWTH IN FASHION

According to some sources, the ever-increasing pace of fibre, textile, and apparel production is motivated by the ideological conviction that economic growth is inherently positive, unlimited, and connected to values such as progress and material wellbeing.69 This conviction would reinforce resource use intensification as co-produced by changes in consumer preferences and the interest of companies to maximise profits. Since this intensification should be fundamentally inversed to reduce the impact of the fashion sector on biodiversity, the ideology of growth in fashion is a barrier to biodiversity-positive transformative change.

# B. INGRAINED PRACTICES AND HABITS: FASHION CONSUMERISM

The results about overconsumption and fast fashion suggest that the changes in consumer practices (i.e., overconsumption, embracing novelty, quickly disposing clothes) towards consumerism co-produced by the emergence of fast fashion have solidified into social norms and habits that might become a barrier to promote sustainable consumption to reduce the pressures of fashion on biodiversity loss.

# C. TELECOUPLINGS: OPAQUE OUTSOURCING OF BIODIVERSITY LOSS

‘Telecoupling’ dynamics, i.e., the effects of seemingly unrelated events in one region experienced in other regions (IPBES, 2019a), are suggested in our results in the outsourcing of biodiversity loss from consumption hubs towards the main raw material and manufacturing locations. The globalised and fragmented nature of FVCs

obscures these dynamics which become a barrier for transformative change: for consumers it is difficult to be aware of the environmental and social issues in FVCs; for companies and legislators it is difficult to assess impacts and monitor the compliance with codes of conduct, standards, and sustainability certifications.

# D. RIGID POLITICAL/ADMINISTRATIVE BOUNDARIES TO GOVERN FVCS

Our interviewees suggest that national states have difficulties to regulate global dynamics of production and trade, which ends up intensifying the impacts of fashion on biodiversity and would probably prevent transformative outcomes even if fashion-specific biodiversity policies were designed and implemented. Moreover, current biodiversityand fashion- specific governance initiatives are solely proposed by CSOs and the private sector, therefore they remain unbinding.

# E. UNCOORDINATED INSTITUTIONS AND POLICIES FOR FASHION AND BIODIVERSITY

Our data shows that current and forthcoming regulations and policy frameworks (e.g., the EU Textile Strategy, the CSDDD) partially or totally aimed at improving the social and environmental sustainability of fashion lack specific attention to biodiversity. This could hide some trade-offs, e.g., between climate and biodiversity outcomes, and make these policies an obstacle for transformative change.

# F. LACK OF UNDERSTANDING, HUMAN CAPITAL, AND MEASURING THE PROBLEM OF BIODIVERSITY LOSS IN FASHION

Our data suggests that the recognition of the connection between biodiversity loss and fashion is very recent: most policymakers, producers, sustainability managers, CEOs, and consumers (including some of our experts) are not completely aware of it. Just a few fashion-specific private initiatives and CSOs are currently starting to address the topic. However, pending the development of the SBTN, most companies and institutions lack measurement tools and integrated indicators (e.g., the ‘CO2 equivalent’ for climate change) to quantify impacts, allow comparability, and assess policy impacts, which poses a barrier to transformative change.

# G. POOR AVAILABILITY OF BIODIVERSITY-POSITIVE TECHNOLOGIES

Our data points at the underdevelopment, unavailability, unaffordability, or un-scalability of technologies and techniques (e.g., polyester recycling, water purification, regenerative agriculture) as a barrier for transformative change. As a result, e.g., less than $1 \%$ of textile waste is

closed loop recycled.70 This poses a barrier to transformative change as, e.g., if companies would better understand their impacts and dependences on biodiversity, they could still find obstacles to implement technologies to reduce their impacts.

# G. DISCUSSION: EXPLORING WAYS FORWARD FOR BIODIVERSITY-POSITIVE TRANSFORMATIVE CHANGE IN THE FASHION SECTOR

# A. DIRECT DRIVERS: LAND-USE CHANGE AND LACK OF DATA

Our results suggest that the main direct driver of biodiversity loss in fashion is land-use change due to the raw material production supply chain activity (i.e., in the production of plant-based fibres, animal materials, and MMCFs), followed by pollution (i.e., mainly water) in different stages (i.e., raw material extraction, manufacturing, consumer use) and climate change, i.e., distributed across the supply chain but mainly concentrated in raw material extraction and the manufacturing of synthetic materials. These results align with IPBES (2019a) in identifying land-use change as the main pressure on terrestrial biodiversity. Moreover, they point at the production of raw materials in fashion (the socalled ‘Tier 4’) as one of the new focuses of future research and governance, since climate change and pollution have already been present in the discussions about sustainable fashion for years. Our data did not show much evidence about the overexploitation of natural resources (i.e., there were some references to freshwater use) or invasive alien species. However, the exploratory nature of our study, along with the emergent nature of the topic (i.e., very recent discussion), and the lack of detailed data (i.e., very few data sources and publications) does not allow to assume that fashion does not contribute to those direct drivers. Further research specifically focused on these drivers remains necessary, e.g., the recent Thematic Assessment Report on Invasive Alien Species and their Control (IPBES, 2024b) could be a good starting point. Furthermore, most of the current data comes from the industry itself or from civil society initiatives aimed at informing the industry, which is a common trend in the study of sustainable fashion (Moran et al., 2021; Palm et al., 2021). This highlights the need for independent studies to assess the contribution of fashion to biodiversity loss to ensure that the interests of the industry do not influence the results. Finally, despite the lack of data, our study shows the important direct pressures that the fashion sector puts on biodiversity and

highlights the need to increase the attention to the topic both in research and policy.

# B. INDIRECT DRIVERS: ECONOMIC DRIVERS AND THE LACK OF VALUES

Since deliberate transformative change should be directed at addressing the indirect drivers of biodiversity loss, our results about indirect drivers point at potential directions for research and governance. In this section we focus on discussing the economic indirect drivers we mapped and the absence of social and sociocultural values, while the rest of relevant drivers are discussed in the next section along with the barriers to transformative change.

Our results suggest that economic indirect drivers are the most influential on the fashion supply chain activities and, consequently, intensify (i.e., material resource use intensification as an effect of the dynamics of overconsumption and overproduction) and affect the distribution (i.e., the fragmentation and globalisation of FVCs) of the direct drivers of biodiversity loss. This conclusion aligns with IPBES (2019a) pointing at ‘unsustainable consumption and production’ and ‘trade’ as key indirect drivers. Moreover, it confirms our hypothesis that economic drivers would be part of our mapping given the attention that has been given to unsustainable consumption and trade dynamics in the discussions about sustainable fashion in the last years (Leventon et al., 2024; Niinimäki et al., 2020). Our results add to the evidence pointing to the need to steer fashion-related sustainability governance towards an absolute reduction of volumes of production and consumption, e.g., Palm et al. (2021), which has been historically absent from both private governance and regulations (Maldini & Klepp, 2025; Payne & Mellick, 2022). The potential consequences of such a change, e.g., the economic impact on fashion-producing regions and the loss of jobs, should be further studied to understand how to minimise the negative outcomes.

As a key gap in our results, an explicit recognition of social and sociocultural values seems to be absent from the debate about fashion and biodiversity. However, the references to changes in consumer preferences and consumerism reported in our results could be seen as implicitly connected to values, as people’s behaviour towards consumption is influenced by their worldviews (IPBES, 2019b). We discuss this point in the next section. Despite this, social and sociocultural values connected to the impact of fashion on biodiversity loss deserves further scrutiny. For example, inspired by IPBES (2022, 2024a), the relation between relational values of human-nature interconnectedness and behaviours of production and consumption of fashion could be explored.

# C. BARRIERS TO TRANSFORMATIVE CHANGE: EXPLORING THE DIRECTION OF CHANGE AND FURTHER RESEARCH

Our results show seven barriers to biodiversity-positive transformative change in fashion that could serve as entry points to address the indirect drivers of biodiversity loss and catalyse transformative change if not tackled in isolation. Given this study’s exploratory nature and the lack of data, this list must not be seen as conclusive but as a starting point from which additional assessments can be conducted to systematically identify further barriers and ways to address them.

The ‘ideology of economic growth in fashion’ has been identified before as the main paradigm driving unsustainable consumption and production patterns and therefore preventing the reduction in production and consumption volumes that should be part of transformative change in the sector (Buchel et al., 2022; Leventon et al., 2024). This barrier is connected to ‘ingrained practices and habits: fashion consumerism’, since the overconsumption and quick disposal of fashion items is co-produced by and reinforces the dynamic of systemic overproduction implemented by fashion companies to maximise their economic growth. Therefore, both barriers could be addressed in combination by exploring potential elements of an alternative paradigm or ideology to economic growth taking consumers as agents of change. Some contributors have proposed redesigning the fashion economy based on the principle of sufficiency, i.e., satisfying human needs while fitting planetary boundaries (Coscieme et al., 2022; Freudenreich & Schaltegger, 2020; Mörsen, 2023). However, it could be argued that consumption patterns are not just influenced by preferences, but also by further structures and social norms, therefore addressing consumption might not be enough. Moreover, the ideology of economic growth is not just specific to fashion, but also a societal barrier reproduced by powerful actors which could oppose transformative change. However, as we mention below, barriers connected to power relations are currently absent from the debate about fashion and biodiversity.

The identification of ‘telecouplings: opaque outsourcing of biodiversity loss’ as a barrier aligns with previous evidence highlighting that the environmental consequences of the fashion sector are mainly suffered far away from the places where consumption takes place (Bonelli et al., 2024). However, despite the growing literature studying the dynamics of ‘unequal ecological exchange’ in the world economy, e.g., Hickel et al. (2022), studies about the fashion sector are lacking, and a specific focus on fashion and biodiversity is completely absent. To promote transformative change, the telecoupling dynamics between fashion consumption and production countries

should be further studied, and the transparency and traceability of fashion supply chains should be improved. However, a growing understanding of these dynamics would not automatically translate into better outcomes for biodiversity if, e.g., not embedded in governance frameworks or mobilised to change unsustainable production practices and trade dynamics.

As expected, governance-related barriers as ‘rigid political/administrative boundaries to govern FVCs’ and ‘uncoordinated institutions and policies for fashion and biodiversity’ were identified in our results. Recent literature has argued that voluntary and managerial-based governance has failed to address fashion’s socio-ecological unsustainability and has advocated for collaborative approaches and stronger public regulations (Beyers et al., 2023; Hileman et al., 2020). However, our results show that the only biodiversity-specific attempts to govern the fashion sector come from the private sector, while past legally binding multistakeholder initiatives and the existing and forthcoming EU regulations do not focus on biodiversity. Moreover, national legislation has difficulties to regulate global supply chains, therefore limiting the transformative impact of potential policies while companies can still delocalise their activities to places with weaker regulations. These insights point at the need for a transformation of fashion governance towards coordinated international efforts to halt and reverse biodiversity loss. To study this, researchers could analyse the effects of the implementation of international frameworks such as the GBF on fashion. Moreover, for a coordinated international governance of fashion to be transformative, it should be directed at addressing the indirect drivers of biodiversity loss and other barriers to transformative change, e.g., overproduction, overconsumption, and the ideology of economic growth.

Finally, the identification of the ‘lack of understanding, human capital, and measuring the problem of biodiversity loss in fashion’ reflects the complexity and multidimensional nature of biodiversity and aligns with previous evidence showing that biodiversity concepts, valuation, and targets are not well understood and developed by businesses (Schaltegger et al., 2023; Smith et al., 2020). This result reflects the novelty of biodiversity as a topic within the fashion sector, and points at the need to mainstreaming knowledge about biodiversity at different levels and developing specific indicators to measure the impacts and dependencies of the fashion sector on biodiversity. Similar conclusions can be applied to the barrier ‘poor availability of biodiversity-positive technologies’, i.e., more resources should be invested in developing and mainstreaming biodiversity-positive technologies. However, it remains unclear whether these developments would promote

transformative change, since companies’ motivations to take transformative action for biodiversity are not straightforward. E.g., despite our grey-literature documents argue that companies have strong incentives to take biodiversity actions, the topic remains underdeveloped, i.e., scarce publications and data including private initiatives. Fashion companies could be unfavourable to biodiversitypositive transformative change because they might regard it as against their interests, e.g., a reduction in absolute volumes of production and consumption could jeopardise their profits. To prevent this from becoming a barrier to transformative change, further research could critically study the motivations of the fashion sector to act on biodiversity.

# D. LACK OF ATTENTION TO POWER RELATIONS AND EQUITY

Against our expectations, the results did not show enough evidence to identify ‘socio-economic disparities’ or ‘international monetary system constraining policy autonomy’ as barriers to biodiversity-positive transformative change. Given the abundant evidence about the unequal distribution of benefits and the negative social outcomes of fashion supply chains in the academic literature (Bonelli et al., 2024; Dzhengiz et al., 2023), we argue that the specificity of these disparities and unequal international relations for fashion and biodiversity deserve further scrutiny. Moreover, this insight points at a more general conclusion from our results: specific attention to power relations and equity is currently almost completely absent from the discussion about fashion and biodiversity. As argued in the literature, this absence could compromise transformative change in different ways (Blythe et al., 2018; Lele, 2021; Massarella et al., 2021; Zafra-Calvo et al., 2020). Powerful multinational fashion businesses might co-opt the debates and policies to govern biodiversity-positive transformations and prioritise their vested interests (e.g., economic growth). Global-South transformative initiatives for fashion and indigenous peoples’ knowledge and values (e.g., traditional textile techniques) could be excluded and marginalised. The burden and costs of the transformation could be shifted to vulnerable parties, e.g., textile and apparel workers in the Global South. We propose to start accounting for these dynamics by analysing the specificity of biodiversity-positive transformative change in fashion within broader debates about environmental justice, e.g., Figueroa (2022), and a socially-just transition, e.g., Benegiamo et al. (2023).

# E. LIMITATIONS

Part of this study was aimed at providing a general exploratory map of drivers of biodiversity loss in the fashion sector. However, as recognised in Textile Exchange (2023a),

fashion production practices and biodiversity loss dynamics are strongly dependent on the type of material, production system, and location. E.g., land-use change connected to regenerative cotton agriculture in rainy regions is completely different from the one connected to irrigated cotton monocultures. Similarly, our conceptualisation of fashion supply chain activities might be accused of oversimplifying complex value chain processes into a small set of practices. Further studies might start from our general map and deepen into the dynamics of biodiversity loss in specific value chains recognising the specificity of production systems, materials, and locations.

Additionally, our results could be biased because of the interviewee selection, whose context-specific experiences might have conditioned their answers. Moreover, the authors and organisations of the grey-literature publications, as well as the interviewees, come from Western countries from the Global North. Consequently, our study might be overrepresenting Northern perspectives, which could compromise its contribution to inform biodiversity-positive transformative change in two ways. First, by emphasising fashion-consuming countries’ perspectives, it could be overlooking emerging indirect drivers and barriers specific to fashion-production countries. To overcome this limitation, similar research which engages fashion stakeholders from different countries and contexts might be conducted. Second, our sample selections risks introducing epistemological and ontological views and assumptions which value biodiversity and nature in an instrumental and hierarchical way, which is common in Western countries and has been identified as an obstacle to transformative change (IPBES, 2022). If reproduced in our results and conclusions, this bias might have limited the potential of the paper to go deeper in reflecting about biodiversitypositive transformative change in fashion. Although there are not straightforward ways to prevent this bias, future studies could embrace a transdisciplinary approach to “recognize different knowledge systems, and support the inclusion of sustainable and equitable values by focusing on types of knowledge that are currently underrepresented” (Visseren-Hamakers & Kok, 2022, p. 12). In practice, this might translate into exploring participatory actionresearch approaches which purposedly include historically disempowered actors and different forms of knowledge.

# H. CONCLUSION

Throughout this paper, we have exploratorily developed the first academic characterisation of the connections between the global phenomenon of biodiversity loss and the textile, apparel, and fashion sector by mapping the

main direct and indirect drivers of biodiversity loss linked to different fashion supply chain activities. Moreover, we have pointed at the potential direction of biodiversitypositive transformative change in fashion by identifying barriers that can be taken as entry points to catalyse that change. Our results suggest that land-use change is the direct driver to which the fashion sector contributes the most through the primary extraction and production of raw materials. Moreover, fashion significantly contributes to water pollution and climate change distributed through the supply chain activities of raw material primary production, manufacturing, product’s end-of-life, and consumer use. Regarding indirect drivers, we have highlighted economic drivers, i.e., material resource use intensification through overproduction and overconsumption and the global and fragmented nature of fashion value chains, as the most influential in determining the intensity and distribution of fashion’s direct pressures on biodiversity loss. Moreover, we have shown other relevant demographic (i.e., lack of human capital), governance (e.g., multi-level governance), and technological (e.g., changes in production technologies in agriculture) indirect drivers. Furthermore, we have identified seven barriers to biodiversity-positive transformative change in fashion and have discussed the need to go beyond panaceas to address them in combination, beyond single solutions and governance levels. Finally, we have discussed the absence of attention to power relations and equity in the current debate about biodiversity and fashion as a potential barrier to transformative change, which highlights the need to explicitly study issues of power and justice in combination to biodiversity-positive transformations in fashion. This is especially important since, as mentioned by Visseren-Hamakers et al. (2021, p. 21), transformative change is inherently political “since the desired direction of transformation is often contested, and power relations will change”. By doing this study, we have taken a normative and political position towards biodiversity and transformative change. Paraphrasing Buchel et al. (2022, p. 242), “[r]ather than looking at the symptoms” we have examined “the underlying structural characteristics of the fashion industry that keep them locked in” to modestly provide elements that can serve to better define the direction of change. It is our hope that our study might be useful to inform future governance attempts to promote biodiversity-positive transformations of fashion.

# NOTES

1 E.g., the designation of protected areas, species-specific conservation projects, the definition of global targets (the Aichi targets), or National Biodiversity Plans.   
2 From now on, ‘the fashion sector’, ‘the fashion industry’, or ‘fashion’.   
3 IPBES defines biodiversity as “the variability among living organisms from all sources including terrestrial, marine, and other aquatic ecosystems and the ecological complexes of which they are a part. This includes variation in genetic, phenotypic, phylogenetic, and functional attributes, as well as changes in abundance and distribution over time and space within and among species, biological communities, and ecosystems”.   
4 In fact, the textile, apparel, and/or fashion sector/s are not addressed or mentioned in IPBES Transformative Change Assessment (IPBES, 2024a).   
5 PLANET4B: understanding Plural values, intersectionality, Leverage points, Attitudes, Norms, behaviour and social lEarning in Transformation for Biodiversity decision making.   
6 To develop our analytical framework for studying biodiversity loss in the textile and apparel (TAF) industry, we began by conducting a scoping literature review to assess the integration of biodiversity concepts within sustainability studies in fashion. Initially, our search using the terms “sustainab*” and “fashion” in Scopus yielded an overwhelming 43,590 articles, prompting us to narrow our focus to a review of reviews. We limited our selection to reviews published in English from 2015 to 2023 found in Scopus and Web of Science. This refined search resulted in 566 documents, from which we removed duplicates and excluded studies focused on single case studies, specific production practices, or materials, as well as those outside our expertise like microbiology and nanotechnology. Ultimately, 51 reviews were deemed relevant. Further examination for terms like ‘biodiversity’, ‘bio-diversity’, ‘biological diversity’, and ‘natural diversity’ within these documents revealed 18 mentions across 11 reviews, highlighting that biodiversity is typically referenced only in the context of its deterioration due to unsustainable fashion practices, rather than as a standalone subject of discussion.   
7 In IPBES (2024b), ‘Diverse values of nature’ was renamed as ‘Sociocultural and Social Values’. We decided to use this conceptualisation because it better recognises the existence of broader values beyond values of nature.   
8 I.e., Bailey et al. (2022), Centobelli et al. (2022), Dzhengiz et al. (2023), Liu et al. (2021), Moran et al. (2021), Munasinghe et al. (2021), Niinimäki et al. (2020), and Wagaw & Babu (2023).   
9 Sources: all grey literature; Interviews 4, 5, 9, 10, 11, 12.   
10 Sources: grey literature 1, 4, 7, 9, 12; Interviews 9, 10, 11, 12; Bailey et al. (2022), Dzhengiz et al. (2023), Liu et al. (2021), Niinimäki et al. (2020), Munasinghe et al. (2021), Wagaw & Babu (2023).   
11 Sources: grey literature 1, 9; Interviews 9, 11, 12; Centobelli et al. (2022), IPBES (2019a), Moran et al. (2021), Munasinghe et al. (2021), Niinimäki et al. (2020).   
12 Document 7.   
13 Documents 1, 4, 9, 12; Interviews 4, 5, 10.   
14 FAO (2012).   
15 Documents 1, 4, 9, 12; Interviews 4, 5, 9, 11.   
16 Bailey et al. (2022), Liu et al. (2021).   
17 Document 7.   
18 Niinimäki et al. (2020).   
19 Interviews 9, 10, 11, 12; Munasinghe et al. (2021).   
20 Dzhengiz et al. (2023), Wagaw & Babu (2023).

21 Document 1.   
22 Document 4.   
23 Documents 1, 12.   
24 Docs 9, 12; Dzhengiz et al. (2023), Liu et al. (2021), Niinimäki et al. (2020).   
25 Centobelli et al. (2022), Niinimäki et al. (2020).   
26 Document 1; Moran et al. (2021).   
27 Document 9.   
28 Niinimäki et al. (2020).   
29 Interviews 9, 11, 12.   
30 Document 1.   
31 Munasinghe et al. (2021).   
32 Munasinghe et al. (2021).   
33 We would have called the economic drivers explained in IPBES (2019a) ‘socio-economic drivers’, but we stick to IPBES’s conceptualisation for the sake of coherence.   
34 Textile Exchange (2023b).   
35 Textile Exchange (2023b).   
36 Niinimäki et al. (2020).   
37 Niinimäki et al. (2020).   
38 Niinimäki et al. (2020).   
39 Document 4; Textile Exchange (2023b).   
40 Niinimäki et al. (2020), Wagaw & Babu (2023).   
41 Moran et al. (2021).   
42 Niinimäki et al. (2020).   
43 Niinimäki et al. (2020).   
44 Document 9.   
45 Document 8.   
46 Documents 5, 8.   
47 Moran et al. (2021).   
48 Centobelli et al. (2022).   
49 Document 8.   
50 Documents 10, 12; all interviews; Bailey et al. (2022), Centobelli et al. (2022), Dzhenzig et al. (2023), Liu et al. (2021), Niinimäki et al. (2020).   
51 Documents 10, 12; Interviews 1, 2, 3, 5, 8, 9.   
52 Interviews 2, 3, 5, 6, 8, 9, 10, 11, 12; Niinimäki et al. (2020).   
53 Bailey et al. (2022).   
54 Niinimäki et al. (2020).   
55 Liu et al. (2021).   
56 Document 10; Centobelli et al. (2022), Dzhenzig et al. (2023).   
57 Documents 9, 10, 12; all interviews.   
58 Documents 9, 10, 12; CBD (Decision Adopted by the Conference of the Parties to the Convention on Biological Diversity. Kunming-Montreal Global Biodiversity Framework, 2022).   
59 Documents 1, 2, 3, 6, 7, 8, 9, 10, 11, 12.   
60 Documents 9, 10, 11, 12; all interviews.   
61 Documents 12; Interviews 4, 5, 6, 8; Liu et al. (2021), Wagaw & Babu (2023).   
62 Liu et al. (2021), Wagaw & Babu (2023).   
63 Textile Exchange (2023b).   
64 Documents 4, 5, 7, 11, 12; Interviews 4, 5; Munasinghe (2021), Textile Exchange (2023b).   
65 Documents 4, 5, 7, 11, 12; Interviews 4, 5. Munasinghe (2021) Wagaw & Babu (2023).   
66 Documents 4, 5, 7, 12. Interviews 4, 5.   
67 Document 5; Interviews 4, 5.   
68 Documents 5, 7.   
69 Documents 10,12; Interviews 2, 3, 5, 6, 8, 9, 10, 11, 12.   
70 Document 4; Textile Exchange (2023b).

# ADDITIONAL FILE

The additional file for this article can be found as follows:

Supplementary File. Appendix 1–Appendix 4. DOI: https://doi.org/10.5334/ijc.1458.s1

# AUTHOR AFFILIATIONS

Pedro Navarro-Gambín $\textcircled{1}$ orcid.org/0000-0003-1892-9734 Pisa Agricultural Economics (PAGE), Department of Agriculture, Food and Environment (DAFE), University of Pisa (UNIPI), Pisa, IT   
Marta Bonetti $\textcircled{1}$ orcid.org/0009-0007-1939-0060 Department of Political Sciences, University of Pisa (UNIPI), Pisa, IT   
Matteo Villa $\textcircled { 1 0 }$ orcid.org/0000-0001-6456-9501 Department of Political Sciences, University of Pisa (UNIPI), Pisa, IT   
Gianluca Brunori $\textcircled { 1 0 }$ orcid.org/0000-0003-2905-9738 Pisa Agricultural Economics (PAGE), Department of Agriculture, Food and Environment, University of Pisa (UNIPI), Pisa, IT   
Daniele Vergamini $\textcircled{1}$ orcid.org/0000-0002-0721-826X Pisa Agricultural Economics (PAGE), Department of Agriculture, Food and Environment, University of Pisa (UNIPI), Pisa, IT

# TO CITE THIS ARTICLE:

Navarro-Gambín, P., Bonetti, M., Villa, M., Brunori, G., & Vergamini, D. (2025). Paving the Ground for Biodiversity-Positive Transformative Change in Fashion: An Exploration of Drivers of Biodiversity Loss and Barriers to Transformative Change in the Textile, Apparel, and Fashion Sector. International Journal of the Commons, 19(1), pp. 322–341. DOI: https://doi.org/10.5334/ijc.1458

Submitted: 14 August 2024 Accepted: 22 July 2025 Published: 04 August 2025

# COPYRIGHT:

$\circledcirc$ 2025 The Author(s). This is an open-access article distributed under the terms of the Creative Commons Attribution 4.0 International License (CC-BY 4.0), which permits unrestricted use, distribution, and reproduction in any medium, provided the original author and source are credited. See http://creativecommons.org/licenses/by/4.0/.

International Journal of the Commons is a peer-reviewed open access journal published by Ubiquity Press.
