# Telecoupling between urban expansion and forest ecosystem service loss through cultivated land displ

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:57:16.930051+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Ma et al. - 2024 - Telecoupling between urban expansion and forest ecosystem service loss through cultivated land displ.pdf
- Year: unknown
- DOI: 10.1016/j.jenvman.2024.120695
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This article examines how urban expansion in Zhejiang Province, China, drives forest loss and degradation of forest ecosystem services through both direct land conversion and indirect cultivated land displacement, within a telecoupling framework.

The study focuses on 2000-2020 and considers Zhejiang as a rapidly urbanizing, forested, economically advanced coastal province. The authors analyze how urban growth converts forests and cropland, how lost cropland is replaced elsewhere by converting natural ecosystems (especially forests) into new farmland, and how these changes alter forest landscape structure and five key ecosystem services: timber production, water yield, carbon sequestration, soil conservation, and biodiversity.

Using 1-km land use/land cover maps, climate, soil, topography, roads, biomass, NPP, and vegetation indices, they quantify cultivated land displacement via NPP-based grain yield equivalence, evaluate ecosystem services with established biophysical models (e.g., InVEST water yield, RUSLE for soil conservation, NPP for carbon, habitat quality index for biodiversity), calculate forest structure metrics (forest proportion, mean patch area, edge density, mean nearest-neighbor distance), and relate structure to services with generalized additive models. They also construct a qualitative telecoupling case linking highly urbanized Hangzhou and less urbanized, forest-rich Lishui.

Urban land increased sharply, mainly at the expense of cropland, while forest loss occurred mostly by conversion to cropland. Indirect forest loss due to cropland replacement was 1.8-2.5 times the direct loss from urban encroachment. Indirect ecosystem service losses were about 3-4 times direct losses, and impacts were strongest for carbon sequestration, water yield, and biodiversity. Urbanization increased forest fragmentation and patch isolation; most services rose with higher forest proportion and patch size and declined with higher edge density and isolation, in nonlinear ways.

The work is explicitly about telecoupling: urban expansion in one city (e.g., Hangzhou) drives remote deforestation and ecosystem service loss in another (e.g., Lishui) through land and capital flows and land-balance policies. It also illustrates metacoupling by linking local urbanization processes, regional land policy, and distant ecological outcomes.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling; intra- and inter-city links between urban growth and distant forest ES losses.

### Intracoupling
#### Systems
- Urban, cultivated, and forest landscapes within Zhejiang cities.
- Local forest ecosystems providing multiple services.
- Municipal socio-economic systems driving urban land change.
#### Flows
- Conversion of local cultivated and forest land to urban land.
- Within-city afforestation and deforestation dynamics.
- Local changes in forest ecosystem service supply.
#### Agents
- Municipal governments implementing land policies.
- Local farmers and forest managers.
- Urban residents and developers.
#### Causes
- Rapid local urbanization and economic growth.
- Implementation of balanced cultivated land policy.
- Local demand for housing, infrastructure, and grain.
#### Effects
- Forest fragmentation and isolation within provinces.
- Decline in local timber, water yield, biodiversity indicators.
- Increased forest edges and altered patch configuration.

### Pericoupling
#### Systems
- Neighboring cities within Zhejiang sharing land and ES impacts.
- Adjacent mountainous and lowland agricultural regions.
- Regional forest and cultivated land mosaics.
#### Flows
- Cultivated land conversion between neighboring municipalities.
- Regional redistribution of forest loss and gain.
- Movement of rural labor within the province.
#### Agents
- Provincial government coordinating land quotas.
- Inter-city planning and negotiation bodies.
- Regional agricultural and forestry enterprises.
#### Causes
- Provincial food security and land balance requirements.
- Differences in land productivity across north-south gradients.
- Search for low-cost land in less urbanized neighbors.
#### Effects
- Southern mountainous cities bear higher deforestation pressure.
- Spatial mismatch between urban growth and forest loss.
- Regional disparities in ecosystem service degradation.

### Telecoupling
#### Systems
- Highly urbanized Hangzhou as sending system.
- Less urbanized, forest-rich Lishui as receiving system.
- Broader socio-ecological systems linked by cultivated land displacement.
#### Flows
- Displacement of cultivated land from urban cores to distant forests.
- Financial compensation from developed to less developed cities.
- Telecoupled loss of forest ecosystem services via land conversion.
#### Agents
- Provincial and city governments brokering land deals.
- Urban investors purchasing external land resources.
- Rural communities supplying land under compensation schemes.
#### Causes
- Urban expansion removing high-yield cropland near cities.
- Policy mandating maintenance of total cultivated area.
- Need to offset grain production losses from urbanization.
#### Effects
- Indirect forest loss exceeding direct urban forest conversion.
- Greater reductions in carbon storage, water yield, biodiversity far from cities.
- Cascade: urbanization to deforestation to altered forest structure to ES decline.

### Cross-Coupling Interactions
- Cultivated land displacement links urban intracoupling with distant forest telecoupling.
- Forest structure change mediates between land conversions and multi-ES responses.
- Monetary flows counterbalance economic gaps while externalizing ecological costs.

### Research Gaps or Limitations
- Indirect forest loss mapped only as ranges, not precise locations.
- Coarse-resolution, mainly national datasets limit fine-scale accuracy.
- Vertical forest structure and non-forest ecosystem services not fully assessed.

### Search Keywords
- telecoupling urban expansion forest ecosystem services cultivated land displacement Zhejiang
- indirect deforestation land balance policy Hangzhou Lishui
- forest fragmentation edge effects GAM ecosystem services China

### Extraction Confidence
high
