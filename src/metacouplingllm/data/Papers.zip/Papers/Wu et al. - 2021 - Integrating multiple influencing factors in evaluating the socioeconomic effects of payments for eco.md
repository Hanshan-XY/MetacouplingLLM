# Integrating multiple influencing factors in evaluating the socioeconomic effects of payments for eco

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:11:09.175712+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Wu et al. - 2021 - Integrating multiple influencing factors in evaluating the socioeconomic effects of payments for eco.pdf
- Year: unknown
- DOI: 10.1016/j.ecoser.2021.101348
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper develops and applies a metacoupling-based framework to assess how payments for ecosystem services (PES) influence rural socioeconomic outcomes when many other forces are acting simultaneously.

The study focuses on the Grain for Green Program (GFGP) on Chinas Loess Plateau, one of the worlds largest PES initiatives. The system context is a highly degraded agricultural region undergoing rapid ecological restoration and economic transformation. The analysis is conducted at the county level across 221 mostly rural counties.

Using the metacoupling concept of human-nature interactions within, adjacent to, and distant from a focal region, the authors distinguish external factors (GFGP, tourism), internal factors (local economy, local urbanization), and mixed external-internal factors (rural migration, investment, agricultural technology). Livelihood activities - crop production, orchard fruit production, and non-farm employment - are treated as mediators between these factors and rural household income. Structural equation modeling with official statistics for 2001-2015 is used to quantify direct, indirect, and unspecified (not fully observed) pathways to per capita rural net income.

Results show that GFGP reshaped livelihoods by reducing crop production and increasing orchard fruit production and non-farm work. However, when all metacoupled influences are considered, the dominant drivers of higher rural income are local economic development and investment, mainly through unspecified pathways such as higher wages and more profitable industries. Tourism, investment, and migration also encourage shifts into non-farm work, which raises income, but GFGP and tourism have relatively small, statistically weak total effects on income.

The study is explicitly about metacoupling/telecoupling. It demonstrates that evaluating PES in isolation overstates their socioeconomic contribution and can misinterpret livelihood effects if other flows (capital, labor, visitors, technology) are ignored. The framework highlights how distant and local economic processes condition PES outcomes and suggests that investment, labor mobility, and contextual payment design are crucial for PES programs to support sustainable rural development.

## Structured Metacoupling Extraction

### Coupling Classification
- Applies metacoupling to PES, covering intra, peri, and distant socioeconomic-ecological interactions.

### Intracoupling
#### Systems
- Loess Plateau counties social-ecological system under Grain for Green PES.
- Local rural households, farmland, orchards, and non-farm sectors.
- County-level local economy, urbanization, and agricultural technology.
#### Flows
- Land-use change from cropland to forest, grassland, and orchards.
- Shifts of rural labor among crops, orchards, and non-farm work.
- Local capital flows and technology inputs within counties.
#### Agents
- Rural households and laborers in Loess Plateau counties.
- County and provincial governments managing GFGP and investments.
- Local enterprises providing non-farm employment opportunities.
#### Causes
- Implementation of Grain for Green to combat degradation and poverty.
- Local economic growth and urban expansion influencing livelihoods.
- Agricultural intensification through increased fertilizer use.
#### Effects
- Improved rural incomes mainly driven by local economy and investment.
- Reduced cropland area but increased overall grain output via technology.
- Labor reallocation from farming to more profitable non-farm work.

### Pericoupling
#### Systems
- Neighboring counties within the Loess Plateau region.
- Adjacent urban centers linked to surrounding rural counties.
- Regional tourism destinations near GFGP areas.
#### Flows
- Tourist visits from nearby cities to scenic rural counties.
- Short-distance rural-urban commuting for non-farm jobs.
- Regional investments circulating among adjacent counties.
#### Agents
- Nearby urban residents visiting or working in LP counties.
- Regional investors and firms operating across counties.
- County-level planners coordinating neighboring development.
#### Causes
- Regional tourism development around restored landscapes.
- Urbanization gradients between adjacent rural and town areas.
- Inter-county labor and capital mobility within the region.
#### Effects
- Tourism and investment raise non-farm employment and local incomes.
- Peri-urban expansion converts farmland and alters livelihood mix.
- Income gains vary across neighboring counties by development level.

### Telecoupling
#### Systems
- Loess Plateau PES counties as sending and receiving systems.
- Distant domestic cities demanding labor and tourism services.
- International investors and foreign visitors linked to Shaanxi.
#### Flows
- Financial payments for ecosystem services from outside beneficiaries.
- Long-distance rural migration to distant cities for work.
- Inbound tourism, foreign investment, trade, and capital inflows.
#### Agents
- National government funding and designing Grain for Green.
- Migrant workers connecting LP counties with distant cities.
- External tourists, investors, and trade partners.
#### Causes
- National conservation and development policies driving PES funding.
- Economic growth in distant cities increasing labor demand.
- Global and national tourism and investment trends.
#### Effects
- External payments and investment indirectly enhance rural incomes.
- Migration and tourism expand non-farm livelihood opportunities.
- Telecoupled drivers overshadow local PES in income effects.

### Cross-Coupling Interactions
- Telecoupled investment and tourism amplify intracoupled shifts into non-farm work.
- Local technology development offsets GFGP-induced cropland loss, altering perceived program impacts.
- Economic growth across scales conditions how PES translates into household income gains.

### Research Gaps or Limitations
- County statistics cannot separate participant from non-participant households or PES-specific income.
- Official data may contain reporting errors or biases.
- Origins of migration, investment, and technology flows are unclear, blurring coupling classification.

### Search Keywords
- metacoupling PES Grain for Green Loess Plateau
- rural income tourism migration investment telecoupling
- structural equation modeling livelihood pathways China

### Extraction Confidence
high
