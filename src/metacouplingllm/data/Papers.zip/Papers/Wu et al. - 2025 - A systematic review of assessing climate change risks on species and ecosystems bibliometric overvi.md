# A systematic review of assessing climate change risks on species and ecosystems bibliometric overvi

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:11:46.627376+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Wu et al. - 2025 - A systematic review of assessing climate change risks on species and ecosystems bibliometric overvi.pdf
- Year: unknown
- DOI: 10.1017/sus.2025.8
- OA status: gold
- License: cc-by-nc-nd
- Category: Journal Articles\Review\Telecoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This review synthesizes global research on how climate change threatens species and ecosystems, with a focus on risk assessment concepts, methods, and emerging directions. The authors conduct a systematic search of Web of Science (2000-2022) following PRISMA guidelines, then apply bibliometric tools (notably CiteSpace) to 4000 highly relevant articles, plus in-depth reading of a subset. The scope is worldwide and spans marine, freshwater, and terrestrial systems.

The bibliometric analysis shows explosive growth in publications since 2000, dominated by work from the United States, United Kingdom, Australia, and China, and concentrated in environmental science, ecology, and conservation journals. Keyword patterns highlight risk, impact, vulnerability, adaptation, prediction, and management as central themes, indicating a strong orientation toward climate risk assessment and early warning.

The review distills five widely used conceptual components for assessing climate risks to biodiversity: exposure (degree of climatic stress and disturbance), sensitivity (how strongly organisms respond, driven by traits and interactions), adaptivity/adaptive capacity (behavioral, physiological, genetic, and spatial buffering), vulnerability (integrated susceptibility and extinction risk), and response (short- to long-term demographic, distributional, and ecosystem shifts). These concepts are illustrated across different spatial, temporal, and biological scales.

Methodologically, the paper organizes risk-assessment tools into correlative models (e.g., species distribution models), mechanistic models (process- and trait-based), hybrid approaches that combine both, and additional tools such as IUCN criteria, expert elicitation, paleoecological reconstructions, and combined frameworks.

In terms of telecoupling/metacoupling, the paper explicitly argues that climate-driven range shifts, cross-border species movements, and supply-chain propagation of ecosystem service changes demand a telecoupling perspective. It stresses that climate impacts in one region can trigger ecological and socio-economic effects elsewhere, and that conservation focused only on local systems may create distant spillovers. The authors call for integrating telecoupling thinking, geographic technologies, and early-warning systems into future risk assessments and conservation planning.

## Structured Metacoupling Extraction

### Coupling Classification
- Mainly telecoupling; intra system risk processes with cross border ecological linkages.

### Intracoupling
#### Systems
- Local species populations under changing climate within one region
- Single ecosystem types such as forests, tundra, mangroves
#### Flows
- Within system flows of energy, nutrients, and ecosystem services
- Local climate stressors like heatwaves, drought, and floods
#### Agents
- Local land managers and conservation agencies
- National research institutions and scientists
#### Causes
- Rising greenhouse gases increasing local temperatures
- Habitat fragmentation limiting microclimate access
#### Effects
- Shifts in species ranges and phenology inside ecosystems
- Local biodiversity loss and ecosystem function change

### Pericoupling
#### Systems
- Neighboring terrestrial or marine ecosystems along climate gradients
- Adjacent countries sharing species and habitats
#### Flows
- Cross boundary dispersal of species to nearby regions
- Shared river basins transmitting climate impacts
#### Agents
- Regional conservation networks and NGOs
- Transboundary river and park authorities
#### Causes
- Regional climate variability affecting contiguous landscapes
- Land use change spreading across borders
#### Effects
- Range shifts altering community composition in bordering regions
- Spatial mismatches between species and protected areas

### Telecoupling
#### Systems
- Distant source and destination regions linked by species redistribution
- Globally connected ecosystem service supply regions
#### Flows
- Long distance species migrations under warming climates
- Global supply chains of ecosystem services and commodities
- Information and finance flows for climate risk governance
#### Agents
- International environmental agreements and conventions
- Multinational research collaborations and funding bodies
- Global conservation organizations and intergovernmental panels
#### Causes
- Anthropogenic emissions driving global climate change
- International trade and consumption shifting ecosystem pressures
- Cross regional policy decisions influencing distant land management
#### Effects
- Arrival of novel species causing distant ecosystem disruption
- Teleconnected collapse or alteration of ecosystem services
- Cross border spillover from locally focused conservation actions

### Cross-Coupling Interactions
- Species moving from source to destination regions reshape both local and distant food webs
- Climate impacts on ecosystem services propagate through multi region supply chains
- Telecoupled feedbacks between biodiversity loss, land use, and global climate

### Research Gaps or Limitations
- Limited empirical multi region studies explicitly applying telecoupling to climate biodiversity risks
- Scarcity of long term, high resolution data for early warning across coupled systems
- Models rarely integrate socio economic teleconnections with ecological risk dynamics

### Search Keywords
- climate change risk assessment biodiversity telecoupling
- species range shifts ecosystem services supply chains
- exposure sensitivity vulnerability adaptivity response models

### Extraction Confidence
high
