# Mapping the global distribution of locally-generated marine ecosystem services The case of the West

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:41:48.476838+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Drakou et al. - 2018 - Mapping the global distribution of locally-generated marine ecosystem services The case of the West.pdf
- Year: unknown
- DOI: 10.1016/j.ecoser.2018.05.008
- OA status: hybrid
- License: cc-by-nc-nd
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: ND license (cc-by-nc-nd) prohibits derivative chunks/embeddings

## Copyright-Safe Summary
This article develops and applies a framework to map how benefits from a locally generated marine ecosystem service - tuna from purse seine fisheries - are distributed globally. The study focuses on the Western and Central Pacific Ocean (WCPO), especially tuna harvested within the Exclusive Economic Zones of Pacific Island states that are parties to the Nauru Agreement. Biophysically, this region produces roughly a third of global industrial tuna catches, dominated by skipjack and yellowfin.

The authors argue that conventional ecosystem service maps are mostly place-based and emphasize local supply. They rarely show where benefits ultimately go or how they are shared along global value chains, despite clear telecouplings among distant regions. To address this, the paper merges ecosystem service mapping with value chain analysis and a human well-being lens. The framework traces flows from ecosystem functions through harvesting, processing, trade, and final consumption, and it explicitly attaches spatial information to each stage.

Using secondary data from fisheries agencies, market reports, and prior studies, the authors qualitatively map three main stages: catch by national fleets, processing locations (loining and canning), and final markets. They show that fleets from the United States, Japan, Korea, Taiwan, China, Spain, and several smaller flag states harvest tuna in WCPO waters; most processing occurs in Thailand, Japan, Korea, the Philippines, Papua New Guinea and other Pacific states; and final consumption is concentrated in Europe, the United States, Asia, Latin America, the Middle East, and Oceania.

The analysis identifies three types of spatial benefit flows: one-to-one (e.g., Japan and Korea harvesting, processing, and consuming domestically), closed loops (e.g., US fleets fishing in WCPO, processing abroad, product returning to US markets), and open loops (e.g., European fleets fishing in Pacific waters, processing in multiple countries, and selling largely in Europe). This clearly illustrates a telecoupled marine social-ecological system. The work is directly about telecoupling/metacoupling, and highlights the need for better data on intermediate actors, improved transparency in seafood supply chains, and more globally informed ecosystem service assessments to address equity, benefit sharing, and sustainability.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via global tuna value chains; some intra and peri linkages within Pacific fisheries.

### Intracoupling
#### Systems
- WCPO marine ecosystem and tuna stocks
- Pacific Island coastal communities and economies
#### Flows
- Tuna biomass from ocean to landing sites
- Access fees and public revenues within Pacific states
#### Agents
- Pacific Island governments and fisheries agencies
- Local fish workers and processors
- Regional tuna management bodies
#### Causes
- Local and regional demand for income and protein
- National policies selling fishing access rights
#### Effects
- Employment and state revenue in Pacific Island countries
- Local food security from tuna consumption
- Pressure on regional tuna stocks and ecosystems

### Pericoupling
#### Systems
- Neighboring Pacific Island EEZs under Nauru Agreement
- Regional tuna processing hubs in Pacific and Southeast Asia
#### Flows
- Mobile purse seine fleets crossing national boundaries
- Regional trade in landed and semi-processed tuna
- Shared management rules and access arrangements
#### Agents
- Parties to the Nauru Agreement and Tokelau
- Regional fishing companies and plants
- Pacific Islands Forum Fisheries Agency
#### Causes
- Migratory tuna moving across adjacent EEZs
- Regional cooperation to control access and maximize rents
#### Effects
- Uneven regional distribution of jobs and processing benefits
- Collective control over large share of global tuna supply

### Telecoupling
#### Systems
- WCPO tuna fisheries as sending system
- Processing countries in Asia, Latin America, Pacific
- Consumer markets in Europe, USA, Asia, Middle East, others
#### Flows
- Tuna products shipped globally as canned, loins, frozen
- Economic benefits along distant value chain stages
- Nutritional benefits to distant consumers
#### Agents
- Distant-water fleets from USA, Japan, Korea, Taiwan, Europe, China
- Global trading and trans-shipment firms
- Retailers and consumers in importing countries
#### Causes
- Global seafood demand and trade liberalization
- Corporate value chains seeking cheap, reliable tuna supply
- International policies on oceans, access, and benefit sharing
#### Effects
- Spatially unequal sharing of marine ecosystem service benefits
- Externalization of ecological pressures to WCPO ecosystems
- Dependence of global food security on distant fisheries

### Cross-Coupling Interactions
- Telecoupled demand shapes local access, fishing pressure, and regional management decisions.
- Intermediate processors and traders mediate flows between WCPO supply and distant markets.
- Climate and economic change alter tuna distributions, affecting all coupled systems.

### Research Gaps or Limitations
- Sparse, inconsistent data on intermediate beneficiaries, jobs, and revenues in value chain.
- Limited traceability of product-specific flows by fleet, processor, and market.
- Well-being and cultural impacts on different beneficiary groups poorly quantified.

### Search Keywords
- telecoupling tuna WCPO value chain
- marine ecosystem service flow mapping
- purse seine fisheries global trade

### Extraction Confidence
high
