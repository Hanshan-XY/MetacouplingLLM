# Sustainable landscape pattern a landscape approach to serving spatial planning

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:41:10.022531+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Dong et al. - 2022 - Sustainable landscape pattern a landscape approach to serving spatial planning.pdf
- Year: unknown
- DOI: 10.1007/s10980-021-01329-0
- OA status: closed
- License: none recorded
- Category: Journal Articles\Review\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This review article develops a clear concept of sustainable landscape pattern (SLP) and shows how it can support spatial planning for sustainable development. The work is global in scope, with many examples from China, Europe, and North America, and is situated within landscape ecology, landscape sustainability science, and planning systems such as urban-rural plans, territorial spatial planning, and ecological red lines.

The authors define SLP as particular combinations of landscape elements and their spatial arrangement that allow social-ecological processes to maintain ecosystem service provision and human well-being over time. They distinguish two broad types. Adaptive SLPs arise mainly in highly urbanized or lower-pressure regions (for example, green infrastructure, ecological networks, and urban growth boundaries) and emphasize enhancing resilience and connectivity. Constrained SLPs, more common in rapidly urbanizing or high-pressure contexts (for example, ecological security patterns, ecological red lines, biodiversity hotspots), focus on meeting ecological thresholds with minimal but strategically located protected areas.

Methodologically, the paper synthesizes literature on related planning tools including ecological networks, green infrastructure, ecological security patterns, urban growth boundaries, conservation priority areas, and ecological red lines. It categorizes how SLP-related tools serve three key steps in spatial planning: (1) assessment of ecological conditions, ecosystem services, risk, and vulnerability; (2) identification of critical zones, corridors, and boundaries; and (3) simulation of alternative future scenarios using land-use and climate-socioeconomic models to compare planning schemes.

The authors highlight emerging directions where SLP concepts can be expanded: incorporating spatial resilience analysis, using the metacoupling framework to address cross-boundary flows of ecosystem services and species, designing patterns for urban agglomerations, explicitly managing landscape multifunctionality and trade-offs, and informing nature-based solutions and ecological restoration.

The paper directly engages with metacoupling and telecoupling by arguing that SLPs should account not only for local human-nature interactions but also for spillover effects and inter-regional benefit flows, such as upstream-downstream water services and migratory species, thus extending SLP analysis beyond local scales.

## Structured Metacoupling Extraction

### Coupling Classification
- Introduces metacoupling to extend sustainable landscape patterns from local to interregional scales.

### Intracoupling
#### Systems
- Single-region social-ecological systems under spatial planning.
- Urban or rural landscapes within one administrative unit.
#### Flows
- Local ecosystem services from landscapes to resident populations.
- Internal flows of materials, energy, information within a region.
#### Agents
- Local governments and planners designing spatial plans.
- Residents, landowners, and local businesses.
#### Causes
- Need to balance local ecological conservation and development.
- Urbanization, land use change, and local SDG implementation.
#### Effects
- Changed local landscape patterns and resilience.
- Altered local ecosystem service supply and human well-being.

### Pericoupling
#### Systems
- Adjacent cities within an urban agglomeration.
- Upstream and downstream regions sharing resources.
#### Flows
- Cross-boundary water resources and ecological flows.
- Intercity movement of people, goods, and services.
#### Agents
- Regional planning authorities for city clusters.
- Neighboring municipal governments coordinating policies.
#### Causes
- Expansion of metropolitan regions into interconnected agglomerations.
- Need to coordinate land use and ecological protection across borders.
#### Effects
- Reduced habitat fragmentation via regional ecological networks.
- Shared benefits from coordinated ecological red lines and UGBs.

### Telecoupling
#### Systems
- Distant habitats connected by species migration routes.
- Remote regions linked by ecosystem service trade-offs.
#### Flows
- Long-distance wildlife migration between separated habitats.
- Nonlocal ecosystem service benefits, such as downstream flood control.
#### Agents
- National-level agencies setting broad spatial policies.
- Conservation organizations operating across distant regions.
#### Causes
- Spillover effects of ecosystem services beyond local boundaries.
- Remote human-nature interactions highlighted by metacoupling theory.
#### Effects
- Benefits and costs of landscape patterns exported to distant areas.
- Need to design SLPs considering off-site beneficiaries and impacts.

### Cross-Coupling Interactions
- Metacoupling framework links SLP-driven local planning with adjacent and distant beneficiaries.
- Urban agglomeration SLP design integrates intra-, peri-, and telecoupled ecological networks.

### Research Gaps or Limitations
- Current SLP studies focus mainly on local scales, underusing metacoupling perspectives.
- Limited quantification of spillover ecosystem services and cross-regional beneficiaries in SLP design.
- Resilience and multifunctionality trade-offs rarely integrated with metacoupled SLP assessment.

### Search Keywords
- sustainable landscape pattern metacoupling spatial planning
- urban agglomeration ecological network peri-coupling
- ecosystem service spillover telecoupling landscape resilience

### Extraction Confidence
high
