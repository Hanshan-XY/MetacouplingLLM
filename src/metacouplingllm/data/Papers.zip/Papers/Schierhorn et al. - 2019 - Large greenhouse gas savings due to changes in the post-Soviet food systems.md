LETTER • OPEN ACCESS

# Large greenhouse gas savings due to changes in the post-Soviet food systems

To cite this article: Florian Schierhorn et al 2019 Environ. Res. Lett. 14 065009

View the article online for updates and enhancements.

# You may also like

Tracking urban carbon footprints fromproduction and consumption perspectives Jianyi Lin, Yuanchao Hu, Shenghui Cui et al.   
The emission benefits of Europeanintegration

Luís Costa and Vincent Moreau

Carbon emissions from fossil fuel consumption of Beijing in 2012 Ling Shao, Dabo Guan, Ning Zhang et al.

![](images/66a94fa0643b504265a813229311407b01975d41e5d7d3ba51e2c13a0bfe924c.jpg)

250th ECS Meeting

Otober 25-29, 2026

Calgary, Canada

BMO Center

![](images/1877f6c87a1162e3d56a48b1c3be6026439bb1c74f7b4f951aba3b80a3cd74ec.jpg)

The Electrochemical Society

Advancing solid state&electrochemical science & technology

Stepintothe

Spotlight

SUBMIT YOUR

ABSTRACT

Submission deadline:

March 27,2026

# Environmental Research Letters

![](images/9fd926e85b6955ead100baeeff93e5f33f987fb1645eea1d8666c85141aacaa9.jpg)

CrossMark

# OPEN ACCESS

# LETTER

# Large greenhouse gas savings due to changes in the post-Soviet food systems

RECEIVED

13 January 2019

REVISED

27 March 2019

ACCEPTED FOR PUBLICATION

26 April 2019

PUBLISHED

21 June 2019

Original content from this work may be used under the terms of the Creative Commons Attribution 3.0 licence.

Any further distribution of this work must maintain attribution to the author(s) and the title of the work, journal citation and DOI.

![](images/e2499ce617c06c6ec105b5b022107bc1704a34c84202003614d79ed9cdcaee2b.jpg)

# Florian Schierhorn $^ 1 \oplus$ , Thomas Kastner ${ } ^ { 2 , 3 } \oplus$ , Tobias Kuemmerle $^ { 4 , 5 } \oplus$ , Patrick Meyfroidt $\cdot ^ { 6 , 7 } \textcircled { \mathbb { P } }$ 7 , Irina Kurganova8 , Alexander V Prishchepov $^ { 9 , 1 0 } \oplus _ { \textcircled { 1 0 } }$ , Karl-Heinz Erb $^ 3 \oplus$ , Richard A Houghton $^ { 1 1 } \oplus$ and Daniel Müller $^ { 1 , 4 , 5 } \oplus$

1 Leibniz Institute of Agricultural Development in Transition Economies (IAMO), Theodor-Lieser-Strasse 2, D-06120 Halle (Saale), Germany   
2 Senckenberg Biodiversity and Climate Research Centre (SBIK-F), Frankfurt am Main, Germany   
3 Institute of Social Ecology, University of Natural Resources and Life Sciences, Vienna (BOKU), Vienna, Austria   
4 Geography Department, Humboldt-Universität zu Berlin, Unter den Linden 6, D-10099 Berlin, Germany   
5 Integrative Research Institute on Transformations of Human-Environment Systems (IRI THESys), Humboldt Universität zu Berlin, Unter den Linden 6, D-10099 Berlin, Germany   
6 Georges Lemaitre Earth and Climate Research Centre, Earth and Life Institute, UCLouvain, 1348 Louvain-La-Neuve, Belgium 7 Fonds de la Recherche Scientifique F. R. S.—FNRS, B-1000 Brussels, Belgium   
8 Institute of Physicochemical and Biological Problems in Soil Science, RAS, Institutskaya st., 2, Pushchino, Moscow region 142290, Russia   
9 Department of Geosciences and Natural Resource Management, University of Copenhagen, Øster Voldgade 10, 1350 København K, Denmark   
10 Institute of Environmental Sciences, Kazan Federal University, Kazan, Tovarishcheskaya str. 5, Kazan, 420097, Russia   
11 Woods Hole Research Center, Falmouth, Massachusetts, United States of America

# E-mail: schierhorn@iamo.de

Keywords: carbon sequestration, telecoupling, trade, food’s carbon footprint, former Soviet Union

Supplementary material for this article is available online

# Abstract

As the global food system contributes significantly to global greenhouse gas (GHG) emissions, understanding the sources of GHG emissions embodied in different components of food systems is important. The collapse of the Soviet Union triggered a massive restructuring of the domestic food systems, namely declining consumption of animal products, cropland abandonment, and a major restructuring of agricultural trade. However, how these complex changes have affected global GHG emissions is uncertain. Here, we quantified the net GHG emissions associated with changes in the former Soviet Union’s food systems. Changes in food production, consumption, and trade together resulted in a net emissions reduction of 7.61 Gt carbon dioxide equivalents from 1992 to 2011. For comparison, this corresponds to one quarter of the $\mathrm { C O } _ { 2 }$ emissions from deforestation in Latin America from 1991 to 2011. The key drivers of the emissions reductions were the decreasing beef consumption in the 1990s, increasing beef imports after 2000, mainly from South America, and carbon sequestration in soils on abandoned cropland. Ongoing transformations of the food systems in the former Soviet Union, however, suggest emissions will likely rebound. The results highlight the importance of considering agricultural production, land-use change, trade, and consumption when assessing countries emissions portfolios. Moreover, we demonstrated how emissions reductions that originate from a reduction in the extent and intensity of agricultural production can be compromised by increasing emissions embodied in rising imports of agricultural commodities.

# Introduction

With approximately a quarter of total anthropogenic greenhouse gas (GHG) emissions, the global food system is a key driver of climate change (Smith et al

2014). Estimating the sources of GHG emissions embodied in major components of food systems is therefore important when developing strategies to mitigate climate change, but this is challenging for several reasons. First, global food systems are highly

complex as they encompass all processes from agricultural production to processing and distribution, are spatially very heterogeneous, include a large variety of food products, and distinct supply chains (Garnett 2011). Second, relating GHG emissions from agricultural land-use change to individual food products is difficult because both direct and indirect landuse changes are not fully understood (Arima et al 2011, Lambin and Meyfroidt 2011). Third, food systems change over time, for example due to political and economic restructuring, which often have drastic effects on food production, per capita consumption, and food trade (Müller et al 2014, Distefano et al 2018).

As a striking case in point, the breakdown of socialism in 1991 across the former Soviet Union (FSU) and transitioning from planned to market economy had drastic consequences for the region’s agricultural sector and food system (Lerman and Shagaida 2007). On the demand side, higher consumer prices and lower purchasing power substantially reduced per capita consumption of livestock products (Schierhorn et al 2016). Lower demand combined with market liberalization and diminishing state support for agriculture resulted in $5 1 \%$ and $5 2 \%$ reductions in cattle and pig numbers, respectively, across the 15 FSU countries between 1992 and 2011 (Schierhorn et al 2016, FAOSTAT 2017). The collapse of the livestock sector also contributed to widespread agricultural abandonment, defined as the cessation of agricultural land use, especially in Russia and Kazakhstan in the 1990s (Alcantara et al 2013, Schierhorn et al 2013, Kraemer et al 2015, Lesiv et al 2018). Patchy and inconsistent data have thus far prevented a consistent quantification of the effects of the collapse of the Soviet Union on GHG emissions resulting from changes in the food systems. In particular, soil organic carbon sequestered on abandoned cropland, largely due to succession of secondary vegetation (Kalinina et al 2011), has been severely underestimated in most global GHG emission accounts so far, mainly because of the lack of reliable land-use data (Schierhorn et al 2013, Houghton and Nassikas 2017).

Assessing the net impact of the collapse of the FSU on GHG emissions as well as understanding future emissions trajectories requires quantifying the effects of the massive restructuring of international trade after 1991. This is challenging as production-based national emissions inventories fail to capture the substantial GHG emissions embodied in traded agricultural commodities. Domestic food demand in the FSU countries started to rebound in the late 1990s, once economies had stabilized. Consumption of beef, the most GHG-intensive food, increased by $1 5 \%$ between 2000 and 2008, although beef production in the FSU stagnated. The region thereby became the second largest importer of beef globally (after the US), with approximately $8 0 \%$ of these imports sourced from South America between 2005 and 2010 (FAO-STAT 2017). Beef exports from South America

embody high GHG emissions due to deforestation and inefficient production systems (Berndt and Tomkins 2013, Karstensen et al 2013, Opio et al 2013). Conversely, the Soviet Union had to import large amounts of grain until the late 1980s to feed its livestock, but rebounding domestic grain production turned the region into a leading exporter of grains after 2000 (Liefert et al 2010). To date, accounting for global GHG emissions has failed to capture how changes in trade patterns affect regional GHG emission balances (Peters et al 2012).

Our main objective was to quantify the combined net GHG effect from 1992 to 2011 of (i) changes in livestock production inside the FSU, (ii) cropland abandonment inside the FSU, and (iii) feed and food trade between the FSU and other world regions. We used a new, consistent database on land-use change and associated changes in soil organic carbon stocks to quantify the emission intensities of agricultural production (emissions measured in carbon dioxide equivalents, $\mathrm { C O } _ { 2 } \mathrm { e } .$ , per unit of agricultural output), including livestock, and the emissions embodied in the trade of agricultural commodities. Based on an index decomposition approach, we identified the most important socio-economic drivers contributing to changing GHG emissions embodied in food consumption inside the FSU after 1991.

# Methods

To assess the post-Soviet changes in GHG emissions from food production and food trade, we estimate the net cumulative change in GHG emissions of all years from 1992 to 2011 minus the average emissions of 1986–1991.

# Physical trade flows

Traditional production-based national emissions inventories fail to capture the emissions embodied in trade. We used consumption-based accounting of emissions in livestock and crops and separated emissions from agricultural production and emissions embodied in traded agricultural commodities (figure 1). We used bilateral trade data from FAOSTAT of the Food and Agriculture Organization of the United Nations (FAO) for milk and meat because livestock products are mainly traded directly from the country of origin to the country where the products are consumed. In contrast, crops are often traded indirectly. For example, soybeans are shipped from South America to the Netherlands, where soybeans are converted into soy oil and cakes, which are then traded to other countries in the EU. We therefore used a physical trade flow model based on bilateral trade matrices and matrix algebra to estimate country-tocountry exports and imports of agricultural commodities via international supply chains (Kastner et al 2011).

![](images/5112a54024498d076e23bb5930c8a8d335b35c831998710d392af9d561867576.jpg)  
Figure 1. Work flow. Blue boxes represent data sources and models and grey boxes contain output datasets and results. LEAP: Livestock Environmental Assessment and Performance Model. GLEAM: Global Livestock Environmental Assessment Model. FSU: former Soviet Union.

# GHG emissions embodied in food

We multiplied annual data for production, imports, and exports of both livestock products and crops with regional data on GHG emission intensity for the FSU. We estimated the emissions embodied in food consumption for the Soviet Union and for all 15 countries that emerged after the breakup of the Soviet Union by equating food consumption with production plus imports minus exports. We derived emission intensities of livestock products from the Global Livestock Environmental Assessment Model (GLEAM, figure 1), which quantifies GHG emissions arising from production of the main livestock commodities (ruminants: Opio et al (2013); pig and chicken: MacLeod et al (2013)) based on a combination of IPCC Tier 1 and Tier 2. In GLEAM, GHG-emissions arising from the direct transformation of forest to cropland and of forest to pasture in Latin America are captured. We did not apply IPCC Tier 1 for estimating emission intensities of livestock products due to the high uncertainty inherent in Tier 1 estimates (global uncertainty: $\pm 5 0 \%$ for Tier 1 and $\pm 2 0 \%$ for Tier 2). In contrast to IPCC Tier 1, GLEAM provides a detailed assessment of the emissions of livestock products and accounts for different regions, sectors, and systems of production.

The emission intensity were calculated as averages over the period from 1990 to 2006. However, the GLEAM lacks data for changes in emission intensity over time, while both livestock productivity and crop productivity have changed substantially during the post-Soviet era. For example, synthetic fertilizer application rates for fodder crops in the early 2010s were

approximately $8 0 \%$ lower than during the final years of the Soviet era, when agricultural inputs were heavily subsidized by the state. Yields of fodder crops nevertheless had rebounded to the 1990 level by the late 2000s. This suggests that feed production became more efficient and therefore feed emissions (i.e. $\mathrm { N } _ { 2 } \mathrm { O }$ and $\mathrm { C O } _ { 2 }$ ) per kilogram of livestock produced were lower in the Soviet Union compared to the recent production systems. We complemented the GLEAM data with changes in emission intensity over time, using emissions factors and activity data reported by Annex I countries to the United Nations Framework Convention on Climate Change (UNFCCC, National Inventory Submissions 2017). Among all FSU countries, national GHG inventory data were available for Belarus, Estonia, Kazakhstan, Latvia, Russian Federation, and Ukraine and for all the years from 1990 to 2015 (UNFCCC, National Inventory Submissions 2017). Using the national inventory data, we divided annual total GHG emission from enteric fermentation $\mathrm { ( C H _ { 4 } ) }$ and manure management $\mathrm { C H } _ { 4 }$ and $_ { \mathrm { N _ { 2 } O } ) }$ of different livestock types by total annual production of meat and milk derived from FAOSTAT (2017). In this way, we used the annual national inventory data to replace the GLEAM emission intensities for enteric fermentation and manure management. For $_ { \mathrm { N } _ { 2 } \mathrm { O } }$ emissions from feed production, we divided annual $_ { \mathrm { N } _ { 2 } \mathrm { O } }$ emissions by annual cropland area, both from the national inventory data. We then divided the annual $_ { \mathrm { N } _ { 2 } \mathrm { O } }$ -to-cropland ratio by the mean $\mathrm { N } _ { 2 } \mathrm { O } \cdot$ -to-cropland ratio of the period 1992–2006 and used these annual ratios to adjust the GLEAM emission intensities for $\mathrm { N } _ { 2 } \mathrm { O }$ emissions from feed

production. For livestock imports from countries outside the FSU, we used the original GLEAM data and thus did not account for changes in emission intensity over time.

For crops other than feed production, we used emission intensity data reported by Heller and Keoleian (2015) and from the Livestock Environmental Assessment and Performance Model (LEAP). The LEAP emissions for crop production include emissions from agricultural expansion, including recultivation when it occurred, but do not account for the sink from abandoned cropland. We did not account for potential changes in emission intensity of crops over time due to missing data.

Methodological complexities and data gaps compromise estimating the emission intensity of livestock products (Opio et al 2013). Moreover, the attribution of $\mathrm { C O } _ { 2 }$ emissions from deforestation in South America to specific agricultural commodities due to indirect land-use change is challenging (Persson et al 2014). Assumptions of amortization periods over which the $\mathrm { C O } _ { 2 }$ emissions related to deforestation are distributed to the livestock products are arbitrary (Davis et al 2014). We used emission intensities for the reference period 1990– 2006, a period of high deforestation rates in the Amazon. Changing market conditions and various policy and supply chain interventions have resulted in decreasing deforestation rates since 2005 (Gibbs et al 2016). Therefore, we may have overestimated the emissions embodied in beef imported by the FSU countries after 2005.

# Drivers of changes in emissions from consumption of livestock products

We used an index decomposition analysis to identify the most important contributors to the post-Soviet changes in emissions from the consumption of livestock products. We assessed the individual contributions with the logarithmic mean Divisia index (LMDI) (Ang 2005) for the periods 1986/1991–2009/2013, 1986/1991–1998/2002, and 1998/2002–2009/2013. This index ensures perfect decomposition: the contribution of the individual factors will add up to the total overall change. Among other Index Decomposition Analysis, LMDI is simple to calculate and can handle cases with zero values without leaving residuals during analysis. The LMDI approach has often been applied to analyze the most important contributor to the changes in energy or carbon dioxide emissions (Lin and Lei 2015). The basis for decomposition analysis is the identity function that captures all potential driving factors of the process under investigation. In our identity equation, we assessed emissions embodied in consumption of livestock products as the product of population, per capita consumption, and emission intensity of the consumed livestock products. To assess the contribution of changing emission intensity caused by international trade (for

example, beef imports from South America) to the changes of the emissions embodied in consumption of livestock products, we compared the results of an index decomposition analysis with trade to a scenario without trade. In the scenario without trade, we assumed that all consumed livestock products were produced domestically.

# Soil carbon sequestration on abandoned croplands

Post-Soviet cropland abandonment was predominantly concentrated where soils and climate conditions are less suitable for farming (Schierhorn et al 2013). In general, weedy grasses and forbs, later perennial grasses colonized the former agricultural lands after the abandonment of cropland (Kalinina et al 2011). The rapidly recovering vegetation reduced soil organic carbon (SOC) losses substantially (Don et al 2011). Moreover, the increasing above-ground plant biomass and plant residues promoted carbon inputs into the soils. Soil types, soil depth, climate, topography, as well as intensity and type of the previous land use all mediate the degree of soil organic carbon sequestration on the abandoned lands (Kalinina et al 2011, Kurganova et al 2015). As the livestock sector was substantially shrinking after 1991, grazing pressure after abandonment likely was low across the FSU (Schierhorn et al 2016, Hankerson et al 2019).

Extensive inventories of in situ measurements of SOC stocks allowed us to assess the effect of land-use on changes on SOC. To estimate SOC dynamics on abandoned croplands in the FSU, we used estimates of SOC sequestration rates from field experiments (unit: t C/ha/year) that are available for various soil types in the FSU (Kurganova et al 2014, Kurganova et al 2015). For Russia, the relationship between mean SOC sequestration rate and years after cropland abandonment was described by a negative logarithmic function $( \gamma = - 0 . 6 3 \ ^ { * } \ln ( x ) + 2 . 6 8$ ; $\mathrm { R } ^ { 2 } = 0 . 7 4$ ; figure S1 is available online at stacks.iop.org/ERL/14/065009/ mmedia). For Kazakhstan, we excluded the measurements taken on Luvisol soils because Luvisols are very rare in Kazakhstan. The relationship between mean SOC sequestration rate and years after cropland abandonment was also described by a negative logarithmic function for Kazakhstan $( y = - 0 . 6 6 \ ^ { * } \ln ( x ) + 2 . 7 6 ;$ ; $\mathrm { R } ^ { 2 } = 0 . 7 2$ ; figure S2). We used the regression equation fitted for Russia and Kazakhstan to estimate SOC sequestration for the rest of the FSU. To estimate SOC sequestration (unit: Mt C y−1 ) for Russia, Kazakhstan, and the rest of the FSU for all the years between 1991 and 2011, we multiplied the predicted SOC sequestration rates with the abandoned cropland areas of the corresponding year derived from the national sown area statistics (figure S3). We calculated the accumulated sum of annual SOC sequestration to estimate total SOC sequestration due to cropland abandonment from 1991 to 2011. Finally, we used the regression equations with the abandoned cropland

![](images/4728477275320009a4d585d29fad8c907cbccbe5094a6720b90e0018710a4f40.jpg)

![](images/97d1f3cf9f421ec16a69cd4cc469b0bbdd6384c7d3cbda57be4fb64a0e865e5e.jpg)

![](images/65f1e4b9b493ddad1011aa9a11115ce14df1354d4128874b587d0d9a8ad8fa6c.jpg)

![](images/9eb0d923f817a4b3ffc4018dd27837e10bd56d34e762fea9596970c6ff1b0423.jpg)  
Figure 2. GHG emissions of food production and trade within the territory of the former Soviet Union (FSU). (A): Net cumulative change in GHG emissions of all years from 1992 to 2011 minus the average emissions of 1986 to 1991. Increasing crop exports resulted in a negative net cumulative change in emissions due to the consumption-based approach followed in this study. (B): annual rate of soil organic carbon sequestration on cropland that was abandoned after 1991 in the FSU. (C): GHG emissions embodied in domestic livestock production and in imports of livestock products to the FSU. (D): GHG emissions embodied in domestic crop production, crop exports, and imports of crops to the FSU. Note the different y-axis scales. Dashed vertical lines mark the end of the Soviet Union. Light-colored shades represent the $9 5 \%$ confidence intervals.

areas of 2014 to predict future SOC sequestration in the FSU until 2050. Our approach hinges upon the assumption that the negative logarithmic function fitted for the first few years of regeneration holds for longer time spans. Moreover, we assumed that no land-use change occurs in this scenario until 2050. Due to a lack of consistent data, we did not account for SOC sequestration due to pasture and meadow abandonment and we could also not include carbon stored in regrowing forest or any other aboveground biomass.

# Results and discussion

The post-Soviet changes in GHG emissions from food production, food trade, and cropland extent in the FSU resulted in a cumulative net reduction of 7.61 Gt $\mathrm { C O } _ { 2 } \mathrm { e }$ from 1992 to 2011 compared to a scenario in which emissions remained at the late Soviet level (figure 2). For comparison, this reduction is equivalent to $6 7 \% { - } 8 0 \%$ of the total global emissions from the Agriculture, Forestry and Other Land Use (AFOLU) sector in 2010 (9.5–11.3 Gt ${ \mathrm { C O } } _ { 2 } { \mathrm { e } } .$ , Tubiello et al 2015) or to $2 6 \%$ of the total net $\mathrm { C O } _ { 2 }$ fluxes from Forestry and Other Land Use (FOLU) in Latin America and

Caribbean from 1991 to 2011 (29 Gt $\mathrm { C O } _ { 2 } \mathrm { e }$ , accumulated using mean values reported in figure 11.7 in (Smith et al 2014)). The most important components of this net reduction in GHG emissions were the declining domestic livestock production across the FSU (4.15 Gt $\mathrm { C O } _ { 2 } \mathrm { e }$ , figure 2) and the soil organic carbon sequestration on abandoned cropland, particularly in Russia and Kazakhstan $( 1 0 9 2 . 6 \mathrm { ~ T g ~ C ~ }$ or 4.01 Gt ${ \mathrm { C O } } _ { 2 } { \mathrm { e } } .$ , figure 2). In contrast, the increase in GHG emissions embodied in domestic production of crops and imports of livestock products (figure 2) amounted to only $1 4 \%$ of the total GHG decreases $( 1 . 2 2 \mathrm { G t } \mathrm { C O } _ { 2 } \mathrm { e }$ $\mathrm { C O } _ { 2 } \mathrm { e }$ versus $8 . 8 4 \ : \mathrm { G t } \ : \mathrm { C O } _ { 2 } \mathrm { e } )$ $\mathrm { C O } _ { 2 } \mathrm { e }$ . We discuss these different components in more detail in the following sections.

# Food consumption and imports

Per capita consumption of most livestock products in the Soviet Union increased rapidly during the postwar period, driven by meat-based diets and strong government support to livestock producers and consumers (figure S4; Schierhorn et al (2016)). By the early 1990s, annual per capita consumption of beef reached $3 2 \mathrm { k g } ,$ which is $2 7 \%$ and $3 0 0 \%$ higher than the European and global average, respectively (figure S4).

![](images/12e7c496a802bb639cb3fa40f7033d1a297343f22a71386fb3bfb460d24c4811.jpg)

![](images/b6e49ad9b35f384337f776aed7595ca7b46e1e0b5e1844cd7206559dfeb87489.jpg)

![](images/8fb14d688b491cfa2c50b6270c46a0e76b5d3b7646cbd76fa37e961a4bd69c33.jpg)

![](images/9ee58e12783d99c3c9890f976f95bc757b7ade5d3b9573a26170d653c786ac90.jpg)

![](images/31a2f103d08754ef2413f38ef3faad3779cc87fe83d87d1fbc69ac45656a5581.jpg)

![](images/e505e10acccbcc12ed24ae302b47f5b3f5a8f9698b42f4df4affd1a618a7abfd.jpg)

![](images/8efccfe45f20a028c903f7241385df1d6fa84025d0c4ad362779cb9dc128848a.jpg)

![](images/51922efde7b28fa01dd644516523bbc20070d51068c043030637c75ed88119df.jpg)  
Figure 3. GHG emissions embodied in domestic livestock consumption and imports of livestock products to the FSU. Note: emissions from consumption include emissions from imports. Dashed vertical lines mark the end of the Soviet Union. GHG emissions were estimated by multiplying per capita consumption (kg/capita/year) with emission intensity $( \mathrm { k g C O _ { 2 } e / k g }$ livestock product). For imports, we multiplied the import quantity with the emission intensity. Colored shades represent the $9 5 \%$ uncertainty intervals. Note the different y-axis scales.

Within the Soviet Union, Russia had the highest per capita beef consumption (USDA 2016). At the same time, productivity in the livestock sector and fertilizeruse efficiency in feed production were low (figure S5) (Dronin and Bellinger 2005). Together, this resulted in high GHG emissions associated with livestock consumption in the Soviet Union during the 1980s and

early 1990s (figure 3). Imports of livestock products were negligible at the time, but imports of feed grains were substantial (figure 2) (Liefert and Liefert 2015).

After the collapse of the Soviet Union in 1991, diets in the FSU changed remarkably (Herzfeld et al 2014). Per capita consumption of beef decreased from $3 2 \mathrm { k g / }$ capita/year in 1990 to $1 4 . 3 \mathrm { k g / }$ capita/year in 2000

(figure S4), reflecting the severe economic crisis. Meanwhile, the emission intensity of livestock production decreased for most commodities across the FSU due to improvements in livestock productivity and fertilizer-use efficiency (figure S5; Schierhorn et al (2016)). For example, methane emissions from enteric fermentation and manure management decreased by $1 7 \%$ in Russia between 1992 and 2000. Emission intensity of beef also decreased because it was increasingly derived as a byproduct from dairy production after 1992, and parts of the livestock emissions were thus allocated to dairy products (Prikhodko and Davleyev 2014). Overall, GHG emissions embodied in livestock products consumed in the FSU decreased substantially, on average, from 0.5 Gt $\mathrm { C O } _ { 2 } \mathrm { e } _ { \prime }$ /year in 1986–1991 to 0.28 Gt $\mathrm { C O } _ { 2 } \mathrm { e }$ /year in 1997–2002 (figure 3). Declining methane emissions from enteric fermentation (limited to milk, beef, and sheep production, figure S7), declining nitrous oxide emissions related to the use of N fertilizer in feed production (mostly milk, beef, and pork production), and declining carbon dioxide emissions from feed production were the main drivers of this decline (figures 3; S6; S7). After 2000, emissions embodied in the consumption of livestock products rebounded to approximately 0.33 Gt $\mathrm { C O } _ { 2 } \mathrm { e } _ { \prime }$ /year between 2008 and 2013, amounting to $6 6 \%$ of the GHG emissions from food production and cropland use at the end of the Soviet era (mostly due to increasing beef, pork, and poultry consumption, figure 3). At the national level, per-capita emissions embodied in the consumption of livestock products differed substantially due to different diets (figure S8). Moreover, the per-capita emissions embodied in the consumption of livestock products increased particularly in Central Asia because pork consumption decreased and consumption of ruminant meats, which have much higher emissions, increased as a result of the revival of Islam in the region (figure S8). Increasing per-capita emissions in combination with strong population growth (figure S9) resulted in a drastic increase of emissions embodied in the consumption of livestock products in Central Asia after 2000. GHG emissions from the consumption of crops remained stable during the 1990s and increased after 2000, mainly due to increasing consumption of sunflower oil and vegetables (figures S10; S11).

Trade patterns changed drastically after the transition from centrally planned to market-oriented economies. During socialist times in the late 1980s, the Soviet Union was a major importer of feed grains to sustain its large domestic livestock sector, particularly from the US and South America (figure S12). These feed imports contributed annual GHG emissions of 0.04 Gt $\mathrm { C O } _ { 2 } \mathrm { e }$ between 1986 and 1991 (figure 2). Following the collapse of the FSU, emissions embodied in imported feed crops plummeted to almost zero until the mid-1990s, because the livestock sector contracted substantially and livestock herds were reduced to a small fraction (figure 2).

While the Soviet Union imported few livestock products, the region developed into a major importer after the breakdown of the Soviet Union (and here since the early 2000s). GHG emissions embodied in imports of livestock products increased more than sixfold from 0.01 Gt $\mathrm { C O } _ { 2 } \mathrm { e }$ per year from 1986 to 1991 to 0.06 Gt $\mathrm { C O } _ { 2 } \mathrm { e }$ per year from 2009 to 2013 (figure 2), with beef imports accounting for $7 5 \%$ of this increase. On average, $6 8 \%$ of the annual emissions embodied in livestock imports by the FSU countries were sourced from South America between 1998 and 2013. Beef exports from South America embody high $\mathrm { C O } _ { 2 }$ emissions per unit of product due to the expansion of pastures into tropical forests and savannas and high methane emissions from enteric fermentation, mainly because of low productivity and inefficient cattle production systems (Berndt and Tomkins 2013, Opio et al 2013, Graesser et al 2015). At the national level, GHG emissions embodied in imports of livestock products increased predominately in Russia and in the Baltic states (figure S8).

GHG emissions embodied in imported crops increased after 1995, mainly due to increased soybean imports from South America (figure S5), but emissions remained substantially below the late-Soviet levels (figure 2). Since 2000, the FSU has used its competitive advantage in wheat production and developed into an important exporter of wheat (Liefert 2002). Since 2005, the emissions embodied in crop exports have been higher than those embodied in crop imports (figure 2; S11).

# Drivers of the changes in emissions associated with livestock consumption

Using decomposition analysis, we quantified the contributions of changes in population, per capita consumption (affluence), and emission intensity (technology) on the observed decrease (0.17 Gt $\mathrm { C O } _ { 2 } \mathrm { e }$ /year) in emissions (impact) embodied in the consumption of livestock products between 1986 and 2013. Over this period, decreasing per capita livestock consumption contributed most to the declining emissions (figure 4; table S1). From 1986 to 1991 to 1998 to 2002, decreasing consumption of beef, pork, and milk were the most important drivers of decreasing emissions $- 3 5 \%$ , in total, figure S13). From 1998 to 2002 to 2009 to 2013, growing emission intensity of beef, mainly because of increasing beef imports from South America and increasing consumption of livestock products contributed considerably to the $2 8 \%$ increase in emissions. In contrast, demographic changes had little impact on the changes in emissions embodied in consumption between 1986 and 2013 (figure 4).

A counterfactual scenario assuming that all livestock products consumed in the FSU were produced inside the FSU (i.e. without international trade) indicated that trade substantially increased emissions in the period from 1998 to 2002 to 2009 to 2013

![](images/9a9838112aa3305613ee67f22d327ea92e7140a79eb4693ef2047012baa02fe3.jpg)

![](images/c0043152971ce6d2e5072a7ce762cf39ed76571ece9ce7e42cc254b8b6b045a5.jpg)  
Figure 4. Contribution of changes in population, per-capita consumption, and emission intensity to changes in emissions from the consumption of beef (A) and other livestock products than beef (B) with and without trade for two periods. Individual livestock products are shown in figure S11.

(figure 4). This is mainly because of the large beef imports from South America, a region with high emission intensities that are due to the long calving-slaughter intervals and the high deforestation footprint of ranching (Cederberg et al 2011, Opio et al 2013, Baumann et al 2017).

# Soil organic carbon sequestration on abandoned cropland

The abandonment of croplands across the FSU after the collapse of socialism was one of the most drastic episodes of land-use change in the 20th century in the northern hemisphere (Henebry 2009), leading to 62.6 Mha or $3 0 \%$ of late-Soviet cropland being abandoned from 1990 to 2011 (equivalent to approximately $5 0 \%$

of the total arable land of the European Union) (figure S3). The main reason for this was the contraction of the livestock sector and the decline in demand for fodder crops (Schierhorn et al 2016). The large majority of abandonment (59 Mha) occurred from 1990 to 2000. Some abandoned croplands have been recultivated since the late 1990s, particularly in the fertile black soil belt, but the vast majority of abandoned cropland (55.1 Mha) remains uncultivated $8 8 \%$ in Russia and Kazakhstan, where 41 Mha and 14.1 Mha, respectively, remain uncultivated; figure S3).

Several previous studies have estimated carbon accumulation rates due to farmland abandonment in the FSU (table S2). Estimates of carbon accumulation

for the first 20 years after abandonment in the FSU range between 49 and $1 2 2 \mathrm { g C } \mathrm { m } ^ { - 2 }$ to soils per year (table S2). This large variation is due to differences in calculation methods and land-use data (Kurganova et al 2014). Our empirical soil-based approach suggest that post-Soviet cropland abandonment resulted in a total soil sink of 1092.6 Tg C (4.01 Gt $\mathrm { C O } _ { 2 } \mathrm { e }$ ) until 2011, with 648.5 Tg C (2.38 Gt $\mathrm { C O } _ { 2 } \mathrm { e } )$ ) in Russia, 299.7 Tg C (1.10 Gt $\mathrm { C O } _ { 2 } \mathrm { e }$ ) in Kazakhstan, and $1 4 1 . 7 \mathrm { T g } \mathrm { C }$ (0.52 Gt $\mathrm { C O } _ { 2 } \mathrm { e }$ ) in the rest of the FSU (figure 2, see methods). For comparison, the carbon sequestered in the soils of the FSU by 2011 was larger than the carbon emissions from deforestation in the South American Chaco, a global deforestation hotspot with a forest loss of 14.2 Mha and net cumulative emissions of approximately 3 Gt $\mathrm { C O } _ { 2 } \mathrm { e }$ $( 2 0 0 \mathrm { g C } \mathrm { m } ^ { - 2 }$ per year) between 1985 and 2013 (Baumann et al 2017). From 1991 to 2011, we estimated a SOC sequestration rate of $8 3 . 1 \mathrm { g C } \mathrm { m } ^ { - 2 }$ per year for the entire FSU, which is in the mid-range of the reviewed estimates (table S2). These estimates are similar to sequestration rates obtained with a dynamic vegetation model (Schierhorn et al 2013).

In the Fifth Assessment Report of the IPCC (Smith et al 2014), emissions from forestry and other land use (FOLU) were estimated using bookkeeping models (Houghton et al 2012). Estimates for cropland and pasture change for this assessment were based on FAO land-use statistics, but these statistics are problematic for the study region. For example, according to the FAO only 10 Mha of former cropland were abandoned in Russia, which is likely more than a three-fold underestimation (Schierhorn et al 2013). The IPCC report underestimates the large terrestrial carbon sink of 4 Gt $\mathrm { C O } _ { 2 } \mathrm { e }$ on former cropland in the FSU. Recently, updated estimates with more accurate land-use data for 1991–2006 (Houghton and Nassikas 2017) are closer to our estimate than the IPCC report, but still substantially lower (figure S14), likely because cropland abandonment continued to remain underestimated for Asian Russia and Kazakhstan.

Our estimate of the post-Soviet SOC sink due to cropland abandonment of roughly 4 Gt $\mathrm { C O } _ { 2 } \mathrm { e }$ is conservative for two reasons. First, we did not account for carbon sequestration in pasture and meadow abandonment due to a lack of data, although these land-use changes were widespread (Ioffe et al 2012). However, the carbon effects of such transitions are likely comparatively small due to the much larger SOC content of managed grassland compared to cropland (Smith et al 2016). Second, forests have expanded on at least 3.5 Mha of agricultural lands in European Russia alone (Potapov et al 2015), but we did not consider the additional carbon stored in recovering forests. The omission of biomass in regrowing forests likely results in a substantial underestimation of carbon sequestration. For instance, carbon stored in aboveground biomass accounted for $6 0 \%$ of the total net emissions over the period 1991–2015 in the FSU (Houghton and

Nassikas 2017) (figure S14). In sum, our analyses suggest that cropland abandonment in the FSU may explain a considerable part of the global residual terrestrial C sink since 1991 (Erb et al 2013, Le Quéré et al 2016).

# Future tradeoffs between agriculture and GHG emissions in the FSU

Additional carbon sequestration on currently abandoned cropland can be expected in the future, with possibly up to $7 0 0 \mathrm { T g } \mathrm { C }$ (2.57 Gt $\mathrm { C O } _ { 2 } \mathrm { e }$ of additional sequestration in the FSU by 2050 (excluding land-use changes over that period, see Methods). This is equivalent to $6 4 \%$ of the amount of carbon that was sequestered between 1991 and 2011, as older abandoned croplands have lower carbon sequestration rates (Wertebach et al 2017). However, the booming agricultural sectors may trigger recultivation of abandoned land, thus preventing additional carbon sequestration and driving rapid SOC losses, particularly in Russia and Kazakhstan.

The Russian government now targets higher selfsufficiency in livestock production. From 2014 to 2016, the trade embargo on food imports from Western countries triggered a $4 2 \%$ reduction in pork imports, while pork production in Russia increased by $2 0 \%$ (USDA 2016). Increasing feed demand may trigger the recultivation of carbon-rich abandoned cropland, and thus an increase of GHG emissions from land use. While recultivation may carry a lower carbon cost per hectare compared to agricultural expansion into tropical forests, the potentially attainable crop yields in areas that are still abandoned are likely modest (Schierhorn et al 2014a), implying high emission costs per unit of feed produced (Meyfroidt et al 2016). Instead of cropland expansion, intensification on existing cropland could serve to increase feed production at low GHG emissions (Schierhorn et al 2014b, Meyfroidt et al 2016). This seems feasible given the large prevailing yield gaps in the FSU (Swinnen et al 2017). Furthermore, livestock systems that are based on the widespread rangelands, steppes, and abandoned farmland of the FSU could be an effective way to produce meat and milk at low GHG emissions footprints (Herrero et al 2016), although this GHG emissions benefit is challenged in the literature (Garnett 2017). Nevertheless, grasslands support biodiversity conservation and many other important ecosystem services (Werling et al 2014).

The dynamics of beef consumption in the FSU will be decisive for the GHG balance of the global land sector. Beef consumption in the FSU continued to decline over the past decade ( $\cdot 3 4 \%$ from 2010 to 2016), but recent restructuring of international trade relations suggests that the emission associated with beef consumption in the FSU may not decline further. Russia’s 2014 trade embargo on food imports from Western countries, including the US and the EU, contributed to

an even greater dependency on beef imports from South America (Schierhorn et al 2016), and these imports will produce high GHG emissions owing to the high GHG emission intensity of the South American livestock sector (Opio et al 2013). It would be interesting to assess the degree to which total emissions can be reduced if emissions-intensive imports are replaced with domestic products. Nevertheless, as elsewhere, shifting to diets with a low share of beef and dairy products would lower land-use pressure, and, in the case of the FSU, likely reduce GHG emissions from cropland reclamation.

Our assessment of the different components of GHG emissions from the Agriculture, Forestry and other Land Use (AFOLU) linked with an analysis of their socio-economic drivers allowed us to understand the global effects of restructuring the Soviet Union’s food systems after the collapse of socialism. We highlighted the importance of jointly considering agricultural production, land-use change, trade, and consumption when assessing countries emissions portfolios and their temporal evolution. Global GHG accountings often fail to consider the regional context as well as international trade, and hence only yield an incomplete pictures about the drivers for the emissions and are marred by substantial uncertainties about GHG emission in regional food systems. The consumption-based accounting that we used in this study highlights important insights that are of high relevance for policies aimed at emissions reductions in the food sector. The case of the FSU reveals how negative emissions due to agricultural land abandonment can be compromised by increasing emissions from rising agricultural imports, a situation that is likely similar in many industrialized and emerging regions where agricultural land use has been contracting in the recent past.

# ORCIDiDs

Florian Schierhorn https://orcid.org/0000-0002- 0243-8247   
Thomas Kastner $\textcircled{1}$ https://orcid.org/0000-0002- 8155-136X   
Tobias Kuemmerle $\textcircled{1}$ https://orcid.org/0000-0002- 9775-142X   
Patrick Meyfroidt $\textcircled{1}$ https://orcid.org/0000-0002- 1047-9794   
Alexander V Prishchepov $\textcircled{1}$ https://orcid.org/0000- 0003-2375-1651   
Karl-Heinz Erb $\textcircled{1}$ https://orcid.org/0000-0002- 8335-4159   
Richard A Houghton $\textcircled{1}$ https://orcid.org/0000-0002- 3298-7028   
Daniel Müller $\textcircled{1}$ https://orcid.org/0000-0001- 8988-0718

