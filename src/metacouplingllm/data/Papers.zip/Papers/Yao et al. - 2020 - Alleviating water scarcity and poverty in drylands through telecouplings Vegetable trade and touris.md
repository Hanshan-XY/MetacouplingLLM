# Alleviating water scarcity and poverty in drylands through telecouplings Vegetable trade and touris

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:14:54.299585+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Yao et al. - 2020 - Alleviating water scarcity and poverty in drylands through telecouplings Vegetable trade and touris.pdf
- Year: unknown
- DOI: 10.1016/j.scitotenv.2020.140387
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines how telecoupled economic activities - specifically vegetable exports and tourism - can simultaneously ease water scarcity and rural poverty in a dryland context. The case is Zhangye City in the middle reaches of the Heihe River Basin, an arid, agriculture-dependent region in northwest China. The work is explicitly grounded in the telecoupling framework, focusing on flows of goods, people, income, and virtual water between Zhangye and distant regions.

The authors integrate hydrological simulation, crop water-use modeling, and socioeconomic statistics from 2000 to 2012. An existing physically based hydrological model provides estimates of surface and groundwater availability. A crop model (CropWat) is used to compute crop water requirements and virtual water embedded in agricultural products. Statistical yearbooks and tourism records supply data on production, trade volumes, prices, tourist numbers, and incomes.

Water scarcity is evaluated using a composite water scarcity index that combines three standardized dimensions: physical availability of water, rural income as a measure of affordability, and the share of water allocated to nonagricultural sectors as an indicator of social adaptability. Scenario analyses compare the historical development of vegetable trade and tourism with counterfactual paths where these sectors are not promoted or are replaced by grain or rapeseed cultivation, or by each other.

Results show that total water availability increased over the study period due to climate-related changes, while the dominance of agricultural withdrawals declined slightly. Vegetable trade emerged as a major contributor to both water saving and income growth: it accounts for roughly one-third of total water savings and about one-third to two-fifths of the increase in rural per capita income under water-use constraints. Tourism initially had limited water-saving effects, but as markets expanded, its contribution to saving water rose substantially, while also boosting broader local GDP.

The paper is clearly about metacoupling/telecoupling. It demonstrates how distant economic linkages in non-grain agriculture and tourism can reconfigure local water allocation, enhance water-use efficiency, and reduce poverty in drylands, while also emphasizing the decisive roles of climate variability, policy, and social structure in shaping long-term water sustainability.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via vegetable trade and tourism; intracoupling within Heihe Basin socio-hydrological system; limited pericoupling detail.

### Intracoupling
#### Systems
- Zhangye city oasis socio-hydrological system in middle Heihe River Basin
- Local agricultural production system shifting from grain to vegetables
- Local tourism destinations, infrastructure, and urban water supply
#### Flows
- Irrigation water from Heihe River and groundwater to crops
- Tap water and virtual water for local residents and tourists
- Financial flows from agriculture and tourism to rural households
#### Agents
- Local farmers dependent on irrigation and crop choice
- Zhangye municipal and basin water managers
- Local tourism operators and service workers
#### Causes
- Regional water scarcity and rural poverty in arid northwest China
- Policy support for water efficient industries and industrial upgrading
- Climate driven increases in rainfall and surface runoff
#### Effects
- Reduced share of agricultural water and more for nonagricultural sectors
- Higher rural per capita income and improved affordability
- Relief of local water scarcity indexed by composite WSI

### Pericoupling
#### Systems
- Not identified.
#### Flows
- Not identified.
#### Agents
- Not identified.
#### Causes
- Not identified.
#### Effects
- Not identified.

### Telecoupling
#### Systems
- Export region: Zhangye and middle Heihe River Basin drylands
- Domestic destination regions for traded vegetables in China
- International markets and inbound tourism origins
#### Flows
- Trade of vegetables embodying virtual water exports
- Tourist movements bringing virtual and direct water use
- Financial remittances from external consumers and tourists
#### Agents
- Central and provincial Chinese governments promoting telecoupled industries
- Traders and logistics firms moving vegetables nationwide and abroad
- Domestic and international tourists visiting Zhangye attractions
#### Causes
- Improved transportation like high speed rail enabling distant interactions
- National policies encouraging non grain food trade and tourism
- Global and domestic demand for vegetables and Silk Road tourism
#### Effects
- Vegetable trade saves regional water compared with local grain or rapeseed
- Telecoupled income significantly boosts rural livelihoods under water limits
- Tourism gradually contributes to water saving and GDP diversification

### Cross-Coupling Interactions
- Vegetable trade and tourism jointly reallocate limited water among sectors
- Industry transformation mediates climate driven water availability impacts
- Tourism benefits urban and rural incomes but depends on agricultural labor structure

### Research Gaps or Limitations
- Limited coverage of receiving systems environmental and social impacts
- Uncertainty in future climate, policy, and technology trajectories
- Assumptions about constant income and water use shares may oversimplify dynamics

### Search Keywords
- telecoupling vegetable trade tourism Heihe River Basin Zhangye
- virtual water export poverty alleviation drylands
- water scarcity index hydrological socioeconomic integration

### Extraction Confidence
high
