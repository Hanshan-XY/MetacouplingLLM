# An integrated biophysical and ecosystem approach as a base for ecosystem services analysis across re

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:44:16.063483+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Fridman and Kissinger - 2018 - An integrated biophysical and ecosystem approach as a base for ecosystem services analysis across re.pdf
- Year: unknown
- DOI: 10.1016/j.ecoser.2018.01.005
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper develops and applies an integrated framework to connect global food trade with ecosystem services and dis-services, using Israel’s staple crop supply as a case study.

The study focuses on four major crops - wheat, maize, soybeans, and rice - that are traded internationally and form a large share of Israel’s calorie intake. The geographic scope is global production regions supplying Israel, with analysis at roughly 10 km grid resolution. The system context is the global food system, emphasizing how importing countries depend on remote ecosystems and how their consumption drives environmental pressures elsewhere.

Methodologically, the authors combine two strands of analysis: (1) biophysical accounting of land and blue water embodied in crop production and trade, and (2) ecosystem-state indicators capturing potential soil erosion and water scarcity. They use FAO trade and food balance data, a spatial crop production allocation model (SPAM), global water footprint estimates, a global soil loss model based on USLE, and a global aridity index. These datasets are combined into a typology of 24 functional regions, defined by yield level, irrigation water efficiency, aridity, and soil erosion risk. National imports to Israel are downscaled to sub-national production areas, allowing assignment of Israel’s supply to specific functional regions.

Results show that the four staples provide around half of Israel’s agricultural demand by weight and about 60 percent of calorie intake. More than half of this supply originates in areas with high potential soil loss, and roughly 15 percent comes from water-scarce regions. Eight functional region types account for over 90 percent of Israel’s staple supply, including both high-yield, relatively benign regions and high-yield but erosion-prone regions. The analysis also identifies substantial cultivation in biophysically suboptimal areas, implying room to reduce environmental impacts through sourcing shifts and land-use reallocation.

The paper explicitly engages telecoupling and interregional sustainability concepts. It links flows of provisioning services (food) from sending to receiving regions with spatially explicit ecosystem dis-services (soil erosion and water scarcity), illustrating how an importing country’s food security is telecoupled to environmental conditions and risks in distant production landscapes.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong telecoupling via traded staple crops and embedded ecosystem impacts

### Intracoupling
#### Systems
- Not identified.
#### Flows
- Not identified.
#### Agents
- Not identified.
#### Causes
- Not identified.
#### Effects
- Not identified.

### Pericoupling
#### Systems
- Not identified.
#### Flows
- Not identified.
#### Agents
- Not identified.
#### Causes
- Not identified.
#### Effects
- Not identified.

### Telecoupling
#### Systems
- Israel food consumption system as receiving region
- Global crop production regions as sending systems
#### Flows
- Trade flows of wheat maize soybeans rice and derivatives
- Embodied land blue water and potential soil loss in trade
#### Agents
- Farmers and agribusiness in exporting countries
- Importers retailers and policy makers in Israel
#### Causes
- Globalized food system and interregional sustainability dependencies
- Domestic demand for calories livestock feed and processed foods
#### Effects
- High soil erosion risk and water scarcity in production hotspots
- Consumption driven environmental pressures displaced to distant ecosystems

### Cross-Coupling Interactions
- Functional regions combine local biophysical conditions with distant consumption drivers
- Trade offs between yield water use and soil loss across regions

### Research Gaps or Limitations
- Global datasets limited in years resolution and ecosystem variables
- Subnational export patterns approximated by proportional national exports

### Search Keywords
- functional regions telecoupling Israel staple crops soil loss water scarcity
- biophysical accounting ecosystem services dis services SPAM blue water footprint

### Extraction Confidence
high
