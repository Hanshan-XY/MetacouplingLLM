# Spatial-temporal coupling between the global digital economy and sustainable development_ å…¨çƒæ•°å

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:13:00.593846+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Xu and Song - 2025 - Spatial-temporal coupling between the global digital economy and sustainable development_ å…¨çƒæ•°å.pdf
- Year: unknown
- DOI: 10.13249/j.cnki.sgs.20231200
- OA status: unknown
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: no license info, oa_status=unknown

## Copyright-Safe Summary
This paper analyzes how the global digital economy and sustainable development interact over space and time, framed explicitly within a metacoupling perspective (internal, nearby, and distant couplings among systems).

The study is global in scope, covering 106 countries and regions from 2016 to 2021. The authors build a composite digital economy index based on three dimensions: digital infrastructure, digital economic environment, and digital economic market (ICT goods and services trade). Sustainable development is measured using the UN SDG Index, averaged across all 17 goals and grouped into economic, social, and environmental dimensions. A standard coupling and coupling-coordination model evaluates how tightly and how harmoniously the two systems evolve. Geodetector is used to identify key drivers and interaction effects behind spatial differentiation in coupling coordination.

Results show that both digital economy and SDG levels have risen globally, but with pronounced regional disparities. Europe and North America generally achieve higher scores, while sub-Saharan Africa and parts of South and Southeast Asia lag behind, reflecting strong digital divides and uneven SDG progress. The digital economy and sustainable development are highly coupled in a statistical sense, yet the coordination level is only in an intermediate stage and far from optimal. Most countries exhibit digital economy lagging behind their SDG performance; truly synchronized development is rare.

Spatially, coordination is strongest in Northern and Western Europe and weakest in sub-Saharan Africa. Geodetector results indicate that no poverty (SDG1) and digital infrastructure are the most influential factors, and their interaction, along with combinations involving SDG9, SDG6, and SDG5, strongly enhances coordination. The authors interpret the dynamics through internal drivers (data as a new form of productivity, transformative and disruptive effects of digital technologies, and resource constraints) and external drivers (market forces that can both stimulate and unbalance development, and government regulation that can facilitate or hinder cross-border data and digital trade flows).

The work directly contributes to telecoupling/metacoupling research by applying the metacoupling framework to global digital-sustainability linkages and by highlighting how cross-scale, cross-border flows of data, goods, and environmental impacts shape coupled human-environment systems.

## Structured Metacoupling Extraction

### Coupling Classification
- Uses metacoupling framework to analyze intra, nearby, and distant coupling of digital economy and SDGs

### Intracoupling
#### Systems
- National or local digital economy system within one country or region
- Same area sustainable development system across economic social environmental dimensions
- Human land relationship system shaped by digitalization and SDGs
#### Flows
- Data flows within regions via platforms networks and digital infrastructure
- Capital and labor reallocated by local digital industries and services
- Information and knowledge flows supporting local SDG implementation
#### Agents
- National and local governments designing digital and SDG policies
- Enterprises platform firms ICT providers and data centers
- Households workers and vulnerable groups affected by digital divide
#### Causes
- Expansion of ICT infrastructure and digital services inside countries
- SDG agenda demanding integrated economic social environmental progress
- Internal drivers such as data productivity and digital technology change
#### Effects
- Rising national coupling coordination from primary to intermediate level
- Unequal local access producing internal digital divide and inclusion issues
- Changes in employment structures innovation patterns and poverty reduction

### Pericoupling
#### Systems
- Neighboring cities and city clusters linked by digital infrastructure
- Adjacent countries within same world region
- Regional value chains in ICT manufacturing and services
#### Flows
- Material flows of ICT products traded within regions
- Regional data and information exchanges across nearby networks
- Pollution and resource transfers from smart city projects to surroundings
#### Agents
- Regional governments and inter city alliances
- Cross border regional firms in ICT and logistics
- Regional organizations coordinating SDG and digital policies
#### Causes
- Flow space integrating virtual and physical spaces at regional scales
- Market driven regional specialization in ICT production
- Policy coordination for regional sustainable development and connectivity
#### Effects
- Spatial clustering of high coordination in Europe and North America
- Spillover of pollution or resource pressure to neighboring areas
- Regional disparities where some subregions stay near disordered coupling

### Telecoupling
#### Systems
- Global digital economy spanning multiple distant countries
- Sustainable development systems in exporting and importing nations
- Global human land system shaped by data and resource flows
#### Flows
- Cross border trade of digital goods and ICT services
- Transnational data flows including platforms cloud and cross border e commerce
- International transfer of e waste causing environmental and health impacts
#### Agents
- Multinational digital platforms and ICT corporations
- International organizations promoting SDGs and digital indicators
- National governments setting data sovereignty and digital trade rules
#### Causes
- Globalization of ICT markets and digital technologies
- External market pulling and imbalance forces in digital sectors
- Government regulations digital trade barriers and security concerns
#### Effects
- Global digital divide between advanced regions and Sub Saharan Africa or South Asia
- Telecoupled carbon emissions and resource use embedded in digital trade
- Cross border e waste dumping degrading environments in poorer countries

### Cross-Coupling Interactions
- Internal data productivity and external markets jointly shape multi scale coupling evolution
- SDG1 poverty reduction interacts strongly with digital infrastructure across distances
- Economic social environmental SDGs interact with digital factors producing complex spillovers

### Research Gaps or Limitations
- Previous work focused on one way digital impacts lacking full metacoupling logic
- Current study mostly qualitative on coupling dynamics needing quantitative force estimation
- Limited by data availability to 106 economies and short 2016 2021 period

### Search Keywords
- digital economy and sustainable development metacoupling
- coupling coordination degree Geodetector SDG1 digital infrastructure
- global digital divide ICT trade e waste telecoupling

### Extraction Confidence
high
