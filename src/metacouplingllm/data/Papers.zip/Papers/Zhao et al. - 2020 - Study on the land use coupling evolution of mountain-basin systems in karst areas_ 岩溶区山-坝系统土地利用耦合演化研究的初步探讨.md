# Study on the land use coupling evolution of mountain-basin systems in karst areas_ å²©æº¶åŒºå±±-åç

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:20:08.866074+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Zhao et al. - 2020 - Study on the land use coupling evolution of mountain-basin systems in karst areas_ å²©æº¶åŒºå±±-åç.pdf
- Year: unknown
- DOI: 10.11932/karst2019y38
- OA status: unknown
- License: none recorded
- Category: Journal Articles\Conceptual\Telecoupling
- Closed-access reason: no license info, oa_status=unknown

## Copyright-Safe Summary
This conceptual paper focuses on how land use in linked mountain and basin systems evolves in karst regions of southwest China, especially under rapid urbanization and poverty alleviation policies. The geographic emphasis is Guizhou and similar karst mountain areas where steep slopes are extensive, flat basin farmland is scarce, and ecological fragility and rural poverty are acute.

The authors argue that mountain-basin land systems are tightly interconnected: basin plains provide high-quality farmland and space for towns and industry, while surrounding mountains supply labor and ecological functions. Recent decades of urbanization and industrialization have converted large areas of basin cropland to construction land and higher value agriculture, while rural-urban migration has driven land abandonment, forest recovery, and hollowed villages in adjacent mountains. Existing studies often examine basin land conversion or mountain land marginalization separately, but rarely treat them as a coupled system.

Using telecoupling as the central theoretical lens, the paper proposes an analysis framework that views people, goods, information, capital, and technology flows between mountains, basins, and external regions as key drivers of land use change. It outlines four main research themes: (1) describing spatio-temporal patterns and vertical gradients of coupled land use change in mountain-basin systems; (2) identifying driving mechanisms at macro (policies, markets, urbanization) and micro (household livelihoods and behavior) levels; (3) classifying evolution types and phases and designing differentiated management models for various mountain-basin types and locations; and (4) assessing how these land changes reshape production-living-ecological space and its functions.

The authors also sketch a methodological roadmap combining GIS and remote sensing, household surveys, landscape metrics, and modeling for case studies in typical karst mountain-basin systems.

The work is explicitly about telecoupling and closely related metacoupling ideas, applied to internal regional linkages between mountains, basins, and outside regions. It mainly contributes a problem statement, conceptual framework, and research agenda rather than empirical results, aiming to guide future studies and land-use policy for coordinated mountain-basin management in karst areas.

## Structured Metacoupling Extraction

### Coupling Classification
- Focuses on telecoupling between karst mountains and basins
- Also analyzes intra-system dynamics within mountains and basins

### Intracoupling
#### Systems
- Mountain land system in karst areas
- Basin farmland and construction land system
#### Flows
- Internal land use transitions within basins and surrounding mountains
- Local adjustments of production living ecological spaces
#### Agents
- Mountain households and village collectives
- County and township governments managing land
#### Causes
- Local land scarcity and steep terrain constraints
- Village hollowing and changing household livelihoods
#### Effects
- Abandonment and reforestation of sloping cropland
- Reduced land use intensity in depopulated villages

### Pericoupling
#### Systems
- Adjacent mountain villages around basins
- Neighboring basins within same karst region
#### Flows
- Short distance commuting and nearby urbanization
- Spillover of construction land into surrounding farmland
#### Agents
- Nearby small towns and county seats
- Developers expanding industrial and residential land
#### Causes
- Policies promoting nearby urbanization and relocation
- Transport improvements linking basins and nearby mountains
#### Effects
- Concentration of population in accessible basins
- Spatial reorganization of rural settlements around basins

### Telecoupling
#### Systems
- Karst mountain basin systems in Southwest China
- External urban and industrial destination regions
#### Flows
- Rural urban migration from mountains to cities
- Flows of capital technology and information into basins
#### Agents
- Migrant workers and their households
- Central and provincial governments designing poverty policies
#### Causes
- National western development and poverty alleviation strategies
- External urbanization and industrialization attracting labor
#### Effects
- Farmland occupation by construction in basins
- Sloping land abandonment and forest transition in mountains

### Cross-Coupling Interactions
- Telecoupled migration simultaneously drives basin land loss and mountain land abandonment
- Policies reshape multi scale land use coupling among mountains basins and outside regions

### Research Gaps or Limitations
- Lack of integrated analysis of coupled mountain basin land dynamics
- Need empirical models linking macro drivers and household behaviors

### Search Keywords
- karst mountain basin land use telecoupling China
- rural urban migration land system coupling

### Extraction Confidence
high
