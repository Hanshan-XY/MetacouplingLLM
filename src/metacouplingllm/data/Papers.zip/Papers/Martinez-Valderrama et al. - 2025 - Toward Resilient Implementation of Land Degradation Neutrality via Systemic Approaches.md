Article

# Toward Resilient Implementation of Land Degradation Neutrality via Systemic Approaches

Jaime Martínez-Valderrama $^ { 1 , * \oplus }$ , Jorge Andrick Parra Valencia ${ } ^ { 2 } \textcircled { \mathbb { D } }$ , Tamar Awad 3, Antonio J. Álvarez $^ 4 \oplus _ { i }$ D Rocío M. Oliva ${ \mathfrak { s } } _ { \oplus }$ , Juanma Cintas $\mathbf { 1 } _ { \textcircled { [ [  ] }  }$ and Víctor Castillo $\mathbf { 6 } \oplus \mathbf { \rho }$

1 Estación Experimental de Zonas Áridas, CSIC, Ctra. Sacramento s/n, La Cañada, 04120 Almería, Spain; jmcintas@eeza.csic.es   
2 Facultad de Ingeniería, Universidad Autónoma de Bucaramanga, Bucaramanga 680001, Colombia; japarra@unab.edu.co   
3 Departamento de Ideación Gráfica Arquitectónica, Universidad Politécnica de Madrid, 28040 Madrid, Spain; t.awad@upm.es   
4 Departamento de Ingeniería, Universidad de Almería, 04120 Almería, Spain; ajalvare@ual.es   
5 Departamento Agroforestal y Ambiental, Facultad de Ciencias y Artes, Universidad Católica de Ávila, Calle Canteros S/N, 05005 Ávila, Spain; rocio.oliva@ucavila.es   
6 Centro de Edafología y Biología Aplicada del Segura, CSIC, 30100 Murcia, Spain; victor@cebas.csic.es   
* Correspondence: jaimonides@eeza.csic.es

![](images/0d0a3e031c742087203c1ce55226b4dbc5251953fb78e4ca2bf037be3cc33359.jpg)

check for updates

Academic Editor: Alberto

Paucar-Caceres

Received: 17 March 2025

Revised: 4 May 2025

Accepted: 23 May 2025

Published: 24 May 2025

Citation: Martínez-Valderrama, J.;

Valencia, J.A.P.; Awad, T.; Álvarez, A.J.;

Oliva, R.M.; Cintas, J.; Castillo, V.

Toward Resilient Implementation of

Land Degradation Neutrality via

Systemic Approaches. Systems 2025,

13, 408. https://doi.org/10.3390/

systems13060408

Copyright: © 2025 by the authors.

Licensee MDPI, Basel, Switzerland.

This article is an open access article

distributed under the terms and

conditions of the Creative Commons

Attribution (CC BY) license

(https://creativecommons.org/

licenses/by/4.0/).

Abstract: Land Degradation Neutrality (LDN) is an ambitious initiative by the United Nations Convention to Combat Desertification (UNCCD) to tackle land degradation. Inspired by the “no net loss” concept, LDN seeks to counterbalance unavoidable land degradation—primarily driven by food systems—through targeted regenerative actions at multiple scales—such as regenerative agriculture or grazing practices that simultaneously support production and preserve land fertility. The objective is to ensure that degradation does not surpass the 2015 baseline. While the UNCCD’s Science–Policy Interface provides guidance and the LDN Target Setting Programme has led many countries to define baselines using agreed indicators (soil organic carbon, land use change, and primary productivity), concrete intervention strategies often remain poorly defined. Moreover, the voluntary nature of LDN has limited its effectiveness. A key shortcoming is the lack of integrated planning. LDN should function as a “Plan of Plans”—a coordinating framework to align policies across sectors and scales, reconciling conflicting agendas in areas such as food, energy, and water. To this end, we advocate for a systemic approach to uncover synergies, manage trade-offs, and guide decision-making in complex socio-ecological landscapes. Land degradation is intricately linked to issues such as food insecurity, land acquisitions, and transboundary water stress. Although LDN is implemented at the national level, its success also depends on accounting for global dynamics—particularly “LDN leaks”, where land degradation is outsourced through international trade in food and raw materials. In an increasingly complex world shaped by globalization, resource depletion, and unpredictable system dynamics, effective responses demand an integrated socio-ecological management approach. LDN is not simply a strategy to address desertification. It offers a comprehensive framework for sustainable resource management, enabling the balancing of trade-offs and the promotion of long-term resilience.

Keywords: desertification; global change; food system; telecoupling; restoration; water gap

# 1. Introduction

Land degradation is a pressing global issue that poses significant threats to ecosystem services, food security, and human livelihoods. The United Nations has recognized this

challenge and set forth the goal of achieving Land Degradation Neutrality (LDN) by 2030 as part of the Sustainable Development Goals (SDGs). LDN has emerged as the leading strategy for addressing land degradation. The growing political acknowledgment of land’s essential role in achieving sustainable development was underscored at the United Nations General Assembly High-Level Meeting in 2011, where it was declared that “. . .the time had come to commit for building a land degradation neutral world. . .” [1,2]. With strong backing from a wide range of stakeholders, the concept of a “land degradation neutral world” was formally included in the United Nations Conference on Sustainable Development $( \mathrm { R i o } + 2 0 )$ outcome document The Future We Want. Among its key advocates were the United Nations Convention to Combat Desertification (UNCCD) and the scientific community, both of which had been promoting the concept of zero net land degradation (ZNLD) [3,4]. Following extensive political and scientific consultations, the ZNLD concept evolved into what is now known as Land Degradation Neutrality (LDN) [5,6].

The UNCCD defines LDN as “a state whereby the amount and quality of land resources necessary to support ecosystem functions and services and enhance food security remain stable or increase within specified temporal and spatial scales and ecosystems” (decision 3/COP.12, UNCCD) [7]. LDN is integrated into the Sustainable Development Goals (SDGs), specifically under Target 15.3, which aims to “combat desertification, restore degraded land and soil, including land affected by desertification, drought and floods, and strive to achieve a land degradation-neutral world” by 2030 [8].

The Scientific Conceptual Framework for LDN is a recent paradigm endorsed by the UNCCD and developed by its Science–Policy Interface (SPI). The framework is structured into five interconnected modules (Figure 1) [9,10]. Module A sets out the vision and objectives of LDN: (i) to maintain or enhance the sustainable provision of ecosystem services; (ii) to promote synergies with other social, economic, and environmental goals (e.g., the SDGs and UN Conventions on Climate Change and Biological Diversity); and (iii) to support inclusive and responsible land governance.

![](images/12bcccb1a9b47626ef5bb4a6fc6dda03b2f3bf649b6d3334fd3a8a12fc796a04.jpg)  
Figure 1. Modules comprising the Scientific Conceptual Framework for LDN and detailing the objectives of Module C, in which a mechanism for achieving degradation neutrality is to be proposed.

Module B defines the reference state against which future land condition will be assessed. This is a critical and often contested element in desertification studies [11], as degradation is only meaningful when measured against a non-degraded benchmark. Thus, the initial values of the indicators (outlined in Module E) represent the baseline, and any future deviations serve as the basis for assessing progress toward neutrality.

Module C, the primary focus of this study, represents a pivotal step prior to the operationalization of LDN (covered in Module D). While Modules A, B, and E are generally well defined—albeit open to further refinement—Module C remains under development and continues to evolve. As academic interest in LDN grows, most research to date has focused on LDN indicators [12]. However, few studies have explored the framework’s conceptual foundations. One notable exception is Zucca et al. [13], who examined sustainable land management planning based on an impact assessment of land use and land management transition aimed at achieving LDN.

The primary objective of Module C is to ensure that anticipated land degradation is counterbalanced by planned positive actions elsewhere. The neutrality mechanism should be applied within spatial domains that align with biophysical characteristics (e.g., catchments) or administrative units (e.g., provinces) commonly used in land use planning and policy-making. Moreover, this mechanism must also be scalable to enable consistent reporting at the national level. Ideally, neutrality should be integrated into existing land use planning frameworks and implemented through established institutions, promoting coherence and operational efficiency.

Once future land uses have been strategically planned to maintain neutrality, Module D outlines the core components of a logical framework for the practical implementation of LDN. This module is based on the principle of prevention, recognizing that avoiding or minimizing further degradation is generally more cost-effective than restoring already degraded land [9]. Module D provides guidance on key implementation aspects, particularly governance, and emphasizes the need to embed LDN targets within the National Action Plans (NAPs) under the UNCCD framework.

One of the central challenges in implementing LDN, particularly in the context of Module $C ,$ is the adoption of a holistic approach that simultaneously considers the diverse elements influencing land use, land degradation, policy frameworks, and societal perceptions [14]. A systemic perspective (i.e., an approach that considers the interconnections, feedback, and interdependencies among ecological, social, economic, and institutional components within land systems) is essential for minimizing overlaps and contradictions among actions or plans with shared components.

Because land systems changes occur at the interface of social and ecological processes [15], effectively addressing these challenges requires insights from the social sciences, natural sciences, and humanities to foster a renewed culture of land stewardship. Innovative strategies grounded in interdisciplinarity, systems thinking, and adaptive governance are critical for tackling the ecological and societal drivers of land system transformation. Such approaches enable more integrated and sustainable land resource management [16].

This article aims to explore how a systemic approach can effectively address the complex challenges associated with implementing LDN. First, we present the conceptual foundations of this approach and its relevance to the dilemmas posed by Module C. Then, we examine specific case examples to illustrate how systemic thinking helps navigate the trade-offs that can arise from seemingly straightforward actions, such as ecosystem restoration, which require nuanced and context-sensitive implementation. Finally, we discuss the broader potential of this approach to support coherent, adaptive, and integrated strategies for achieving LDN.

# 2. Unraveling LDN Knots Through a Systemic Lens

# 2.1. A Systemic Approach to Understanding Complex Mechanisms

The consequences of land degradation go beyond environmental decline, affecting poverty, food security, and climate resilience [17]. As noted in the literature, vulnerable com-

munities that depend directly on natural resources are disproportionately impacted [18,19]. Therefore, achieving LDN requires more than just restoring degraded lands; it also calls for sustainable land management practices that strengthen ecosystems and community resilience [20]. This integrated approach is essential to ensure the continued provision of ecosystem services and to support the well-being of both present and future generations [5]. A systemic approach to understanding land degradation is essential to effectively address desertification and land degradation. This perspective considers the complex interactions between ecological, social, and economic factors that drive the degradation processes [21,22]. Rather than examining individual components in isolation, a systemic lens considers the full spectrum of components. The key aspects of the systemic lens approach are as follows:

Holistic Perspective: Understanding how different elements within a system interact and influence one another.

Interconnectivity: Recognizing that changes in one area can impact others.

Dynamic Nature: Systems are dynamic, with interactions that can change over time and require adaptive and flexible responses.

Multi-disciplinary: Integrating knowledge from various fields and disciplines to understand the complexities of the system.

Stakeholder Engagement: Emphasizes the importance of integrating varied stakeholder perspectives.

Feedback loops: Identifying reinforcing or balancing cycles that influence system behavior.

Adaptive management: Supports learning and adaptation based on new information or changing conditions, allowing for the ongoing refinement of strategies.

Long-term outlook: Balancing short-term impacts with long-term sustainability.

Applying a systemic lens enables more sustainable, effective, and equitable solutions—ones that address root causes rather than symptoms while enhancing overall system resilience. One of the primary challenges in achieving LDN is the lack of standardized methodologies for monitoring and assessing land degradation across different contexts. Current approaches often rely on remote sensing data and various indicators; yet these can yield inconsistent outcomes due to local variability and the subjectivity in indicator selection [23]. While remote sensing provides valuable data for assessing land cover changes, it may overlook nuanced socioecological dynamics contributing to land degradation [22,24]. This underscores the need for an integrated and adaptive monitoring framework that can accommodate the diverse realities of land degradation across different regions.

Governance also presents challenges. LDN implementation is often hampered by policies that fail to reflect local realities or engage key stakeholders, particularly farmers, who are critical land stewards [21,25]. Top-down approaches may overlook local knowledge, creating a disconnect between policy and practice [2]. A systemic approach—one that incorporates local voices and fosters inclusive collaboration—is essential for developing context-specific, effective responses to land degradation [26].

# 2.2. Methodological Proposals for Adopting a Systemic Approach

There are various methodological approaches to integrating the connections between the different elements of a system. While not exhaustive, the following methods offer valuable tools for addressing potential conflicts and promoting sustainable land management through collaborative, multi-stakeholder processes. Applying a systemic lens to address potential conflicts in LDN requires the integration of techniques such as cognitive maps, participatory modeling, causal mapping, and participatory mapping techniques. By involving stakeholders in the decision-making process and fostering collaborative governance, these methods can deepen our understanding of complex land use dynamics and support sustainable land management practices.

Cognitive maps are effective for visualizing complex relationships and integrating diverse stakeholder perspectives in land use planning. By representing perceptions of land use, environmental conditions, and socioeconomic factors, cognitive maps enhance decision-making and facilitate the identification of vulnerable areas requiring sustainable management. By bridging scientific data with local knowledge, cognitive mapping supports a holistic understanding of land degradation and its drivers. Tools like the LUP4LDN framework illustrate how geoinformatics and cognitive mapping can be combined to create targeted strategies that address both ecological and socioeconomic challenges [13]. Additionally, cognitive maps improve communication among stakeholders by visually representing complex data, fostering collaborative discussions, and ensuring socially and environmentally sustainable land management strategies. Overall, cognitive mapping promotes a participatory, adaptive, and context-specific approach to combating land degradation.

Participatory modeling actively involves stakeholders in the development and application of models that represent land use scenarios and their potential impacts. This approach empowers local communities and strengthens their commitment to land stewardship [27]. For instance, participatory scenario planning has been successfully used to evaluate tradeoffs between food security and biodiversity conservation, highlighting the importance of multi-stakeholder participation in governance systems [28]. By integrating local knowledge into these models, strategies can be tailored to the specific needs and realities of different regions.

Causal mapping helps visualize and analyze the interrelated factors driving land degradation and land use conflict. This technique clarifies causal relationships among environmental, social, and economic variables, allowing stakeholders to identify underlying drivers and explore potential synergies and conflicts. For example, mapping interactions between land use practices, ecosystem services, and community well-being can guide decision-making toward effective and balanced LDN interventions.

Participatory mapping, including tools like Public Participation Geographic Information Systems (PPGIS), can be employed to gather spatial data on community values and perceptions regarding land use. This method allows stakeholders to visually represent their priorities and concerns on maps, facilitating discussions on land use conflicts and the establishment of potential solutions [29]. For instance, participatory mapping has been used to identify areas of high conflict potential in coastal and marine environments, providing valuable insights for managers to assess the compatibility among different land uses [30]. When integrated with causal and participatory modeling, they contribute to a comprehensive and inclusive decision-making framework.

In addition to these techniques, iterative stakeholder engagement is essential for adaptive governance. Ongoing dialog ensures the inclusion of new insights and allows for flexible responses to emerging challenges [31]. This iterative process enhances the resilience of socio-ecological systems, and fosters trust and collaboration among stakeholders, which is essential for achieving LDN.

# 3. The Systemic Lens for Addressing Some Potential LDN Conflicts

Implementing LDN requires navigating trade-offs among the many interrelated components of the complex socio-economic systems we have constructed. In particular, the neutrality mechanism outlined in Module C must consider the multiple interconnections that arise when allocating a territory’s resources to meet the diverse and evolving needs of its population. This section highlights three key conflicts that must be addressed to design effective neutrality mechanisms. Causal diagrams are used to illustrate the main interactions between the elements involved.

# 3.1. The Water-Energy-Food Nexus

Agriculture is widely recognized as the leading driver of desertification [32]. As it directly depends on soil and water, it forms a critical link between ecosystems and the economy. Globally, food systems are responsible for $8 0 \%$ of deforestation and $7 0 \%$ of freshwater withdrawals, and represent the single largest driver of terrestrial biodiversity loss [33].

The intensification of agriculture—spurred by changing lifestyles, urban migration, and population growth, among other factors—has led to increased consumption of energy and water to sustain a continuous supply of increasingly affordable food. By 2050, the global population is expected to rise from 7.4 billion in 2016 to 9.7 billion [34]. Consequently, global demands for water, energy, and food are projected to increase by $5 5 \%$ , $8 0 \%$ , and $6 0 \%$ , respectively [35], compared to 2015 levels (see Figure 2). Climate change further exacerbates this competition, creating significant trade-offs among food security, water security, and energy security [36].

![](images/9427345c4ae499d17e3bc76b3b2259c425faa92443fcf4bc4ced65dc15555089.jpg)  
Figure 2. Illustrative connections within the Food–Energy–Water (FEW) Nexus, incorporating data from Scanlon et al. [36] (arrows) and projected global increases in demand for water, food, and energy [35]. The relationships between variables are indicated as either direct $( + )$ or inverse $( - )$ correlations. A direct correlation implies that variables move in the same direction—for example, increased water use leads to a larger water gap, while reduced water use narrows the gap. An inverse correlation indicates that variables move in opposite directions—for instance, greater water availability decreases the water gap, whereas reduced availability exacerbates it.

The interdependencies among these three sectors have led to the development of the Food–Energy–Water (FEW) Nexus paradigm. This approach has become a central focus for researchers in both the natural and social sciences investigating how water constraints affect energy and food production [37–39] and evaluating how rising human pressure on global freshwater systems intensifies as global demand grows [40]. While the nexus approach captures three essential pillars, it also fits within the broader and more complex framework of desertification, emphasizing the multifaceted nature of this global challenge.

Despite the increasing adoption of renewable energy sources—such as solar power and biofuels—the near future will likely see continued reliance on unconventional fossil fuel reserves, including oil sands, shale oil, and shale gas. These reserves require significantly more water for extraction [41] and represent a substantial share of proven fossil fuel resources, potentially limited by water availability. Moreover, some alternative energy sources like biofuels also impose considerable stress on water supplies [42].

Food production is becoming ever more dependent on water resources [43]. In a warming world with more frequent droughts and advanced technology that capitalizes on thermal advantages and extended daylight in arid regions—including deserts like the Arabian Desert [44]—enormous volumes of water are allocated for irrigation. Irrigated land has expanded steadily over the last three centuries, growing from 5 million hectares in 1700 [45] to 338 million hectares by 2018 [46], surpassing earlier projections of 322 million hectares by 2050 [47]. Currently, agriculture accounts for roughly $7 0 \%$ of global freshwater use $2 8 0 0 { \mathrm { k m } } ^ { 3 }$ out of $4 0 0 0 \mathrm { k m } ^ { 3 }$ annually) [46].

This increasing demand continues to widen the global water gap. The dominant response—focused on expanding water supply through dams, inter-basin transfers, groundwater extraction, desalination plants, and water reuse—has not curbed demand, but instead intensified it [43]. In fact, these supply-side solutions, along with efficiency improvements, often reinforce the belief that any level of demand can be met [48,49]. A shift in paradigm is urgently needed: rather than trying to endlessly meet rising demand, we must focus on aligning demand with the planet’s shrinking water availability. The reality is stark: there are few viable locations left for large reservoirs [48], groundwater is being depleted at an alarming rate [50–52], and many lakes and inland seas have already been severely drained [53]. We are nearing systemic hydraulic failure.

Despite these warning signs, the prevailing response to increasing aridity has been to expand irrigated agriculture into unsuitable areas. For instance, asparagus is grown in parts of Peru that receive as little as $1 5 \mathrm { m m }$ of annual rainfall, while regions such as the Taklamakan Desert and North Africa are consuming water reserves that may be critical for climate adaptation.

To navigate this escalating crisis, we must fundamentally reconsider how we allocate and manage increasingly scarce water resources. A holistic perspective—supported by causal diagrams like those presented here—can foster a deeper understanding of the intricate relationships among three essential dimensions of human security: energy, food, and, most critically, water.

# 3.2. Ecosystem Restoration

One of the key strategies to combat desertification is the reforestation of degraded ecosystems. At first glance, this approach appears straightforward: restoring vegetation to reclaim desertified land while creating carbon sinks to mitigate climate change. Unsurprisingly, ambitious global targets have been set, including a commitment to restore one billion hectares of degraded ecosystems by 2030 [33]. Notable initiatives include the Bonn Challenge (aiming to restore 350 million hectares by 2030) [54], the Great Green Wall of the Sahara and Sahel [55] (a multibillion-dollar effort to create a forested corridor spanning Africa from the Atlantic to the Red Sea), and China’s large-scale programs to establish “Great Green Walls” in its arid regions [56–58].

While these efforts hold promise, they are often based on oversimplified assumptions. For instance, desertification is sometimes misunderstood to be the mere expansion of deserts, or forested landscapes are assumed to represent only “healthy” ecosystems. Such misconceptions ignore the natural prevalence of open ecosystems in many dryland regions [59]. In addition, widespread myths around ecosystem restoration

persist [60], obscuring the fact that restoration must be tailored to diverse environmental and cultural conditions.

Climate change mitigation is also frequently oversimplified by the assumption that emissions can be offset through large-scale afforestation. Some advocate for this strategy’s untapped potential [61]. However, as Figure 3 illustrates, two major complications arise. First, reforestation decreases the albedo, meaning the Earth reflects less solar radiation and absorbs more heat [62]. Paradoxically, this can raise global temperatures. The more forests are restored, the lower the albedo, and since a lower albedo means less solar energy is reflected, this results in higher temperatures (an inverse relationship, indicated by the “−” sign). Second, forests are vulnerable to wildfires, which can release substantial amounts of $\mathrm { C O } _ { 2 }$ and can convert carbon sinks into sources [63].

![](images/6632acffa1f7682ca8969bdebabe8db339a11e2e98bd1d43c6d1e7f254e213a5.jpg)  
Figure 3. Interactions between ecosystem restoration and other sectors and policies (in capital letters).

Another often-overlooked consequence of large-scale reforestation is its impact on regional water dynamics. Numerous studies have shown that introducing vegetation with high water requirements can significantly disrupt local hydrological balances [64], reducing streamflow [65,66] and water availability in already water-scarce regions [67,68]. In drylands, this may generate conflicts between ecological needs and human demands—especially agriculture—over limited water resources [69,70].

That said, forest restoration also offers significant benefits. New vegetation can reduce erosion, stabilize soils, and enhance carbon sequestration. Improved soil health boosts fertility, increases organic carbon content [71], and reduces sedimentation, extending dam lifespans and preventing landslides. Well-structured soils also retain more water. However, depending on the species composition, increased vegetation cover may also

increase wildfire risk, potentially leading to environmental damage, carbon emissions, and further erosion.

To improve the effectiveness of reforestation initiatives, a systems approach is essential ([72,73]). This highlights the necessity of considering factors such as hydrological planning and food strategy, to name just two examples. As shown in Figure 3, a forested area introduced into a territory interacts with multiple other variables. Taking these interactions into account is essential for designing one of the many pieces needed in the complex puzzle of combating desertification. The Great Green Wall of the Sahel serves as an example [55] of how to integrate the population’s food needs with water security by envisioning the project as a mosaic of various species—both forest and fruit-bearing—rather than a dense barrier intended to halt the desert’s advance.

# 3.3. The Global Decoupling of Production and Consumption

One of the primary weaknesses of LDN—and of NAPs more broadly—is the geographical limitation within which they are implemented. Constrained by the formal framework of the UNCCD and, more generally, by the political organization of the world into nation states, misalignments inevitably emerge. These “cracks” in coordination give rise to what we refer to as “LDN leaks”: instances of land degradation that fall outside the scope of NAPs unless every country rigorously implements LDN in a globally coordinated fashion.

The balance between domestic food production and imports has shifted dramatically in recent decades [74]. While it may be unsurprising that countries like Japan (with a domestic-to-import ratio of 8:92) or the United Kingdom (20:80) rely heavily on imports due to limited agricultural land, it is more striking that Europe as a whole imports more food than it produces. Even in Spain—a country with vast agricultural potential—the ratio stands at just 37:63. This growing reliance on imported food means that a significant share of the environmental impact associated with consumption takes place beyond national borders and is therefore omitted from the national assessments used in LDN reporting.

A stark example is the industrialization of livestock farming, which has increasingly shifted from traditional extensive grazing to highly concentrated, feed-dependent megafarms. This transition has erased one of the degradation landscapes identified in the Spanish NAP [75,76]—agro-silvo-pastoral systems affected by overgrazing. Yet this apparent success masks a new reality: the environmental burden has simply been displaced, rather than eliminated. This becomes evident only when we consider the decoupling between sites of consumption and production.

One study [77] estimated that during the first decade of the 21st century, 1.188 million hectares of ecologically valuable primary ecosystems were converted into soybean monocultures in South America. Among the most severely affected regions are the Brazilian Atlantic Forest, the Amazon, the Cerrado, and the Paraguayan and Argentine Chaco—some of the world’s richest biodiversity hotspots. These once-intact ecosystems have been cleared by chainsaws and bulldozers to meet the growing global demand for soybeans, largely used as livestock feed.

If our assessment of desertification were confined to Spain alone, the picture would appear much more optimistic. The same study indicates that 7078 million hectares of potential grazing areas have improved in condition based on LDN indicators—in other words, they have accumulated biomass. Livestock numbers are at record highs, and forests are regenerating. However, this progress is overshadowed by the fact that the environmental cost is now borne by South America’s degraded primary forests.

Soybeans are just one example among many globally traded commodities that travel thousands of kilometers [78], heavily influencing the trade balances of both importing and exporting countries. As illustrated in Figure 4A, imports by one country are exports for

another. The maps in Figure 4 further depict major trade flows: global soybean distribution (Figure 4C; [79]); ethanol—a biofuel produced from sugarcane or corn (Figure 4B; [80]); and palm oil originating primarily from Indonesia (Figure 4D; [81]). Through these trade networks, the agribusiness sector functions as a mechanism for displacing environmental impacts—including land use change [82], nitrogen [83] and phosphorus [84] pollution, and water resource depletion [85]—to exporting nations.

This global exchange generates “virtual flows” of water (Figure 4E) and $\mathrm { C O } _ { 2 }$ emissions that are effectively outsourced across borders [86]. Incorporating these transboundary effects into LDN accounting remains a major unresolved challenge. As shown in the causal diagram, environmental degradation occurs at the site of production, even though much of the agro-industrial output is consumed elsewhere. This raises a critical question: To which country should the environmental degradation be attributed—the producer or the consumer? Can this environmental debt be considered settled through financial transactions, even though the prices paid often fail to reflect the full extent of environmental externalities? These are precisely the types of questions that must be addressed to confront the problem of “LDN leaks” and to develop a truly global, equitable framework for managing land degradation.

![](images/3cbaf29550321ec3478556f9cebaea7e40f20dc1d95d4eeccebad1d7b7b39c14.jpg)

![](images/f042e7c7209f0d1203794af0514f82692b8cdce3469c482183c74d869adf1a66.jpg)

![](images/9d2e548d496d8b94380c9cbd874dc79822d9a7ec65ab95daab6f4677587579fe.jpg)

![](images/272d7cbf695c015307ff2f1e9cc864bf7034b5e59af220a6006ad3fff95b821f.jpg)

![](images/9a18f2e23a1987124971ca8ccebf07c936a843f9533d437930f32bb81f75848a.jpg)  
Figure 4. Economic and environmental impacts of international trade in raw materials and food. Inset (A) illustrates a country’s imports and exports derived from its agro-industrial production, which is interconnected with other countries. The maps show (B) major global ethanol trade streams [80]; (C) the global export of palm oil from Malaysia and Indonesia [81]; (D) global soybean trade flows [79]; and (E) the ten largest inter-regional virtual water trade fluxes $\mathrm { G m } ^ { 3 }$ /year), based on Chen and Chen [87].

# 4. Discussion

# 4.1. Complexity: A Defining Feature of Contemporary Society

The need for a systemic approach becomes evident when considering how deeply interconnected the three conflicts outlined in the previous section are. For instance, local food scarcity can increase reliance on external (i.e., non-domestic) production, leading to higher imports in the short term [88] and, over the medium to long term, driving large-scale foreign land acquisitions (LSLAs), which contribute to land and water grabbing [89,90]. This dependence exposes importing countries to economic and environmental shocks originating beyond their borders and outside their control [88,91]. Conversely, reliance on surplusproducing regions can support population growth in areas facing food insecurity [92,93]. While this dynamic further entrenches dependence on external production, it can also serve as a stabilizing force during periods of local agricultural instability [88], and may help reduce inequalities and injustices in access to water for food production [94].

An initial analysis of the key elements related to land degradation clearly demonstrates that, despite LDN’s national focus, the international dimension must be considered. Specifically, it is crucial to recognize “LDN leaks” that emerge within the globalized systems in which societies now operate. Although not yet fully realized, the UNCCD initially envisioned the development of Regional and Sub-regional Action Programs to address this gap and complement the National Action Plans (NAPs).

The increasing complexity of the world we live in presents significant challenges to formulating effective responses to emerging problems. While this complexity has contributed to improved societal well-being—through global exchanges of people, goods, capital, information, and ideas—it has also heightened systemic vulnerability. As Helbing notes [95], “trends such as globalization, increasing network densities, sparse use of resources, higher complexity, and an acceleration of institutional decision processes may ultimately push our anthropogenic (man-made or human-influenced) systems toward systemic instability—a state in which things will inevitably get out of control sooner or later”.

This complexity stems from two primary sources. On one hand, humans create intricate networks of interaction, such as international trade. One major challenge is that this complexity tends to grow faster than our intellectual capacity to fully comprehend or manage it. Moreover, these networks exhibit self-organizing behavior, giving rise to internal dynamics that are inherently unpredictable. In systems shaped by billions of individual decisions, control often shifts from individuals to the system itself. Faced with an overwhelming and opaque reality, people frequently attribute crises such as global warming, financial crashes, or pandemics to “the system”. More accurately, we should say, “It is the systems” [96]. The second source of complexity arises from our own desire to understand these systems. Soil offers a compelling example. It remains largely a mystery, yet as soil sciences advances, researchers are uncovering a rich and complex universe teeming with life, forcing us to reconsider previously unacknowledged factors.

# 4.2. Land Degradation Neutrality as a Framework for Navigating Complexity

LDN is a proposal that must be implemented with tools specifically designed to navigate and address complexity—precisely to avoid the collapse that Helbing warns about. Recognizing this complexity is the first step. It is crucial to understand that implementing solutions targeting isolated components of a system often leads to unintended consequences. The properties of complex systems—such as the socio-ecological systems we must manage to prevent land degradation from constraining future land use options [97]—cannot be understood by analyzing their individual components in isolation. A systemic perspective is essential to identify the interactions among various elements, sectors, and interests.

One way to embrace this systemic approach is by incorporating multiple perspectives that reflect the multifaceted nature of reality. The causal diagrams presented in this work are built on the knowledge and experience of a diverse range of stakeholders, including land managers, natural resource users (such as farmers and herders), scientists, and representatives from different economic sectors. This plurality of viewpoints allows for a much richer and more robust understanding of how socio-ecological systems function.

However, the goal is not simply to generate causal diagrams. These tools must help individuals with a primarily economic or production-focused view of nature understand the consequences of overexploiting natural resources beyond their capacity for regeneration [98]. At the same time, it is important to highlight the interdependencies of market-based economies, which underpin the welfare models that most societies aspire to. Living well inevitably entails some environmental degradation, but as LDN proposes, such degradation must be limited and counterbalanced. If we fail to strike this balance, we risk behaving like viruses—destroying the very host we depend on.

The systemic perspective advocated for in this work supports the development of several key policy recommendations: (i) foster cross-sectoral and inter-agency cooperation by promoting the exchange of data and knowledge; (ii) conduct participatory workshops to ensure a pluralistic understanding of the country’s diverse realities; (iii) synthesize the collected information using tools such as causal diagrams and matrices (see Table 1 as an example) to evaluate the pros and cons of each economic sector (these syntheses should lead to informed discussions and eventual consensus, creating a shared vision of how different sectors use resources and the trade-offs involved in land use decisions); (iv) establish governance bodies with strong scientific and technical support to carry out these tasks effectively.

Table 1. Matrix showing advantages (green) and disadvantages (red) of selected economic sectors. Note: This example compares Spanish economic sectors, but other classification criteria should be explored. The selection of sectors and uses should itself be the result of a consensus-building process.   

<table><tr><td>Sector</td><td colspan="4">Pros and Cons</td></tr><tr><td>Irrigated Agriculture</td><td>Ensures Food security</td><td>Causes significant environmental degradation</td><td>Requires costly water infrastructure</td><td>Important for trade balance</td></tr><tr><td>Tourism</td><td>Major contributor to GDP</td><td>High water use during times of water stress</td><td>High income-to-water-use ratio</td><td>Worsens coastal-inland development imbalance</td></tr><tr><td>Extensive Grazing Systems</td><td>Reduces wildfire risk</td><td colspan="2">Can trigger degradation (e.g., erosion, biodiversity loss) if mobility is limited</td><td>Produces high-quality food</td></tr></table>

With this foundational information, it becomes possible to explore how land use policies can be adapted—and what levels of degradation or restoration might result from this. This, ultimately, is the core of the LDN approach. After proposing new policies, indicators can be recalculated and compared with the baseline scenario. This is the fundamental purpose of LDN indicators: to monitor the outcomes of a planned trajectory versus the starting point.

In the end, implementing LDN requires an educational process [99,100]. Society must develop as accurate an understanding as possible of the intricate complexities of our environment. Decisions must be based on the best available science. For instance, restricting irrigated agriculture may increase vulnerability within the food system. However, it must

also be made clear that continuing to rely on an ever-expanding, supply-driven model of water management only exacerbates the water gap [43], increasing vulnerability in both hydrological and food security terms. These trade-offs must be communicated transparently so that society can make informed decisions about the direction it wishes to take. In this way, LDN is not merely a technical strategy for combating desertification; it is an entire philosophy for responsible natural resource management.

# 5. Conclusions

Desertification, soil degradation, climate change, water scarcity, plastic pollution, deforestation, and food security are critical issues are often discussed in isolation, each within its own forum, conference, or legal framework. What is missing is a unified platform that integrates these interrelated challenges. Addressing any one of them in isolation is no longer sufficient. For instance, we cannot achieve food security by focusing solely on production; we must also consider water management and land degradation. Likewise, halting soil degradation and preventing desertification require rethinking of agricultural practices, as agriculture itself is a major contributor to the problem. But the solution is not only technical—it is also managerial and systemic. Market dynamics, lifestyle changes, and certain geopolitical conditions are pushing us toward a model of hyper-intensive, large-scale agriculture that, paradoxically, leads to agriculture without farmers.

LDN offers an effective platform for integrating these interconnected challenges. It breaks down the boundaries that separate them and helps us understand and act upon their complex interrelationships. A holistic, integrated approach is essential for the successful implementation of LDN. Although originally developed under the UNCCD as a tool to guide NAPs, LDN should be applied beyond drylands. In doing so, it can serve as a broader platform for coordinating efforts to address environmental and socio-economic challenges that demand integrated solutions.

Our contribution underscores that achieving LDN requires a systemic approach, just as the issue of desertification itself demands multidisciplinary thinking. The increasing complexity of today’s world must be met with tools capable of representing and managing that complexity. Understanding the structure and behavior of socio-economic and ecological systems is the first step toward designing solutions that are not only functional but also minimize unintended consequences. Only then can we propose realistic and effective alternatives to the major challenges we face.

Author Contributions: Conceptualization, J.M.-V.; formal analysis, J.M.-V.; investigation, J.M.-V. and J.A.P.V.; writing—original draft preparation, J.M.-V., J.A.P.V. and V.C.; writing—review and editing, J.M.-V., J.A.P.V., T.A., A.J.Á., R.M.O., J.C. and V.C.; visualization, J.M.-V., T.A. and V.C.; supervision, J.M.-V. and V.C.; funding acquisition, J.M.-V. All authors have read and agreed to the published version of the manuscript.

Funding: This research was supported by the ATLAS project (funded by the Biodiversity Foundation of the Ministry for the Ecological Transition and the Demographic Challenge (MITECO) within the framework of the Recovery, Transformation and Resilience Plan (PRTR), financed by the European Union—NextGenerationEU), and by the project “Plan Complementario de $_ { \mathrm { I + D + i } }$ en el área de Biodiversidad (PCBIO)” (funded by the European Union within the framework of the Recovery, Transformation and Resilience Plan—NextGenerationEU and by the Regional Government of Andalucia).

Data Availability Statement: No new data were created or analyzed in this study. Data sharing is not applicable to this article.

Conflicts of Interest: The authors declare no conflicts of interest.

