# Biodiversity loss through cropland displacement for urban expansion in China

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:52:34.274051+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Li et al. - 2024 - Biodiversity loss through cropland displacement for urban expansion in China.pdf
- Year: unknown
- DOI: 10.1016/j.scitotenv.2023.167988
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This study examines how urban expansion in China indirectly drives biodiversity loss through cropland displacement, using a telecoupling framework. The analysis covers mainland China from 1980 to 2015 (with limited use of 2020 data), a period of rapid urbanization and strong national food security policies such as the cropland balance policy.

The authors treat urban growth and associated cropland reclamation as a coupled human-natural system with distant linkages. Urban expansion directly converts cropland and natural habitats to built-up land. To offset lost food production, cropland is newly reclaimed elsewhere, often in ecologically sensitive regions. This creates a telecoupled flow in which crop products move from new production zones to cities, while biodiversity losses are effectively exported from urban regions to distant landscapes.

Land cover change is mapped at 1 km resolution, and cropland displacement is quantified via environmental-economic accounting of the production value of 36 crops. Decreases in crop production where cropland is urbanized are balanced by increases in newly reclaimed cropland, yielding a compensation factor, leverage factor, and a compensated cropland area. Biodiversity impacts are estimated with three complementary indicators: a biodiversity intactness index (BII), a fraction of regionally remaining species (FRRS) for vertebrates, and changes in extent of suitable habitat (ESH) for 455 mammals, all parameterized with global and national biodiversity datasets.

Nationwide, total biodiversity loss attributable to urban expansion is modest numerically (about 0.6-1.0 percent by 2015), but indirect losses from cropland displacement are roughly 2-4 times greater than direct losses from urban land conversion. Newly reclaimed croplands have lower yields but are located in areas with higher biodiversity baselines, so more and richer habitat must be converted to replace production. Southeastern provinces, where cropland is heavily urbanized, emerge as source hotspots of indirect biodiversity loss; northeastern and northwestern provinces, where large-scale reclamation occurs, act as sink hotspots.

The work is explicitly about telecoupling and metacoupling: it quantifies distant ecological consequences of urban land change mediated by displaced agriculture and highlights policy risks if only direct, local impacts are considered.

## Structured Metacoupling Extraction

### Coupling Classification
- Telecoupling via cropland displacement dominates; pericoupling mentioned conceptually; intracoupling not a focus.

### Intracoupling
#### Systems
- Not identified.
#### Flows
- Not identified.
#### Agents
- Not identified.
#### Causes
- Not identified.
#### Effects
- Not identified.

### Pericoupling
#### Systems
- Urban areas and nearby habitats linked by noise, trampling, pollution.
- Urban expansion edges and surrounding ecosystems within buffer zones.
#### Flows
- Local spillover of disturbance, pollutants, human access.
- Edge effects reducing nearby habitat quality.
#### Agents
- Urban residents and industries near city borders.
- Local governments managing periurban land.
#### Causes
- Urban expansion into adjacent landscapes.
- Periurban infrastructure and human activity growth.
#### Effects
- Habitat quality decline around cities.
- Indirect biodiversity loss in periurban buffer zones.

### Telecoupling
#### Systems
- Southeastern Chinese urban regions losing cropland.
- Northeast and Northwest Chinese regions reclaiming cropland.
- National food system linking urban demand and distant cropland.
#### Flows
- Crop production flows from NE/NW to SE cities.
- Telecoupled biodiversity loss transferred from sources to sinks.
- Displacement of cropland from high-yield south to marginal north.
#### Agents
- National and provincial governments implementing cropland balance and food security policies.
- Farmers and land developers converting land to urban and cropland.
- Agricultural and food supply chain actors moving grain between provinces.
#### Causes
- Rapid urban expansion consuming high-quality cropland.
- Food security strategy requiring cropland quantity compensation.
- Cropland balance policy driving reclamation in marginal, biodiversity-rich areas.
#### Effects
- Indirect biodiversity loss 2–4 times larger than direct urban losses.
- Reclamation of grasslands, forests, wetlands in NE and NW China.
- Source-sink pattern: SE provinces export biodiversity loss to NE/NW sinks.

### Cross-Coupling Interactions
- Urban growth internally reduces cropland, triggering telecoupled reclamation in distant regions.
- Food trade from NE/NW to SE couples economic benefits with distant biodiversity costs.
- Ignoring telecoupling risks conservation leakage from protected urban peripheries to remote frontiers.

### Research Gaps or Limitations
- Assumes compensated cropland is evenly spread across all reclaimed areas.
- Focuses only on land use change; omits climate and other human pressures.
- Uses 2015 patterns because 2020 land data likely overestimates urban area.

### Search Keywords
- telecoupling cropland displacement China biodiversity
- urban expansion indirect biodiversity loss China
- source sink hotspots cropland reclamation

### Extraction Confidence
high
