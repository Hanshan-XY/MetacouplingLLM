# Does urbanization inevitably exacerbate cropland pressure The multiscale evidence from China

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:12:46.456141+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Xiong et al. - 2025 - Does urbanization inevitably exacerbate cropland pressure The multiscale evidence from China.pdf
- Year: unknown
- DOI: 10.1016/j.jclepro.2025.145413
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
The paper examines how different dimensions of urbanization affect pressures on cropland in China, considering both food production and ecological impacts, and explicitly uses the metacoupling framework to capture local and distant linkages.

The study covers 31 provinces and 233 prefecture-level cities in mainland China from 2009 to 2022. It distinguishes two types of cropland pressure: cropland quantity pressure (CQP), reflecting supply-demand balance and land quality, and cropland ecological pressure (CEP), reflecting the stress of agricultural production on local ecosystems via a productive ecological footprint based on cropland ecosystem service values. Using multiple national datasets (land use, meteorological, socio-economic, and remote sensing) the authors calculate CQP and CEP and then apply a spatial self-lag (SLX) econometric model with gravity-based spatial weights to estimate both local and remote effects of urbanization. Urbanization is decomposed into population, spatial, social, and economic subsystems and combined into a comprehensive index.

Nationally, CQP rose by about 7 percent and then stabilized at a moderate but elevated level, while CEP fell by about 8 percent, also remaining moderate. Ecological pressure is strongest in major grain-producing regions and often exceeds the national average, indicating that these regions bear disproportionate environmental burdens to ensure food supply. Some provinces and many cities face simultaneous increases in both CQP and CEP.

Urbanization does not uniformly worsen cropland pressure. Spatial and economic urbanization generally intensify quantity pressure and often harm ecological conditions. In contrast, population and social urbanization tend to ease quantity pressure, but can increase ecological pressure locally. Remote (interregional) urbanization typically raises CQP elsewhere, while its effects on CEP are more mixed and subsystem-dependent. These spillover effects, framed as metacouplings, show that urbanization in one region can shift cropland pressure to other regions, especially to major grain-producing areas. The paper is directly about metacoupling/telecoupling, demonstrating cross-scale and cross-regional human-nature linkages and arguing for policies that account for both local and distant impacts in managing cropland security.

## Structured Metacoupling Extraction

### Coupling Classification
- Applies metacoupling to urbanization impacts on cropland quantity and ecological pressure within and across Chinese regions.

### Intracoupling
#### Systems
- Provincial cropland-human systems within China
- City-level urban-rural land systems
- Major grain-producing regional systems
#### Flows
- Local land conversion between cropland and built-up land
- Local food production and consumption flows
- Local flows of labor, capital, and agricultural inputs
#### Agents
- Farmers adjusting land use and crop intensity
- Local governments managing land and agricultural policies
- Urban residents shaping food demand and lifestyles
#### Causes
- Population, spatial, social, and economic urbanization within regions
- Agricultural input use, mechanization, and irrigation development
- Local income growth and fiscal support for agriculture
#### Effects
- Changes in cropland quantity pressure index CQP
- Changes in cropland ecological pressure index CEP
- Trade-offs between food security and cropland ecosystem health

### Pericoupling
#### Systems
- Neighboring provinces linked by short-distance factor flows
- Adjacent cities with shared labor and land markets
#### Flows
- Regional labor migration from rural to nearby cities
- Spillover of agricultural technology and knowledge
- Short-distance food and input trade among neighboring regions
#### Agents
- Provincial and municipal governments in bordering regions
- Migrating workers choosing nearby destinations
- Regional agribusiness and logistics firms
#### Causes
- Urbanization-driven regional economic disparities
- Transport cost and distance-sensitive factor mobility
- Interjurisdictional competition for investment and construction land
#### Effects
- Pericoupled urbanization increasing neighboring CQP
- Adjacent spatial urbanization affecting nearby CEP
- Unequal cropland pressure between grain and non-grain regions

### Telecoupling
#### Systems
- Distant Chinese provinces connected via national markets
- City networks linked through long-distance migration
- Grain-marketing versus main grain-producing regions
#### Flows
- Long-distance migration of population and labor
- Interregional trade in food and virtual cropland resources
- Cross-regional capital, technology, and enterprise relocation
#### Agents
- Central government designing national food and land policies
- Interprovincial agribusiness and trading companies
- Migrant workers and urban consumers in distant regions
#### Causes
- National-scale urbanization and regional income gaps
- Economic agglomeration and industrial upgrading in distant regions
- National transport and digital connectivity reducing distance frictions
#### Effects
- Remote urbanization generally raising CQP in other regions
- Remote spatial and economic urbanization influencing CEP elsewhere
- Main grain regions bearing telecoupled ecological burdens without full compensation

### Cross-Coupling Interactions
- Local urbanization interacts with remote urbanization to shape multiscale CQP and CEP patterns.
- Pericoupled and telecoupled flows amplify cropland pressure in main grain-producing regions.
- Different urbanization subsystems create opposing effects on CQP versus CEP across scales.

### Research Gaps or Limitations
- Cropland quantity pressure factor omits detailed soil property and broader quality dimensions.
- Ecological pressure measurement depends on ecological footprint and ecosystem service valuation simplifications.
- Remote metacoupling mechanisms and regional heterogeneity are not fully resolved with the SLX model alone.

### Search Keywords
- urbanization cropland pressure CQP CEP China metacoupling
- spatial econometric SLX telecoupling food and ecological security
- grain-producing regions remote urbanization ecological footprint

### Extraction Confidence
high
