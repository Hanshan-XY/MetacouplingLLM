# Reducing sand mining_s growing toll on marine biodiversity

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:08:52.617459+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Torres et al. - 2025 - Reducing sand mining_s growing toll on marine biodiversity.pdf
- Year: unknown
- DOI: 10.1016/j.oneear.2025.101202
- OA status: closed
- License: none recorded
- Category: Journal Articles\Commentary\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This commentary examines how accelerating marine sand extraction is degrading ocean biodiversity and how governance can better manage this pressure using systems approaches, especially the metacoupling framework.

The geographic focus is global, with examples from the North and Baltic Seas, US and African coasts, the Persian Gulf, East Asia, small island states, and Southeast Asia. The system context is coastal and marine ecosystems supplying sand for construction, land reclamation, and coastal protection. The article synthesizes recent monitoring data, particularly from UNEP and GRID-Geneva's Marine Sand Watch, which uses vessel tracking to estimate that billions of tonnes of sand and sediment are dredged each year. It also draws on case studies and existing biodiversity assessments rather than new fieldwork.

The authors describe how dredging is expanding spatially and intensifying, including extensive overlap with marine protected areas. Sand removal directly disturbs seabeds and kills organisms, and indirectly alters sediment transport, water clarity, and habitat structure. These impacts combine with other pressures such as climate warming, contributing to declines in sensitive habitats and marine species.

Metacoupling is central to the paper. Sand extraction sites are treated as sending systems, development and nourishment projects as receiving systems, and transit routes and adjacent ecosystems as spillover systems. This lens reveals that benefits accrue mainly to distant coastal developments, while ecological costs are borne at and beyond extraction areas, often without recognition or compensation.

Key recommendations are to improve seabed mapping and habitat assessment, expand and refine dredging monitoring, strengthen transparency and corporate accountability, and mainstream active ecological restoration in addition to passive recovery. The paper is explicitly about metacoupling/telecoupling, using that framework to connect material flows of sand with distributed ecological impacts and to inform more integrated, biodiversity-aware governance of marine sand resources.

## Structured Metacoupling Extraction

### Coupling Classification
- Explicit metacoupling application to sand extraction impacts within, nearby, and distant from marine dredging sites.

### Intracoupling
#### Systems
- Individual marine sand extraction area and its local ecosystems
- Single coastal city managing nearby sand demand and supply
#### Flows
- Local removal and redeposition of sand within the same coastal system
- Project-level sediment disturbance and plume dispersion
#### Agents
- Dredging companies operating at specific extraction sites
- Local coastal authorities permitting and monitoring dredging
- Nearby fishers and tourism operators affected by dredging
#### Causes
- Local coastal development and infrastructure expansion
- Beach protection and nourishment projects at the same coastline
#### Effects
- Habitat loss and seabed alteration under dredgers
- Increased turbidity and smothering of nearby seagrass and corals
- Local biodiversity decline and reduced ecosystem services

### Pericoupling
#### Systems
- Adjacent coastal zones neighboring extraction sites
- Marine protected areas overlapping regional dredging hotspots
- Neighboring islands affected by altered sediment dynamics
#### Flows
- Sediment plumes drifting from borrow areas into nearby habitats
- Changed wave regimes affecting adjacent shorelines
- Regional ecological connectivity shifts among coastal ecosystems
#### Agents
- Regional environmental regulators and MPA managers
- Neighboring coastal communities and small island states
- Fishing and energy sectors sharing regional seascapes
#### Causes
- Expansion of marine sand dredging frontiers into new regions
- Regional land reclamation and port development needs
- Cumulative pressures from fishing, energy, and extraction
#### Effects
- Degradation of nearby mangroves, seagrass beds, and coral reefs
- Overlap of dredging with conservation areas reduces MPA effectiveness
- Regional erosion and reduced coastal resilience to sea level rise

### Telecoupling
#### Systems
- Distant offshore sand extraction areas as sending systems
- Urban and infrastructure consumption centers as receiving systems
- Transit corridors and remote coasts as spillover systems
#### Flows
- Long-distance trade and shipping of marine sand for construction
- Information flows via global monitoring platforms like Marine Sand Watch
- Financial flows from international investors to large dredging projects
#### Agents
- Multinational dredging and construction corporations
- International financial institutions funding reclamation projects
- Global organizations such as UNEP, IUCN, and multilateral bodies
#### Causes
- Global urbanization and infrastructure growth driving sand demand
- Climate adaptation projects requiring sand for coastal protection
- International policies lacking explicit sand extraction targets
#### Effects
- Biodiversity losses and carbon impacts far from consumption sites
- Atoll islands and distant coasts facing increased erosion risk
- Global marine wildlife decline compounded by sand mining

### Cross-Coupling Interactions
- Sending, receiving, and spillover systems linked via sand, sediment plumes, species movements, and information feedbacks.
- Beach nourishment in one region externalizes habitat loss and services decline to distant borrow areas.
- Corporate and governmental reporting from receiving regions can influence restoration and planning in sending systems.

### Research Gaps or Limitations
- Sparse mapping of seabed sand deposits and habitat condition limits metacoupling quantification.
- Significant unmonitored artisanal and small scale dredging, especially in small island and Southeast Asian states.
- Poor data on biodiversity, carbon footprint, and full life cycle emissions of marine sand supply chains.

### Search Keywords
- marine sand dredging metacoupling sending receiving spillover systems
- beach nourishment land reclamation biodiversity impacts
- Marine Sand Watch global sand mining monitoring

### Extraction Confidence
high
