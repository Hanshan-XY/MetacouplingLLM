# Progress and prospects of rural human-earth system coupling research

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:47:19.807184+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Hu et al. - 2023 - Progress and prospects of rural human-earth system coupling research.pdf
- Year: unknown
- DOI: 10.18306/dlkxjz.2023.12.013
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Review\Metacoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This review synthesizes Chinese and international research on how rural societies and environmental systems interact as coupled human-earth systems. The focus is on rural regions, mainly in China but drawing from global literature, and on how socioeconomic change, land and water use, climate, and policy jointly reshape rural environments and livelihoods.

The authors conceptualize the rural human-earth system as a dynamic, open, multi-scalar system in which social and ecological components coevolve. They summarize a dominant analytical frame as process-mechanism-pattern-effect-regulation: human and natural processes (e.g., migration, land conversion, hydrological change) interact to generate coupling mechanisms, spatial patterns, environmental and social effects, and in turn policy and engineering responses.

Five main research themes are identified: (1) coupling among key rural elements such as population, land, water, energy, and food, and associated spatial-temporal coordination or mismatch; (2) climate change impacts on agricultural suitability, yields, and rural livelihoods, and adaptive responses under combined climate and socioeconomic scenarios; (3) urbanization-driven changes in rural labor, land abandonment or consolidation, pollution, and ecosystem services; (4) globalization and agricultural trade, including distant feedbacks between producing and consuming regions through commodity flows, virtual land and water, and environmental displacement; and (5) effects, including unintended ones, of land, ecological restoration, and water-transfer policies and engineering projects.

Methodologically, most work relies on indicator-based coupling and coordination indices, decoupling and elasticity models, DPSIR-type frameworks, and econometric or spatial analyses. Emerging approaches include social-ecological networks, agent-based models, system dynamics, and integrated assessment, though process-based coupling models remain underdeveloped. Data gaps for rural social processes and cross-scale integration are emphasized.

The paper is closely aligned with metacoupling and telecoupling perspectives: it stresses multi-scale feedbacks, distant interactions via trade and ecological flows, and spillover effects of policies and markets. It calls for stronger quantitative analysis of long-distance couplings, better multi-scale data platforms, and integrated models to support rural sustainability, SDGs, and human-nature harmony.

## Structured Metacoupling Extraction

### Coupling Classification
- Mainly intracoupling of rural human earth systems, with peri and telecoupling via urbanization and trade

### Intracoupling
#### Systems
- Rural socioeconomic system interacting with local natural ecosystem
- Rural territorial system including production living ecological functions
- Local social ecological systems on plateaus basins and watersheds
#### Flows
- Local flows of population land water energy food and information
- Ecosystem service flows between rural nature and residents
- Material and energy exchanges within agriculture and village systems
#### Agents
- Farmers and rural households
- Village collectives local governments
- Rural enterprises and cooperatives
#### Causes
- Industrialization urbanization information development affecting rural structure
- Local resource endowment technology and organization driving change
- Climate variability influencing local agriculture and livelihoods
#### Effects
- Changes in land use degradation or restoration of ecosystems
- Shifts in livelihoods poverty and rural revitalization outcomes
- Altered food production water use and environmental risks

### Pericoupling
#### Systems
- Rural areas and nearby towns within urban rural integration regions
- Upstream and downstream basins in water diversion or reservoir projects
#### Flows
- Short distance flows of labor construction land and services
- Water transfers from upstream rural areas to downstream cities
#### Agents
- County and municipal governments coordinating urban rural policy
- Water resource managers and reservoir authorities
#### Causes
- Regional urbanization and construction land expansion
- Ecological protection and land consolidation policies
#### Effects
- Farmland loss near cities and reallocation elsewhere
- Improved urban water security but higher upstream ecological risk

### Telecoupling
#### Systems
- Chinese rural regions linked with Brazilian soybean regions
- Provincial rural areas connected through national agricultural trade
- Global rural regions connected by climate change and SDGs
#### Flows
- Trade flows of soybeans cereals vegetables and fertilizers
- Virtual land and water embodied in traded products
- Telecoupled ecosystem service and carbon flows
#### Agents
- International agribusiness firms and traders
- National governments designing trade and climate policies
- International organizations promoting SDGs
#### Causes
- Globalization and compressed space time via information networks
- International demand for feed biofuels and food security
- Climate policy and shared socioeconomic pathways
#### Effects
- Deforestation and cropland expansion in exporting regions
- Crop shifts and nutrient pollution in importing regions
- Cascading impacts on soil erosion emissions and rural incomes

### Cross-Coupling Interactions
- Climate change urbanization and policy jointly reshape local coupling and propagate across regions
- Urban land expansion in wealthy areas induces telecoupled land use change in poorer regions
- National ecological projects alter basin scale processes with downstream and telecoupled impacts

### Research Gaps or Limitations
- Insufficient understanding of multiscale feedbacks and transmission mechanisms among elements
- Limited quantitative analysis of telecoupling contributions and combined eco socioeconomic effects
- Temporal and spatial scales short coarse data scarce especially for household and global levels

### Search Keywords
- rural human earth system coupling
- urbanization trade telecoupling agriculture
- policy engineering ecological effects China

### Extraction Confidence
high
