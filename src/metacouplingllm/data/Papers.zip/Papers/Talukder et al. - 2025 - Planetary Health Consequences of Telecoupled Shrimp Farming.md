# Planetary Health Consequences of Telecoupled Shrimp Farming

Byomkesh Talukder , 1 Krishna Prosad Mondal,2 Md Saifuzzaman,3 Ranjan Roy,4 Reza Salim,5 Gary W. vanLoon,6 and Keith W. Hipel7

1 Department of Global Health, Florida International University, Miami   
2 Institute of Remote Sensing and GIS, Jahangirnagar University, Savar, Dhaka, Bangladesh   
3 Department of Bioresource Engineering, McGill University, Montre´al, Canada   
4 Department of Agricultural Extension & Information System, Sher-E-Bangla Agricultural University, Dhaka, Bangladesh   
5 Amader Gram Cancer Care & Research Center, Bagerhat, Bangladesh   
6 School of Environmental Studies, Queen’s University, Kingston, Canada   
7 Department of Systems Design Engineering, Waterloo University, Waterloo, Canada

Abstract: The international demand for shrimp from Bangladesh exhibits a Telecoupled system. Semi-intensive to intensive shrimp farming has changed vast coastal areas into saline zones by altering land use and land cover. While shrimp cultivation significantly contributes to foreign exchange earnings, it also leads to various social and environmental impacts that affect planetary health. This study sees shrimp farming as a result of these Telecoupled dynamics. It uses a mixed-methods approach, combining both primary and secondary data to examine its effects on planetary health in Bangladesh’s southwestern coastal areas. The findings reveal several important health and social issues associated with shrimp farming. These include (i) scarcity of drinking and household water, (ii) infectious diseases, (iii) non-infectious diseases, (iv) food and nutritional insecurity, (v) antimicrobial resistance and chemical contamination, (vi) mental pressure, (vii) disaster-related health vulnerability, (viii) social conflict, (ix) healthcare inequality, and (x) rural–urban migration. This analysis enhances our understanding of the complex interactions between humans and nature in shrimp farming systems and their evolving impacts on planetary health in southwestern coastal Bangladesh. The study stresses the urgent need for integrated, ecosystem-based agricultural practices to find a balance between economic benefits and sustainable health and environmental outcomes.

Keywords: planetary health, shrimp farming, telecoupled systems, coastal ecosystems, bangladesh

Publisher’s Note: Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.

Published online: July 25, 2025

Correspondence to: Byomkesh Talukder, e-mail: btalukde@fiu.edu

# INTRODUCTION

A coastal ecosystem is a unique mix of land and water (Burke et al., 2001). It creates a distinct structure, diversity, and energy flow. These ecosystems are crucial for providing services, such as food security, livelihoods, biodiversity, and

coastal protection (Primavera, 2006; UNEP, 2011; Ahammad et al., 2013). Costanza et al. (1997) found that coastal ecosystems support about $7 7 \%$ of global ecosystem services. One of their key roles is their ability to store blue carbon, which helps reduce the effects of climate change (Pendleton et al., 2012). Currently, these crucial ecosystems worldwide are facing significant changes and damage due to various natural and human-made factors (Yap, 2000; Lotze et al., 2006; Waycott et al., 2009; Nichols et al., 2019). These include rising ocean temperatures, more frequent cyclones, sea level rise, mangrove loss, intense agriculture, aquaculture, human settlement, coastal embankment, upstream damming, and industrial and municipal runoff.

Coastal agriculture and aquaculture have notably altered these ecosystems (Azad et al., 2009; Vernier, 2010). Globally, coastal ecosystems with alluvial plains (FAO, 1998) are suitable for agriculture and have been turned into cropland. For example, Indonesia and China’s alluvial coastal plains have the highest percentages of cropland among these ecosystems (Martı´nez et al., 2007). In many regions, coastal areas are utilized for intensive aquaculture due to their favorable conditions, including brackish and saline water (Primavera, 2006). Aquaculture farming has thrived in coastal ecosystems in countries such as Indonesia, Brazil, the Bahamas, Bangladesh, Thailand, and Sri Lanka (FAO, 2018a). There is a high demand for coastal aquaculture from local and global markets to meet the food needs of a growing population (Ahmed & Thompson, 2019). Notably, the Black Tiger shrimp (Penaeus monodon) has become the leading globally traded aquaculture product, providing significant employment opportunities (Gillett, 2008). Approximately 6 million tons of shrimp are produced worldwide, with around $6 0 \%$ of this amount entering the international market. Asia is the primary shrimp-producing region, accounting for approximately 3.4 million tons annually (Gillett, 2008).

The rising demand for shrimp in both domestic and international markets has led to increased shrimp harvesting and aquaculture, resulting in significant changes in land use and land cover across coastal areas. These changes are not limited to production zones; they result from complex interactions between distant production and consumption systems known as Telecoupled systems (Liu, 2017; Leisz et al., 2016). Liu (2017) describe a Telecoupled system as a set of coupled systems that interact both locally and from far away, influenced by various agents and causes with diverse effects (Liu, 2017, p. 1). They further define it as a framework that integrates human and nature interac-

tions within a system (Intracoupling), between neighboring systems (Pericoupling), and between distant systems (Telecoupling) (Liu, 2017, p. 4).

While shrimp farming has provided economic benefits, it has also caused serious ecological and social issues. A clear example is the extensive destruction of mangrove forests, linked to intensive aquaculture (Martinez-Porchas & Martinez-Cordova, 2012). Globally, around 1 to 1.5 million hectares of coastal lowlands, including salt flats, mangroves, marshes, and agricultural areas, have been converted to shrimp farms (Pa´ez-Osuna, 2001). In Bangladesh, this expansion has significantly altered coastal landscapes, leading to widespread ecosystem decline (Paul & Vogl, 2011).

To understand these global–local interactions, we employed the Telecoupling framework, as described by Liu (2017). This framework examines socioeconomic and environmental interactions over distances by identifying and connecting key components: sending systems, such as consumer countries; receiving systems, including shrimpproducing areas like coastal Bangladesh; and spillover systems, which encompass neighboring regions indirectly affected by trade or environmental changes. These systems are linked through flows of shrimp products, capital, labor, and environmental impacts, including carbon emissions and biodiversity loss. Distant markets, such as international shrimp trade, significantly shape these flows and affect outcomes across systems.

This study utilizes the five main components of the Telecoupling framework: (i) sending systems, (ii) receiving systems, (iii) spillover systems, (iv) flows, and (v) agents (FAO, 1998). Sending systems, such as those in the USA, the UK, Germany, and Japan, create demand that drives shrimp farming in southwest Bangladesh, the receiving system, particularly in the Shyamnagar Upazila of Satkhira district. Spillover systems encompass neighboring areas that are affected by ecological damage or changes in regulations. Agents, such as farmers, exporters, policymakers, and development organizations, facilitate the movement of products, capital, labor, and environmental impacts. This framework enables a structured analysis of how global market forces contribute to local environmental degradation and public health risks. The degradation of Bangladesh’s coastal ecosystems illustrates Telecoupled humannature interactions (Liu, 2017), connecting distant consumption to local production (Barbier et al., 2011). Demand from Europe, North America, and East Asia leads to changes in land use, salinity intrusion, biodiversity loss, and

health impacts in the coastal areas of Bangladesh. Although these effects are felt locally, they are rooted in global consumer behavior. The Telecoupling framework helps clarify these links, showing how international trade affects local ecological and health outcomes.

In these Telecoupled areas, changes in ecosystem services have direct and indirect effects on human health (Jackson et al., 2013; Myers et al., 2013). Degraded coastal systems can no longer protect communities from cyclones, floods, and storm surges, making them more vulnerable (Rusch & Martinez, 2014). They also fail to support diverse livelihoods and essential services, highlighting the connection between environmental decline and public health (Pongsiri et al., 2017). This situation illustrates broader planetary health challenges, providing a clear example of how global ecological changes impact local well-being.

Planetary health focuses on the relationship between human health and environmental systems. It is defined as ‘‘the achievement of the highest possible standard of health, well-being, and equity worldwide through careful attention to the human systems political, economic, and social that shape the future of humanity and the Earth’s natural systems that set the safe environmental limits within which humanity can thrive’’ (Whitmee et al., 2015, p. 1978). This concept emphasizes the connections between ecological changes and health outcomes (Whitmee et al., 2015).

Shrimp farming in Bangladesh has grown in a complex sociopolitical environment. The industry expanded by converting rice paddies into shrimp ponds, often without proper environmental oversight. Weak regulations, informal land leasing, and unclear property rights enabled this transformation. Although government policies promoted shrimp exports to increase foreign currency, they did not address the resulting ecological and health impacts. Local institutions and communities were left mainly to cope with these challenges (Azad et al., 2009; Paul & Vogl, 2011; MoWR, 2005; Abdullah et al., 2017; Akber et al., 2017; Hossain et al., 2013; Pokrant, 2014).

In this context, the Telecoupling framework and the concept of planetary health offer complementary viewpoints. Telecoupling reveals the global–local dynamics of shrimp production, while planetary health highlights the long-term effects on human and environmental well-being. By applying these frameworks, this study examines how global shrimp demand contributes to the decline of coastal ecosystems and their health implications in Bangladesh. Understanding the drivers, flows, and consequences of

these Telecoupled systems is essential to addressing the interconnected risks they present to planetary health.

# DATA AND METHODOLOGY

This study employs both quantitative and qualitative techniques to examine the planetary health implications of shrimp farming from the perspective of the Telecoupling framework. The detailed methodology aspects of the study are presented below.

# Study Area Context and Justification: the Southwest Coastal Ecosystem of Bangladesh

This study examines shrimp farming on the southwest coast of Bangladesh to understand the planetary health effects of shrimp farming as a Telecoupled system. The coastal zone of Bangladesh is home to approximately 40 million people and spans $4 7 { , } 2 0 1 ~ \mathrm { k m } ^ { 2 }$ , which accounts for $3 2 \%$ of the country’s total area (MoWR, 2005). This zone is low-lying, with $6 2 \%$ of the land below $3 \textrm { m }$ and $8 6 \%$ below $5 \textrm { m }$ (Islam et al., 2006). The coastal area can be divided into three regions: southeast, south, and southwest.

The southwest coastal zone is part of the struggling Ganges Delta. It is crisscrossed by rivers that branch off from the Ganges, creating an area where tidal waters flood the coastal plain. The ecosystem here primarily consists of salt marshes and mangrove-dominated intertidal areas. This zone has a unique brackish water ecosystem due to tidal influence and relies on freshwater supplies from upstream (Mondal et al., 2013). The low-lying area is highly vulnerable to natural disasters, such as cyclones and tidal surges (Gillingham, 2016). With its extensive lowland regions surrounded by man-made polders, the area is very susceptible to climate change-related hazards. Climate change is expected to increase the vulnerability of communities in Southwest Bangladesh to both rapid and slow natural disasters, including coastal erosion, cyclones, floods, and rising sea levels (Mondal et al., 2013; Gillingham, 2016).

Among the primary shrimp-producing districts in the southwest coastal zone, Khulna, Satkhira, and Bagerhat were chosen for data collection. Their unique mix of environmental, economic, and social-political factors makes them a suitable case study for understanding the implications of shrimp farming on planetary health (Pokrant, 2014). While tiger shrimp (Penaeus monodon)

are also farmed in Khulna and Bagerhat, Satkhira is notable for facing greater salinity intrusion, more frequent cyclones, and severe impacts of climate change. This makes it a valuable case for studying the environmental and health effects of shrimp farming in the region. Additionally, shrimp farming in Satkhira has expanded into ecologically sensitive lowland areas, leading to ecological degradation and reduced resilience of local ecosystems.

From a social and policy perspective, the rapid growth of shrimp aquaculture in Satkhira has been driven by national policies that promote export-oriented production, foreign investment, and rural economic development. Shrimp farming is one of Bangladesh’s primary export sectors, with significant demand from distant markets such as the USA, Japan, the UK, and Germany. These distant markets are part of the Telecoupling framework, pushing local land-use changes and intensifying aquaculture in places like Satkhira. International trade policies, development aid, and market certification standards, such as those for organic or sustainable shrimp, connect local practices to global institutions and actors, reinforcing Telecoupled dynamics. The push for foreign currency through shrimp exports has led to the transformation of agricultural land into shrimp farms, often at the expense of ignoring ecological impacts, national regulations, and social consequences. The local environmental and health issues in Satkhira, such as land degradation, salinity intrusion, water pollution, and public health concerns, are connected to economic choices and consumption patterns in distant places. These interactions across different scales underscore the central concept of the Telecoupling framework (Liu, 2017) and demonstrate the necessity for integrated policy responses that address both global and local impacts.

In Satkhira, Shyamnagar Upazila was selected as the primary study site due to its proximity to the Sundarbans, high density of shrimp farms, and significant socio-ecological pressures. This makes it a crucial area for examining the Telecoupled human-nature dynamics and the planetary health effects of industrial shrimp aquaculture.

# Primary and Secondary Data Collection

To further understand this Telecoupled system, data were collected in 2025 in Shyamnagar Upazila (see study area in Fig. 1A) of the Satkhira district, located in the southwestern coastal region of Bangladesh, where Black Tiger shrimp are cultivated. The research was conducted as part of a project

initiated by the Institute of Remote Sensing and GIS, Jahangirnagar University, Savar, Dhaka, Bangladesh.

Primary data were collected through a questionnaire survey involving 200 households to assess the health impacts of shrimp farming. Additionally, informal interviews and discussions were held with key informants, including government officials from the agriculture, fisheries, veterinary, and health departments. Field observations and practical experiences related to shrimp farming further helped identify and verify the planetary health impacts in the study area.

The demographic profile of the respondents revealed an average age of 65.0 years. There was a significant gender imbalance, with $9 3 . 9 7 \%$ of respondents being male and only $6 . 0 3 \%$ being female. The main occupational categories of the respondents’ families included fishing/crab catching (53 respondents), day labor (53), agriculture excluding shrimp (38), business (32), and shrimp farming (21), with 3 respondents engaged in other activities. The average educational qualification level was 1.82, based on a scale where $0 = { \mathrm { n o } }$ formal education, $1 =$ primary education, $2 =$ secondary education, and $3 =$ higher secondary education or above.

To validate and complement the findings from the primary data, secondary data were collected through a narrative review of 99 documents. These included peerreviewed journal articles and reports from government agencies and non-governmental organizations. Keywords such as ‘‘shrimp farming,’’ ‘‘health impacts of shrimp farming,’’ and ‘‘impacts of shrimp farming’’ were used to guide the literature review and extract relevant health-related information.

# Technique to Analyze Land Use and Land Cover Change

The Telecoupled human-nature interactions of shrimp farming have profound impacts on land-use and landcover change (LULCC). Landsat satellite images were analyzed using ERDAS Imagine software to understand the rate of coastal land use and land cover changes related to shrimp farming over a 49-year period. A flowchart of the steps involved in satellite image analysis is presented in Appendix I. In short, satellite image analysis comprised seven steps: (i) Landsat image collection, (ii) image processing, (iii) feature extraction from the image, (iv) decision and classification of the features, (v) reclassification of

LEGEND   
![](images/218b575ead58f17e568259b0b5e9c036ecea68eefb350dc5c9468d3b0c5ddc3d.jpg)  
Highsalinitybrackish water;shrimpdominant; nointegratedagriculture   
MediumSalinitybrackish water;shrimpand prawn culturealtermated with rice   
Low salinity freshwater; prawn dominant; rice grown concurrentl   
□ MangroveForest   
Areas in which survey farms we sampled   
Distict capital   
OMajor town

![](images/f9e2afca34e869af677f4fffeb430845a71326aee986b46cd7773c38c149e64d.jpg)

![](images/45693e80d0a7c29a8da3bc49d94939d5ae2af31cece9257f6f1e9853b87b21a3.jpg)

![](images/8bfdd9b617f306288c29ec69eca07c8e09869f8c8412d14cc480eaf1b8c2b11d.jpg)

![](images/0d8905b4ad7bbd6543489a8e069ecf526a650855e5f4320370247a50afad1554.jpg)  
Figure 1. Telecoupled dimensions of shrimp aquaculture in coastal Bangladesh. [A] Study area: Shyamnagar Upazila in Satkhira District, a hotspot of shrimp farming and the focal site of this study (Hinchliffe et al., 2018). [B] Shrimp farming zones: Spatial distribution of shrimp aquaculture areas across the southwestern coastal region of Bangladesh, highlighting clusters in Khulna, Bagerhat, and Satkhira (adapted and modified from Islam & Bhuiyan, 2016). [C] Export destinations: Global network of shrimp export destinations from Bangladesh, including countries in North America, Europe, East Asia, and the Middle East, which function as sending systems in the Telecoupling framework (BFFEA, 2014). [D] Land-use change: Expansion of shrimp farming areas from 1984 to 2018, demonstrating how international demand drives local ecosystem transformation (DoF, 2018). [E] Export trends: Temporal patterns of shrimp exports from Bangladesh between 1984 and 2018, reflecting growing integration into global seafood markets (DoF, 2018).

the features, (vi) accuracy assessment, and (vii) outputs (maps and data).

# RESULTS

# Telecoupled System Analysis of Shrimp Farming in Bangladesh

Shrimp farming has rapidly expanded across both the southwestern and southeastern coasts of Bangladesh, driven by a combination of local and global factors. As shown in Fig. 1[B], key shrimp-producing regions include Khulna, Bagerhat, and Satkhira, with significant spatial clustering of aquaculture zones. Among these, Shyamnagar Upazila in Satkhira District, highlighted in Fig. 1[A], was selected as the focal site for this study due to its high intensity of shrimp farming and its proximity to the Sundarbans, making it a critical zone for investigating the planetary health implications of this industry (Hinchliffe et al., 2018).

Shrimp aquaculture in Bangladesh operates within a Telecoupled system, emerging from the complex interactions between local ecological, social, and economic conditions and global consumption and trade networks. As illustrated in Fig. 1[C], distant markets in North America, Europe, East Asia, and the Middle East serve as the sending systems under the Telecoupling framework, creating a transnational demand that drives local land-use transformations and intensifies shrimp production (BFFEA, 2014).

The origin of this Telecoupled transformation can be traced back to the 1980s when global demand for shrimp began to surge significantly (Hossain & Hasan, 2017). Several key forces contributed to the expansion of shrimp farming and the development of its export-oriented model. These include international donor support, trade liberalization, and structural adjustment policies aimed at promoting global shrimp trade (Abdullah et al., 2017). Additional contributing factors (Paul & Vogl, 2011; Abdullah et al., 2017; Pokrant, 2014; Alam & Pokrant, 2009; Hossain et al., 2013; Khan et al., 2015; Akber et al., 2017; Karim et al., 2019) include (i) rising demand in both international and local markets, (ii) government support and policy promotion, (iii) favorable ecological and climatic conditions, (iv) availability of shrimp fry and polderized coastal lands, (v) relatively high market prices, low land costs, and cheap labor, and (vi) Bangladesh’s broader export-led development trajectory.

Over the past three decades, shrimp farming has experienced exponential growth to meet international market demands, making it one of Bangladesh’s major sources of foreign currency from the agricultural sector (Hossain & Hasan, 2017). Figure 1[E] depicts the export trends from 1984 to 2018, showing a steady increase until 2011. Despite a slight decline between 2012 and 2018, primarily due to disease outbreaks, such as white spot syndrome, and natural disasters, including Cyclone Sidr (2007) and Cyclone Aila (2009), shrimp exports remain substantial (DoF, 2018). For example, Bangladesh exported 59.7 million kg and 60.7 million kg of shrimp in 2011 and 2012, respectively, earning US$ 445.35 million and $\operatorname { U S } \$ \ S$ 449.56 million in those years (DoF, 2014).

The scale of shrimp aquaculture is further emphasized by Fig. 1[D], which shows the expansion of shrimp farming land from 51,812 hectares in 1983–84 to 137,996 hectares in 2015–16, marking a $2 6 6 \%$ increase over just two decades (DoF, 2018, 2005, 1995). This spatial transformation underscores how international demand has reshaped the local landscape, often at the expense of traditional agricultural practices and ecological stability.

Today, Bangladesh ranks fourth globally in terms of shrimp farming area and sixth in production volume. The main shrimp varieties cultivated include the Black Tiger shrimp (Penaeus monodon) and freshwater prawn (Macrobrachium rosenbergii) (Azad et al., 2009). According to estimates from 2004, Bangladesh supplied $2 . 5 \%$ of the world’s shrimp exports (DoF, 2004). The global scope of Bangladesh’s shrimp trade, shown in Fig. 1[C], reflects its deep integration into international seafood markets, reinforcing the structural dependence on foreign demand.

In summary, the telecoupled dynamics of shrimp farming in Bangladesh are evident in the cross-scale interactions between local vulnerabilities and global economic drivers. The transformation of land use, increased export earnings, and ecological consequences illustrate the multi-dimensional implications of this industry, which is both shaped by and contributes to planetary health outcomes.

# Planetary Health Consequences

The global demand for shrimp has led to serious planetary health consequences in regions where shrimp are cultivated and harvested. To explore these consequences, this section first examines the socio-ecological impacts of shrimp

![](images/27679567ee9f91c6e0cc51382cdc3e0fea1f8a546c059ed22abd6670467e8b39.jpg)

![](images/148c7d321a255c41d23b13f6b9048e375a8fa09650e217d4748638fb22935c83.jpg)  
Figure 2. Socio-Ecological Dynamics and Trade-Offs of Shrimp Farming. A Causal diagram illustrating the socio-ecological dynamics triggered by shrimp farming. The introduction of saltwater ponds increases surface water salinity, triggering a cascade of interconnected impacts—some positive $( ~ + )$ , such as increased economic benefits, and several negative (–), including reduced livelihood diversity, ecological degradation, and adverse health effects. B Conceptual model visualizing the trade-offs of shrimp aquaculture. While shrimp farming boosts regional monetary inflow, it simultaneously erodes livelihood diversity, compromises ecological services, and deteriorates health conditions, underscoring the broader implications for planetary health.

farming at the regional level, followed by an interpretation of their broader implications for planetary health.

# Socio-Ecological Consequences

Shrimp farming in the study area, particularly focused on Black Tiger shrimp (Bagda), has triggered a complex web of socio-ecological cause-and-effect relationships, illustrated in Fig. 2[A]. This diagram illustrates how saltwater shrimp ponds increase surface water salinity, resulting in a range of both positive $( \mathbf { \nabla } + )$ and negative (–) socio-ecological outcomes. While economic gains are one benefit, the adverse effects on livelihood diversity, health, and ecological services are also evident.

Figure 2[B] conceptually illustrates the trade-offs associated with shrimp farming: Although monetary flow into the region has increased, there has been a concurrent decline in livelihood diversity, ecological services, and health outcomes. These diagrams are essential for visualizing how shrimp farming restructures socio-ecological systems and how these changes scale up to influence planetary health dynamics.

In its early phase, shrimp farming yielded significant economic benefits by generating foreign currency. Policymakers considered these gains instrumental for local socioeconomic development. However, much of this

potential benefit failed to materialize locally, as large farm owners often lived elsewhere (e.g., in Khulna or Dhaka) and did not reinvest profits into the communities where shrimp farming took place (Abdullah et al., 2017). Although shrimp-related activities, such as fry collection, pond processing, hatchery, pharmaceutical sales, shrimp feed production, ice making, and processing and distribution, created employment opportunities for residents (Abdullah et al., 2017; Hossain & Hasan, 2017; Apu, 2014), these economic benefits were not equitably shared. Instead, the system exacerbated income inequality, as wealthy elites gained control over common lands and water bodies, often through illegal acquisition, thereby marginalizing poorer households that had historically depended on these commons.

Shrimp farming has also entrenched gender inequality, as women are primarily limited to shrimp fry collection (Abdullah et al., 2017), a low-paying and labor-intensive task. Additionally, industry has led to widespread loss of agricultural biodiversity, fish diversity, and livestock diversity (Abdullah et al., 2017; Johnson et al., 2016). With agricultural lands converted to monoculture shrimp ponds, the diversity of livelihoods has sharply declined, affecting millions of small farmers and marginalized communities that rely on coastal ecosystems (Johnson et al., 2016). As disease outbreaks and cyclones grew more frequent, the

![](images/a1d8b5cd9ed8035488cb07a099281049de35fa7b3d63b78443ef9531e204c468.jpg)

![](images/ec60ca5bb294ca4f0425631573b425cfb9938a08a2f992985c5ebdfe55bd8b8b.jpg)

![](images/3389754f63fbb037b27909e8a418e4f0137cdbd53ab233d9f9d6358fcbc80f69.jpg)  
Figure 3. Land Use and Land Cover Change in the Study Area (1973–2022) Showing Agricultural Land Conversion to Shrimp Farms and Other Key Transitions.

<table><tr><td rowspan="2">Legend</td><td rowspan="2">Land Cover Class</td><td colspan="2">1973</td><td colspan="2">2000</td><td colspan="2">2022</td></tr><tr><td>Area (ha)</td><td>%</td><td>Area (ha)</td><td>%</td><td>Area (ha)</td><td>%</td></tr><tr><td></td><td>Agriculture land</td><td>38930.40</td><td>18.79</td><td>13807.89</td><td>6.66</td><td>9121.95</td><td>4.40</td></tr><tr><td></td><td>Homestead</td><td>2154.24</td><td>1.04</td><td>8599.61</td><td>4.15</td><td>8367.66</td><td>4.04</td></tr><tr><td></td><td>Shrimp Firm</td><td>0.00</td><td>0.00</td><td>20285.98</td><td>9.79</td><td>24885.18</td><td>12.01</td></tr><tr><td></td><td>Mangrove Forest</td><td>111075.12</td><td>53.61</td><td>108537.66</td><td>52.39</td><td>104012.82</td><td>50.21</td></tr><tr><td></td><td>Waterbodies</td><td>55014.12</td><td>26.55</td><td>55942.74</td><td>27.00</td><td>60786.27</td><td>29.34</td></tr></table>

initial high economic returns diminished, triggering income reduction and rural-to-urban migration (Kafle et al., 2018).

The transformation of the physical landscape is further demonstrated in Fig. 3, which presents satellite imagery analysis of land-use changes between 1973 and 2022. This visual evidence illustrates how agricultural land, fallow fields, and wetlands—once integral to the dynamic estuarine ecosystem—were increasingly converted into shrimp ponds. The resulting changes in land use increased soil and water salinity, altering key biophysical properties of the

surrounding landscape (Abdullah et al., 2017; Johnson et al., 2016). The shrimp ponds, often filled with saltwater during high tides, fragmented the landscape and created barriers to biodiversity, disrupting wildlife habitats and natural corridors (Mullu, 2016).

Figure 4 [A] and [B] further document this transformation. These images depict various types of agricultural lands that have been converted into saltwater ponds, thereby destroying natural vegetation. One significant impact is the interruption of mangrove forest succession, especially the clearing of species such as Sundari (Heritiera

![](images/06b65eb0f3bc46f376fee27f21aaba08de606be51f9a3571dca343601a5fe8a8.jpg)

![](images/8d3e46187a4f6817cce8e07c654e483dbce57431bf090ccb47b62359388ae1f2.jpg)

![](images/3a9bdb84d991334a213943ac65a64f02844ced880736a7ceb15a68ac0cba64a2.jpg)

![](images/13a9226576f4a39577e7799f5817f77231e9e886fc5c7cb606735cfbf3dfeea4.jpg)

![](images/2636a00e78155879cf51320955f992cca8aae7ec11948e47b230707e146e9da6.jpg)

![](images/f99474321c3d025c5ab5502a4a0f95b0e9204fc3fb604555a5907f99601b11c9.jpg)  
Figure 4. Socio-Ecological Impacts of Shrimp Farming in Coastal Bangladesh. [A] Shrimp farming area with no vegetation, illustrating ecosystem degradation. [B] Homestead with sparse tree cover, indicating reduced biodiversity. [C] Collection of shrimp fry from natural water bodies. [D] Discarding non-shrimp species while retaining shrimp fry, affecting aquatic biodiversity. [E] Snail collection for use as shrimp feed. [F] Delivery of potable water by boat post-Cyclone Aila, reflecting freshwater scarcity in shrimp-farming regions.

littoralis) and Golpata (Nypa fruticans) for pond development. All wetlands in the study area have been converted for shrimp farming, and the saline seepage has made even adjacent agricultural lands less viable, severely limiting the diversity of crops that can be grown (Canedo-Arguelles et al., 2019).

This alteration undermines vital ecosystem services, particularly natural water purification, which relies on healthy ecosystems with diverse species (UNEP, 2006). Without these natural filters, the risk of waterborne diseases and pollution increases, posing a significant threat to both human and ecological well-being.

Shrimp farming in the region has long depended on wild shrimp larvae collected from local estuaries. However, the high demand has led to illegal, unreported, and indiscriminate fishing for fry, as shown in Fig. 4 [C] and [D]. While shrimp fry is retained, the vast majority of by-catch species are discarded, severely damaging aquatic biodiversity (Ahmed & Troell, 2010; Rahman et al., 2013). Expert interviews and field observations confirm that many native estuarine fish species are in decline, while Tilapia (Oreochromis niloticus), known for its resilience, is becoming a monospecific invasive species. Furthermore, snails, a local food source and input for shrimp feed, are being overharvested, as shown in Fig. 1 [E], contributing to imbalances in aquatic ecosystems. In extreme cases, this has transformed vibrant estuarine systems into barren aquatic zones.

Recently, shrimp production has declined, mainly due to white syndrome disease, which is exacerbated by cyclone-related waterlogging, intensive chemical use, and unsustainable farming methods (Talukder et al., 2016).

Adding to these ecological challenges is the mismanagement of embankments and polders, initially built in the 1960s for disaster protection. These structures have altered natural water flow, disrupted drainage patterns, and worsened problems, such as waterlogging and saline intrusion (Gillingham, 2016). The combined impacts of saline water intrusion, sea-level rise, reduced freshwater inflow, and coastal polder systems have altered the hydromorphological dynamics of the southwest coastal region (Mondal et al., 2013), further intensifying both environmental degradation and vulnerability to climate-related shocks.

# Planetary Health Consequences

The socio-ecological impacts of shrimp farming have led to a range of adverse consequences for planetary health. These

can be grouped into ten key categories: (i) scarcity of drinking and household water, (ii) infectious diseases, (iii) non-infectious diseases, (iv) food and nutritional insecurity, (v) antimicrobial resistance and chemical contamination, (vi) mental pressure, (vii) disaster-related health vulnerability, (viii) social conflict, (ix) healthcare inequality, and (x) rural–urban migration. Each of these consequences is detailed in Sects. ‘‘Scarcity of Drinking and Household Water’’ through ‘‘Rural–Urban Migration’’.

Scarcity of Drinking and Household Water Shrimp farming has significantly contributed to the rise in salinity levels in soil, surface water, and groundwater across coastal areas. This problem has been exacerbated by sea level rise and recurrent cyclones, which cause prolonged waterlogging and further intrusion of saline water into freshwater sources. According to local farmers, the salinity levels in shrimp ponds typically range between 3 and 10 parts per thousand (ppt).

All 200 respondents $( 1 0 0 \%$ ) reported living within $1 ~ \mathrm { k m }$ of a shrimp farm, indicating constant exposure to environmental factors. Despite this proximity, access to safe water remains a challenge. Notably, $5 0 \%$ of respondents reported experiencing difficulties in accessing safe water, underscoring the widespread impact of environmental degradation on daily life. While $4 2 . 5 \%$ of respondents use shrimp pond water for household activities such as cooking, washing, and bathing, the majority $( 5 7 . 5 \% )$ ) actively avoid it. The scarcity of potable water forces $3 2 \%$ of respondents to collect drinking or cooking water from outside their village, often traveling 1–2 km $\left( 4 3 . 0 8 \% \right)$ ) or more than 2 km $2 1 . 5 4 \%$ ), adding to the burden of daily life.

Survey findings reveal that $9 3 . 5 \%$ of respondents have observed an increase in salinity in their water sources over the past five years. Furthermore, over half $( 5 3 \% )$ ) of the households reported experiencing waterlogging or flooding, attributed to shrimp aquaculture practices or cyclone impacts. Concerns over deteriorating environmental quality are widespread, with $5 3 \%$ of respondents believing that shrimp farming has hurt local air and water quality. A severe shortage of drinking water emerged as a common and urgent concern among all respondents. This issue, particularly intense during the hot summer months, was considered one of the most significant impacts of shrimp farming, posing a threat to both everyday life and longterm public health (Paul & Vogl, 2011).

Infectious Diseases Several studies have demonstrated a strong correlation between elevated salinity levels and the spread of infectious diseases (Saha, 2017; Nahian et al., 2018; Jabed et al., 2020). In the shrimp farming zones examined in this study—where saline water is commonly used for drinking, bathing, and other household purposes, often in unsanitary conditions—residents reported experiencing a wide range of health problems. Prolonged exposure to brackish water, particularly during daily farming activities, further increases vulnerability to disease. Survey data revealed that a significant portion of the population is directly engaged in shrimp farming activities: $7 3 . 5 \%$ in pond maintenance, $6 1 . 0 \%$ in prawn fry collection, and $2 5 . 0 \%$ in feed preparation. These tasks often involve standing in brackish water for extended hours, heightening the risk of waterborne infections, skin diseases, and respiratory complications.

Among the 200 households surveyed, a striking $9 0 \%$ reported fever or viral infections, $6 0 \%$ reported diarrhea or stomach-related issues, $5 9 . 5 \%$ experienced respiratory problems, $5 7 . 5 \%$ reported skin diseases or itching, and $5 1 \%$ experienced eye irritation. These conditions are all commonly associated with communicable diseases, indicating that at least $9 3 . 5 \%$ of households reported suffering from one or more communicable illnesses. This high prevalence underscores the significant public health burden in these communities exposed to saline.

People directly engaged in shrimp farming face heightened risks due to their routine activities. Many spend five to eight hours per day standing in waist-deep pond water while collecting shrimp fry, maintaining embankments, or managing farm operations (Hossain & Hasan, 2017). This prolonged contact, especially when skin is cracked or abraded, provides a direct pathway for infections to enter the body. Additionally, biodiversity loss in the study area may have exacerbated ecological imbalances, creating more favorable conditions for the proliferation of disease-causing organisms, including those responsible for diarrheal diseases (Johnson, 2019).

Non-Infectious Diseases High salinity in drinking water is associated with a range of non-infectious health issues, most notably heart failure, hypertension, and other cardiovascular diseases (Nahian et al., 2018; Scheelbeek et al., 2017; Talukder et al., 2018). In the household survey, $2 4 \%$ of respondents reported suffering from high blood pressure (hypertension). Additionally, $1 4 . 5 \%$ reported reproductive health issues, which are often linked to bathing in saline

water. One key informant explained that the scarcity of freshwater forces women to rely on saline sources for bathing, which contributes to hygiene issues particularly affecting reproductive health due to the inability to remove saline residues adequately. However, due to conservative social norms, many women do not seek treatment for these conditions.

Further, a recent study showed that miscarriage rates are high in saline-prone areas (BBC, 2018), a finding supported by local public health officials who also noted frequent cases of pre-eclampsia, eclampsia, and hypertension among pregnant women in the region (Khan et al., 2008; Khan et al., 2014). Many women may experience menstrual irregularities and have a heightened risk of pre-term birth (Khan et al., 2014; Stocher et al., 2018). In addition, $0 . 5 \%$ of households surveyed reported kidney-related problems, which, along with risks such as kidney stones and reduced bone mass, are common among residents exposed to prolonged salinity in their drinking water (Habiba et al., 2014; Akter, 2019).

Food and Nutritional Insecurity Biodiversity in animals, fish, fruits, vegetables, and crops is a vital foundation for ensuring food productivity and nutritional security. Since the expansion of shrimp cultivation, biodiversity in the region has declined significantly [see Picture 1(A) and (B)]. One of the most affected areas has been rice production, as nearly all rice fields have been converted into shrimp farms. This shift has reduced the availability of this staple grain, contributing to lower caloric intake. Farmers now receive only about 1200 kcal per person per day, compared to the recommended $1 8 0 0 \ \mathrm { k c a l }$ (Talukder et al., 2016).

Before the rise of shrimp farming, local households cultivated a variety of fruits and vegetables and raised livestock, including poultry. However, this diversity has diminished. According to survey data, while $6 4 \%$ of households still engage in home production of vegetables, fruits, or grains, $3 6 \%$ do not. Additionally, $6 7 \%$ of respondents reported a decline in the local availability of vegetables, fruits, and fish, with another $2 0 \%$ uncertain, highlighting a widespread perception of reduced food access.

Soil salinity has also impacted homestead fruit trees such as banana, guava, jackfruit, and mango, leading to a sharp decline in productivity. Duck rearing has notably decreased, as shrimp farmers discourage ducks due to their tendency to eat shrimp larvae and fish.

Fish diversity has been significantly altered. While previously 12–16 types of brackish water fish were available, only 1–3 dominant varieties remain now. Survey results show that $6 9 . 3 5 \%$ of households consume 3–5 types of fish per month, while only $1 6 . 5 8 \%$ consume more than 5 types, and $1 4 . 0 7 \%$ consume just 1–2 types, indicating a narrowing dietary range.

These changes have had nutritional consequences. Although $6 9 \%$ of households reported no signs of malnutrition or growth issues among children, $3 1 \%$ did, pointing to a substantial minority facing dietary challenges. Local health officials have linked this to rising cases of vitamin deficiencies and related health impacts among both children and adults.

Antimicrobial Resistance and Chemical Contamination Monocultures of Black Tiger shrimp are particularly vulnerable to diseases, such as white spot syndrome, prompting the everyday use of antibiotics in aquaculture. However, only $2 . 0 0 \%$ of households surveyed reported involvement in chemical use, suggesting that while antibiotics and other chemical treatments are known practices, their direct application may be limited to a small subset of farmers. In contrast, $7 3 . 5 0 \%$ of families are engaged in - pond maintenance, a critical activity that often involves managing water quality and removing unwanted organisms using sanitizers such as algicides and pesticides. Additionally, $2 5 . 0 0 \%$ of respondents are involved in feed preparation, where substances like urea are applied to stimulate the growth of plankton. Lime is also used to adjust pond pH during preparation, but excessive use can disrupt the ecosystem by encouraging cyanophyte blooms and suppressing beneficial diatoms. These findings highlight a reliance on ecological management practices over chemical interventions in many shrimp-farming communities.

Mental Pressure In addition to physical health issues, shrimp farming has significantly contributed to mental stress among farmers, women, and children. According to recent data, $9 3 . 5 \%$ of respondents reported financial uncertainty as a significant source of mental stress, followed by health problems $\left( 8 9 . 0 \% \right)$ , crop or livestock loss $( 5 9 . 5 \% )$ , and a lack of safe water $( 5 1 . 0 \% )$ ). These stressors are often interconnected, with shrimp disease outbreaks and unprofitable harvests exacerbating economic instability. Although only $5 . 5 \%$ of respondents explicitly cited shrimprelated disputes as a cause of mental stress, such conflicts still contribute to the broader psychosocial burden in af-

fected communities. Women, in particular, face heightened burdens. With $5 1 \%$ of households lacking access to safe water, many women must travel long distances to collect potable water, leaving them with little time for self-care and thereby increasing their psychological strain. Additionally, the transformation of the landscape into saline-dominated, barren terrain has diminished natural greenery, further impacting the community’s mental well-being (Dadvand et al., 2016).

Disaster-Related Health Vulnerability Coastal vegetation such as mangroves and salt marshes serves as natural buffers against cyclones, storm surges, and coastal erosion (Mo¨ller et al., 2014; Narayan et al., 2017; Hanley et al., 2020). According to Narayan et al. (2016), mangroves and salt marshes can reduce wave heights by $3 5 \%$ to $7 1 \%$ . However, shrimp farming has significantly altered coastal vegetation and estuarine wetlands, increasing community vulnerability to natural disasters.

Local shrimp farmers often cut embankments to bring saline water into their ponds, further exposing the region to flooding and waterlogging. This damages remaining crops, increases food insecurity, and harms houses and homesteads. Flooding also exacerbates health issues such as diarrhea, cholera, and fever, which are already prevalent in the region (Jabed et al., 2020).

Social Conflict Shrimp farming continues to be a source of environmental degradation and social unrest, undermining human security (Malik et al., 2014). Although only $5 . 5 \%$ of respondents explicitly cited shrimp-related disputes as a cause of mental stress, field observations reveal that conflicts over land and water access remain prevalent. These include poisoning of shrimp farms, forced occupations, and violent confrontations, sometimes resulting in serious injuries or fatalities. Large-scale Gher (shrimp pond) owners have been reported to install unauthorized sluice gates and pipes to control water flow, weakening embankments and intensifying disputes over land and water rights.

Healthcare Inequality Healthcare inequality is a critical concern in the study area, where environmental degradation, freshwater scarcity, and frequent cyclones make it challenging to retain healthcare professionals at local facilities. Economic disparities further compound this issue, as many low-income households are unable to afford necessary medical services.

Public perception aligns with these systemic challenges: $5 0 \%$ of respondents believe shrimp farming is responsible for local health problems, while $1 7 . 5 \%$ remain uncertain. Despite widespread health issues, $5 1 . 7 6 \%$ of households reported taking no preventive measures against diseases caused by polluted water or air, pointing to gaps in health awareness and access to protective resources.

When illness occurs, $8 0 \%$ of households turn to private doctors. In comparison, only $6 \%$ seek care at government health centers, suggesting a heavy reliance on out-of-pocket healthcare and possible mistrust or inaccessibility of public health services. This is further reinforced by survey data showing that $0 . 0 \%$ of respondents have access to a health center or hospital within a five-kilometer radius, and $0 . 0 \%$ reported that women in their families can access reproductive health services. These findings underscore the urgent need for targeted health infrastructure and awareness initiatives in areas affected by shrimp farming using saline water.

Rural–Urban Migration In coastal Bangladesh, declining agricultural viability driven by increased soil salinity from shrimp farming has led many poor and marginalized households to aspire to migrate to urban areas (Samui et al., 2024). Despite these structural pressures and deteriorating environmental conditions, actual migration from the studied communities remains limited. Although severe health and livelihood challenges persist, only $1 . 0 \%$ of surveyed households reported considering migration to cities for health or income reasons, suggesting that substantial barriers or uncertainties continue to deter rural residents from relocating.

# DISCUSSION

Driven by growing international demand, shrimp farming has rapidly expanded in the study area, generating significant environmental degradation and health challenges. Poor management practices have led to mangrove destruction, biodiversity loss, salinity intrusion, freshwater scarcity, and increased disease prevalence, collectively hindering sustainable development and threatening both planetary and human health. Local communities are increasingly requiring resilient ecosystems that can sustain

essential services, which are foundational to planetary health.

Telecoupled shrimp farming supplies affordable shrimp to global markets, but this comes at the cost of substantial land-use and land-cover changes, particularly the conversion of rice paddies into shrimp ponds. This land conversion severely undermines local food systems, leading to declines in livestock, fruit trees, and freshwater fish, which in turn exacerbate food and nutritional insecurity. Past studies have shown that such agro-ecological disruptions reduce dietary diversity and increase the risks of childhood micronutrient deficiencies (Vernier, 2010; FAO, 1998).

The expansion of shrimp ponds has exacerbated salinity intrusion, which is further intensified by sea-level rise and cyclone-driven tidal surges, leading to a deep-water crisis in the region’s shrimp-farming zones. Consistent with findings from Khulna and Dacope (Ahmed & Ambinakudige, 2024), $9 3 . 5 \%$ of survey respondents reported increased salinity in household water, and $5 0 \%$ faced difficulties accessing potable water. This severe water stress has led to a reliance on private water vendors or saline tube wells, reflecting broader patterns of infrastructural collapse and growing socioeconomic inequality (Hoque et al., 2019; The Guardian, 2024a).

Saline exposure has been linked to both infectious and non-infectious diseases. Communities using brackish water experience higher incidences of skin diseases, respiratory infections, and diarrheal illnesses (Iqbal, 2019). Our study aligns with this evidence, as approximately $9 0 \%$ of participants reported experiencing recurrent fevers, rashes, or gastrointestinal distress. Chronic saline exposure is also associated with hypertension, kidney dysfunction, and reproductive complications, particularly affecting women (The Guardian, 2024b; The Guardian, 2024a). Clinics in Dacope have recorded spikes in pre-eclampsia and chronic hypertension, corroborating our finding that $1 4 . 5 \%$ of respondents experienced reproductive health issues.

Chemical-intensive aquaculture practices compound these planetary health challenges. While only $2 \%$ of respondents acknowledged antibiotic use, water sampling and other reports confirm the widespread application of lime, urea, algicides, and pesticides in shrimp ponds (Hossain & Moniruzzaman, 2019). These inputs degrade aquatic ecosystems and contribute to antimicrobial resistance, a significant global health threat (FAO, 2018b).

Beyond physical health impacts, shrimp farming imposes severe mental health burdens. The majority of households reported financial stress $( 9 3 . 5 \% )$ ), health-related anxiety $( 8 9 \% )$ , and perceived inequities in the distribution of aquaculture benefits. These psychosocial stresses, particularly pronounced among women and young people, align with findings from other coastal Bangladesh studies.

Ecologically, shrimp farming has undermined disaster resilience. Mangrove deforestation, often driven by the expansion of ponds, removes crucial coastal buffers. Mangroves reduce wave energy by $3 5 \mathrm { - } 7 1 \%$ during cyclonic surges (McIvor et al., 2012), thereby intensifying flooding, waterlogging, and post-disaster disease outbreaks, which heighten health vulnerabilities among coastal populations.

Socially, shrimp aquaculture has exacerbated land and water conflicts. Our study documented instances of pond poisoning, forced occupation, and sluice gate manipulation, all of which are clear indicators of environmental injustice in the allocation of resources. Such conflicts undermine social cohesion and marginalize vulnerable populations (FAO, 2018b). Healthcare inequality further compounds these issues; although half of the respondents recognize the negative health impacts of shrimp farming, $8 0 \%$ rely on out-of-pocket private healthcare due to the dysfunction or absence of public services, a pattern observed nationally in saline-affected areas (Iqbal, 2019).

This breakdown in agricultural and healthcare infrastructure contributes to the pressures of rural–urban migration. Although only $1 \%$ of respondents had migrated or planned to migrate, broader research suggests a higher latent migration intent constrained by financial and social barriers. Migrants often face poor sanitation and increased disease exposure in urban slums.

While Telecoupled shrimp farming supports global seafood markets, it imposes disproportionate ecological and health costs on production zones. Economic benefits primarily accrue to local elites or exporters, whereas local communities bear the burdens of degraded water quality, rising disease incidence, and diminishing ecological buffers (Liu, 2017). Without fundamental reforms, these pressures are likely to intensify under climate change, posing a threat to the sustainability of agriculture, aquaculture, public health, and disaster preparedness sectors.

Human development and ecosystem integrity are deeply intertwined. Development models, such as shrimp

farming, when pursued at the expense of planetary health, are unsustainable. Hence, transformative, system-aware approaches are urgently needed. The FAO emphasizes restructuring shrimp farming to promote sustainable production, equitable livelihoods, and ecosystem restoration (FAO, 2018b).

Promising pathways for sustainable transformation exist. Talukder et al. (2016) advocate for integrated farming systems that combine rice, vegetables, and limited shrimp production to sustain yields while mitigating ecological degradation. Globally, approaches such as agroecology (Aubin & Jerome, 2018), regenerative agriculture (Gosnell et al., 2019), and circular aquaculture (Toop et al., 2017) offer innovative frameworks to enhance resilience and justice in food systems.

Additionally, Benessaiah and Sengupta (2014) propose applying social-ecological systems (SES) approaches to shrimp farming, as seen in Nicaragua, to address sustainability challenges and reduce vulnerability among coastal communities. Adopting such holistic models can guide the necessary transition in Bangladesh’s shrimp sector.

This study focuses exclusively on intensive shrimp farming areas, with no comparative data from non-shrimp farming villages, which limits causal inference. Nevertheless, the congruence between observed health symptoms, ecosystem changes, and broader literature strongly supports the presence of complex Telecoupled human-nature interactions. Future comparative and longitudinal research is essential to reinforce the evidence base and identify scalable, effective solutions.

# CONCLUSION

This study highlights various, sometimes hidden, effects of shrimp farming on the health of the planet in the study area. The findings shed light on how local and global systems interact and influence the spread of shrimp farming in Bangladesh’s coastal ecosystems. These insights will help create policies, plans, and programs that address the impacts of shrimp farming on planetary health in coastal regions. The study documents both positive and negative effects, providing an opportunity to consider the best ways to promote responsible shrimp farming, create livelihood opportunities, and support sustainable development.

By revisiting the concept of planetary health, this study highlights its significance in understanding the intricate relationship between environmental degradation, socioeconomic issues, and human health. As shown, shrimp farming is not merely a local issue; it is part of a Telecoupled system. Global demand and economic systems drive land-use changes, health risks, and ecological harm in the region. The Telecoupling framework serves as a valuable tool for tracing these distant but connected effects. It helps identify opportunities for intervention and planning for sustainability.

However, while the Telecoupling approach effectively reveals links across scales and spillover effects, it has its limits. It may downplay deeply rooted local sociopolitical issues, such as elite capture and weak institutions, which also influence environmental and health outcomes. Furthermore, the model’s abstraction can sometimes hide the complex, real-life experiences of local communities, especially in situations of inequality and marginalization.

Bangladesh has a ‘‘100-year delta plan,’’ and the blue economy is seen as one of the vehicles to implement that plan. This implies that there will be significant impacts on coastal ecosystems and resources in the future, making this study especially important for understanding the consequences of using ecosystems for economic activities. The findings provide evidence of the planetary health effects in areas where mono-agricultural practices have a significant impact on the ecosystem.

Based on the findings of this study, the following recommendations are made:

1. Building awareness of the planetary health consequences of shrimp farming among farmers and the shrimp industry is essential. The government of Bangladesh should develop a comprehensive plan to manage shrimp farming sustainably, taking into account the long-term

effects of climate change and mitigating its negative impacts.

2. Eco-shrimp farming, also known as integrated farming (combining rice $^ +$ shrimp $^ +$ vegetables), can be a suitable measure to mitigate the planetary health impacts of current monoculture shrimp farming.   
3. International buyers and the government of Bangladesh should invest a portion of the profits of shrimp cultivation into support of sustainable shrimp farming, which is key to addressing planetary health in the study area.   
4. Further research is required to develop a complex adaptive system-based model of shrimp cultivation and its planetary health implications in order to formulate more effective policy and ecosystem-based adaptation strategies in the study area.

# APPENDIX: I

See Fig. 5

![](images/ad6c271f1be0fdb1c1c6d117273a0d7e3bd700e66ee46b9bf454163364895e48.jpg)  
Figure 5. Flow diagram of the data processing for Landsat images.

