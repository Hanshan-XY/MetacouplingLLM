# Assessing the sustainability of China_s coastal regions A perspective on local coupling and telecou

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:47:33.821858+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Hu et al. - 2025 - Assessing the sustainability of China_s coastal regions A perspective on local coupling and telecou.pdf
- Year: unknown
- DOI: 10.1016/j.ecolmodel.2024.110974
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper evaluates the sustainability of Chinas coastal provinces by explicitly separating local and distant (telecoupled) resource linkages. The study area covers 11 coastal provincial-level units from Liaoning to Hainan over 2011-2021, a key belt of industrialization and international trade in China.

The authors embed telecoupling concepts into an emergy-analysis framework. They classify inputs as internal renewable and nonrenewable resources, and external resources delivered through trade, investment, and other cross-regional flows. Emergy indicators measure total resource use, dependence on external inputs, environmental loading from local versus imported resources, and an emergy-based sustainability index. Spatiotemporal patterns of environmental pressure are examined with Local Indicators of Spatial Association time paths, and drivers of sustainability change are decomposed using the Logarithmic Mean Divisia Index.

Results show that total emergy use in coastal provinces rose overall but dipped after 2019, linked to COVID-19 impacts on trade and activity. Most emergy use comes from nonrenewable and imported resources. Provinces such as Shanghai and Tianjin are highly dependent on external inputs, while Guangxi and Hainan rely more on local resources. Environmental loading from both local and telecoupled sources generally increased. In Hebei, Liaoning, and Shandong, pressure is dominated by intensive use of local nonrenewables; in Tianjin and Shanghai, pressure is mainly tied to imported resources and strong integration into global markets.

The emergy-based sustainability index declines over time in all provinces, with Guangxi, Hainan, and Fujian performing best and Shanghai and Tianjin least sustainable. Decomposition shows that economic growth and better use of renewables can support sustainability, but rising dependence on external and nonrenewable inputs overwhelms these gains.

The paper is directly about metacoupling/telecoupling: it operationalizes local coupling and telecoupling within one quantitative system, distinguishes local versus remote environmental load, and shows how cross-regional flows reshape coastal sustainability. This framework is proposed as transferable to other urban and regional systems facing intensive telecoupled resource exchanges.

## Structured Metacoupling Extraction

### Coupling Classification
- Explicitly analyzes intra-regional local coupling and cross-regional telecoupling in China coastal sustainability.

### Intracoupling
#### Systems
- Coastal provincial socio-economic systems and their local ecosystems
- Internal resource base and environmental carrying capacity
#### Flows
- Use of local renewable resources like water, land, biomass, hydropower
- Extraction and consumption of local non-renewable resources and energy
- Generation of solid, water, and gaseous wastes within provinces
#### Agents
- Provincial governments managing land, energy, and environment
- Local industries including heavy manufacturing and processing
- Urban populations driving consumption and waste generation
#### Causes
- Urbanization and industrialization increasing local resource demand
- Economic growth strategies prioritizing heavy industry in some provinces
- Limited renewable resource endowments in compact coastal cities
#### Effects
- Rising local environmental loading ratios from non-renewable use
- Higher ecological pressure in Hebei, Liaoning, Shandong, Tianjin
- Declining emergy-based sustainability where local loads dominate

### Pericoupling
#### Systems
- Neighboring coastal provinces within Bohai Rim and southern coasts
- Regional urban agglomerations like Yangtze River Delta
- Adjacent inland provinces linked by industrial relocation
#### Flows
- Interprovincial trade in goods, electricity, fuels, and services
- Labor migration from inland to coastal urban clusters
- Relocation of labor-intensive industries inland from coastal cores
#### Agents
- Regional planning authorities and development zones
- Firms shifting production between coastal and inland regions
- Logistics and trade hubs linking nearby provinces
#### Causes
- National strategies such as coastal opening and Belt and Road nodes
- Search for lower environmental constraints and costs inland
- Regional integration of markets and infrastructure
#### Effects
- Spatial spillovers in LELR and TELR detected by LISA time paths
- Competitive versus cooperative environmental load dynamics among neighbors
- Export of pollution-intensive activities away from rich coastal cores

### Telecoupling
#### Systems
- China coastal provinces and global trading partners
- Coastal regions and distant resource-exporting areas
- International economic system and local coastal ecosystems
#### Flows
- Imported fuels, coal, minerals, electricity, refined goods, services
- Foreign investment, tourism revenues, other trade inputs and exports
- Embodied environmental impacts in international commodity trade
#### Agents
- Central and provincial governments promoting openness
- International trading firms and foreign investors
- Tourists and global consumers influencing trade patterns
#### Causes
- Globalization increasing cross-border flows of goods, capital, information
- Coastal gateway role in national opening and export orientation
- Domestic demand exceeding local resource and environmental capacity
#### Effects
- Growing dependency on external resources indicated by rising EER
- High telecoupling environmental loads in Tianjin and Shanghai
- Declining sustainability as imported non-renewables and ELR increase

### Cross-Coupling Interactions
- Internal non-renewable depletion and external imports jointly raise total environmental loading ratios
- Industrial relocation redistributes local coupling pressure while maintaining telecoupled dependence
- Changing emergy intensity mediates how global flows translate into local ecological stress

### Research Gaps or Limitations
- Prefecture and county level analysis limited by data availability and quality
- Telecoupling pathways beyond aggregated emergy flows not fully resolved
- Further interdisciplinary modeling of coupled human-environment systems still needed

### Search Keywords
- China coastal telecoupling emergy sustainability
- local coupling LELR TELR EER ESI
- resource flows environmental loading coastal provinces

### Extraction Confidence
high
