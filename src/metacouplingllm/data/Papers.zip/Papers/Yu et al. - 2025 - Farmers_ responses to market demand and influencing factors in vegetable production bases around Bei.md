# Farmers_ responses to market demand and influencing factors in vegetable production bases around Bei

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:16:56.454242+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Yu et al. - 2025 - Farmers_ responses to market demand and influencing factors in vegetable production bases around Bei.pdf
- Year: unknown
- DOI: 10.1016/j.habitatint.2024.103284
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Metacoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
The paper examines how smallholder farmers around Beijing adjust their land use and vegetable production in response to the citys market demand, using a metacoupling-based food systems framework. The study focuses on seven external vegetable production bases in Hebei Province (Gu an, Zhuozhou, Xuanhua, and Chongli) that supply most of their output to Beijing, highlighting urban-rural linkages within the Beijing-Tianjin-Hebei region.

Using 338 household surveys and interviews with base enterprises conducted in 2023, the authors measure farmland use efficiency with a DEA model and construct an index for Responsiveness of Farmland Use to Demand (RFUD). RFUD is decomposed into four dimensions: factor substitution (technology and inputs), structure adjustment (cropping and land transfer), function transition (economic, social, ecological roles of land), and efficiency (yields, income). Indicators are standardized and weighted by an entropy method, then aggregated. Multiple linear regression is used to analyze how cooperation with bases, services, education, market information, and off-farm work affect RFUD.

Overall RFUD is modest and skewed toward low and medium response levels. Farmers heavily dependent on agriculture, living in mountainous areas, or linked to jointly operated bases show higher responsiveness than mixed-income or off-farm households and those near contract-based operations. Function transition and efficiency differ most by livelihood type; structure adjustment differs mainly by region (mountain vs plain); factor substitution differs most by business model. Cooperation with bases, employment and service support, education, and better market knowledge raise RFUD, while long-term off-farm migration of main laborers lowers it.

The study is explicitly framed within metacoupling: Beijing is the urban demand system, Hebei vegetable bases are the rural supply systems, and flows of produce, capital, labor, technology, and information connect them. Findings show how enterprise-mediated links and farmer capabilities shape cross-regional food supply, with implications for urban food security, regional coordination, and rural revitalization, and they extend metacoupling applications to micro-level farmer behavior in metropolitan foodsheds.

## Structured Metacoupling Extraction

### Coupling Classification
- Telecoupling between Beijing urban food demand and external vegetable bases in Hebei
- Pericoupling among neighboring counties, bases, and nearby villages around Beijing
- Intracoupling within rural household farming systems and within Beijing urban food system

### Intracoupling
#### Systems
- Rural household farming systems in Gu an, Zhuozhou, Xuanhua, Chongli
- Urban Beijing food consumption and distribution system
- Enterprise-centered vegetable production base systems
#### Flows
- On-farm reallocations of labor, inputs, machinery, and cropping structure
- Information flows on prices, market demand, and base requirements within villages
- Income, costs, and productivity changes at household level
#### Agents
- Pure agricultural, mixed-income, and off-farm farmer households
- Base enterprise managers and agronomists
- Village and local government staff supporting bases
#### Causes
- Household characteristics such as education, labor availability, income structure
- Access to cooperative services, machinery, facilities, and credit
- Perceived market signals and risk in local production
#### Effects
- Differences in RFUD levels and pyramidal distribution of responsiveness
- Changes in pesticide, fertilizer, and manure use intensity
- Variation in farm efficiency, diversification, and commercialization

### Pericoupling
#### Systems
- Beijing and immediately surrounding Hebei counties forming a city-region foodshed
- Cluster of external vegetable bases and their adjacent administrative villages
- Regional agribusiness and cooperative networks within Beijing Tianjin Hebei
#### Flows
- Short-distance flows of vegetables from bases to Beijing markets
- Capital, technology, and employment flows from enterprises to nearby villages
- Policy support, subsidies, and technical training from regional governments
#### Agents
- Beijing distribution enterprises and circulation entities
- Local agribusinesses and cooperative organizations in Hebei
- County and municipal governments implementing coordinated development
#### Causes
- Declining farmland and food self sufficiency inside Beijing
- Regional coordinated development strategy and external base construction policies
- Improved transport links such as high speed rail and expressways
#### Effects
- Increased dependence of Beijing on near regional vegetable bases
- Rising agricultural incomes and employment in supplying counties
- Regional differentiation in planting structures and RFUD capabilities

### Telecoupling
#### Systems
- Megacity Beijing as demand core of metropolitan food system
- External vegetable production bases across broader Hebei plateau and plains
- Emerging extended urban regional food systems in North China
#### Flows
- Large scale vegetable flows from external bases to Beijing wholesale markets
- Flows of market information, quality standards, and production orders
- Financial flows via contracts, land transfer rents, and wage payments
#### Agents
- Beijing based agribusinesses operating contract, joint, or self built bases
- Local farmers integrated into distant metropolitan markets
- Regulators coordinating cross jurisdictional food supply policies
#### Causes
- Urbanization driven dietary change and increased per capita vegetable demand
- Metropolitan outsourcing of food production to external bases
- Strategic goal of resilient, secure urban food supply chains
#### Effects
- Transformation of land use and cropping patterns in distant supply areas
- Enhanced but uneven farmer responsiveness to metropolitan market demand
- Creation of interregional green corridors and agri tourism belts

### Cross-Coupling Interactions
- Meta coupling framework links intra household behavior with peri and tele food flows
- Enterprise bases mediate Beijing demand to village level land use responses
- Different base business models reshape local RFUD and regional equity

### Research Gaps or Limitations
- Only single year cross sectional survey data for RFUD analysis
- Limited tracking of product, data, and financial flows across systems
- Indicator system may not fully capture household heterogeneity and temporal dynamics

### Search Keywords
- meta coupling food system Beijing vegetable bases RFUD
- farmland use efficiency DEA Hebei farmers market response
- Beijing Tianjin Hebei external production bases telecoupling

### Extraction Confidence
high
