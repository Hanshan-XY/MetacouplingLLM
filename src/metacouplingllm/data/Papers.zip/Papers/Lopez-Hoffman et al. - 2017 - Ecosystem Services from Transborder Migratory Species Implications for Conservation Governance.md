# Ecosystem Services from Transborder Migratory Species Implications for Conservation Governance

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:56:27.077922+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Lopez-Hoffman et al. - 2017 - Ecosystem Services from Transborder Migratory Species Implications for Conservation Governance.pdf
- Year: unknown
- DOI: 10.1146/annurev-environ-
- OA status: unknown
- License: none recorded
- Category: Journal Articles\Review\Telecoupling
- Closed-access reason: no license info, oa_status=unknown

## Copyright-Safe Summary
This review examines how flying migratory animals that cross national borders - primarily birds, bats, and insects - generate ecosystem services and what this implies for conservation governance. The geographic focus is largely North America, with broader reference to global policy frameworks. The work is explicitly grounded in telecoupling and spatial subsidies, and is a core metacoupling paper.

The authors synthesize ecological, economic, and policy literature rather than presenting new primary data. They adopt the IPBES classification of instrumental values, covering cultural (nonmaterial), regulating, and material (provisioning) services, and briefly note supporting (nonanthropocentric) values. Case material centers on three North American examples: the US Duck Stamp Program for waterfowl, Mexican free-tailed bats, and eastern monarch butterflies.

Biologically, migrants depend on multiple, spatially separated habitats for breeding, wintering, and stopover, making them highly vulnerable to habitat loss, barriers (e.g., buildings, wind farms), climate change, and overexploitation. Data limitations on migration routes, timing, and demography further complicate management. Cross-jurisdictional governance is a central challenge, as different countries and agencies control different life stages and habitats.

The paper documents substantial cultural services (wildlife watching, festivals, hunting traditions), regulating services (pest control, pollination, seed dispersal, scavenging, disease regulation), and material uses (food, pets, specialty products) from migratory species. It also highlights their roles in nutrient transport and ecosystem engineering.

Using the telecoupling framework, migration is framed as a long-distance linkage where sending areas supply habitat that sustains populations, receiving areas enjoy ecosystem service benefits, and spillover regions include migratory corridors and stopovers. Spatial subsidies analysis reveals mismatches between where benefits accrue (often urban or downrange regions) and where critical habitat costs are borne (often rural or foreign areas), as shown for bats and monarchs. The review argues that quantifying these flows can underpin new governance tools, especially international and cross-sector collaborations such as Payments for Ecosystem Services, and can improve design of transboundary migration conservation areas and treaties like CMS and North American migratory bird agreements.

## Structured Metacoupling Extraction

### Coupling Classification
- Strong focus on telecoupling and spatial subsidies among distant habitats and beneficiaries

### Intracoupling
#### Systems
- Within-country habitat networks for migratory birds, bats, insects
- Domestic agricultural landscapes relying on pest control by migrants
#### Flows
- Seasonal movements within national borders between breeding and nonbreeding areas
- Nutrient and seed transfers inside a single country
#### Agents
- National wildlife agencies and conservation NGOs
- Domestic hunters, farmers, ecotourists
#### Causes
- Seasonal resource variation within countries
- National land-use policy and protected area management
#### Effects
- Local biodiversity maintenance and supporting services
- Domestic economic benefits from hunting and wildlife tourism

### Pericoupling
#### Systems
- Neighboring countries sharing flyways and wetlands
- Borderland regions in US-Mexico and US-Canada
#### Flows
- Migratory waterfowl moving across adjacent national borders
- Cross-border bat movements between northern Mexico and southern United States
#### Agents
- Binational treaty organizations and joint commissions
- Borderland landowners and local communities
#### Causes
- Cross-jurisdictional differences in conservation capacity and priorities
- Spatially contiguous habitats fragmented by political borders
#### Effects
- Need for coordinated monitoring and management across borders
- Cost savings and efficiency gains from regional cooperation

### Telecoupling
#### Systems
- Breeding areas in Canada and northern United States
- Overwintering and stopover habitats in Mexico and Central America
- Urban consumer regions far from migration corridors
#### Flows
- Migratory species transporting ecosystem services across continents
- Economic flows via Duck Stamp revenues and ecotourism spending
- Spatial subsidies where conservation in one nation sustains services in another
#### Agents
- Hunters financing habitat via license and stamp purchases
- Farmers benefiting from pest control by bats and birds
- International conventions like CMS and regional bird agreements
#### Causes
- Seasonal migration driven by resource availability and climate
- Governance gaps and policy misalignment among distant countries
- Global demand for recreation, food, and wildlife-related culture
#### Effects
- Remote habitat degradation reduces ecosystem services in faraway regions
- Net service subsidies from rural or tropical areas to urban and northern beneficiaries
- Motivation for Payments for Ecosystem Services and new governance arrangements

### Cross-Coupling Interactions
- Local land-use change in overwintering areas alters benefits in distant breeding regions
- Wind-energy expansion and disease interact to threaten bat-mediated pest control across countries
- Climate-driven phenological shifts disrupt telecoupled services along entire flyways

### Research Gaps or Limitations
- Substantial data gaps on full annual cycles, especially tropical overwintering sites
- Limited quantification of spatial subsidies for most migratory taxa
- Sparse governance mechanisms explicitly using telecoupling information

### Search Keywords
- telecoupling spatial subsidies migratory species ecosystem services
- Duck Stamp Mexican free-tailed bat monarch butterfly governance
- transboundary migration conservation CMS AEWA Payments for Ecosystem Services

### Extraction Confidence
high
