# Why telecoupling research needs to account for environmental justice

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:29:14.518809+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Boillat et al. - 2020 - Why telecoupling research needs to account for environmental justice.pdf
- Year: unknown
- DOI: 10.1080/1747423X.2020.1737257
- OA status: green
- License: none recorded
- Category: Journal Articles\Commentary\Telecoupling
- Closed-access reason: green OA without permissive license (none)

## Copyright-Safe Summary
This commentary paper argues that telecoupling research must systematically incorporate environmental justice thinking to address the normative implications of distant land-use interactions. The paper is conceptual in scope and global in its geographical orientation, drawing illustrative examples from international commodity chains such as South American soy exports to China and Europe. It is situated within land system science and telecoupling frameworks, and mainly synthesizes existing literature in environmental justice, ecological unequal exchange, governance, and decolonial thought rather than presenting new empirical data.

The authors contend that telecoupled flows of goods, resources, and information routinely redistribute environmental burdens and benefits across great distances, typically allowing wealthier actors and regions to externalize costs onto less powerful communities. They propose that environmental justice offers a mature conceptual toolkit for examining these dynamics, emphasizing three interrelated dimensions: distributive justice (who gains and who bears social-ecological harms), procedural justice (who participates in and shapes decisions across linked action situations and supply chains), and recognition justice (whose identities, knowledges, and values are acknowledged or marginalized in problem framings and information flows).

The article highlights how unequal power, colonial legacies, and dominant economic framings structure telecoupled systems and their governance, often excluding those who are most affected from meaningful participation or fair representation. It also outlines potential mechanisms through which injustices in telecoupled land systems can be challenged or transformed, including transnational environmental justice movements, NGO-led alliances, shifts in investor behavior, and transparency initiatives.

This paper is explicitly about telecoupling and metacoupling. Its main contribution is to show how integrating environmental justice perspectives can deepen telecoupling analyses, helping researchers trace responsibilities, understand power-laden information flows, and design more reflexive, co-produced research that supports fairer and more sustainable cross-border land-use relations.

## Structured Metacoupling Extraction

### Coupling Classification
- Conceptual telecoupling paper; focuses on distant social ecological interactions and justice dimensions

### Intracoupling
#### Systems
- Local land systems where commodities are produced
- Local communities facing land use change impacts
#### Flows
- Local ecosystem service changes within production landscapes
- Shifts in local labour practices and land control
#### Agents
- Indigenous peoples and small farmers
- Local elites and authorities
- Local social movements and community organizations
#### Causes
- Commodity driven land use change at production sites
- Inequitable local institutions and tenure rules
- Colonial legacies shaping local governance
#### Effects
- Displacement and livelihood loss
- Exposure to pollution and flooding
- Local environmental degradation and social conflict

### Pericoupling
#### Systems
- Neighbouring agricultural regions replacing displaced crops
- Regional governance arenas around land and resources
#### Flows
- Regional trade in agricultural products
- Diffuse pollution and ecosystem service spillovers
#### Agents
- Regional governments and planning agencies
- Regional agribusiness companies and traders
#### Causes
- Crop displacement within countries due to export demand
- Regional policy incentives for commercial agriculture
#### Effects
- Pollution in nearby farming areas
- Regional inequalities in land access and benefits

### Telecoupling
#### Systems
- Export oriented South American soybean frontiers
- Import dependent regions in China and Europe
- Global financial and governance institutions
#### Flows
- International trade in soy and other global commodities
- Embedded land, water, emissions and ecosystem services
- Information, discourses and capital along supply chains
#### Agents
- Multinational agribusiness and processing firms
- Financial institutions and investors
- International NGOs and transnational advocacy networks
#### Causes
- Global demand for commodities and animal feed
- Ecological unequal exchange and historical core periphery relations
- Power asymmetries enabling burden shifting across borders
#### Effects
- Concentrated environmental burdens in producing regions
- Benefits captured by affluent consumers and corporations
- Cross scale justice conflicts and contested governance

### Cross-Coupling Interactions
- Telecoupled trade drives local and regional land use change and spillover pollution
- Transnational justice movements link distant affected communities and decision arenas
- Information and value framings travel across scales shaping distribution and procedures

### Research Gaps or Limitations
- Most telecoupling studies neglect explicit justice analysis, especially procedural and recognition aspects
- Limited integration of diverse valuation languages and decolonial perspectives in telecoupling research
- Scarce empirical work tracing power, responsibility and accountability along whole supply chains

### Search Keywords
- telecoupling environmental justice unequal exchange
- ecosystem services burdens distant trade
- procedural recognition justice land systems

### Extraction Confidence
high
