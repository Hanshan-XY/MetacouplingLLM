Research, part of a Special Feature on Telecoupling: A New Frontier for Global Sustainability

# Operationalizing the telecoupling framework for migratory species using the spatial subsidies approach to examine ecosystem services provided by Mexican free-tailed bats

Laura López-Hoffman 1,2, Jay Diffendorfer 3, Ruscena Wiederholt 4, Kenneth J. Bagstad 3, Wayne E. Thogmartin 5, Gary McCracken 6, Rodrigo L. Medellin 7, Amy Russell 8 and Darius J. Semmens 3

ABSTRACT. Drivers of environmental change in one location can have profound effects on ecosystem services and human well-being in distant locations, often across international borders. The telecoupling provides a conceptual framework for describing these interactions—for example, locations can be defined as sending areas (sources of flows of ecosystem services, energy, or information) or receiving areas (recipients of flows). However, the ability to quantify feedbacks between ecosystem change in one area and societal benefits in other areas requires analytical approaches. We use spatial subsidies—an approach developed to measure the degree to which a migratory species’ ability to provide services in one location depends on habitat in another location—as an example of how telecoupling can be operationalized. Using the cotton pest control and ecotourism services of Mexican free-tailed bats as an example, we determined that of the 16 states in the United States and Mexico where the species resides, three states (Texas, New Mexico, and Colorado) are receiving areas, while the rest of the states are sending areas. In addition, the magnitude of spatial subsidy can be used as an indicator of the degree to which different locations are telecoupled to other locations. In this example, the Mexican free-tailed bat ecosystem services to cotton production and ecotourism in Texas and New Mexico are heavily dependent on winter habitat in four states in central and southern Mexico. In sum, spatial subsidies can be used to operationalize the telecoupling conceptual framework by identifying sending and receiving areas, and by indicating the degree to which locations are telecoupled to other locations.

Key Words: ecosystem services; Mexican free-tailed bats; pest control; spatial subsidies; telecoupled natural–human systems; telecoupling; transborder conservation

# INTRODUCTION

Within complex, coupled natural–human systems, the drivers of environmental change in one location can have profound effects on ecosystem services and human well-being in distant locations, often across international borders (López-Hoffman et al. 2009, 2010). International trade and information networks move vast quantities of matter, energy, and information that underpin global to local exchange of ecosystem services (Kissinger and Rees 2010, Kastner et al. 2011, 2014). Oceanic, atmospheric, and hydrological flows are further long-distance/international transporters of ecosystem services (Bagstad and Wiederholt 2013). The phenomena of long-distance cause–effect interactions in social-ecological systems (Brauman et al. 2007, DeFries et al. 2010, Kissinger and Rees 2010, Lenzen et al. 2012) is well recognized. Nonetheless, most studies to date have treated distal forces as exogenous variables, and have rarely considered the feedbacks between ecological processes in one location and ecosystem services and human well-being in other locations (Kissinger et al. 2011, Liu et al. 2013, 2016). The conceptual framework of telecoupling developed by Liu and colleagues (Liu et al. 2013, 2016) provides a way of articulating important features of long-distance interactions in social-ecological systems such as sending areas (sources of flows of ecosystem services, energy, or information), receiving areas (recipients of flows), or spillover areas (locations affecting and/or affected by interactions between sending and receiving systems). However, to fully develop and extend this conceptual framework requires the ability to identify and quantify telecouplings. To overcome this hurdle, we present

operational tools to measure the flow and value of telecoupled ecosystem service benefits specifically related to the provision of ecosystem services by migratory species.

Migratory species move regularly between habitats to take advantage of seasonal resources. In North America, many bird and bat species spend the summer in breeding grounds in the northern latitudes of Canada and the United States and migrate south to the southern United States, Mexico, and Central America to spend the winter (López-Hoffman et al. 2017). As they move between habitats, these migratory species support ecosystem functions in multiple areas, thereby creating ecological “mobile links” between their distant habitats (Gilbert 1980, Lundberg and Moberg 2003). Further, as these animals travel, they often provide benefits to people, such as controlling crop pests, pollinating food plants, or supporting recreational hunting and viewing activities (Kunz et al. 2011, Wenny et al. 2011). Because the population viability of a migratory species depends on habitat in different locations, it follows that the ecosystem services provided by the species in one location depend upon habitat and ecological processes provided in other locations. This dependency creates a telecoupling such that impacts on the habitat of a migratory species in one location will affect the ecosystem services enjoyed by people in other locations (Hulina et al. 2017).

The spatial subsidies approach (Semmens et al. 2011, López-Hoffman et al. 2013) assesses the degree to which ecosystem service provision in one location depends on a migratory species’ habitat in other locations. The approach is called “spatial

subsidies” because species often provide more ecosystem service benefits in certain parts of their range than in others, while habitats in other parts of the range are often more critical to a species’ population viability. In such situations, people in areas where the species provides the most ecosystem service benefits may in effect be “subsidized” by the habitat conservation efforts of people in the areas of most critical habitat (Semmens et al. 2011, López-Hoffman et al. 2013). The spatial subsidies approach operationalizes the telecoupling framework by identifying areas that are sending and receiving subsidies of ecosystem services.

We provide an example of how the telecoupling framework can be operationalized by presenting spatial subsidy calculations for the Mexican free-tailed bat (Tadarida brasiliensis mexicana). Both male and female bats winter in southern Mexico, and in the summer, females travel to roosts in the southwestern United States and northern Mexico to birth their pups. The species is insectivorous and preys on bollworms (Helicoverpa zea), the most common and damaging pest to cotton production in Texas and across the southwestern United States (Cleveland et al. 2006, Federico et al. 2008). By reducing crop damage from bollworms, Mexican free-tailed bats provide an economic benefit to agricultural producers. We have estimated that the bats provided an annual average of US$12.4 million in pest control services in cotton fields across the U.S. southwest from 1990 to 2008 (López-Hoffman et al. 2014). In addition, the viewing of the bats’ evening emergences from their roosts has become a highly popular activity for more than 240,000 people per year, which generates more than US$6.5 million per year in economic benefits (Bagstad and Wiederholt 2013).

The spatial subsidy estimates we present indicate which states in the United States and Mexico either send subsidies to, or receive subsidies from, other states. The estimates also suggest the degree to which different portions of the Mexican free-tailed bat range subsidize ecosystem services in other locations, and as such the degree to which different locations are telecoupled to other locations. Nonetheless, our goal is not to promote these estimates as precise monetary figures. Rather, we aim to provide operational tools to measure the flow and value of telecoupled ecosystem service benefits.

# METHODS

The purpose of the spatial subsidies approach is to identify the locations that (a) send subsidies by contributing to the overall viability of migratory species that in turn provide services to humans throughout their entire range, and (b) receive subsidies in the form of services provided locally by migratory populations that are dependent upon habitat elsewhere. Two types of information are required to estimate spatial subsidies: the first is information about the quantity of ecosystem services provided by a migratory species and the locations where people most benefit from those services; the second is information about the proportional dependence of the migratory species’ population viability on different portions of its range. In this section, we first review the equation to calculate spatial subsidies, then detail the data we used to parameterize the quantity and location of Mexican free-tailed bat ecosystem services, and finally we explain the approach we used to estimate proportional dependence.

# Spatial subsidies calculation

The determination of whether a given location is sending or receiving a subsidy depends on the balance between the services received from other locations and the habitat support the area provides to the species (Semmens et al. 2011). For a single species, the net difference between sent contribution and received benefit is the spatial subsidy for location $A \ ( Y _ { A } )$ :

$$
Y _ {A} = V _ {S} \times D _ {S A} - V _ {S A} \tag {1}
$$

where $V _ { s }$ is the total value of migratory services provided by a species $S$ throughout its range, $V _ { S A }$ is the value of services provided by species $S$ at location $A$ , and $D _ { S A }$ is the proportional dependence of the species’ population on location A. $D _ { S A }$ for a given location cannot be greater than one, and the total of all $D _ { s }$ values must sum to one across all locations. The latter unit-sum constraint assumes migratory species are dependent upon favorable habitat across their entire range; they cannot be more or less than $100 \%$ dependent upon their environment.

The values calculated in Eq. 1 are based on the recurring, annual value of services provided by the migratory species. The first term, $V _ { S } \mathrm { \bf X } D _ { S A }$ represents how much a particular location contributes to the overall ecosystem service value. Subtracting the last term, $V _ { S A }$ , from the equation yields the net subsidy. Positive values indicate location $A$ is sending subsidies to other areas. Negative values indicate location $A$ is receiving subsidies from other areas. When applied to all sending and receiving locations throughout a species’ range, Eq. 1 satisfies the requirement that the rangewide sum of all subsidies is zero.

# Parameterizing ecosystem service values

We used our previous work to value the cotton pest control services (López-Hoffman et al. 2014) and ecotourism services (Bagstad et al. 2013) of Mexican free-tailed bats to parameterize our estimates of the quantity and location of the ecosystem services provided by this species. Values are expressed in 2011 U. S. dollars. We briefly summarize the methods of the previous valuation studies and the results.

# Parameterizing bat pest control

We parameterized $V _ { S A }$ values for pest control using data from López-Hoffman et al. (2014), an avoided-cost assessment of the value of reduced crop damage and reduced insecticide use resulting from the foraging of Mexican free-tailed bats on bollworm pests. This approach consisted of (a) estimating the number of insect pests preyed upon nightly by individual bats, (b) determining the hectares of cotton fields within a given distance of known bat roosts, and then (c) estimating the value of the crops that would have been damaged in the absence of bats (Cleveland et al. 2006, Wiederholt et al. 2015).

Cleveland et al. (2006) first applied an avoided-cost approach to valuing Mexican free-tailed bat pest control services to cotton in the eight-county Texas Winter Garden region. In López-Hoffman et al. (2014), we refined the approach and expanded the geographic extent of analysis. The refinements consisted of (a) estimating both the reduced private costs (i.e., to farmers) and the reduced public (i.e., societal) costs of insecticides released into the environment; (b) considering how the adoption and expansion of transgenic Bacillus thuringiensis (Bt) cotton, starting in 1996, subsequently affected service values; (c) using improved estimates

Table 1. Spatial subsidy calculations for the Mexican free-tailed bats summed by state. Note that several states have more than one bat breeding roost. Currency is expressed in 2011 U.S. dollars.   

<table><tr><td>Country</td><td>State</td><td>Season</td><td>\( V_{s}^{\dagger } cotton \)</td><td>\( V_{s} \) viewing</td><td>\( V_{s} \) total</td><td>\( D_{s}^{\ddagger} \)</td><td>Total subsidy</td></tr><tr><td>U.S.</td><td>Arizona</td><td>Summer</td><td>5,000</td><td>9,000</td><td>14,000</td><td>0.0060</td><td>103,166</td></tr><tr><td>U.S.</td><td>California</td><td>Summer</td><td>56,000</td><td>58,000</td><td>114,000</td><td>0.0063</td><td>7,614</td></tr><tr><td>U.S.</td><td>Colorado</td><td>Summer</td><td>0</td><td>83,000</td><td>83,000</td><td>0.0020</td><td>-44,131</td></tr><tr><td>U.S.</td><td>New Mexico</td><td>Summer</td><td>28,000</td><td>3,477,000</td><td>3,505,000</td><td>0.0069</td><td>-3,371,658</td></tr><tr><td>U.S.</td><td>Oklahoma</td><td>Summer</td><td>497,000</td><td>30,000</td><td>527,000</td><td>0.0341</td><td>133,193</td></tr><tr><td>U.S.</td><td>Texas</td><td>Summer</td><td>11,652,000</td><td>2,840,000</td><td>14,492,000</td><td>0.2927</td><td>-8,821,430</td></tr><tr><td>Mexico</td><td>Coahuila</td><td>Summer</td><td>222,000</td><td>0</td><td>222,000</td><td>0.0380</td><td>514,120</td></tr><tr><td>Mexico</td><td>Nuevo Leon</td><td>Summer</td><td>0</td><td>0</td><td>0</td><td>0.0498</td><td>965,244</td></tr><tr><td>Mexico</td><td>Sinaloa</td><td>Summer</td><td>36,000</td><td>0</td><td>36,000</td><td>0.0020</td><td>2,873</td></tr><tr><td>Mexico</td><td>Sonora</td><td>Summer</td><td>0</td><td>0</td><td>0</td><td>0.0418</td><td>810,750</td></tr><tr><td>Mexico</td><td>Tamaulipas</td><td>Summer</td><td>382,000</td><td>0</td><td>382,000</td><td>0.0204</td><td>12,759</td></tr><tr><td>Mexico</td><td>Chiapas</td><td>Winter</td><td>0</td><td>0</td><td>0</td><td>0.0900</td><td>1,744,148</td></tr><tr><td>Mexico</td><td>Hildago</td><td>Winter</td><td>0</td><td>0</td><td>0</td><td>0.0900</td><td>1,743,535</td></tr><tr><td>Mexico</td><td>Michoacan &amp; Jalisco</td><td>Winter</td><td>0</td><td>0</td><td>0</td><td>0.1876</td><td>3,633,797</td></tr><tr><td>Mexico</td><td>Queretaro</td><td>Winter</td><td>0</td><td>0</td><td>0</td><td>0.1324</td><td>2,566,021</td></tr><tr><td>Totals</td><td></td><td></td><td>12,878,000</td><td>6,497,000</td><td>19,375,000</td><td>1.0000</td><td>0</td></tr></table>

$^ { \dag } { \cal V } _ { s }$ is the total value of migratory services provided by a species S throughout its range.   
$^ { \ddag } D _ { s } ^ { ' }$ is proportional dependence.

of societal costs by considering only insecticides specifically targeted to cotton bollworms (Leach and Mumford 2008); and (d) expanding the analysis of pest control values to all cottonproducing areas within $5 0 ~ \mathrm { k m }$ of major bat roosts across the southwestern United States and northern Mexico rather than just the Texas Winter Garden region.

We used the annual estimates of pest control values from 1990 to 2008 in López-Hoffman et al. (2014) to determine a mean annual value over that time period for each state where Mexican freetailed bats are located. Pest control values were spatially variable, which reflected county-level differences in bat population size, area of cotton planted, type of cotton, and year of adoption of Bt cotton (see López-Hoffman et al. 2014 for further explanation). Estimates of the mean county-level ecosystem service value varied widely from $\$ 0.01$ to $\$ 8.06$ per hectare; the highest values $( > \$ 2.60$ per hectare) were all found in Texas (Table 1).

# Parameterizing bat ecotourism

We parameterized $V _ { S A }$ values for ecotourism using data about consumer surplus from Bagstad and Wiederholt (2013), a study of visitation rates and consumer surplus for recreational visitors to viewing sites for the Mexican free-tailed bat throughout the southwestern United States. Consumer surplus is the difference between the maximum price a consumer is willing to pay for something and the actual price they do pay, which is a measure of the net benefits received by the consumer. Recreational viewing of Mexican free-tailed bats occurs in six states in the United States. The most significant economic benefits from bat viewing occur in New Mexico (at Carlsbad Caverns National Park), which generates more than US$3.5 million per year in economic benefits, followed by Texas (primarily at the Congress Avenue Bridge in Austin and Bracken Cave near San Antonio), with about US$2.8 million per year in benefits (Table 1). Although bat viewing occurs at some sites in Mexico, visitation data for those sites either do not exist or were not obtainable for this study (Rodrigo Medellín, personal observation).

# Estimating proportional dependence

To estimate $D _ { S A }$ , the proportional dependence of Mexican freetailed bats on different roosts and habitat regions, we used a network model for the species that was developed by Wiederholt et al. (2013). The model simulates bat migration between four winter regions in southern Mexico and 25 major summer breeding roosts in northern Mexico and the southwestern United States, with each site receiving individuals from several locations (Fig. 1). Expected migratory routes are determined based on distancebased formulations of migration costs. The approach allows us to simulate changes in migratory population size associated with the loss of any particular habitat region or roost (Wiederholt et al. 2013, 2015).

To determine the proportional dependence on each habitat area, we simulated a habitat removal experiment—removing each habitat (i.e., each summer roost and winter region) with replacement from the network model. In line with other analyses of migratory populations (Taylor and Norris 2010, Rayfield et al. 2011), we quantified the impact of each area’s removal on the total summer population size. When removing a given summer roost or winter region from the model, the individuals contained in that location were allowed to migrate to other areas. This approach was used by Wiederholt et al. (2015) to determine the relative importance of the various breeding roosts for conservation activities.

We rescaled the results of the habitat removal experiment to apportion $50 \%$ of the proportional habitat dependency, $D _ { s } ,$ to the winter habitats, and $50 \%$ to the summer breeding habitats. This was necessary to reflect the fact that each habitat type is equally important for population viability. Winter sites are critical because that is where mating occurs and where most males reside year-round, whereas summer sites are critical for the birthing and rearing of juveniles.

![](images/debfb14330a46ea35a47aaf90425477338bf36addc1c365b8c04af892a24b71a.jpg)  
Fig. 1. Summer breeding roost sites (dots 1–25) and wintering regions (dots 26–29) for the Mexican free-tailed bat (Tadarida brasiliensis mexicana). Line colors represent the total number of migrant bats. If a summer site was connected to more than one route, the circle representing the summer site was filled and outlined with the colors of the two different routes (from Wiederholt et al. [2013]).

# SUMMER ROOSTS

1 Eagle Creek Cave,AZ   
2Cosumnes River Preserve,CA   
3Yolo Bypass Bridge, CA   
4Orient Mine,CO   
5Carlsbad Caverns,NM   
6Merrihew Cave,OK  
7Read Cave,OK   
8Vickery Cave,OK   
9Bracken Cave,TX   
10 Congress Bridge,TX   
11 Davis Cave,TX   
12 Devils Sink Hole,TX

13 Eckert James River Cave,TX   
14 Fern Cave,TX   
15 Frio Cave,TX   
16 McNeil Bridge,TX   
17 Ney Cave,TX   
18 Stuart Bat Cave,TX   
19 Waugh Bridge,TX   
20 Cuatrociénegas de Carranza,Coahuila   
21Cueva de Consuelo, Coahuila   
22 Cueva La Boca, Nuevo Leon   
23 Maviri, Sinaloa   
24 Cueva del Tigre,Sonora   
25Presa de Amistad,Tamaulipas

# WINTER SUBREGIONS

26 Chiapas   
27 Hidalgo   
28 Michoacan & Jalisco   
29 Queretaro

# RESULTS

# Proportional dependence

# Habitat removal

The total decline in summer population ranged from 1.1 to 2.3 million individuals or approximately $5- 1 0 \%$ of the population depending on which location was removed from the network (Fig. 2). All the most important sites for maintaining the bat population are among the southernmost sites (Fig. 2). Removal of these large southern breeding roosts caused the bats to migrate farther distances, which in the model increased energetic costs and reduced the probability of survival during migration (Wiederholt et al. 2013).

# Proportional dependence estimates

Table 1 shows the rescaled proportional dependency values, D , $D _ { s } ,$ from the habitat removal exercise (Fig. 2) such that $50 \%$ of $D _ { s }$ was apportioned to the winter habitat and $50 \%$ to the summer breeding habitat. The habitat with the highest $D _ { s }$ values was located in Texas $( D _ { s } = 0 . 2 9$ , summer habitat), followed by habitat in the Mexican states of Michoacán and Jalisco ${ \cal D } _ { s } ^ { \phantom { - } } = 0 . 1 9$ , winter habitat).

# Spatial subsidies

Texas, New Mexico, and Colorado had negative spatial subsidy values, which indicates that these states are receiving subsidies from other locations. Therefore, these states are receiving the benefits of bat habitat in other locations (Table 1). The other 12

![](images/ffb7dbd2678de6840299cbdaef76d69864cacebf4d948b591a9a2d9217851818.jpg)  
Fig. 2. Results of the habitat removal experiment. Changes in summer population size with eliminated habitat (each breeding roost site and winter region) are expressed as the proportional difference from the baseline summer population size (i.e., the summer population with no removals).   
Deviation from baseline summer population size

U.S. and Mexican states had positive spatial subsidy values, which indicates that they are sending subsidies to other locations. To use the language of the telecoupling framework (Liu et al. 2013), Texas, New Mexico, and Colorado are receiving locations in the telecoupled natural–human system of Mexican free-tailed bats and their ecotourism and cotton pest control services, while the other states are sending locations.

Of the three receiving locations (locations with calculated negative spatial subsidy values), Texas and New Mexico had the most negative values, approximately -US$8.8 million and -US$3.4 million, respectively. In contrast, Colorado, another receiving region, had a less negative subsidy value (approximately - US$44,000). The sending locations with the greatest positive subsidy values were, in descending order, the Mexican states of Michoacán and Jalisco (US$3.6 million combined), Queretaro (US$2.6 million), and Chiapas and Hidalgo (US$1.7 million each). The Mexican state of Sinaloa had the lowest positive subsidy value of any sending location, at approximately US$3000.

# DISCUSSION

# Operationalizing the telecoupling framework

We used spatial subsidies to operationalize key concepts from the telecoupling framework (Liu et al. 2013) by identifying locations that receive and send flows of ecosystem services. In our analysis of telecoupling for the Mexican free-tailed bat, three states— Texas, New Mexico, and Colorado—have negative spatial subsidy values, and as such are receiving areas. All the other U.S and Mexican states have positive subsidy values, and therefore are sending areas.

Spatial subsidies can also extend the analysis of telecoupled systems by evaluating the degree to which different locations are coupled to other locations. The magnitude of a negative spatial subsidy value can be interpreted to indicate the degree to which a location depends upon habitat in other locations for the provision of ecosystem services locally. Of the three locations with negative subsidy values, Texas and New Mexico had the most negative values. On the other hand, the magnitude of a positive subsidy value can indicate whether a location enables the provisioning of ecosystem services in other locations by providing critical habitat for migratory species. In this case, we see a pattern of the benefits from Mexican free-tailed bat ecosystem services to cotton production and ecotourism in Texas and New Mexico being heavily dependent on winter habitat in four states in central and southern Mexico.

# Important caveats to the subsidy calculations presented

There are a number of important caveats to consider. First, the spatial subsidy estimates are a static snapshot of a dynamic system. Ecosystem service values can change over time due to both ecological and socioeconomic factors (Eigenbrod et al. 2009, 2011, Koch et al. 2009, Burkhard et al. 2011, Barbier 2012, Johnson et al. 2012, Lautenbach et al. 2012, Yuan et al. 2012, López-Hoffman et al. 2014). For example, in our previous work, we have shown that the value of bat pest control services in cotton was largely influenced by temporal changes in cotton commodity price, impacts of demand and price changes on the number of hectares planted with cotton, and the technological substitution of Bt transgenic cotton for non-Bt cotton (López-Hoffman et al. 2014).

Second, the spatial subsidy calculations do not fully account for all the ways that Mexican free-tailed bats may be providing benefits to society. Critics have long pointed out that it is impossible to identify and measure, let alone value, all the ways functioning ecosystems provide benefits to society (Spash 2008, Peterson et al. 2010, Muradian and Rival 2012). It is important to note that in the present analysis, we used two types of ecosystem services—pest control services to cotton, and ecotourism—that happen to be most commonly enjoyed in the United States. However, Mexican free-tailed bats are generalist predators (Lee and McCracken 2005, McCracken et al. 2012) and likely provide significant pest control services to other crops, in particular corn and tomatoes. Unlike cotton, corn and tomato production is common in Mexico. At present, there are insufficient data to assess the species’ pest control services to these crops, as well as any other regulating and cultural services provided by bats. Nonetheless, had the necessary data been available to assess additional ecosystem service values, the spatial subsidy calculations might have been very different: locations in Mexico might have been sending less subsidy to the United States, or perhaps might have been receiving locations.

Finally, our analysis does not consider the three types of uncertainty in our calculations: observation (measurement) error, parametric uncertainty, and external stochasticity (environmental and demographic stochasticity). In future work, we will employ several techniques to address these types of uncertainty, including using parameter ranges for maximum and minimum estimates of service values and proportional dependencies to generate confidence intervals, and varying input parameters such as bat survival and mortality to identify the system’s sensitivity to key factors.

Applications of spatial subsidies to the governance of telecoupled natural–human systems

Our results emphasize the necessity of coordinated binational conservation efforts for maintaining habitat across the Mexican free-tailed bat’s range, as well as efforts to protect critical habitat areas in the United States and Mexico. Results from the spatial subsidies approach could be used to more effectively target conservation funding to priority areas. In addition, they could be used as an argument for long-term population-level monitoring, as bats may switch roosts over time, and the population’s viability depends on habitat in both countries (Glass 1982, Genoways et al. 2000, McCracken 2003). North America lacks a formal treaty that protects migratory bats. However, data such as ours that elucidate the cross-border connections between people and locations that receive benefits in one country and those that provide benefits in another country might prove useful for the establishment of such an agreement. Despite the lack of a formal treaty, other North American conservation agreements do exist, such as the Program for the Conservation of Migratory Bats (between the United States and Mexico) and the North American Bat Conservation Partnership (among Canada, the United States, and Mexico) (Keeley et al. 2003, Medellin 2003).

The notion that distant locations in telecoupled systems may be critical to enabling people to benefit from ecosystem services locally addresses a central goal of political ecology: to reveal winners and losers and hidden costs in environmental outcomes (Robbins 2011). In our study, we see a pattern of the benefits from

Mexican free-tailed bat ecosystem services in the southwestern United States being largely subsidized by overwintering habitat in central and southern Mexico. In other words, the costs of enabling bat ecosystem services in the southwestern United States are born by habitat and the habitat conservation efforts of people in central and southern Mexico. Elsewhere, we have suggested that the spatial subsidies concept could be used to structure crossjurisdictional payments for ecosystem services (PES) programs (Semmens et al. 2011, López-Hoffman et al. 2013). For example, our results could be used to argue for U.S. agricultural payment programs to support landowners in Mexico for bat habitat conservation efforts. However, the wise implementation of new ideas such as PES that arise from the ecological and natural resources sciences requires caution and prudence.

# CONCLUSIONS

The goal of the telecoupling conceptual framework is to stimulate research that elucidates, measures, and ultimately enables society to govern long-distance cause-effect relationships in socialecological systems. However, to fully implement the conceptual framework requires the ability to quantify the degree of telecoupling between locations. We have used spatial subsidies, which measure the degree to which a migratory species’ ability to provide services in one location depends on habitat in another location, as an example of how the telecoupling framework can be operationalized. The spatial subsidies approach identifies sending and receiving areas and indicates the degree to which different locations are telecoupled to one another. We thus present a first step toward identifying and quantifying telecoupled interactions that arise from migratory species and the ecosystem services that they provide to their human beneficiaries.

Responses to this article can be read online at: http://www.ecologyandsociety.org/issues/responses. php/9589

