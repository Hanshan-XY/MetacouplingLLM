# Effects of global shocks on the evolution of an interconnected world

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:10:06.569388+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Vina and Liu - 2023 - Effects of global shocks on the evolution of an interconnected world.pdf
- Year: unknown
- DOI: 10.1007/s13280-022-01778-0
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Commentary\Metacoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This perspective paper examines how major global shocks reshape an increasingly interconnected world, using the metacoupling framework as the main analytical lens. Metacoupling distinguishes interactions within a system (intracoupling), between neighboring systems (pericoupling), and among distant systems (telecoupling), and tracks flows of people, goods, energy, information, and capital along with their spillover effects.

Geographically, the paper is global in scope. It uses historical examples from all world regions and more detailed export data for major regions and selected countries. The authors rely primarily on secondary data and prior syntheses, including long-term statistics on merchandise exports relative to GDP and region-to-region trade flows, to infer shifts in intra-, peri-, and telecouplings over the 20th and early 21st centuries.

The analysis links major periods of increased and decreased global trade to shocks such as the two World Wars, the Great Depression, the 1979 energy crisis, the Great Recession, and most recently the COVID-19 pandemic. Shocks typically weaken pericoupling and telecoupling (trade, tourism, migration), while strengthening intracoupling through greater reliance on local or regional production. As shocks subside, global systems recouple, but often with altered patterns of dependence and vulnerability. The paper highlights that these dynamics are regionally heterogeneous; for example, Africa and Latin America show different balances of intra-, peri-, and telecoupling than Western Europe or North America.

A substantial section focuses on COVID-19 as an ongoing global shock. It documents how the pandemic disrupted international supply chains, tourism, and food trade, while temporarily improving some environmental indicators and encouraging local supply chains and changes in consumption. The authors argue that COVID-19 fits within a longer history of coupling-decoupling-recoupling cycles, and that its long-term impacts will depend on policy and societal choices.

The article is explicitly about metacoupling/telecoupling. It uses the framework to interpret past and present shocks and proposes actions for more sustainable recoupling, including better mapping of flows, internalizing spillover costs, balancing local and distant sourcing, and embedding metacoupling concepts in governance and education.

## Structured Metacoupling Extraction

### Coupling Classification
- Conceptual and empirical analysis of intra, peri, and telecoupling under historical and COVID-19 global shocks.

### Intracoupling
#### Systems
- National and regional coupled human nature systems such as Asia, Western Europe, North America.
- Local food production and domestic supply chains within single countries or regions.
- Urban and rural communities adjusting behavior during wars, recessions, and pandemics.
#### Flows
- Domestic production and consumption of food, goods, and services.
- Local information exchange, risk perception, and governance decisions.
- Internal migration such as urban suburban or urban rural shifts during COVID-19.
#### Agents
- Households, consumers, and local producers shaping domestic demand and supply.
- National governments designing internal restrictions, stimulus, conservation policies.
- Local businesses, farmers, and service providers adapting to disrupted trade.
#### Causes
- Local shocks like droughts, floods, and domestic economic crises.
- National policy responses to wars, recessions, and health emergencies.
- Changing consumption preferences toward local products and shorter chains.
#### Effects
- Increased reliance on local resources during disrupted global trade.
- Short term environmental improvements such as better local air and water quality.
- Potential long term underfunding of conservation and pressure on wildlife use.

### Pericoupling
#### Systems
- Neighboring world regions such as North America Latin America, Oceania Asia.
- Bordering countries with strong regional trade and migration links.
- Regional economic blocs and shared ecosystems crossing national borders.
#### Flows
- Regional trade in commodities, including food and manufactured goods.
- Tourism, labor migration, and cross border commuting.
- Shared environmental management and cross border conservation initiatives.
#### Agents
- Regional organizations and trade blocs coordinating policies.
- Exporters and importers operating mainly within neighboring markets.
- Border communities engaged in cross border commerce and work.
#### Causes
- Cost advantages of sourcing from geographically closer suppliers.
- Global shocks weakening long distance trade and redirecting flows regionally.
- Trade liberalization within regions and regional trade agreements.
#### Effects
- Regional reorientation of exports after global crises or recessions.
- Shifts in biodiversity pressures as sourcing moves among neighboring regions.
- Altered vulnerability where regions depend heavily on nearby partners.

### Telecoupling
#### Systems
- Distant regions such as Western Europe North America, Latin America Asia.
- Sending, receiving, and spillover countries linked by global supply chains.
- Remote ecosystems affected by consumer demand in faraway markets.
#### Flows
- Long distance trade of merchandise, especially agricultural commodities and high value goods.
- International tourism, migration, and financial capital movements.
- Global information flows through digital networks and media.
#### Agents
- Multinational corporations managing fragmented global production networks.
- International institutions like WTO, World Bank, UN, WHO.
- Consumers in wealthy countries driving distant environmental and social impacts.
#### Causes
- Technological advances in transport and telecommunications lowering distance costs.
- Trade liberalization, e commerce expansion, and global demand growth.
- Wars, pandemics, and recessions altering but not eliminating long distance links.
#### Effects
- Cascading economic, social, and environmental impacts across distant systems.
- Biodiversity loss in exporting regions supplying global markets.
- Rapid global spread of diseases like COVID 19 along travel and trade networks.

### Cross-Coupling Interactions
- Global shocks shift dominance among intra, peri, telecoupling, altering vulnerability and recovery trajectories.
- Policies targeting one coupling type often create spillover effects on others and on third party systems.
- Balancing local production with regional and global trade crucial for resilience and sustainability.

### Research Gaps or Limitations
- Incomplete long term data for some countries and periods limit precise coupling quantification.
- Heterogeneous regional responses complicate generalized predictions about coupling dynamics.
- Long term consequences of COVID 19 recoupling patterns remain uncertain.

### Search Keywords
- metacoupling global shocks COVID 19 war recession telecoupling
- intracoupling pericoupling trade tourism migration supply chains
- coupled human natural systems sustainability spillover systems

### Extraction Confidence
high
