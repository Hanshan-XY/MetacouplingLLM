# Check for updates

# OPEN ACCESS

EDITED BY

Albie F. Miles,

University of Hawaii–West Oahu,

United States

REVIEWED BY

Nicholas R. Magliocca,

University of Alabama, United States

*CORRESPONDENCE

Jianguo Liu

liuji@msu.edu

RECEIVED 22 August 2025

ACCEPTED 31 October 2025

PUBLISHED 08 December 2025

CITATION

Liu J, Winkler JA, Ross RB, Viña A, Frank KA, Konar M, Liang C-l, Marshall MI, Nichols S, Robinson JM, Varshney LR, Whipple JM, Wu F, Beverly B, Knipe D, Knipe R, Kraus J,

Naik S and Ripmaster C (2025) Building sustainable and resilient agri-food systems under multiple shocks.

Front. Sustain. Food Syst. 9:1690853.

doi: 10.3389/fsufs.2025.1690853

COPYRIGHT

$\circledcirc$ 2025 Liu, Winkler, Ross, Viña, Frank, Konar, Liang, Marshall, Nichols, Robinson, Varshney,

Whipple, Wu, Beverly, Knipe, Knipe, Kraus, Naik and Ripmaster. This is an open-access article distributed under the terms of the Creative Commons Attribution License

(CC BY). The use, distribution or reproduction in other forums is permitted, provided the original author(s) and the copyright owner(s) are credited and that the original publication in this journal is cited, in accordance with accepted academic practice. No use, distribution or reproduction is permitted which does not comply with these terms.

# Building sustainable and resilient agri-food systems under multiple shocks

Jianguo Liu1 *, Julie A. Winkler2 , R. Brent Ross3 , Andrés Viña1 , Kenneth A. Frank4 , Megan Konar5 , Chyi-lyi Liang6 ,

Maria I. Marshall7 , Sue Nichols1 , Jennifer Meta Robinson8 ,

Lav R. Varshney9,10, Judith M. Whipple11, Felicia Wu3,12,

Bryan Beverly13, Darlene Knipe14, Richard Knipe14, John Kraus15, Sai Naik16 and Colin Ripmaster17

1 Center for Systems Integration and Sustainability, Department of Fisheries and Wildlife, Michigan State University, East Lansing, MI, United States, 2Department of Geography, Environment, and Spatial Sciences, Michigan State University, East Lansing, MI, United States, 3Department of Agricultural,

Food, and Resource Economics, Michigan State University, East Lansing, MI, United States,

4Department of Counseling, Educational Psychology, and Special Education, Michigan State University, East Lansing, MI, United States, 5Civil and Environmental Engineering Department, The Grainger College of Engineering, University of Illinois at Urbana-Champaign, Champaign, IL,

United States, 6Department of Agribusiness, Economics and AgriScience, North Carolina Agricultural and Technical State University, Greensboro, NC, United States, 7 Department of Agricultural Economics, Purdue University, West Lafayette, IN, United States, 8Department of Anthropology,

Indiana University, Bloomington, IN, United States, 9Department of Electrical & Computer

Engineering, University of Illinois at Urbana-Champaign, Champaign, IL, United States, 10AI Innovation Institute, Stony Brook University, Stony Brook, NY, United States, 11Department of Supply Chain Management, Michigan State University, East Lansing, MI, United States, 12Department of Food Science and Human Nutrition, Michigan State University, East Lansing, MI, United States, 13Office of K-12 Outreach, Michigan State University, East Lansing, MI, United States, 14Global Food and Ag Network, LLC, Davenport, IA, United States, 15Mavin Project, Grand Rapids, MI, United States, 16Mavin Global Company, Grand Rapids, MI, United States, 17Michigan Association of Secondary School

Principals, Lansing, MI, United States

Shocks, such as disease outbreaks, extreme weather events, cyberattacks, financial crises, and wars, are occurring with greater frequency. When these shocks occur simultaneously and/or in sequence, referred to here as multiple shocks, they can generate compound impacts on agri-food systems and contribute to food and nutrition insecurity. Building sustainable agri-food systems that are resilient to multiple shocks requires an integrated understanding of the threats posed by multiple shocks to all aspects of supply chain networks. Collective action by researchers, educators, extension experts, and other stakeholders can mitigate and improve adaptation to these impacts. However, there are major knowledge gaps in examining, understanding, and synthesizing agri-food systems under multiple shocks. Previous actions have been fragmented, as efforts have largely focused only on an individual shock, in a specific place, and with separate rather than integrated efforts in research, education, and extension. Here, we present an integrated framework to address multiple shocks toward enhancing agri-food system resilience and sustainability. We illustrate how this integrated framework can be  operationalized, focusing on assessing impacts, identifying mitigation strategies, providing decision support, training a future agri-food system workforce, and building communities for resilience to multiple shocks. Finally, we discuss challenges and opportunities in applying the framework for enhancing agri-food system resilience and sustainability worldwide, thus contributing to the realization of several United Nations Sustainable Development Goals, particularly SDG 2 (Zero Hunger).

KEYWORDS

food security, metacoupling framework, SDGs, supply chains, transdisciplinary

# 1 Introduction

Shocks are sudden and impactful events. Recent shocks (e.g., Ukraine war, COVID-19, extreme weather events) have revealed critical vulnerabilities in agri-food systems (Lim-Camacho et al., 2017; Lougee, 2020; Chai et  al., 2024). For instance, spring freezes and windstorms present challenges for fresh and perishable foods, while heat waves may harm the health and well-being of agricultural laborers. Such extreme events are anticipated to increase in frequency and intensity (Fischer et al., 2013). Other shocks also affect many parts of agri-food systems (Davis et al., 2021), resulting in supply reductions of key commodities and increasing the vulnerability of agri-food systems (Aday and Aday, 2020). This is particularly true for resourcepoor communities (Forster et al., 2020; Miller et al., 2020). Thus, there is a growing need to understand and promote agri-food system sustainability in the context of shocks. Since resilience is the capacity to absorb, endure, and recover from shocks (National Academies, 2024), it constitutes a critical pathway to achieve sustainability.

Previous research has tended to address individual shocks separately (Fourth National Climate Assessment, 2018; McKibbin and Fernando, 2020), even as agri-food systems can experience multiple shocks simultaneously or sequentially (i.e., when a system has not recovered from a shock before experiencing a second shock) (Machlis et al., 2022). Therefore, complex interactions and cumulative impacts from multiple shocks are often overlooked (Drake et al., 2023). While prior research has identified numerous approaches to enhance the resilience of agri-food systems to a shock, it is not clear how particular strategies play out under multiple shocks. A recent review found 40 elements that enhance resilience in agri-food systems (Eller, 2020), but their relative importance and interactions in the context of multiple shocks is not known (Stone and Rahimifard, 2018). Also, enhancing resilience to a particular shock may strengthen or compromise resilience to other shocks. Thus, understanding the complex interactions of multiple shocks is crucial for building resilience.

Another limitation of previous efforts is their focus on specific locations, even though shocks in one place may affect food sustainability and resilience in other places nearby and far away over time (Liu, 2023). The lack of knowledge about how multiple shocks affect agri-food systems across spatial and temporal scales may lead to ineffective and/or maladaptive interventions. Therefore, it is essential to address these knowledge and action gaps by identifying the most effective strategies across relevant places for building resilience while preparing for, responding to, and recovering from multiple shocks.

Additionally, previous efforts have mostly tended to separate research, education, and extension, causing inefficiencies and ineffectiveness in knowledge generation, dissemination, and utilization. Separate efforts can result in years passing between publication, curriculum updates, and real-world uptake. Separating research from education and extension is also ineffective for educating a transdisciplinary workforce and for solving real-world problems. In contrast, integrating research, education, and extension means conducting them simultaneously and interactively. More specifically, research is conducted in a way that is engaged with, and not siloed from, the needs of education and extension. Furthermore, such

integration facilitates the rapid translation of scientific discoveries into effective education and practical, real-world applications that promote food sustainability and resilience under multiple shocks, while also enhancing interest in the STEM workforce for agri-food systems (Institute of Medicine, 2011). This exposes students to, and engages them in, research and extension, while allowing the inclusion of non-traditional and lifelong learning avenues for professional development, online training, and certification across multiple disciplines. Extension also needs to evolve from the traditional primarily unidirectional flow of information (e.g., from extension personnel to farmers) into bidirectional and feedback-driven flows of information (e.g., from farmers to extension personnel to researchers and educators) to guide more targeted research and education.

While the advantages of integrating research, education, and extension have long been recognized (Van Crowder and Anderson, 1997), there is an urgent need for a transdisciplinary, systems-based integration to address the impacts of multiple shocks with the goal of building resilient and sustainable agri-food systems (Marshall and Schrank, 2014; Choularton et al., 2015). For example, to prepare for, respond to, and recover from multiple shocks, it is essential to conduct transdisciplinary research with relevant stakeholders to address knowledge gaps about how multiple shocks impact agri-food system resilience and sustainability across various spatial and temporal scales. At the same time, it is crucial to address action gaps by developing mitigation strategies for multiple shocks and disseminating knowledge through extension and educating the workforce to use it effectively.

In this paper, we first present a holistic framework that integrates agri-food supply chains in a focal region and in regions near and far to address food sustainability and resilience under multiple shocks. We  then illustrate how the framework can be  operationalized to increase the resilience of agri-food systems by integrating research, education and extension. Finally, we  discuss challenges and opportunities to operationalize the framework worldwide, and its contributions to achieve United Nations Sustainable Development Goals, particularly SDG 2 (Zero Hunger) (United Nations, 2015).

# 2 Integrated framework

An integrated framework is necessary to address agri-food system sustainability and resilience under multiple shocks (Figure  1). We  propose a framework that encompasses the impacts of, and responses to, multiple shocks and includes entities such as producers, processors and/or manufacturers, distributors/wholesalers, retailers, institutional food services and end consumers (Jones and Hiller, 2017). Multiple shocks may affect one, some, or all supply chain entities, while decisions specific to a supply chain entity may also impact other entities. When shocks occur simultaneously (Savary et al., 2020; Queiroz et al., 2021), there may be interactive effects beyond the primary effects of the individual shocks. When shocks occur sequentially, the earlier shocks may have legacy effects that amplify the impact of later shocks.

Moreover, we expand the scope of agri-food systems using the framework of metacoupling (human-nature interactions within, and among adjacent and distant human-nature systems) (Liu, 2017).

![](images/7e53367ce8a60bdd3d0dae8dfc847ee19764a539994377ebb37633cc9d1b6a82.jpg)  
FIGURE 1 Schematic representation of proposed agri-food supply chains under multiple shocks. The green and blue boxes at the back refer to agri-food supply chains in other places near and far, respectively, that may interact with humans and nature of the focal place in the front. *Food Waste is defined by the USDA as “wholesome food that could have helped feed families in need is sent to landfills” (USDA, 2021).

Interactions among systems occur through various flows (e.g., food, people, materials, energy, information, financial capital). Depending on the direction of the flows, a system can be treated as sending, receiving, or spillover. Spillover systems affect or are affected by the interactions between sending and receiving systems. Each agri-food system includes human and natural components, which play various roles: agents or actors (decision-making entities such as policymakers, farmers, and traders that facilitate or impede flows), causes (reasons behind the flows), and effects (socioeconomic and environmental consequences of flows) (Liu, 2023). The metacoupling framework incorporates all relevant human and natural components of the agrifood system as well as their interactions within and beyond borders. Furthermore, shocks in one place may influence food production and other processes across adjacent and distant places.

# 3 Operationalization of the framework

To illustrate how the framework can be  operationalized, we  identify a suite of key questions, propose methodological approaches and research protocols, and describe possible outcomes and products. The questions below are directed towards different actors in multiple organizations. While each question may have different relevance to different actors, the participation and collaboration of all actors are crucial for an effective operationalization of the framework and its use to address the impacts of multiple shocks within, and in adjacent and distant, agri-food systems worldwide.

The questions address the broad goals of defining and characterizing shocks, estimating the impacts of multiple shocks, identifying mitigation strategies, providing decision support systems, enhancing extensionstakeholder linkages, educating an agri-food system workforce, and building and engaging an agri-food resilience community (Figure 2). We organize this section sequentially by the nature of the questions being addressed but note that successful implementation of the framework requires not only its adoption (e.g., by different actors working simultaneously) but also its iteration as new knowledge is acquired.

# 3.1 Defining and characterizing shocks

What shocks are of concern to the agri-food system(s) under investigation? How can these shocks be  characterized for long-term monitoring and assessment? What strategies have been adopted to mitigate vulnerabilities to shocks? The recommended starting point is to investigate the characteristics, likelihood, and mitigation strategies currently in place or under consideration for relevant single shocks. This step provides a needed baseline for assessing the risks and consequences of multiple shocks. Qualitative research (Gephart, 2004) using in-depth interviews with representative stakeholders along supply chains provides insights into the most vulnerable points in agri-food supply chains, the strategies to mitigate vulnerabilities, and the outcomes of these strategies. Such information can be  categorized using the (PESTEL) approach (Yusop, 2018), which focuses on assessing macro environment conditions in six key areas: Political (e.g., regulation, trade/

![](images/b79a3f19b41b1dbabe10295236c8e3701051b382671d3ee51871e6d41f12a680.jpg)  
FIGURE 2 Schematic illustration of the operationalization of the proposed integrated framework for addressing agri-food system sustainability and resilience in the face of multiple shocks. The white boxes represent the suggested broad goals of the operationalization, and the green box represents the desired goal of a sustainable, resilient agri-food system. The arrows highlight connections between the suggested goals, the integration of research, education and extension across all the goals, and the need for iteration as more information becomes available and knowledge is gained.

tariff considerations), Economic (e.g., price, trade flows, growth rates), Socio-cultural (e.g., health consciousness, education, buying habits), Technological (e.g., infrastructure, technological change), Environmental (e.g., pandemics, pollution, waste) and Legal (e.g., labor laws, cyber-data protection). While interviewees are not expected to have insights on specific macro environment conditions, the shocks experienced may be categorized using the PESTEL framework. This approach allows for obtaining the perspectives and experiences from different stakeholders along supply chains, which in turn helps identify a broader range of different types of shocks and an assessment of their severity at different points of the supply chain. For example, farmers may be  impacted by regulations which require adapting farming practices and/or legal aspects related to laws in terms of hiring labor, while food manufacturers may be  impacted by socio-cultural considerations, such as health consciousness which could affect consumer buying patterns and/or ingredients used in production. It is also necessary to estimate the likelihood of shock occurrences and trends in shock frequency from historical data and future projections.

# 3.2 Estimating the impacts of multiple shocks

What combinations of shocks pose the greatest threat to agrifood systems? What are the impacts of multiple shocks on the

production and flows of agri-food systems? Would multiple shocks lead to more food insecurity and nutritional inequities? These questions can be addressed using a combination of quantitative, qualitative, and modeling approaches. The frequency and trend analyses from above for single shocks provide initial estimates of the likelihood of different combinations of multiple shocks. Qualitative surveys, conducted either separately or in concert with the surveys suggested above for single shocks, can gather information on stakeholder experiences with multiple shocks, recovery challenges, and the combinations of shocks with the greatest impacts. Approaches to estimating the impacts include counterfactual analyses in similar areas that did and did not experience multiple shocks, and/or in time periods before and after multiple shocks. For environmental shocks, crop and pest models can help estimate the impacts of multiple shocks on production, and remotely sensed observations (Viña et al., 2011; Gitelson et al., 2025) can provide valuable information on multiple shock impacts. Impacts on food flows can be evaluated using the Food Flow Model (Lin et al., 2019), and network analysis can help identify hotspots of vulnerability (Lin et  al., 2014). Examining household purchases before and after multiple shocks can help determine how shocks affect purchases of different foods, how micronutrient and macronutrient contents of diets change, and whether changes in nutritional intake vary among different regions as well as by age, ethnicity and socioeconomic status.

# 3.3 Identifying mitigation strategies

How can agri-food systems become more resilient to multiple shocks? Can mitigation strategies designed for single shocks also reduce vulnerability to multiple shocks or do unintended consequences minimize their effectiveness? What are the estimated short- and longterm consequences of different scenarios (e.g., combinations of multiple shocks and mitigation strategies)? To identify and evaluate alternative actionable strategies to mitigate vulnerabilities and enhance adaptive capacity to multiple shocks, the role of both individual stakeholders and systems-level factors affecting the resilience of supply chains should be  examined while recognizing different motivations, behaviors, and outcomes. Participatory model building involving different agri-food supply chain participants provides an overall assessment of system resilience under multiple shocks, and ways to reduce vulnerabilities through learning from resilient features. Mitigation strategies can be evaluated by their technological feasibility, economic viability, social acceptability and environmental sustainability (Benis and Ferrão, 2017). These approaches can be complemented by multi-scale, spatially explicit, multi-agent-based systems models to simulate the impacts (e.g., interactive, cumulative, and cascading) of multiple shocks and mitigation strategies under various scenarios (Muto et al., 2020). A factorial design (Pulliam et al., 1992) can be used to explore main effects and magnitudes of shocks, and their interactive effects.

# 3.4 Developing decision-support systems

Which knowledge/information sources and flows are most important for real-time decision-making in agri-food systems? What are optimal designs and performance limits for alerts/rapid response of AI-based decision-making under multiple shocks? What plans and proactive thinking emerge from AI simulations that provide the best tradeoffs between productivity and resilience under different conditions? While there are several knowledge-based decision support tools such as checklists, these tend to follow predefined rules and cannot adapt to novel situations without manual reprogramming. In contrast, novel AI-enabled systems (especially those involving machine learning), such as those developed using Markov Decision Process (MDP) modeling (Sutton and Barto, 2018), can learn from data, adapt, and improve performance over time. Thus, they can better assist stakeholders to prepare for, and respond to, multiple shocks. MDP-based simulations can provide alerts when they are deployed in real time and inform rapid response, with algorithms recommending decisions related to specific shocks/combinations of shocks. MDP-based scenario simulations allow decision makers to think through what they might do under different settings and proactively prepare for multiple shocks. They may also be used to design policies in the face of strategic agents (Zheng et  al., 2022) with different idiosyncratic properties (Baltaji et al., 2024).

# 3.5 Enhancing extension-stakeholder linkages

How can extension professionals effectively communicate new insights and best practices regarding resilience and sustainability under

multiple shocks? Innovative extension curricula that incorporate new perspectives on mitigation strategies for coping with multiple shocks and novel decision-making tools can help build the resilience to multiple shocks. They can employ a risk management framework (Alexander and Marshall, 2006) to include contents, such as mitigation strategies and characteristics of different types of agri-food supply chains under multiple shocks. Possible communication strategies include StoryMaps to visualize supply chain disruptions under different scenarios. Train-the-trainer webinars and workshops can disseminate the extension curricula while allowing stakeholders to provide input to extension personnel on the proposed mitigation strategies.

# 3.6 Educating a future agri-food system workforce

Can novel curricula centered on complex agri-food systems under multiple shocks help prepare a transdisciplinary STEM workforce in agri-food systems? Can students be engaged in obtaining knowledge and skills through teaching multiple shocks? Recent interest in multiple shocks can be  harnessed to develop engaging curricula for K-12, undergraduate, and graduate students that innovatively focus on the impacts and mitigation of multiple shocks. These novel curricula can help address the underdevelopment and underrepresentation of agrifood systems in the STEM workforce (Institute of Medicine, 2011) through engaging curriculum formats, workshops, and courses. Storylike case studies, project-based assignments, virtual career fairs, simulations and other active learning design can be  adapted to learning levels. Realistic scenarios can challenge students to analyze problems and evaluate solutions, while leveraging AI advances in systems analysis, uncertainty, and decision making. Moreover, a special focus on transdisciplinary, integrative, and systems thinking can train a high-powered, flexible workforce ready to solve problems across geographic scales. Such advances may include participatory processes that build relationships while developing collective learning involving students across disciplines and among multiple higher education institutions (Collier et al., 2024). Such novel curricula will benefit from informative outreach about food shocks research to federal, state, and local entities that support educational delivery systems, meaningful metrics and high-quality professional development for teachers.

# 3.7 Building and engaging an agri-food resilience community

How can the research, education, extension and stakeholder communities be effectively integrated to address challenges to agri-food systems under multiple shocks? How can community members share and inspire new ideas and innovative solutions for improving agri-food system resilience and sustainability? Research, education and extension are often compartmentalized (e.g., in separate institutions). Under this single sector approach, scientific and technological information are viewed as a unidirectional flow from research organizations to stakeholders (e.g., farmers, consumers). Such a view hampers the establishment of effective linkages that allow direct and explicit feedback mechanisms. In contrast, an integrated approach that

establishes strong multi-directional linkages among research, education, extension and stakeholder communities enables information to flow in all relevant directions, ultimately producing knowledge outcomes that are more holistic and adaptive than those produced by any of these sectors in isolation. This is particularly needed to more effectively cope with, and mitigate the effects of, multiple shocks. Such integration requires efforts in community building and creating platforms where different communities can engage, share, and inspire new ideas and innovative solutions. Options for community building and engagement include: a) establishing a Food Resilience Fellows program where Fellows (e.g., graduate students, faculty, extension specialists, and other professionals) participate in all major activities of an ongoing integrated, multiperspective project to speed up their readiness and ability to undertake and lead future projects; b) building a virtual and open-access portal that contains inspiring ideas, valuable lessons, success stories, news, data, models, publications, presentations, extension curricula, and novel educational materials; and c) creating solution incubators where community members can connect through video conferencing and social media to share and discuss new ideas and innovative solutions.

# 4 Challenges and opportunities

It is challenging to study agri-food system sustainability and resilience under multiple shocks because they involve not only simultaneous and/or sequential shocks but also their complex interactions, which elevate their potential risks and are likely to extend across administrative boundaries and across scales. It is also challenging to integrate research, education, and extension simultaneously than to focus on only one of these aspects. Challenges also exist in gathering primary data, compiling secondary data, and synthesizing various sources of data. Moreover, there are many uncertainties as many unpredictable factors and their interactions could be  overlooked. Nevertheless, the simultaneous integration of research, education and extension under the metacoupling framework can help address these uncertainties and interactions. Furthermore, because the metacoupling framework encompasses human-environment interactions within, and between adjacent and distant places (Liu, 2023), its inclusion will help organize and coordinate efforts to achieve SDGs (United Nations, 2015), particularly SDG 2, under multiple shocks, as factors affecting food production and demand in one place have cascading consequences in places near and far (e.g., through trade) (Liu, 2018). This constitutes a paradigm shift that will enable transitioning from traditional place-based approaches to a more holistic approach that incorporates the interactive effects of multiple shocks across different places worldwide.

Multiple shocks pose unprecedented challenges to food sustainability and resilience across local to global scales. Addressing these challenges can benefit from the integrated framework proposed here. A transdisciplinary systems approach, applied by a qualified researcheducation-extension team with complementary expertise and incorporating multi-institutional collaborations and stakeholder engagement, can be used to operationalize the framework to accomplish the overall goals of increased resilience and sustainability of agri-food systems. With appropriate modifications that address different cultural settings and governance systems, such an integrated approach can be  adapted and replicated throughout the world to enable the development and evaluation of policy prescriptions (e.g., infrastructure

investment, labor relocation, subsidies, tariffs) that consider not only local and regional but global effects. To do so, transdisciplinary teams should mentor a new generation of researchers, educators, and extension specialists by training students, postdoctoral associates, and junior professionals to work together, lead, and organize their own transdisciplinary projects. For example, we  are organizing a Food Resilience Fellows program in our transdisciplinary project that enables learning various skills (e.g., leadership, team science, proposal writing, project implementation). These efforts can speed up the readiness of the fellows to undertake new integrated research, extension, and education projects. Although addressing agri-food system sustainability and resilience under multiple shocks is not easy, the integration of various activities, data, approaches, and models is increasingly appreciated by the research, education, and extension communities. These endeavors are also being supported by some funding agencies, such as the USDA NIFA’s Agriculture and Food Research Initiative-Sustainable Agricultural Systems (USDA NIFA AFRI-SAS) Program, which has supported ongoing efforts to implement such an integrated framework and approaches in the U.S. Midwest.

# 5 Concluding remarks

Agri-food systems are faced with multiple shocks. Strengthening agri-food system resilience and sustainability under multiple shocks requires innovation and integration across research, education, and extension, each of which requires participation from communities with fairly distinct epistemic and working cultures. The framework proposed in this paper integrates human-nature interactions and supply chains across space and scales through collaborations among research, education, and extension communities, as well as relevant stakeholders. The general approaches highlighted here can help untangle the complex impacts of multiple shocks, develop strategies to prepare for and mitigate the impacts of multiple shocks, train a new generation of workforce, and disseminate information for policy and management. While much remains to be  done, they lay a good foundation for addressing challenges and opportunities to achieve agri-food system resilience and sustainability worldwide.

# Generative AI statement

The authors declare that no Gen AI was used in the creation of this manuscript.

Any alternative text (alt text) provided alongside figures in this article has been generated by Frontiers with the support of artificial intelligence and reasonable efforts have been made to ensure accuracy, including review by the authors wherever possible. If you identify any issues, please contact us.

