# Resources time footprint for assessment of human influence on ecosystem service from a sustainabilit

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:40:49.004796+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Dem et al. - 2024 - Resources time footprint for assessment of human influence on ecosystem service from a sustainabilit.pdf
- Year: unknown
- DOI: 10.1016/j.jclepro.2024.140612
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper develops and applies a new sustainability indicator, the Resource Time Footprint (RTF), to evaluate how human activities influence ecosystem service (ES) supply and flow over time.

The study focuses on the Phobjikha Conservation Area in central Bhutan, a biodiverse wetland valley that is both a Ramsar site and an important agricultural region, especially for potatoes. The authors map land cover for 2010 and 2020 using satellite imagery, classify it into six classes, and then estimate the supply potential of 17 ecosystem services (provisioning, regulating, supporting, and cultural) via a land-cover-based benefit transfer approach. They also convert ES to emergy units and compute emergy-based indices (ELR, EYR, ESI) for comparison.

RTF is introduced as a life-cycle-oriented, time-based footprint that measures how long four key resources - materials, land, labor, and pollutant absorption capacity - are occupied relative to their social and ecological carrying capacities over a 100-year lifespan. It is applied in detail to potato production and its flow to markets, using national and global data on land availability, working population, steel stocks and reserves, fertilizer and fuel use, and carbon sequestration. Uncertainty and sensitivity analyses (data quality scoring, Monte Carlo simulation, and sensitivity indices) test the robustness of the RTF estimates.

Results show that overall ES supply in Phobjikha increased about 3.5 percent between 2010 and 2020, mainly through more vegetation and associated regulating and supporting services, while provisioning services declined. For potato ES, average per capita RTF dropped from 0.81 to 0.52 years (about 2 vs 1.3 years per 100 kg), implying lower resource occupancy and higher intergenerational sustainability in 2020. Land and labor are identified as the main constraints; material and pollutant footprints are comparatively small. Emergy-based indicators also improve over time but still classify potato production as environmentally stressed and economically weak.

The paper explicitly situates RTF within a telecoupling / metacoupling perspective by analyzing how ES produced in one region (potato supply) flow via infrastructure to distant consumers, and how human-driven flows interact with local ecological capacities. It argues that RTF and emergy analysis are complementary tools for assessing sustainability of ES supply-flow systems in a telecoupled world.

## Structured Metacoupling Extraction

### Coupling Classification
- Telecoupling focus; also addresses intra and inter regional ecosystem service flows via potato trade.

### Intracoupling
#### Systems
- Phobjikha valley social ecological system in central Bhutan.
- National Bhutanese agricultural and labor system.
- Local forest and wetland ecosystems supporting multiple services.
#### Flows
- Local use of ecosystem services by resident households.
- Flow of potatoes from farms to Bhutanese consumers.
- Use of local forests for fodder, litter, and fuelwood.
#### Agents
- Bhutanese farmers and laborers in Phobjikha.
- Local households depending on valley resources.
- Bhutanese planners and conservation authorities.
#### Causes
- Land cover change driven by agriculture and conservation policies.
- Human inputs of machinery, fertilizers, and labor to potato farming.
- Tourism growth and conservation designations affecting access.
#### Effects
- Shift from provisioning to regulating and supporting services.
- Land and labor pressures highlighted by high RTF components.
- Local social vulnerability from restricted forest access.

### Pericoupling
#### Systems
- Phobjikha valley and other Bhutanese regions linked by food trade.
- Protected wetlands versus adjacent agricultural zones.
- Valley communities and nearby tourism markets.
#### Flows
- Regional trade and transport of potatoes to domestic markets.
- Tourist visits bringing cultural ecosystem service demand.
- Movement of agricultural inputs from other Bhutan districts.
#### Agents
- Regional traders and transport companies within Bhutan.
- Tour operators and visiting tourists.
- National ministries managing agriculture, forestry, and tourism.
#### Causes
- Regional demand for potatoes as staple food and cash crop.
- Conservation measures designating Ramsar wetland and protected area.
- Tourism promotion of the valley as attraction site.
#### Effects
- Trade offs between agriculture expansion and wetland conservation.
- Regional redistribution of labor demand and income.
- Increased pressure on regional road and transport infrastructure.

### Telecoupling
#### Systems
- Bhutan potato producing system and distant consumer regions.
- Global steel and fertilizer production systems supplying inputs.
- Global carbon cycle and climate regulation services.
#### Flows
- Export oriented flow of potatoes via long distance trucking.
- Embodied material flows of steel, diesel, fertilizers, and pesticides.
- Greenhouse gas emissions affecting global atmospheric sinks.
#### Agents
- International and national supply chains for machinery and inputs.
- Global consumers indirectly benefiting from exported potatoes.
- Researchers applying RTF and emergy within telecoupling framework.
#### Causes
- Spatial mismatch between ecosystem service supply and demand.
- Globalized markets for agricultural products and farm machinery.
- Reliance on worldwide carbon sequestration capacity for emissions.
#### Effects
- Resource time occupancy of global steel and carbon sinks by local farming.
- Intergenerational sustainability risks exported beyond Bhutan.
- Need for governance of cross scale ecosystem service flows.

### Cross-Coupling Interactions
- Telecoupled demand for potatoes intensifies local land and labor pressures, reducing some local services.
- Global carbon absorption capacity constrains locally driven emissions from agriculture.
- Imported machinery links global steel depletion to regional ES trade offs.

### Research Gaps or Limitations
- RTF currently omits many natural inputs like sunlight, rainfall, and soil formation.
- Emergy ESI weakly represents social equity, specific ecological thresholds, and pollutant assimilative capacities.
- Need methods to extend RTF to biodiversity impacts and scenario based future land use changes.

### Search Keywords
- resource time footprint RTF ecosystem services Bhutan potatoes emergy telecoupling
- intergenerational sustainability land labor pollutant footprint agricultural provisioning services
- ecosystem service supply flow demand cross scale trade offs

### Extraction Confidence
high
