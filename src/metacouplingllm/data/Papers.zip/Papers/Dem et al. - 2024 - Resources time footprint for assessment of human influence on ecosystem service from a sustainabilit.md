# Resources time footprint for assessment of human influence on ecosystem service from a sustainability standpoint

![](images/c4397993bf16d1f8213111b52f3c97ed7f6c839f9c10d66cecad5c5d252477b4.jpg)

Phub Dem a,\*, Kiichiro Hayashi b, Minoru Fujii c

<sup>a</sup> Graduate School of Engineering, Nagoya University, Furo-cho, Chikusa-ku, Nagoya, 464-8601, Japan   
b Institute of Materials and Systems for Sustainability, Nagoya University, Furo-cho, Chikusa-ku, Nagoya, 464-8601, Japan   
$^{\mathrm{c}}$ Social Systems Division, National Institute for Environmental Studies (NIES), 16-2 Onogawa, Tsukuba, Ibaraki, 305-8506, Japan

# ARTICLEINFO

Handling Editor: Jing-Li Fan

Keywords:

RTF

Ecosystem services

Sustainability

Emergy

# ABSTRACT

Nature provides diverse services to humanity, known as ecosystem services (ES), yet certain services, such as food and timber, are geographically distant from human settlements. This spatial separation of ES from supply area to demand site fosters transfer through human-made carrier as ES flow, resulting in social and ecological impacts. This study delves into this complex ES supply, flow, and demand relation. While the conventional ES assessment approach mainly quantifies ES supply potential, Resources Time Footprint (RTF) is introduced as a new indicator to evaluate human intervention part of ES supply and flow. RTF examines intergenerational sustainability of ES by evaluating material, land, labor, and pollutant resource utilization in relation to individual allocations. The efficacy of this integration is evaluated through a case study covering 17 ESs dynamics in central Bhutan for 2010 and 2020, and RTF is applied to potato-ES, given its higher human intervention in the area. This is finally validated against commonly used emergy analysis and its derivatives. The study observed a $3.5\%$ increase in 17 ESs, with minor intergenerational implications associated with supply and flow of potato-ES. The average per capita RTF values were 0.81 and 0.52 years, or 2 and 1.3 years per $100\mathrm{kg}$ of potatoes for the 2010 and 2020 base case, respectively. This smaller RTF value for 2020 indicates reduced resource occupancy rates with higher intergenerational sustainability. This replicable indicator effectively evaluated human related impacts on ES supply and flow and identified land and labor as underperforming aspects with higher occupancy rates. The comparative validation showed inadequateness of emergy-derivatives in examining human intervention in ES flow, and limitations of ES-RTF in evaluating nature's contribution. This underscores the complementary nature of two methodologies. Overall, this study contributes to a telecoupling framework for a sustainable society, enhancing coherence and consistency in analyzing ES supply and flow.

# 1. Background

The Earth and human activities are closely interconnected, with each providing and receiving various goods and services, notably ecosystem service (referred to as 'ES'), which includes economic commodities and social amenities. However, over the last few decades, this integration has significantly weakened, diminishing essential ecosystem functions, thereby severely jeopardizing human health and well-being (Millenium Ecosystem Assessment Report (MA), 2005; Costanza et al., 2017). In response, research employing descriptive concept of ES potential has flourished over time and space (Liu et al., 2020). However, the higher prevalence of geographical heterogeneity in ES supply (area that provide specific ES within a given period) and demand sites (where ES are

consumed or utilized) has resulted in intra- and inter-regional routing of ES, represented as ES flow, posing threats to their long-term viability (Burkhard et al., 2013). Specifically, provisioning ES (referred to as 'P-ES'), which includes food, fiber, fresh water, genetic resources, and biochemicals, are tradable resources that often degrade ecological and social resources (MA, 2005). For instance, $80\%$ of coffee, a P-ES produced through human contributions like fertilizer application and soil tillage in Colombia (supply area), is distributed in global markets (demand area) through manmade networks, such as roads, shipping routes, and aviation (Schroter et al., 2018). Such P-ES, produced and influenced significantly by human contributions, have documented substantial environmental and social repercussions, namely, multi-aspect sustainability implications. Sustainability, as defined by Fiksel et al. (2012),

refers to the promotion of societal well-being, economic prosperity, and environmental protection within each carrying capacity.

Generally, ES and sustainability are overarching concepts that analyze the relationship between humans and nature. However, a vision is lacking on how to align ES with the sustainability goal (Schroter et al., 2017). Previous studies mostly conduct independent analyses of ES supply, flow, and/or demand, overlooking the interdependence and implications of human intervention on ES sustainability. A balanced ES assessment considering supply and flow, the inclusion of demand-side perspectives, such as commensurate benefits and beneficiaries, impacts of human intervention on ES sustainability, and approaches to achieving social and environmental justice within carrying capacity are still in their relative infancy. Furthermore, questions have been raised about how to govern intra- and inter-regional flows of ES (Serna-Chavez et al., 2014; Schroter et al., 2017; Blanco et al., 2021).

Gauging and monitoring the progress of the human-environment system toward sustainability through indicators and indices, and selecting favorable options, are imperative for establishing a sustainable society. Yet, evaluating system sustainability remains arduous due to multiplicity of components, intricate interactions, ideal-oriented goals, trade-offs, and ambiguous interpretations (Anon, 2011). Although ecological indicators have been used for over 50 years, the development of sustainability indicators is rather new, with notable turning points occurring after the 1992 Earth Summit in Rio de Janeiro, Brazil (Hak et al., 2016). The Compendium of Sustainable Development Indicator Initiatives lists 894 indicators (Wu and Wu, 2012), yet many are singular indicators that reflect only certain aspects of human-environmental system tiptoeing from the fundamental concept of sustainability. Several approaches and indicators, such as life cycle assessment (de Bruijn et al., 2002), material flow accounting, and families of footprints, such as the ecological footprint (Wackernagel and Rees, 1998), carbon footprint, and water footprint (Hoekstra et al., 2011), are widely used in ES impact assessments. Nevertheless, they cover only environmental dimension (Mancini et al., 2018). Ignoring other sustainability features may result in distorted assessments, and such an environmentally viable process alone cannot be considered sustainable (Gasparatos and Scolobig, 2012). Consequently, there is still no consistent conceptual or analytical framework for evaluating the societal driven impacts on ES supply-flow and relative sustainability (Bluszcz, 2016; Costanza et al., 2017).

The energy sustainability index (ESI), a derivative of emergy synthesis (Odom, 1996a,b), is frequently used in sustainability assessment of P-ES (He et al., 2020). It disentangles renewable and non-renewable contributions and assesses social and environment system's performance in terms of efficiency and intensity (Brown and Ulgiati, 2004). The potential contribution of a system or product is reflected through economy per unit of environmental load (Brown and Ulgaiti, 1997). Despite its widespread acceptance across diverse fields, this approach encounters several challenges and criticisms attributable to its complicated algebras, unstandardized accounting framework, and evaluation uncertainties (He et al., 2020; Wang et al., 2020). ESI's approach of categorizing nature's and human's contribution through renewability and non-renewability represents an innovative approach (Ferraro and Benzi, 2015; Shah et al., 2019). Nevertheless, this disengagement exaggerates and undermines certain contributions, resulting in the perception of agriculture as human-engineered and controlled (Pérez-Soba et al., 2019). It also cannot explicitly identify trade-offs among various dimensions of sustainability.

The critical need for optimization tools that can effectively allocate ES supply and demand, demonstrate sustainability repercussions across spatiotemporal scales, and identify emergent trade-offs is frequently emphasized (Hak et al., 2016; Schröter et al., 2018). To address this urgent need, this study develops a method that can evaluate human induced impacts on ES. In combination with the conventional ES assessment approach, the Resource Time Footprint (referred to as 'RTF') is introduced to evaluate human impacts on ES supply and flow from an

intergeneration perspective, serving as a sustainability assessment. RTF referred to as the resource occupancy to capacity ratio by Fujii et al. (2014) is defined as the temporal occupation of essential aspects by a human activity. It measures the temporal length of occupation for four fundamentally required aspects; materials, land, labor, and pollutants, by comparing their occupancy to capacity, using a threshold of 100 years. While previous studies have utilized RTF for renewable energy site selection (Huang et al., 2023), assessment of forest management practices, and waste recycling (Ooba et al., 2015), its application to ES is a new approach.

In pursuit of this objective, Phobjikha central Bhutan - a region of significant ecological and economic value but facing growing social vulnerability (ICIMOD.RSPN., 2014) - is selected as the case study area. The assessment begins with an analysis of 17 ESs for 2010 and 2020, identifying potato as having high supply potential and substantial human intervention (Lepcha et al., 2021). Subsequently, RTF evaluates how human intervention impacts the supply and flow of potato-ES from an intergenerational sustainability perspective. Remaining ESs items are excluded here as their supply and flow involve limited human intervention. Finally, ES and RTF results are validated against those obtained through emergy and ESI, revealing the limitations and complementarities of both approaches.

# 2. Method

# 2.1. Research flow

In ES field, managing trade-offs among ES and achieving sustainability present significant difficulties (King et al., 2015). Promotion of P-ES often degrades remaining ES. For instance, intensive agricultural operation threatens regulating ES through pollutant emissions and land occupancy. As a tool governing ES flow and managing trade-offs is frequently sought, this study introduces RTF for evaluating human driven impacts of ES supply and flow. After quantifying land cover (LC) based ES dynamics, the effectiveness of RTF is demonstrated through a potato P-ES case study (Fig. 1).

# 2.2. Case study area

Decadal ES dynamics and indicator potential were investigated in the Phobjikha Conservation Area in Central Bhutan (Fig. 2). This small biologically rich area with 90 bird and 20 mammalian species, including the globally threatened species (RSPN, 2005) is not only a local and international tourist attraction site (ICIMOD.RSPN., 2014), but is also a productive agricultural area, with an annual potato productivity rate of $19\mathrm{t / ha}$ (MoAF, 2020). The core wetland region and riverine area is designated as Ramsar Site No. 2264 (Ramsar, 2016). These diverse uses have resulted in an adversarial scenario, with noticeable conflicts between environmental enthusiasts and economic promoters. Societal vulnerability arises here, with $80\%$ of the local community dependent on the valley forests but having limited access due to conservation plans (Chaudhary et al., 2017).

# 2.3. Process and methods

ES, as a natural capital asset, has gained widespread prominence after the release of MA report in 2005. The report presented an unprecedented decline in most ES worldwide, jeopardizing future generations' access to them (MA, 2005). To restore depleted ES, there is a global surge in evaluation efforts using various methods (Costanza et al., 2017). In this study, following the MA classification typology and employing a cost-effective LC-based simple benefit function transfer approach, the supply potential of 17 ES subtypes was assessed for 2010 and 2020.

![](images/5d25d6807e615c7c3755cf6ed68b4eb29e537fa36ed5b26f2a86e17f87a199b5.jpg)  
Fig. 1. Scheme research flow.

![](images/8925d5cdb933fe3c6e81adfdedb569c2a0e109160cae716190ad7feb3c2f6917.jpg)  
Fig. 2. Geographical location of study area.

# 2.3.1. Preparation of LC maps

LC change, an inevitable landscape phenomenon, occurs at various scales and frequencies due to natural and human forces (Giri, 2012). This alteration affects structures and functions of ecosystems, influencing the supply of ES. Given the inexorable linkage between LC and ES, freely accessible, accurate, and timely published remotely sensed data are predominately used to study the extent of LC change and its repercussions on global and local ES (Giri, 2012; Tolessa et al., 2017). Here, the LC dynamics over a decade were analyzed through LC mapping, which was later used as a surrogate indicator for ES change. The 2020 LC is mapped using a $15m \times 15m$ spatial resolution sentinel image (L1C_T46RBR_A028916_20210104T044202) from https://earthexplorer.usgs.gov with virtually no clouds ( $<5\%$ ). Before undergoing classification, images were subjected to atmospheric correction in QGIS 3.16. The Normalized Difference Vegetation Index (NDVI), an indicator of vegetation greenness, is used to identify live vegetation. The composite image was then classified into vegetation, artificial surface (AS), agriculture, bare area, river, and wetland through supervised-based Maximum Likelihood Classification. Misclassified pixels were manually corrected to improve its accuracy. For 2010, LC map of ICIMOD & RSPN (2014) was resampled, rectified, and reclassified into six LC classes. 250 randomly generated points were used for the accuracy assessment.

# 2.3.2. ES evaluation procedure

This study adhered to the widely used MA (2005) ES classification typology, namely provisioning, regulating, supporting and cultural ES. The assessment covers seventeen ES items, specifically, seven provisioning, seven regulating, two supporting and a cultural for both 2010 and 2020 (listed in S5). The P-ES evaluation includes four foods (MoAF, 2010; MoAF, 2020) and three fiber ESs. The amount of leaf litter collected was approximated based on $89.9\%$ of households rearing livestock data (RSPN, 2005) and average annual leaf collection data of 1, 500 to $10,000~\mathrm{kg}$ (Dorji et al., 2018). Given the limited on-site unit ES values, benefit function transfer approach was employed for regulating and supporting ES. This approach is widely recognized for its cost-effective transfer of existing data from original studies to new settings and has been applied to various global and national ES valuation studies (Costanza et al., 2014; Vackar et al., 2018). For the cultural ES, benefits rendered to visitors are determined using visitor data from JICA. (2012) for 2010, and 2018 visitor data (Tourism Council of Bhutan, 2019) for 2020. Eq. (1) linked the LC data with unit ES values.

$$
E S V = \sum \left(A _ {k} \times V C _ {k f}\right) \tag {1}
$$

Where $ESV$ represents the estimated ES value, $A_{k}$ is the total land area (ha) for LC category "k" and VCkf is the unit functional value coefficient

for each thematic LC category $k$ and ES type $f$ (Table S1).

The contribution of vegetation to sediment regulation was determined through Martinez-Lopez et al. (2019) model, which is based on Renard (1997)'s soil erosion concept. By computing the Revised Universal Soil Loss Equation (RUSLE) twice-first using the existing LC and then shifting all land cover to bare soil, the total averted soil erosion was calculated. RUSLE, an empirical approach for soil erosion modeling, calculates the annual soil loss as; $S = (R \times K \times LS \times C \times P)$ , where $S$ is annual soil loss expressed in t/ha. $K$ refers to the soil erodibility, $R$ expresses the rainfall erosivity, $LS$ is the slope length and steepness factor, and $C$ and $P$ are cover management and conservation practice factors.

The amount of $\mathrm{O}_2$ released under supporting ES was estimated through the photosynthetic equation, which states that for $1\mathrm{g}$ of dry matter, a plant fixes $1.47\mathrm{gCO_2}$ and releases $1.06\mathrm{gO_2}$ (Pan et al., 2021).

# 2.4. RTF analysis of ES supply and flow

RTF evaluates four aspects that are necessary for a person to live (Fig. 3). Through a comparison of resource occupancy with social and environmental carrying capacities, it highlights aspects that require countermeasures to enhance intergenerational sustainability (Fujii et al., 2014). Each aspect is allocated to a beneficiary over a period of 100 years, the lifespan unit, which is used as the indicator's threshold. Such allocation ensures fair and equitable distribution of ES from intergenerational sustainability perspective. The occupancy duration is finally measured by averaging the occupancy rates of four aspects. A higher RTF value indicates lower sustainability, implying an extended duration, huge resource occupancy, and/or large levels of pollution emissions (Ooba et al., 2015). The RTF (in years) is calculated through Eqs. (2a) and (2b).

$$
R T F = \frac {O A \times T}{T A} \tag {2a}
$$

$$
R T F (\text {p o l l u t a n t}) = \frac {O A}{T A} \tag {2b}
$$

Where, $OA$ in above equations represent resources occupied (kg of resources, $km^2$ of land, or persons involved), $T$ indicates duration of resource occupancy (years), and $TA$ represents ecological and social capacity. For primary functions with finite flow and supply speed (such as water and pollutant), Eq. (2b) is used.

# 2.4.1. RTF calculation procedure

The RTF's potential to quantify human intervention in ES supply and its impacts on ES flow was tested through a decadal analysis of potatos, considering a cradle-to-the-factory gate boundary. At each production stage, RTF aspects with visible impacts were evaluated (Fig. 4(a)). The land aspect measured the human land area occupancy rate for crop cultivation, while the material aspect indicated the occupancy rate of limited resources. The labor aspect evaluated the societal burden, and the pollutant aspect calculated the occupancy rate associated with $\mathrm{CO}_{2}$

![](images/eee321e9aed0dff04deed08f64503333020e43cf0832d58e33b92da5b51ddb88.jpg)

$$
R T F m a t e r i a l = \frac {\text {a m o u n t} \times (k g) \times T}{\text {s t o c k} + \text {r e s e r v e}}
$$

![](images/cd307de0a58027dd17e6dc6cd2ab87bb32675e835433f364dedf5f29b6aee9d6.jpg)

$$
R T F l a n d = \frac {\text {o c c u p l e d} \text {l a n d} m ^ {2} \times T}{\text {t o t a l} \text {l a n d} \text {f o r h u m a n} m ^ {2}}
$$

![](images/e61b0ec967ccdf49780e81f84c285e33fcf3ddaccdabe0baf1bb103260bae805.jpg)

$$
R T F l a b o r = \frac {\text {w o r k i n g - d a y / p e r s o n} \times T}{\text {w o r k i n g p o p u l a t i o n}}
$$

![](images/293c3aa46b39fff78e286a881eb64d8e99f22657baa73a4e7c4433beb064b2f1.jpg)

$$
R T F p o l l u t a n t = \frac {\text {e m i s s i o n} \ln k g}{\text {a b s o r p t i o n c a p i e n g} k g / y e a r}
$$

![](images/77eafcf0370406a744990cd2f0b422e8d5b8e6bda376727e683f3f2931fc776b.jpg)  
Fig. 3. Overview of RTF concept.

emission from conventional tillage, fertilizers, transportation, and seeds. The RTF values of four aspects were averaged per beneficiary (per capita), which is the number of people whose annual potato demand can be met from the total output. This was calculated based on an annual per capita national potato consumption rate of $40\mathrm{kg}$ , or 30,800 kcal (MoAF, 2015; Haden, 2002). The RTF values were further expressed per 1,000 kcal and $100\mathrm{kg}$ of potatoes to demonstrate the magnitude of human occupancy per 100 years.

2.4.1.1. RTF material. Among various input materials, the evaluation focuses on finite materials with a relatively large mass of use (Fujii et al., 2014). Given that farm machinery is primarily composed of steel, the RTF of steel was calculated based on the required number of tillers and equipment (FMC, 2020), considering the replacement rates of 10 and 5 years, respectively (Kinga and Wangchen, 2020). The estimated value of steel used was compared with the global per capita allocated steel resources, encompassing both stocks and recoverable reserves (Eq. 3).

2.4.1.2. RTF land. Land is another primary fundamental resource with finite abundance required to generate the secondary resource (potato). The land aspect determined the per capita land occupancy rate over 100 years using Eq. (4), which compares per capita land occupancy with the national per capita land capacity. This was calculated by multiplying human occupancy level (y) by the corresponding national LC data (Table 1).

2.4.1.3. RTF labor. Human labor, a social feature of sustainability, determined the social burden by comparing the total labor required with the national labor population. The value of 251 in Eq. (5) represents the national annual per capita legal working days in Bhutan, which we employed to allocate labor to each beneficiary. The temporal labor occupancy rate was determined through Eq. (5) using the input data listed in Table 2.

2.4.1.4. RTF pollutant. The production of machinery, its usage, and the application of fertilizers are associated with pollutant emissions into the entire bio-geosphere. Here, $\mathrm{CO}_{2}$ emissions were calculated by multiplying input parameters such as steel and agrochemicals, tillage, and transportation of produce with respective emission factors (Table 3). The pollutant occupancy rate was calculated using Eq. (6), comparing per capita emissions with the per capita global carbon sequestration rate, considering the global omnidirectional service delivery (Bagstad et al., 2013).

2.4.1.5. Average RTF. The potato-ES's intergenerational sustainability over the next 100 years was estimated by averaging occupancy rate of aspects without weighting (Table 4 in Eq. (7)). However, if one aspect is deemed more significant, it becomes necessary to consider weighting. The common unit of measurement enabled us to identify trade-offs among aspects and communicate sustainability results effectively.

$$
R T F \text {s t e e l} = \frac {M a (\text {s t e e l}) \times T}{M b (\text {s t e e l})} \tag {3}
$$

$$
R T F l a n d = \frac {(\mathrm {L a} \times \mathrm {T})}{\mathrm {L b}} \tag {4}
$$

$$
R T F l a b o r = \frac {\mathrm {P a} / 2 5 1 \times \mathrm {T}}{P \times \mathrm {P b}} \tag {5}
$$

$$
R T F p o l l u t a n t = \frac {\mathrm {C a}}{C b} \tag {6}
$$

$$
R T F = \frac {R T F \text {s t e e l} + R T F \text {l a n d} + R T F \text {l a b o r} + R T F \text {p o l l u t a n t}}{4} \tag {7}
$$

![](images/044aaebd86b2f1bc1d82d48e8478b310a12a2a011c0a62737d16d8813d2ac95f.jpg)  
Fig. 4(a). System boundary of potato farming for RTF analysis. 4(b). Hybrid data quality indicator and statistical method.

Table 1 National land capacity (in ha).   

<table><tr><td>LC</td><td>ya</td><td>Area in 2010b</td><td>Area in 2020c</td><td>Human land capacity in 2010</td><td>Human land capacity in 2020</td></tr><tr><td>Forest</td><td>0</td><td>2,673,200</td><td>2,717,161</td><td>0</td><td>0</td></tr><tr><td>Grassland</td><td>0</td><td>749,200</td><td>600,403</td><td>0</td><td>0</td></tr><tr><td>Agriculture</td><td>0.6</td><td>120,000</td><td>105,682</td><td>72,000</td><td>63,409</td></tr><tr><td>Build-ups</td><td>1</td><td>6,800</td><td>7,457</td><td>6,800</td><td>7,457</td></tr><tr><td></td><td></td><td></td><td>total</td><td>78,800</td><td>70,866</td></tr></table>

a Value from Kawaguchi et al. (2020).   
b National land area data from Gilani et al. (2015).   
c FRMD (2017).

Table 2 Input parameters for labor RTF analysis.   

<table><tr><td>Activity</td><td>unit</td><td>2010</td><td>2020</td><td>Source/note</td></tr><tr><td>Land preparation</td><td>Person-day/ha</td><td>10</td><td>10</td><td>Lepcha et al. (2021).</td></tr><tr><td>Farmyard manure preparation</td><td>Person-day/ha</td><td>20</td><td>20</td><td></td></tr><tr><td>Plantation</td><td>Person-day/ha</td><td>42</td><td>42</td><td></td></tr><tr><td>Weeding</td><td>Person-day/ha</td><td>28</td><td>28</td><td></td></tr><tr><td>Pesticide application</td><td>Person-day/ha</td><td>5</td><td>5</td><td></td></tr><tr><td>Produce harvesting</td><td>Person-day/ha</td><td>195</td><td>195</td><td></td></tr><tr><td>Transportation of produce</td><td>person-day</td><td>589</td><td>953</td><td>Estimated AL &amp; kg/ha (MoAF, 2010; MoAF, 2020).</td></tr><tr><td>Total labor</td><td>person-day/year</td><td>2.3E+05</td><td>2.5E+05</td><td>(labor per ha × AL + transportation labor)</td></tr></table>

# 2.5. Uncertainty and sensitivity analysis of RTF

Theoretically, RTF findings appear reliable and effective for making the best decision. However, its reliance on several spatiotemporal data introduces uncertainty, potentially impacting the reliability of results. Uncertainty and sensitivity analyses are therefore crucial to determine the accuracy and influence of input parameters on model outcomes (Liu and Ashton, 1998; Mountford et al., 2017). To analyze RTF result's uncertainty, as employed by Wang et al. (2019), a hybrid data quality indicator and statistical method were used (Fig. 4(b)).

Table 3 Parameters for pollutant analysis.   

<table><tr><td>Parameter</td><td>Unit</td><td>2010</td><td>2020</td><td>Source/note</td></tr><tr><td>Nitrogen (N2)</td><td>kg/ha</td><td>235</td><td>287</td><td rowspan="2">Lepcha et al. (2021); Lepcha &amp; Suwanmaneepong (2022), Yeshey et al. (2013).</td></tr><tr><td>Phosphorous (P)</td><td>kg/ha</td><td>173</td><td>235</td></tr><tr><td>Potassium (K)</td><td>kg/ha</td><td>111</td><td>428</td><td></td></tr><tr><td>Seed potatoes</td><td>kg/ha</td><td>3,060</td><td>3,060</td><td></td></tr><tr><td>Fungicides</td><td>kg/ha</td><td>4.95</td><td>4</td><td></td></tr><tr><td>Herbicides</td><td>kg/ha</td><td>4</td><td>7</td><td></td></tr><tr><td>Total chemical fertilizers</td><td>kg/ha</td><td>528</td><td>961</td><td></td></tr><tr><td>Steel used in machinery</td><td>kg/year</td><td>2,693</td><td>5,087</td><td>Estimated based on steel content in machines (https://isae.in.)</td></tr><tr><td>Emission coefficient of steel</td><td>kgCE/t</td><td>2,148</td><td>2,148</td><td>Hasanbeigi et al. (2016)</td></tr><tr><td>Distance to market</td><td>km</td><td>282</td><td>282</td><td>Acorn (2020).</td></tr><tr><td>Emission coefficient of conventional tillage</td><td>kgCE/ha</td><td>10</td><td>10</td><td>Lal (2004).</td></tr><tr><td>Emission coefficient of N2</td><td>kgCE/ha</td><td>1.3</td><td>1.3</td><td></td></tr><tr><td>Emission coefficient of P</td><td>kgCE/ha</td><td>0.2</td><td>0.2</td><td></td></tr><tr><td>Emission coefficient of K</td><td>kgCE/ha</td><td>0.15</td><td>0.15</td><td></td></tr><tr><td>Emission coefficient of herbicide</td><td>kgCE/ha</td><td>6.3</td><td>6.3</td><td></td></tr><tr><td>Emission coefficient of fungicide</td><td>kgCE/ha</td><td>3.9</td><td>3.9</td><td></td></tr><tr><td>Transportation emission factor (by truck)</td><td>kgCE/t-km</td><td>0.062</td><td>0.062</td><td>Cefic (2011).</td></tr></table>

The input parameters for RTF aspects were scored from 1 to 5 referring to a data quality pedigree matrix, consisting of three indices: geographical correlation, age, and supplier independence (Wang and Shen, 2013). Following it, its scores were equally weighted (Table 5) to determine the data quality score (DQS) (Wang et al., 2019). Data were

Table 4 Summarized RTF parameters.   

<table><tr><td>Symbol</td><td></td><td>Parameter</td><td>Unit</td><td>2010</td><td>2020</td><td>Source/note</td></tr><tr><td rowspan="2">Basic Information</td><td>AL</td><td>Acreage</td><td>ha</td><td>792</td><td>836</td><td>From LC Map.</td></tr><tr><td>P</td><td>Beneficiaries</td><td>man</td><td>1.8E+05</td><td>3.3E+05</td><td>Annual output (MoAF, 2010; MoAF, 2020) (/) per capita consumption rate (MoAF, 2015).</td></tr><tr><td rowspan="3">Material Aspect</td><td>T</td><td>Occupancy period</td><td>year</td><td>100</td><td>100</td><td>Fujii et al. (2014).</td></tr><tr><td>Ma(steel)</td><td>Per capita steel used.</td><td>kg</td><td>1.46</td><td>1.53</td><td>number of machines × steel content × replacement rate of 10 and 5 years (Norbu and Wangchen, 2010).</td></tr><tr><td>Mb(steel)</td><td>Total steel allocated per capita</td><td>kg</td><td>1.5E+04</td><td>1.3E+04</td><td>Morfeldt et al. (2015); Statista (2021).</td></tr><tr><td rowspan="2">Land Aspect</td><td>La</td><td>Per capita land occupancy</td><td>ha</td><td>0.003</td><td>0.002</td><td>AL × Loccupancy level of 0.4 (Kawaguchi et al., 2020).</td></tr><tr><td>Lb</td><td>Per capita land capacity</td><td>ha</td><td>0.11</td><td>0.1</td><td>Table 1 (/) total national population (World Bank, 2010; NSB, 2020a,b).</td></tr><tr><td>Labor aspect</td><td>Pa</td><td>Total labor</td><td>man-day</td><td>2.3E+05</td><td>2.5E+05</td><td>From Table 2.</td></tr><tr><td rowspan="3">Pollutant aspect</td><td>Pb</td><td>per capita laboring population</td><td>man</td><td>0.63</td><td>0.67</td><td>World Bank (2010); NSB (2020).</td></tr><tr><td>Ca</td><td>Per capita carbon emission</td><td>kg</td><td>289</td><td>235</td><td>Emissions in Table 3 (/) P.</td></tr><tr><td>Cb</td><td>Per capita carbon absorption capacity</td><td>kg</td><td>2,184</td><td>2,591</td><td>Ballantyne et al. (2012).</td></tr></table>

Table 5 Data quality indicator matrix for uncertainty analysis.   

<table><tr><td>Input parameter</td><td>DQS_2020</td><td>DQS_2010</td><td>DQS_2020 fraction</td><td>DQS_2010 fraction</td></tr><tr><td>Area</td><td>5,5,5</td><td>5,5,5</td><td>5</td><td>5</td></tr><tr><td>Population beneficiaries</td><td>4,3,3</td><td>4,3,3</td><td>3.7</td><td>3.7</td></tr><tr><td>Population of Bhutan</td><td>5,5,5</td><td>5,5,5</td><td>5</td><td>5</td></tr><tr><td>Land capacity</td><td>5,5,5</td><td>5,5,4</td><td>5</td><td>4.6</td></tr><tr><td>Farm labor input</td><td>5,4,5</td><td>5,4,4</td><td>4.5</td><td>4</td></tr><tr><td>Labor for transportation</td><td>3,3,5</td><td>3,3,5</td><td>3.7</td><td>3.7</td></tr><tr><td>Labor population of Bhutan</td><td>5,5,5</td><td>5,5,5</td><td>5</td><td>5</td></tr><tr><td>Steel used in 100 years</td><td>2,3,3</td><td>2,3,3</td><td>2.7</td><td>2.7</td></tr><tr><td>World population</td><td>5,5,5</td><td>5,5,5</td><td>5</td><td>5</td></tr><tr><td>Global Steel stocks in use</td><td>5,5,4</td><td>5,5,4</td><td>4.6</td><td>4.6</td></tr><tr><td>Steel reserves (iron ore)</td><td>5,3,5</td><td>5,3,5</td><td>4</td><td>4</td></tr><tr><td>Emission from fertilizers</td><td>4,4,4</td><td>4,4,4</td><td>4</td><td>4</td></tr><tr><td>Emission from seed potatoes</td><td>5,4,4</td><td>5,4,5</td><td>4</td><td>4.5</td></tr><tr><td>Emission from delivery</td><td>5,4,4</td><td>5,4,4</td><td>4</td><td>4.5</td></tr><tr><td>Emission from tillage</td><td>3,4,4</td><td>3,4,4</td><td>3.6</td><td>3.6</td></tr><tr><td>Emission from material</td><td>4,3,3</td><td>4,3,3</td><td>3.7</td><td>3.7</td></tr><tr><td>Carbon sequestration of World</td><td>5,5,4</td><td>5,5,5</td><td>4.5</td><td>5</td></tr></table>

transformed into a beta distribution, and range of values are determined based on the transformation matrix of Kennedy et al. (1996). The non-parametric Kolmogorov-Smirnov goodness of fit test estimated the probability distribution of parameters (Wang and Shen, 2013). Monte Carlo simulation (MCS) analysis with 1,000 iterations extracted averaged input value and possible RTF values for parameters with low DQS.

The sensitivity index (Eq. (8)) proposed by Liu and Ashton (1998) was employed to assess the impact of fluctuations in input parameters on RTF results. A higher sensitivity index indicates a greater influence on the average RTF value, and vice versa.

$$
S x = \frac {(\Delta X / X)}{(\Delta P / P)} \tag {8}
$$

Here, $X$ represents the original RTF results, $\Delta X$ represents the difference from simulated results, $P$ represents the parameter's reference value, $\Delta P$

represents its resulting variation, and $Sx$ denotes the sensitivity index. A larger $Sx$ indicates higher sensitivity of the dependent variable to a change in a particular parameter, and the signs $+$ and $-$ indicate the direction of change (Mountford et al., 2017).

# 2.6. ES assessment through emergy synthesis and its derivatives

In conjunction with the benefit function transfer approach and RTF indicator, this study evaluated decadal ES dynamics and potato P-ES sustainability through energy analysis and its derivatives. Emergy accounting quantifies the cumulative energy invested by nature and humans in coherent wholes, sej (Chaudhary et al., 2017). This study converted ES subtypes to emergy unit (sej) through Eq. (9), with unit emergy values (in Table S2) relative to $15.83\mathrm{E} + 24$ sej/yr global emergy baseline (GEB) (Odum et al., 2000). Emergy sustainability indices measured the system's performance by segregating contributions into local renewable (R), local non-renewable (NR), imports, and services (F) types (Table S3). The environmental loading ratio (ELR) and environment yield ratio (EYR) were utilized for sustainability assessment, with ELR gauging environmental sustainability performance and EYR quantifying the system's reliance on imported resources and its economic contribution (Brown and Ulgaiti, 1997; Londono et al., 2014). This relationship is expressed through emergy sustainability index (ESI), where a system with maximum economic benefit (EYR) and minimum environmental stress (ELR) indicates better sustainability (Cao and Feng, 2007).

$$
E m e r g y = B i o p h y s i c a l v a l u e \times U E V \tag {9}
$$

Where biophysical values are commonly given in grams, joules, or dollars, and UEV shows energy per unit of available energy (Campbell and Brown, 2012).

$$
E L R = \frac {\mathrm {F} + \mathrm {N R}}{\mathrm {R}} \tag {Eq. (10)}
$$

$$
E Y R = \frac {\mathrm {R} + \mathrm {N R} + \mathrm {F}}{\mathrm {F}} \tag {Eq. (11)}
$$

$$
E S I = \frac {E Y R}{E L R} \tag {Eq. (12)}
$$

# 2.7. RTF discussion with emergy analysis in quantifying ES

This section compared the ability of ES-RTF and emergy-ESI to assess supply-flow of ES. It provides a detailed analysis of system boundaries, sustainability features, and assessment complexity comparisons to enhance understanding of complementary possibilities for a comprehensive analysis of ES sustainability.

# 3. Results

# 3.1. Results of ES dynamics

Fig. 5, with accuracies of $96\%$ and $93\%$ , illustrates an increase in vegetation, agricultural, and artificial areas, coupled with a decrease in rivers, wetland, and bare areas (Table S4). Despite the expansion in acreage, P-ES exhibited a decreasing trend. This can be attributed to shifts in crop priority and a reduction in fuelwood and timber extraction from nearby forests. The augmentation of vegetation area resulted in an $8\%$ increase in supply of regulating and supporting ES (Table S5). When aggregated, ES followed an LC order: vegetation $>$ wetland $>$ bare land $>$ agriculture $>$ river $>$ artificial area for both years (Table S6). Cultural ES demonstrated an increase in visitors' bed nights. The overall ES supply potential showed an upward trajectory of $3.5\%$ . Fig. 6(a) shows ES dynamics normalized through logarithmic normalization with 2010 baseline values.

# 3.2. Implications of human intervention on ES supply and flow

Fig. 6(b) shows the intergenerational sustainability performance and contribution rate of each aspect given the baseline situation persists for 100 years. Despite expansion of acreage and anthropocentric inputs, the magnitude of potato-RTF for both baselines remained lower than its threshold value. In comparison, the 2010 base case, with a per capita RTF value of 0.81 years, exhibited higher temporal occupancy and lower sustainability compared to the 2020 baseline (Table S7). The average RTF values were 0.026 and 0.017 years per $1,000\mathrm{kcal}$ of potatoes, and 2 years and 1.3 years per $100\mathrm{kg}$ of potatoes for the 2010 and 2020 base cases, respectively. The improved sustainability in 2020 is credited to factors like increased global per capita carbon dioxide absorption capacity (Ballantyne et al., 2012), a growing national working population (NSB, 2020a,b), higher land productivity (MoAF, 2020), and beneficiaries leading to reduce per capita land occupancy. However, the occupancy rate of materials was higher in 2020, due to increased imports of farm machinery and a decline in global steel reserves (Statista, 2021). To enhance system sustainability and ensure continued supply of remaining ES, greater emphasis needs to be placed on labor and land aspects. Improving land productivity, thereby increasing beneficiaries, and adopting renewable farm machinery can reduce land and labor RTF values, fostering higher intergenerational sustainability. Sustainable farming practices, including precision farming, integrated pest management, and the adoption of sustainable technologies, can further decrease land and labor occupancy rates (Li et al., 2020).

# 3.3. Sensitivity analysis result $(Sx)$

Sensitivity analysis revealed the response of average RTF result to changes in input parameters (Table 6). Land capacity, population beneficiaries, and steel reserves showed negative sensitivity to RTF values for both years, whereas other parameters were mostly positively sensitive. Specifically, land capacity, population beneficiaries, steel used, and farm labor were sensitive in 2020 base case, while land capacity, farm labor, steel reserve and fertilizer emissions were sensitive in 2010. This indicates that increasing land capacity, ensuring sufficient steel reserves, and increasing population beneficiaries can improve the sustainability of potato production. Farm labor showed the highest influence on average RTF, indicating a negative impact on overall sustainability. It should therefore be taken seriously to enhance sustainability performance.

# 3.4. Emergy-based ES results

The aggregated ES solar energy values were $2.22\mathrm{e} + 21\mathrm{sej}/$ year and $2.31\mathrm{e} + 21\mathrm{sej}/$ year for 2010 and 2020, respectively, indicating a $3.5\%$ higher ES value in 2020 (Table S8). However, the solar emergy of P-ES was higher in 2010 $(1.72\mathrm{e} + 19\mathrm{sej}/$ year). The regulating services potential has increased from $2.20\mathrm{e} + 21\mathrm{sej}/$ year to $2.29\mathrm{e} + 21\mathrm{sej}/$ year, and the NPP-based $\mathrm{O}_2$ releasing capacity rose by $8\%$ . Visitors' solar emergy increased from $1.02\mathrm{e} + 18\mathrm{sej}/$ year to $1.14\mathrm{e} + 18\mathrm{sej}/$ year. From the ESI analysis, the UEV of potatoes was $1.82\mathrm{E} + 05\mathrm{sej}/$ J and $1.44\mathrm{E} + 05\mathrm{sej}/$ J for 2010 and 2020, respectively (Table 7), which closely align with $1.78\mathrm{E} + 05\mathrm{sej}/$ J, the UEV of Brandt-Williams (2002). The low crop productivity rate of $12.4~\mathrm{t / ha}$ coupled with higher dependence on NR and F, contributed to the elevated UEV in 2010. This increased environmental load and reduced economic benefits, consequently diminishing sustainability. In 2020, UEV was lower due to higher productivity (MoAF, 2020). Both systems exhibited moderate environmental impacts, low economic benefits with no significant contribution to local resources, and an unsustainable process in the long term.

# 4. Discussion

# 4.1. RTF analysis of ES supply and flow

The LC-based ES analysis showed increased greening and subsequent regulating, supporting, and cultural ES, but a decrease in P-ES. This descriptive assessment offers an overview of nature's contribution to human well-being but doesn't measure human impacts on ES supply and flow. Given that P-ES often degrades other ES (MA, 2005), the impacts of human intervention on ES sustainability were assessed through a potato case study employing the RTF approach. The implications were

![](images/d29890bbb2698d54548667bc70d9803e724a925f3846524eb91bb43db870120c.jpg)  
Fig. 5. Land cover map for 2010 and 2020 (L-R).

![](images/205330c01256ca170e504ef39c349d45958c33da24b247afd995ca190c08b4f4.jpg)

![](images/fde18f25a7f4cfae731c3b31b44ab81bdd051eb6871038132e2435c7960f2507.jpg)  
Fig. 6. (a) Normalized ES dynamics. 6 (b) Average per capita RTF values.

Table 6 Parameter influence on average RTF.   

<table><tr><td>Parameter</td><td>Influence on RTF 2020</td><td>Influence on RTF 2010</td></tr><tr><td>Land capacity</td><td>-1</td><td>-1</td></tr><tr><td>Population beneficiaries</td><td>-1</td><td>-0.1</td></tr><tr><td>The steel used in 100 years</td><td>1</td><td>0</td></tr><tr><td>Global Steel stock in use</td><td>-0.1</td><td>0</td></tr><tr><td>Steel reserves (iron ore)</td><td>-0.8</td><td>-0.8</td></tr><tr><td>Farm labor</td><td>2</td><td>6</td></tr><tr><td>Labor for transportation</td><td>0</td><td>-0.1</td></tr><tr><td>Emission from fertilizers</td><td>0.4</td><td>0.6</td></tr><tr><td>Emission from seed</td><td>0.1</td><td>0.2</td></tr><tr><td>Emission from delivery</td><td>0.4</td><td>0.2</td></tr><tr><td>Emission from tillage</td><td>0</td><td>0</td></tr><tr><td>Emission from materials</td><td>0.1</td><td>0</td></tr></table>

Table 7 UEV and ESI results for potato-ES.   

<table><tr><td>Note</td><td>Aspect</td><td>2020</td><td>2010</td></tr><tr><td>1</td><td>UEV value (sej/J)</td><td>1.44E+05</td><td>1.82E+05</td></tr><tr><td>2</td><td>Environment load Ratio (ELR)</td><td>4.51</td><td>5.53</td></tr><tr><td>3</td><td>Emergy yield ratio (EYR)</td><td>1.62</td><td>1.66</td></tr><tr><td>4</td><td>Emergy sustainability index (ESI)</td><td>0.35</td><td>0.3</td></tr></table>

allocated per beneficiary, and occupancy rates for social and ecological dimensions were evaluated for a period of 100 years, which is the human life span. The selected parameters for RTF include steel used under the material aspect, land occupancy for food production in land aspect, emission of $\mathrm{CO}_{2}$ under the pollutant aspect, and required man-day for the labor aspect. Considering the global omnidirectional service delivery for material and pollutant, the denominator of these aspects was allocated per capita at the global scale, while land and labor capacity were calculated at the national scale. The comprehensive evaluation revealed minor impacts of human intervention on potato supply and flow. With an average per capita RTF value of 0.52 years in the 2020 base case, the RTF performance was superior to the production and flow of resources in 2010 (0.81 years). Alternatives for saving resources and reducing emission was found labor and land intensive. Improving land productivity and adopting sustainable farming techniques can reduce the RTF value and achieve higher intergenerational sustainability. Specifically, to improve land and labor RTF, the study recommends using renewable energy, diversifying income, modernizing worn-out agricultural machinery, and promoting green fuel to replace fossil fuels in tillage practices.

In addition to the intergenerational sustainability results, a common unit for fundamental aspects facilitated a clear understanding of trade-offs among aspects. For instance, the case study indicated higher land and social implications, with lower ecological impacts through pollutant

and material occupancy. This explicitly conveys a comprehensive picture of pressures human places on specific aspects. The combination of function transfer approach with the RTF approach was found effective in evaluating human impacts of ES supply and flow from intergeneration sustainability perspective. Its use could aid decision-making in land-use planning, resource allocation, and policy development to achieve overarching sustainability goals.

# 4.2. RTF vs. emergy-ESI analysis of ES sustainability

Fig. 7 illustrates the distinctions and commonalities between the RTF and emergy-ESI from both ES and sustainability standpoint. For ES analysis, emergy synthesis aggregates multiple sub-types into common biophysical units and provides an overall estimate of ES value. However, it does not explicitly account for regulating ES such as pollination or cultural ES. In contrast, RTF focuses exclusively on ES with human involvement, such as P-ES and cultural ES.

The indicators also offer different sustainability perspectives. RTF emphasizes the intergenerational flow of resources within carrying capacity as a measure of sustainability aspect, whereas ESI focuses on using renewable resources optimally. RTF measures its sustainability by evaluating material, land, labor, and pollutants occupancy in relation to specific carrying capacity. Whereas ESI quantifies the potential contribution of a system to the economy per unit of environmental load. They also share different system boundaries: ESI considers a natural ecosystem boundary from the donor's perspective (Reza et al., 2014), while RTF examines the entire life cycle system from the demand side. A sustainable system should be inclusive of societal well-being, economic prosperity, and environmental protection within each carrying and regeneration capacity (Ben-Eli, 2018). However, we found limited consideration of social equity and specific ecological capacity aspects in ESI, such as assimilative capacities for air or water pollutants. Emergy's carrying capacity is determined by the local environment's renewable emergy flux and ELR (Brown and Ulgiati, 2001), whereas the RTF relies on carrying capacity of each aspect. Conceptual GEB and UEVs in emergy were not well-defined, and it was difficult to obtain the spatial embodied energy content of resources. The temporal scale is yet another important sustainability dimension influencing intergenerational fairness (Mayer, 2008). However, a common resolution for sustainability is annually in ESI, which is inadequate to cover long-term impacts such as depletion of resources, or climate change. The occupancy is assessed by RTF over a period of 100 years. Human-environmental contributions are vital for sustaining the biosphere and its subsystems (Ingwersen, 2011). However, certain natural contributions, such as rain, water, and sun, have not been considered in RTF evaluation so far. It can be interpreted from the land aspect, however, obtaining quantitative values requires further evaluation. Similarly, human contributions and specific implications on the sustainability aspect are of lesser concern in ESI compared to its assessment of nature contributions.

![](images/5a29ebd5795fb8c546a496447f1d63108776a410e945861bd9c9b726cfdb0117.jpg)  
Fig. 7. ES analysis from different perspectives. The purple boundary represents an independent study of ES supply and demand by previous studies. The green emergy boundary clearly illustrates emergry analysis of nature and human contributions at P-ES sites, with limited focus on pollutants, land use intensity and socioecological limits. The brown box shows RTF studying ES supply and flow from anthropocentric view, and this research's boundary is marked by bold black box. (For interpretation of the references to colour in this figure legend, the reader is referred to the Web version of this article.)

Despite having different definitions of sustainability, both indicators demonstrated enhanced sustainability for the 2020 system. The environmental sustainability defined by the ratio of per capita pollutant emissions to absorption capacity in the RTF was higher in 2010, indicating low environmental sustainability. Similarly, ELR of emergy synthesis showed a moderate environmental impact due to its higher dependence on non-renewable and purchased resources than local renewable resources. Although the temporal comparison results are similar, the overall sustainability results were contradictory. The RTF indicated a sustainable production system for both years, whereas the ESI revealed an unsustainable production system. However, with a specific social and ecological carrying capacities, RTF effectively identified trade-offs among its aspects and presented clearer sustainability results. Comprehending and communicating the biophysical unit of emergy was challenging. ESI provides insights into ES sustainability, but it captures a partial view of sustainability concept (Gronlund, 2016; Wang et al., 2019). It does not account for spatial-temporal capacity and cannot specify unsustainable aspects or stages.

# 4.3. Limitation of ESI in evaluating agricultural P-ES sustainability

Agroecosystem services encompass contributions from nature and humans, and ESI accounts these contributions through the concepts of renewability (R) and non-renewability (NR). It categorizes purchased goods and services (F), including seeds and labor input, into Renewable F (RF), while machinery and fertilizer inputs are classified as Non-Renewable F (NRF) (Ferraro and Benzi, 2015; Shah et al., 2019). However, this binary categorization does not accurately capture varying degrees of renewability present in certain NRF. For example, fuel, steel, and fertilizers are considered non-renewable, even though nature has processed them for millions of years. This practice results in the perception of agriculture as human-engineered and controlled (Pérez-Soba et al., 2019).

To disentangle varying contributions, nature and human efforts are further quantified in FNR of potato-ES. These include $87.1\%$ and $12.9\%$ in diesel, $58\%$ and $42\%$ for potash, $69.2\%$ and $30.8\%$ for phosphate, and $20.5\%$ and $79.5\%$ for steel (Brown et al., 2011; Odum and Odum, 1983; Odum, 1996a,b). The aggregated contributions were $33\%$ nature, $67\%$ human in 2010, and $36\%$ nature, $64\%$ human in 2020, differing significantly from Brandt-Williams (2002) findings of $14\%$ nature and $86\%$ human.

# 4.4. Synergy & improvement potential of RTF

The ES-associated environmental challenges have been widely explored using various indicators, including emergy synthesis. However, this concept has been criticized for being complicated, and inaccurate, and is facing standardization issues such as inconsistent GEB and UEV standards (Wang et al., 2020). To enhance accuracy and reduce uncertainty, users have begun combining emergy with commonly used LCA (Raugei et al., 2014) and Ecological Footprint (Zadgaonkar and Mandavgane, 2020). However, despite its excellent coordination and integration, its ability to fully integrate triple-bottom-line assessments remains limited. Their focus is mostly on embodied energy and environmental impacts, and only environmentally viable processes cannot be considered sustainable. Furthermore, its ability to identify the underperforming stage and integrate sustainability features, such as specific environmental repercussion, remained limited (Wang et al., 2020). Human contributions are acknowledged, yet emergy-ESI inadequately capture the complexities of how human activities impact the dynamics of ES supply and flow.

The temporal component of RTF, which compares occupancy rates to natural and societal capacity rates, is a significant trait that comprehensively values several aspects of sustainability. However, it does not specifically evaluate the natural inputs such as sun and rain, nonrenewable inputs like surface erosion, and biodiversity impacts associated with ES supply and flow. Both the eco-centric approach of ESI and anthropocentric approach of RTF aim to determine system's sustainability. However, for P-ES, this study observed significant contribution of emergy in quantifying natural inputs in ES. On the other hand, RTF, coupled with the benefit function transfer approach, comprehensively evaluates human impacts on supply and flow from a sustainability perspective. However, benefit function transfer faces limitations in quantifying ES in common units, making it challenging for users to understand the total ES. As the ES-RTF approach does not directly account for nature's contribution and Emergy-ESI does not comprehensively evaluate human contribution, this study demonstrates the complementarity of emergy-ESI and ES-RTF methods. After extracting duplication issues, incorporating emergy-ESI ideas could be a commendable addition to future RTF development.

A roadmap is proposed to refine RTF for aligning ES supply and flow with sustainability goal.

i. RTF exclusively addresses aspects with finite abundance but neglects free environmental inputs. For example, freshwater resources represent only $2.5\%$ of all water resources, and securing these resources for society is one limiting factor for sustainable development (Ansorge et al., 2022). For balanced assessment, such resources can be incorporated under the material aspect.   
ii. RTF omits nature resource loss, such as soil erosion. Incorporating land use intensity in land RTF appears to be an optional consideration.   
iii. Although the general impact on biodiversity can be inferred from the land RTF, the impact on specific biota cannot be conclusively determined. These hidden effects on specific biodiversity should be evaluated in the future.   
iv. Future studies can simulate LC change under multiple representative concentration pathways and shared socioeconomic pathways scenarios and use it to measure future RTF land occupancy rates.   
v. By modifying the input parameters, this approach is replicable to gauge other ES sustainability, including cultural ES for sustainable tourism management.

# 5. Conclusion

In response to degrading ES and the pursuit of sustainability, both ES and sustainability concepts are gaining substantial attention in research and international agendas. While both addresses human- nature relations, it has remained unclear how ES supply and flow corresponds to the level of sustainability. This study broadened ES research by addressing complex ES supply, demand, and flow relation. Specifically, it aligned P-ES with intergenerational sustainability by introducing the RTF indicator, which can evaluate human impacts of ES supply and flow. RTF, coupled with the conventional ES assessment approach, was validated against the commonly used emergy synthesis and its derivatives. The integration robustness, assessed through a case study on the decadal ES trend in Bhutan, revealed higher greening and sustainability of ES supply and flow for 2020. Additionally, the emergy-derivatives indicated higher sustainability for 2020 P-ES.

A comparative examination of ES method coupled with RTF and emergy-ESI revealed distinct capabilities in covering various ES-sustainability features. Emergy-ESI, with its scientific nature, proved effective in quantifying ES potential and assessing nature's contributions. However, for studying human-ES implications, this study found RTF more convincing due to its rigorous coverage of sustainability features from human-dominated perspective. The average RTF values, expressed per capita or per unit of energy, allowed for comparisons between different aspects and the identification of areas for improvement. Given the uniqueness of emergy in evaluating nature's contribution and the profound intergenerational sustainability assessment potential of RTF, this study demonstrated the complementarity of emergy synthesis and RTF after eliminating duplications. Not only did this study align ES with sustainability, but it also established a clear framework for enhancing coherence and consistency in analyzing ES supply and flow.

# Appendix A. Supplementary data

Supplementary data to this article can be found online at https://doi.org/10.1016/j.jclepro.2024.140612.

