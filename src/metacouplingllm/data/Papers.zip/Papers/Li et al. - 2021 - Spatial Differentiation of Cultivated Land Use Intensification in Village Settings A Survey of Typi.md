Article

# Spatial Differentiation of Cultivated Land Use Intensification in Village Settings: A Survey of Typical Chinese Villages

Quanfeng Li 1,2, Zhe Dong 1, Guoming $\mathbf { D u ^ { 1 , * } }$ and Aizheng Yang 3

1 School of Public Administration and Law, Northeast Agricultural University, Harbin 150030, China; quanfeng.li@neau.edu.cn (Q.L.); dzneau@gmail.com (Z.D.)   
2 Key Laboratory of Research on Rule of Law, Ministry of Natural Resources, Wuhan 430074, China   
3 School of Water Conservancy and Civil Engineering, Northeast Agricultural University, Harbin 150030, China; aizheng.yang@neau.edu.cn   
* Correspondence: duguoming@neau.edu.cn; Tel.: +86-133-8465-7203

![](images/6c8c32cda731c23006b4828085e0213aff1962adcd9c0fc9d8c005be2a335cac.jpg)

- -

Citation: Li, Q.; Dong, Z.; Du, G.; Yang, A. Spatial Differentiation of Cultivated Land Use Intensification in Village Settings: A Survey of Typical Chinese Villages. Land 2021, 10, 249. https://doi.org/10.3390/land10030249

Academic Editor: Hossein Azadi

Received: 7 January 2021

Accepted: 23 February 2021

Published: 1 March 2021

Publisher’s Note: MDPI stays neutral with regard to jurisdictional claims in published maps and institutional affiliations.

![](images/e19d01cf86dabac5ee60736c9e3eba05024ab83f4ff929b68cf23b1f69d7d40e.jpg)

Copyright: $^ ©$ 2021 by the authors. Licensee MDPI, Basel, Switzerland. This article is an open access article distributed under the terms and conditions of the Creative Commons Attribution (CC BY) license (https:// creativecommons.org/licenses/by/ 4.0/).

Abstract: The intensified use of cultivated land is essential for optimizing crop planting practices and protecting food security. This study employed a telecoupling framework to evaluate the cultivated land use intensification rates in typical Chinese villages (village cultivated land use intensifications— VCLUIs). The pressure–state–response (PSR) model organizes the VCLUI indexes including the intensity press, output state, and structural response of cultivated land use. Empirical analysis conducted in Baiquan County, China, indicating that the cultivated land use intensification levels of the whole county were low. However, the intensifications of villages influenced by physical and geographic locations and socioeconomic development levels varied significantly. This paper also found that variations in the VCLUIs were mainly dependent on new labor-driven social subsystem differences. Thus, the expanding per capita farmland scales and increasing numbers of new agricultural business entities were critical in improving the VCLUI. Overall, the theoretical framework proposed in this study was demonstrated to be effective in analyzing interactions among the natural, social, and economic subsystems of the VCLUI. The findings obtained in this study potentially have important implications for future regional food security, natural stability, and agricultural land use sustainability.

Keywords: cultivated land use intensification; the pressure-state-response model; the village setting; China; land system; telecoupling

# 1. Introduction

The land system is where the interactions between humans and natural environments occur. It has been accepted that this interaction could change the land system [1–3]. As vital branches of the land system, cultivated land systems have different changing trends [4]. In particular, the transitions of planting practices and farmer livelihoods have resulted in extensive cultivation actions [5–7]. This phenomenon has posed a severe threat to China’s food security and natural environment stability [8–11]. Moreover, cultivated land’s marginalization has harmed food security, evidenced by the increases in nonagricultural farmland and agro-natural problems. Increasing the scale of farming operations and promoting cultivated land use intensification are considered two important ways to protect crop yields and achieve comprehensive benefits [12–17]. However, due to the continuous decrease in the total area of cultivated land [18–20], village cultivated land use intensification has drawn increasing attention from governments and researchers. Meanwhile, optimizing land use structures and improving land use efficiency has become the Chinese government’s primary goals in implementing land conservation and land use intensification policies [21–27].

In recent years, studies that have investigated cultivated land use intensification have mainly focused on connotations, evaluation methods, change revelations, allocation

modes, and countermeasures [28–31]. Previous studies have employed various methods, including comprehensive multifactor evaluations, analytic hierarchy processes, and energy value analyses [32–35]. Besides, empirical study cases have covered the macroscales at the national and provincial levels [36–39], mesoscales at the regional, city, and county levels [40,41], and microscales at the farmer and land plot levels [42]. The exploration has played a positive role in revealing the states of cultivated land use intensification in China. However, in the Chinese management system, managers at various levels tend to have different requirements for their goals related to cultivated land use intensification. The national goal is to ensure food security and agricultural supplies. However, the provincial plan focuses on agricultural production efficiency and grain yields [43], while city and county goals include updating agricultural structures and infrastructure construction [44]. Furthermore, the village level goal mainly focuses on structuring new agricultural business entities and increasing the average per capita agricultural income. These goals have direct impacts on farmers’ enthusiasm levels related to crop production. However, previous studies have rarely been conducted at the village level.

An administrative village is a management unit with rural grassroots, and the government establishes this level under Chinese law [45]. Village committees are set up in administrative villages to implement self-governance. As agents of the administrative village, village committee members manage the cultivated land collectively belonging to village members and equally distribute the cultivated land to village members [46]. Simultaneously, the village committees organize village members to develop various agricultural organization’s cooperative modes to meet agricultural markets and products’ demands. Cooperative land shareholding and collaborative agricultural machinery are currently two popular cooperative modes used in China [47–50]. These two modes can effectively solve extensive farmland management issues and help conduct effective cultivated land use at large scales. However, the number of agricultural cooperatives may vary significantly due to the different production services and coordination capabilities that the village committees can provide. Moreover, to protect the legitimate rights and interests of village members [51], village committee members maintain two-tier management systems between decentralized management (i.e., household-contracted farmland) areas and unified collective management areas [52–54]. Therefore, according to these unique management systems, the village committees can carry out agricultural production activities that are not suitable for contracting with village members, such as farmland infrastructure construction, agricultural socialization, and crop structure adjustments in the village [55,56]. In other words, village committees can ultimately engage in specific behaviors to implement national policies. Therefore, the village committees play an essential role in guiding village members to intensify cultivated land. Although village committees can directly change cultivated land use and optimize the structure of crop planting practices, previous studies that have focused on cultivated land use intensification have rarely considered these factors.

Given the research above uncertainties, this study evaluated cultivated land use intensification at the village scale. The pressure–state–response (PSR) model synthesizes factors associated with cultivated land use intensification from cultivated land systems at the village level. This article’s remainder arranged as follows: Section 2 introduces the cultivated land use intensification’s evaluation framework. Section 3 presents the data sources and methodology. Section 4 describes the spatial variation in cultivated land use intensification within the PSR framework. Section 5 discusses the findings and implications of this study. The conclusions and limitations of this study are also described in the final section. Overall, this study aims to provide a valuable theoretical basis for further investigations of China’s agricultural sustainability at the microscale level.

# 2. Telecoupling Framework of Cultivated Land Use Intensification

Among the best agricultural production practices, village members frequently and reasonably increase capital, machinery, and agricultural materials to maximize crop benefits per unit of cultivated land area [57–59]. These practices or behaviors have been defined

as village cultivated land use intensification (VCLUI) in previous studies [35–37]. The VCLUI reflects the optimal allocation of cultivated land use in villages, which helps solve contradictions between infinite human demands for agricultural products and the limited available cultivated land area.

The village cultivated land use system (VCLUS) in China is a dynamically open framework that can explain complex human–farmland relationships [60,61]. Based on the theory of land use systems [62], the VCLUS is the result of interactions among existing natural, social, and economic village subsystems. Moreover, these interactions are essentially the mutual coupling of cultivated land use elements at the village scale [63] (Figure 1). In the natural subsystem, the soil, topography, climate, hydrology, and organisms constitute the physical cultivated spaces for the VCLUI. These elements take on different physical and chemical properties under other geographical conditions [64]. Due to the natural subsystem’s spatial heterogeneity, village members can potentially optimize their cultivated land use structures using their own experiences and wishes to implement more effective farming practices. In the social subsystem, village members can link natural and economic subsystems. The village members, agricultural cooperatives, and village committees are engaged in agricultural production, management, and services. In the economic subsystem, the capital, machinery, and agricultural materials function to plant and enhance economic benefits. Overall, by nurturing the natural subsystem, the interactions between the social and economic subsystems will affect crop benefits. Theoretically, within the VCLUS framework, the subsystems follow cultivated land use loops of “input, output, and feedback” to obtain the output. Therefore, during agricultural production activities, cultivated land use benefits are determined by the structural elements of the various VCLUSs. Meanwhile, the VCLUI is an effective way to achieve economic benefits from cultivated land use.

![](images/d430044eb473e82df766a263db05a39607d998c06e4ec0ce92e169ec35825080.jpg)  
Figure 1. Logistics between the cultivated land use system and intensification.

# 3. Materials and Methods

# 3.1. Research Area

Baiquan County (Figure 2) is located in the transitional zone between the Lesser Hinggan Mountains and the Songnen Plains in Northeastern China $\mathrm { 2 5 ^ { \circ } 3 0 ^ { \prime } }$ to $1 2 6 ^ { \circ } 3 1 ^ { \prime } \mathrm { E }$ ; $4 7 ^ { \circ } 2 0 ^ { \prime }$ to $4 7 ^ { \circ } 5 5 ^ { \prime } \mathrm { N }$ ). The elevation is between 250 and $4 5 0 \mathrm { m }$ . The slope alluvial deposits at the foot of the Lesser Hinggan Mountains affect the terrain of Baiquan. It gradually decreases from the northeast to southwest, displaying landform pattern characteristics that transition slowly from shallow mountains to rolling hills to low plains, namely the rolling hill and shallow mountains of the north, the high plain of the southwest, the hills and plains of the southeast, and the low-lying plain of the west. Furthermore, the slope is mainly between 3 and $7 ^ { \circ }$ , and the length of them is more than $2 0 0 \mathrm { m }$ . The soil type is a priority of black soil covering the eastern, northern, and central hilly plains of Baiquan, partially based on chernozem soil, peat soil, meadow soil, saline–alkaline soil, and swamp

soil. However, the black soil’s surface is generally loose, vicious, and has poor permeability, which could lead to surface runoff.

![](images/acd277c1fe430e9f21349e3f874dd46dcd85068189f7fd9a9989672454491322.jpg)  
Figure 2. Locations of (a) Northeastern China and (b) Baiquan County. The study area contains 186 administrative villages with a total village member population of 497,000.

Baiquan County has a temperate continental monsoon climate. The average annual rainfall is $4 8 8 \mathrm { m m }$ , which mainly concentrates between July and September. Due to the large amounts of rainfall concentrated within a short period, surface runoff regularly results in water erosion problems. Baiquan County has a relatively high average annual evaporation rate (1132 mm/year), leading to indirect water scarcity. In summary, the region is considered a dry farming area with a high water scarcity level. Moreover, according to the five types of soil fertility survey in China, the first-grade soil is high-yield, which mainly concentrates on the flat alluvial plain of the center, east, and north. The second and third soil is the middle-yield, which was distributed in the flat hilly plain and the low plain. The fourth and fifth soil are of low-yield mainly distributed in the low-lying plain of the southwest, west, and south. The region’s physical geographical features, such as its steep slopes, changing climate conditions, and fertile soil textures, have influenced agricultural development in the county.

Regarding the agricultural conditions, the total land area of Baiquan County is $3 5 . 9 9 \times { \mathrm { \bar { 1 0 ^ { 4 } } } }$ ha, which includes $2 4 . 4 3 \times 1 0 ^ { 4 }$ ha of cultivated land in which soybean, corn, and wheat crops are planted every year. In recent years, Baiquan County has been actively promoting a modern agricultural model. The agricultural data indicates that cash crops have increased to $4 . 6 8 \%$ of the total crops; the numbers of agricultural cooperative organizations, family farms, and large plantations have reached 37,216 and 3950, respectively. The total plant production value is estimated at 3.14 billion yuan RMB, which accounted for $3 6 . 6 8 \%$ of the county’s total GDP in 2018.

# 3.2. Data Sources

The data used in this study included survey data, geospatial data, and administrative boundary data. Specifically, the data used to describe the indexes of the VCLUI were obtained from field surveys. The geospatial data (e.g., the elevation data) were downloaded from the Resource and Environment Data Cloud Platform (http://www.resdc.cn (accessed on 15 October 2019)). Baiquan County villages’ administrative boundaries were also downloaded from the Resource and Environment Data Cloud Platform (http://www. resdc.cn (accessed on 15 October 2019)). During acquiring the survey data, the necessary information of 186 administrative villages was obtained by face-to-face interviews with

village members and village cadres. The other socioeconomic data were obtained from the development statistical yearbook of Baiquan County.

# 3.3. Pressure–State–Response Model and the Index System of the VCLUI

The PSR model was proposed by Canadian statisticians David J Rapport and Anthony Marcus Friend in 1979 and used to explore the sustainability of humans and nature [65,66]. The primary objectives of the PSR model were to clarify three logical questions of “what happened”, “why it happened”, and “how to respond” to an environmental problem. In land use systems, the PSR model helps understand the interactions between human and natural systems. Specifically, the PSR model considers the human activities, environmental conditions, and external feedback of the land system as the pressure, state, and response [67,68].

In the VCLUS, PSR models can commendably explain relationships among village members, cultivated land areas, and agricultural materials. In this study, the pressure was defined as the input intensity, the state was defined as the output level, and the response was defined as the land structure. Furthermore, the pressure was represented by the input that village members exerted on cultivated land, including the capital, labor, and agricultural material. The state was represented by the output under the input intensity of cultivated land use, including regional crop yield and village member’s income. The output reflected the relief degree of the pressure, which was considered to be a passive result of the interactions among sub-VCLUS elements. The responses were expressed by the land structures of planting proportion, cultivation scale, and disaster governance. The land structure directly affected the input intensity and indirectly affected the output per unit of cultivated land. During cultivated land use processes, a logistic circle would be summarized among input intensities, output levels, and land structures.

This study established an evaluated indicator system of the VCLUI using the PSR model based on the aforementioned theoretical analysis. The indicator system was divided into target layers, criterion layers, and index layers. The target layer included the intensity degrees of cultivated land use. The criterion layer had the input intensities (pressure), output levels (states), and land structures (responses). Following previous studies, the index layer contained 12 indexes, such as the fertilizer input, crop yields, and per capita cultivated land scales. The detailed index meanings are shown in Table 1. The visualization of the indexes is shown in Figure 3.

Table 1. Indicator system of cultivated land use intensification.   

<table><tr><td>Target Layers</td><td>Criterion Layers</td><td>Index Layers</td><td>Target Directions</td><td>Formulae and Units</td><td>Index Weights</td></tr><tr><td rowspan="5">Intensive degrees of cultivated land use</td><td rowspan="5">Input intensity</td><td>Fertilizer input</td><td>+</td><td>Fertilizer purification application amount/cultivated land area (kg/ha)</td><td>0.0691</td></tr><tr><td>Pesticide input</td><td>+</td><td>Total pesticide application amount/cultivated land area (kg/ha)</td><td>0.0744</td></tr><tr><td>Technical input</td><td>+</td><td>Total power of agricultural machinery/cultivated land area (kw/ha)</td><td>0.1228</td></tr><tr><td>General labor input</td><td>+</td><td>Total number of general labor/cultivated land area (person/ha)</td><td>0.0318</td></tr><tr><td>New labor input</td><td>+</td><td>Total number of large planters, family farms, and agricultural cooperatives/cultivated land area (person/ha)</td><td>0.1406</td></tr></table>

Table 1. Cont.   

<table><tr><td>Target Layers</td><td>Criterion Layers</td><td>Index Layers</td><td>Target Directions</td><td>Formulae and Units</td><td>Index Weights</td></tr><tr><td rowspan="3">Output levels</td><td>Grain yield per area</td><td>+</td><td></td><td>Grain output/cultivated land area (kg/ha)</td><td>0.1007</td></tr><tr><td>Agricultural output value per area</td><td>+</td><td></td><td>Agricultural output value/cultivated land (yuan RMB/ha)</td><td>0.0926</td></tr><tr><td>Agricultural output value per capita</td><td>+</td><td></td><td>Agricultural output value/village member papulation in agricultural production (yuan RMB/person)</td><td>0.0756</td></tr><tr><td rowspan="4">Land structures</td><td>Scale operation area</td><td>+</td><td></td><td>Scale operation area of large planter, family farm and agricultural cooperative/cultivated land area (%)</td><td>0.1373</td></tr><tr><td>Cultivated land per capita</td><td>+</td><td></td><td>Cultivated land area/total village member population (ha /person)</td><td>0.0061</td></tr><tr><td>Cash crop ratio</td><td>+</td><td></td><td>Cash crop area/cultivated land area (%)</td><td>0.1475</td></tr><tr><td>Erosion area ratio</td><td>-</td><td></td><td>Erosion ditch area/cultivated land area (%)</td><td>0.0015</td></tr></table>

# 3.4. Comprehensive Evaluations

This study adopted a multifactor comprehensive evaluation method to calculate the VCLUI of Baiquan County [67]. The critical steps of this method are selecting the evaluation indexes and calculating the index weights. The specific equation of this method is as follows:

$$
S _ {i} = \sum_ {j = 1} ^ {m} w _ {j} \cdot p _ {i j}, i = 1, \dots , n, \tag {1}
$$

where $S _ { i }$ is the intensive degree of cultivated land use, $p _ { i j }$ indicates the evaluation index value, and $w$ denotes the weight. The process of setting the weights of the evaluation indexes was as follows: (1) a range of standardization methods (specific formulas were omitted in this study) were adopted to standardize the evaluation indexes and (2) the index weights were determined using an entropy weight method and an expert scoring method (the specific formula was omitted in this study).

# 3.5. Correlation Analyses

To accurately measure correlations between different elements of the VCLUI, a unitary linear regression model was used in this study [69]. Moreover, this study explored the relationships among input intensities, output levels, land structures, and intensification using a significance testing method. The method’s principle was to determine the fitting degrees of the regression curves through the values of $\mathbb { R } ^ { 2 }$ . The closer the values of $\mathbb { R } ^ { 2 }$ were to 1, the better the relevant effects of the proper lines were. Meanwhile, the closer the values of $\mathbb { R } ^ { 2 }$ were to 0, the poorer the fitting results of the appropriate lines were. The study used the correlation and regression analysis tools to explore the correlation between the different elements of the VCLUI.

![](images/ca5f4e2a30403ba019b2b47546dffa8c4e6c4d7094ac80d1cba4cd3dc2a202c4.jpg)  
a.Fertilizer input

![](images/3a1b2f974c1d4912751f5070eb28bce258267c5567d8d5863ca9fc8e41b0e9cf.jpg)  
b.Pesticide input

![](images/aaa6407b8fdafc42aaa3c35b41081a319c30ec428e0487c605e87227e79e6bee.jpg)  
c.Technical input

![](images/7f81e8dec228f09d2c45072633967031b91348fb721031587ecc850f067caa5e.jpg)  
d.General labor input

![](images/9681bbc5a594d65c2b90952b2ed2dcd28752dade07a0490dcb89911f34363804.jpg)  
e.New labor input

![](images/15e42ebe85eb8d99a4d7582c03490230e71801550e6f7ec924abcdfdc4d2d2e0.jpg)  
f.Grain yield per area

![](images/c449e17a4142d7424516b4ba25bba838850459361873d87f1993433f0bddda39.jpg)  
g.Agricultural output value per area

![](images/6a3bc5039d10c8338a49d9bb3b2c805f0929d8ffb924bc911390a9058d325879.jpg)  
h.Agricultural output value per capita

![](images/0d9b4c4a4d8ea815236097453ce922cb4b73c7f5ae7a04b46dec21d41888033e.jpg)  
i.Scale operation

![](images/8ad587307d1e763a364ba12a85fecef219d6890a2caa5f50892d9c0e566be46c.jpg)  
j.Cultivated land per captia

![](images/561d2d421c3685abf03e79d2b6c0629629133badc0a7a50da91d7495fc36dd9d.jpg)  
k.Cash crop ratio

![](images/11496d5b8b7b0e5b4228626e1b2b93a822538f95452170431e7d28e524447c4d.jpg)  
l.Erosion area ratio

![](images/3af50363f42e381b8145b6726a4d6f0a9719fc34e30641fdb5c5ecb2f587cd6e.jpg)  
Ilevel

![](images/d9d6076b35a05de20300755dd1aa5ef727da787ab324344aa1dc155903569be6.jpg)  
Ilevel

![](images/beebf77b67f9cf810e46d4b41b490358b7192014a85097000417c983527ea337.jpg)  
III level

![](images/c31051f22cbbcf8c1b53ff608ee175a0492110d26b1e88bc5ee852726a0d29de.jpg)  
IVlevel   
0   
  
  
5   
km   
Figure 3. Indexes of cultivated land use intensification in Baiquan.

# 4. Results

# 4.1. Spatial Variation in the VCLUI

# 4.1.1. Intensive Degrees of Cultivated Land Use

The average intensive degree (ID) of cultivated land use was 0.53 in 2018, and $2 5 . 2 7 \%$ of the evaluation units’ IDs ranged between 0.31 and 0.42. The low ID value indicated that the cultivated land use in Baiquan County required optimization.

Based on the ID values, the villages could be classified into four categories: I, II, III, and IV, using the natural break method (Figure 4). The number of villages that were at levels I or II was 118. Besides, there were 68 villages at levels III or IV. Figure 4 illustrates the spatial variations in the IDs in Baiquan County. Villages at levels I and II locates in the rolling hill and shallow mountain of the county. The spatial patterns of the ID values matched well with the distributions of high-quality water and soil resources. The villages

at levels III or IV concentrated in the southwestern section of the county, which has rich water resources, well-run irrigation facilities, and right heat conditions. Furthermore, the villages at level IV scattered near the seats of the county or main townships. These results showed that the economic location has a significant impact on the ID.

![](images/c2e880b25c66828b4ab0d48c72859db7cab01bde51b4c469c4cb4b4f21177457.jpg)  
Figure 4. Distribution of the intensive degrees of cultivated land use.

# 4.1.2. Input Intensities

It was found that the input intensity (IN) values in Baiquan County displayed a very large range. Specifically, the highest and lowest values of IN in Baiquan County were 0.71 and 0.07, respectively. Moreover, the average IN value was 0.25, and there were 125 villages with values lower than 0.25. These results indicated that the IN was relatively low in the county.

Figure 5 shows the significant spatial variations in the IN in the county. It was found that the villages at level IV were scattered within the county seat or main town government area. Moreover, the villages with the IN level III value were to be mainly distributed in the southwestern section of the county, near the Shuangyang River basin. The level I villages were located in the rolling hill and shallow mountain of the county with greater slopes. Generally, the investment of capital, technology, and labor (particularly new types of labor) factors was sufficient in the villages at levels III and IV, which mainly located in flat plains with right economic development strategies.

# 4.1.3. Output Levels

The average value of the output index (OU) was 0.15 in Baiquan, and the standard deviation was 0.062. Moreover, the number of administrative villages below the average level was 108, indicating that Baiquan County’s output was also low.

As detailed in Figure 6, the OU values of villages in the southwestern section of the county were typically significantly higher than those of other county sections. The distributions of OU values showed a decreasing pattern from the north to the south. Therefore, when combined with the spatial distributions of indexes associated with output (Figure 3), it was found that the spatial patterns of the new labor were similar to those of the OU. This result indicated that the greater the proportion of new labor in the agricultural

population, the higher cultivated land use efficiency in large-scale scenarios. Furthermore, it was speculated that the changes in planting structure were caused by the agricultural market, which could also be a primary factor potentially affecting the output of cultivated land use.

![](images/1008a0e3dbe7281601cd07caee22a28c9ba267dd9da6dd3ce963692cea5e6e9b.jpg)  
Figure 5. Distribution of the input intensities of the cultivated land use.

![](images/e23675a4ff8aa39ce3b03f6bb7071471fa5a9bdb2054ec53b9f943e076264e4a.jpg)  
Figure 6. Distribution of the output level of cultivated land use.

# 4.1.4. Land Structures

The average value of the land structure (LS) in Baiquan County was 0.14. There were 121 administrative villages with LS values below the middle level. Moreover, the LS showed a significant spatial variation. As shown in Figure 7, the number of administrative villages with LS levels of III and IV was 53, and 133 were categorized with LS levels of I and II. LS distributions were mainly affected by the cultivated land’s management scales and the cash crops’ planting structures. As a result, there were significant spatial variations observed in the county. This study compared those findings with the index data and found that the scales of the operational areas of cultivated land were significantly affected by the complex topography of the county. Moreover, the planting structures of the cash crops were dependent on the conditions of the water resources. It was also believed that the land structure might mainly be affected by village members’ planting experiences.

![](images/866a4ea4fc11ffd5358ab380856f97a834c3cb57cc41a7d8921c3a85ed78f855.jpg)  
Figure 7. Distribution of the land structure of cultivated land use.

# 4.2. Correlations among the VCLUIs

# 4.2.1. Correlation between the Intensity Degrees and the Elements

According to the regression results (Figure 8), correlations between the ID–IN and the OU–LS passed the significance test at the 0.05 level. The R2 values of the regression models were 0.68, 078, and 0.70, respectively. Combining these findings with the VCLUI framework, we found that the interactions among elements of the VCLUS could directly affect the VCLUI. It was observed that within a specific space–time, the input intensity and the land structure could restrict and promote each other to obtain the output. Therefore, the ID was considered to be a comprehensive condition of cultivated land use. That the logical relationship further explained why the correlation coefficients between ID and OU were higher.

![](images/a07569556589b3b2c20bd6286339c2cd3777bbe20d95bc6f16593d69f2153b5b.jpg)

![](images/42dca4deac7fd114a20c079b85adf1aacd1d868144d69d670aa01798be31aeda.jpg)

![](images/f0af4345272ed06e6f9f097990592806898002f0e97f2315eca081e1f46f131f.jpg)  
Figure 8. The left figure is the correlation between the intensification and the input intensity, the middle figure is the correlation between the intensification and the output level, and the right figure is the correlation between the intensification and the land structure.

# 4.2.2. Correlations among the Elements of the VCLUIs

This study carried out further regression analyses to analyze reasons for variations in the correlations among the ID, IN, OU, and LS. The results revealed that the correlations between the IN and OU (0.61), the IN and LS (0.62), and the OU and LS (0.58) were significant at the 0.05 level (Figure 9).

![](images/70923c46f470e2eff3da1a64421302424a2827c859ad30249d22c492f5cbea62.jpg)

![](images/66401009fe4c5c902db7583251d2ca7df5e9ffbcd1fadb75ee49241c687f333b.jpg)

![](images/ac6543f891f591050abceff0ac58d0b12c63b4246904acc0f035db336c22f66a.jpg)  
Figure 9. The left figure is the correlation between the output level and the input intensity, the middle figure is the correlation between the land structure and the input intensity, and the right figure is the correlation between the output level and the land structure.

Besides, the IN and OU’s positive relationships illustrated that greater amounts of capital, agricultural materials, and labor were invested per unit of cultivated land; thus, the cultivated land would have a larger output. The correlation coefficients between the IN and LS indicated an increase in new labor helped improve the cultivated land’s scale management. Meanwhile, scale management was assumed to increase the utilization efficiency of capital and agricultural materials. It was observed that the IN and LS were mutually reinforcing factors, which optimized the allocation of cultivated land to a certain extent. The relationships between the OU and LS indicated that increasing the operational areas could improve cultivated land use efficiency. It was also found that expanding the proportions of cash crops with a high economic value could potentially increase the economic benefits of cultivated land use.

# 5. Discussion

# 5.1. Interpretation of the Findings

This study analyzed cultivated land use intensification in the study area using a PSR model framework. The VCLUI index revealed the sufficient pressure of the VCLUS from the dimensions of the input intensity of the available capital, agricultural materials, and labor and identified the output state of the crop yields and income levels. Besides, effective

responses were measured using the land structure of the VCLUS, including the cash crop rates and scales of the operational areas. Generally, the VCLUI in Baiquan County were low levels, and villages’ intensification levels varied significantly. The input intensities, output levels, and land structures displayed significant variations among different villages in the study area. It was determined that the low intensification of cultivated land use was mainly due to the low output levels and input intensities. This result was mostly because it was difficult to improve the input intensities and output levels, particularly in the mountainous and hilly areas where the hydrothermal conditions were uneven at higher elevations. Furthermore, villages with the lowest input intensities were commonly located far from townships with good social and economic development. In those locations, the planting structures were typically relatively simple food crops.

In this study, the subsystems’ elements were superior in the villages with high intensification compared with villages with low intensification. Moreover, villages with high intensification were more likely to be distributed in low altitude plain regions of the study area, where the farmland was more concentrated and contiguous due to the abundant water resources. The good tillage characteristics of these areas were expected to increase the operational ability of mechanized farming processes. Subsequently, villages with high intensification were concentrated near developed socioeconomic centers in the plain areas. The planting proportions of the cash crops were found to meet the demands for vegetables and fruits, thereby improving the socioeconomic centers’ intensification. This trend of spatial evolution was found to conform to the theory of energy location. Furthermore, it was found that the VCLUI was determined by the physical geographical locations and impacted by the socioeconomic development levels. The high intensification of villages in 2018 enhanced the new labor factor, including larger farms, family farms, and planting cooperatives, which expanded the management scales of the cultivated land.

# 5.2. Advantages of the VCLUI Theoretical Framework

This study incorporated the PSR model into the VCLUI theoretical framework to analyze the interactions among the natural, social, and economic subsystems (Figure 10). The flow between subsystems connected the telecoupling systems [58–60,69], in which the natural subsystems included the cultivated space systems. The social subsystems included the hub systems, and the economic subsystems included the material systems. Meanwhile, every two subsystems interacted to form three interrelated parts: pressure, state, and response. This paper found that the variations in the VCLUIs were mainly dependent on the new labor-driven social subsystem differences. Therefore, the social subsystem’s main agents were large plantations, family farms, and agricultural cooperatives. By combining the results with the actual survey data, this study found that the added new labor could change the cultivated land use by adopting more advanced farming techniques and efficient machinery, and updating the planting structures and scales. Moreover, the new labor could dynamically adjust the planting schemes according to the natural subsystem’s conditions. Meanwhile, although consistently planting crops with high yields and high added value requires more capital and agricultural material input, it has promoted villages to develop toward desired expectations.

Moreover, the PSR model has been demonstrated to be a useful tool to understand the complex process of the VCLUI. This paper summarized the VCLUI circle of input press output state structure response input press based on the PSR model’s theoretical knowledge. Specifically, cultivated land use intensification mainly aims to optimize farmland resource allocation, improve the comprehensive capacity of agricultural production, and increase village members’ income. It was common practice for village members to increase input intensities using techniques and their own planting experiences to improve output. Meanwhile, this study observed that the new labor and total machinery power’s input intensities, which the Chinese government currently promotes, are crucial to the VCLUI. Furthermore, output efficiency was determined to be an essential basis for agricultural production practices within the preconditions of constant planting structures. According

to this study’s survey, the general labor force would not easily change their planting plans due to their farming habits and operational practices. In contrast, the new labor force had opposite opinions regarding the change. The agreement that the advanced farming practices required re-evaluations was the main reason for the new labor force’s high output in the study area. Additionally, when the output levels were very unsatisfactory, village members tended to change the planting scheme or the land structure (for example, the cash crop planting rate and the management scale). As a result, input intensities were adjusted to meet expected output levels better. Therefore, the VCLUI was expected to be realized by the continuous optimization of cultivated land use.

![](images/b905a6b5eaa9724c5458f28e694f350b1ff2da65e12038e7c0aeb2ccae9fa919.jpg)  
Figure 10. Logistics of the village cultivated land use intensification (VCLUI) based on the pressure– state–response (PSR) model.

Another notable contribution of this study was the evaluation of cultivated land use intensification at the village scale. In a village, the village committee is the central coordinating body and is mainly concerned about village members’ interests. These behaviors guide the committee to optimize the land structure and reasonably increase inputs. In this study, the spatial patterns of the VCLUI indicated regional differences in the cultivated land use status using different agents. Therefore, the VCLUI systematically and directly explained how other agents promoted cultivated land use intensification. The study was found this result to be more effective than the cultivated land use intensification of the single agent in accurately evaluating agricultural management methods.

# 5.3. Types of VCLUI and Recommendations

This study divided the study area into four typological areas and eight hierarchical areas to reveal the spatial patterns of the VCLUI more clearly (Table 2). Specifically, typological areas were divided by both input intensities and output levels, while hierarchical areas were subdivided according to the typology of land structures. In addition, based on

the characteristics of the typological areas, the development directions of each area were proposed as the characteristic planting areas, upgrading transformation areas, developing guide areas, and key lifting areas.

Table 2. Types and directions of the VCLUI in Baiquan County.   

<table><tr><td>Types</td><td>Characteristics</td><td>Development Directions</td></tr><tr><td>High input and high output</td><td>Cultivated land is concentrated and contiguous in the plains; Scales of the average households&#x27; cultivated land areas are large; Proportions of new labor are high; Total power of the agricultural machinery is sufficient; Soil and water resources are abundant</td><td>Characteristics of the planting areas of cultivated land use</td></tr><tr><td>High input and low output</td><td>Cultivated land areas are scattered in the hill areas; Scales of the average households&#x27; cultivated land areas are large; Proportions of the new labor are high; Total power of the agricultural machinery is sufficient; Soil and water resources are not abundant</td><td>Upgraded transformation areas of cultivated land use</td></tr><tr><td>Low input and high output</td><td>Cultivated land areas are concentrated and contiguous in the plains; Scales of the average households&#x27; cultivated land area are large; Proportion of the new labor is low; Total power of the agricultural machinery is not sufficient; Soil and water resources are abundant</td><td>Developing guide areas of cultivated land use</td></tr><tr><td>Low input and low output</td><td>Cultivated land areas are scattered in the hilly areas; Scales of the average households&#x27; cultivated land are areas low; Proportion of the new labor is low; Total power of the agricultural machinery is not sufficient; Soil and water resources are not abundant</td><td>Key lifting areas of cultivated land use</td></tr></table>

The characteristic planting areas of the VCLUI were located in the plain areas with average slopes of $1 . 1 0 ^ { \circ }$ , which were observed to be more conducive to large-scale production activities. Village members were able to plant more cash crops with the help of rich water resources. Additionally, the higher new labor rate had relatively increased the per capita cultivated land area for the implementation of improved farming machinery. Therefore, these areas had higher input intensities and high output levels. Although the high input intensities of the upgrading transformation areas of the VCLUI were similar to those of the characteristic planting areas, hilly locations were not as conducive to large-scale cultivation practices. In prospective agricultural development areas, cultivated land use structures were found to require appropriate changes through land remediation projects to increase the planting of cash crops. It was believed that maximum output benefits could then be obtained to the greatest possible extent. Meanwhile, the intensification of the developing guide areas displayed distinct differences from the upgrading transformation areas. The contiguous and flat cultivated land was very suitable for large-scale cultivated land operations. However, the high general labor rates tended to lead to low input intensities. At the same time, the good land structure and geographical locations promoted high output levels. The result of this study shows that low input and low output were in the rolling hill and shallow mountains of the county. When village members promote the intensification of cultivated land use, more natural subsystem elements need to be protected, such as bird biotopes, vegetation organisms, and microorganisms. The natural elements maintain the sustainability of the physical and chemical states of cultivated land. Therefore, it was considered that in that type, not only should the input intensities be increased, but close attention should also be paid to natural security. This study found that the key lifting areas of cultivated land use were noteworthy and significant in regard to their overall poor conditions. Although measures such as leveling the farmland and building ditches and encouraging the establishment of new labor (large plantations, family farms, and agricultural cooperatives) have been vigorously carried out, further actions will be needed to improve the VCLUI in the key lifting areas in the future.

More importantly, spatial patterns of the four typological areas of the VCLUI demonstrates that the importance of high-water for the VCLUI. Under the same input, the cultivated land has a high output with abundant water resources or superior water conservancy

facilities. Therefore, the VCLUI of Baiquan in the future is to strengthen ways of intensive use according to local conditions and improve the construction of agricultural infrastructure to enhance the utilization rate of water resources and cultivated land protection effect.

# 6. Conclusions

The present study investigated the spatial differentiation of the VCLUI in Baiquan County based on a PSR model. Moreover, an overall framework of the VCLUI was established based on the VCLUS to provide system insight to understand and evaluate the VCLUI. The results found that cultivated land use required optimization in Baiquan County. Moreover, the analysis results indicated that villages with higher intensive degree values were commonly located in areas with high-quality water and soil resources and well-run irrigation facilities. With the IN, OU, and LS relationships, we found that villages with high ID values were expected to have a more immense amount of new labor (e.g., larger farms, family farms, and agricultural cooperatives). Besides, it observed interactions among elements of the VCLUS to impact the VCLUI potentially. Specifically, the IN and LS could not only restrict but also promote each other to obtain the OU. Meanwhile, expanding the management scales of cultivated land and increasing the new labor force could increase the cash crop ratios and economic benefits. Therefore, this study’s findings provide important guidance for future agricultural production strategies and agricultural land use intensification investigations at the microscale.

VCLUS based on PSR model is a systematic work. In this study, we established the PSR model of the village cultivated land use system to explain the interaction between system elements and agricultural management behavior. However, the influence factors of village cultivated land use system are complicated, and some of them are difficult to quantify, such as land property rights, village member’s management behavior, etc. This paper only researched precisely these factors as hypotheses. Therefore, it is needed to integrate these factors into the index system that could study spatiotemporal differentiation of VCLUS and its influencing mechanism in future studies.

Author Contributions: Conceptualization, Q.L. and G.D.; methodology, Q.L.; validation, Q.L., Z.D. and G.D.; formal analysis, Z.D.; investigation, Q.L., Z.D. and G.D.; resources, G.D.; data curation, G.D.; writing—original draft preparation, Z.D.; writing—review and editing, Q.L. and A.Y.; visualization, Z.D.; supervision, Q.L. and A.Y.; project administration, Q.L.; funding acquisition, Q.L. All authors have read and agreed to the published version of the manuscript.

Funding: This research was funded by National Natural Science Foundation of China, grant number 41901208, Youth Talent Project of Northeast Agricultural University of China, grant number 18QC10, and Opening Fund of Key Laboratory of Research on Rule of Law, grant number CUGFP-1905.

Institutional Review Board Statement: Not applicable.

Informed Consent Statement: Informed consent was obtained from all subjects involved in the study.

Data Availability Statement: The data presented in this study are available on request from the corresponding author. The data are not publicly available due to privacy or other restrictions.

Acknowledgments: We thank Mai Li and Shijin Qu for their detailed and helpful reviews of an early draft of the manuscript. We also express gratitude to the Northeast Agricultural University professionals who have participated in the research and survey.

Conflicts of Interest: The authors declare no conflict of interest.

