# Exploring global interregional food system_s sustainability using the functional regions typology

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:44:42.527475+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Fridman et al. - 2021 - Exploring global interregional food system_s sustainability using the functional regions typology.pdf
- Year: unknown
- DOI: 10.1016/j.gloenvcha.2021.102276
- OA status: closed
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: closed access (subscription only)

## Copyright-Safe Summary
This paper examines how sustainable the global food system is when viewed as an interconnected network of producing and consuming regions. It focuses on four staple crops - wheat, rice, maize, and soybeans - which together supply roughly half of global food calories and occupy about half of harvested cropland.

The authors develop a global typology of agricultural functional regions at high spatial resolution. Using self-organizing maps, they cluster crop-growing grid cells based on yields, harvested area, blue and green water requirements, water availability, soil erosion per ton, and species loss per ton. This yields 12 functional region types that differ in productivity, irrigation needs, and ecological impacts such as soil loss and biodiversity loss.

They then couple this typology to FAO production, trade, and food-balance data, and to a trade-by-origin reconstruction that traces both direct and feed-embedded crop flows between more than 160 countries. Calorie flows from each functional region to each country are calculated, distinguishing domestic supply from imports. A simple sustainability metric compares each country’s reliance on the most suitable regions (high yield, low impact) versus regions with high environmental impacts (water-stressed, erosion-prone, or biodiversity-sensitive).

The analysis shows that over one-third of global calorie intake from these staples originates in high-impact regions, while only about one-fifth comes from the most suitable regions. Water-stressed areas account for a small share of cropland but more than a third of production and most irrigation water use. Ecologically vulnerable regions produce little volume but drive a large fraction of projected species loss. Trade generally shifts importing countries’ supplies toward more suitable production regions, reducing per-ton impacts, but also creates telecoupled tradeoffs by externalizing soil erosion, water depletion, and biodiversity loss to exporting regions.

This study is explicitly about telecoupling and interregional (meta)coupled food systems. It provides a spatially explicit framework to identify where international trade improves or undermines food-system sustainability and highlights overlooked risks, such as biodiversity loss in low-income countries that rely heavily on domestic production.

## Structured Metacoupling Extraction

### Coupling Classification
- Strongly telecoupled global food system via staple trade and environmental impacts
- Pericoupled regional producer importer clusters linked by functional regions
- Intracoupled national food systems dominated by domestic staple production

### Intracoupling
#### Systems
- National food systems dominated by domestic wheat rice maize soybean production
- Functional regions within countries classified by yields water stress and biodiversity impact
- Domestic ecological vulnerable regions with high species loss and staple dependence
#### Flows
- Domestic flows of staple calories from local croplands to national consumers
- Use of domestic blue and green water for staple cultivation
- Soil and biodiversity degradation within national agricultural landscapes
#### Agents
- National governments managing agriculture and trade policies
- Domestic farmers and agribusinesses producing staple crops
- National statistical and environmental agencies providing data and regulation
#### Causes
- Rising national food demand from population and income growth
- Historical cropland expansion and intensification within country borders
- Limited trade capacity in low income countries constraining import options
#### Effects
- Concentrated soil erosion and water stress in key domestic production regions
- National food security risks where staples come from high impact regions
- Loss of local and global species reducing future ecosystem service potential

### Pericoupling
#### Systems
- Neighboring or regional countries sharing similar functional regions
- Regional trade blocs exchanging staples and environmental pressure
- Transboundary water stressed agricultural zones across adjacent states
#### Flows
- Regional staple trade reallocating calories among nearby countries
- Cross border outsourcing of irrigation water demand and soil erosion
- Movement of embodied biodiversity impacts within regions
#### Agents
- Regional trade organizations and bilateral agreements
- Exporters and importers operating within regional markets
- Regional development and conservation initiatives
#### Causes
- Geographic proximity and shared agroecological conditions
- Regional infrastructure and market integration facilitating trade
- Similar dietary patterns driving demand for the same staples
#### Effects
- Regional clustering of water stressed and soil loss prone production
- Shared vulnerability to environmental degradation in regional breadbaskets
- Opportunities for regional cooperative governance and compensation schemes

### Telecoupling
#### Systems
- Major exporting regions like rainfed and irrigated functional regions
- Import dependent countries including islands and arid economies
- Ecologically vulnerable low income regions supplying domestic staples
#### Flows
- International trade of wheat rice maize soybeans and derived calories
- Embodied flows of irrigation water soil erosion and species loss
- Potential future flows of genetic resources from biodiverse regions
#### Agents
- Global traders agribusiness corporations and commodity chains
- International organizations such as FAO and World Bank
- Policy actors designing certification and conservation payment schemes
#### Causes
- Globalized food demand and specialization of production regions
- Price signals and comparative advantage in land and water productivity
- Limited domestic resources prompting imports from distant regions
#### Effects
- Displacement of environmental impacts from consumers to remote producers
- Interregional tradeoffs between food provision and ecosystem integrity
- Telecoupled risks from degrading key exporting regions sustainability

### Cross-Coupling Interactions
- Trade links domestic high impact regions with remote most suitable regions altering national sustainability metrics
- Low income biodiverse countries remain domestically focused reducing potential global genetic resource flows
- Imports can reduce domestic pressure yet intensify water and soil stress in exporting telecoupled regions

### Research Gaps or Limitations
- Focus on four staples excludes other important traded crops and livestock products
- Input datasets and clustering introduce considerable spatial and model uncertainty
- Human management factors like conservation practices and irrigation efficiency are simplified or omitted

### Search Keywords
- telecoupling interregional food systems functional regions
- global staple trade soil loss water stress species loss
- sustainability of national food supply and embodied impacts

### Extraction Confidence
high
