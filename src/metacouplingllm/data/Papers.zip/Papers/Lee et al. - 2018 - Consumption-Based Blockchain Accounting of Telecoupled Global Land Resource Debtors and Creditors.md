Editorial

# Consumption-Based Blockchain Accounting of Telecoupled Global Land Resource Debtors and Creditors

Huey-Lin Lee 1, Yu-Pin Lin 2,* ID , Joy R. Petway 2, Josef Settele 3 and Wan-Yu Lien 2

1 Department of Economics, National Chengchi University, Taipei 116, Taiwan; hlee@nccu.edu.tw   
2 Department of Bioenvironmental Systems Engineering, National Taiwan University, No. 1, Sec. 4, Roosevelt Rd., Taipei 10617, Taiwan; d05622007@ntu.edu.tw (J.R.P.); wanyulien@gmail.com (W.-Y.L.)   
3 Department of Community Ecology, Helmholtz-Centre for Environmental Research—UFZ, Theodor-Lieser-Str. 4, 06120 Halle, Germany; josef.settele@ufz.de   
Correspondence: yplin@ntu.edu.tw; Tel.: +886-2-3366-3467

Received: 11 April 2018; Accepted: 12 April 2018; Published: 24 April 2018

![](images/d334b66863c444c6446153cf97fee0623340d33d5eee9a0866c96f1df4496019.jpg)

- -

Since global agricultural trade reflects a ‘telecoupled’ land use network of countries wherein consumption in one country results in flows affecting land use in another country, measuring country-specific resource use along telecoupled socioeconomic and environmental supply chains can provide useful information for efforts to achieve Sustainable Development Goals (SDG) [1–3]. While land use statistics record how land is economically exploited, assessing resource use tradeoffs with conflicting environmental and economic metrics [4] remains challenging. Yet, sustainability assessments are limited since national accounts often exclude landscape function losses which are induced by economic activities [5], and population growth projections further imply that future assessments will exclude social environmental impacts to prioritize global food needs [6]. Further, stakeholders often lack the enthusiasm to efficiently execute agreed-upon solutions to common environmental problems [7], or worse, the numerous proposed solutions to boost both food production and biodiversity remain ineffective [6] without concerted international efforts. While the United Nations’ System of Environmental and Economic Accounting (SEEA) links biophysical conditions with economic activities to define spatially explicit tradeoffs [4,8], individual countries with distinct land resources for agricultural livelihood still require land use indicators and threshold levels [3] to gauge their progress towards the SDGs. Using blockchain technology for a decentralized immutable public consumption record [9–11], with the aim of ensuring trust and engageability, may be advantageous. However, some argue that inefficiencies and ethical issues exist if this method is applied in science [9–11]. To secure global land use sustainability, blockchain technology can facilitate the identification of “debtor” and “creditor” countries and ensuring transparent multilateral monetary flows between globally telecoupled land systems. A blockchained record of land use transactions, based on indicators, could be a precursor to a market-based instrument whereby debtor countries’ resource exhaustion and ecosystem service demand translates into equitable reimbursements toward creditor countries’ environmental management program and policy measures.

Acknowledgments: The authors would like to thank the Ministry of Science and Technology of the Republic of China, Taiwan, for financially supporting this research under Contract No. 105-2621-M-002-003-MY3.

Conflicts of Interest: The authors declare no conflict of interest.

