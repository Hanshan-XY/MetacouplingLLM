# Research progress and prospect of telecoupling of human-earth system

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T05:56:52.897339+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Ma et al. - 2020 - Research progress and prospect of telecoupling of human-earth system.pdf
- Year: unknown
- DOI: 10.18306/dlkxjz.2020.02.012
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Review\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This article is a Chinese-language review of the telecoupling and metacoupling frameworks as applied to coupled human-Earth (human-nature) systems. Its geographic scope is global, with many examples from China (especially major urban agglomerations and ecological projects) and international trade and conservation cases. The system context is broad: it covers climate teleconnections, globalization, urbanization, ecosystem services, land systems, and policy instruments that link distant places.

Using a structured literature search (English and Chinese databases, screening down to about 150 geography-related papers and intensively reading a subset), the authors synthesize research in four dimensions: theory building, empirical evidence, key thematic domains, and methods. They summarize how telecoupling was developed as a framework for distant interactions among coupled human-natural systems through flows, agents, causes, and effects, and how it was later generalized into the metacoupling concept that integrates internal, nearby, and distant couplings.

Empirical evidence is organized around three drivers: large-scale environmental teleconnections, economic globalization (trade, investment, migration, tourism, information), and multi-scalar urbanization. The review highlights applications in three main domains: (1) ecosystem service flows, evaluation, and management across regions and scales; (2) socioeconomic and environmental consequences of distant interactions (for biodiversity, emissions, livelihoods, infrastructure, and habitat fragmentation); and (3) land change science, including how distant drivers and cross-border land deals shape land-use and land-cover dynamics.

Methodologically, the paper discusses specialized GIS-based telecoupling toolkits and web apps, along with multi-region input-output models, material flow analysis, life cycle assessment, and environmental input-output analysis, noting their strengths and limitations for tracing cross-regional flows and impacts.

The article is explicitly about telecoupling and metacoupling. It concludes with research prospects: developing a human-Earth relationship network system theory, clarifying telecoupling mechanisms (especially around urbanization and interacting drivers), and designing regulatory tool sets (such as supply-chain interventions and ecological compensation) to govern distant interactions in support of global sustainability.

## Structured Metacoupling Extraction

### Coupling Classification
- Paper is a review of metacoupling, emphasizing telecoupling with links to intra and pericoupling.

### Intracoupling
#### Systems
- Urban agglomerations and internal human environment systems
- Single river basins with upstream midstream downstream segments
- Local human land relationship regional systems
#### Flows
- Local resource and ecosystem service use within one region
- Internal urban material and energy metabolism
- Short distance population commuting and service flows
#### Agents
- Local households farmers and residents
- Municipal and local governments
- Local enterprises and cooperatives
#### Causes
- Urbanization and internal land use change
- Local development policies and planning
- Household livelihood strategies and preferences
#### Effects
- Internal land cover conversion and soil degradation
- Local habitat fragmentation and biodiversity loss
- Urban environmental pressure and resource depletion

### Pericoupling
#### Systems
- Neighboring cities within large urban agglomerations
- Upstream and downstream regions within the same basin
- Adjacent rural urban continua
#### Flows
- Short to medium distance commuting and migration
- Regional trade of food water and energy
- Intercity infrastructure and transport connectivity
#### Agents
- Regional planning authorities and corridor managers
- Intercity logistics and transport firms
- Regional water and energy utilities
#### Causes
- Regional integration and specialization dynamics
- Infrastructure expansion such as highways
- Ecological restoration and compensation programs
#### Effects
- Redistributed environmental pressures among adjacent regions
- Changed regional ecosystem service provision
- Peri urban land conversion and rural marginalization

### Telecoupling
#### Systems
- Distant coupled human nature systems linked by trade migration or teleconnection
- Soybean production regions in Brazil and consumption regions in China
- Protected areas in China and international donor and tourism regions
#### Flows
- International trade of agricultural commodities timber and bioenergy
- Global flows of tourists migrants information and conservation funding
- Long distance flows of pollutants waste and atmospheric or oceanic materials
#### Agents
- Farmers smallholders and plantation companies in exporting countries
- Consumers retailers certifiers and NGOs in importing regions
- National governments international organizations and media outlets
#### Causes
- Globalization urbanization and changing consumption patterns
- Technological advances in energy transport and communication
- Climate variability teleconnections and large scale restoration policies
#### Effects
- Land use change deforestation biodiversity loss and habitat fragmentation
- Displaced environmental burdens and cross border pollution transfer
- Impacts on rural livelihoods food security and carbon emissions

### Cross-Coupling Interactions
- Metacoupling framework integrates intracoupling pericoupling and telecoupling across all distances
- Urbanization simultaneously drives local land change and distant resource appropriation via trade and migration
- Ecosystem service flows and restoration policies generate multi scale feedbacks among sending receiving spillover systems

### Research Gaps or Limitations
- Limited quantitative empirical applications of telecoupling and metacoupling frameworks
- Mechanisms linking teleconnection globalization and urbanization to telecoupling remain underexplored
- Few operational regulatory tools and governance instruments explicitly designed for telecoupled systems

### Search Keywords
- telecoupling metacoupling intracoupling pericoupling
- ecosystem service flows land change science globalization urbanization
- spillover systems smallholder livelihoods trade biodiversity carbon

### Extraction Confidence
high
