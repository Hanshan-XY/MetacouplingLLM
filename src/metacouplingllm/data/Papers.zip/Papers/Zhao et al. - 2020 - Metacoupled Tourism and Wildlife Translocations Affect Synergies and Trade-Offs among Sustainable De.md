Article

# Metacoupled Tourism and Wildlife Translocations Affect Synergies and Trade-Offs among Sustainable Development Goals across Spillover Systems

Zhiqiang Zhao $^ { 1 , 2 , * \oplus } \oplus$ , Meng Cai ${ } ^ { 3 } \textcircled { \backslash } .$ , Thomas Connor 2, Min Gon Chung $2 , 4 \textcircled { | | }$ and Jianguo Liu ${ \mathfrak { 2 } } _ { \bigoplus }$

1 Academy of Plateau Science and Sustainability, Xining 810016, China   
2 Department of Fisheries and Wildlife, Center for Systems Integration and Sustainability, Michigan State University, East Lansing, MI 48824, USA; connort2@msu.edu (T.C.); chungm13@msu.edu (M.G.C.); liuji@msu.edu (J.L.)   
3 School of Planning, Design and Construction, Michigan State University, East Lansing, MI 48824, USA; caimeng2@msu.edu   
4 Sierra Nevada Research Institute, University of California, Merced, CA 95343, USA   
￥ Correspondence: zhaozq@msu.edu

Received: 29 August 2020; Accepted: 15 September 2020; Published: 17 September 2020

![](images/17a700e0185d1f15670ba20d2953198b21a730b32af439f1b37d2f48cc1dfcaa.jpg)

- -

Abstract: Synergies and trade-offs among the United Nations Sustainable Development Goals (SDGs) have been hotly debated. Although the world is increasingly metacoupled (socioeconomicenvironmental interactions within and across adjacent or distant systems), there is little understanding of the impacts of globally widespread and important flows on enhancing or compromising sustainability in different systems. Here, we used a new integrated framework to guide SDG synergy and trade-off analysis within and across systems, as influenced by cross-boundary tourism and wildlife translocations. The world’s terrestrial protected areas alone receive approximately 8 billion visits per year, generating a direct economic impact of US $\$ 600$ billion. Globally, more than 5000 animal species and 29,000 plant species are traded across country borders, and the wildlife trade has arguably contributed to zoonotic disease worldwide, such as the ongoing COVID-19 pandemic. We synthesized 22 cases of tourism and wildlife translocations across six continents and found 33 synergies and 14 trade-offs among 10 SDGs within focal systems and across spillover systems. Our study provides an empirical demonstration of SDG interactions across spillover systems and insights for holistic sustainability governance, contributing to fostering synergies and reducing trade-offs to achieve global sustainable development in the metacoupled Anthropocene.

Keywords: sustainable development goals; synergy; trade-off; metacoupling; telecoupling; spillover systems; tourism; wildlife; protected area

# 1. Introduction

Enhancing synergies and reducing trade-offs among the 17 Sustainable Development Goals (SDGs) and related 169 targets [1], which were adopted by world leaders from 193 countries, is fundamental to realize the ambitious and transformative vision of socioeconomic and environmental sustainability on the planet Earth. Synergies emerge when multiple SDGs/targets are improved simultaneously. Trade-offs occur when efforts for achieving SDGs/targets hamper other SDGs/targets [2–6]. Since the adoption of the 2030 Agenda in 2015, many studies have focused on evaluating synergies and trade-offs among the SDGs/targets [7–11], yet less attention has been paid to the effects of actions on SDG interactions across geographical boundaries [6,12–16]. Recent studies noticed different impacts of consumption levels [12,13] and international trade [17] on the SDGs/targets between developed and developing countries, and another study indicated energy use changes in one local place may influence

progress toward SDGs of other areas [15]. In the socioeconomically and environmentally metacoupled planet [18,19], special attention to evaluating SDG synergies and trade-offs across boundaries is urgently needed. As processes at one place may enhance or hinder sustainability in both surrounding and distant areas [20], the SDGs may fail to make significant progress at the global level without a better understanding of how sustainable development efforts are metacoupled locally, regionally, and globally.

A new integrated framework, based on the concept of metacoupling [21], was introduced to evaluate SDG synergies and trade-offs within and across boundaries explicitly [6]. As a new frontier for global sustainability [22–28], the metacoupling framework addresses socioeconomic-environmental interactions within a system (i.e., intracoupling) and across adjacent (i.e., pericoupling) or distant systems (i.e., telecoupling) [21]. The metacoupling framework has been applied to many important issues, such as environment [29], energy [30], soil conservation [31], food trade [32], and fishery [22], and across different scales, such as smallholders [25], regional watershed systems [33], national energy network [30], and marine system at global scales [23]. It was only recently applied to SDG interactions and emphasized that the flows (e.g., tourism and trade) affect SDG synergies and trade-offs across boundaries [6,17].

The new framework [6] filled the research gap that spillover effects on SDG synergies and trade-offs across geographic boundaries were less understood [16], because one advantage of using the new framework to study SDG interactions is emphasizing spillover systems, defined as the systems that affect and/or are affected by the interactions between sending systems (e.g., exporting country) and receiving systems (e.g., importing country) [34,35]. In other words, spillover systems identify the areas that do not participate in a particular process but are influenced by it. Examining SDG synergies and trade-offs only within or between sending and receiving systems overlooks the complex interactions that may exist beyond the two systems. Moreover, the demonstrating cases of tourism to and panda loans from the Wolong Nature Reserve [6] are two examples of many metacoupled flows (of information, energy, people, organisms, goods, and matter) that increasingly connect the world. The flows influence SDG synergies and trade-offs when several targets or SDGs are positively or negatively affected by the flows from start to end, across boundaries [6,17].

Tourism, one of the most typical flows of people, is an important sector of the global economy and accounts for nearly $1 0 \%$ of jobs worldwide [36]. The contribution of tourism is also recognized in SDG 8 (decent work and economic growth) and target 8.9: “By 2030, devise and implement policies to promote sustainable tourism that creates jobs and promotes local culture and products [1].” Tourism in protected areas is among the fastest-growing sectors of the world’s tourism industry [37,38]. The world’s terrestrial protected areas alone receive approximately 8 billion visits annually, generating a direct economic impact of US $\$ 600$ billion [39].

Concerning the movement of wildlife, an increasing number of species have been translocated due to conservation purposes and trade. More than 5000 animal species and 29,000 plant species are traded as live specimens, fur coats, and dried herbs across country borders [40]. Legal international wildlife trade alone is estimated to be worth over US $\$ 320$ billion per year [41], and the demand for wildlife has grown rapidly, involving 233 countries and territories worldwide [40–42]. For instance, a total of 88,081 records of trade of live specimens for non-commercial purposes (e.g., educational, scientific, breeding, botanical gardens, and zoos) were reported between 1975 and 2017, and at least 49 countries and territories had more than 100 trade records (Figure 1). Moreover, wildlife trade has arguably contributed to zoonotic disease worldwide [43], such as the ongoing COVID-19 [44], which has infected over 23 million cases and resulted in more than 800,000 deaths as of 23 August 2020 [45].

![](images/45ae69c2c0814129adb46b3baff842a54064242dfb9b0e30e0a8120b7dc44373.jpg)  
(a)

![](images/b23149cc607a098310e05a2c3632921a520c618f01e4edada6dace80fb0b2c30.jpg)  
(b)   
Figure 1. (a) Trade of live specimens for non-commercial purposes between 1975 and 2017. A total of Figure 1. (a) Trade of live specimens for non-commercial purposes between 1975 and 2017. A total 88,081 records of trade of live specimens for educational, scientific, breeding, botanical gardens, and of 88,081 records of trade of live specimens for educational, scientific, breeding, botanical gardens, zoo purposes were reported, involving 233 countries and territories worldwide. Data wereand zoo purposes were reported, involving 233 countries and territories worldwide. Data were downloaded from the Convention on International Trade in Endangered Species of Wild Fauna and downloaded from the Convention on International Trade in Endangered Species of Wild Fauna and Flora (CITES) website (www.cites.org). (b) International live specimens trade flows (for the purposes Flora (CITES) website (www.cites.org). (b) International live specimens trade flows (for the purposes of educational, scientific, botanical gardens, and zoos) among 49 key countries and territories, among of educational, scientific, botanical gardens, and zoos) among 49 key countries and territories, among which the trade records are more than 100 from 1975–2017. Tick marks indicate the record number of trade (one thousand). Trade flow ribbons adjacent to a country, with the same color as the country, trade (one thousand). Trade flow ribbons adjacent to a country, with the same color as the country, indicate exports, and ribbons with arrows next to a country indicate imports. The total records can be downloaded from the Convention on International Trade in Endangered Species of Wild Fauna and Flora (CITES) website (www.cites.org).

Evaluating how those flows of people and wildlife may influence SDG synergies and trade-offs is urgently required, and can contribute to further understanding the drivers behind the synergies and trade-offs among SDG/targets across boundaries [6,12–16]. Building on the framework and Wolong case study [6], at global level, we synthesize 22 selected peer-reviewed studies focused on tourism and wildlife translocations, aiming to demonstrate how to use this framework to guide the analysis of SDG

synergies and trade-offs within the focal system (e.g., a protected area as a receiving system of tourists)analysis of SDG synergies and trade-offs within the focal system (e.g., a protected area as a receiving and across spillover systems (e.g., neighboring towns and villages of the protected area).system of tourists) and across spillover systems (e.g., neighboring towns and villages of the pr

# 2. Materials and Methods

# 2.1. The Framework of Metacoupled Tourism and Wildlife Translocations Affect SDG Synergies and Trade-Offs across Spillover Systems2.1. The Framework o

Here, we applied the new framework [6], which integrates the conceptual structure of metacoupling [21] and SDGs and targets [1], to assess synergies and trade-offs among SDGs withinHere, we applied the new framework [6], which integrates the conceptual structure of and across different systems due to tourism and wildlife translocations (Figure 2).

![](images/f07468be721aa839d2e715883300db7c285b054ee82f495c974a8a18a6f1691d.jpg)

![](images/0192322ff55f7e6ec61c9f3debb8339757455a45442356b3a5f8c93573bbb1ea.jpg)

![](images/17190f2dd9e694a8efb76fe417665a696a1fca4e34ac06586c3e45deb0a30f60.jpg)

![](images/023393e4313a95dba57d2c2c6b710bead49b448670a65991326242893f921faa.jpg)  
Figure 2. The cross-boundary tourism and wildlife translocations influence Sustainable Development Figure 2. The cross-boundary tourism and wildlife translocations influence Sustainable Development Goal (SDG) synergies and trade-offs within focal systems and across spillover systems. (a) The Goal (SDG) synergies and trade-offs within focal systems and across spillover systems. (a) The conceptual framework of metacoupling. Modified from [21]. (b) A protected area, as a focal system, receives tourists from sending systems (origin of the tourists). The effects of the metacoupled flows of enhance or compromise other SDGs both locally (i.e., within the receiving system) and across spillover tourists go beyond the directly related SDG 8 (decent work and economic growth), and may enhance or systems (e.g., neighboring areas). (c) The focal system can be a sending system of wildlife compromise other SDGs both locally (i.e., within the receiving system) and across spillover systems translocations. The effects of the wildlife translocations go beyond the directly related SDG 15 (life on (e.g., neighboring areas). (c) The focal system can be a sending system of wildlife translocations. land) and may enhance or compromise other SDGs both locally (i.e., within the sending system) and The effects of the wildlife translocations go beyond the directly related SDG 15 (life on land) and may across spillover systems. (d) The focal system also can be a receiving system (e.g., zoo), depending on enhance or compromise other SDGs both locally (i.e., within the sending system) and across spillover the direction of flows of wildlife translocations. The arrows between SDGs (in subfigures b, c, and d) systems. (d) The focal system also can be a receiving system (e.g., zoo), depending on the direction indicate interactions (i.e., synergies or trade-offs). Subfigures b, c, and d were modified from [6]. of flows of wildlife translocations. The arrows between SDGs (in subfigures b, c, and d) indicate Credit (SDG symbols): United Nations [1].interactions (i.e., synergies or trade-offs). Subfigures b, c, and d were modified from [6]. Credit (SDG symbols): United Nations [1].

natural system (CHANS), subsystems interact through various flows between them. Cross-boundary Under the conceptual framework of metacoupling (Figure 2a) [21], within a coupled human and flows (e.g., tourism and wildlife translocations) between the sending systems (e.g., origins of wildlife) natural system (CHANS), subsystems interact through various flows between them. Cross-boundary flows (e.g., tourism and wildlife translocations) between the sending systems (e.g., origins of wildlife) and receiving systems (e.g., destinations of wildlife) may affect the spillover systems (which affect and/or are affected by the metacoupled flows between sending and receiving systems). Agents are the stakeholders, such as individuals, households, organizations, and governments, that facilitate or

hinder the metacoupling. Causes indicate why couplings occur (e.g., environmental, socioeconomic, political, cultural reasons), and effects are the consequences of couplings [21].

Efforts (e.g., tourism development) toward achieving a specific SDG in a certain place (focal system) may enhance or compromise other SDGs both in the focal system and in other systems (e.g., spillover systems), generating direct or indirect SDG synergies and trade-offs [6]. Concerning tourism in protected areas, effects of the tourism flow go beyond the directly related SDG 8 (decent work and economic growth) within the focal system (e.g., a protected area), and may enhance or compromise other SDGs both locally (i.e., within the receiving system) and across spillover systems (e.g., neighboring areas) (Figure 2b). Regarding wildlife translocations, the effects of the wildlife translocations go beyond the directly related SDG 15 (life on land) and may enhance or compromise other SDGs both locally and across spillover systems. The focal system of wildlife translocations can be a sending system (e.g., an export country of wildlife) or receiving system (e.g., a zoo for wildlife translocations) depending on the direction of flows (Figure 2c,d). Within a focal system, besides the interactions between different SDGs, synergies or trade-offs between different targets of an individual SDG may exist [6]. Across spillover systems, besides the synergies or trade-offs between different SDGs, flows may hinder or favor the same SDG/target of the focal system, generating the synergy/trade-off within an individual SDG across different systems. Moreover, by tracking where the flows start, progress, and end, indirect SDG synergies and trade-offs can be identified, because the SDGs/targets influenced by the initial flow (e.g., tourism) may, in turn, enhance or compromise other SDGs/targets through associated flows (e.g., money), both within the focal system and across spillover systems [6].

# 2.2. Metacoupled Tourism and Wildlife Translocation Cases

Guided by the general procedure of using the framework [6], we conducted a literature review and analyzed tourism in protected areas and wildlife translocations globally. We first searched for relevant studies that presented effects beyond the boundaries of focal systems. We then assessed the directions and magnitudes of the flows of tourism and wildlife translocations as well as the features of focal and spillover systems. We linked the quantitatively measured effects with the SDG indicators [46] based on the framework (Figure 2).

We gathered literature on global tourism and wildlife translocations through comprehensive searches on Web of Knowledge and Google Scholar. The literature was published between 1 January 1990 and 3 May 2018. The search terms we used were: tourism, wildlife trade, wildlife translocation, wildlife introduction; protected areas, national parks, nature reserves, forest parks; neighboring areas, surrounding areas, other places, beyond boundaries; effects; and spillover system. Our purpose was to illustrate the widespread SDG interactions across spillover systems due to extensive metacoupled tourism and wildlife translocations, rather than to exhaustively search all previous studies. Therefore, we stopped searching after we identified ${ \sim } 3 0 $ publications in each of the six continents.

The searches returned 96 peer-reviewed journal articles, 24 book chapters, and 66 reports (17 by government agencies, e.g., Great Barrier Reef Marine Park Authority, 32 by intergovernmental agencies, e.g., CITES (Convention on International Trade in Endangered Species of Wild Fauna and Flora), and 17 by non-governmental organizations, e.g., World Wildlife Fund).

To further locate detailed data for our study, we then read through these journal articles, book chapters, and reports to see whether: (1) the cases involved costs and/or effects beyond the boundaries of focal systems; (2) the costs and/or effects were quantitatively evaluated; and (3) the costs and/or effects were associated with SDG targets or indicators [46]. Based on these three criteria, our screening yielded 22 cases for final analysis, including 12 cases of tourism (Table 1) and 10 cases of wildlife trade and translocation (Table 2). The quantitative costs and/or effects of 22 cases were acquired from 26 peer-reviewed articles (24 journal articles, 1 conference paper, and 1 discussion paper), 4 peer-reviewed books, and 4 reports (peer-reviewed and published by the government or intergovernmental agencies).

Table 1. Examples of SDG synergies and trade-offs within or across spillover systems due to tourism in protected areas.   

<table><tr><td>Country</td><td>Focal System and SDGs (Targets/Indicators)</td><td>Spillover System and SDGs (Targets/Indicators)</td><td>SDG Synergy and Trade-Off</td><td>Source</td></tr><tr><td>United Kingdom</td><td>The Broads National Park
SDG 8
8.9 More than 6.9 million visitors each year
8.9.1 Annual visitor expenditure of £345 million
8.9.2 4420 jobs supported by visitor expenditures</td><td>Neighboring towns and villages
SDG 8
8.9.1 Visitor expenditures influence £124 million within a wider “area of influence”
8.9.2 1937 jobs supported by visitor expenditures</td><td>One linkage within individual SDG across
places.
SDG 8 in the spillover systems synergized with
SDG 8 in the focal system.</td><td>[47]</td></tr><tr><td>United Kingdom</td><td>Yorkshire Dales National Park
SDG 8
8.9 More than 3.5 million visitors each year
8.9.1 Annual visitor expenditure of £199 million
8.9.2 3790 jobs supported by visitor expenditures</td><td>Neighboring towns and villages
SDG 8
8.9 Visitor expenditures influence £327 million within a wider “area of influence”
8.9.1 5564 jobs supported by visitor expenditures</td><td>One linkage within individual SDG across
places.
SDG 8 in the spillover systems synergized with
SDG 8 in the focal system.</td><td>[47]</td></tr><tr><td>United Kingdom</td><td>Dartmoor National Park
SDG 8
8.9 2.3 million visitors each year
8.9.1 Annual visitor expenditure of £119 million
8.9.2 2172 jobs supported by visitor expenditures
SDG 17
17.17 The Dartmoor Partnership, with more than 450 members</td><td>Neighboring towns and villages
SDG 8
8.9.1 Visitor expenditures influence £38 million within a wider “area of influence”
8.9.2 942 jobs supported by visitor expenditures
8.9 The Dartmoor Partnership promotes local produce
SDG 17
17.17 The Dartmoor Partnership, with more than 450 members</td><td>One linkage between different SDGs within
one place.
Within the focal system, SDG 17 synergized with
SDG 8.
One linkage within individual SDG across
places.
SDG 8 in the spillover systems synergized with
SDG 8 in the focal system.
One linkage between different SDGs across
places.
SDG 17 in the spillover systems synergized with
SDG 8 in the focal system.</td><td>[47]</td></tr><tr><td>Australia</td><td>Great Barrier Reef Marine Park
SDG 8
8.9 2,680,000 visitors each year
8.9.1 Contribution of approximately $480 million
related expenditure
8.9.2 Supports 4800 full-time jobs
SDG 14
14.2 $8 million visitor expenditure each year
directly to the management of the Great Barrier
Reef
14.1 Water quality decreased due to the tourism</td><td>Rest of Australia
SDG 8
8.1 Contributes almost $5.2 billion (value-added) to Australia&#x27;s economy
8.3 Supports about 69,000 full-time jobs
SDG 17
17.17 Tourism Tropical North Queensland, an Inter-firm organization, for joint destination promotion between the Great Barrier Reef and nearby areas (e.g., Cod Hole and Michaelmas Cay)</td><td>One linkage between different SDGs within
one place.
Within the focal system, SDG 14 synergized with
SDG 8.
One linkage within individual SDG across
places.
SDG 8 in the spillover systems synergized with
SDG 8 in the focal system.
One linkage between different SDGs across
places.
SDG 17 in the spillover systems synergized with
SDG 8 in the focal system.</td><td>[48,49]</td></tr><tr><td>Australia</td><td>Kakadu National Park
SDG 8
8.9 210,000 visitors each year</td><td>The Top End region
SDG 8
8.9.1 Contributes approximately $15 million to the economy of the top end region each year</td><td>One linkage within individual SDG across
places.
SDG 8 in the spillover systems synergized with
SDG 8 in the focal system.</td><td>[50,51]</td></tr></table>

Table 1. Cont.   

<table><tr><td>Country</td><td>Focal System and SDGs (Targets/Indicators)</td><td>Spillover System and SDGs (Targets/Indicators)</td><td>SDG Synergy and Trade-Off</td><td>Source</td></tr><tr><td>China</td><td>Zhangjiajie National Forest Park
SDG 8
8.9 Annual visits increased from 29,333 in early 1980s to 1,124,947 in 2000s
8.9.2 Non-agriculture population increased from 15.9% in 1982 to 75.3% in 2005
8.4.1 Coal consumption increased from 70 t in 1981 to 1200 t in 1985, and jumped to 6100 t in 1998
SDG 2
2.3.2 Average annual individual income increased from 193 RMB in 1981 to 4000 RMB in 2002; average tourism-related income (RMB 15,788) accounted for 60.8% of average total family income (25,958 RMB) in 2004
SDG 9
9.1 Road and other facilities in the park were improved due to tourism development
SDG 15
15.5 Landscape fragmented; air quality and groundwater quality deteriorated; biodiversity decreased
SDG 17
17.3.1 Foreign direct investments were used to build hotels and other tourism-related facilities
17.16 The park and two adjacent nature reserves (Tianzishan and Suoxiyu) were jointly listed as a World Natural Heritage site by the UNESCO in 1992</td><td>Zhangjiajie City and other places in China
SDG 8
8.9.1 Zhangjiajie City&#x27;s tourism-related industry accounted for 54.4% of the city&#x27;s GDP (2005); the city&#x27;s tax revenues from tourism and related sectors increased from 20% in the early 1990s to 59% in 2002
8.9.2 More than 2000 people migrated from the rest of the country to the park seeking better jobs and higher incomes from 1982 to 2005
SDG 9
9.1 Zhangjiajie airport opened for commercial use in 1994; A highway connecting Zhangjiajie to a major city of Changde, 137 km to the east, was completed in 2005
SDG 17
17.16 The first international cooperation agreement between Zhangjiajie City and travel agencies of the former Soviet Union was signed in 1989 due to tourism in the park</td><td>One linkage within individual SDG in one place.
Within SDG 8 in Zhangjiajie National Forest Park, SDG target 8.4 traded off with target 8.9.
Four linkages (three synergies and one trade-off) between different SDGs within one place.
Within the focal system, SDGs 2, 9, and 17 synergized with SDG 8, while 15 traded off with SDG 8.
One linkage within individual SDG across places.
SDG 8 in the spillover systems synergized with SDG 8 in the focal system.
Two linkages between different SDGs across places.
SDGs 9 and 17 in the spillover systems synergized with SDG 8 in the focal system.</td><td>[52]</td></tr><tr><td>South Africa</td><td>Kruger National Park
SDG 8
8.9 1.3 million visitors per year
SDG 17
17.17 Partnerships with parastatal-owned enterprises (e.g., Pretoriuskop Rest Camp) to promote sustainable tourism</td><td>Neighboring communities
SDG 1
1.1 4.1% of the local population were lifted above the absolute poverty line of $1 per day
SDG 17
17.17 Partnerships with private sector enterprises (e.g., Ngala Private Game Reserve, Jackalberry Lodge, and Sabi Sabi Private Game Reserve) to promote sustainable tourism</td><td>One linkage between different SDGs within one place.
Within the focal system, SDG 17 synergized with SDG 8.
Two linkages between different SDGs across places.
SDGs 1 and 17 in the spillover systems are synergized with SDG 8 in the focal system.</td><td>[53,54]</td></tr></table>

Table 1. Cont.   

<table><tr><td>Country</td><td>Focal System and SDGs (Targets/Indicators)</td><td>Spillover System and SDGs (Targets/Indicators)</td><td>SDG Synergy and Trade-Off</td><td>Source</td></tr><tr><td>Tanzania</td><td>Serengeti National Park
SDG 8
8.9 350,000 visitors per year
SDG 15
15.2 Tourism fees are the only source of revenue for the management of Serengeti National Park</td><td>Neighboring communities, rest of Tanzania
SDG 8
8.1 Spillover visitation from the park helps drive approximately 1,000,000 tourism- and travel-related jobs throughout Tanzania
SDG 1
1.1 Local communities outside the park face exacerbated poverty due to limited tourism benefits and land availability and increased wildlife conflict
SDG 15
15.2 Excess tourism revenue used to manage 11 additional less-visited national parks in Tanzania</td><td>One linkage between different SDGs within one place.
Within the focal system, SDG 15 synergized with SDG 8.
One linkage within individual SDG across places.
SDG 8 in the spillover systems synergized with SDG 8 in the focal system.
Two linkages between different SDGs across places.
SDGs 1 and 15 in the spillover systems are synergized with SDG 8 in the focal system.</td><td>[55-57]</td></tr><tr><td>Nepal</td><td>Sagarmatha National Park
SDG 8
8.9 Receives 35,000 visitors per year
8.9.2 Tourism is a major source of income for 3500 Sherpas living in the park
SDG 15
15.2 Revenue from tourism funds management of the park</td><td>Rest of Nepal, India, Bhutan
SDG 8
8.9 80% tourists to Sagarmatha national park travel to Nepal because of the park
SDG 17
17.17 WWF-supported partnership and coordination for the conservation and promotion of ecotourism within the &quot;Sacred Himalayan Landscape&quot; across Nepal, India, and Bhutan</td><td>One linkage between different SDGs within one place.
Within the focal system, SDG 15 synergized with SDG 8.
One linkage within individual SDG across places.
SDG 8 in the spillover systems synergized with SDG 8 in the focal system.
One linkage between different SDGs across places.
SDG 17 in the spillover systems synergized with SDG 8 in the focal system.</td><td>[58]</td></tr><tr><td>Peru</td><td>Machu Picchu
SDG 8
8.9 Receives over 900,000 visitors per year
SDG 12
SDG 12.b Large tourism volumes have resulted in limited access for indigenous peoples and degradation of the site. Tourists have now been limited to 2500 a day to address these issues</td><td>Bordering area, Inca Trail, Peru
SDG 8
8.9 Approximately 70,000 tourists to Macchu Picchu per year combine the trip with a hike on the Inca Trail
8.9.1 Tourism entrance fees contribute about $20 million annually to the Peruvian government
SDG 15
15.5 Large numbers of tourists had negative ecological effects in the surrounding area, including the loss in plant diversity and wildlife avoidance. Tourists hiking the Inca Trail have now been limited to 500 a day to address these issues.</td><td>One linkage between different SDGs within one place.
Within the focal system, SDG 12 synergized with SDG 8.
One linkage within individual SDG across places.
SDG 8 in the spillover systems synergized with SDG 8 in the focal system.
One linkage between different SDGs across places.
SDG 15 in the spillover systems traded off with SDG 8 in the focal system.</td><td>[59,60]</td></tr></table>

Table 1. Cont.   

<table><tr><td>Country</td><td>Focal System and SDGs (Targets/Indicators)</td><td>Spillover System and SDGs (Targets/Indicators)</td><td>SDG Synergy and Trade-Off</td><td>Source</td></tr><tr><td>United States</td><td>Yellowstone National Park
SDG 8
8.9 Receives 3.4 million visitors per year
8.9.1 Visitor spending generates $135.7 million inside the park
8.9.2 4994 jobs supported by visitor spending</td><td>Neighboring towns and villages (within 150 miles of the park)
SDG 8
8.9.1 Visitor spending generates $269.7 million outside the park
8.9.2 1317 jobs supported by visitor spending as secondary effects</td><td>One linkage within individual SDG across places.
SDG 8 in the spillover systems synergized with SDG 8 in the focal system.</td><td>[61]</td></tr><tr><td>United States</td><td>Yosemite National Park
SDG 8
8.9 Receives 3.7 million visitors per year
8.9.1 Visitor spending generates $184.9 million inside the park
8.9.2 3795 jobs supported by visitor spending</td><td>Neighboring towns and villages (within 50 miles of the park)
SDG 8
8.9.1 Visitor spending generates $207.9 million outside the park
8.9.2 1132 jobs supported by visitor spending as secondary effects</td><td>One linkage within individual SDG across places.
SDG 8 in the spillover systems synergized with SDG 8 in the focal system.</td><td>[62]</td></tr></table>

Table 2. Examples of SDG synergies and trade-offs within focal and across spillover systems due to wildlife translocations.   

<table><tr><td>Movement of Wildlife</td><td>Focal System and SDGs (Targets/Indicators)</td><td>Spillover System and SDGs (Targets/Indicators)</td><td>SDG Synergy and Trade-Off</td><td>Source</td></tr><tr><td>Trade of grey and timneh parrots (Psittacus erithacus and Psittacus timneh)</td><td>United States (receiving system)</td><td>South Africa, Democratic Republic of the Congo (DRC)SDG 1515.7.1 The import ban of wild birds into the US enhanced the development of the captive-breeding industry in South Africa, which had more than 1600 breeding facilities by 2015 and accounted for 67% of all captive-bred exports.15.c Due to the development of the captive-breeding industry, South Africa became a major importer of wild-sourced parrots (being used as breeding stock) from the DRC. From 2006 to 2014, DRC exported 92% of 42, 965 wild-sourced parrots.</td><td>Two linkages within individual SDG across places.SDG 15 in South Africa synergized with SDG 15 in the focal system. Within SDG 15 in the spillover systems, the enhanced SDG 15 in South Africa generated one trade-off between DRC and South Africa.</td><td>[63,64]</td></tr><tr><td>Trade of polar bears (Ursus maritimus)</td><td>United States (receiving system)</td><td>EU, Russia, and CanadaSDG 1515.5 After the prohibition of polar bear trophies into the US, hunters from the EU, Russia, and Canada harvested more polar bears, and more trophies were imported into these areas due to the Nunavut polar bear quota (i.e., the number of polar bear tags allocated in Nunavut for sustainable harvest).</td><td>One linkage within individual SDG across places.SDG 15 in the spillover systems traded off with SDG 15 in the focal system.</td><td>[65]</td></tr></table>

Table 2. Cont.   

<table><tr><td>Movement of Wildlife</td><td>Focal System and SDGs (Targets/Indicators)</td><td>Spillover System and SDGs (Targets/Indicators)</td><td>SDG Synergy and Trade-Off</td><td>Source</td></tr><tr><td>Translocation of raccoons (Procyon lotor)</td><td>West Virginia, USA (receiving system)SDG 1515.8 A few thousand raccoons were translocated from Florida to West Virginia to augment the local raccoon stock for hunting purposes in 1977.SDG 33.3 The translocation brought rabies epizootic in the local raccoon population.</td><td>Pennsylvania, Virginia, and Maryland, USASDG 33.3 The current rabies epizootic in raccoons and skunks (Mephitis mephitis) in Pennsylvania, Virginia, and Maryland is because of the translocation of raccoons from Florida to West Virginia.</td><td>One linkage between different SDGs in one place. Within West Virginia, SDG 3 traded off with SDG 15.One linkage between different SDGs across places.SDG 3 in the spillover system traded off with SDG 15 in the focal system.</td><td>[66]</td></tr><tr><td>Trade and introduction of domestic reindeer (Rangifer tarandus)</td><td>Godthàbsfjord (mid-west Greenland, receiving system)SDG 22.3 In 1952, 263 domestic reindeer were traded and translocated from Norway to the local Inuit community in western Greenland, to provide a new livelihood. The reindeer husbandry succeeded; for example, from 1967 to 1972, Greenland export revenues from the sale of reindeer products increased dramatically from 0.1 to 1.8 million Danish kroner (1 Danish kroner = 0.15 US dollar).</td><td>The rest of western GreenlandSDG 1515.8 All indigenous wild Greenland caribou (R. tarandus greenlandicus) in western Greenland are infested with warble fly (Oedemagna tarandi) and nostril fly (Cephenemyia trompe), both of which did not occur in Greenland before 1952 and were brought with the imported domestic reindeer. The Greenland caribou are greatly reduced in number due to severe mortality associated with the severe harassment of these flies.</td><td>One linkage between different SDGs across places.SDG 15 in the spillover system traded off with SDG 2 in the focal system.</td><td>[66,67]</td></tr><tr><td>Introduction of American grey squirrels (Sciurus carolinensis)</td><td>Stupinigi, Italy (receiving system)SDG 1515.8 Two pairs of American grey squirrels were introduced to Stupinigi from Washington, DC, in 1948.</td><td>Piedmont (Italy), and EuropeSDG 1515.8 By 2010, a large population of grey squirrels occupied a range of over 2000 km² in Piedmont. In the same period, red squirrels (Sciurus vulgaris) went extinct in most of the forested areas occupied by grey squirrels.15.8.1 Trade ban of grey squirrels in Italy (inter-ministerial decree) was approved to avoid further release of grey squirrels to the wild in 2012; trade restrictions at the European level (Commission Regulation n. 101/2012 of 6 February 2012 amending Council Regulation No 338/97 on the protection of species of wild fauna and flora by regulating trade therein) were adopted to reduce the invasive risk in the long term.15.a.1 A project (2010–2015, € 2 million) was funded by the European Commission (co-financing 45.43%) and the Italian Ministry for the Environment, Land, and Sea, to control or eradicate the grey squirrels in North Italy, including Piedmont area.</td><td>One linkage within individual SDG across places.SDG 15 in the spillover systems traded off with SDG 15 in the focal system.</td><td>[68,69]</td></tr></table>

Table 2. Cont.   

<table><tr><td>Movement of Wildlife</td><td>Focal System and SDGs (Targets/Indicators)</td><td>Spillover System and SDGs (Targets/Indicators)</td><td>SDG Synergy and Trade-Off</td><td>Source</td></tr><tr><td rowspan="3">Introduction of North American Beavers (Castor canadensis)</td><td>Lake Fagnano, Argentina (receiving system)</td><td>Tierra del Fuego ecosystem, Argentina and Chile SDG 15</td><td>One linkage within individual SDG across places. SDG 15 in the spillover system traded off with SDG 15 in the focal system.</td><td>[70]</td></tr><tr><td>SDG 15</td><td>15.1 A large population of beavers (over 100,000) is disrupting wetland ecosystems in lake Fagnano and destroying native forests of the neighboring area.</td><td>[70]</td><td></td></tr><tr><td>15.8 Fifty beavers were introduced to the lake Fagnano in 1946 to start a fur-trapping industry.</td><td>15.8 A massive control and eradication plan is underway across both Argentinean and Chilean Tierra del Fuego.</td><td></td><td></td></tr><tr><td rowspan="2">Trade of Australian endemic parrots</td><td>Australia (sending system)</td><td>New Zealand SDG 15</td><td>One linkage within individual SDG across places. SDG 15 in the spillover system traded off with SDG 15 in the focal system.</td><td>[71-73]</td></tr><tr><td>SDG 15</td><td>15.7 Australia banned the export of its native parrot species since 1960, and passed the Commonwealth Environmental Protection and Biodiversity Conservation Act 1999 (EPBC Act) to regulate the trade of all the species listed in the Convention on International Trade in Endangered Species of Wild Fauna and Flora (CITES) Appendices, including Australian endemic parrots. Between 1996 and 2008, 6% of recorded global illegal wildlife seizures occurred in Australia. The destinations of illegal exports from Australia were predominantly to New Zealand and the US.</td><td>One linkage within individual SDG in one place. Within SDG 15 in Venezuela, two different SDG targets (15.1 and 15.a) synergized. One linkage within individual SDG across places. SDG 15 in the spillover system is synergized with SDG 15 in the focal system.</td><td>[74-77]</td></tr><tr><td rowspan="2">Trade of caiman (Caiman crocodilus)</td><td>Venezuela (sending system)</td><td>Honduras, Nicaragua, Guyana, Paraguay, and Colombia SDG 15</td><td>One linkage within individual SDG in one place. Within SDG 15 in Venezuela, two different SDG targets (15.1 and 15.a) synergized. One linkage within individual SDG across places. SDG 15 in the spillover system is synergized with SDG 15 in the focal system.</td><td>[74-77]</td></tr><tr><td>15.1 In 1983, Venezuela firstly initiated a large-scale sustainable harvesting program for caiman, which generated great economic values through export (mainly to Japan) and maintained the wild population at a sustainable level. For example, between 1983 and 1995, more than 1 million caimans were harvested and exported, with an export value of $US 115 million. Besides, censuses (1996 and 1999) indicated that wild caiman densities were generally higher in harvested than non-harvested areas, indicating that Venezuela&#x27;s caiman harvest was being sustained by the wild population. 15.a The caiman program generated substantial managing funds of the Venezuelan wildlife department for all wildlife programs nationwide. For example, the 1989 caiman harvest contributed $US 1.1 million to the Venezuelan wildlife department.</td><td>15.1 Honduras, Nicaragua, Guyana, Paraguay, and Colombia were encouraged by the sustainable use program and trade of caiman in Venezuela, and initiated the large-scale sustainable farming or captive-breeding program. 15.c Under the influence of CITES, crocodilian products supply from sustainable wild harvests, ranching, or captive breeding increased. 15.7 Illegal international trade was eradicated and displaced by legal trade.</td><td></td><td></td></tr></table>

Table 2. Cont.   

<table><tr><td>Movement of Wildlife</td><td>Focal System and SDGs (Targets/Indicators)</td><td>Spillover System and SDGs (Targets/Indicators)</td><td>SDG Synergy and Trade-Off</td><td>Source</td></tr><tr><td rowspan="3">Trade of reticulated python (Python reticulatus)</td><td>Indonesia (sending system)</td><td>Singapore</td><td></td><td></td></tr><tr><td>SDG 15</td><td>SDG 15</td><td>One linkage within individual SDG across places.</td><td rowspan="2">[78]</td></tr><tr><td>15.7.1 Indonesia&#x27;s direct exports of reticulated python to European Commission (EC) stopped due to the EC import suspensions between 1992 and 1994.</td><td>15.7.1 EC&#x27;s imports of reticulated python from Indonesia via Singapore increased about 20% to offset the suspended direct imports due to inadequate instructions about the application of the suspension.</td><td>SDG 15 in the spillover system traded off with SDG 15 in the focal system.</td></tr><tr><td rowspan="7">Trade of African lions (Panthera leo)</td><td>South Africa (sending system)</td><td></td><td></td><td></td></tr><tr><td>SDG 15</td><td></td><td>One linkage within individual SDG in one place.</td><td></td></tr><tr><td>15.1 The captive-bred lion hunting industry in South Africa, an example of sustainable use of wildlife, has grown rapidly, with annual exports of lion trophies (57.8% to the United States) increasing sharply from less than 50 in the 1980s to 833 in 2008. The lion breeding and hunting industry was estimated to generate annual revenue of US$11.2 million directly from 2005 to 2007. Besides this, the lion breeding and hunting industry created 220 direct jobs.</td><td>Other African countries (Benin, Botswana, Burkina Faso, Cameroon, Central African Republic, Ethiopia, Mozambique, Namibia, Tanzania, Zambia, Zimbabwe)</td><td>Within SDG 15 in South Africa, two different SDG targets (15.1 and 15.7) synergized.</td><td></td></tr><tr><td>15.7 Wild lions hunted in South Africa decreased significantly, so that only 0.9% and 1.1% of the total exported lions in 2009 and 2010 were wild lions.</td><td>SDG 15</td><td>One linkage among SDGs within one place.</td><td>[79,80]</td></tr><tr><td>SDG 1</td><td>15.7 The number of lion trophies exported from other African countries declined rapidly from over 900 in 1994 to 318 in 2010, due to the increased captive-bred lion hunting in South Africa.</td><td>Within South Africa, SDG 1 synergized with SDG 15.</td><td></td></tr><tr><td>1.b The economic benefits from the lion breeding and hunting industry helped reduce poverty for the main beneficiary provinces (North West, Limpopo, and Free State), as these areas are among the poorest in South Africa.</td><td></td><td>One linkage within individual SDG across places.</td><td></td></tr><tr><td></td><td></td><td>SDG 15 in the spillover systems synergized with SDG 15 in the focal system.</td><td></td></tr></table>

# 3. Results

The results from analyzing the 22 cases (Figure 3) from around the world show a total of 47 linkagesThe results from analyzing the 22 cases (Figure 3) from around the world show a total of 47 among 23 targets of 10 SDGs, including 33 synergies and 14 trade-offs (Tables 1 and 2).linkages among 23 targets of 10 SDGs, including 33 synergies and 14 trade-offs (Tables

![](images/cd6147c97148092069463f5198191ab6f0ffe51cb22622cedc0b3ef7fea78019.jpg)  
Figure 3. Map highlighting affected SDGs in focal and spillover systems due to tourism and wildlifeFigure 3. Map highlighting affected SDGs in focal and spillover systems due to tourism and wildlife translocations. The bullets and boxes in red represent the 12 cases of tourism, whereas the bullets and translocations. The bullets and boxes in red represent the 12 cases of tourism, whereas the bullets boxes in green represent the 10 cases of wildlife translocations. The empty circle bullets linked by and boxes in green represent the 10 cases of wildlife translocations. The empty circle bullets linked dashed lines indicate spillover systems located far from focal systems, whereas the ones that are by dashed lines indicate spillover systems located far from focal systems, whereas the ones that are adjacent to solid circle bullets indicate nearby spillover systems. For each case, the focal system and adjacent to solid circle bullets indicate nearby spillover systems. For each case, the focal system and influenced SDGs are color-coded orange, whereas the spillover systems and influenced SDGs are influenced SDGs are color-coded orange, whereas the spillover systems and influenced SDGs are color-coded blue. The detailed 47 linkages among 23 targets of 10 SDGs, including 33 synergies and color-coded blue. The detailed 47 linkages among 23 targets of 10 SDGs, including 33 synergies and 14 14 trade-offs, are presented in Tables 1 and 2. Credit (SDG symbols): United Nations [trade-offs, are presented in Tables 1 and 2. Credit (SDG symbols): United Nations [1].

# 3.1. SDG Synergies and Trade-Offs in the 12 Cases of Tourism

The 12 cases of tourism (Figure 3 and Table 1) indicate that, beyond the directly related SDG 8 (decent work and economic growth), tourism in protected areas enhanced or compromised other SDGs, including SDGs 2 (zero hunger), 9 (industry, innovation and infrastructure), 12 (responsible consumption and production), 14 (life below water), 15 (life on land,) and 17 (partnerships) within focal systems, and SDGs 1 (no poverty), 8, 9, 15, and 17 across spillover systems.

# 3.1.1. Within Focal Systems, Synergies and Trade-Offs between SDG 8 (Decent Work and Economic Growth) and Other SDGs Varied in Three Ways

First, both synergies and trade-offs were present. For example, SDG 15 (life on land) synergized with SDG 8 in the case that tourism contributed management funds (SDG 15 target 15.2) in Sagarmatha National Park of Nepal and Serengeti National Park in Tanzania; while it traded off with SDG 8 in other cases, including landscape fragmented and biodiversity decreased (SDG target 15.5) due to tourism in Zhangjiajie National Forest Park in China (Table 1). Second, only synergies were present. For example, tourism strengthened multi-stakeholder partnerships (SDG 17) in Dartmoor National Park of the United Kingdom, Zhangjiajie National Forest Park, and Kruger National Park in South Africa; increased income (SDG 2) and improved infrastructures (SDG 9) in Zhangjiajie National Forest Park; and increased management fund (SDG 14) for the Great Barrier Reef Marine Park in Australia (Table 1). Third, only trade-offs were identified. For example, large tourism volumes (over 900,000 visitors per year) in Machu Picchu of Peru resulted in limited access for indigenous peoples and degradation of the site (SDG 12.b) (Table 1).

# 3.1.2. Across Spillover Systems, Synergies and Trade-Offs between SDG 8 (Decent Work and Economic Growth) and Other SDGs Varied in Two Ways

First, both synergies and trade-offs occurred. For example, SDG 15 (life on land) synergized with SDG 8 (decent work and economic growth) in one case: tourism revenue of Serengeti National Park provided management funds to 11 additional less-visited national parks in Tanzania; while SDG 15 traded off with SDG 8in another case: large numbers of tourists had negative ecological effects in the surrounding area of Machu Picchu (Table 1). Another example is the relationships between SDG 1 (no poverty) and SDG 8 (decent work and economic growth): a synergy occurred when neighboring communities benefited from tourism in Kruger National Park, within which $4 . 1 \%$ of the local population lifted above the absolute poverty line of $\$ 1.25$ per day (SDG target 1.1); a trade-off occurred when local communities bordering the Serengeti National Park faced exacerbated poverty due to limited tourism benefits, reduced land availability, and increased wildlife conflicts (Table 1). Second, only synergies were identified. For example, tourism in five protected areas (Dartmoor National Park, Zhangjiajie National Forest Park, Kruger National Park, Great Barrier Reef Marine Park, and Sagarmatha National Park) enhanced multi-stakeholder partnerships (SDG 17) of the neighboring areas of these protected areas (Table 1).

# 3.1.3. Within SDG 8 (Decent Work and Economic Growth), both Synergies and Trade-Offs Existed within Focal Systems as well as across Spillover Systems

Within the focal system, Zhangjiajie National Forest Park, one trade-off was observed between SDG target 8.9 (tourism) and 8.4.1 (material footprint, material footprint per capita, and material footprint per GDP) (Table 1). Across spillover systems, tourism in 11 of the 12 protected areas (except for Kruger National Park) has promoted the tourism economy of neighboring towns, villages, cities, or the whole country (Table 1).

# 3.2. SDG Synergies and Trade-Offs in the 10 Cases of Wildlife Translocations

Regarding the 10 cases of wildlife translocations (Figure 3 and Table 2), we found that beyond the directly related SDG 15 (life on land), wildlife translocations enhanced or compromised SDGs 1

(no poverty) and 3 (good health and well-being) in focal systems, and SDGs 2 (zero hunger) and 3 in spillover systems.

# 3.2.1. Within Focal Systems, SDG 15 (Life on Land) Synergized with SDG 1 (No Poverty) and Traded off with SDG 3 (Good Health and Well-Being)

One synergy occurred between sustainable use of wildlife (SDG target 15.1) and investment in poverty eradication actions (SDG target 1.b) in the trade case of African lions (Panthera leo), because the main benefiting provinces (North West, Limpopo, and Free State) are among the poorest in South Africa, and the economic benefits from lion breeding and hunting industry are significant (Table 2). Trade-off occurred when raccoons were translocated from Florida to West Virginia to augment its local raccoon population (SDG target 15.8), which brought about rabies epizootic (SDG target 3.3) in the local raccoon population (Table 2).

# 3.2.2. Across Spillover Systems, Only Trade-Offs between SDG 15 (Life on Land) and SDGs 2 (Zero Hunger) and 3 (Good Health and Well-Being) Were Observed

Regarding SDG 2, in 1952, 263 domestic reindeer (Rangifer tarandus) were traded and translocated from Norway to the Inuit community in Godthåbsfjord of western Greenland to provide a new livelihood (SDG target 2.3). This translocation brought two invasive parasitic insects (SDG target 15.8), warble fly (Oedemagna tarandi) and nostril fly (Cephenemyia trompe), which infested all indigenous wild Greenland caribou (R. tarandus groenlandicus) in the whole western Greenland (spillover system) (Table 2). The translocated raccoons from Florida to West Virginia to augment the local raccoon population (SDG target 15.8) also brought rabies epizootic (SDG target 3.3) to raccoons and skunks (Mephitis mephitis) in Pennsylvania, Virginia, and Maryland, which was a trade-off between SDGs 15 and 3 across the spillover systems (Table 2).

# 3.2.3. Within SDG 15 (Life on Land), We Found Only Synergies in Focal Systems, and Both Synergies and Trade-Offs across Spillover Systems

Within the focal system, Venezuela, a synergy occurred because the caiman (Caiman crocodilus) sustainable use program (SDG target 15.1) for exportation (export value of $US 115 million between 1983 and 1995) generated substantial operating funds for all wildlife programs nationwide (SDG target 15.a) (Table 2). Across spillover systems, synergies occurred when the trade policy of grey and Timneh parrots in the United States and the trade policy of caiman in Venezuela led to positive effects in the spillover systems (Table 2). Trade-offs existed in more cases (Table 2). The restriction of wildlife trade in focal systems sometimes increased the trade in other places (spillover systems), for example, prohibited polar bear importations to the United States increased the importation to EU, Russia, and Canada; suspensions of reticulated python (Python reticulatus) trade from Indonesia promoted the trade from Singapore; banned export of its endemic parrots in Australia led to the laundering of wild-caught native Australian species in New Zealand and transporting them “legally” out of New Zealand to other countries. Translocated animals sometimes become invasive species. For example, the introduced American grey squirrels (Sciurus carolinensis) in Stupinigi, Italy, and North American beavers (Castor canadensis) in Lake Fagnano, Argentina, for hunting or fur-trapping purposes posed negative effects to neighboring ecosystems (Table 2).

# 3.2.4. One Indirect Trade-Off across Spillover Systems Was Identified in Wildlife Translocation

The United States (receiving system) had been a major importer of wild-sourced Psittacus parrots and accounted for $4 7 \%$ of annual imports of more than 50,000 parrots (mainly from the west and central African countries) before the 1992 Wild Bird Conservation Act passed. The import restriction of wild birds in the United States accelerated the expansion of the captive-breeding industry in South Africa (spillover system), which had over 1600 breeding facilities by 2015 and accounted for $6 7 \%$ of all captive-bred exports. This synergy between the focal system (United States) and spillover system

(South Africa) was within SDG 15, however, it generated trade-off between South Africa and the Democratic Republic of the Congo (DRC), because South Africa was a major importer of wild-sourced Psittacus parrots (used as breeding stock) from the DRC, from where $9 2 \%$ of 42,965 wild-sourced Psittacus parrots were exported during 2006–2014. In this way, the enhanced SDG 15 in one spillover system (South Africa) compromised SDG 15 in another spillover system (DRC) due to the efforts toward SDG 15 in the focal system (United States) (Table 2).

# 4. Discussion and Conclusions

We applied the framework [6], which explicitly tackles increasingly important cross-boundary interactions in the context of SDG interactions, to guide the synthesis of tourism and wildlife translocations cases from the six continents and analyzed SDG synergies and trade-offs among 10 SDGs. Besides the SDG synergies and trade-offs within a system boundary, by tracking the effects of the flows, both direct and indirect SDG synergies and trade-offs across spillover systems were identified. Our results suggest that the SDG interactions within and across boundaries are widespread because of the extensive metacoupled flows.

Tourism and wildlife translocations are two types of globally common and important flows, and share features with other metacoupled processes, such as international trade [17,19], ecosystem services [81,82], and migration [83], as many studies indicate [26,34,84,85]. For instance, various flows connect sending, receiving, and spillover systems, which are affected socioeconomically and environmentally by the flows. The identification of widespread spillover systems is a new frontier in sustainability research [21,35]. It is a similarity that both tourists and wildlife flows impact spillover systems, however, the spillover effects affected SDGs at different spatial scales. Our study suggests that the spillover systems are distributed from neighboring areas to several distant countries (Figure 3). The composition of spillover systems differs for different cross-boundary processes. For instance, for tourism, the spillover effects mainly occur in adjacent areas, while the implementation of wildlife translocations could impact far away spillover systems, such as remote countries (Figure 3). The variation may also depend on the magnitude of flows, for example, a large number of tourists may influence larger neighboring areas. Besides the spillover systems and spatial scales, tourists and wildlife flows have similarities and differences in the influenced SDGs. Our synthesis indicates that both synergies and trade-offs existed within the same SDG (e.g., SDG 8 for tourism and SDG 15 for wildlife translocations) within focal systems as well as across spillover systems. Across the social, economic, and environmental dimensions of sustainable development, the tourist flow to protected areas influenced both SDGs of social inclusion (SDGs 1 and 2) and environmental sustainability (SDGs 14 and 15), besides the economic SDGs (8 and 9). As for wildlife translocations, our synthesis only identified synergies and trade-offs between environmental SDGs (15) and social inclusion SDGs (1, 2, and 3).

The World Tourism Organization claimed that tourism has the potential to contribute to all of the 17 SDGs [36]. From only 12 protected areas, our synthesis (Figure 3 and Table 1) indicates that, besides the directly related SDG 8 and target 8.9, tourism flow influenced seven other SDGs (1, 2, 9, 12, 14, 15, and 17) in the protected areas and across spillover systems. For many cases, the fact that SDG interactions were not identified is more likely to reflect data deficiencies than the absence of SDG synergies and trade-offs. It will be possible to identify more SDG interactions by tracking other positive or negative effects of the tourists flows and other associated flows (e.g., money). For example, the increased waste and sewage from tourism reduce water quality [86] may lead to trade-offs with SDG 6 (clean water and sanitation) both locally and across adjacent areas, and carbon emissions due to tourism [87] may influence spillover systems at the global scale and result in a trade-off with SDG 13 (climate action). Identifying, tracking, and quantifying the flows, spillover systems, and effects on SDG interactions need more investigation.

Regarding the wildlife translocations (Figure 3 and Table 2), besides the directly related SDG 15 (life on land), we identified relatively fewer SDGs (1, 2, and 3) that were enhanced or compromised in

the focal systems and across spillover systems. Similar to the tourism cases, it is possible to explore more impacted SDGs and interactions among them by tracking the flows. For example, the panda loans favored multiple SDGs (9, 15, and 17) within Wolong and across spillover systems [6], while the associated carbon emissions may also lead to trade-offs with SDG 13 (climate change) [84]. Moreover, similar to the raccoon translocation program (Table 2), the wildlife trade has noticeably played a role in the emergence of zoonotic disease (SDG 3) across the world [43], such as monkeypox in the USA [88,89], Ebola in Africa, salmonellosis in the USA and Europe [90]. The most recent case is the novel coronavirus COVID-19, which was believed bat trade-related [44], and has spread on a global scale, and resulted in over 23 million people infected and more than 800,000 people died as of 23 August 2020 [45]. The affected spillover systems go beyond the better connected urban areas to smaller cities, towns, and rural areas globally through trade and travel [91]. Beyond public health (SDG 3), the COVID-19 may have impacts on all of the 17 SDGs. For example, the ongoing pandemic, the lockdown, and the travel restriction around the world have imposed negative impacts on poverty alleviation (SDG 1) [92], food security (SDG 2) (availability, access, utilization, and stability) [91,93], quality education (SDG 4) [94], gender equality (SDG 5) [94], sustainable energy (SDG 7) [95], and reducing inequality (SDG 10) [92], the tourism industry [96,97], and the world economy [98] (SDG 8). Moreover, although the reduced economic activities have resulted in some unexpected profit of climate change mitigation (SDG 13) [99], improved water quality in some areas (SDG 6) [100], and improved air quality in some urban areas (SDG 11) [101,102], negative environmental impacts such as increased pharmaceutical and household waste and consumption (SDG 12) increase challenges in management [103]. It is more essential than ever to govern the cross-boundary flows, such as improving the biosecurity of the wildlife trade [90], to reduce the trade-offs and promote the synergies of achieving SDGs.

Although our results have illustrated that the SDG interactions within and across boundaries are widespread due to extensive metacoupled tourism and wildlife translocations, we note there were limitations in this study. First, more data are needed to understand the reasons behind the conclusion that more synergies than tradeoffs occurred—our synthesis identified 33 synergies and 14 trade-offs among 23 targets of 10 SDGs. Future studies need to track the flows to identify the spillover systems and evaluate socioeconomic and environmental effects. Moreover, the 22 cases were relatively small compared to the large amount of relevant literature. Our synthesis showed that the SDG interactions across spillover systems are geographically widespread, although they may not sufficiently represent the global tourism and wildlife translocations, because these are only a small proportion of the enormous tourism in protected areas (e.g., at least 8 billion annual visits [39]) and the international trade of more than 5000 animal species and 29,000 plant species [40].

Despite the above limitations, our synthesis suggests that, beyond the flows of tourism and wildlife translocation and these specific cases, special attention should be paid to the increasingly important metacoupled flows that affect SDG synergies and trade-offs across boundaries. Theoretically, the synthesis showed that the general framework [6] is a useful tool and can provide general guidance for quantifying SDG interactions across different locations around the world in future studies. Practically, attempts to accomplish the 17 SDGs everywhere should include extensive spillover systems in sustainability governance [35]. Moreover, to hinder trade-offs and enhance synergies among SDGs across boundaries, it is necessary to track, evaluate, and manage the flows. We hope that this study will provide insights for more empirical investigation on SDG interactions that integrate local, regional, and global flows (of people, money, matter, and information) to enhance holistic management to achieve the 2030 Agenda locally to globally.

Author Contributions: Conceptualization, Z.Z. and J.L.; methodology, Z.Z., M.C., and J.L.; investigation, Z.Z., T.C., M.G.C.; writing—original draft preparation, Z.Z. and M.C.; writing—review and editing, Z.Z., M.C., T.C., M.G.C. and J.L.; visualization, Z.Z. and M.C.; funding acquisition, J.L. All authors have read and agreed to the published version of the manuscript.

Funding: The project was funded by the National Science Foundation (Grant No.: 1924111, 1340812); Michigan AgBioResearch.

Acknowledgments: We are very grateful to Sue Nichols, Andrés Viña, and two anonymous reviewers for their helpful suggestions and comments on the earlier draft.

Conflicts of Interest: The authors declare no conflict of interest.

