# South American Camelids: their values and contributions to people

<!--
RAG record type: paraphrased-summary-and-structured-extraction
Copyright note: This file intentionally contains no full text from
the source paper. It is a short paraphrased metadata/summary record
for retrieval only.
Generated at: 2026-04-25T06:09:52.271110+00:00
Prompt version: rag_rebuild_v4
-->

## Metadata
- Filename: Vila and Arzamendia - 2022 - South American Camelids their values and contributions to people.pdf
- Year: 2022
- DOI: 10.1007/s11625-020-00874-y
- OA status: bronze
- License: none recorded
- Category: Journal Articles\Research\Telecoupling
- Closed-access reason: bronze OA, free to read but no license to redistribute

## Copyright-Safe Summary
This paper examines how South American camelids (SACs) contribute to human wellbeing in the Andean region, using the IPBES conceptual framework to analyze values, flows, and governance. The focus is on two species most common in the Altiplano of northwest Argentina: wild vicunas and domestic llamas. The work is grounded in Andean Indigenous worldviews that distinguish wild (Salqa) and domestic (Uywa) camelids, and in the broader notion of buen vivir, or good living.

Geographically, the study centers on Santa Catalina in Jujuy Province, Argentina, but traces connections across the Andes, to international fiber markets, and to global biomedical laboratories. Methods are primarily ethnobiological and qualitative: more than a decade of participatory work with Indigenous and local communities, participatory observation of vicuna captures (chakus), 260 open interviews during annual llama-caravan fairs, workshops, school activities, and targeted questionnaires. A third case, llama nanobodies, is examined through literature review and expert consultation.

Three case studies illustrate different types of nature contributions to people. First, community-based vicuna management via live-capture and shearing generates luxury fiber while reinforcing cultural ties to Pachamama and vicuna guardian deities. However, global luxury brands, export companies, and trade regulations create strong telecouplings; only a small share of final garment value reaches Andean communities, and poaching and market monopsony remain key threats.

Second, traditional llama caravans move fiber and dried meat from Bolivia to Argentine fairs, where they are bartered for industrial foods. This ancient mobility system is rapidly disappearing due to motor vehicles, changing aspirations of youth, drought, and shifting fiber markets, showing how global and regional drivers alter local pastoral systems.

Third, llama nanobodies used in advanced immunology research link Andean domestication history to cutting-edge therapies worldwide, a metacoupled health connection that raises questions about access, benefit-sharing, and Indigenous rights under the Nagoya Protocol.

The paper explicitly engages telecoupling and metacoupling, using the IPBES framework to map distant economic, institutional, and scientific interactions that shape camelid-based livelihoods and conservation.

## Structured Metacoupling Extraction

### Coupling Classification
- Paper explicitly analyzes telecouplings linking Andean camelids with distant markets and laboratories

### Intracoupling
#### Systems
- Andean altiplano socioecological systems with vicunas, llamas, alpacas, guanacos
- Santa Catalina local communities, schools, cooperatives and fairs
- Bolivian Nor Lipez llama herder communities using caravans
#### Flows
- Local flows of camelid fiber, meat, skins and dung within Andean communities
- Knowledge exchange between indigenous cosmovision and local scientific researchers
- Cultural flows via rituals, festivals, petroglyphs, stories about deities
#### Agents
- Indigenous and local Andean people including IPLCs and llameros
- VICAM research team, universities, local schools
- Local cooperatives such as COOPASAC and municipal authorities
#### Causes
- Historical domestication and co-production of llamas and alpacas from wild camelids
- Andean livelihood dependence on camelid products and transport services
- Application of IPBES framework to organize camelid management knowledge
#### Effects
- Maintenance of biocultural heritage and Andean concepts of good living
- Local income from vicuna fiber and pastoral products
- Shifts in youth aspirations away from traditional caravanning

### Pericoupling
#### Systems
- Border region between Santa Catalina Argentina and Bolivia
- Regional Andean markets and provincial governments
- Neighboring pastoral landscapes sharing camelid populations
#### Flows
- Cross-border movement of llama caravans, herders and goods
- Illegal cross-border poaching of vicunas and fiber smuggling
- Regional policy, permits and enforcement affecting camelid use
#### Agents
- Border control authorities and security forces
- Regional environmental agencies and provincial governments
- Cross-border poachers and regional traders
#### Causes
- Shared camelid ranges and grazing lands across national borders
- Differences in market access and regulations among Andean countries
- Regional infrastructure development including roads and vehicles
#### Effects
- Management challenges for vicuna conservation across jurisdictions
- Erosion of traditional llama caravans replaced by trucks
- Unequal bargaining power for local communities in regional trade

### Telecoupling
#### Systems
- Andean highlands producing vicuna and llama fiber
- Luxury fashion centers in Europe, Japan, United States
- Global biomedical laboratories developing llama nanobody therapeutics
#### Flows
- Export of raw vicuna fiber and finished luxury garments
- Capital and market signals from international textile and fiber organizations
- Genetic resources and nanobody-based pharmaceuticals derived from llamas
#### Agents
- International fashion brands, European designers, export companies
- CITES and Vicuña Convention bodies regulating trade
- Global research institutes, pharmaceutical companies and patent holders
#### Causes
- High international demand and prices for fine vicuna fiber garments
- Biotechnological interest in unique camelid antibodies and nanobodies
- Global narratives marketing vicuna products as ecofriendly luxury
#### Effects
- Very small share of garment value reaching Andean communities
- Lobbying by powerful companies influencing national governance
- Potential benefit-sharing debates under the Nagoya protocol for nanobodies

### Cross-Coupling Interactions
- Global fashion demand intensifies local poaching risks and management pressures on vicuna populations
- Improved Bolivian livelihoods and vehicle access reduce transboundary llama caravan traditions
- Biomedical use of llama nanobodies creates distant health benefits unrelated to Andean livelihoods

### Research Gaps or Limitations
- Limited analysis of concrete benefit sharing mechanisms for IPLCs from nanobody commercialization
- Insufficient quantitative assessment of how fiber price volatility shapes local welfare
- Need for deeper study of youth perceptions and future of camelid-based livelihoods

### Search Keywords
- South American camelids telecoupling vicuna llama caravans nanobodies
- Andean biocultural heritage IPBES framework vicuna fiber luxury markets
- llama nanobodies biomedical applications Nagoya protocol benefit sharing

### Extraction Confidence
high
